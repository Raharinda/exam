package com.google.android.material.expandable;

public interface ExpandableWidget {
    boolean isExpanded();

    boolean setExpanded(boolean z);
}
