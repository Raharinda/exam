package com.google.android.material.shape;

import com.google.android.material.internal.Experimental;

@Experimental("The shapes API is currently experimental and subject to change")
public class CornerTreatment {
    public CornerTreatment() {
    }

    public void getCornerPath(float angle, float interpolation, ShapePath shapePath) {
    }
}
