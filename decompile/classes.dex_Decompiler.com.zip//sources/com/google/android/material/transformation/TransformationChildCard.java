package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import com.google.android.material.circularreveal.cardview.CircularRevealCardView;

public class TransformationChildCard extends CircularRevealCardView {
    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public TransformationChildCard(Context context) {
        this(context, (AttributeSet) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public TransformationChildCard(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
