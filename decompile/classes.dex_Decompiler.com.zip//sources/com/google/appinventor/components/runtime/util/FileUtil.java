package com.google.appinventor.components.runtime.util;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.errors.RuntimeError;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URL;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class FileUtil {
    private static final String LOG_TAG = FileUtil.class.getSimpleName();

    private FileUtil() {
    }

    public static String getFileUrl(String str) {
        File file;
        new File(str);
        return file.toURI().toString();
    }

    @Deprecated
    public static byte[] readFile(String str) throws IOException {
        Throwable th;
        new IllegalAccessException();
        int w = Log.w(LOG_TAG, "Calling deprecated function readFile", th);
        return readFile(Form.getActiveForm(), str);
    }

    /* JADX INFO: finally extract failed */
    public static byte[] readFile(Form form, String str) throws IOException {
        File file;
        InputStream openFile;
        Throwable th;
        Form form2 = form;
        String str2 = str;
        if (str2.startsWith("file://")) {
            str2 = str2.substring(7);
        }
        try {
            if (str2.startsWith("/android_asset/")) {
                String str3 = str2;
                openFile = form2.openAsset(str3.substring(str3.lastIndexOf(47) + 1));
            } else {
                new File(str2);
                if (!file.isFile()) {
                    Throwable th2 = th;
                    new FileNotFoundException("Cannot find file: ".concat(String.valueOf(str2)));
                    throw th2;
                }
                openFile = openFile(form2, str2);
            }
            byte[] readStream = IOUtils.readStream(openFile);
            IOUtils.closeQuietly(LOG_TAG, openFile);
            return readStream;
        } catch (Throwable th3) {
            Throwable th4 = th3;
            IOUtils.closeQuietly(LOG_TAG, (Closeable) null);
            throw th4;
        }
    }

    @Deprecated
    public static FileInputStream openFile(String str) throws IOException, PermissionException {
        Throwable th;
        new IllegalAccessException();
        int w = Log.w(LOG_TAG, "Calling deprecated function openFile", th);
        return openFile(Form.getActiveForm(), str);
    }

    public static FileInputStream openFile(Form form, String str) throws IOException {
        FileInputStream fileInputStream;
        Form form2 = form;
        String str2 = str;
        if (needsReadPermission(form2, str2.startsWith("/") ? "file://".concat(String.valueOf(str2)) : str2)) {
            form2.assertPermission("android.permission.READ_EXTERNAL_STORAGE");
        }
        new FileInputStream(str2);
        return fileInputStream;
    }

    @Deprecated
    public static FileInputStream openFile(File file) throws IOException, PermissionException {
        Throwable th;
        new IllegalAccessException();
        int w = Log.w(LOG_TAG, "Calling deprecated function openFile", th);
        return openFile(Form.getActiveForm(), file.getAbsolutePath());
    }

    public static FileInputStream openFile(Form form, File file) throws IOException, PermissionException {
        return openFile(form, file.getAbsolutePath());
    }

    @Deprecated
    public static FileInputStream openFile(URI uri) throws IOException, PermissionException {
        Throwable th;
        new IllegalAccessException();
        int w = Log.w(LOG_TAG, "Calling deprecated function openFile", th);
        return openFile(Form.getActiveForm(), uri);
    }

    public static FileInputStream openFile(Form form, URI uri) throws IOException, PermissionException {
        FileInputStream fileInputStream;
        File file;
        Form form2 = form;
        URI uri2 = uri;
        if (MediaUtil.isExternalFileUrl(form2, uri2.toString())) {
            form2.assertPermission("android.permission.READ_EXTERNAL_STORAGE");
        }
        new File(uri2);
        new FileInputStream(file);
        return fileInputStream;
    }

    /* JADX INFO: finally extract failed */
    public static String downloadUrlToFile(String str, String str2) throws IOException {
        URL url;
        new URL(str);
        InputStream openStream = url.openStream();
        try {
            String writeStreamToFile = writeStreamToFile(openStream, str2);
            openStream.close();
            return writeStreamToFile;
        } catch (Throwable th) {
            Throwable th2 = th;
            openStream.close();
            throw th2;
        }
    }

    /* JADX INFO: finally extract failed */
    public static String writeFile(byte[] bArr, String str) throws IOException {
        InputStream inputStream;
        new ByteArrayInputStream(bArr);
        InputStream inputStream2 = inputStream;
        try {
            String writeStreamToFile = writeStreamToFile(inputStream2, str);
            inputStream2.close();
            return writeStreamToFile;
        } catch (Throwable th) {
            Throwable th2 = th;
            inputStream2.close();
            throw th2;
        }
    }

    /* JADX INFO: finally extract failed */
    public static String copyFile(String str, String str2) throws IOException {
        InputStream inputStream;
        new FileInputStream(str);
        InputStream inputStream2 = inputStream;
        try {
            String writeStreamToFile = writeStreamToFile(inputStream2, str2);
            inputStream2.close();
            return writeStreamToFile;
        } catch (Throwable th) {
            Throwable th2 = th;
            inputStream2.close();
            throw th2;
        }
    }

    public static boolean copyFile(Form form, ScopedFile scopedFile, ScopedFile scopedFile2) throws IOException {
        Form form2 = form;
        ScopedFile scopedFile3 = scopedFile;
        ScopedFile scopedFile4 = scopedFile2;
        if (Build.VERSION.SDK_INT < 24 || scopedFile3.getScope() == FileScope.Shared || scopedFile4.getScope() == FileScope.Shared) {
            try {
                InputStream openForReading = openForReading(form2, scopedFile3);
                OutputStream openForWriting = openForWriting(form2, scopedFile3);
                byte[] bArr = new byte[4096];
                while (true) {
                    int read = openForReading.read(bArr);
                    int i = read;
                    if (read <= 0) {
                        break;
                    }
                    openForWriting.write(bArr, 0, i);
                }
                IOUtils.closeQuietly(LOG_TAG, openForReading);
                IOUtils.closeQuietly(LOG_TAG, openForWriting);
            } catch (Throwable th) {
                Throwable th2 = th;
                IOUtils.closeQuietly(LOG_TAG, (Closeable) null);
                IOUtils.closeQuietly(LOG_TAG, (Closeable) null);
                throw th2;
            }
        } else {
            Path copy = Files.copy(Paths.get(scopedFile3.resolve(form2).toURI()), Paths.get(scopedFile4.resolve(form2).toURI()), new CopyOption[]{StandardCopyOption.REPLACE_EXISTING});
        }
        return true;
    }

    /* JADX INFO: finally extract failed */
    public static String writeStreamToFile(InputStream inputStream, String str) throws IOException {
        File file;
        OutputStream outputStream;
        new File(str);
        File file2 = file;
        File file3 = file2;
        boolean mkdirs = file2.getParentFile().mkdirs();
        new FileOutputStream(file3);
        OutputStream outputStream2 = outputStream;
        try {
            copy(inputStream, outputStream2);
            String uri = file3.toURI().toString();
            outputStream2.flush();
            outputStream2.close();
            return uri;
        } catch (Throwable th) {
            Throwable th2 = th;
            outputStream2.flush();
            outputStream2.close();
            throw th2;
        }
    }

    public static void copy(InputStream inputStream, OutputStream outputStream) throws IOException {
        OutputStream outputStream2;
        InputStream inputStream2;
        new BufferedOutputStream(outputStream, 4096);
        OutputStream outputStream3 = outputStream2;
        new BufferedInputStream(inputStream, 4096);
        InputStream inputStream3 = inputStream2;
        while (true) {
            int read = inputStream3.read();
            int i = read;
            if (read != -1) {
                outputStream3.write(i);
            } else {
                outputStream3.flush();
                return;
            }
        }
    }

    public static File getPictureFile(String str) throws IOException, FileException {
        Throwable th;
        new IllegalAccessException();
        int w = Log.w(LOG_TAG, "Calling deprecated function getPictureFile", th);
        return getPictureFile(Form.getActiveForm(), str);
    }

    public static File getPictureFile(Form form, String str) throws IOException, FileException {
        return hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(form, "Pictures", str);
    }

    @Deprecated
    public static File getRecordingFile(String str) throws IOException, FileException {
        return getRecordingFile(Form.getActiveForm(), str);
    }

    public static File getRecordingFile(Form form, String str) throws IOException, FileException {
        return hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(form, "Recordings", str);
    }

    @Deprecated
    public static File getDownloadFile(String str) throws IOException, FileException {
        Throwable th;
        new IllegalAccessException();
        int w = Log.w(LOG_TAG, "Calling deprecated function getDownloadFile", th);
        return getDownloadFile(Form.getActiveForm(), str);
    }

    public static File getDownloadFile(Form form, String str) throws IOException, FileException {
        return hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(form, "Downloads", str);
    }

    public static ScopedFile getScopedPictureFile(Form form, String str) {
        String str2;
        StringBuilder sb;
        ScopedFile scopedFile;
        String str3 = str;
        String str4 = "Pictures";
        FileScope DefaultFileScope = form.DefaultFileScope();
        FileScope fileScope = DefaultFileScope;
        if (DefaultFileScope == FileScope.Legacy) {
            str2 = "/My Documents/".concat(String.valueOf(str4));
        } else {
            str2 = str4;
            if (fileScope == FileScope.Asset) {
                fileScope = FileScope.Private;
            }
        }
        new StringBuilder();
        new ScopedFile(fileScope, sb.append(str2).append("/kodular_").append(System.currentTimeMillis()).append(".").append(str3).toString());
        return scopedFile;
    }

    private static File hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(Form form, String str, String str2) throws IOException, FileException {
        StringBuilder sb;
        Throwable th;
        StringBuilder sb2;
        new StringBuilder("My Documents/");
        File externalFile = getExternalFile(form, sb.append(str).append("/kodular_").append(System.currentTimeMillis()).append(".").append(str2).toString());
        File file = externalFile;
        File parentFile = externalFile.getParentFile();
        File file2 = parentFile;
        if (parentFile.exists() || file2.mkdirs()) {
            return file;
        }
        Throwable th2 = th;
        new StringBuilder("Unable to create directory: ");
        new IOException(sb2.append(file2.getAbsolutePath()).toString());
        throw th2;
    }

    @Deprecated
    public static File getExternalFile(String str) throws IOException, FileException, SecurityException {
        return getExternalFile(Form.getActiveForm(), str);
    }

    public static File getExternalFile(Form form, String str) throws FileException {
        File file;
        Form form2 = form;
        String str2 = str;
        if (form2.DefaultFileScope() == FileScope.Legacy && !str2.startsWith("/")) {
            str2 = "/".concat(String.valueOf(str2));
        }
        String resolveFileName = resolveFileName(form2, str2, form2.DefaultFileScope());
        if (isExternalStorageUri(form2, resolveFileName)) {
            checkExternalStorageWriteable();
        }
        if (needsPermission(form2, resolveFileName)) {
            form2.assertPermission("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        new File(URI.create(resolveFileName));
        return file;
    }

    public static File getExternalFile(Form form, String str, boolean z, boolean z2) throws IOException, FileException {
        Throwable th;
        StringBuilder sb;
        Throwable th2;
        StringBuilder sb2;
        boolean z3 = z2;
        File externalFile = getExternalFile(form, str);
        File file = externalFile;
        File parentFile = externalFile.getParentFile();
        if (z && !parentFile.exists() && !parentFile.mkdirs()) {
            Throwable th3 = th2;
            new StringBuilder("Unable to create directory ");
            new IOException(sb2.append(parentFile.getAbsolutePath()).toString());
            throw th3;
        } else if (!z3 || !file.exists() || file.delete()) {
            return file;
        } else {
            Throwable th4 = th;
            new StringBuilder("Cannot overwrite existing file ");
            new IOException(sb.append(file.getAbsolutePath()).toString());
            throw th4;
        }
    }

    public static File getExternalFile(Form form, String str, FileScope fileScope) throws FileException, PermissionException {
        File file;
        new File(URI.create(resolveFileName(form, str, fileScope)));
        return file;
    }

    public static File getExternalFile(Form form, String str, FileScope fileScope, FileAccessMode fileAccessMode, boolean z) throws IOException, FileException, PermissionException {
        Throwable th;
        StringBuilder sb;
        FileAccessMode fileAccessMode2 = fileAccessMode;
        File externalFile = getExternalFile(form, str, fileScope);
        if (z && fileAccessMode2 != FileAccessMode.READ) {
            File parentFile = externalFile.getParentFile();
            File file = parentFile;
            if (!parentFile.exists() && !file.mkdirs()) {
                Throwable th2 = th;
                new StringBuilder("Unable to create directory ");
                new IOException(sb.append(file.getAbsolutePath()).toString());
                throw th2;
            }
        }
        return externalFile;
    }

    public static void checkExternalStorageWriteable() throws FileException {
        Throwable th;
        Throwable th2;
        String externalStorageState = Environment.getExternalStorageState();
        if (!"mounted".equals(externalStorageState)) {
            if ("mounted_ro".equals(externalStorageState)) {
                Throwable th3 = th2;
                new FileException(ErrorMessages.ERROR_MEDIA_EXTERNAL_STORAGE_READONLY);
                throw th3;
            }
            Throwable th4 = th;
            new FileException(ErrorMessages.ERROR_MEDIA_EXTERNAL_STORAGE_NOT_AVAILABLE);
            throw th4;
        }
    }

    public static String resolveFileName(Form form, String str, FileScope fileScope) {
        File externalFile;
        File file;
        File file2;
        StringBuilder sb;
        File file3;
        File file4;
        File file5;
        File file6;
        File file7;
        File file8;
        Form form2 = form;
        String str2 = str;
        FileScope fileScope2 = fileScope;
        if (str2.startsWith("//")) {
            new File(form2.getAssetPath(str2.substring(2)).substring(7));
            externalFile = file8;
        } else if (fileScope2 == FileScope.App) {
            new File(form2.getExternalFilesDir(""), str2);
            externalFile = file7;
        } else if (fileScope2 == FileScope.Asset) {
            new File(form2.getAssetPath(str2).substring(7));
            externalFile = file6;
        } else if (fileScope2 == FileScope.Cache) {
            new File(form2.getCachePath(str2).substring(7));
            externalFile = file5;
        } else if ((fileScope2 == FileScope.Legacy || fileScope2 == null) && str2.startsWith("/")) {
            new File(QUtil.getExternalStorageDir(form2, false, true), str2.substring(1));
            externalFile = file4;
        } else if (fileScope2 == FileScope.Private) {
            new File(form2.getPrivatePath(str2).substring(7));
            externalFile = file3;
        } else if (fileScope2 == FileScope.Shared) {
            new StringBuilder();
            new File(sb.append(Environment.getExternalStorageDirectory()).append("/").append(str2).toString());
            externalFile = file2;
        } else if (!str2.startsWith("/")) {
            new File(form2.getPrivatePath(str2).substring(7));
            externalFile = file;
        } else {
            externalFile = getExternalFile(form2, str2.substring(1), fileScope2);
        }
        return Uri.fromFile(externalFile).toString();
    }

    public static String resolveFileName(Form form, ScopedFile scopedFile) {
        ScopedFile scopedFile2 = scopedFile;
        return resolveFileName(form, scopedFile2.getFileName(), scopedFile2.getScope());
    }

    public static boolean needsPermission(Form form, String str) {
        Form form2 = form;
        String str2 = str;
        if (isAssetUri(form2, str2)) {
            return false;
        }
        if (isPrivateUri(form2, str2)) {
            return false;
        }
        if (isAppSpecificExternalUri(form2, str2)) {
            return false;
        }
        return isExternalStorageUri(form2, str2);
    }

    public static boolean needsReadPermission(Form form, String str) {
        return needsPermission(form, str);
    }

    public static boolean needsReadPermission(ScopedFile scopedFile) {
        switch (scopedFile.getScope()) {
            case Legacy:
            case Shared:
                return true;
            default:
                return false;
        }
    }

    public static boolean needsWritePermission(Form form, String str) {
        Form form2 = form;
        String str2 = str;
        if (Build.VERSION.SDK_INT >= 30) {
            return false;
        }
        return needsPermission(form2, str2);
    }

    public static boolean needsWritePermission(ScopedFile scopedFile) {
        return needsWritePermission(scopedFile.getScope());
    }

    public static boolean needsWritePermission(FileScope fileScope) {
        switch (fileScope) {
            case Legacy:
            case Shared:
                return Build.VERSION.SDK_INT < 30;
            default:
                return false;
        }
    }

    public static boolean needsExternalStorage(Form form, ScopedFile scopedFile) {
        ScopedFile scopedFile2 = scopedFile;
        Form form2 = form;
        return isExternalStorageUri(form2, resolveFileName(form2, scopedFile2.getFileName(), scopedFile2.getScope()));
    }

    public static boolean isAssetUri(Form form, String str) {
        return str.startsWith(form.getAssetPath(""));
    }

    public static boolean isPrivateUri(Form form, String str) {
        return str.startsWith(form.getPrivatePath(""));
    }

    public static boolean isAppSpecificExternalUri(Form form, String str) {
        StringBuilder sb;
        new StringBuilder("file://");
        return str.startsWith(sb.append(form.getExternalFilesDir("").getAbsolutePath()).toString());
    }

    public static boolean isExternalStorageUri(Form form, String str) {
        StringBuilder sb;
        StringBuilder sb2;
        Form form2 = form;
        String str2 = str;
        if (str2.startsWith("file:///sdcard/") || str2.startsWith("file:///storage")) {
            return true;
        }
        new StringBuilder("file://");
        if (!str2.startsWith(sb.append(Environment.getExternalStorageDirectory().getAbsolutePath()).toString())) {
            new StringBuilder("file://");
            if (!str2.startsWith(sb2.append(form2.getExternalFilesDir("").getAbsolutePath()).toString())) {
                return false;
            }
        }
        return true;
    }

    public static class FileException extends RuntimeError {
        private final int UT8jc0jwpnlGoVnBZm9Vqfc7zQxpOFTo7zW0ZxKDjXZZsrQ7LsG7hsoko7RBNNg5;

        public FileException(int i) {
            this.UT8jc0jwpnlGoVnBZm9Vqfc7zQxpOFTo7zW0ZxKDjXZZsrQ7LsG7hsoko7RBNNg5 = i;
        }

        public int getErrorMessageNumber() {
            return this.UT8jc0jwpnlGoVnBZm9Vqfc7zQxpOFTo7zW0ZxKDjXZZsrQ7LsG7hsoko7RBNNg5;
        }
    }

    public static String getNeededPermission(Form form, String str, FileAccessMode fileAccessMode) {
        Throwable th;
        Throwable th2;
        Form form2 = form;
        String str2 = str;
        FileAccessMode fileAccessMode2 = fileAccessMode;
        if (str2 == null) {
            Throwable th3 = th2;
            new NullPointerException("path cannot be null");
            throw th3;
        }
        if (str2.startsWith("file:") || str2.startsWith("/")) {
            if (str2.startsWith("/")) {
                str2 = "file://".concat(String.valueOf(str2));
            }
            if (isExternalStorageUri(form2, str2)) {
                if (isAppSpecificExternalUri(form2, str2) && Build.VERSION.SDK_INT >= 19) {
                    return null;
                }
                if (fileAccessMode2 == FileAccessMode.READ) {
                    return "android.permission.READ_EXTERNAL_STORAGE";
                }
                return "android.permission.WRITE_EXTERNAL_STORAGE";
            }
        } else if (!str2.contains(":")) {
            Throwable th4 = th;
            new IllegalArgumentException("path cannot be relative");
            throw th4;
        }
        return null;
    }

    public static boolean moveFile(Form form, ScopedFile scopedFile, ScopedFile scopedFile2) throws IOException {
        Throwable th;
        Form form2 = form;
        ScopedFile scopedFile3 = scopedFile;
        ScopedFile scopedFile4 = scopedFile2;
        if (Build.VERSION.SDK_INT < 26 || scopedFile3.getScope() == FileScope.Shared || scopedFile4.getScope() == FileScope.Shared) {
            byte[] bArr = new byte[4096];
            try {
                InputStream openForReading = openForReading(form2, scopedFile3);
                OutputStream openForWriting = openForWriting(form2, scopedFile4);
                while (true) {
                    int read = openForReading.read(bArr);
                    int i = read;
                    if (read <= 0) {
                        break;
                    }
                    openForWriting.write(bArr, 0, i);
                }
                IOUtils.closeQuietly(LOG_TAG, openForReading);
                IOUtils.closeQuietly(LOG_TAG, openForWriting);
                File resolve = scopedFile3.resolve(form2);
                File resolve2 = scopedFile4.resolve(form2);
                if (resolve.delete()) {
                    return true;
                }
                if (resolve2.delete()) {
                    return false;
                }
                Throwable th2 = th;
                new IOException("Unable to delete fresh file");
                throw th2;
            } catch (Throwable th3) {
                Throwable th4 = th3;
                IOUtils.closeQuietly(LOG_TAG, (Closeable) null);
                IOUtils.closeQuietly(LOG_TAG, (Closeable) null);
                throw th4;
            }
        } else {
            Path move = Files.move(Paths.get(scopedFile3.resolve(form2).toURI()), Paths.get(scopedFile4.resolve(form2).toURI()), new CopyOption[]{StandardCopyOption.REPLACE_EXISTING});
            return true;
        }
    }

    public static boolean removeDirectory(File file, boolean z) throws IOException {
        boolean z2;
        boolean delete;
        Throwable th;
        Throwable th2;
        File file2 = file;
        boolean z3 = z;
        if (file2 == null) {
            Throwable th3 = th2;
            new NullPointerException();
            throw th3;
        } else if (!file2.isDirectory()) {
            Throwable th4 = th;
            new IllegalArgumentException();
            throw th4;
        } else {
            File[] listFiles = file2.listFiles();
            File[] fileArr = listFiles;
            if (listFiles == null) {
                return file2.delete();
            }
            if (!z3 && fileArr.length > 0) {
                return false;
            }
            boolean z4 = true;
            int length = fileArr.length;
            for (int i = 0; i < length; i++) {
                File file3 = fileArr[i];
                File file4 = file3;
                if (file3.isDirectory()) {
                    z2 = z4;
                    delete = removeDirectory(file2, z3);
                } else {
                    z2 = z4;
                    delete = file4.delete();
                }
                z4 = z2 & delete;
            }
            return z4 && file2.delete();
        }
    }

    /* JADX INFO: finally extract failed */
    public static InputStream openForReading(Form form, ScopedFile scopedFile) throws IOException {
        InputStream inputStream;
        File file;
        InputStream inputStream2;
        File file2;
        InputStream inputStream3;
        File file3;
        InputStream inputStream4;
        File file4;
        Throwable th;
        StringBuilder sb;
        Form form2 = form;
        ScopedFile scopedFile2 = scopedFile;
        switch (scopedFile2.getScope()) {
            case Legacy:
                new File(Environment.getExternalStorageDirectory(), scopedFile2.getFileName());
                new FileInputStream(file2);
                return inputStream2;
            case Shared:
                String[] split = scopedFile2.getFileName().split("/", 2);
                String[] strArr = split;
                Uri hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(split[0]);
                String[] strArr2 = new String[2];
                strArr2[0] = "_id";
                String[] strArr3 = strArr2;
                strArr3[1] = "_display_name";
                String[] strArr4 = strArr3;
                try {
                    Cursor query = form2.getContentResolver().query(hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME, strArr4, "_display_name = ?", new String[]{strArr[1]}, (String) null);
                    Cursor cursor = query;
                    int columnIndexOrThrow = query.getColumnIndexOrThrow("_id");
                    if (!cursor.moveToFirst()) {
                        IOUtils.closeQuietly(LOG_TAG, cursor);
                        break;
                    } else {
                        InputStream openInputStream = form2.getContentResolver().openInputStream(ContentUris.withAppendedId(hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME, cursor.getLong(columnIndexOrThrow)));
                        IOUtils.closeQuietly(LOG_TAG, cursor);
                        return openInputStream;
                    }
                } catch (Throwable th2) {
                    Throwable th3 = th2;
                    IOUtils.closeQuietly(LOG_TAG, (Closeable) null);
                    throw th3;
                }
            case Asset:
                return form2.openAsset(scopedFile2.getFileName());
            case App:
                new File(form2.getExternalFilesDir(""), scopedFile2.getFileName());
                new FileInputStream(file4);
                return inputStream4;
            case Cache:
                new File(URI.create(form2.getCachePath(scopedFile2.getFileName())));
                new FileInputStream(file3);
                return inputStream3;
            case Private:
                new File(URI.create(form2.getPrivatePath(scopedFile2.getFileName())));
                new FileInputStream(file);
                return inputStream;
        }
        Throwable th4 = th;
        new StringBuilder("Unsupported file scope: ");
        new IOException(sb.append(scopedFile2.getScope()).toString());
        throw th4;
    }

    public static OutputStream openForWriting(Form form, ScopedFile scopedFile) throws IOException {
        ContentValues contentValues;
        Throwable th;
        Throwable th2;
        Throwable th3;
        StringBuilder sb;
        OutputStream outputStream;
        File file;
        OutputStream outputStream2;
        File file2;
        OutputStream outputStream3;
        File file3;
        OutputStream outputStream4;
        File file4;
        Throwable th4;
        Throwable th5;
        StringBuilder sb2;
        Form form2 = form;
        ScopedFile scopedFile2 = scopedFile;
        switch (scopedFile2.getScope()) {
            case Legacy:
                new File(Environment.getExternalStorageDirectory(), scopedFile2.getFileName());
                new FileOutputStream(file2);
                return outputStream2;
            case Shared:
                String[] split = scopedFile2.getFileName().split("/", 2);
                new ContentValues();
                ContentValues contentValues2 = contentValues;
                ContentValues contentValues3 = contentValues2;
                contentValues2.put("_display_name", split[1]);
                contentValues3.put("mime_type", "");
                contentValues3.put("relative_path", split[0]);
                ContentResolver contentResolver = form2.getContentResolver();
                Uri hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(split[0]);
                Uri uri = hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;
                if (hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME == null) {
                    Throwable th6 = th3;
                    new StringBuilder("Unrecognized shared folder: ");
                    new IOException(sb.append(split[0]).toString());
                    throw th6;
                }
                Uri insert = contentResolver.insert(uri, contentValues3);
                Uri uri2 = insert;
                if (insert == null) {
                    Throwable th7 = th2;
                    new IOException("Unable to insert MediaStore entry for shared content");
                    throw th7;
                }
                OutputStream openOutputStream = contentResolver.openOutputStream(uri2);
                OutputStream outputStream5 = openOutputStream;
                if (openOutputStream != null) {
                    return outputStream5;
                }
                Throwable th8 = th;
                new IOException("Unable to open stream for writing");
                throw th8;
            case Asset:
                Throwable th9 = th4;
                new IOException("Assets are read-only.");
                throw th9;
            case App:
                new File(form2.getExternalFilesDir(""), scopedFile2.getFileName());
                new FileOutputStream(file4);
                return outputStream4;
            case Cache:
                new File(URI.create(form2.getCachePath(scopedFile2.getFileName())));
                new FileOutputStream(file3);
                return outputStream3;
            case Private:
                new File(URI.create(form2.getPrivatePath(scopedFile2.getFileName())));
                new FileOutputStream(file);
                return outputStream;
            default:
                Throwable th10 = th5;
                new StringBuilder("Unsupported file scope: ");
                new IOException(sb2.append(scopedFile2.getScope()).toString());
                throw th10;
        }
    }

    /* JADX INFO: finally extract failed */
    public static List<String> listDirectory(Form form, ScopedFile scopedFile) throws IOException {
        List<String> list;
        StringBuilder sb;
        StringBuilder sb2;
        File file;
        Throwable th;
        StringBuilder sb3;
        Form form2 = form;
        ScopedFile scopedFile2 = scopedFile;
        switch (scopedFile2.getScope()) {
            case Legacy:
            case App:
            case Cache:
            case Private:
                break;
            case Shared:
                String fileName = scopedFile2.getFileName();
                String str = fileName;
                if (fileName.startsWith("/")) {
                    str = str.substring(1);
                }
                String[] split = str.split("/", 2);
                ContentResolver contentResolver = form2.getContentResolver();
                Uri hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(split[0]);
                Uri uri = hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;
                if (hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME == null) {
                    uri = MediaStore.Files.getContentUri("external");
                }
                try {
                    String str2 = Build.VERSION.SDK_INT < 29 ? "_data" : "relative_path";
                    String[] strArr = new String[2];
                    strArr[0] = "_display_name";
                    String[] strArr2 = strArr;
                    strArr2[1] = str2;
                    Cursor query = contentResolver.query(uri, strArr2, (String) null, (String[]) null, (String) null);
                    Cursor cursor = query;
                    int columnIndex = query.getColumnIndex("_display_name");
                    int columnIndex2 = cursor.getColumnIndex(str2);
                    new ArrayList();
                    List<String> list2 = list;
                    new StringBuilder();
                    String sb4 = sb.append(QUtil.getExternalStoragePath(form2, false, true)).append("/").toString();
                    while (cursor.moveToNext()) {
                        String string = cursor.getString(columnIndex);
                        String string2 = cursor.getString(columnIndex2);
                        if (Build.VERSION.SDK_INT < 29) {
                            boolean add = list2.add(string2.replace(sb4, ""));
                        } else {
                            new StringBuilder();
                            boolean add2 = list2.add(sb2.append(string2).append(string).toString());
                        }
                    }
                    List<String> list3 = list2;
                    IOUtils.closeQuietly(LOG_TAG, cursor);
                    return list3;
                } catch (Throwable th2) {
                    Throwable th3 = th2;
                    IOUtils.closeQuietly(LOG_TAG, (Closeable) null);
                    throw th3;
                }
            case Asset:
                if (!form2.isRepl()) {
                    String[] list4 = form2.getAssets().list(scopedFile2.getFileName());
                    String[] strArr3 = list4;
                    if (list4 != null) {
                        return Arrays.asList(strArr3);
                    }
                    return Collections.emptyList();
                }
                break;
            default:
                Throwable th4 = th;
                new StringBuilder("Unsupported file scope: ");
                new IOException(sb3.append(scopedFile2.getScope()).toString());
                throw th4;
        }
        new File(URI.create(resolveFileName(form2, scopedFile2.getFileName(), scopedFile2.getScope())));
        String[] list5 = file.list();
        String[] strArr4 = list5;
        if (list5 != null) {
            return Arrays.asList(strArr4);
        }
        return null;
    }

    private static Uri hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(String str) {
        String str2 = str;
        if ("DCIM".equals(str2) || "Pictures".equals(str2) || "Screenshots".equals(str2)) {
            if (Build.VERSION.SDK_INT >= 29) {
                return MediaStore.Images.Media.getContentUri("external");
            }
            return MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        } else if ("Videos".equals(str2) || "Movies".equals(str2)) {
            if (Build.VERSION.SDK_INT >= 29) {
                return MediaStore.Video.Media.getContentUri("external");
            }
            return MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        } else if ("Audio".equals(str2) || "Music".equals(str2)) {
            if (Build.VERSION.SDK_INT >= 29) {
                return MediaStore.Audio.Media.getContentUri("external");
            }
            return MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        } else if (Build.VERSION.SDK_INT < 30 || (!"Download".equals(str2) && !"Downloads".equals(str2))) {
            return MediaStore.Files.getContentUri("external");
        } else {
            return MediaStore.Downloads.getContentUri("external");
        }
    }
}
