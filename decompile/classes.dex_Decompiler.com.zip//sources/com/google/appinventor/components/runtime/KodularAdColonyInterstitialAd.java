package com.google.appinventor.components.runtime;

import android.content.Context;
import android.util.Log;
import com.adcolony.sdk.AdColony;
import com.adcolony.sdk.AdColonyAdOptions;
import com.adcolony.sdk.AdColonyAppOptions;
import com.adcolony.sdk.AdColonyInterstitial;
import com.adcolony.sdk.AdColonyInterstitialListener;
import com.adcolony.sdk.AdColonyZone;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesActivities;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.annotations.androidmanifest.ActivityElement;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.util.KodularAdsUtil;
import com.google.appinventor.components.runtime.util.KodularAnalyticsUtil;
import com.google.appinventor.components.runtime.util.KodularGDPRUtil;
import com.google.appinventor.components.runtime.util.OnInitializeListener;

@DesignerComponent(category = ComponentCategory.ADVERTISING, description = "...in ode messages file", helpUrl = "https://docs.kodular.io/components/monetization/adcolony-interstitial/", iconName = "images/adcolony.png", nonVisible = true, version = 1)
@UsesLibraries({"AdColony.jar", "play-services-ads-identifier.jar", "play-services-ads-identifier.aar", "play-services-basement.jar", "play-services-basement.aar"})
@SimpleObject
@UsesActivities(activities = {@ActivityElement(configChanges = "keyboardHidden|orientation|screenSize", hardwareAccelerated = "true", name = "com.adcolony.sdk.AdColonyAdViewActivity")})
@UsesPermissions({"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE", "android.permission.VIBRATE", "com.google.android.gms.permission.AD_ID"})
public class KodularAdColonyInterstitialAd extends AndroidNonvisibleComponent implements OnDestroyListener, OnInitializeListener {
    private boolean AsUIHfRHW1pScN9YQW0IsOeuFdHXhbXb53xXbDg8x2ZIBxv57XORnQnTS1wprCIt = false;
    private String appId = "";
    private ComponentContainer container;
    private Context context;
    private String f9MsIiC6MxciaFVJmtpdDaPCPu1tdZDTYoHbgfSwKXBhLXF2LgZTKbRmVlZ1kb0Z = "";
    /* access modifiers changed from: private */
    public Form form;
    private AdColonyAppOptions hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

    /* renamed from: hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME  reason: collision with other field name */
    private AdColonyInterstitial f166hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

    /* renamed from: hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME  reason: collision with other field name */
    private AdColonyInterstitialListener f167hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;
    private String jfz4esSp2gG8GcabwIhRTwYj9V6OBMxneQTmg596S0YedndAxvJdoaPHqPTMCjiO = "";

    static /* synthetic */ AdColonyInterstitial hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(KodularAdColonyInterstitialAd kodularAdColonyInterstitialAd, AdColonyInterstitial adColonyInterstitial) {
        AdColonyInterstitial adColonyInterstitial2 = adColonyInterstitial;
        AdColonyInterstitial adColonyInterstitial3 = adColonyInterstitial2;
        kodularAdColonyInterstitialAd.f166hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = adColonyInterstitial3;
        return adColonyInterstitial2;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public KodularAdColonyInterstitialAd(com.google.appinventor.components.runtime.ComponentContainer r7) {
        /*
            r6 = this;
            r0 = r6
            r1 = r7
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            java.lang.String r3 = ""
            r2.appId = r3
            r2 = r0
            java.lang.String r3 = ""
            r2.f9MsIiC6MxciaFVJmtpdDaPCPu1tdZDTYoHbgfSwKXBhLXF2LgZTKbRmVlZ1kb0Z = r3
            r2 = r0
            r3 = 0
            r2.AsUIHfRHW1pScN9YQW0IsOeuFdHXhbXb53xXbDg8x2ZIBxv57XORnQnTS1wprCIt = r3
            r2 = r0
            java.lang.String r3 = ""
            r2.jfz4esSp2gG8GcabwIhRTwYj9V6OBMxneQTmg596S0YedndAxvJdoaPHqPTMCjiO = r3
            r2 = r0
            r3 = r1
            r2.container = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.context = r3
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.form = r3
            r2 = r0
            com.google.appinventor.components.runtime.Form r2 = r2.form
            r3 = r0
            r2.registerForOnDestroy(r3)
            r2 = r0
            com.google.appinventor.components.runtime.Form r2 = r2.form
            r3 = r0
            r2.registerForOnInitialize(r3)
            r2 = r0
            com.adcolony.sdk.AdColonyAppOptions r3 = new com.adcolony.sdk.AdColonyAppOptions
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r2.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r3
            java.lang.String r2 = "AdColony Interstitial Ad"
            java.lang.String r3 = "Kodular AdColony Interstitial Ad created"
            int r2 = android.util.Log.d(r2, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.appinventor.components.runtime.KodularAdColonyInterstitialAd.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    public void onInitialize() {
        AdColonyInterstitialListener adColonyInterstitialListener;
        if (AppID().isEmpty() || ZoneID().isEmpty()) {
            boolean configure = AdColony.configure(this.container.$context(), this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME, KodularAdsUtil.AD_COLONY_APP_ID, new String[]{KodularAdsUtil.AD_COLONY_ZONE_ID});
            this.jfz4esSp2gG8GcabwIhRTwYj9V6OBMxneQTmg596S0YedndAxvJdoaPHqPTMCjiO = KodularAdsUtil.AD_COLONY_ZONE_ID;
        } else {
            boolean configure2 = AdColony.configure(this.container.$context(), this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME, AppID(), new String[]{ZoneID()});
            this.jfz4esSp2gG8GcabwIhRTwYj9V6OBMxneQTmg596S0YedndAxvJdoaPHqPTMCjiO = ZoneID();
        }
        new AdColonyInterstitialListener(this) {
            private /* synthetic */ KodularAdColonyInterstitialAd hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

            {
                this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r5;
            }

            public final void onRequestFilled(AdColonyInterstitial adColonyInterstitial) {
                KodularAnalyticsUtil.adEvent(KodularAnalyticsUtil.Ads.NETWORK_ADCOLONY, KodularAnalyticsUtil.Ads.FORMAT_INTERSTITIAL, this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.form);
                AdColonyInterstitial hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME2 = KodularAdColonyInterstitialAd.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME, adColonyInterstitial);
                this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.AdLoaded();
                int i = Log.i("AdColony Interstitial Ad", "AdColony Interstitial: Interstitial ad loaded");
            }

            public final void onRequestNotFilled(AdColonyZone adColonyZone) {
                AdColonyZone adColonyZone2 = adColonyZone;
                this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.Error("Request not filled.");
                int e = Log.e("AdColony Interstitial Ad", "AdColony Interstitial: Interstitial ad failed to load: request not filled");
            }

            public final void onOpened(AdColonyInterstitial adColonyInterstitial) {
                AdColonyInterstitial adColonyInterstitial2 = adColonyInterstitial;
                this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.AdOpened();
                int i = Log.i("AdColony Interstitial Ad", "AdColony Interstitial: Interstitial ad opened");
            }

            public final void onExpiring(AdColonyInterstitial adColonyInterstitial) {
                AdColonyInterstitial adColonyInterstitial2 = adColonyInterstitial;
                this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.AdExpiring();
                int i = Log.i("AdColony Interstitial Ad", "AdColony Interstitial: Interstitial ad is expiring");
            }
        };
        this.f167hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = adColonyInterstitialListener;
    }

    @SimpleFunction(description = "Loads a new ad.")
    public void LoadAd() {
        boolean requestInterstitial = AdColony.requestInterstitial(this.jfz4esSp2gG8GcabwIhRTwYj9V6OBMxneQTmg596S0YedndAxvJdoaPHqPTMCjiO, this.f167hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME, (AdColonyAdOptions) null);
    }

    @SimpleFunction(description = "Shows an ad to the user.")
    public void ShowAd() {
        if (this.f166hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME != null) {
            if (this.f166hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.isExpired()) {
                AdExpiring();
            } else {
                boolean show = this.f166hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.show();
            }
        }
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, userVisible = false)
    public String AppID() {
        return this.appId;
    }

    @DesignerProperty
    @SimpleProperty(userVisible = false)
    public void AppID(String str) {
        String str2 = str;
        this.appId = str2;
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, userVisible = false)
    public String ZoneID() {
        return this.f9MsIiC6MxciaFVJmtpdDaPCPu1tdZDTYoHbgfSwKXBhLXF2LgZTKbRmVlZ1kb0Z;
    }

    @DesignerProperty
    @SimpleProperty(userVisible = false)
    public void ZoneID(String str) {
        String str2 = str;
        this.f9MsIiC6MxciaFVJmtpdDaPCPu1tdZDTYoHbgfSwKXBhLXF2LgZTKbRmVlZ1kb0Z = str2;
    }

    @SimpleEvent(description = "Called when an ad request failed. The message will display the reason for why the ad failed.")
    public void Error(String str) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "Error", str);
    }

    @SimpleEvent(description = "Called when the ad is expiring. You should load a new ad.")
    public void AdExpiring() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "AdExpiring", new Object[0]);
    }

    @SimpleEvent(description = "Called when an ad is received.")
    public void AdLoaded() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "AdLoaded", new Object[0]);
    }

    @SimpleEvent(description = "Called when an ad was opened.")
    public void AdOpened() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "AdOpened", new Object[0]);
    }

    @SimpleEvent(description = "Called when an ad request failed to load. The message will display the error code and error message.")
    public void AdFailedToLoad(int i, String str) {
        Object[] objArr = new Object[2];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = str;
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "AdFailedToLoad", objArr2);
    }

    @SimpleProperty(description = "If set to true the user allowed the ad network to show personalized ads. You only need to request the consent from european users.")
    public void UserConsent(boolean z) {
        boolean z2 = z;
        this.AsUIHfRHW1pScN9YQW0IsOeuFdHXhbXb53xXbDg8x2ZIBxv57XORnQnTS1wprCIt = z2;
        AdColonyAppOptions privacyFrameworkRequired = this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.setPrivacyFrameworkRequired("GDPR", true);
        AdColonyAppOptions privacyConsentString = this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.setPrivacyConsentString("GDPR", z2 ? "1" : "0");
        boolean appOptions = AdColony.setAppOptions(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME);
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR)
    public boolean UserConsent() {
        return this.AsUIHfRHW1pScN9YQW0IsOeuFdHXhbXb53xXbDg8x2ZIBxv57XORnQnTS1wprCIt;
    }

    @SimpleFunction(description = "Returns true if the current app user is located in europe. If true you must ask the user as example in a dialog if he give his consent for personalized ads.")
    public boolean IsEuropeanUser() {
        return KodularGDPRUtil.isRequestLocationInEurope(this.container.$context());
    }

    public void onDestroy() {
        if (this.f166hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME != null) {
            boolean destroy = this.f166hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.destroy();
            this.f166hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = null;
        }
    }
}
