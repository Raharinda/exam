package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Form;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public abstract class CompositeFileOperation extends FileOperation implements Iterable<FileOperand> {
    private final List<FileOperand> DmQGLROFyZ9Eo0RSsJcpZNxJZjgcsPDfYPi3awNwmyyErT71sGU5mvgG4PDW3yL;
    private boolean aWkZqinykMPj8SPm5jVT2wNdrJPpyMEjt10g4Ng570XD4n7VSaFhL3td3g0Xab2G = false;
    private final Set<String> permissions;

    /* access modifiers changed from: protected */
    public abstract void performOperation();

    public static class FileOperand {
        /* access modifiers changed from: private */
        public final String ZFwQoaMsdRwNqOTkWG5sFNIKnTcrKyb4dIRsDmVa68cFIA9m1jUiaqOHngvgXrvD;
        private final FileAccessMode hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

        FileOperand(String str, FileAccessMode fileAccessMode) {
            this.ZFwQoaMsdRwNqOTkWG5sFNIKnTcrKyb4dIRsDmVa68cFIA9m1jUiaqOHngvgXrvD = str;
            this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = fileAccessMode;
        }

        public String getFile() {
            return this.ZFwQoaMsdRwNqOTkWG5sFNIKnTcrKyb4dIRsDmVa68cFIA9m1jUiaqOHngvgXrvD;
        }

        public FileAccessMode getMode() {
            return this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CompositeFileOperation(Form form, Component component, String str, boolean z) {
        super(form, component, str, z);
        List<FileOperand> list;
        Set<String> set;
        new ArrayList();
        this.DmQGLROFyZ9Eo0RSsJcpZNxJZjgcsPDfYPi3awNwmyyErT71sGU5mvgG4PDW3yL = list;
        new HashSet();
        this.permissions = set;
    }

    public void addFile(FileScope fileScope, String str, FileAccessMode fileAccessMode) {
        FileOperand fileOperand;
        String str2 = str;
        FileAccessMode fileAccessMode2 = fileAccessMode;
        new FileOperand(FileUtil.resolveFileName(this.form, str2, fileScope), fileAccessMode2);
        FileOperand fileOperand2 = fileOperand;
        boolean add = this.DmQGLROFyZ9Eo0RSsJcpZNxJZjgcsPDfYPi3awNwmyyErT71sGU5mvgG4PDW3yL.add(fileOperand2);
        boolean add2 = this.permissions.add(FileUtil.getNeededPermission(this.form, str2, fileAccessMode2));
        this.aWkZqinykMPj8SPm5jVT2wNdrJPpyMEjt10g4Ng570XD4n7VSaFhL3td3g0Xab2G |= FileUtil.isExternalStorageUri(this.form, fileOperand2.ZFwQoaMsdRwNqOTkWG5sFNIKnTcrKyb4dIRsDmVa68cFIA9m1jUiaqOHngvgXrvD);
    }

    public List<String> getPermissions() {
        List<String> list;
        new ArrayList(this.permissions);
        return list;
    }

    /* access modifiers changed from: protected */
    public boolean needsExternalStorage() {
        return this.aWkZqinykMPj8SPm5jVT2wNdrJPpyMEjt10g4Ng570XD4n7VSaFhL3td3g0Xab2G;
    }

    public Iterator<FileOperand> iterator() {
        return this.DmQGLROFyZ9Eo0RSsJcpZNxJZjgcsPDfYPi3awNwmyyErT71sGU5mvgG4PDW3yL.iterator();
    }
}
