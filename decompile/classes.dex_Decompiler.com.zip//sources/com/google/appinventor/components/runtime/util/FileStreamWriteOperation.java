package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Form;
import java.io.IOException;
import java.io.OutputStreamWriter;

public abstract class FileStreamWriteOperation extends FileWriteOperation {
    private static final String LOG_TAG = FileStreamWriteOperation.class.getSimpleName();

    /* access modifiers changed from: protected */
    public abstract boolean process(OutputStreamWriter outputStreamWriter) throws IOException;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FileStreamWriteOperation(Form form, Component component, String str, String str2, FileScope fileScope, boolean z, boolean z2) {
        super(form, component, str, str2, fileScope, z, z2);
    }

    /* JADX WARNING: type inference failed for: r4v2, types: [java.io.OutputStreamWriter] */
    /* access modifiers changed from: protected */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean process(java.io.OutputStream r8) throws java.io.IOException {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r3 = 0
            r2 = r3
            java.io.OutputStreamWriter r3 = new java.io.OutputStreamWriter     // Catch:{ all -> 0x0021 }
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r1
            r4.<init>(r5)     // Catch:{ all -> 0x0021 }
            r2 = r3
            r3 = r0
            r4 = r2
            boolean r3 = r3.process((java.io.OutputStreamWriter) r4)     // Catch:{ all -> 0x0021 }
            r1 = r3
            r3 = r1
            if (r3 == 0) goto L_0x001e
            java.lang.String r3 = LOG_TAG
            r4 = r2
            com.google.appinventor.components.runtime.util.IOUtils.closeQuietly(r3, r4)
        L_0x001e:
            r3 = r1
            r0 = r3
            return r0
        L_0x0021:
            r3 = move-exception
            r1 = r3
            java.lang.String r3 = LOG_TAG
            r4 = r2
            com.google.appinventor.components.runtime.util.IOUtils.closeQuietly(r3, r4)
            r3 = r1
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.appinventor.components.runtime.util.FileStreamWriteOperation.process(java.io.OutputStream):boolean");
    }
}
