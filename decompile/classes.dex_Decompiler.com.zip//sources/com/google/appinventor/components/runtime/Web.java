package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.text.TextUtils;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.HtmlEntities;
import com.google.appinventor.components.runtime.collect.Lists;
import com.google.appinventor.components.runtime.collect.Maps;
import com.google.appinventor.components.runtime.errors.DispatchableError;
import com.google.appinventor.components.runtime.errors.IllegalArgumentError;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.errors.RequestTimeoutException;
import com.google.appinventor.components.runtime.repackaged.org.json.XML;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import com.google.appinventor.components.runtime.util.BulkPermissionRequest;
import com.google.appinventor.components.runtime.util.ErrorMessages;
import com.google.appinventor.components.runtime.util.FileUtil;
import com.google.appinventor.components.runtime.util.GingerbreadUtil;
import com.google.appinventor.components.runtime.util.JsonUtil;
import com.google.appinventor.components.runtime.util.MediaUtil;
import com.google.appinventor.components.runtime.util.NanoHTTPD;
import com.google.appinventor.components.runtime.util.YailList;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.CookieHandler;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.SocketTimeoutException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONException;

@DesignerComponent(category = ComponentCategory.CONNECTIVITY, description = "Non-visible component that provides functions for HTTP GET, POST, PUT, and DELETE requests.", iconName = "images/web.png", nonVisible = true, version = 6)
@UsesLibraries({"json.jar"})
@SimpleObject
@UsesPermissions({"android.permission.INTERNET"})
public class Web extends AndroidNonvisibleComponent implements Component {
    private static final String LOG_TAG = "Web";
    private static final Map<String, String> mimeTypeToExtension;
    private final Activity activity;
    /* access modifiers changed from: private */
    public boolean allowCookies;
    /* access modifiers changed from: private */
    public final CookieHandler cookieHandler;
    private boolean haveReadPermission;
    private boolean haveWritePermission;
    /* access modifiers changed from: private */
    public YailList requestHeaders;
    /* access modifiers changed from: private */
    public String responseFileName;
    /* access modifiers changed from: private */
    public boolean saveResponse;
    /* access modifiers changed from: private */
    public int timeout;
    /* access modifiers changed from: private */
    public String urlString = "";

    static /* synthetic */ boolean access$1002(Web web, boolean z) {
        boolean z2 = z;
        boolean z3 = z2;
        web.haveWritePermission = z3;
        return z2;
    }

    static /* synthetic */ boolean access$902(Web web, boolean z) {
        boolean z2 = z;
        boolean z3 = z2;
        web.haveReadPermission = z3;
        return z2;
    }

    static class b extends Exception {
        final int BeAOotgA7zBP9Op6r2FqJlUCXvxuSHPx6BwhNdpgtXlIG2LNe5NWKzZhiJoW0gYE;
        final int rt5vY3dr7aqqLpGGqZnuBZtCcoybaeOtN6eJM7wVAxcn7hidZNH6rGtSnPCIECFs;

        b(int i, int i2) {
            this.BeAOotgA7zBP9Op6r2FqJlUCXvxuSHPx6BwhNdpgtXlIG2LNe5NWKzZhiJoW0gYE = i;
            this.rt5vY3dr7aqqLpGGqZnuBZtCcoybaeOtN6eJM7wVAxcn7hidZNH6rGtSnPCIECFs = i2;
        }
    }

    static class a extends Exception {
        final int BeAOotgA7zBP9Op6r2FqJlUCXvxuSHPx6BwhNdpgtXlIG2LNe5NWKzZhiJoW0gYE;
        final int rt5vY3dr7aqqLpGGqZnuBZtCcoybaeOtN6eJM7wVAxcn7hidZNH6rGtSnPCIECFs;

        a(int i, int i2) {
            this.BeAOotgA7zBP9Op6r2FqJlUCXvxuSHPx6BwhNdpgtXlIG2LNe5NWKzZhiJoW0gYE = i;
            this.rt5vY3dr7aqqLpGGqZnuBZtCcoybaeOtN6eJM7wVAxcn7hidZNH6rGtSnPCIECFs = i2;
        }
    }

    static class CapturedProperties {
        final boolean allowCookies;
        final Map<String, List<String>> cookies;
        final Map<String, List<String>> requestHeaders;
        final String responseFileName;
        final boolean saveResponse;
        final int timeout;
        final URL url;
        final String urlString;

        CapturedProperties(Web web) throws MalformedURLException, b {
            URL url2;
            Web web2 = web;
            this.urlString = web2.urlString;
            new URL(this.urlString);
            this.url = url2;
            this.allowCookies = web2.allowCookies;
            this.saveResponse = web2.saveResponse;
            this.responseFileName = web2.responseFileName;
            this.timeout = web2.timeout;
            this.requestHeaders = Web.processRequestHeaders(web2.requestHeaders);
            Map<String, List<String>> map = null;
            if (this.allowCookies && web2.cookieHandler != null) {
                try {
                    map = web2.cookieHandler.get(this.url.toURI(), this.requestHeaders);
                } catch (Exception | URISyntaxException e) {
                }
            }
            this.cookies = map;
        }
    }

    static {
        HashMap newHashMap = Maps.newHashMap();
        mimeTypeToExtension = newHashMap;
        Object put = newHashMap.put("application/pdf", "pdf");
        String put2 = mimeTypeToExtension.put("application/zip", "zip");
        String put3 = mimeTypeToExtension.put("audio/mpeg", "mpeg");
        String put4 = mimeTypeToExtension.put("audio/mp3", "mp3");
        String put5 = mimeTypeToExtension.put("audio/mp4", "mp4");
        String put6 = mimeTypeToExtension.put("image/gif", "gif");
        String put7 = mimeTypeToExtension.put("image/jpeg", "jpg");
        String put8 = mimeTypeToExtension.put("image/png", "png");
        String put9 = mimeTypeToExtension.put("image/tiff", "tiff");
        String put10 = mimeTypeToExtension.put(NanoHTTPD.MIME_PLAINTEXT, "txt");
        String put11 = mimeTypeToExtension.put(NanoHTTPD.MIME_HTML, "html");
        String put12 = mimeTypeToExtension.put(NanoHTTPD.MIME_XML, "xml");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public Web(com.google.appinventor.components.runtime.ComponentContainer r7) {
        /*
            r6 = this;
            r0 = r6
            r1 = r7
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            java.lang.String r3 = ""
            r2.urlString = r3
            r2 = r0
            com.google.appinventor.components.runtime.util.YailList r3 = new com.google.appinventor.components.runtime.util.YailList
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r2.requestHeaders = r3
            r2 = r0
            java.lang.String r3 = ""
            r2.responseFileName = r3
            r2 = r0
            r3 = 0
            r2.timeout = r3
            r2 = r0
            r3 = 0
            r2.haveReadPermission = r3
            r2 = r0
            r3 = 0
            r2.haveWritePermission = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.activity = r3
            r2 = r0
            java.net.CookieManager r3 = new java.net.CookieManager
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r2.cookieHandler = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.appinventor.components.runtime.Web.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected Web() {
        super((Form) null);
        YailList yailList;
        new YailList();
        this.requestHeaders = yailList;
        this.responseFileName = "";
        this.timeout = 0;
        this.haveReadPermission = false;
        this.haveWritePermission = false;
        this.activity = null;
        this.cookieHandler = null;
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "The URL for the web request.")
    public String Url() {
        return this.urlString;
    }

    @DesignerProperty(defaultValue = "", editorType = "string")
    @SimpleProperty
    public void Url(String str) {
        String str2 = str;
        this.urlString = str2;
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "The request headers, as a list of two-element sublists. The first element of each sublist represents the request header field name. The second element of each sublist represents the request header field values, either a single value or a list containing multiple values.")
    public YailList RequestHeaders() {
        return this.requestHeaders;
    }

    @SimpleProperty
    public void RequestHeaders(YailList yailList) {
        YailList yailList2 = yailList;
        try {
            Map<String, List<String>> processRequestHeaders = processRequestHeaders(yailList2);
            this.requestHeaders = yailList2;
        } catch (b e) {
            b bVar = e;
            this.form.dispatchErrorOccurredEvent(this, "RequestHeaders", bVar.BeAOotgA7zBP9Op6r2FqJlUCXvxuSHPx6BwhNdpgtXlIG2LNe5NWKzZhiJoW0gYE, Integer.valueOf(bVar.rt5vY3dr7aqqLpGGqZnuBZtCcoybaeOtN6eJM7wVAxcn7hidZNH6rGtSnPCIECFs));
        }
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "Whether the cookies from a response should be saved and used in subsequent requests. Cookies are only supported on Android version 2.3 or greater.")
    public boolean AllowCookies() {
        return this.allowCookies;
    }

    @DesignerProperty(defaultValue = "false", editorType = "boolean")
    @SimpleProperty
    public void AllowCookies(boolean z) {
        boolean z2 = z;
        this.allowCookies = z2;
        if (z2 && this.cookieHandler == null) {
            this.form.dispatchErrorOccurredEvent(this, "AllowCookies", 4, new Object[0]);
        }
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "Whether the response should be saved in a file.")
    public boolean SaveResponse() {
        return this.saveResponse;
    }

    @DesignerProperty(defaultValue = "false", editorType = "boolean")
    @SimpleProperty
    public void SaveResponse(boolean z) {
        boolean z2 = z;
        this.saveResponse = z2;
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "The name of the file where the response should be saved. If SaveResponse is true and ResponseFileName is empty, then a new file name will be generated.")
    public String ResponseFileName() {
        return this.responseFileName;
    }

    @DesignerProperty(defaultValue = "", editorType = "string")
    @SimpleProperty
    public void ResponseFileName(String str) {
        String str2 = str;
        this.responseFileName = str2;
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "The number of milliseconds that a web request will wait for a response before giving up. If set to 0, then there is no time limit on how long the request will wait.")
    public int Timeout() {
        return this.timeout;
    }

    @DesignerProperty(defaultValue = "0", editorType = "non_negative_integer")
    @SimpleProperty
    public void Timeout(int i) {
        Throwable th;
        int i2 = i;
        if (i2 < 0) {
            Throwable th2 = th;
            new IllegalArgumentError("Web Timeout must be a non-negative integer.");
            throw th2;
        }
        this.timeout = i2;
    }

    @SimpleFunction(description = "Clears all cookies for this Web component.")
    public void ClearCookies() {
        if (this.cookieHandler != null) {
            boolean clearCookies = GingerbreadUtil.clearCookies(this.cookieHandler);
        } else {
            this.form.dispatchErrorOccurredEvent(this, "ClearCookies", 4, new Object[0]);
        }
    }

    @SimpleFunction
    public void Get() {
        Runnable runnable;
        CapturedProperties capturePropertyValues = capturePropertyValues("Get");
        CapturedProperties capturedProperties = capturePropertyValues;
        if (capturePropertyValues != null) {
            final CapturedProperties capturedProperties2 = capturedProperties;
            new Runnable(this) {

                /* renamed from: hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME  reason: collision with other field name */
                private /* synthetic */ Web f268hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                {
                    this.f268hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r6;
                }

                public final void run() {
                    this.f268hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.performRequest(capturedProperties2, (byte[]) null, (String) null, "GET", "Get");
                }
            };
            AsynchUtil.runAsynchronously(runnable);
        }
    }

    @SimpleFunction(description = "Performs an HTTP POST request using the Url property and the specified text.<br>The characters of the text are encoded using UTF-8 encoding.<br>If the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The responseFileName property can be used to specify the name of the file.<br>If the SaveResponse property is false, the GotText event will be triggered.")
    public void PostText(String str) {
        requestTextImpl(str, "UTF-8", "PostText", "POST");
    }

    @SimpleFunction(description = "Performs an HTTP POST request using the Url property and the specified text.<br>The characters of the text are encoded using the given encoding.<br>If the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The ResponseFileName property can be used to specify the name of the file.<br>If the SaveResponse property is false, the GotText event will be triggered.")
    public void PostTextWithEncoding(String str, String str2) {
        requestTextImpl(str, str2, "PostTextWithEncoding", "POST");
    }

    @SimpleFunction(description = "Performs an HTTP POST request using the Url property and data from the specified file.<br>If the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The ResponseFileName property can be used to specify the name of the file.<br>If the SaveResponse property is false, the GotText event will be triggered.")
    public void PostFile(String str) {
        Runnable runnable;
        String str2 = str;
        CapturedProperties capturePropertyValues = capturePropertyValues("PostFile");
        CapturedProperties capturedProperties = capturePropertyValues;
        if (capturePropertyValues != null) {
            final CapturedProperties capturedProperties2 = capturedProperties;
            final String str3 = str2;
            new Runnable(this) {

                /* renamed from: hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME  reason: collision with other field name */
                private /* synthetic */ Web f269hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                {
                    this.f269hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r7;
                }

                public final void run() {
                    this.f269hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.performRequest(capturedProperties2, (byte[]) null, str3, "POST", "PostFile");
                }
            };
            AsynchUtil.runAsynchronously(runnable);
        }
    }

    @SimpleFunction(description = "Performs an HTTP PUT request using the Url property and the specified text.<br>The characters of the text are encoded using UTF-8 encoding.<br>If the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The responseFileName property can be used to specify the name of the file.<br>If the SaveResponse property is false, the GotText event will be triggered.")
    public void PutText(String str) {
        requestTextImpl(str, "UTF-8", "PutText", "PUT");
    }

    @SimpleFunction(description = "Performs an HTTP PUT request using the Url property and the specified text.<br>The characters of the text are encoded using the given encoding.<br>If the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The ResponseFileName property can be used to specify the name of the file.<br>If the SaveResponse property is false, the GotText event will be triggered.")
    public void PutTextWithEncoding(String str, String str2) {
        requestTextImpl(str, str2, "PutTextWithEncoding", "PUT");
    }

    @SimpleFunction(description = "Performs an HTTP PUT request using the Url property and data from the specified file.<br>If the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The ResponseFileName property can be used to specify the name of the file.<br>If the SaveResponse property is false, the GotText event will be triggered.")
    public void PutFile(String str) {
        Runnable runnable;
        String str2 = str;
        CapturedProperties capturePropertyValues = capturePropertyValues("PutFile");
        CapturedProperties capturedProperties = capturePropertyValues;
        if (capturePropertyValues != null) {
            final CapturedProperties capturedProperties2 = capturedProperties;
            final String str3 = str2;
            new Runnable(this) {

                /* renamed from: hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME  reason: collision with other field name */
                private /* synthetic */ Web f270hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                {
                    this.f270hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r7;
                }

                public final void run() {
                    this.f270hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.performRequest(capturedProperties2, (byte[]) null, str3, "PUT", "PutFile");
                }
            };
            AsynchUtil.runAsynchronously(runnable);
        }
    }

    @SimpleFunction
    public void Delete() {
        Runnable runnable;
        CapturedProperties capturePropertyValues = capturePropertyValues("Delete");
        CapturedProperties capturedProperties = capturePropertyValues;
        if (capturePropertyValues != null) {
            final CapturedProperties capturedProperties2 = capturedProperties;
            new Runnable(this) {

                /* renamed from: hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME  reason: collision with other field name */
                private /* synthetic */ Web f271hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                {
                    this.f271hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r6;
                }

                public final void run() {
                    this.f271hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.performRequest(capturedProperties2, (byte[]) null, (String) null, "DELETE", "Delete");
                }
            };
            AsynchUtil.runAsynchronously(runnable);
        }
    }

    private void requestTextImpl(String str, String str2, String str3, String str4) {
        Runnable runnable;
        String str5 = str;
        String str6 = str2;
        String str7 = str3;
        String str8 = str4;
        CapturedProperties capturePropertyValues = capturePropertyValues(str7);
        CapturedProperties capturedProperties = capturePropertyValues;
        if (capturePropertyValues != null) {
            final String str9 = str6;
            final String str10 = str5;
            final String str11 = str7;
            final CapturedProperties capturedProperties2 = capturedProperties;
            final String str12 = str8;
            new Runnable(this) {

                /* renamed from: hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME  reason: collision with other field name */
                private /* synthetic */ Web f272hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                {
                    this.f272hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r10;
                }

                public final void run() {
                    byte[] bArr;
                    try {
                        if (str9 == null || str9.length() == 0) {
                            bArr = str10.getBytes("UTF-8");
                        } else {
                            bArr = str10.getBytes(str9);
                        }
                        this.f272hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.performRequest(capturedProperties2, bArr, (String) null, str12, str11);
                    } catch (UnsupportedEncodingException e) {
                        this.f272hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.form.dispatchErrorOccurredEvent(this.f272hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME, str11, ErrorMessages.ERROR_WEB_UNSUPPORTED_ENCODING, str9);
                    }
                }
            };
            AsynchUtil.runAsynchronously(runnable);
        }
    }

    @SimpleEvent
    public void GotText(String str, int i, String str2, String str3) {
        Object[] objArr = new Object[4];
        objArr[0] = str;
        Object[] objArr2 = objArr;
        objArr2[1] = Integer.valueOf(i);
        Object[] objArr3 = objArr2;
        objArr3[2] = str2;
        Object[] objArr4 = objArr3;
        objArr4[3] = str3;
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "GotText", objArr4);
    }

    @SimpleEvent
    public void GotFile(String str, int i, String str2, String str3) {
        Object[] objArr = new Object[4];
        objArr[0] = str;
        Object[] objArr2 = objArr;
        objArr2[1] = Integer.valueOf(i);
        Object[] objArr3 = objArr2;
        objArr3[2] = str2;
        Object[] objArr4 = objArr3;
        objArr4[3] = str3;
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "GotFile", objArr4);
    }

    @SimpleEvent
    public void TimedOut(String str) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "TimedOut", str);
    }

    @SimpleFunction
    public String BuildRequestData(YailList yailList) {
        try {
            return buildRequestData(yailList);
        } catch (a e) {
            a aVar = e;
            this.form.dispatchErrorOccurredEvent(this, "BuildRequestData", aVar.BeAOotgA7zBP9Op6r2FqJlUCXvxuSHPx6BwhNdpgtXlIG2LNe5NWKzZhiJoW0gYE, Integer.valueOf(aVar.rt5vY3dr7aqqLpGGqZnuBZtCcoybaeOtN6eJM7wVAxcn7hidZNH6rGtSnPCIECFs));
            return "";
        }
    }

    /* access modifiers changed from: package-private */
    public String buildRequestData(YailList yailList) throws a {
        StringBuilder sb;
        Throwable th;
        Throwable th2;
        YailList yailList2 = yailList;
        new StringBuilder();
        StringBuilder sb2 = sb;
        String str = "";
        int i = 0;
        while (i < yailList2.size()) {
            Object object = yailList2.getObject(i);
            Object obj = object;
            if (object instanceof YailList) {
                YailList yailList3 = (YailList) obj;
                YailList yailList4 = yailList3;
                if (yailList3.size() == 2) {
                    StringBuilder append = sb2.append(str).append(UriEncode(yailList4.getObject(0).toString())).append('=').append(UriEncode(yailList4.getObject(1).toString()));
                    str = "&";
                    i++;
                } else {
                    Throwable th3 = th2;
                    new a(ErrorMessages.ERROR_WEB_BUILD_REQUEST_DATA_NOT_TWO_ELEMENTS, i + 1);
                    throw th3;
                }
            } else {
                Throwable th4 = th;
                new a(ErrorMessages.ERROR_WEB_BUILD_REQUEST_DATA_NOT_LIST, i + 1);
                throw th4;
            }
        }
        return sb2.toString();
    }

    @SimpleFunction
    public String UriEncode(String str) {
        try {
            return URLEncoder.encode(str, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            int e2 = Log.e(LOG_TAG, "UTF-8 is unsupported?", e);
            return "";
        }
    }

    @SimpleFunction
    public String UriDecode(String str) {
        try {
            return URLDecoder.decode(str, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            int e2 = Log.e(LOG_TAG, "UTF-8 is unsupported?", e);
            return "";
        }
    }

    @SimpleFunction
    public Object JsonTextDecode(String str) {
        String str2 = str;
        try {
            return decodeJsonText(str2);
        } catch (IllegalArgumentException e) {
            this.form.dispatchErrorOccurredEvent(this, "JsonTextDecode", ErrorMessages.ERROR_WEB_JSON_TEXT_DECODE_FAILED, str2);
            return "";
        }
    }

    static Object decodeJsonText(String str) throws IllegalArgumentException {
        Throwable th;
        try {
            return JsonUtil.getObjectFromJson(str);
        } catch (JSONException e) {
            Throwable th2 = th;
            new IllegalArgumentException("jsonText is not a legal JSON value");
            throw th2;
        }
    }

    @SimpleFunction(description = "Decodes the given XML string to produce a list structure.  See the App Inventor documentation on \"Other topics, notes, and details\" for information.")
    public Object XMLTextDecode(String str) {
        StringBuilder sb;
        StringBuilder sb2;
        try {
            return JsonTextDecode(XML.toJSONObject(str).toString());
        } catch (com.google.appinventor.components.runtime.repackaged.org.json.JSONException e) {
            com.google.appinventor.components.runtime.repackaged.org.json.JSONException jSONException = e;
            new StringBuilder();
            int e2 = Log.e("Exception in XMLTextDecode", sb.append(jSONException.getMessage()).toString());
            new StringBuilder();
            this.form.dispatchErrorOccurredEvent(this, "XMLTextDecode", ErrorMessages.ERROR_WEB_JSON_TEXT_DECODE_FAILED, sb2.append(jSONException.getMessage()).toString());
            return YailList.makeEmptyList();
        }
    }

    @SimpleFunction(description = "Decodes the given HTML text value. HTML character entities such as &amp;amp;, &amp;lt;, &amp;gt;, &amp;apos;, and &amp;quot; are changed to &amp;, &lt;, &gt;, &#39;, and &quot;. Entities such as &amp;#xhhhh, and &amp;#nnnn are changed to the appropriate characters.")
    public String HtmlTextDecode(String str) {
        String str2 = str;
        try {
            return HtmlEntities.decodeHtmlText(str2);
        } catch (IllegalArgumentException e) {
            this.form.dispatchErrorOccurredEvent(this, "HtmlTextDecode", ErrorMessages.ERROR_WEB_HTML_TEXT_DECODE_FAILED, str2);
            return "";
        }
    }

    /* access modifiers changed from: private */
    public void performRequest(CapturedProperties capturedProperties, byte[] bArr, String str, String str2, String str3) {
        List list;
        boolean z;
        int i;
        Runnable runnable;
        Throwable th;
        Runnable runnable2;
        Runnable runnable3;
        BulkPermissionRequest bulkPermissionRequest;
        CapturedProperties capturedProperties2 = capturedProperties;
        byte[] bArr2 = bArr;
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        new ArrayList();
        List list2 = list;
        if (str4 != null && FileUtil.needsPermission(this.form, str4) && !this.haveReadPermission) {
            boolean add = list2.add("android.permission.READ_EXTERNAL_STORAGE");
        }
        if (this.saveResponse) {
            if (FileUtil.needsPermission(this.form, FileUtil.resolveFileName(this.form, capturedProperties2.responseFileName, this.form.DefaultFileScope())) && !this.haveWritePermission) {
                boolean add2 = list2.add("android.permission.WRITE_EXTERNAL_STORAGE");
            }
        }
        boolean z2 = list2.size() > 0;
        if (!this.haveReadPermission) {
            z = true;
        } else {
            z = false;
        }
        if (z2 && z) {
            Form form = this.form;
            BulkPermissionRequest bulkPermissionRequest2 = bulkPermissionRequest;
            final List list3 = list2;
            final CapturedProperties capturedProperties3 = capturedProperties2;
            final byte[] bArr3 = bArr2;
            final String str7 = str4;
            final String str8 = str5;
            final String str9 = str6;
            new BulkPermissionRequest(this, this, str6, (String[]) list2.toArray(new String[0])) {

                /* renamed from: hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME  reason: collision with other field name */
                private /* synthetic */ Web f273hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                {
                    this.f273hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r17;
                }

                public final void onGranted() {
                    Runnable runnable;
                    if (list3.contains("android.permission.READ_EXTERNAL_STORAGE")) {
                        boolean access$902 = Web.access$902(this, true);
                    }
                    if (list3.contains("android.permission.WRITE_EXTERNAL_STORAGE")) {
                        boolean access$1002 = Web.access$1002(this, true);
                    }
                    new Runnable(this) {
                        private /* synthetic */ AnonymousClass6 hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                        {
                            this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r5;
                        }

                        public final void run() {
                            this.performRequest(capturedProperties3, bArr3, str7, str8, str9);
                        }
                    };
                    AsynchUtil.runAsynchronously(runnable);
                }
            };
            form.askPermission(bulkPermissionRequest2);
            return;
        }
        try {
            HttpURLConnection openConnection = openConnection(capturedProperties2, str5);
            HttpURLConnection httpURLConnection = openConnection;
            if (openConnection != null) {
                if (bArr2 != null) {
                    try {
                        writeRequestData(httpURLConnection, bArr2);
                    } catch (SocketTimeoutException e) {
                        final CapturedProperties capturedProperties4 = capturedProperties2;
                        new Runnable(this) {

                            /* renamed from: hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME  reason: collision with other field name */
                            private /* synthetic */ Web f277hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                            {
                                this.f277hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r6;
                            }

                            public final void run() {
                                this.f277hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.TimedOut(capturedProperties4.urlString);
                            }
                        };
                        this.activity.runOnUiThread(runnable);
                        Throwable th2 = th;
                        new RequestTimeoutException();
                        throw th2;
                    } catch (Throwable th3) {
                        Throwable th4 = th3;
                        httpURLConnection.disconnect();
                        throw th4;
                    }
                } else if (str4 != null) {
                    writeRequestFile(httpURLConnection, str4);
                }
                int responseCode = httpURLConnection.getResponseCode();
                String responseType = getResponseType(httpURLConnection);
                processResponseCookies(httpURLConnection);
                if (this.saveResponse) {
                    final CapturedProperties capturedProperties5 = capturedProperties2;
                    final int i2 = responseCode;
                    final String str10 = responseType;
                    final String saveResponseContent = saveResponseContent(httpURLConnection, capturedProperties2.responseFileName, responseType);
                    new Runnable(this) {

                        /* renamed from: hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME  reason: collision with other field name */
                        private /* synthetic */ Web f275hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                        {
                            this.f275hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r9;
                        }

                        public final void run() {
                            this.f275hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.GotFile(capturedProperties5.urlString, i2, str10, saveResponseContent);
                        }
                    };
                    this.activity.runOnUiThread(runnable3);
                } else {
                    final CapturedProperties capturedProperties6 = capturedProperties2;
                    final int i3 = responseCode;
                    final String str11 = responseType;
                    final String responseContent = getResponseContent(httpURLConnection);
                    new Runnable(this) {

                        /* renamed from: hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME  reason: collision with other field name */
                        private /* synthetic */ Web f276hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                        {
                            this.f276hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r9;
                        }

                        public final void run() {
                            this.f276hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.GotText(capturedProperties6.urlString, i3, str11, responseContent);
                        }
                    };
                    this.activity.runOnUiThread(runnable2);
                }
                httpURLConnection.disconnect();
            }
        } catch (PermissionException e2) {
            this.form.dispatchPermissionDeniedEvent((Component) this, str6, e2);
        } catch (FileUtil.FileException e3) {
            this.form.dispatchErrorOccurredEvent(this, str6, e3.getErrorMessageNumber(), new Object[0]);
        } catch (DispatchableError e4) {
            DispatchableError dispatchableError = e4;
            this.form.dispatchErrorOccurredEvent(this, str6, dispatchableError.getErrorCode(), dispatchableError.getArguments());
        } catch (RequestTimeoutException e5) {
            this.form.dispatchErrorOccurredEvent(this, str6, ErrorMessages.ERROR_WEB_REQUEST_TIMED_OUT, capturedProperties2.urlString);
        } catch (Exception e6) {
            if (str6.equals("Get")) {
                i = 1101;
            } else if (str6.equals("PostFile")) {
                i = 1104;
            } else if (str6.equals("PutFile")) {
                i = 1104;
            } else if (str6.equals("Delete")) {
                i = 1114;
            } else {
                i = 1103;
            }
            this.form.dispatchErrorOccurredEvent(this, str6, i, capturedProperties2.urlString);
        }
    }

    private static HttpURLConnection openConnection(CapturedProperties capturedProperties, String str) throws IOException, ClassCastException, ProtocolException {
        CapturedProperties capturedProperties2 = capturedProperties;
        String str2 = str;
        HttpURLConnection httpURLConnection = (HttpURLConnection) capturedProperties2.url.openConnection();
        HttpURLConnection httpURLConnection2 = httpURLConnection;
        httpURLConnection.setConnectTimeout(capturedProperties2.timeout);
        httpURLConnection2.setReadTimeout(capturedProperties2.timeout);
        if (str2.equals("PUT") || str2.equals("DELETE")) {
            httpURLConnection2.setRequestMethod(str2);
        }
        for (Map.Entry next : capturedProperties2.requestHeaders.entrySet()) {
            String str3 = (String) next.getKey();
            for (String addRequestProperty : (List) next.getValue()) {
                httpURLConnection2.addRequestProperty(str3, addRequestProperty);
            }
        }
        if (capturedProperties2.cookies != null) {
            for (Map.Entry next2 : capturedProperties2.cookies.entrySet()) {
                String str4 = (String) next2.getKey();
                for (String addRequestProperty2 : (List) next2.getValue()) {
                    httpURLConnection2.addRequestProperty(str4, addRequestProperty2);
                }
            }
        }
        return httpURLConnection2;
    }

    private static void writeRequestData(HttpURLConnection httpURLConnection, byte[] bArr) throws IOException {
        BufferedOutputStream bufferedOutputStream;
        HttpURLConnection httpURLConnection2 = httpURLConnection;
        byte[] bArr2 = bArr;
        httpURLConnection2.setDoOutput(true);
        httpURLConnection2.setFixedLengthStreamingMode(bArr2.length);
        new BufferedOutputStream(httpURLConnection2.getOutputStream());
        BufferedOutputStream bufferedOutputStream2 = bufferedOutputStream;
        try {
            bufferedOutputStream2.write(bArr2, 0, bArr2.length);
            bufferedOutputStream2.flush();
            bufferedOutputStream2.close();
        } catch (Throwable th) {
            Throwable th2 = th;
            bufferedOutputStream2.close();
            throw th2;
        }
    }

    /* JADX INFO: finally extract failed */
    private void writeRequestFile(HttpURLConnection httpURLConnection, String str) throws IOException {
        BufferedInputStream bufferedInputStream;
        BufferedOutputStream bufferedOutputStream;
        BufferedOutputStream bufferedOutputStream2;
        HttpURLConnection httpURLConnection2 = httpURLConnection;
        new BufferedInputStream(MediaUtil.openMedia(this.form, str));
        BufferedInputStream bufferedInputStream2 = bufferedInputStream;
        try {
            httpURLConnection2.setDoOutput(true);
            httpURLConnection2.setChunkedStreamingMode(0);
            BufferedOutputStream bufferedOutputStream3 = bufferedOutputStream;
            new BufferedOutputStream(httpURLConnection2.getOutputStream());
            bufferedOutputStream2 = bufferedOutputStream3;
            while (true) {
                int read = bufferedInputStream2.read();
                int i = read;
                if (read != -1) {
                    bufferedOutputStream2.write(i);
                } else {
                    bufferedOutputStream2.flush();
                    bufferedOutputStream2.close();
                    bufferedInputStream2.close();
                    return;
                }
            }
        } catch (Throwable th) {
            Throwable th2 = th;
            bufferedInputStream2.close();
            throw th2;
        }
    }

    private static String getResponseType(HttpURLConnection httpURLConnection) {
        String contentType = httpURLConnection.getContentType();
        return contentType != null ? contentType : "";
    }

    private void processResponseCookies(HttpURLConnection httpURLConnection) {
        HttpURLConnection httpURLConnection2 = httpURLConnection;
        if (this.allowCookies && this.cookieHandler != null) {
            try {
                this.cookieHandler.put(httpURLConnection2.getURL().toURI(), httpURLConnection2.getHeaderFields());
            } catch (Exception | URISyntaxException e) {
            }
        }
    }

    /* JADX INFO: finally extract failed */
    private static String getResponseContent(HttpURLConnection httpURLConnection) throws IOException {
        InputStreamReader inputStreamReader;
        StringBuilder sb;
        StringBuilder sb2;
        StringBuilder sb3;
        HttpURLConnection httpURLConnection2 = httpURLConnection;
        String contentEncoding = httpURLConnection2.getContentEncoding();
        String str = contentEncoding;
        if (contentEncoding == null) {
            str = "UTF-8";
        }
        new InputStreamReader(getConnectionStream(httpURLConnection2), str);
        InputStreamReader inputStreamReader2 = inputStreamReader;
        try {
            int contentLength = httpURLConnection2.getContentLength();
            int i = contentLength;
            if (contentLength != -1) {
                sb2 = sb3;
                new StringBuilder(i);
            } else {
                sb2 = sb;
                new StringBuilder();
            }
            StringBuilder sb4 = sb2;
            char[] cArr = new char[1024];
            while (true) {
                int read = inputStreamReader2.read(cArr);
                int i2 = read;
                if (read != -1) {
                    StringBuilder append = sb4.append(cArr, 0, i2);
                } else {
                    String sb5 = sb4.toString();
                    inputStreamReader2.close();
                    return sb5;
                }
            }
        } catch (Throwable th) {
            Throwable th2 = th;
            inputStreamReader2.close();
            throw th2;
        }
    }

    /* JADX INFO: finally extract failed */
    private String saveResponseContent(HttpURLConnection httpURLConnection, String str, String str2) throws IOException {
        BufferedInputStream bufferedInputStream;
        BufferedOutputStream bufferedOutputStream;
        OutputStream outputStream;
        BufferedOutputStream bufferedOutputStream2;
        Throwable th;
        HttpURLConnection httpURLConnection2 = httpURLConnection;
        File createFile = createFile(str, str2);
        File file = createFile;
        File parentFile = createFile.getParentFile();
        File file2 = parentFile;
        if (parentFile.exists() || file2.mkdirs()) {
            new BufferedInputStream(getConnectionStream(httpURLConnection2), 4096);
            BufferedInputStream bufferedInputStream2 = bufferedInputStream;
            try {
                BufferedOutputStream bufferedOutputStream3 = bufferedOutputStream;
                new FileOutputStream(file);
                new BufferedOutputStream(outputStream, 4096);
                bufferedOutputStream2 = bufferedOutputStream3;
                while (true) {
                    int read = bufferedInputStream2.read();
                    int i = read;
                    if (read != -1) {
                        bufferedOutputStream2.write(i);
                    } else {
                        bufferedOutputStream2.close();
                        bufferedInputStream2.close();
                        return file.getAbsolutePath();
                    }
                }
            } catch (Throwable th2) {
                Throwable th3 = th2;
                bufferedInputStream2.close();
                throw th3;
            }
        } else {
            Throwable th4 = th;
            new DispatchableError(ErrorMessages.ERROR_CANNOT_MAKE_DIRECTORY, file2.getAbsolutePath());
            throw th4;
        }
    }

    private static InputStream getConnectionStream(HttpURLConnection httpURLConnection) throws SocketTimeoutException {
        HttpURLConnection httpURLConnection2 = httpURLConnection;
        try {
            return httpURLConnection2.getInputStream();
        } catch (SocketTimeoutException e) {
            throw e;
        } catch (IOException e2) {
            return httpURLConnection2.getErrorStream();
        }
    }

    private File createFile(String str, String str2) throws IOException, FileUtil.FileException {
        String str3 = str;
        String str4 = str2;
        if (!TextUtils.isEmpty(str3)) {
            return FileUtil.getExternalFile(this.form, str3);
        }
        int indexOf = str4.indexOf(59);
        int i = indexOf;
        if (indexOf != -1) {
            str4 = str4.substring(0, i);
        }
        String str5 = mimeTypeToExtension.get(str4);
        String str6 = str5;
        if (str5 == null) {
            str6 = "tmp";
        }
        return FileUtil.getDownloadFile(this.form, str6);
    }

    /* access modifiers changed from: private */
    public static Map<String, List<String>> processRequestHeaders(YailList yailList) throws b {
        Throwable th;
        Throwable th2;
        YailList yailList2 = yailList;
        HashMap newHashMap = Maps.newHashMap();
        int i = 0;
        while (i < yailList2.size()) {
            Object object = yailList2.getObject(i);
            Object obj = object;
            if (object instanceof YailList) {
                YailList yailList3 = (YailList) obj;
                YailList yailList4 = yailList3;
                if (yailList3.size() == 2) {
                    String obj2 = yailList4.getObject(0).toString();
                    Object object2 = yailList4.getObject(1);
                    ArrayList newArrayList = Lists.newArrayList();
                    if (object2 instanceof YailList) {
                        YailList yailList5 = (YailList) object2;
                        for (int i2 = 0; i2 < yailList5.size(); i2++) {
                            boolean add = newArrayList.add(yailList5.getObject(i2).toString());
                        }
                    } else {
                        boolean add2 = newArrayList.add(object2.toString());
                    }
                    Object put = newHashMap.put(obj2, newArrayList);
                    i++;
                } else {
                    Throwable th3 = th2;
                    new b(ErrorMessages.ERROR_WEB_REQUEST_HEADER_NOT_TWO_ELEMENTS, i + 1);
                    throw th3;
                }
            } else {
                Throwable th4 = th;
                new b(ErrorMessages.ERROR_WEB_REQUEST_HEADER_NOT_LIST, i + 1);
                throw th4;
            }
        }
        return newHashMap;
    }

    private CapturedProperties capturePropertyValues(String str) {
        CapturedProperties capturedProperties;
        String str2 = str;
        try {
            CapturedProperties capturedProperties2 = capturedProperties;
            new CapturedProperties(this);
            return capturedProperties2;
        } catch (MalformedURLException e) {
            this.form.dispatchErrorOccurredEvent(this, str2, ErrorMessages.ERROR_WEB_MALFORMED_URL, this.urlString);
            return null;
        } catch (b e2) {
            b bVar = e2;
            this.form.dispatchErrorOccurredEvent(this, str2, bVar.BeAOotgA7zBP9Op6r2FqJlUCXvxuSHPx6BwhNdpgtXlIG2LNe5NWKzZhiJoW0gYE, Integer.valueOf(bVar.rt5vY3dr7aqqLpGGqZnuBZtCcoybaeOtN6eJM7wVAxcn7hidZNH6rGtSnPCIECFs));
            return null;
        }
    }
}
