package com.google.appinventor.components.runtime.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;

public class FileWriteOperation extends FileStreamOperation<OutputStream> {
    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public FileWriteOperation(com.google.appinventor.components.runtime.Form r18, com.google.appinventor.components.runtime.Component r19, java.lang.String r20, java.lang.String r21, com.google.appinventor.components.common.FileScope r22, boolean r23, boolean r24) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            r2 = r19
            r3 = r20
            r4 = r21
            r5 = r22
            r6 = r23
            r7 = r24
            r8 = r0
            r9 = r1
            r10 = r2
            r11 = r3
            r12 = r4
            r13 = r5
            r14 = r6
            if (r14 == 0) goto L_0x0038
            com.google.appinventor.components.runtime.util.FileAccessMode r14 = com.google.appinventor.components.runtime.util.FileAccessMode.APPEND
        L_0x001b:
            r15 = r7
            r8.<init>(r9, r10, r11, r12, r13, r14, r15)
            r8 = r4
            java.lang.String r9 = "//"
            boolean r8 = r8.startsWith(r9)
            if (r8 == 0) goto L_0x003b
            java.lang.IllegalArgumentException r8 = new java.lang.IllegalArgumentException
            r16 = r8
            r8 = r16
            r9 = r16
            java.lang.String r10 = "Cannot perform a write operation on an asset"
            r9.<init>(r10)
            throw r8
        L_0x0038:
            com.google.appinventor.components.runtime.util.FileAccessMode r14 = com.google.appinventor.components.runtime.util.FileAccessMode.WRITE
            goto L_0x001b
        L_0x003b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.appinventor.components.runtime.util.FileWriteOperation.<init>(com.google.appinventor.components.runtime.Form, com.google.appinventor.components.runtime.Component, java.lang.String, java.lang.String, com.google.appinventor.components.common.FileScope, boolean, boolean):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public FileWriteOperation(com.google.appinventor.components.runtime.Form r16, com.google.appinventor.components.runtime.Component r17, java.lang.String r18, com.google.appinventor.components.runtime.util.ScopedFile r19, boolean r20, boolean r21) {
        /*
            r15 = this;
            r0 = r15
            r1 = r16
            r2 = r17
            r3 = r18
            r4 = r19
            r5 = r20
            r6 = r21
            r7 = r0
            r8 = r1
            r9 = r2
            r10 = r3
            r11 = r4
            r12 = r5
            if (r12 == 0) goto L_0x0030
            com.google.appinventor.components.runtime.util.FileAccessMode r12 = com.google.appinventor.components.runtime.util.FileAccessMode.APPEND
        L_0x0017:
            r13 = r6
            r7.<init>(r8, r9, r10, r11, r12, r13)
            r7 = r4
            com.google.appinventor.components.common.FileScope r7 = r7.getScope()
            com.google.appinventor.components.common.FileScope r8 = com.google.appinventor.components.common.FileScope.Asset
            if (r7 != r8) goto L_0x0033
            java.lang.IllegalArgumentException r7 = new java.lang.IllegalArgumentException
            r14 = r7
            r7 = r14
            r8 = r14
            java.lang.String r9 = "Cannot perform a write operation on an asset"
            r8.<init>(r9)
            throw r7
        L_0x0030:
            com.google.appinventor.components.runtime.util.FileAccessMode r12 = com.google.appinventor.components.runtime.util.FileAccessMode.WRITE
            goto L_0x0017
        L_0x0033:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.appinventor.components.runtime.util.FileWriteOperation.<init>(com.google.appinventor.components.runtime.Form, com.google.appinventor.components.runtime.Component, java.lang.String, com.google.appinventor.components.runtime.util.ScopedFile, boolean, boolean):void");
    }

    /* access modifiers changed from: protected */
    public boolean process(OutputStream outputStream) throws IOException {
        OutputStream outputStream2 = outputStream;
        return true;
    }

    /* access modifiers changed from: protected */
    public OutputStream openFile() throws IOException {
        File file;
        OutputStream outputStream;
        String resolveFileName = FileUtil.resolveFileName(this.form, this.fileName, this.scope);
        String str = resolveFileName;
        if (resolveFileName.startsWith("file://")) {
            str = URI.create(str).getPath();
        } else if (str.startsWith("file:")) {
            str = URI.create(str).getPath();
        }
        new File(str);
        File file2 = file;
        IOUtils.mkdirs(file2);
        new FileOutputStream(file2, FileAccessMode.APPEND.equals(this.accessMode));
        return outputStream;
    }
}
