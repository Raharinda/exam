package com.google.appinventor.components.runtime.util;

import android.util.Log;
import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Form;
import java.io.Closeable;
import java.io.IOException;

public class FileStreamOperation<T extends Closeable> extends SingleFileOperation {
    private static final String LOG_TAG = FileStreamOperation.class.getSimpleName();

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected FileStreamOperation(Form form, Component component, String str, String str2, FileScope fileScope, FileAccessMode fileAccessMode, boolean z) {
        super(form, component, str, str2, fileScope, fileAccessMode, z);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected FileStreamOperation(Form form, Component component, String str, ScopedFile scopedFile, FileAccessMode fileAccessMode, boolean z) {
        super(form, component, str, scopedFile, fileAccessMode, z);
    }

    /* access modifiers changed from: protected */
    public void processFile(ScopedFile scopedFile) {
        ScopedFile scopedFile2 = scopedFile;
        Closeable closeable = null;
        try {
            closeable = openFile();
            if (process(closeable)) {
                IOUtils.closeQuietly(this.component.getClass().getSimpleName(), closeable);
            }
        } catch (IOException e) {
            IOException iOException = e;
            IOException iOException2 = iOException;
            iOException.printStackTrace();
            onError(iOException2);
            IOUtils.closeQuietly(this.component.getClass().getSimpleName(), closeable);
        } catch (Throwable th) {
            Throwable th2 = th;
            IOUtils.closeQuietly(this.component.getClass().getSimpleName(), closeable);
            throw th2;
        }
    }

    public void onError(IOException iOException) {
        int e = Log.e(LOG_TAG, "IO error in file operation", iOException);
    }

    /* access modifiers changed from: protected */
    public boolean process(T t) throws IOException {
        Throwable th;
        T t2 = t;
        Throwable th2 = th;
        new UnsupportedOperationException("Subclasses must implement FileOperation#process.");
        throw th2;
    }

    /* access modifiers changed from: protected */
    public T openFile() throws IOException {
        Throwable th;
        Throwable th2 = th;
        new UnsupportedOperationException("Subclasses must implement FileOperation#openFile.");
        throw th2;
    }
}
