package com.google.appinventor.components.runtime.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GameInstance {
    private String G6NGZkO3GzJPBmNJ6LwDoEfdjbnPkejEO5C5VyyDaUNT1yJXqTcFE5lxbNsfgCQk;
    private String SZ5aRRQoo4RABtl0KnlkQDhNcppg3ZUNkmsRmBa9EW4UdQenZXJCu8cuK0SgtVYc = "";
    private List<String> vB3WjEtL56PUGm0spJ96S19MI1O4vPR6yju8tUYcKrC4atk0AV5GbVcHQNB7BlIK;
    private Map<String, String> vOibdtOfNxMVixWab9VDGgvD9L4Kqb2ZDQBius3PMdhiP1dPN68Z9GzWJA49TUbE;

    public GameInstance(String str) {
        List<String> list;
        Map<String, String> map;
        new ArrayList(0);
        this.vB3WjEtL56PUGm0spJ96S19MI1O4vPR6yju8tUYcKrC4atk0AV5GbVcHQNB7BlIK = list;
        new HashMap();
        this.vOibdtOfNxMVixWab9VDGgvD9L4Kqb2ZDQBius3PMdhiP1dPN68Z9GzWJA49TUbE = map;
        this.G6NGZkO3GzJPBmNJ6LwDoEfdjbnPkejEO5C5VyyDaUNT1yJXqTcFE5lxbNsfgCQk = str;
    }

    public String getInstanceId() {
        return this.G6NGZkO3GzJPBmNJ6LwDoEfdjbnPkejEO5C5VyyDaUNT1yJXqTcFE5lxbNsfgCQk;
    }

    public String getLeader() {
        return this.SZ5aRRQoo4RABtl0KnlkQDhNcppg3ZUNkmsRmBa9EW4UdQenZXJCu8cuK0SgtVYc;
    }

    public void setLeader(String str) {
        String str2 = str;
        this.SZ5aRRQoo4RABtl0KnlkQDhNcppg3ZUNkmsRmBa9EW4UdQenZXJCu8cuK0SgtVYc = str2;
    }

    public PlayerListDelta setPlayers(List<String> list) {
        List list2;
        List<String> list3;
        PlayerListDelta playerListDelta;
        List<String> list4 = list;
        if (list4.equals(this.vB3WjEtL56PUGm0spJ96S19MI1O4vPR6yju8tUYcKrC4atk0AV5GbVcHQNB7BlIK)) {
            return PlayerListDelta.NO_CHANGE;
        }
        List<String> list5 = this.vB3WjEtL56PUGm0spJ96S19MI1O4vPR6yju8tUYcKrC4atk0AV5GbVcHQNB7BlIK;
        new ArrayList(list4);
        List list6 = list2;
        new ArrayList(list4);
        this.vB3WjEtL56PUGm0spJ96S19MI1O4vPR6yju8tUYcKrC4atk0AV5GbVcHQNB7BlIK = list3;
        boolean removeAll = list6.removeAll(list5);
        boolean removeAll2 = list5.removeAll(list4);
        if (list6.size() == 0 && list5.size() == 0) {
            return PlayerListDelta.NO_CHANGE;
        }
        new PlayerListDelta(list5, list6);
        return playerListDelta;
    }

    public List<String> getPlayers() {
        return this.vB3WjEtL56PUGm0spJ96S19MI1O4vPR6yju8tUYcKrC4atk0AV5GbVcHQNB7BlIK;
    }

    public String getMessageTime(String str) {
        String str2 = str;
        if (this.vOibdtOfNxMVixWab9VDGgvD9L4Kqb2ZDQBius3PMdhiP1dPN68Z9GzWJA49TUbE.containsKey(str2)) {
            return this.vOibdtOfNxMVixWab9VDGgvD9L4Kqb2ZDQBius3PMdhiP1dPN68Z9GzWJA49TUbE.get(str2);
        }
        return "";
    }

    public void putMessageTime(String str, String str2) {
        String put = this.vOibdtOfNxMVixWab9VDGgvD9L4Kqb2ZDQBius3PMdhiP1dPN68Z9GzWJA49TUbE.put(str, str2);
    }
}
