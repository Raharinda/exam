package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Form;
import java.io.File;
import java.util.Collections;
import java.util.List;

public abstract class SingleFileOperation extends FileOperation {
    private static final String LOG_TAG = FileOperation.class.getSimpleName();
    protected final FileAccessMode accessMode;
    protected final File file;
    protected final String fileName;
    protected final String resolvedPath;
    protected final FileScope scope;
    protected final ScopedFile scopedFile;

    /* access modifiers changed from: protected */
    public abstract void processFile(ScopedFile scopedFile2);

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected SingleFileOperation(com.google.appinventor.components.runtime.Form r15, com.google.appinventor.components.runtime.Component r16, java.lang.String r17, java.lang.String r18, com.google.appinventor.components.common.FileScope r19, com.google.appinventor.components.runtime.util.FileAccessMode r20, boolean r21) {
        /*
            r14 = this;
            r0 = r14
            r1 = r15
            r2 = r16
            r3 = r17
            r4 = r18
            r5 = r19
            r6 = r20
            r7 = r21
            r8 = r0
            r9 = r1
            r10 = r2
            r11 = r3
            r12 = r7
            r8.<init>(r9, r10, r11, r12)
            r8 = r0
            r9 = r5
            r8.scope = r9
            r8 = r0
            r9 = r6
            r8.accessMode = r9
            r8 = r0
            r9 = r4
            r8.fileName = r9
            r8 = r0
            com.google.appinventor.components.runtime.util.ScopedFile r9 = new com.google.appinventor.components.runtime.util.ScopedFile
            r13 = r9
            r9 = r13
            r10 = r13
            r11 = r5
            r12 = r4
            r10.<init>(r11, r12)
            r8.scopedFile = r9
            r8 = r0
            r13 = r8
            r8 = r13
            r9 = r13
            com.google.appinventor.components.runtime.util.ScopedFile r9 = r9.scopedFile
            r10 = r1
            java.io.File r9 = r9.resolve(r10)
            r8.file = r9
            r8 = r0
            r13 = r8
            r8 = r13
            r9 = r13
            java.io.File r9 = r9.file
            java.lang.String r9 = r9.getAbsolutePath()
            r8.resolvedPath = r9
            java.lang.String r8 = LOG_TAG
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            r13 = r9
            r9 = r13
            r10 = r13
            java.lang.String r11 = "resolvedPath = "
            r10.<init>(r11)
            r10 = r0
            java.lang.String r10 = r10.resolvedPath
            java.lang.StringBuilder r9 = r9.append(r10)
            java.lang.String r9 = r9.toString()
            int r8 = android.util.Log.d(r8, r9)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.appinventor.components.runtime.util.SingleFileOperation.<init>(com.google.appinventor.components.runtime.Form, com.google.appinventor.components.runtime.Component, java.lang.String, java.lang.String, com.google.appinventor.components.common.FileScope, com.google.appinventor.components.runtime.util.FileAccessMode, boolean):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected SingleFileOperation(com.google.appinventor.components.runtime.Form r14, com.google.appinventor.components.runtime.Component r15, java.lang.String r16, com.google.appinventor.components.runtime.util.ScopedFile r17, com.google.appinventor.components.runtime.util.FileAccessMode r18, boolean r19) {
        /*
            r13 = this;
            r0 = r13
            r1 = r14
            r2 = r15
            r3 = r16
            r4 = r17
            r5 = r18
            r6 = r19
            r7 = r0
            r8 = r1
            r9 = r2
            r10 = r3
            r11 = r6
            r7.<init>(r8, r9, r10, r11)
            r7 = r0
            r8 = r4
            com.google.appinventor.components.common.FileScope r8 = r8.getScope()
            r7.scope = r8
            r7 = r0
            r8 = r5
            r7.accessMode = r8
            r7 = r0
            r8 = r4
            java.lang.String r8 = r8.getFileName()
            r7.fileName = r8
            r7 = r0
            r8 = r4
            r7.scopedFile = r8
            r7 = r0
            r12 = r7
            r7 = r12
            r8 = r12
            com.google.appinventor.components.runtime.util.ScopedFile r8 = r8.scopedFile
            r9 = r1
            java.io.File r8 = r8.resolve(r9)
            r7.file = r8
            r7 = r0
            r12 = r7
            r7 = r12
            r8 = r12
            java.io.File r8 = r8.file
            java.lang.String r8 = r8.getAbsolutePath()
            r7.resolvedPath = r8
            java.lang.String r7 = LOG_TAG
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r12 = r8
            r8 = r12
            r9 = r12
            java.lang.String r10 = "resolvedPath = "
            r9.<init>(r10)
            r9 = r0
            java.lang.String r9 = r9.resolvedPath
            java.lang.StringBuilder r8 = r8.append(r9)
            java.lang.String r8 = r8.toString()
            int r7 = android.util.Log.d(r7, r8)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.appinventor.components.runtime.util.SingleFileOperation.<init>(com.google.appinventor.components.runtime.Form, com.google.appinventor.components.runtime.Component, java.lang.String, com.google.appinventor.components.runtime.util.ScopedFile, com.google.appinventor.components.runtime.util.FileAccessMode, boolean):void");
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    protected SingleFileOperation(Form form, Component component, String str, String str2, FileScope fileScope, FileAccessMode fileAccessMode) {
        this(form, component, str, str2, fileScope, fileAccessMode, true);
    }

    public List<String> getPermissions() {
        String neededPermission = FileUtil.getNeededPermission(this.form, this.resolvedPath, this.accessMode);
        String str = neededPermission;
        if (neededPermission == null) {
            return Collections.emptyList();
        }
        return Collections.singletonList(str);
    }

    public final File getFile() {
        return this.file;
    }

    public final ScopedFile getScopedFile() {
        return this.scopedFile;
    }

    public final boolean isAsset() {
        return this.fileName.startsWith("//") || this.scope == FileScope.Asset;
    }

    public final FileScope getScope() {
        return this.scope;
    }

    /* access modifiers changed from: protected */
    public void performOperation() {
        processFile(this.scopedFile);
    }

    /* access modifiers changed from: protected */
    public boolean needsExternalStorage() {
        return FileUtil.isExternalStorageUri(this.form, this.resolvedPath);
    }

    /* access modifiers changed from: protected */
    public final boolean needsPermission() {
        return FileUtil.needsPermission(this.form, this.resolvedPath);
    }
}
