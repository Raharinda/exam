package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import gnu.mapping.Procedure;
import java.util.concurrent.Callable;

public final class ContinuationUtil {
    private ContinuationUtil() {
    }

    public static <T> Continuation<T> wrap(Procedure procedure, Class<T> cls) {
        Continuation<T> continuation;
        final Class<T> cls2 = cls;
        final Procedure procedure2 = procedure;
        new Continuation<T>() {
            public final void call(T t) {
                Throwable th;
                T t2 = t;
                try {
                    if (cls2 == Void.class) {
                        Object apply0 = procedure2.apply0();
                    } else {
                        Object apply1 = procedure2.apply1(t2);
                    }
                } catch (Throwable th2) {
                    Throwable th3 = th2;
                    Throwable th4 = th;
                    new YailRuntimeError(th3.getMessage(), th3.getClass().getSimpleName());
                    throw th4;
                }
            }
        };
        return continuation;
    }

    public static <T> void callWithContinuation(Callable<T> callable, Continuation<T> continuation) {
        Runnable runnable;
        final Callable<T> callable2 = callable;
        final Continuation<T> continuation2 = continuation;
        new Runnable() {
            public final void run() {
                Throwable th;
                try {
                    continuation2.call(callable2.call());
                } catch (Exception e) {
                    Exception exc = e;
                    Throwable th2 = th;
                    new RuntimeException(exc);
                    throw th2;
                }
            }
        };
        AsynchUtil.runAsynchronously(runnable);
    }

    public static <T> T callWithContinuationSync(Callable<T> callable) {
        Synchronizer synchronizer;
        Callable callable2;
        Continuation continuation;
        Throwable th;
        new Synchronizer();
        Synchronizer synchronizer2 = synchronizer;
        final Callable<T> callable3 = callable;
        final Synchronizer synchronizer3 = synchronizer2;
        new Callable<T>() {
            public final T call() {
                try {
                    return callable3.call();
                } catch (Throwable th) {
                    synchronizer3.caught(th);
                    return null;
                }
            }
        };
        final Synchronizer synchronizer4 = synchronizer2;
        new Continuation<T>() {
            public final void call(T t) {
                T t2 = t;
                if (synchronizer4.getThrowable() != null) {
                    synchronizer4.wakeup(t2);
                }
            }
        };
        callWithContinuation(callable2, continuation);
        Throwable throwable = synchronizer2.getThrowable();
        Throwable th2 = throwable;
        if (throwable == null) {
            return synchronizer2.getResult();
        }
        if (th2 instanceof RuntimeException) {
            throw ((RuntimeException) th2);
        }
        Throwable th3 = th;
        new RuntimeException("Exception in call", th2);
        throw th3;
    }
}
