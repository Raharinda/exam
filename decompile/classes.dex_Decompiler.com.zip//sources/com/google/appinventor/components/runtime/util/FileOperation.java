package com.google.appinventor.components.runtime.util;

import android.util.Log;
import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.PermissionResultHandler;
import com.google.appinventor.components.runtime.errors.StopBlocksExecution;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

public abstract class FileOperation implements PermissionResultHandler, Runnable {
    /* access modifiers changed from: package-private */
    public static final String LOG_TAG = FileOperation.class.getSimpleName();
    protected volatile boolean askedForPermission = false;
    protected final boolean async;
    protected final Component component;
    protected final Form form;
    protected volatile boolean hasPermission = false;
    protected final String method;

    public interface FileInvocation {
        void call(ScopedFile[] scopedFileArr) throws IOException;
    }

    public abstract List<String> getPermissions();

    /* access modifiers changed from: protected */
    public abstract boolean needsExternalStorage();

    /* access modifiers changed from: protected */
    public abstract boolean needsPermission();

    /* access modifiers changed from: protected */
    public abstract void performOperation();

    FileOperation(Form form2, Component component2, String str, boolean z) {
        this.form = form2;
        this.component = component2;
        this.method = str;
        this.async = z;
    }

    public final void run() {
        Set set;
        List list;
        List list2;
        BulkPermissionRequest bulkPermissionRequest;
        Throwable th;
        if (this.hasPermission) {
            list2 = Collections.emptyList();
        } else {
            List<String> permissions = getPermissions();
            new HashSet();
            Set set2 = set;
            for (String next : permissions) {
                if (this.form.isDeniedPermission(next)) {
                    boolean add = set2.add(next);
                }
            }
            list2 = list;
            new ArrayList(set2);
        }
        List list3 = list2;
        if (AsynchUtil.isUiThread()) {
            if (needsExternalStorage()) {
                FileUtil.checkExternalStorageWriteable();
            }
            if (list3.isEmpty()) {
                this.hasPermission = true;
                if (this.async) {
                    AsynchUtil.runAsynchronously(this);
                } else {
                    performOperation();
                }
            } else if (!this.hasPermission) {
                if (this.askedForPermission) {
                    this.form.dispatchPermissionDeniedEvent(this.component, this.method, (String) list3.get(0));
                } else {
                    this.askedForPermission = true;
                    Form form2 = this.form;
                    BulkPermissionRequest bulkPermissionRequest2 = bulkPermissionRequest;
                    new BulkPermissionRequest(this, this.component, this.method, (String[]) list3.toArray(new String[0])) {
                        private /* synthetic */ FileOperation hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                        {
                            this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r10;
                        }

                        public final void onGranted() {
                            this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.hasPermission = true;
                            this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.run();
                        }
                    };
                    form2.askPermission(bulkPermissionRequest2);
                }
                Throwable th2 = th;
                new StopBlocksExecution();
                throw th2;
            } else if (this.async) {
                AsynchUtil.runAsynchronously(this);
            } else {
                performOperation();
            }
        } else if (!list3.isEmpty()) {
            this.hasPermission = false;
            this.askedForPermission = false;
            this.form.runOnUiThread(this);
        } else {
            performOperation();
        }
    }

    public void HandlePermissionResponse(String str, boolean z) {
        String str2 = str;
        this.askedForPermission = true;
        this.hasPermission = z;
        run();
    }

    /* access modifiers changed from: protected */
    public void reportError(int i, Object... objArr) {
        Runnable runnable;
        final int i2 = i;
        final Object[] objArr2 = objArr;
        new Runnable(this) {
            private /* synthetic */ FileOperation hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

            {
                this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r7;
            }

            public final void run() {
                this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.form.dispatchErrorOccurredEvent(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.component, this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.method, i2, objArr2);
            }
        };
        this.form.runOnUiThread(runnable);
    }

    public static class Builder {
        private final List<FileInvocation> ZXVyhZW2wwbAysjXrMReFP00vcRkftFV6dFiSCOUB0OBlMJVjuhF9XlRGX7w6PdR;
        /* access modifiers changed from: private */
        public boolean aWkZqinykMPj8SPm5jVT2wNdrJPpyMEjt10g4Ng570XD4n7VSaFhL3td3g0Xab2G = false;
        private boolean async = true;
        private Component component;
        private Form form;
        private boolean hibTQF3buaJTulLZvSVkxWzq69D3X99LEonIrTaR8DG6SkVpYpvjF3tGUybbhvWG = true;
        private final LinkedHashMap<ScopedFile, FileAccessMode> hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;
        private String method;
        private final Set<String> vwEpIRqEf6xdtwTR9dehwBO7JUhyLV6iEzEK2WqfPN10eUMQDPn3AUmqAFfsnr6R;

        public Builder() {
            LinkedHashMap<ScopedFile, FileAccessMode> linkedHashMap;
            Set<String> set;
            List<FileInvocation> list;
            new LinkedHashMap<>();
            this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = linkedHashMap;
            new HashSet();
            this.vwEpIRqEf6xdtwTR9dehwBO7JUhyLV6iEzEK2WqfPN10eUMQDPn3AUmqAFfsnr6R = set;
            new ArrayList();
            this.ZXVyhZW2wwbAysjXrMReFP00vcRkftFV6dFiSCOUB0OBlMJVjuhF9XlRGX7w6PdR = list;
        }

        public Builder(Form form2, Component component2, String str) {
            LinkedHashMap<ScopedFile, FileAccessMode> linkedHashMap;
            Set<String> set;
            List<FileInvocation> list;
            new LinkedHashMap<>();
            this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = linkedHashMap;
            new HashSet();
            this.vwEpIRqEf6xdtwTR9dehwBO7JUhyLV6iEzEK2WqfPN10eUMQDPn3AUmqAFfsnr6R = set;
            new ArrayList();
            this.ZXVyhZW2wwbAysjXrMReFP00vcRkftFV6dFiSCOUB0OBlMJVjuhF9XlRGX7w6PdR = list;
            this.form = form2;
            this.component = component2;
            this.method = str;
        }

        public Builder setForm(Form form2) {
            this.form = form2;
            return this;
        }

        public Builder setComponent(Component component2) {
            this.component = component2;
            return this;
        }

        public Builder setMethod(String str) {
            this.method = str;
            return this;
        }

        public Builder addFile(FileScope fileScope, String str, FileAccessMode fileAccessMode) {
            ScopedFile scopedFile;
            StringBuilder sb;
            Throwable th;
            FileScope fileScope2 = fileScope;
            String str2 = str;
            FileAccessMode fileAccessMode2 = fileAccessMode;
            new ScopedFile(fileScope2, str2);
            ScopedFile scopedFile2 = scopedFile;
            ScopedFile scopedFile3 = scopedFile2;
            if (scopedFile2.getScope() != FileScope.Asset || fileAccessMode2 == FileAccessMode.READ) {
                Object put = this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.put(scopedFile3, fileAccessMode2);
                String resolveFileName = FileUtil.resolveFileName(this.form, str2, fileScope2);
                String vwEpIRqEf6xdtwTR9dehwBO7JUhyLV6iEzEK2WqfPN10eUMQDPn3AUmqAFfsnr6R2 = FileOperation.LOG_TAG;
                new StringBuilder();
                int d = Log.d(vwEpIRqEf6xdtwTR9dehwBO7JUhyLV6iEzEK2WqfPN10eUMQDPn3AUmqAFfsnr6R2, sb.append(this.method).append(" resolved ").append(resolveFileName).toString());
                this.aWkZqinykMPj8SPm5jVT2wNdrJPpyMEjt10g4Ng570XD4n7VSaFhL3td3g0Xab2G |= FileUtil.needsPermission(this.form, resolveFileName);
                String neededPermission = FileUtil.getNeededPermission(this.form, resolveFileName, fileAccessMode2);
                String str3 = neededPermission;
                if (neededPermission != null) {
                    boolean add = this.vwEpIRqEf6xdtwTR9dehwBO7JUhyLV6iEzEK2WqfPN10eUMQDPn3AUmqAFfsnr6R.add(str3);
                }
                return this;
            }
            this.form.dispatchErrorOccurredEvent(this.component, this.method, ErrorMessages.ERROR_CANNOT_WRITE_ASSET, scopedFile3.getFileName());
            Throwable th2 = th;
            new StopBlocksExecution();
            throw th2;
        }

        public Builder addCommand(FileInvocation fileInvocation) {
            boolean add = this.ZXVyhZW2wwbAysjXrMReFP00vcRkftFV6dFiSCOUB0OBlMJVjuhF9XlRGX7w6PdR.add(fileInvocation);
            return this;
        }

        public Builder setAsynchronous(boolean z) {
            this.async = z;
            return this;
        }

        public Builder setAskPermission(boolean z) {
            this.hibTQF3buaJTulLZvSVkxWzq69D3X99LEonIrTaR8DG6SkVpYpvjF3tGUybbhvWG = z;
            return this;
        }

        public FileOperation build() {
            FileOperation fileOperation;
            FileOperation fileOperation2 = fileOperation;
            new FileOperation(this, this.form, this.component, this.method, this.async) {
                private /* synthetic */ Builder hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                {
                    this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r12;
                }

                public final List<String> getPermissions() {
                    List<String> list;
                    new ArrayList(Builder.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME));
                    return list;
                }

                /* access modifiers changed from: protected */
                public final void performOperation() {
                    Throwable th;
                    StringBuilder sb;
                    BulkPermissionRequest bulkPermissionRequest;
                    Throwable th2;
                    if (Builder.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME) && Builder.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME).size() > 0) {
                        Iterator it = Builder.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME).iterator();
                        while (it.hasNext()) {
                            if (!this.form.isDeniedPermission((String) it.next())) {
                                it.remove();
                            }
                        }
                        if (needsPermission()) {
                            String str = FileOperation.LOG_TAG;
                            new StringBuilder();
                            int d = Log.d(str, sb.append(this.method).append(" need permissions: ").append(Builder.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME)).toString());
                            Form form = this.form;
                            BulkPermissionRequest bulkPermissionRequest2 = bulkPermissionRequest;
                            new BulkPermissionRequest(this, this.component, this.method, (String[]) Builder.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME).toArray(new String[0])) {
                                private /* synthetic */ AnonymousClass1 hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                                {
                                    this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r10;
                                }

                                public final void onGranted() {
                                }
                            };
                            form.askPermission(bulkPermissionRequest2);
                            Throwable th3 = th2;
                            new StopBlocksExecution();
                            throw th3;
                        }
                    }
                    ScopedFile[] scopedFileArr = (ScopedFile[]) Builder.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME).keySet().toArray(new ScopedFile[0]);
                    for (FileInvocation call : Builder.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME)) {
                        try {
                            call.call(scopedFileArr);
                        } catch (IOException e) {
                            IOException iOException = e;
                            Throwable th4 = th;
                            new RuntimeException(iOException);
                            throw th4;
                        }
                    }
                }

                /* access modifiers changed from: protected */
                public final boolean needsPermission() {
                    return !Builder.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME).isEmpty();
                }

                /* access modifiers changed from: protected */
                public final boolean needsExternalStorage() {
                    return this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.aWkZqinykMPj8SPm5jVT2wNdrJPpyMEjt10g4Ng570XD4n7VSaFhL3td3g0Xab2G;
                }
            };
            return fileOperation2;
        }
    }
}
