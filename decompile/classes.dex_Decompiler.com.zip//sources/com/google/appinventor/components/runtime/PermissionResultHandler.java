package com.google.appinventor.components.runtime;

public interface PermissionResultHandler {
    void HandlePermissionResponse(String str, boolean z);
}
