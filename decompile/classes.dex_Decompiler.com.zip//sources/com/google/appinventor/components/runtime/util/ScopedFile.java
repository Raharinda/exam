package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Form;
import java.io.File;
import java.net.URI;

public class ScopedFile {
    private final String fileName;
    private final FileScope scope;

    public ScopedFile(FileScope fileScope, String str) {
        FileScope fileScope2 = fileScope;
        String str2 = str;
        if (str2.startsWith("//")) {
            fileScope2 = FileScope.Asset;
            str2 = str2.substring(2);
        } else if (!str2.startsWith("/") && fileScope2 == FileScope.Legacy) {
            fileScope2 = FileScope.Private;
        } else if (str2.startsWith("/") && fileScope2 != FileScope.Legacy) {
            str2 = str2.substring(1);
        }
        this.scope = fileScope2;
        this.fileName = str2;
    }

    public FileScope getScope() {
        return this.scope;
    }

    public String getFileName() {
        return this.fileName;
    }

    public int hashCode() {
        return (this.scope.hashCode() * 37) + this.fileName.hashCode();
    }

    public boolean equals(Object obj) {
        Object obj2 = obj;
        if (!(obj2 instanceof ScopedFile)) {
            return false;
        }
        ScopedFile scopedFile = (ScopedFile) obj2;
        if (this.scope != scopedFile.scope) {
            return false;
        }
        if (this.fileName == null && scopedFile.fileName == null) {
            return true;
        }
        if (this.fileName == null || scopedFile.fileName == null) {
            return false;
        }
        return this.fileName.equals(scopedFile.fileName);
    }

    public File resolve(Form form) {
        File file;
        new File(URI.create(FileUtil.resolveFileName(form, this.fileName, this.scope)));
        return file;
    }

    public String toString() {
        StringBuilder sb;
        new StringBuilder("ScopedFile{scope=");
        return sb.append(this.scope).append(", fileName='").append(this.fileName).append('\'').append('}').toString();
    }
}
