package com.google.appinventor.components.runtime.util;

import android.annotation.SuppressLint;

@SuppressLint({"InlinedApi"})
public enum FileAccessMode {
    ;
    
    private final String YVNsLa2BpUWGzhTNtYSeh7by1SaqIwLHkFGvDAPqWStA5E6saDa7VpXzg6M8aqS3;

    private FileAccessMode(String str) {
        String str2 = r8;
        int i = r9;
        this.YVNsLa2BpUWGzhTNtYSeh7by1SaqIwLHkFGvDAPqWStA5E6saDa7VpXzg6M8aqS3 = str;
    }

    public final String getPermission() {
        return this.YVNsLa2BpUWGzhTNtYSeh7by1SaqIwLHkFGvDAPqWStA5E6saDa7VpXzg6M8aqS3;
    }
}
