package com.google.appinventor.components.runtime;

import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.errors.StopBlocksExecution;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import com.google.appinventor.components.runtime.util.Continuation;
import com.google.appinventor.components.runtime.util.ErrorMessages;
import com.google.appinventor.components.runtime.util.FileAccessMode;
import com.google.appinventor.components.runtime.util.FileOperation;
import com.google.appinventor.components.runtime.util.FileStreamReadOperation;
import com.google.appinventor.components.runtime.util.FileStreamWriteOperation;
import com.google.appinventor.components.runtime.util.FileUtil;
import com.google.appinventor.components.runtime.util.FileWriteOperation;
import com.google.appinventor.components.runtime.util.IOUtils;
import com.google.appinventor.components.runtime.util.ScopedFile;
import com.google.appinventor.components.runtime.util.SingleFileOperation;
import com.google.appinventor.components.runtime.util.Synchronizer;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.model.ZipParameters;

@SimpleObject
@DesignerComponent(category = ComponentCategory.STORAGE, description = "Non-visible component for storing and retrieving files. Use this component to write or read files on your device. The default behaviour is to write files to the private data directory associated with your App. The Companion is special cased to write files to a public directory for debugging. Use the More information link to read more about how the File component uses paths and scopes to manage access to files.", iconName = "images/file.png", nonVisible = true, version = 8)
@UsesLibraries({"zip4j.jar"})
public class File extends AndroidNonvisibleComponent implements Component {
    private static final String LOG_TAG = "FileComponent";
    private FileScope scope = FileScope.App;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public File(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        DefaultScope(FileScope.App);
    }

    @DesignerProperty(defaultValue = "App", editorType = "file_scope")
    @SimpleProperty(userVisible = false)
    public void DefaultScope(FileScope fileScope) {
        FileScope fileScope2 = fileScope;
        this.scope = fileScope2;
    }

    @Deprecated
    @SimpleProperty(category = PropertyCategory.BEHAVIOR, userVisible = false)
    public void LegacyMode(boolean z) {
        this.scope = z ? FileScope.Legacy : FileScope.App;
    }

    @Deprecated
    @SimpleProperty(description = "Allows app to access files from the root of the external storage directory (legacy mode).")
    public boolean LegacyMode() {
        return this.scope == FileScope.Legacy;
    }

    @DesignerProperty(defaultValue = "False", editorType = "boolean")
    @UsesPermissions({"android.permission.READ_EXTERNAL_STORAGE"})
    @SimpleProperty(userVisible = false)
    public void ReadPermission(boolean z) {
    }

    @SimpleProperty
    public void Scope(FileScope fileScope) {
        FileScope fileScope2 = fileScope;
        this.scope = fileScope2;
    }

    @SimpleProperty
    public FileScope Scope() {
        return this.scope;
    }

    @DesignerProperty(defaultValue = "False", editorType = "boolean")
    @UsesPermissions({"android.permission.WRITE_EXTERNAL_STORAGE"})
    @SimpleProperty(userVisible = false)
    public void WritePermission(boolean z) {
    }

    @SimpleFunction
    public void MakeDirectory(FileScope fileScope, String str, Continuation<Boolean> continuation) {
        AnonymousClass1 r14;
        FileScope fileScope2 = fileScope;
        String str2 = str;
        Continuation<Boolean> continuation2 = continuation;
        if (fileScope2 == FileScope.Asset) {
            this.form.dispatchErrorOccurredEvent(this, "MakeDirectory", ErrorMessages.ERROR_CANNOT_MAKE_DIRECTORY, str2);
            return;
        }
        AnonymousClass1 r4 = r14;
        final Continuation<Boolean> continuation3 = continuation2;
        new SingleFileOperation(this, this.form, this, "MakeDirectory", str2, fileScope2, FileAccessMode.WRITE) {
            private /* synthetic */ File hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

            {
                this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r18;
            }

            public final void processFile(ScopedFile scopedFile) {
                java.io.File resolve = scopedFile.resolve(this.form);
                java.io.File file = resolve;
                if (resolve.exists()) {
                    if (file.isDirectory()) {
                        onSuccess();
                        return;
                    }
                    reportError(ErrorMessages.ERROR_FILE_EXISTS_AT_PATH, file.getAbsolutePath());
                } else if (file.mkdirs()) {
                    onSuccess();
                } else {
                    reportError(ErrorMessages.ERROR_CANNOT_MAKE_DIRECTORY, file.getAbsolutePath());
                }
            }

            private void onSuccess() {
                Runnable runnable;
                new Runnable(this) {
                    private /* synthetic */ AnonymousClass1 hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                    {
                        this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r5;
                    }

                    public final void run() {
                        continuation3.call(Boolean.TRUE);
                    }
                };
                this.form.runOnUiThread(runnable);
            }
        };
        r4.run();
    }

    @SimpleFunction
    public void RemoveDirectory(FileScope fileScope, String str, boolean z, Continuation<Boolean> continuation) {
        Synchronizer synchronizer;
        FileOperation.Builder builder;
        FileOperation.FileInvocation fileInvocation;
        FileScope fileScope2 = fileScope;
        String str2 = str;
        boolean z2 = z;
        Continuation<Boolean> continuation2 = continuation;
        if (fileScope2 == FileScope.Asset) {
            this.form.dispatchErrorOccurredEvent(this, "RemoveDirectory", ErrorMessages.ERROR_CANNOT_REMOVE_DIRECTORY, str2);
            return;
        }
        new Synchronizer();
        Synchronizer synchronizer2 = synchronizer;
        new FileOperation.Builder(this.form, this, "RemoveDirectory");
        final Synchronizer synchronizer3 = synchronizer2;
        final boolean z3 = z2;
        new FileOperation.FileInvocation(this) {
            private /* synthetic */ File hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

            {
                this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r7;
            }

            public final void call(ScopedFile[] scopedFileArr) {
                try {
                    synchronizer3.wakeup(Boolean.valueOf(FileUtil.removeDirectory(scopedFileArr[0].resolve(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.form), z3)));
                } catch (Exception e) {
                    synchronizer3.caught(e);
                }
            }
        };
        builder.addFile(fileScope2, str2, FileAccessMode.WRITE).addCommand(fileInvocation).build().run();
        AsynchUtil.finish(synchronizer2, continuation2);
    }

    @SimpleFunction
    public void ListDirectory(FileScope fileScope, String str, Continuation<List<String>> continuation) {
        Synchronizer synchronizer;
        FileOperation.Builder builder;
        FileOperation.FileInvocation fileInvocation;
        StringBuilder sb;
        ScopedFile scopedFile;
        FileScope fileScope2 = fileScope;
        String str2 = str;
        Continuation<List<String>> continuation2 = continuation;
        if (fileScope2 != FileScope.Asset || this.form.isRepl()) {
            if (!str2.contains("/")) {
                new StringBuilder();
                str2 = sb.append(str2).append("/").toString();
            }
            new Synchronizer();
            Synchronizer synchronizer2 = synchronizer;
            new FileOperation.Builder(this.form, this, "ListDirectory");
            final Synchronizer synchronizer3 = synchronizer2;
            new FileOperation.FileInvocation(this) {
                private /* synthetic */ File hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                {
                    this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r6;
                }

                public final void call(ScopedFile[] scopedFileArr) throws IOException {
                    StringBuilder sb;
                    ScopedFile[] scopedFileArr2 = scopedFileArr;
                    new StringBuilder("Listing directory ");
                    int d = Log.d(File.LOG_TAG, sb.append(scopedFileArr2[0]).toString());
                    List<String> listDirectory = FileUtil.listDirectory(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.form, scopedFileArr2[0]);
                    List<String> list = listDirectory;
                    if (listDirectory == null) {
                        list = Collections.emptyList();
                    }
                    synchronizer3.wakeup(list);
                }
            };
            builder.setAskPermission(true).setAsynchronous(true).addFile(fileScope2, str2, FileAccessMode.READ).addCommand(fileInvocation).build().run();
            AsynchUtil.finish(synchronizer2, continuation2);
            return;
        }
        Continuation<List<String>> continuation3 = continuation2;
        try {
            new ScopedFile(fileScope2, str2);
            continuation3.call(FileUtil.listDirectory(this.form, scopedFile));
        } catch (IOException e) {
            this.form.dispatchErrorOccurredEvent(this, "ListDirectory", ErrorMessages.ERROR_CANNOT_LIST_DIRECTORY, str2);
        }
    }

    @Deprecated
    @SimpleFunction(description = "Check whether the path is a directory. Use the other IsDirectory function instead.")
    public boolean IsDirectory(String str) {
        java.io.File externalFile = FileUtil.getExternalFile(this.form, str, FileScope.Legacy);
        return externalFile.exists() && externalFile.isDirectory();
    }

    @SimpleFunction
    public void IsDirectory(FileScope fileScope, String str, Continuation<Boolean> continuation) {
        Synchronizer synchronizer;
        FileOperation.Builder builder;
        FileOperation.FileInvocation fileInvocation;
        StringBuilder sb;
        FileScope fileScope2 = fileScope;
        String str2 = str;
        Continuation<Boolean> continuation2 = continuation;
        if (fileScope2 != FileScope.Asset || this.form.isRepl()) {
            new Synchronizer();
            Synchronizer synchronizer2 = synchronizer;
            new FileOperation.Builder(this.form, this, "IsDirectory");
            final Synchronizer synchronizer3 = synchronizer2;
            new FileOperation.FileInvocation(this) {
                private /* synthetic */ File hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                {
                    this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r6;
                }

                public final void call(ScopedFile[] scopedFileArr) {
                    StringBuilder sb;
                    ScopedFile[] scopedFileArr2 = scopedFileArr;
                    new StringBuilder("IsDirectory ");
                    int d = Log.d(File.LOG_TAG, sb.append(scopedFileArr2[0]).toString());
                    synchronizer3.wakeup(Boolean.valueOf(scopedFileArr2[0].resolve(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.form).isDirectory()));
                }
            };
            builder.addFile(fileScope2, str2, FileAccessMode.READ).addCommand(fileInvocation).build().run();
            AsynchUtil.finish(synchronizer2, continuation2);
            return;
        }
        try {
            String[] list = this.form.getAssets().list(str2);
            new StringBuilder("contents of ");
            int d = Log.d(LOG_TAG, sb.append(str2).append(" = ").append(Arrays.toString(list)).toString());
            continuation2.call(Boolean.valueOf(list != null && list.length > 0));
        } catch (IOException e) {
            this.form.dispatchErrorOccurredEvent(this, "IsDirectory", ErrorMessages.ERROR_DIRECTORY_DOES_NOT_EXIST, str2);
        }
    }

    @SimpleFunction
    public void CopyFile(FileScope fileScope, String str, FileScope fileScope2, String str2, Continuation<Boolean> continuation) {
        Synchronizer synchronizer;
        FileOperation.Builder builder;
        FileOperation.FileInvocation fileInvocation;
        Throwable th;
        FileScope fileScope3 = fileScope;
        String str3 = str;
        FileScope fileScope4 = fileScope2;
        String str4 = str2;
        Continuation<Boolean> continuation2 = continuation;
        if (fileScope4 == FileScope.Asset) {
            this.form.dispatchErrorOccurredEvent(this, "CopyFile", ErrorMessages.ERROR_CANNOT_WRITE_ASSET, str4);
            Throwable th2 = th;
            new StopBlocksExecution();
            throw th2;
        }
        new Synchronizer();
        Synchronizer synchronizer2 = synchronizer;
        new FileOperation.Builder(this.form, this, "CopyFile");
        final Synchronizer synchronizer3 = synchronizer2;
        new FileOperation.FileInvocation(this) {
            private /* synthetic */ File hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

            {
                this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r6;
            }

            public final void call(ScopedFile[] scopedFileArr) {
                Throwable th;
                ScopedFile[] scopedFileArr2 = scopedFileArr;
                InputStream inputStream = null;
                OutputStream outputStream = null;
                java.io.File parentFile = scopedFileArr2[1].resolve(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.form).getParentFile();
                java.io.File file = parentFile;
                if (parentFile.exists() || file.mkdirs()) {
                    try {
                        inputStream = FileUtil.openForReading(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.form, scopedFileArr2[0]);
                        outputStream = FileUtil.openForWriting(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.form, scopedFileArr2[1]);
                        FileUtil.copy(inputStream, outputStream);
                        IOUtils.closeQuietly(File.LOG_TAG, inputStream);
                        IOUtils.closeQuietly(File.LOG_TAG, outputStream);
                        synchronizer3.wakeup(Boolean.TRUE);
                    } catch (IOException e) {
                        IOException iOException = e;
                        int w = Log.w(File.LOG_TAG, "Unable to copy file", iOException);
                        this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.form.dispatchErrorOccurredEvent(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME, "CopyFile", ErrorMessages.ERROR_CANNOT_COPY_MEDIA, scopedFileArr2[0].getFileName());
                        synchronizer3.caught(iOException);
                        IOUtils.closeQuietly(File.LOG_TAG, inputStream);
                        IOUtils.closeQuietly(File.LOG_TAG, outputStream);
                    } catch (Throwable th2) {
                        IOUtils.closeQuietly(File.LOG_TAG, inputStream);
                        IOUtils.closeQuietly(File.LOG_TAG, outputStream);
                        throw th2;
                    }
                } else {
                    this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.form.dispatchErrorOccurredEvent(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME, "CopyFile", ErrorMessages.ERROR_CANNOT_MAKE_DIRECTORY, file.getAbsolutePath());
                    new IOException();
                    synchronizer3.caught(th);
                }
            }
        };
        builder.addFile(fileScope3, str3, FileAccessMode.READ).addFile(fileScope4, str4, FileAccessMode.WRITE).addCommand(fileInvocation).build().run();
        AsynchUtil.finish(synchronizer2, continuation2);
    }

    @SimpleFunction
    public void MoveFile(FileScope fileScope, String str, FileScope fileScope2, String str2, Continuation<Boolean> continuation) {
        Synchronizer synchronizer;
        FileOperation.Builder builder;
        FileOperation.FileInvocation fileInvocation;
        FileScope fileScope3 = fileScope;
        String str3 = str;
        FileScope fileScope4 = fileScope2;
        String str4 = str2;
        Continuation<Boolean> continuation2 = continuation;
        if (fileScope3 == FileScope.Asset) {
            this.form.dispatchErrorOccurredEvent(this, "MoveFile", ErrorMessages.ERROR_CANNOT_DELETE_ASSET, str3);
        } else if (fileScope4 == FileScope.Asset) {
            this.form.dispatchErrorOccurredEvent(this, "MoveFile", ErrorMessages.ERROR_CANNOT_WRITE_ASSET, str4);
        } else {
            new Synchronizer();
            Synchronizer synchronizer2 = synchronizer;
            new FileOperation.Builder(this.form, this, "MoveFile");
            final Synchronizer synchronizer3 = synchronizer2;
            new FileOperation.FileInvocation(this) {
                private /* synthetic */ File hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                {
                    this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r6;
                }

                public final void call(ScopedFile[] scopedFileArr) {
                    ScopedFile[] scopedFileArr2 = scopedFileArr;
                    try {
                        synchronizer3.wakeup(Boolean.valueOf(FileUtil.moveFile(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.form, scopedFileArr2[0], scopedFileArr2[1])));
                    } catch (IOException e) {
                        synchronizer3.wakeup(Boolean.FALSE);
                    }
                }
            };
            builder.addFile(fileScope3, str3, FileAccessMode.READ).addFile(fileScope4, str4, FileAccessMode.WRITE).addCommand(fileInvocation).build().run();
            AsynchUtil.finish(synchronizer2, continuation2);
        }
    }

    @SimpleFunction
    public String MakeFullPath(FileScope fileScope, String str) {
        return FileUtil.resolveFileName(this.form, str, fileScope);
    }

    @SimpleFunction(description = "Saves text to a file. If the filename begins with a slash (/) the file is written to the sdcard. For example writing to /myFile.txt will write the file to /sdcard/myFile.txt. If the filename does not start with a slash, it will be written in the programs private data directory where it will not be accessible to other programs on the phone. There is a special exception for the AI Companion where these files are written to /sdcard/AppInventor/data to facilitate debugging. Note that this block will overwrite a file if it already exists.\n\nIf you want to add content to a file use the append block.")
    public void SaveFile(String str, String str2) {
        write(str2, "SaveFile", str, false);
    }

    @SimpleFunction(description = "Appends text to the end of a file storage, creating the file if it does not exist. See the help text under SaveFile for information about where files are written.")
    public void AppendToFile(String str, String str2) {
        write(str2, "AppendToFile", str, true);
    }

    @SimpleFunction(description = "Reads text from a file in storage. Prefix the filename with / to read from a specific file on the SD card. for instance /myFile.txt will read the file /sdcard/myFile.txt. To read assets packaged with an application (also works for the Companion) start the filename with // (two slashes). If a filename does not start with a slash, it will be read from the applications private storage (for packaged apps) and from /sdcard/AppInventor/data for the Companion.")
    public void ReadFrom(String str) {
        AnonymousClass10 r10;
        try {
            AnonymousClass10 r2 = r10;
            new FileStreamReadOperation(this, this.form, this, "ReadFrom", str, this.scope) {
                final /* synthetic */ File hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                {
                    this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r15;
                }

                public final boolean process(String str) {
                    Runnable runnable;
                    final String normalizeNewLines = IOUtils.normalizeNewLines(str);
                    new Runnable(this) {
                        private /* synthetic */ AnonymousClass10 hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                        {
                            this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r6;
                        }

                        public final void run() {
                            this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.GotText(normalizeNewLines);
                        }
                    };
                    this.form.runOnUiThread(runnable);
                    return true;
                }

                public final void onError(IOException iOException) {
                    IOException iOException2 = iOException;
                    if (iOException2 instanceof FileNotFoundException) {
                        int e = Log.e(File.LOG_TAG, "FileNotFoundException", iOException2);
                        this.form.dispatchErrorOccurredEvent(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME, "ReadFrom", ErrorMessages.ERROR_CANNOT_FIND_FILE, this.fileName);
                        return;
                    }
                    int e2 = Log.e(File.LOG_TAG, "IOException", iOException2);
                    this.form.dispatchErrorOccurredEvent(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME, "ReadFrom", ErrorMessages.ERROR_CANNOT_READ_FILE, this.fileName);
                }
            };
            r2.run();
        } catch (StopBlocksExecution e) {
        }
    }

    @SimpleFunction(description = "Deletes a file from storage. Prefix the filename with / to delete a specific file in the SD card, for instance /myFile.txt. will delete the file /sdcard/myFile.txt. If the file does not begin with a /, then the file located in the programs private storage will be deleted. Starting the file with // is an error because assets files cannot be deleted.")
    public void Delete(String str) {
        AnonymousClass11 r10;
        String str2 = str;
        if (str2.startsWith("//")) {
            this.form.dispatchErrorOccurredEvent(this, "Delete", ErrorMessages.ERROR_CANNOT_DELETE_ASSET, str2);
            return;
        }
        try {
            AnonymousClass11 r2 = r10;
            new FileWriteOperation(this, this.form, this, "Delete", str2, this.scope) {
                private /* synthetic */ File hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                {
                    this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r16;
                }

                public final void processFile(ScopedFile scopedFile) {
                    java.io.File resolve = scopedFile.resolve(this.form);
                    java.io.File file = resolve;
                    if (resolve.exists() && !file.delete()) {
                        this.form.dispatchErrorOccurredEvent(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME, "Delete", ErrorMessages.ERROR_CANNOT_DELETE_FILE, this.fileName);
                    }
                }
            };
            r2.run();
        } catch (StopBlocksExecution e) {
        }
    }

    @SimpleEvent(description = "Event indicating that the contents from the file have been read.")
    public void GotText(String str) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "GotText", str);
    }

    @SimpleEvent(description = "Event indicating that the contents of the file have been written.")
    public void AfterFileSaved(String str) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "AfterFileSaved", str);
    }

    @Deprecated
    @SimpleFunction(description = "Move a file. You can not move asset files. Use MoveFile instead.")
    public boolean Move(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        if (str3.startsWith("//") || str4.startsWith("//")) {
            return false;
        }
        return FileUtil.getExternalFile(this.form, str3, FileScope.Legacy).renameTo(FileUtil.getExternalFile(this.form, str4, FileScope.Legacy));
    }

    @Deprecated
    @SimpleFunction(description = "Copy a file. If input path started with two // (slashes) then it's a asset file. You can not copy a file into the assets directory. Use CopyFile instead.")
    public void Copy(String str, String str2) {
        Continuation continuation;
        String str3 = str;
        String str4 = str2;
        if (!str4.startsWith("//")) {
            new Continuation<Boolean>(this) {
                private /* synthetic */ File hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                {
                    this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r5;
                }

                public final /* bridge */ /* synthetic */ void call(Object obj) {
                }
            };
            CopyFile(FileScope.Legacy, str3, FileScope.Legacy, str4, continuation);
        }
    }

    @Deprecated
    @SimpleFunction(description = "Check whether a file exists. If file path started with two // (slashes) then it means you would check if a asset file exists. Use the other Exists function instead.")
    public boolean Exists(String str) {
        return FileUtil.getExternalFile(this.form, str, FileScope.Legacy).exists();
    }

    @SimpleFunction
    public void Exists(FileScope fileScope, String str, Continuation<Boolean> continuation) {
        Synchronizer synchronizer;
        FileOperation.Builder builder;
        FileOperation.FileInvocation fileInvocation;
        new Synchronizer();
        Synchronizer synchronizer2 = synchronizer;
        new FileOperation.Builder(this.form, this, "Exists");
        final Synchronizer synchronizer3 = synchronizer2;
        new FileOperation.FileInvocation(this) {
            private /* synthetic */ File hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

            {
                this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r6;
            }

            public final void call(ScopedFile[] scopedFileArr) {
                synchronizer3.wakeup(Boolean.valueOf(scopedFileArr[0].resolve(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.form).exists()));
            }
        };
        builder.addFile(fileScope, str, FileAccessMode.READ).addCommand(fileInvocation).build().run();
        AsynchUtil.finish(synchronizer2, continuation);
    }

    @SimpleFunction(description = "Get file size")
    public long FileSize(String str) {
        java.io.File externalFile = FileUtil.getExternalFile(this.form, str, FileScope.Legacy);
        java.io.File file = externalFile;
        if (!externalFile.exists() || !file.isFile()) {
            return -1;
        }
        return file.length();
    }

    @SimpleFunction(description = "Get total space")
    public long GetTotalSpace(String str) {
        return FileUtil.getExternalFile(this.form, str, FileScope.Legacy).getTotalSpace();
    }

    @SimpleFunction(description = "Get Free Space")
    public long GetFreeSpace(String str) {
        return FileUtil.getExternalFile(this.form, str, FileScope.Legacy).getFreeSpace();
    }

    @SimpleFunction(description = "Get file name")
    public String GetFileName(String str) {
        return FileUtil.getExternalFile(this.form, str, FileScope.Legacy).getName();
    }

    @SimpleFunction(description = "Check whether the path is a file")
    public boolean IsFile(String str) {
        java.io.File externalFile = FileUtil.getExternalFile(this.form, str, FileScope.Legacy);
        return externalFile.exists() && externalFile.isFile();
    }

    @SimpleEvent(description = "Event indicating that the zip file have been created.")
    public void AfterZip() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "AfterZip", new Object[0]);
    }

    @SimpleEvent(description = "Event indicating that the zip file have been created.")
    public void AfterUnzip() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "AfterUnzip", new Object[0]);
    }

    @SimpleEvent(description = "Event indicating that there was any failure on zip or unzip a file.")
    public void OnZipFailure(String str) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnZipFailure", str);
    }

    @SimpleFunction(description = "Create a zip file with or without a password.")
    public void Zip(String str, String str2, String str3) {
        StringBuilder sb;
        ZipParameters zipParameters;
        ZipFile zipFile;
        java.io.File file;
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        try {
            new ZipParameters();
            ZipParameters zipParameters2 = zipParameters;
            ZipParameters zipParameters3 = zipParameters2;
            zipParameters2.setCompressionMethod(8);
            zipParameters3.setCompressionLevel(5);
            if (str6.length() > 0) {
                zipParameters3.setEncryptFiles(true);
                zipParameters3.setEncryptionMethod(99);
                zipParameters3.setAesKeyStrength(3);
                zipParameters3.setPassword(str6);
            }
            new ZipFile(str5);
            ZipFile zipFile2 = zipFile;
            new java.io.File(str4);
            java.io.File file2 = file;
            java.io.File file3 = file2;
            if (file2.isFile()) {
                zipFile2.addFile(file3, zipParameters3);
            } else if (file3.isDirectory()) {
                zipFile2.addFolder(file3, zipParameters3);
            }
            AfterZip();
        } catch (Exception e) {
            Exception exc = e;
            int e2 = Log.e(LOG_TAG, String.valueOf(exc));
            new StringBuilder();
            OnZipFailure(sb.append(exc.getMessage()).toString());
        }
    }

    @SimpleFunction(description = "Unzip a file with or without a password. If you dont need a passwort then let it empty.")
    public void Unzip(String str, String str2, String str3) {
        StringBuilder sb;
        ZipFile zipFile;
        String str4 = str2;
        String str5 = str3;
        try {
            new ZipFile(str);
            ZipFile zipFile2 = zipFile;
            ZipFile zipFile3 = zipFile2;
            if (zipFile2.isEncrypted()) {
                zipFile3.setPassword(str5);
            }
            zipFile3.extractAll(str4);
            AfterUnzip();
        } catch (Exception e) {
            Exception exc = e;
            int e2 = Log.e(LOG_TAG, String.valueOf(exc));
            new StringBuilder();
            OnZipFailure(sb.append(exc.getMessage()).toString());
        }
    }

    @Deprecated
    @SimpleFunction(description = "Create a new directory. Use MakeDirectory instead.")
    public void CreateDirectory(String str) {
        Continuation continuation;
        new Continuation<Boolean>(this) {
            private /* synthetic */ File hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

            {
                this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r5;
            }

            public final /* synthetic */ void call(Object obj) {
                this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.DirectoryCreated(((Boolean) obj).booleanValue());
            }
        };
        MakeDirectory(FileScope.Legacy, str, continuation);
    }

    @SimpleEvent(description = "Event indicating that there was a directory created. The return value is 'true' or 'false'.")
    @Deprecated
    public void DirectoryCreated(boolean z) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "DirectoryCreated", Boolean.valueOf(z));
    }

    private void write(String str, String str2, String str3, boolean z) {
        AnonymousClass4 r16;
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        boolean z2 = z;
        if (str4.startsWith("//")) {
            this.form.dispatchErrorOccurredEvent(this, str5, ErrorMessages.ERROR_CANNOT_WRITE_ASSET, str4);
            return;
        }
        if (str4.startsWith("/")) {
            FileUtil.checkExternalStorageWriteable();
        }
        try {
            AnonymousClass4 r5 = r16;
            final String str7 = str6;
            final String str8 = str4;
            new FileStreamWriteOperation(this, this.form, this, str5, str4, this.scope, z2) {
                final /* synthetic */ File hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                {
                    this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r19;
                }

                public final void processFile(ScopedFile scopedFile) {
                    StringBuilder sb;
                    ScopedFile scopedFile2 = scopedFile;
                    java.io.File resolve = scopedFile2.resolve(this.form);
                    java.io.File file = resolve;
                    if (!resolve.exists()) {
                        boolean z = false;
                        try {
                            IOUtils.mkdirs(file);
                            z = file.createNewFile();
                        } catch (IOException e) {
                            new StringBuilder("Unable to create file ");
                            int e2 = Log.e(File.LOG_TAG, sb.append(file.getAbsolutePath()).toString());
                        }
                        if (!z) {
                            this.form.dispatchErrorOccurredEvent(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME, this.method, ErrorMessages.ERROR_CANNOT_CREATE_FILE, file.getAbsolutePath());
                            return;
                        }
                    }
                    super.processFile(scopedFile2);
                }

                public final boolean process(OutputStreamWriter outputStreamWriter) throws IOException {
                    Runnable runnable;
                    OutputStreamWriter outputStreamWriter2 = outputStreamWriter;
                    outputStreamWriter2.write(str7);
                    outputStreamWriter2.flush();
                    new Runnable(this) {
                        private /* synthetic */ AnonymousClass4 hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                        {
                            this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r5;
                        }

                        public final void run() {
                            this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME.AfterFileSaved(str8);
                        }
                    };
                    this.form.runOnUiThread(runnable);
                    return true;
                }

                public final void onError(IOException iOException) {
                    super.onError(iOException);
                    this.form.dispatchErrorOccurredEvent(this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME, this.method, ErrorMessages.ERROR_CANNOT_WRITE_TO_FILE, getFile().getAbsolutePath());
                }
            };
            r5.run();
        } catch (StopBlocksExecution e) {
        }
    }
}
