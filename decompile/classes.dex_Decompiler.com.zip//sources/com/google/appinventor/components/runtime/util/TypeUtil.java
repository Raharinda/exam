package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.common.OptionList;
import com.google.appinventor.components.runtime.errors.DispatchableError;
import gnu.mapping.Symbol;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public final class TypeUtil {
    private TypeUtil() {
    }

    public static <T> T cast(Object obj, Class<T> cls, String str) {
        Throwable th;
        Object obj2 = obj;
        Class<T> cls2 = cls;
        String str2 = str;
        if (obj2 == null) {
            return null;
        }
        if (cls2.isInstance(obj2)) {
            return cls2.cast(obj2);
        }
        Throwable th2 = th;
        Object[] objArr = new Object[2];
        objArr[0] = obj2.getClass().getSimpleName();
        Object[] objArr2 = objArr;
        objArr2[1] = str2;
        new DispatchableError(ErrorMessages.ERROR_INVALID_TYPE, objArr2);
        throw th2;
    }

    public static <T> T castNotNull(Object obj, Class<T> cls, String str) {
        Throwable th;
        Object obj2 = obj;
        Class<T> cls2 = cls;
        String str2 = str;
        if (obj2 != null) {
            return cast(obj2, cls2, str2);
        }
        Throwable th2 = th;
        Object[] objArr = new Object[2];
        objArr[0] = "null";
        Object[] objArr2 = objArr;
        objArr2[1] = str2;
        new DispatchableError(ErrorMessages.ERROR_INVALID_TYPE, objArr2);
        throw th2;
    }

    public static <T> OptionList<T> castToEnum(T t, Symbol symbol) {
        String str;
        Throwable th;
        StringBuilder sb;
        T t2 = t;
        String name = symbol.getName();
        String str2 = name;
        if (name.endsWith("Enum")) {
            str = str2.substring(0, str2.length() - 4);
        } else {
            str = str2;
        }
        String str3 = str;
        try {
            Class<?> cls = Class.forName(str3);
            if (!OptionList.class.isAssignableFrom(cls)) {
                Throwable th2 = th;
                new StringBuilder();
                new IllegalArgumentException(sb.append(str3).append(" does not identify an OptionList type.").toString());
                throw th2;
            }
            Method[] methods = cls.getMethods();
            Method[] methodArr = methods;
            int length = methods.length;
            for (int i = 0; i < length; i++) {
                Method method = methodArr[i];
                if ("fromUnderlyingValue".equals(method.getName())) {
                    return (OptionList) method.invoke(cls, new Object[]{t2});
                }
            }
            return null;
        } catch (ClassNotFoundException e) {
            return null;
        } catch (InvocationTargetException e2) {
            return null;
        } catch (IllegalAccessException e3) {
            return null;
        }
    }
}
