package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Form;

public class RUtil {
    public RUtil() {
    }

    public static boolean needsFilePermission(Form form, String str, FileScope fileScope) {
        Form form2 = form;
        String str2 = str;
        FileScope fileScope2 = fileScope;
        if (fileScope2 != null) {
            switch (fileScope2) {
                case App:
                case Asset:
                    return false;
                case Shared:
                    return true;
                default:
                    return false;
            }
        } else if (str2.startsWith("//")) {
            return false;
        } else {
            if (!str2.startsWith("/") && !str2.startsWith("file:")) {
                return false;
            }
            if (str2.startsWith("file:")) {
                str2 = str2.substring(5);
            }
            String concat = "file:".concat(String.valueOf(str2));
            if (!FileUtil.isExternalStorageUri(form2, concat) || FileUtil.isAppSpecificExternalUri(form2, concat)) {
                return false;
            }
            return true;
        }
    }
}
