package com.google.appinventor.components.runtime;

import android.view.Menu;

public interface OnCreateOptionsMenuListener {
    void onCreateOptionsMenu(Menu menu);
}
