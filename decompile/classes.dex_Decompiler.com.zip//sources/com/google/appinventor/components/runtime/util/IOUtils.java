package com.google.appinventor.components.runtime.util;

import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public final class IOUtils {
    public IOUtils() {
    }

    public static void closeQuietly(String str, Closeable closeable) {
        String str2 = str;
        Closeable closeable2 = closeable;
        if (closeable2 != null) {
            try {
                closeable2.close();
            } catch (IOException e) {
                int w = Log.w(str2, "Failed to close resource", e);
            }
        }
    }

    public static byte[] readStream(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream;
        InputStream inputStream2 = inputStream;
        new ByteArrayOutputStream();
        ByteArrayOutputStream byteArrayOutputStream2 = byteArrayOutputStream;
        byte[] bArr = new byte[4096];
        while (true) {
            int read = inputStream2.read(bArr);
            int i = read;
            if (read <= 0) {
                return byteArrayOutputStream2.toByteArray();
            }
            byteArrayOutputStream2.write(bArr, 0, i);
        }
    }

    public static String readStreamAsString(InputStream inputStream, String str) throws IOException {
        String str2;
        new String(readStream(inputStream), str);
        return str2;
    }

    public static String readStreamAsString(InputStream inputStream) throws IOException {
        return readStreamAsString(inputStream, "UTF-8");
    }

    public static String readReader(InputStreamReader inputStreamReader) throws IOException {
        StringBuilder sb;
        InputStreamReader inputStreamReader2 = inputStreamReader;
        new StringBuilder();
        StringBuilder sb2 = sb;
        char[] cArr = new char[4096];
        while (true) {
            int read = inputStreamReader2.read(cArr);
            int i = read;
            if (read <= 0) {
                return sb2.toString();
            }
            StringBuilder append = sb2.append(cArr, 0, i);
        }
    }

    public static String normalizeNewLines(String str) {
        return str.replaceAll("\r\n", "\n");
    }

    public static void mkdirs(File file) throws IOException {
        Throwable th;
        File file2 = file;
        File parentFile = file2.getParentFile();
        File file3 = parentFile;
        if (!parentFile.exists() && !file3.mkdirs()) {
            Throwable th2 = th;
            new IOException("Unable to create directory for ".concat(String.valueOf(file2)));
            throw th2;
        }
    }
}
