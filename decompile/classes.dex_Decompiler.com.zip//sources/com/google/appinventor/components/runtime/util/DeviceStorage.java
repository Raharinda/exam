package com.google.appinventor.components.runtime.util;

public enum DeviceStorage {
}
