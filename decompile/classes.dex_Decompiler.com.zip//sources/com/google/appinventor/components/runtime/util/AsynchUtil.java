package com.google.appinventor.components.runtime.util;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;

public class AsynchUtil {
    private static final String LOG_TAG = AsynchUtil.class.getSimpleName();

    public AsynchUtil() {
    }

    public static void runAsynchronously(Runnable runnable) {
        Thread thread;
        new Thread(runnable);
        thread.start();
    }

    public static void runAsynchronously(Handler handler, Runnable runnable, Runnable runnable2) {
        Runnable runnable3;
        Thread thread;
        final Runnable runnable4 = runnable;
        final Runnable runnable5 = runnable2;
        final Handler handler2 = handler;
        new Runnable() {
            public final void run() {
                Runnable runnable;
                runnable4.run();
                if (runnable5 != null) {
                    new Runnable(this) {
                        private /* synthetic */ AnonymousClass1 hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

                        {
                            this.hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME = r5;
                        }

                        public final void run() {
                            runnable5.run();
                        }
                    };
                    boolean post = handler2.post(runnable);
                }
            }
        };
        new Thread(runnable3);
        thread.start();
    }

    public static boolean isUiThread() {
        return Looper.getMainLooper().equals(Looper.myLooper());
    }

    public static <T> void finish(Synchronizer<T> synchronizer, Continuation<T> continuation) {
        Throwable th;
        Synchronizer<T> synchronizer2 = synchronizer;
        Continuation<T> continuation2 = continuation;
        int d = Log.d(LOG_TAG, "Waiting for synchronizer result");
        synchronizer2.waitfor();
        if (synchronizer2.getThrowable() == null) {
            continuation2.call(synchronizer2.getResult());
            return;
        }
        Throwable throwable = synchronizer2.getThrowable();
        Throwable th2 = throwable;
        if (throwable instanceof RuntimeException) {
            throw ((RuntimeException) th2);
        }
        Throwable th3 = th;
        new YailRuntimeError(th2.toString(), th2.getClass().getSimpleName());
        throw th3;
    }
}
