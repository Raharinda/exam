package com.google.appinventor.components.runtime;

public abstract class SpeechRecognizerController {
    SpeechListener hxYOFxFjLpN1maJuWNxUV40nExCGxsxkDPOTgtzMu4zlZCQb3bPlKsXo1SYJg6ME;

    public SpeechRecognizerController() {
    }

    /* access modifiers changed from: package-private */
    public void start() {
    }

    /* access modifiers changed from: package-private */
    public void stop() {
    }
}
