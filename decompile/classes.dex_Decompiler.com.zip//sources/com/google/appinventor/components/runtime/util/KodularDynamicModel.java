package com.google.appinventor.components.runtime.util;

public class KodularDynamicModel {
    private Object F0SK4gPRNmAI2jCyU6DpJpRxlfo5Y8j9ZujjeLuDeDzReJBeSNN2RZtCnkXv1dho;
    private int KYHvnTv0AWOO8SeFCXsiNXCxcIirISbo8kAOvMnivJLnqAuCVxfixET1OT3ZpHhw;
    private Object KbzcIEn6WDqjdY1QBot1TMrBwhEYy4xAUKG2cbzQ22VNohlOtuBGKUJsEeMNZyEH;
    private Object LYVRHQlR5uMq9RmVQLgPQwQp4HVKuBDt7Jnpu0jTztYClgnk53NSpkUmjjPPbYn;

    public KodularDynamicModel(int i, Object obj, Object obj2) {
        setId(i);
        setObject(obj);
        setViewHolder(obj2);
    }

    public KodularDynamicModel(int i, Object obj, Object obj2, Object obj3) {
        setId(i);
        setObject(obj);
        setViewHolder(obj2);
        setChildViewHolder(obj3);
    }

    public void setId(int i) {
        int i2 = i;
        this.KYHvnTv0AWOO8SeFCXsiNXCxcIirISbo8kAOvMnivJLnqAuCVxfixET1OT3ZpHhw = i2;
    }

    public int getId() {
        return this.KYHvnTv0AWOO8SeFCXsiNXCxcIirISbo8kAOvMnivJLnqAuCVxfixET1OT3ZpHhw;
    }

    public void setObject(Object obj) {
        Object obj2 = obj;
        this.KbzcIEn6WDqjdY1QBot1TMrBwhEYy4xAUKG2cbzQ22VNohlOtuBGKUJsEeMNZyEH = obj2;
    }

    public Object getObject() {
        return this.KbzcIEn6WDqjdY1QBot1TMrBwhEYy4xAUKG2cbzQ22VNohlOtuBGKUJsEeMNZyEH;
    }

    public void setViewHolder(Object obj) {
        Object obj2 = obj;
        this.F0SK4gPRNmAI2jCyU6DpJpRxlfo5Y8j9ZujjeLuDeDzReJBeSNN2RZtCnkXv1dho = obj2;
    }

    public Object getViewHolder() {
        return this.F0SK4gPRNmAI2jCyU6DpJpRxlfo5Y8j9ZujjeLuDeDzReJBeSNN2RZtCnkXv1dho;
    }

    public void setChildViewHolder(Object obj) {
        Object obj2 = obj;
        this.LYVRHQlR5uMq9RmVQLgPQwQp4HVKuBDt7Jnpu0jTztYClgnk53NSpkUmjjPPbYn = obj2;
    }

    public Object getChildViewHolder() {
        return this.LYVRHQlR5uMq9RmVQLgPQwQp4HVKuBDt7Jnpu0jTztYClgnk53NSpkUmjjPPbYn;
    }
}
