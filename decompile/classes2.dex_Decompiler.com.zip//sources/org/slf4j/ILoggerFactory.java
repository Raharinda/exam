package org.slf4j;

public interface ILoggerFactory {
    Logger getLogger(String str);
}
