package org.jose4j.jwk;

public class Use {
    public static final String ENCRYPTION = "enc";
    public static final String SIGNATURE = "sig";

    public Use() {
    }
}
