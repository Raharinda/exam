package org.jose4j.lang;

public interface ByteGenerator {
    byte[] randomBytes(int i);
}
