package org.jose4j.lang;

public class InvalidAlgorithmException extends JoseException {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public InvalidAlgorithmException(String message) {
        super(message);
    }
}
