package org.jose4j.lang;

public class UnresolvableKeyException extends JoseException {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public UnresolvableKeyException(String message) {
        super(message);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public UnresolvableKeyException(String message, Throwable cause) {
        super(message, cause);
    }
}
