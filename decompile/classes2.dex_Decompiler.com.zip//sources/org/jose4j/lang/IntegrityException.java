package org.jose4j.lang;

public class IntegrityException extends JoseException {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public IntegrityException(String message) {
        super(message);
    }
}
