package org.jose4j.lang;

public class JoseException extends Exception {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public JoseException(String message) {
        super(message);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public JoseException(String message, Throwable cause) {
        super(message, cause);
    }
}
