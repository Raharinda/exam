package org.jose4j.json.internal.json_simple;

public interface JSONAware {
    String toJSONString();
}
