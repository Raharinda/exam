package org.jose4j.keys;

public enum KeyPersuasion {
}
