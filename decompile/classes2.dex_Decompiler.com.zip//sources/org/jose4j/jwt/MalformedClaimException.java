package org.jose4j.jwt;

public class MalformedClaimException extends GeneralJwtException {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public MalformedClaimException(String message) {
        super(message);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public MalformedClaimException(String message, Throwable cause) {
        super(message, cause);
    }
}
