package org.jose4j.jwt;

public class GeneralJwtException extends Exception {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public GeneralJwtException(String message) {
        super(message);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public GeneralJwtException(String message, Throwable cause) {
        super(message, cause);
    }
}
