package org.jose4j.zip;

public class CompressionAlgorithmIdentifiers {
    public static final String DEFLATE = "DEF";

    public CompressionAlgorithmIdentifiers() {
    }
}
