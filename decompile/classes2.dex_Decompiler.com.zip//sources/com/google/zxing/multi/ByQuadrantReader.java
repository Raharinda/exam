package com.google.zxing.multi;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.ChecksumException;
import com.google.zxing.DecodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.Reader;
import com.google.zxing.Result;
import java.util.Map;

public final class ByQuadrantReader implements Reader {
    private final Reader delegate;

    public ByQuadrantReader(Reader delegate2) {
        this.delegate = delegate2;
    }

    public Result decode(BinaryBitmap image) throws NotFoundException, ChecksumException, FormatException {
        return decode(image, (Map<DecodeHintType, ?>) null);
    }

    public Result decode(BinaryBitmap binaryBitmap, Map<DecodeHintType, ?> map) throws NotFoundException, ChecksumException, FormatException {
        BinaryBitmap image = binaryBitmap;
        Map<DecodeHintType, ?> hints = map;
        int width = image.getWidth();
        int halfWidth = width / 2;
        int halfHeight = image.getHeight() / 2;
        try {
            return this.delegate.decode(image.crop(0, 0, halfWidth, halfHeight), hints);
        } catch (NotFoundException e) {
            NotFoundException notFoundException = e;
            try {
                return this.delegate.decode(image.crop(halfWidth, 0, halfWidth, halfHeight), hints);
            } catch (NotFoundException e2) {
                NotFoundException notFoundException2 = e2;
                try {
                    return this.delegate.decode(image.crop(0, halfHeight, halfWidth, halfHeight), hints);
                } catch (NotFoundException e3) {
                    NotFoundException notFoundException3 = e3;
                    try {
                        return this.delegate.decode(image.crop(halfWidth, halfHeight, halfWidth, halfHeight), hints);
                    } catch (NotFoundException e4) {
                        NotFoundException notFoundException4 = e4;
                        return this.delegate.decode(image.crop(halfWidth / 2, halfHeight / 2, halfWidth, halfHeight), hints);
                    }
                }
            }
        }
    }

    public void reset() {
        this.delegate.reset();
    }
}
