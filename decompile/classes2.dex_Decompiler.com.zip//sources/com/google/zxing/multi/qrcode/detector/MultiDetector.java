package com.google.zxing.multi.qrcode.detector;

import com.google.zxing.DecodeHintType;
import com.google.zxing.NotFoundException;
import com.google.zxing.ReaderException;
import com.google.zxing.ResultPointCallback;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DetectorResult;
import com.google.zxing.qrcode.detector.Detector;
import com.google.zxing.qrcode.detector.FinderPatternInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class MultiDetector extends Detector {
    private static final DetectorResult[] EMPTY_DETECTOR_RESULTS = new DetectorResult[0];

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public MultiDetector(BitMatrix image) {
        super(image);
    }

    public DetectorResult[] detectMulti(Map<DecodeHintType, ?> map) throws NotFoundException {
        MultiFinderPatternFinder finder;
        List<DetectorResult> list;
        Map<DecodeHintType, ?> hints = map;
        new MultiFinderPatternFinder(getImage(), hints == null ? null : (ResultPointCallback) hints.get(DecodeHintType.NEED_RESULT_POINT_CALLBACK));
        FinderPatternInfo[] infos = finder.findMulti(hints);
        if (infos.length == 0) {
            throw NotFoundException.getNotFoundInstance();
        }
        new ArrayList<>();
        List<DetectorResult> result = list;
        FinderPatternInfo[] arr$ = infos;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            try {
                boolean add = result.add(processFinderPatternInfo(arr$[i$]));
            } catch (ReaderException e) {
                ReaderException readerException = e;
            }
        }
        if (result.isEmpty()) {
            return EMPTY_DETECTOR_RESULTS;
        }
        return (DetectorResult[]) result.toArray(new DetectorResult[result.size()]);
    }
}
