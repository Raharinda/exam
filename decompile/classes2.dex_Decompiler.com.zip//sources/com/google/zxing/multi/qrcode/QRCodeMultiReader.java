package com.google.zxing.multi.qrcode;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.multi.MultipleBarcodeReader;
import com.google.zxing.qrcode.QRCodeReader;
import java.util.Map;

public final class QRCodeMultiReader extends QRCodeReader implements MultipleBarcodeReader {
    private static final Result[] EMPTY_RESULT_ARRAY = new Result[0];

    public QRCodeMultiReader() {
    }

    public Result[] decodeMultiple(BinaryBitmap image) throws NotFoundException {
        return decodeMultiple(image, (Map<DecodeHintType, ?>) null);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v0, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v34, resolved type: com.google.zxing.Result} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v35, resolved type: com.google.zxing.Result} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.google.zxing.Result[] decodeMultiple(com.google.zxing.BinaryBitmap r22, java.util.Map<com.google.zxing.DecodeHintType, ?> r23) throws com.google.zxing.NotFoundException {
        /*
            r21 = this;
            r0 = r21
            r1 = r22
            r2 = r23
            java.util.ArrayList r14 = new java.util.ArrayList
            r20 = r14
            r14 = r20
            r15 = r20
            r15.<init>()
            r3 = r14
            com.google.zxing.multi.qrcode.detector.MultiDetector r14 = new com.google.zxing.multi.qrcode.detector.MultiDetector
            r20 = r14
            r14 = r20
            r15 = r20
            r16 = r1
            com.google.zxing.common.BitMatrix r16 = r16.getBlackMatrix()
            r15.<init>(r16)
            r15 = r2
            com.google.zxing.common.DetectorResult[] r14 = r14.detectMulti(r15)
            r4 = r14
            r14 = r4
            r5 = r14
            r14 = r5
            int r14 = r14.length
            r6 = r14
            r14 = 0
            r7 = r14
        L_0x0030:
            r14 = r7
            r15 = r6
            if (r14 >= r15) goto L_0x009a
            r14 = r5
            r15 = r7
            r14 = r14[r15]
            r8 = r14
            r14 = r0
            com.google.zxing.qrcode.decoder.Decoder r14 = r14.getDecoder()     // Catch:{ ReaderException -> 0x0097 }
            r15 = r8
            com.google.zxing.common.BitMatrix r15 = r15.getBits()     // Catch:{ ReaderException -> 0x0097 }
            r16 = r2
            com.google.zxing.common.DecoderResult r14 = r14.decode((com.google.zxing.common.BitMatrix) r15, (java.util.Map<com.google.zxing.DecodeHintType, ?>) r16)     // Catch:{ ReaderException -> 0x0097 }
            r9 = r14
            r14 = r8
            com.google.zxing.ResultPoint[] r14 = r14.getPoints()     // Catch:{ ReaderException -> 0x0097 }
            r10 = r14
            com.google.zxing.Result r14 = new com.google.zxing.Result     // Catch:{ ReaderException -> 0x0097 }
            r20 = r14
            r14 = r20
            r15 = r20
            r16 = r9
            java.lang.String r16 = r16.getText()     // Catch:{ ReaderException -> 0x0097 }
            r17 = r9
            byte[] r17 = r17.getRawBytes()     // Catch:{ ReaderException -> 0x0097 }
            r18 = r10
            com.google.zxing.BarcodeFormat r19 = com.google.zxing.BarcodeFormat.QR_CODE     // Catch:{ ReaderException -> 0x0097 }
            r15.<init>(r16, r17, r18, r19)     // Catch:{ ReaderException -> 0x0097 }
            r11 = r14
            r14 = r9
            java.util.List r14 = r14.getByteSegments()     // Catch:{ ReaderException -> 0x0097 }
            r12 = r14
            r14 = r12
            if (r14 == 0) goto L_0x007d
            r14 = r11
            com.google.zxing.ResultMetadataType r15 = com.google.zxing.ResultMetadataType.BYTE_SEGMENTS     // Catch:{ ReaderException -> 0x0097 }
            r16 = r12
            r14.putMetadata(r15, r16)     // Catch:{ ReaderException -> 0x0097 }
        L_0x007d:
            r14 = r9
            java.lang.String r14 = r14.getECLevel()     // Catch:{ ReaderException -> 0x0097 }
            r13 = r14
            r14 = r13
            if (r14 == 0) goto L_0x008e
            r14 = r11
            com.google.zxing.ResultMetadataType r15 = com.google.zxing.ResultMetadataType.ERROR_CORRECTION_LEVEL     // Catch:{ ReaderException -> 0x0097 }
            r16 = r13
            r14.putMetadata(r15, r16)     // Catch:{ ReaderException -> 0x0097 }
        L_0x008e:
            r14 = r3
            r15 = r11
            boolean r14 = r14.add(r15)     // Catch:{ ReaderException -> 0x0097 }
        L_0x0094:
            int r7 = r7 + 1
            goto L_0x0030
        L_0x0097:
            r14 = move-exception
            r9 = r14
            goto L_0x0094
        L_0x009a:
            r14 = r3
            boolean r14 = r14.isEmpty()
            if (r14 == 0) goto L_0x00a5
            com.google.zxing.Result[] r14 = EMPTY_RESULT_ARRAY
            r0 = r14
        L_0x00a4:
            return r0
        L_0x00a5:
            r14 = r3
            r15 = r3
            int r15 = r15.size()
            com.google.zxing.Result[] r15 = new com.google.zxing.Result[r15]
            java.lang.Object[] r14 = r14.toArray(r15)
            com.google.zxing.Result[] r14 = (com.google.zxing.Result[]) r14
            r0 = r14
            goto L_0x00a4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.multi.qrcode.QRCodeMultiReader.decodeMultiple(com.google.zxing.BinaryBitmap, java.util.Map):com.google.zxing.Result[]");
    }
}
