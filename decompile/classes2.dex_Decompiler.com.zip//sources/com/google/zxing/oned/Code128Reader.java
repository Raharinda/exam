package com.google.zxing.oned;

import com.google.zxing.NotFoundException;
import com.google.zxing.common.BitArray;

public final class Code128Reader extends OneDReader {
    private static final int CODE_CODE_A = 101;
    private static final int CODE_CODE_B = 100;
    private static final int CODE_CODE_C = 99;
    private static final int CODE_FNC_1 = 102;
    private static final int CODE_FNC_2 = 97;
    private static final int CODE_FNC_3 = 96;
    private static final int CODE_FNC_4_A = 101;
    private static final int CODE_FNC_4_B = 100;
    static final int[][] CODE_PATTERNS;
    private static final int CODE_SHIFT = 98;
    private static final int CODE_START_A = 103;
    private static final int CODE_START_B = 104;
    private static final int CODE_START_C = 105;
    private static final int CODE_STOP = 106;
    private static final int MAX_AVG_VARIANCE = 64;
    private static final int MAX_INDIVIDUAL_VARIANCE = 179;

    public Code128Reader() {
    }

    static {
        int[][] iArr = new int[107][];
        iArr[0] = new int[]{2, 1, 2, 2, 2, 2};
        int[][] iArr2 = iArr;
        iArr2[1] = new int[]{2, 2, 2, 1, 2, 2};
        int[][] iArr3 = iArr2;
        iArr3[2] = new int[]{2, 2, 2, 2, 2, 1};
        int[][] iArr4 = iArr3;
        iArr4[3] = new int[]{1, 2, 1, 2, 2, 3};
        int[][] iArr5 = iArr4;
        iArr5[4] = new int[]{1, 2, 1, 3, 2, 2};
        int[][] iArr6 = iArr5;
        iArr6[5] = new int[]{1, 3, 1, 2, 2, 2};
        int[][] iArr7 = iArr6;
        iArr7[6] = new int[]{1, 2, 2, 2, 1, 3};
        int[][] iArr8 = iArr7;
        iArr8[7] = new int[]{1, 2, 2, 3, 1, 2};
        int[][] iArr9 = iArr8;
        iArr9[8] = new int[]{1, 3, 2, 2, 1, 2};
        int[][] iArr10 = iArr9;
        iArr10[9] = new int[]{2, 2, 1, 2, 1, 3};
        int[][] iArr11 = iArr10;
        iArr11[10] = new int[]{2, 2, 1, 3, 1, 2};
        int[][] iArr12 = iArr11;
        iArr12[11] = new int[]{2, 3, 1, 2, 1, 2};
        int[][] iArr13 = iArr12;
        iArr13[12] = new int[]{1, 1, 2, 2, 3, 2};
        int[][] iArr14 = iArr13;
        iArr14[13] = new int[]{1, 2, 2, 1, 3, 2};
        int[][] iArr15 = iArr14;
        iArr15[14] = new int[]{1, 2, 2, 2, 3, 1};
        int[][] iArr16 = iArr15;
        iArr16[15] = new int[]{1, 1, 3, 2, 2, 2};
        int[][] iArr17 = iArr16;
        iArr17[16] = new int[]{1, 2, 3, 1, 2, 2};
        int[][] iArr18 = iArr17;
        iArr18[17] = new int[]{1, 2, 3, 2, 2, 1};
        int[][] iArr19 = iArr18;
        iArr19[18] = new int[]{2, 2, 3, 2, 1, 1};
        int[][] iArr20 = iArr19;
        iArr20[19] = new int[]{2, 2, 1, 1, 3, 2};
        int[][] iArr21 = iArr20;
        iArr21[20] = new int[]{2, 2, 1, 2, 3, 1};
        int[][] iArr22 = iArr21;
        iArr22[21] = new int[]{2, 1, 3, 2, 1, 2};
        int[][] iArr23 = iArr22;
        iArr23[22] = new int[]{2, 2, 3, 1, 1, 2};
        int[][] iArr24 = iArr23;
        iArr24[23] = new int[]{3, 1, 2, 1, 3, 1};
        int[][] iArr25 = iArr24;
        iArr25[24] = new int[]{3, 1, 1, 2, 2, 2};
        int[][] iArr26 = iArr25;
        iArr26[25] = new int[]{3, 2, 1, 1, 2, 2};
        int[][] iArr27 = iArr26;
        iArr27[26] = new int[]{3, 2, 1, 2, 2, 1};
        int[][] iArr28 = iArr27;
        iArr28[27] = new int[]{3, 1, 2, 2, 1, 2};
        int[][] iArr29 = iArr28;
        iArr29[28] = new int[]{3, 2, 2, 1, 1, 2};
        int[][] iArr30 = iArr29;
        iArr30[29] = new int[]{3, 2, 2, 2, 1, 1};
        int[][] iArr31 = iArr30;
        iArr31[30] = new int[]{2, 1, 2, 1, 2, 3};
        int[][] iArr32 = iArr31;
        iArr32[31] = new int[]{2, 1, 2, 3, 2, 1};
        int[][] iArr33 = iArr32;
        iArr33[32] = new int[]{2, 3, 2, 1, 2, 1};
        int[][] iArr34 = iArr33;
        iArr34[33] = new int[]{1, 1, 1, 3, 2, 3};
        int[][] iArr35 = iArr34;
        iArr35[34] = new int[]{1, 3, 1, 1, 2, 3};
        int[][] iArr36 = iArr35;
        iArr36[35] = new int[]{1, 3, 1, 3, 2, 1};
        int[][] iArr37 = iArr36;
        iArr37[36] = new int[]{1, 1, 2, 3, 1, 3};
        int[][] iArr38 = iArr37;
        iArr38[37] = new int[]{1, 3, 2, 1, 1, 3};
        int[][] iArr39 = iArr38;
        iArr39[38] = new int[]{1, 3, 2, 3, 1, 1};
        int[][] iArr40 = iArr39;
        iArr40[39] = new int[]{2, 1, 1, 3, 1, 3};
        int[][] iArr41 = iArr40;
        iArr41[40] = new int[]{2, 3, 1, 1, 1, 3};
        int[][] iArr42 = iArr41;
        iArr42[41] = new int[]{2, 3, 1, 3, 1, 1};
        int[][] iArr43 = iArr42;
        iArr43[42] = new int[]{1, 1, 2, 1, 3, 3};
        int[][] iArr44 = iArr43;
        iArr44[43] = new int[]{1, 1, 2, 3, 3, 1};
        int[][] iArr45 = iArr44;
        iArr45[44] = new int[]{1, 3, 2, 1, 3, 1};
        int[][] iArr46 = iArr45;
        iArr46[45] = new int[]{1, 1, 3, 1, 2, 3};
        int[][] iArr47 = iArr46;
        iArr47[46] = new int[]{1, 1, 3, 3, 2, 1};
        int[][] iArr48 = iArr47;
        iArr48[47] = new int[]{1, 3, 3, 1, 2, 1};
        int[][] iArr49 = iArr48;
        iArr49[48] = new int[]{3, 1, 3, 1, 2, 1};
        int[][] iArr50 = iArr49;
        iArr50[49] = new int[]{2, 1, 1, 3, 3, 1};
        int[][] iArr51 = iArr50;
        iArr51[50] = new int[]{2, 3, 1, 1, 3, 1};
        int[][] iArr52 = iArr51;
        iArr52[51] = new int[]{2, 1, 3, 1, 1, 3};
        int[][] iArr53 = iArr52;
        iArr53[52] = new int[]{2, 1, 3, 3, 1, 1};
        int[][] iArr54 = iArr53;
        iArr54[53] = new int[]{2, 1, 3, 1, 3, 1};
        int[][] iArr55 = iArr54;
        iArr55[54] = new int[]{3, 1, 1, 1, 2, 3};
        int[][] iArr56 = iArr55;
        iArr56[55] = new int[]{3, 1, 1, 3, 2, 1};
        int[][] iArr57 = iArr56;
        iArr57[56] = new int[]{3, 3, 1, 1, 2, 1};
        int[][] iArr58 = iArr57;
        iArr58[57] = new int[]{3, 1, 2, 1, 1, 3};
        int[][] iArr59 = iArr58;
        iArr59[58] = new int[]{3, 1, 2, 3, 1, 1};
        int[][] iArr60 = iArr59;
        iArr60[59] = new int[]{3, 3, 2, 1, 1, 1};
        int[][] iArr61 = iArr60;
        iArr61[60] = new int[]{3, 1, 4, 1, 1, 1};
        int[][] iArr62 = iArr61;
        iArr62[61] = new int[]{2, 2, 1, 4, 1, 1};
        int[][] iArr63 = iArr62;
        iArr63[62] = new int[]{4, 3, 1, 1, 1, 1};
        int[][] iArr64 = iArr63;
        iArr64[63] = new int[]{1, 1, 1, 2, 2, 4};
        int[][] iArr65 = iArr64;
        iArr65[64] = new int[]{1, 1, 1, 4, 2, 2};
        int[][] iArr66 = iArr65;
        iArr66[65] = new int[]{1, 2, 1, 1, 2, 4};
        int[][] iArr67 = iArr66;
        iArr67[66] = new int[]{1, 2, 1, 4, 2, 1};
        int[][] iArr68 = iArr67;
        iArr68[67] = new int[]{1, 4, 1, 1, 2, 2};
        int[][] iArr69 = iArr68;
        iArr69[68] = new int[]{1, 4, 1, 2, 2, 1};
        int[][] iArr70 = iArr69;
        iArr70[69] = new int[]{1, 1, 2, 2, 1, 4};
        int[][] iArr71 = iArr70;
        iArr71[70] = new int[]{1, 1, 2, 4, 1, 2};
        int[][] iArr72 = iArr71;
        iArr72[71] = new int[]{1, 2, 2, 1, 1, 4};
        int[][] iArr73 = iArr72;
        iArr73[72] = new int[]{1, 2, 2, 4, 1, 1};
        int[][] iArr74 = iArr73;
        iArr74[73] = new int[]{1, 4, 2, 1, 1, 2};
        int[][] iArr75 = iArr74;
        iArr75[74] = new int[]{1, 4, 2, 2, 1, 1};
        int[][] iArr76 = iArr75;
        iArr76[75] = new int[]{2, 4, 1, 2, 1, 1};
        int[][] iArr77 = iArr76;
        iArr77[76] = new int[]{2, 2, 1, 1, 1, 4};
        int[][] iArr78 = iArr77;
        iArr78[77] = new int[]{4, 1, 3, 1, 1, 1};
        int[][] iArr79 = iArr78;
        iArr79[78] = new int[]{2, 4, 1, 1, 1, 2};
        int[][] iArr80 = iArr79;
        iArr80[79] = new int[]{1, 3, 4, 1, 1, 1};
        int[][] iArr81 = iArr80;
        iArr81[80] = new int[]{1, 1, 1, 2, 4, 2};
        int[][] iArr82 = iArr81;
        iArr82[81] = new int[]{1, 2, 1, 1, 4, 2};
        int[][] iArr83 = iArr82;
        iArr83[82] = new int[]{1, 2, 1, 2, 4, 1};
        int[][] iArr84 = iArr83;
        iArr84[83] = new int[]{1, 1, 4, 2, 1, 2};
        int[][] iArr85 = iArr84;
        iArr85[84] = new int[]{1, 2, 4, 1, 1, 2};
        int[][] iArr86 = iArr85;
        iArr86[85] = new int[]{1, 2, 4, 2, 1, 1};
        int[][] iArr87 = iArr86;
        iArr87[86] = new int[]{4, 1, 1, 2, 1, 2};
        int[][] iArr88 = iArr87;
        iArr88[87] = new int[]{4, 2, 1, 1, 1, 2};
        int[][] iArr89 = iArr88;
        iArr89[88] = new int[]{4, 2, 1, 2, 1, 1};
        int[][] iArr90 = iArr89;
        iArr90[89] = new int[]{2, 1, 2, 1, 4, 1};
        int[][] iArr91 = iArr90;
        iArr91[90] = new int[]{2, 1, 4, 1, 2, 1};
        int[][] iArr92 = iArr91;
        iArr92[91] = new int[]{4, 1, 2, 1, 2, 1};
        int[][] iArr93 = iArr92;
        iArr93[92] = new int[]{1, 1, 1, 1, 4, 3};
        int[][] iArr94 = iArr93;
        iArr94[93] = new int[]{1, 1, 1, 3, 4, 1};
        int[][] iArr95 = iArr94;
        iArr95[94] = new int[]{1, 3, 1, 1, 4, 1};
        int[][] iArr96 = iArr95;
        iArr96[95] = new int[]{1, 1, 4, 1, 1, 3};
        int[][] iArr97 = iArr96;
        iArr97[CODE_FNC_3] = new int[]{1, 1, 4, 3, 1, 1};
        int[][] iArr98 = iArr97;
        iArr98[CODE_FNC_2] = new int[]{4, 1, 1, 1, 1, 3};
        int[][] iArr99 = iArr98;
        iArr99[CODE_SHIFT] = new int[]{4, 1, 1, 3, 1, 1};
        int[][] iArr100 = iArr99;
        iArr100[CODE_CODE_C] = new int[]{1, 1, 3, 1, 4, 1};
        int[][] iArr101 = iArr100;
        iArr101[100] = new int[]{1, 1, 4, 1, 3, 1};
        int[][] iArr102 = iArr101;
        iArr102[101] = new int[]{3, 1, 1, 1, 4, 1};
        int[][] iArr103 = iArr102;
        iArr103[CODE_FNC_1] = new int[]{4, 1, 1, 1, 3, 1};
        int[][] iArr104 = iArr103;
        iArr104[CODE_START_A] = new int[]{2, 1, 1, 4, 1, 2};
        int[][] iArr105 = iArr104;
        iArr105[CODE_START_B] = new int[]{2, 1, 1, 2, 1, 4};
        int[][] iArr106 = iArr105;
        iArr106[CODE_START_C] = new int[]{2, 1, 1, 2, 3, 2};
        int[][] iArr107 = iArr106;
        iArr107[CODE_STOP] = new int[]{2, 3, 3, 1, 1, 1, 2};
        CODE_PATTERNS = iArr107;
    }

    private static int[] findStartPattern(BitArray bitArray) throws NotFoundException {
        BitArray row = bitArray;
        int width = row.getSize();
        int rowOffset = row.getNextSet(0);
        int counterPosition = 0;
        int[] counters = new int[6];
        int patternStart = rowOffset;
        boolean isWhite = false;
        int patternLength = counters.length;
        for (int i = rowOffset; i < width; i++) {
            if (row.get(i) ^ isWhite) {
                int[] iArr = counters;
                int i2 = counterPosition;
                iArr[i2] = iArr[i2] + 1;
            } else {
                if (counterPosition == patternLength - 1) {
                    int bestVariance = 64;
                    int bestMatch = -1;
                    for (int startCode = CODE_START_A; startCode <= CODE_START_C; startCode++) {
                        int variance = patternMatchVariance(counters, CODE_PATTERNS[startCode], MAX_INDIVIDUAL_VARIANCE);
                        if (variance < bestVariance) {
                            bestVariance = variance;
                            bestMatch = startCode;
                        }
                    }
                    if (bestMatch < 0 || !row.isRange(Math.max(0, patternStart - ((i - patternStart) / 2)), patternStart, false)) {
                        patternStart += counters[0] + counters[1];
                        System.arraycopy(counters, 2, counters, 0, patternLength - 2);
                        counters[patternLength - 2] = 0;
                        counters[patternLength - 1] = 0;
                        counterPosition--;
                    } else {
                        int[] iArr2 = new int[3];
                        iArr2[0] = patternStart;
                        int[] iArr3 = iArr2;
                        iArr3[1] = i;
                        int[] iArr4 = iArr3;
                        iArr4[2] = bestMatch;
                        return iArr4;
                    }
                } else {
                    counterPosition++;
                }
                counters[counterPosition] = 1;
                isWhite = !isWhite;
            }
        }
        throw NotFoundException.getNotFoundInstance();
    }

    private static int decodeCode(BitArray row, int[] iArr, int rowOffset) throws NotFoundException {
        int[] counters = iArr;
        recordPattern(row, rowOffset, counters);
        int bestVariance = 64;
        int bestMatch = -1;
        for (int d = 0; d < CODE_PATTERNS.length; d++) {
            int variance = patternMatchVariance(counters, CODE_PATTERNS[d], MAX_INDIVIDUAL_VARIANCE);
            if (variance < bestVariance) {
                bestVariance = variance;
                bestMatch = d;
            }
        }
        if (bestMatch >= 0) {
            return bestMatch;
        }
        throw NotFoundException.getNotFoundInstance();
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.google.zxing.Result decodeRow(int r40, com.google.zxing.common.BitArray r41, java.util.Map<com.google.zxing.DecodeHintType, ?> r42) throws com.google.zxing.NotFoundException, com.google.zxing.FormatException, com.google.zxing.ChecksumException {
        /*
            r39 = this;
            r2 = r39
            r3 = r40
            r4 = r41
            r5 = r42
            r27 = r4
            int[] r27 = findStartPattern(r27)
            r6 = r27
            r27 = r6
            r28 = 2
            r27 = r27[r28]
            r7 = r27
            r27 = r7
            switch(r27) {
                case 103: goto L_0x0022;
                case 104: goto L_0x00ff;
                case 105: goto L_0x0105;
                default: goto L_0x001d;
            }
        L_0x001d:
            com.google.zxing.FormatException r27 = com.google.zxing.FormatException.getFormatInstance()
            throw r27
        L_0x0022:
            r27 = 101(0x65, float:1.42E-43)
            r8 = r27
        L_0x0026:
            r27 = 0
            r9 = r27
            r27 = 0
            r10 = r27
            java.lang.StringBuilder r27 = new java.lang.StringBuilder
            r38 = r27
            r27 = r38
            r28 = r38
            r29 = 20
            r28.<init>(r29)
            r11 = r27
            java.util.ArrayList r27 = new java.util.ArrayList
            r38 = r27
            r27 = r38
            r28 = r38
            r29 = 20
            r28.<init>(r29)
            r12 = r27
            r27 = r6
            r28 = 0
            r27 = r27[r28]
            r13 = r27
            r27 = r6
            r28 = 1
            r27 = r27[r28]
            r14 = r27
            r27 = 6
            r0 = r27
            int[] r0 = new int[r0]
            r27 = r0
            r15 = r27
            r27 = 0
            r16 = r27
            r27 = 0
            r17 = r27
            r27 = r7
            r18 = r27
            r27 = 0
            r19 = r27
            r27 = 1
            r20 = r27
        L_0x007a:
            r27 = r9
            if (r27 != 0) goto L_0x0231
            r27 = r10
            r21 = r27
            r27 = 0
            r10 = r27
            r27 = r17
            r16 = r27
            r27 = r4
            r28 = r15
            r29 = r14
            int r27 = decodeCode(r27, r28, r29)
            r17 = r27
            r27 = r12
            r28 = r17
            r0 = r28
            byte r0 = (byte) r0
            r28 = r0
            java.lang.Byte r28 = java.lang.Byte.valueOf(r28)
            boolean r27 = r27.add(r28)
            r27 = r17
            r28 = 106(0x6a, float:1.49E-43)
            r0 = r27
            r1 = r28
            if (r0 == r1) goto L_0x00b5
            r27 = 1
            r20 = r27
        L_0x00b5:
            r27 = r17
            r28 = 106(0x6a, float:1.49E-43)
            r0 = r27
            r1 = r28
            if (r0 == r1) goto L_0x00cd
            int r19 = r19 + 1
            r27 = r18
            r28 = r19
            r29 = r17
            int r28 = r28 * r29
            int r27 = r27 + r28
            r18 = r27
        L_0x00cd:
            r27 = r14
            r13 = r27
            r27 = r15
            r22 = r27
            r27 = r22
            r0 = r27
            int r0 = r0.length
            r27 = r0
            r23 = r27
            r27 = 0
            r24 = r27
        L_0x00e2:
            r27 = r24
            r28 = r23
            r0 = r27
            r1 = r28
            if (r0 >= r1) goto L_0x010b
            r27 = r22
            r28 = r24
            r27 = r27[r28]
            r25 = r27
            r27 = r14
            r28 = r25
            int r27 = r27 + r28
            r14 = r27
            int r24 = r24 + 1
            goto L_0x00e2
        L_0x00ff:
            r27 = 100
            r8 = r27
            goto L_0x0026
        L_0x0105:
            r27 = 99
            r8 = r27
            goto L_0x0026
        L_0x010b:
            r27 = r17
            switch(r27) {
                case 103: goto L_0x0129;
                case 104: goto L_0x0129;
                case 105: goto L_0x0129;
                default: goto L_0x0110;
            }
        L_0x0110:
            r27 = r8
            switch(r27) {
                case 99: goto L_0x01de;
                case 100: goto L_0x0193;
                case 101: goto L_0x012e;
                default: goto L_0x0115;
            }
        L_0x0115:
            r27 = r21
            if (r27 == 0) goto L_0x0127
            r27 = r8
            r28 = 101(0x65, float:1.42E-43)
            r0 = r27
            r1 = r28
            if (r0 != r1) goto L_0x022d
            r27 = 100
        L_0x0125:
            r8 = r27
        L_0x0127:
            goto L_0x007a
        L_0x0129:
            com.google.zxing.FormatException r27 = com.google.zxing.FormatException.getFormatInstance()
            throw r27
        L_0x012e:
            r27 = r17
            r28 = 64
            r0 = r27
            r1 = r28
            if (r0 >= r1) goto L_0x014a
            r27 = r11
            r28 = 32
            r29 = r17
            int r28 = r28 + r29
            r0 = r28
            char r0 = (char) r0
            r28 = r0
            java.lang.StringBuilder r27 = r27.append(r28)
            goto L_0x0115
        L_0x014a:
            r27 = r17
            r28 = 96
            r0 = r27
            r1 = r28
            if (r0 >= r1) goto L_0x0166
            r27 = r11
            r28 = r17
            r29 = 64
            int r28 = r28 + -64
            r0 = r28
            char r0 = (char) r0
            r28 = r0
            java.lang.StringBuilder r27 = r27.append(r28)
            goto L_0x0115
        L_0x0166:
            r27 = r17
            r28 = 106(0x6a, float:1.49E-43)
            r0 = r27
            r1 = r28
            if (r0 == r1) goto L_0x0174
            r27 = 0
            r20 = r27
        L_0x0174:
            r27 = r17
            switch(r27) {
                case 96: goto L_0x017a;
                case 97: goto L_0x017a;
                case 98: goto L_0x017b;
                case 99: goto L_0x0189;
                case 100: goto L_0x0184;
                case 101: goto L_0x017a;
                case 102: goto L_0x017a;
                case 103: goto L_0x0179;
                case 104: goto L_0x0179;
                case 105: goto L_0x0179;
                case 106: goto L_0x018e;
                default: goto L_0x0179;
            }
        L_0x0179:
            goto L_0x0115
        L_0x017a:
            goto L_0x0179
        L_0x017b:
            r27 = 1
            r10 = r27
            r27 = 100
            r8 = r27
            goto L_0x0179
        L_0x0184:
            r27 = 100
            r8 = r27
            goto L_0x0179
        L_0x0189:
            r27 = 99
            r8 = r27
            goto L_0x0179
        L_0x018e:
            r27 = 1
            r9 = r27
            goto L_0x0179
        L_0x0193:
            r27 = r17
            r28 = 96
            r0 = r27
            r1 = r28
            if (r0 >= r1) goto L_0x01b0
            r27 = r11
            r28 = 32
            r29 = r17
            int r28 = r28 + r29
            r0 = r28
            char r0 = (char) r0
            r28 = r0
            java.lang.StringBuilder r27 = r27.append(r28)
            goto L_0x0115
        L_0x01b0:
            r27 = r17
            r28 = 106(0x6a, float:1.49E-43)
            r0 = r27
            r1 = r28
            if (r0 == r1) goto L_0x01be
            r27 = 0
            r20 = r27
        L_0x01be:
            r27 = r17
            switch(r27) {
                case 96: goto L_0x01c5;
                case 97: goto L_0x01c5;
                case 98: goto L_0x01c6;
                case 99: goto L_0x01d4;
                case 100: goto L_0x01c5;
                case 101: goto L_0x01cf;
                case 102: goto L_0x01c5;
                case 103: goto L_0x01c3;
                case 104: goto L_0x01c3;
                case 105: goto L_0x01c3;
                case 106: goto L_0x01d9;
                default: goto L_0x01c3;
            }
        L_0x01c3:
            goto L_0x0115
        L_0x01c5:
            goto L_0x01c3
        L_0x01c6:
            r27 = 1
            r10 = r27
            r27 = 101(0x65, float:1.42E-43)
            r8 = r27
            goto L_0x01c3
        L_0x01cf:
            r27 = 101(0x65, float:1.42E-43)
            r8 = r27
            goto L_0x01c3
        L_0x01d4:
            r27 = 99
            r8 = r27
            goto L_0x01c3
        L_0x01d9:
            r27 = 1
            r9 = r27
            goto L_0x01c3
        L_0x01de:
            r27 = r17
            r28 = 100
            r0 = r27
            r1 = r28
            if (r0 >= r1) goto L_0x0204
            r27 = r17
            r28 = 10
            r0 = r27
            r1 = r28
            if (r0 >= r1) goto L_0x01fa
            r27 = r11
            r28 = 48
            java.lang.StringBuilder r27 = r27.append(r28)
        L_0x01fa:
            r27 = r11
            r28 = r17
            java.lang.StringBuilder r27 = r27.append(r28)
            goto L_0x0115
        L_0x0204:
            r27 = r17
            r28 = 106(0x6a, float:1.49E-43)
            r0 = r27
            r1 = r28
            if (r0 == r1) goto L_0x0212
            r27 = 0
            r20 = r27
        L_0x0212:
            r27 = r17
            switch(r27) {
                case 100: goto L_0x0219;
                case 101: goto L_0x0221;
                case 102: goto L_0x021f;
                case 103: goto L_0x0217;
                case 104: goto L_0x0217;
                case 105: goto L_0x0217;
                case 106: goto L_0x0227;
                default: goto L_0x0217;
            }
        L_0x0217:
            goto L_0x0115
        L_0x0219:
            r27 = 100
            r8 = r27
            goto L_0x0115
        L_0x021f:
            goto L_0x0115
        L_0x0221:
            r27 = 101(0x65, float:1.42E-43)
            r8 = r27
            goto L_0x0115
        L_0x0227:
            r27 = 1
            r9 = r27
            goto L_0x0115
        L_0x022d:
            r27 = 101(0x65, float:1.42E-43)
            goto L_0x0125
        L_0x0231:
            r27 = r4
            r28 = r14
            int r27 = r27.getNextUnset(r28)
            r14 = r27
            r27 = r4
            r28 = r14
            r29 = r4
            int r29 = r29.getSize()
            r30 = r14
            r31 = r14
            r32 = r13
            int r31 = r31 - r32
            r32 = 2
            int r31 = r31 / 2
            int r30 = r30 + r31
            int r29 = java.lang.Math.min(r29, r30)
            r30 = 0
            boolean r27 = r27.isRange(r28, r29, r30)
            if (r27 != 0) goto L_0x0264
            com.google.zxing.NotFoundException r27 = com.google.zxing.NotFoundException.getNotFoundInstance()
            throw r27
        L_0x0264:
            r27 = r18
            r28 = r19
            r29 = r16
            int r28 = r28 * r29
            int r27 = r27 - r28
            r18 = r27
            r27 = r18
            r28 = 103(0x67, float:1.44E-43)
            int r27 = r27 % 103
            r28 = r16
            r0 = r27
            r1 = r28
            if (r0 == r1) goto L_0x0283
            com.google.zxing.ChecksumException r27 = com.google.zxing.ChecksumException.getChecksumInstance()
            throw r27
        L_0x0283:
            r27 = r11
            int r27 = r27.length()
            r21 = r27
            r27 = r21
            if (r27 != 0) goto L_0x0294
            com.google.zxing.NotFoundException r27 = com.google.zxing.NotFoundException.getNotFoundInstance()
            throw r27
        L_0x0294:
            r27 = r21
            if (r27 <= 0) goto L_0x02b4
            r27 = r20
            if (r27 == 0) goto L_0x02b4
            r27 = r8
            r28 = 99
            r0 = r27
            r1 = r28
            if (r0 != r1) goto L_0x0315
            r27 = r11
            r28 = r21
            r29 = 2
            int r28 = r28 + -2
            r29 = r21
            java.lang.StringBuilder r27 = r27.delete(r28, r29)
        L_0x02b4:
            r27 = r6
            r28 = 1
            r27 = r27[r28]
            r28 = r6
            r29 = 0
            r28 = r28[r29]
            int r27 = r27 + r28
            r0 = r27
            float r0 = (float) r0
            r27 = r0
            r28 = 1073741824(0x40000000, float:2.0)
            float r27 = r27 / r28
            r22 = r27
            r27 = r14
            r28 = r13
            int r27 = r27 + r28
            r0 = r27
            float r0 = (float) r0
            r27 = r0
            r28 = 1073741824(0x40000000, float:2.0)
            float r27 = r27 / r28
            r23 = r27
            r27 = r12
            int r27 = r27.size()
            r24 = r27
            r27 = r24
            r0 = r27
            byte[] r0 = new byte[r0]
            r27 = r0
            r25 = r27
            r27 = 0
            r26 = r27
        L_0x02f4:
            r27 = r26
            r28 = r24
            r0 = r27
            r1 = r28
            if (r0 >= r1) goto L_0x0324
            r27 = r25
            r28 = r26
            r29 = r12
            r30 = r26
            java.lang.Object r29 = r29.get(r30)
            java.lang.Byte r29 = (java.lang.Byte) r29
            byte r29 = r29.byteValue()
            r27[r28] = r29
            int r26 = r26 + 1
            goto L_0x02f4
        L_0x0315:
            r27 = r11
            r28 = r21
            r29 = 1
            int r28 = r28 + -1
            r29 = r21
            java.lang.StringBuilder r27 = r27.delete(r28, r29)
            goto L_0x02b4
        L_0x0324:
            com.google.zxing.Result r27 = new com.google.zxing.Result
            r38 = r27
            r27 = r38
            r28 = r38
            r29 = r11
            java.lang.String r29 = r29.toString()
            r30 = r25
            r31 = 2
            r0 = r31
            com.google.zxing.ResultPoint[] r0 = new com.google.zxing.ResultPoint[r0]
            r31 = r0
            r38 = r31
            r31 = r38
            r32 = r38
            r33 = 0
            com.google.zxing.ResultPoint r34 = new com.google.zxing.ResultPoint
            r38 = r34
            r34 = r38
            r35 = r38
            r36 = r22
            r37 = r3
            r0 = r37
            float r0 = (float) r0
            r37 = r0
            r35.<init>(r36, r37)
            r32[r33] = r34
            r38 = r31
            r31 = r38
            r32 = r38
            r33 = 1
            com.google.zxing.ResultPoint r34 = new com.google.zxing.ResultPoint
            r38 = r34
            r34 = r38
            r35 = r38
            r36 = r23
            r37 = r3
            r0 = r37
            float r0 = (float) r0
            r37 = r0
            r35.<init>(r36, r37)
            r32[r33] = r34
            com.google.zxing.BarcodeFormat r32 = com.google.zxing.BarcodeFormat.CODE_128
            r28.<init>(r29, r30, r31, r32)
            r2 = r27
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.oned.Code128Reader.decodeRow(int, com.google.zxing.common.BitArray, java.util.Map):com.google.zxing.Result");
    }
}
