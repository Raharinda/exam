package com.google.zxing.oned.rss.expanded.decoders;

import com.google.zxing.NotFoundException;
import com.google.zxing.common.BitArray;

final class AI013x0x1xDecoder extends AI01weightDecoder {
    private static final int DATE_SIZE = 16;
    private static final int HEADER_SIZE = 8;
    private static final int WEIGHT_SIZE = 20;
    private final String dateCode;
    private final String firstAIdigits;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    AI013x0x1xDecoder(BitArray information, String firstAIdigits2, String dateCode2) {
        super(information);
        this.dateCode = dateCode2;
        this.firstAIdigits = firstAIdigits2;
    }

    public String parseInformation() throws NotFoundException {
        StringBuilder sb;
        if (getInformation().getSize() != 84) {
            throw NotFoundException.getNotFoundInstance();
        }
        new StringBuilder();
        StringBuilder buf = sb;
        encodeCompressedGtin(buf, 8);
        encodeCompressedWeight(buf, 48, 20);
        encodeCompressedDate(buf, 68);
        return buf.toString();
    }

    private void encodeCompressedDate(StringBuilder sb, int currentPos) {
        StringBuilder buf = sb;
        int numericDate = getGeneralDecoder().extractNumericValueFromBitArray(currentPos, 16);
        if (numericDate != 38400) {
            StringBuilder append = buf.append('(');
            StringBuilder append2 = buf.append(this.dateCode);
            StringBuilder append3 = buf.append(')');
            int day = numericDate % 32;
            int numericDate2 = numericDate / 32;
            int month = (numericDate2 % 12) + 1;
            int year = numericDate2 / 12;
            if (year / 10 == 0) {
                StringBuilder append4 = buf.append('0');
            }
            StringBuilder append5 = buf.append(year);
            if (month / 10 == 0) {
                StringBuilder append6 = buf.append('0');
            }
            StringBuilder append7 = buf.append(month);
            if (day / 10 == 0) {
                StringBuilder append8 = buf.append('0');
            }
            StringBuilder append9 = buf.append(day);
        }
    }

    /* access modifiers changed from: protected */
    public void addWeightCode(StringBuilder sb, int weight) {
        StringBuilder buf = sb;
        StringBuilder append = buf.append('(');
        StringBuilder append2 = buf.append(this.firstAIdigits);
        StringBuilder append3 = buf.append(weight / 100000);
        StringBuilder append4 = buf.append(')');
    }

    /* access modifiers changed from: protected */
    public int checkWeight(int weight) {
        return weight % 100000;
    }
}
