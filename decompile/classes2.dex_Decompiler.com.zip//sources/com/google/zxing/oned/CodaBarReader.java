package com.google.zxing.oned;

import com.google.zxing.NotFoundException;
import com.google.zxing.common.BitArray;

public final class CodaBarReader extends OneDReader {
    static final char[] ALPHABET = ALPHABET_STRING.toCharArray();
    private static final String ALPHABET_STRING = "0123456789-$:/.+ABCD";
    static final int[] CHARACTER_ENCODINGS = {3, 6, 9, 96, 18, 66, 33, 36, 48, 72, 12, 24, 69, 81, 84, 21, 26, 41, 11, 14};
    private static final int MAX_ACCEPTABLE = 512;
    private static final int MIN_CHARACTER_LENGTH = 3;
    private static final int PADDING = 384;
    private static final char[] STARTEND_ENCODING = {'A', 'B', 'C', 'D'};
    private int counterLength = 0;
    private int[] counters = new int[80];
    private final StringBuilder decodeRowResult;

    public CodaBarReader() {
        StringBuilder sb;
        new StringBuilder(20);
        this.decodeRowResult = sb;
    }

    /* JADX WARNING: Removed duplicated region for block: B:47:0x0027 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:5:0x002c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.google.zxing.Result decodeRow(int r27, com.google.zxing.common.BitArray r28, java.util.Map<com.google.zxing.DecodeHintType, ?> r29) throws com.google.zxing.NotFoundException {
        /*
            r26 = this;
            r1 = r26
            r2 = r27
            r3 = r28
            r4 = r29
            r14 = r1
            r15 = r3
            r14.setCounters(r15)
            r14 = r1
            int r14 = r14.findStartPattern()
            r5 = r14
            r14 = r5
            r6 = r14
            r14 = r1
            java.lang.StringBuilder r14 = r14.decodeRowResult
            r15 = 0
            r14.setLength(r15)
        L_0x001c:
            r14 = r1
            r15 = r6
            int r14 = r14.toNarrowWidePattern(r15)
            r7 = r14
            r14 = r7
            r15 = -1
            if (r14 != r15) goto L_0x002c
            com.google.zxing.NotFoundException r14 = com.google.zxing.NotFoundException.getNotFoundInstance()
            throw r14
        L_0x002c:
            r14 = r1
            java.lang.StringBuilder r14 = r14.decodeRowResult
            r15 = r7
            char r15 = (char) r15
            java.lang.StringBuilder r14 = r14.append(r15)
            int r6 = r6 + 8
            r14 = r1
            java.lang.StringBuilder r14 = r14.decodeRowResult
            int r14 = r14.length()
            r15 = 1
            if (r14 <= r15) goto L_0x0073
            char[] r14 = STARTEND_ENCODING
            char[] r15 = ALPHABET
            r16 = r7
            char r15 = r15[r16]
            boolean r14 = arrayContains(r14, r15)
            if (r14 == 0) goto L_0x0073
        L_0x004f:
            r14 = r1
            int[] r14 = r14.counters
            r15 = r6
            r16 = 1
            int r15 = r15 + -1
            r14 = r14[r15]
            r7 = r14
            r14 = 0
            r8 = r14
            r14 = -8
            r9 = r14
        L_0x005e:
            r14 = r9
            r15 = -1
            if (r14 >= r15) goto L_0x007a
            r14 = r8
            r15 = r1
            int[] r15 = r15.counters
            r16 = r6
            r17 = r9
            int r16 = r16 + r17
            r15 = r15[r16]
            int r14 = r14 + r15
            r8 = r14
            int r9 = r9 + 1
            goto L_0x005e
        L_0x0073:
            r14 = r6
            r15 = r1
            int r15 = r15.counterLength
            if (r14 < r15) goto L_0x001c
            goto L_0x004f
        L_0x007a:
            r14 = r6
            r15 = r1
            int r15 = r15.counterLength
            if (r14 >= r15) goto L_0x008d
            r14 = r7
            r15 = r8
            r16 = 2
            int r15 = r15 / 2
            if (r14 >= r15) goto L_0x008d
            com.google.zxing.NotFoundException r14 = com.google.zxing.NotFoundException.getNotFoundInstance()
            throw r14
        L_0x008d:
            r14 = r1
            r15 = r5
            r14.validatePattern(r15)
            r14 = 0
            r9 = r14
        L_0x0094:
            r14 = r9
            r15 = r1
            java.lang.StringBuilder r15 = r15.decodeRowResult
            int r15 = r15.length()
            if (r14 >= r15) goto L_0x00ba
            r14 = r1
            java.lang.StringBuilder r14 = r14.decodeRowResult
            r15 = r9
            char[] r16 = ALPHABET
            r17 = r1
            r0 = r17
            java.lang.StringBuilder r0 = r0.decodeRowResult
            r17 = r0
            r18 = r9
            char r17 = r17.charAt(r18)
            char r16 = r16[r17]
            r14.setCharAt(r15, r16)
            int r9 = r9 + 1
            goto L_0x0094
        L_0x00ba:
            r14 = r1
            java.lang.StringBuilder r14 = r14.decodeRowResult
            r15 = 0
            char r14 = r14.charAt(r15)
            r9 = r14
            char[] r14 = STARTEND_ENCODING
            r15 = r9
            boolean r14 = arrayContains(r14, r15)
            if (r14 != 0) goto L_0x00d1
            com.google.zxing.NotFoundException r14 = com.google.zxing.NotFoundException.getNotFoundInstance()
            throw r14
        L_0x00d1:
            r14 = r1
            java.lang.StringBuilder r14 = r14.decodeRowResult
            r15 = r1
            java.lang.StringBuilder r15 = r15.decodeRowResult
            int r15 = r15.length()
            r16 = 1
            int r15 = r15 + -1
            char r14 = r14.charAt(r15)
            r10 = r14
            char[] r14 = STARTEND_ENCODING
            r15 = r10
            boolean r14 = arrayContains(r14, r15)
            if (r14 != 0) goto L_0x00f2
            com.google.zxing.NotFoundException r14 = com.google.zxing.NotFoundException.getNotFoundInstance()
            throw r14
        L_0x00f2:
            r14 = r1
            java.lang.StringBuilder r14 = r14.decodeRowResult
            int r14 = r14.length()
            r15 = 3
            if (r14 > r15) goto L_0x0101
            com.google.zxing.NotFoundException r14 = com.google.zxing.NotFoundException.getNotFoundInstance()
            throw r14
        L_0x0101:
            r14 = r1
            java.lang.StringBuilder r14 = r14.decodeRowResult
            r15 = r1
            java.lang.StringBuilder r15 = r15.decodeRowResult
            int r15 = r15.length()
            r16 = 1
            int r15 = r15 + -1
            java.lang.StringBuilder r14 = r14.deleteCharAt(r15)
            r14 = r1
            java.lang.StringBuilder r14 = r14.decodeRowResult
            r15 = 0
            java.lang.StringBuilder r14 = r14.deleteCharAt(r15)
            r14 = 0
            r11 = r14
            r14 = 0
            r12 = r14
        L_0x011f:
            r14 = r12
            r15 = r5
            if (r14 >= r15) goto L_0x0130
            r14 = r11
            r15 = r1
            int[] r15 = r15.counters
            r16 = r12
            r15 = r15[r16]
            int r14 = r14 + r15
            r11 = r14
            int r12 = r12 + 1
            goto L_0x011f
        L_0x0130:
            r14 = r11
            float r14 = (float) r14
            r12 = r14
            r14 = r5
            r13 = r14
        L_0x0135:
            r14 = r13
            r15 = r6
            r16 = 1
            int r15 = r15 + -1
            if (r14 >= r15) goto L_0x014a
            r14 = r11
            r15 = r1
            int[] r15 = r15.counters
            r16 = r13
            r15 = r15[r16]
            int r14 = r14 + r15
            r11 = r14
            int r13 = r13 + 1
            goto L_0x0135
        L_0x014a:
            r14 = r11
            float r14 = (float) r14
            r13 = r14
            com.google.zxing.Result r14 = new com.google.zxing.Result
            r25 = r14
            r14 = r25
            r15 = r25
            r16 = r1
            r0 = r16
            java.lang.StringBuilder r0 = r0.decodeRowResult
            r16 = r0
            java.lang.String r16 = r16.toString()
            r17 = 0
            r18 = 2
            r0 = r18
            com.google.zxing.ResultPoint[] r0 = new com.google.zxing.ResultPoint[r0]
            r18 = r0
            r25 = r18
            r18 = r25
            r19 = r25
            r20 = 0
            com.google.zxing.ResultPoint r21 = new com.google.zxing.ResultPoint
            r25 = r21
            r21 = r25
            r22 = r25
            r23 = r12
            r24 = r2
            r0 = r24
            float r0 = (float) r0
            r24 = r0
            r22.<init>(r23, r24)
            r19[r20] = r21
            r25 = r18
            r18 = r25
            r19 = r25
            r20 = 1
            com.google.zxing.ResultPoint r21 = new com.google.zxing.ResultPoint
            r25 = r21
            r21 = r25
            r22 = r25
            r23 = r13
            r24 = r2
            r0 = r24
            float r0 = (float) r0
            r24 = r0
            r22.<init>(r23, r24)
            r19[r20] = r21
            com.google.zxing.BarcodeFormat r19 = com.google.zxing.BarcodeFormat.CODABAR
            r15.<init>(r16, r17, r18, r19)
            r1 = r14
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.oned.CodaBarReader.decodeRow(int, com.google.zxing.common.BitArray, java.util.Map):com.google.zxing.Result");
    }

    /* access modifiers changed from: package-private */
    public void validatePattern(int i) throws NotFoundException {
        int start = i;
        int[] sizes = {0, 0, 0, 0};
        int[] counts = {0, 0, 0, 0};
        int end = this.decodeRowResult.length() - 1;
        int pos = start;
        int i2 = 0;
        while (true) {
            int pattern = CHARACTER_ENCODINGS[this.decodeRowResult.charAt(i2)];
            for (int j = 6; j >= 0; j--) {
                int category = (j & 1) + ((pattern & 1) * 2);
                int[] iArr = sizes;
                int i3 = category;
                iArr[i3] = iArr[i3] + this.counters[pos + j];
                int[] iArr2 = counts;
                int i4 = category;
                iArr2[i4] = iArr2[i4] + 1;
                pattern >>= 1;
            }
            if (i2 >= end) {
                break;
            }
            pos += 8;
            i2++;
        }
        int[] maxes = new int[4];
        int[] mins = new int[4];
        for (int i5 = 0; i5 < 2; i5++) {
            mins[i5] = 0;
            mins[i5 + 2] = (((sizes[i5] << 8) / counts[i5]) + ((sizes[i5 + 2] << 8) / counts[i5 + 2])) >> 1;
            maxes[i5] = mins[i5 + 2];
            maxes[i5 + 2] = ((sizes[i5 + 2] * MAX_ACCEPTABLE) + PADDING) / counts[i5 + 2];
        }
        int pos2 = start;
        int i6 = 0;
        loop3:
        while (true) {
            int pattern2 = CHARACTER_ENCODINGS[this.decodeRowResult.charAt(i6)];
            int j2 = 6;
            while (j2 >= 0) {
                int category2 = (j2 & 1) + ((pattern2 & 1) * 2);
                int size = this.counters[pos2 + j2] << 8;
                if (size >= mins[category2] && size <= maxes[category2]) {
                    pattern2 >>= 1;
                    j2--;
                }
            }
            if (i6 < end) {
                pos2 += 8;
                i6++;
            } else {
                return;
            }
        }
        throw NotFoundException.getNotFoundInstance();
    }

    private void setCounters(BitArray bitArray) throws NotFoundException {
        BitArray row = bitArray;
        this.counterLength = 0;
        int i = row.getNextUnset(0);
        int end = row.getSize();
        if (i >= end) {
            throw NotFoundException.getNotFoundInstance();
        }
        boolean isWhite = true;
        int count = 0;
        while (i < end) {
            if (row.get(i) ^ isWhite) {
                count++;
            } else {
                counterAppend(count);
                count = 1;
                isWhite = !isWhite;
            }
            i++;
        }
        counterAppend(count);
    }

    private void counterAppend(int e) {
        this.counters[this.counterLength] = e;
        this.counterLength++;
        if (this.counterLength >= this.counters.length) {
            int[] temp = new int[(this.counterLength * 2)];
            System.arraycopy(this.counters, 0, temp, 0, this.counterLength);
            this.counters = temp;
        }
    }

    private int findStartPattern() throws NotFoundException {
        for (int i = 1; i < this.counterLength; i += 2) {
            int charOffset = toNarrowWidePattern(i);
            if (charOffset != -1 && arrayContains(STARTEND_ENCODING, ALPHABET[charOffset])) {
                int patternSize = 0;
                for (int j = i; j < i + 7; j++) {
                    patternSize += this.counters[j];
                }
                if (i == 1 || this.counters[i - 1] >= patternSize / 2) {
                    return i;
                }
            }
        }
        throw NotFoundException.getNotFoundInstance();
    }

    static boolean arrayContains(char[] cArr, char c) {
        char[] array = cArr;
        char key = c;
        if (array != null) {
            char[] arr$ = array;
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                if (arr$[i$] == key) {
                    return true;
                }
            }
        }
        return false;
    }

    private int toNarrowWidePattern(int i) {
        int position = i;
        int end = position + 7;
        if (end >= this.counterLength) {
            return -1;
        }
        int[] maxes = {0, 0};
        int[] mins = {Integer.MAX_VALUE, Integer.MAX_VALUE};
        int[] thresholds = {0, 0};
        for (int i2 = 0; i2 < 2; i2++) {
            for (int j = position + i2; j < end; j += 2) {
                if (this.counters[j] < mins[i2]) {
                    mins[i2] = this.counters[j];
                }
                if (this.counters[j] > maxes[i2]) {
                    maxes[i2] = this.counters[j];
                }
            }
            thresholds[i2] = (mins[i2] + maxes[i2]) / 2;
        }
        int bitmask = 128;
        int pattern = 0;
        for (int i3 = 0; i3 < 7; i3++) {
            bitmask >>= 1;
            if (this.counters[position + i3] > thresholds[i3 & 1]) {
                pattern |= bitmask;
            }
        }
        for (int i4 = 0; i4 < CHARACTER_ENCODINGS.length; i4++) {
            if (CHARACTER_ENCODINGS[i4] == pattern) {
                return i4;
            }
        }
        return -1;
    }
}
