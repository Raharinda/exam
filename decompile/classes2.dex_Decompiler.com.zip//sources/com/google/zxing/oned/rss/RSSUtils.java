package com.google.zxing.oned.rss;

public final class RSSUtils {
    private RSSUtils() {
    }

    static int[] getRSSwidths(int i, int i2, int i3, int i4, boolean z) {
        int subVal;
        int val = i;
        int n = i2;
        int elements = i3;
        int maxWidth = i4;
        boolean noNarrow = z;
        int[] widths = new int[elements];
        int narrowMask = 0;
        int bar = 0;
        while (bar < elements - 1) {
            narrowMask |= 1 << bar;
            int elmWidth = 1;
            while (true) {
                subVal = combins((n - elmWidth) - 1, (elements - bar) - 2);
                if (noNarrow && narrowMask == 0 && (n - elmWidth) - ((elements - bar) - 1) >= (elements - bar) - 1) {
                    subVal -= combins((n - elmWidth) - (elements - bar), (elements - bar) - 2);
                }
                if ((elements - bar) - 1 > 1) {
                    int lessVal = 0;
                    for (int mxwElement = (n - elmWidth) - ((elements - bar) - 2); mxwElement > maxWidth; mxwElement--) {
                        lessVal += combins(((n - elmWidth) - mxwElement) - 1, (elements - bar) - 3);
                    }
                    subVal -= lessVal * ((elements - 1) - bar);
                } else if (n - elmWidth > maxWidth) {
                    subVal--;
                }
                val -= subVal;
                if (val < 0) {
                    break;
                }
                elmWidth++;
                narrowMask &= (1 << bar) ^ -1;
            }
            val += subVal;
            n -= elmWidth;
            widths[bar] = elmWidth;
            bar++;
        }
        widths[bar] = n;
        return widths;
    }

    public static int getRSSvalue(int[] iArr, int i, boolean z) {
        int[] widths = iArr;
        int maxWidth = i;
        boolean noNarrow = z;
        int elements = widths.length;
        int n = 0;
        int[] arr$ = widths;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            n += arr$[i$];
        }
        int val = 0;
        int narrowMask = 0;
        for (int bar = 0; bar < elements - 1; bar++) {
            int elmWidth = 1;
            int i2 = narrowMask | (1 << bar);
            while (true) {
                narrowMask = i2;
                if (elmWidth >= widths[bar]) {
                    break;
                }
                int subVal = combins((n - elmWidth) - 1, (elements - bar) - 2);
                if (noNarrow && narrowMask == 0 && (n - elmWidth) - ((elements - bar) - 1) >= (elements - bar) - 1) {
                    subVal -= combins((n - elmWidth) - (elements - bar), (elements - bar) - 2);
                }
                if ((elements - bar) - 1 > 1) {
                    int lessVal = 0;
                    for (int mxwElement = (n - elmWidth) - ((elements - bar) - 2); mxwElement > maxWidth; mxwElement--) {
                        lessVal += combins(((n - elmWidth) - mxwElement) - 1, (elements - bar) - 3);
                    }
                    subVal -= lessVal * ((elements - 1) - bar);
                } else if (n - elmWidth > maxWidth) {
                    subVal--;
                }
                val += subVal;
                elmWidth++;
                i2 = narrowMask & ((1 << bar) ^ -1);
            }
            n -= elmWidth;
        }
        return val;
    }

    private static int combins(int i, int i2) {
        int minDenom;
        int maxDenom;
        int n = i;
        int r = i2;
        if (n - r > r) {
            minDenom = r;
            maxDenom = n - r;
        } else {
            minDenom = n - r;
            maxDenom = r;
        }
        int val = 1;
        int j = 1;
        for (int i3 = n; i3 > maxDenom; i3--) {
            val *= i3;
            if (j <= minDenom) {
                val /= j;
                j++;
            }
        }
        while (j <= minDenom) {
            val /= j;
            j++;
        }
        return val;
    }

    static int[] elements(int[] iArr, int i, int K) {
        int[] eDist = iArr;
        int N = i;
        int[] widths = new int[(eDist.length + 2)];
        int twoK = K << 1;
        widths[0] = 1;
        int minEven = 10;
        int barSum = 1;
        for (int i2 = 1; i2 < twoK - 2; i2 += 2) {
            widths[i2] = eDist[i2 - 1] - widths[i2 - 1];
            widths[i2 + 1] = eDist[i2] - widths[i2];
            barSum += widths[i2] + widths[i2 + 1];
            if (widths[i2] < minEven) {
                minEven = widths[i2];
            }
        }
        widths[twoK - 1] = N - barSum;
        if (widths[twoK - 1] < minEven) {
            minEven = widths[twoK - 1];
        }
        if (minEven > 1) {
            for (int i3 = 0; i3 < twoK; i3 += 2) {
                int[] iArr2 = widths;
                int i4 = i3;
                iArr2[i4] = iArr2[i4] + (minEven - 1);
                int[] iArr3 = widths;
                int i5 = i3 + 1;
                iArr3[i5] = iArr3[i5] - (minEven - 1);
            }
        }
        return widths;
    }
}
