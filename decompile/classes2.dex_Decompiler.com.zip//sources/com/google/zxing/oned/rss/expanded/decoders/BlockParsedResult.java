package com.google.zxing.oned.rss.expanded.decoders;

final class BlockParsedResult {
    private final DecodedInformation decodedInformation;
    private final boolean finished;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    BlockParsedResult(boolean finished2) {
        this((DecodedInformation) null, finished2);
    }

    BlockParsedResult(DecodedInformation information, boolean finished2) {
        this.finished = finished2;
        this.decodedInformation = information;
    }

    /* access modifiers changed from: package-private */
    public DecodedInformation getDecodedInformation() {
        return this.decodedInformation;
    }

    /* access modifiers changed from: package-private */
    public boolean isFinished() {
        return this.finished;
    }
}
