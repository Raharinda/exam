package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.Writer;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import java.util.Map;

public final class UPCAWriter implements Writer {
    private final EAN13Writer subWriter;

    public UPCAWriter() {
        EAN13Writer eAN13Writer;
        new EAN13Writer();
        this.subWriter = eAN13Writer;
    }

    public BitMatrix encode(String contents, BarcodeFormat format, int width, int height) throws WriterException {
        return encode(contents, format, width, height, (Map<EncodeHintType, ?>) null);
    }

    public BitMatrix encode(String str, BarcodeFormat barcodeFormat, int i, int i2, Map<EncodeHintType, ?> map) throws WriterException {
        Throwable th;
        StringBuilder sb;
        String contents = str;
        BarcodeFormat format = barcodeFormat;
        int width = i;
        int height = i2;
        Map<EncodeHintType, ?> hints = map;
        if (format == BarcodeFormat.UPC_A) {
            return this.subWriter.encode(preencode(contents), BarcodeFormat.EAN_13, width, height, hints);
        }
        Throwable th2 = th;
        new StringBuilder();
        new IllegalArgumentException(sb.append("Can only encode UPC-A, but got ").append(format).toString());
        throw th2;
    }

    private static String preencode(String str) {
        Throwable th;
        StringBuilder sb;
        StringBuilder sb2;
        StringBuilder sb3;
        String contents = str;
        int length = contents.length();
        if (length == 11) {
            int sum = 0;
            for (int i = 0; i < 11; i++) {
                sum += (contents.charAt(i) - '0') * (i % 2 == 0 ? 3 : 1);
            }
            new StringBuilder();
            contents = sb3.append(contents).append((1000 - sum) % 10).toString();
        } else if (length != 12) {
            Throwable th2 = th;
            new StringBuilder();
            new IllegalArgumentException(sb.append("Requested contents should be 11 or 12 digits long, but got ").append(contents.length()).toString());
            throw th2;
        }
        new StringBuilder();
        return sb2.append('0').append(contents).toString();
    }
}
