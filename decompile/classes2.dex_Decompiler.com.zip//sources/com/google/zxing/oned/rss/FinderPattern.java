package com.google.zxing.oned.rss;

import com.google.zxing.ResultPoint;

public final class FinderPattern {
    private final ResultPoint[] resultPoints;
    private final int[] startEnd;
    private final int value;

    public FinderPattern(int value2, int[] startEnd2, int start, int end, int i) {
        ResultPoint resultPoint;
        ResultPoint resultPoint2;
        int rowNumber = i;
        this.value = value2;
        this.startEnd = startEnd2;
        ResultPoint[] resultPointArr = new ResultPoint[2];
        new ResultPoint((float) start, (float) rowNumber);
        resultPointArr[0] = resultPoint;
        ResultPoint[] resultPointArr2 = resultPointArr;
        new ResultPoint((float) end, (float) rowNumber);
        resultPointArr2[1] = resultPoint2;
        this.resultPoints = resultPointArr2;
    }

    public int getValue() {
        return this.value;
    }

    public int[] getStartEnd() {
        return this.startEnd;
    }

    public ResultPoint[] getResultPoints() {
        return this.resultPoints;
    }
}
