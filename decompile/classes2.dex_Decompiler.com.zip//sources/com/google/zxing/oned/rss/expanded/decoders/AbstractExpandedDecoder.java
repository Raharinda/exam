package com.google.zxing.oned.rss.expanded.decoders;

import com.google.zxing.NotFoundException;
import com.google.zxing.common.BitArray;
import org.jose4j.jwt.consumer.ErrorCodes;

public abstract class AbstractExpandedDecoder {
    private final GeneralAppIdDecoder generalDecoder;
    private final BitArray information;

    public abstract String parseInformation() throws NotFoundException;

    AbstractExpandedDecoder(BitArray bitArray) {
        GeneralAppIdDecoder generalAppIdDecoder;
        BitArray information2 = bitArray;
        this.information = information2;
        new GeneralAppIdDecoder(information2);
        this.generalDecoder = generalAppIdDecoder;
    }

    /* access modifiers changed from: protected */
    public final BitArray getInformation() {
        return this.information;
    }

    /* access modifiers changed from: protected */
    public final GeneralAppIdDecoder getGeneralDecoder() {
        return this.generalDecoder;
    }

    public static AbstractExpandedDecoder createDecoder(BitArray bitArray) {
        AbstractExpandedDecoder abstractExpandedDecoder;
        AbstractExpandedDecoder abstractExpandedDecoder2;
        AbstractExpandedDecoder abstractExpandedDecoder3;
        AbstractExpandedDecoder abstractExpandedDecoder4;
        AbstractExpandedDecoder abstractExpandedDecoder5;
        AbstractExpandedDecoder abstractExpandedDecoder6;
        AbstractExpandedDecoder abstractExpandedDecoder7;
        AbstractExpandedDecoder abstractExpandedDecoder8;
        AbstractExpandedDecoder abstractExpandedDecoder9;
        AbstractExpandedDecoder abstractExpandedDecoder10;
        AbstractExpandedDecoder abstractExpandedDecoder11;
        AbstractExpandedDecoder abstractExpandedDecoder12;
        Throwable th;
        StringBuilder sb;
        AbstractExpandedDecoder abstractExpandedDecoder13;
        AbstractExpandedDecoder abstractExpandedDecoder14;
        BitArray information2 = bitArray;
        if (information2.get(1)) {
            new AI01AndOtherAIs(information2);
            return abstractExpandedDecoder14;
        } else if (!information2.get(2)) {
            new AnyAIDecoder(information2);
            return abstractExpandedDecoder13;
        } else {
            switch (GeneralAppIdDecoder.extractNumericValueFromBitArray(information2, 1, 4)) {
                case 4:
                    new AI013103decoder(information2);
                    return abstractExpandedDecoder2;
                case 5:
                    new AI01320xDecoder(information2);
                    return abstractExpandedDecoder;
                default:
                    switch (GeneralAppIdDecoder.extractNumericValueFromBitArray(information2, 1, 5)) {
                        case ErrorCodes.ISSUER_INVALID /*12*/:
                            new AI01392xDecoder(information2);
                            return abstractExpandedDecoder4;
                        case ErrorCodes.JWT_ID_MISSING /*13*/:
                            new AI01393xDecoder(information2);
                            return abstractExpandedDecoder3;
                        default:
                            switch (GeneralAppIdDecoder.extractNumericValueFromBitArray(information2, 1, 7)) {
                                case 56:
                                    new AI013x0x1xDecoder(information2, "310", "11");
                                    return abstractExpandedDecoder12;
                                case 57:
                                    new AI013x0x1xDecoder(information2, "320", "11");
                                    return abstractExpandedDecoder11;
                                case 58:
                                    new AI013x0x1xDecoder(information2, "310", "13");
                                    return abstractExpandedDecoder10;
                                case 59:
                                    new AI013x0x1xDecoder(information2, "320", "13");
                                    return abstractExpandedDecoder9;
                                case 60:
                                    new AI013x0x1xDecoder(information2, "310", "15");
                                    return abstractExpandedDecoder8;
                                case 61:
                                    new AI013x0x1xDecoder(information2, "320", "15");
                                    return abstractExpandedDecoder7;
                                case 62:
                                    new AI013x0x1xDecoder(information2, "310", "17");
                                    return abstractExpandedDecoder6;
                                case 63:
                                    new AI013x0x1xDecoder(information2, "320", "17");
                                    return abstractExpandedDecoder5;
                                default:
                                    Throwable th2 = th;
                                    new StringBuilder();
                                    new IllegalStateException(sb.append("unknown decoder: ").append(information2).toString());
                                    throw th2;
                            }
                    }
            }
        }
    }
}
