package com.google.zxing.oned.rss.expanded.decoders;

final class DecodedChar extends DecodedObject {
    static final char FNC1 = '$';
    private final char value;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    DecodedChar(int newPosition, char value2) {
        super(newPosition);
        this.value = value2;
    }

    /* access modifiers changed from: package-private */
    public char getValue() {
        return this.value;
    }

    /* access modifiers changed from: package-private */
    public boolean isFNC1() {
        return this.value == '$';
    }
}
