package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.Writer;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import java.util.Map;

public abstract class OneDimensionalCodeWriter implements Writer {
    public abstract boolean[] encode(String str);

    public OneDimensionalCodeWriter() {
    }

    public BitMatrix encode(String contents, BarcodeFormat format, int width, int height) throws WriterException {
        return encode(contents, format, width, height, (Map<EncodeHintType, ?>) null);
    }

    public BitMatrix encode(String str, BarcodeFormat barcodeFormat, int i, int i2, Map<EncodeHintType, ?> map) throws WriterException {
        Throwable th;
        StringBuilder sb;
        Integer sidesMarginInt;
        Throwable th2;
        String contents = str;
        BarcodeFormat barcodeFormat2 = barcodeFormat;
        int width = i;
        int height = i2;
        Map<EncodeHintType, ?> hints = map;
        if (contents.length() == 0) {
            Throwable th3 = th2;
            new IllegalArgumentException("Found empty contents");
            throw th3;
        } else if (width < 0 || height < 0) {
            Throwable th4 = th;
            new StringBuilder();
            new IllegalArgumentException(sb.append("Negative size is not allowed. Input: ").append(width).append('x').append(height).toString());
            throw th4;
        } else {
            int sidesMargin = getDefaultMargin();
            if (!(hints == null || (sidesMarginInt = (Integer) hints.get(EncodeHintType.MARGIN)) == null)) {
                sidesMargin = sidesMarginInt.intValue();
            }
            return renderResult(encode(contents), width, height, sidesMargin);
        }
    }

    private static BitMatrix renderResult(boolean[] zArr, int width, int height, int sidesMargin) {
        BitMatrix bitMatrix;
        boolean[] code = zArr;
        int inputWidth = code.length;
        int fullWidth = inputWidth + sidesMargin;
        int outputWidth = Math.max(width, fullWidth);
        int outputHeight = Math.max(1, height);
        int multiple = outputWidth / fullWidth;
        new BitMatrix(outputWidth, outputHeight);
        BitMatrix output = bitMatrix;
        int inputX = 0;
        int i = (outputWidth - (inputWidth * multiple)) / 2;
        while (true) {
            int outputX = i;
            if (inputX >= inputWidth) {
                return output;
            }
            if (code[inputX]) {
                output.setRegion(outputX, 0, multiple, outputHeight);
            }
            inputX++;
            i = outputX + multiple;
        }
    }

    protected static int appendPattern(boolean[] zArr, int i, int[] pattern, boolean startColor) {
        boolean z;
        boolean[] target = zArr;
        int pos = i;
        boolean color = startColor;
        int numAdded = 0;
        int[] arr$ = pattern;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            int len = arr$[i$];
            for (int j = 0; j < len; j++) {
                int i2 = pos;
                pos++;
                target[i2] = color;
            }
            numAdded += len;
            if (!color) {
                z = true;
            } else {
                z = false;
            }
            color = z;
        }
        return numAdded;
    }

    public int getDefaultMargin() {
        return 10;
    }
}
