package com.google.zxing.oned.rss.expanded.decoders;

import com.google.zxing.common.BitArray;

final class AI01320xDecoder extends AI013x0xDecoder {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    AI01320xDecoder(BitArray information) {
        super(information);
    }

    /* access modifiers changed from: protected */
    public void addWeightCode(StringBuilder sb, int weight) {
        StringBuilder buf = sb;
        if (weight < 10000) {
            StringBuilder append = buf.append("(3202)");
        } else {
            StringBuilder append2 = buf.append("(3203)");
        }
    }

    /* access modifiers changed from: protected */
    public int checkWeight(int i) {
        int weight = i;
        if (weight < 10000) {
            return weight;
        }
        return weight - 10000;
    }
}
