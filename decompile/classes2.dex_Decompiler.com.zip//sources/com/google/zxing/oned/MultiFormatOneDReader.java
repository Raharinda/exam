package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.DecodeHintType;
import com.google.zxing.NotFoundException;
import com.google.zxing.Reader;
import com.google.zxing.ReaderException;
import com.google.zxing.Result;
import com.google.zxing.common.BitArray;
import com.google.zxing.oned.rss.RSS14Reader;
import com.google.zxing.oned.rss.expanded.RSSExpandedReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

public final class MultiFormatOneDReader extends OneDReader {
    private final OneDReader[] readers;

    public MultiFormatOneDReader(Map<DecodeHintType, ?> map) {
        Collection<OneDReader> collection;
        Object obj;
        Object obj2;
        Object obj3;
        Object obj4;
        Object obj5;
        Object obj6;
        Object obj7;
        Object obj8;
        Object obj9;
        Object obj10;
        Object obj11;
        Object obj12;
        Object obj13;
        Object obj14;
        Object obj15;
        Object obj16;
        Map<DecodeHintType, ?> hints = map;
        Collection<BarcodeFormat> possibleFormats = hints == null ? null : (Collection) hints.get(DecodeHintType.POSSIBLE_FORMATS);
        boolean useCode39CheckDigit = (hints == null || hints.get(DecodeHintType.ASSUME_CODE_39_CHECK_DIGIT) == null) ? false : true;
        new ArrayList<>();
        Collection<OneDReader> readers2 = collection;
        if (possibleFormats != null) {
            if (possibleFormats.contains(BarcodeFormat.EAN_13) || possibleFormats.contains(BarcodeFormat.UPC_A) || possibleFormats.contains(BarcodeFormat.EAN_8) || possibleFormats.contains(BarcodeFormat.UPC_E)) {
                new MultiFormatUPCEANReader(hints);
                boolean add = readers2.add(obj16);
            }
            if (possibleFormats.contains(BarcodeFormat.CODE_39)) {
                new Code39Reader(useCode39CheckDigit);
                boolean add2 = readers2.add(obj15);
            }
            if (possibleFormats.contains(BarcodeFormat.CODE_93)) {
                new Code93Reader();
                boolean add3 = readers2.add(obj14);
            }
            if (possibleFormats.contains(BarcodeFormat.CODE_128)) {
                new Code128Reader();
                boolean add4 = readers2.add(obj13);
            }
            if (possibleFormats.contains(BarcodeFormat.ITF)) {
                new ITFReader();
                boolean add5 = readers2.add(obj12);
            }
            if (possibleFormats.contains(BarcodeFormat.CODABAR)) {
                new CodaBarReader();
                boolean add6 = readers2.add(obj11);
            }
            if (possibleFormats.contains(BarcodeFormat.RSS_14)) {
                new RSS14Reader();
                boolean add7 = readers2.add(obj10);
            }
            if (possibleFormats.contains(BarcodeFormat.RSS_EXPANDED)) {
                new RSSExpandedReader();
                boolean add8 = readers2.add(obj9);
            }
        }
        if (readers2.isEmpty()) {
            new MultiFormatUPCEANReader(hints);
            boolean add9 = readers2.add(obj);
            new Code39Reader();
            boolean add10 = readers2.add(obj2);
            new CodaBarReader();
            boolean add11 = readers2.add(obj3);
            new Code93Reader();
            boolean add12 = readers2.add(obj4);
            new Code128Reader();
            boolean add13 = readers2.add(obj5);
            new ITFReader();
            boolean add14 = readers2.add(obj6);
            new RSS14Reader();
            boolean add15 = readers2.add(obj7);
            new RSSExpandedReader();
            boolean add16 = readers2.add(obj8);
        }
        this.readers = (OneDReader[]) readers2.toArray(new OneDReader[readers2.size()]);
    }

    public Result decodeRow(int i, BitArray bitArray, Map<DecodeHintType, ?> map) throws NotFoundException {
        int rowNumber = i;
        BitArray row = bitArray;
        Map<DecodeHintType, ?> hints = map;
        OneDReader[] arr$ = this.readers;
        int len$ = arr$.length;
        int i$ = 0;
        while (i$ < len$) {
            try {
                return arr$[i$].decodeRow(rowNumber, row, hints);
            } catch (ReaderException e) {
                ReaderException readerException = e;
                i$++;
            }
        }
        throw NotFoundException.getNotFoundInstance();
    }

    public void reset() {
        Reader[] arr$ = this.readers;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            arr$[i$].reset();
        }
    }
}
