package com.google.zxing.oned.rss.expanded;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.DecodeHintType;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitArray;
import com.google.zxing.oned.rss.AbstractRSSReader;
import com.google.zxing.oned.rss.DataCharacter;
import com.google.zxing.oned.rss.FinderPattern;
import com.google.zxing.oned.rss.RSSUtils;
import com.google.zxing.oned.rss.expanded.decoders.AbstractExpandedDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class RSSExpandedReader extends AbstractRSSReader {
    private static final int[] EVEN_TOTAL_SUBSET = {4, 20, 52, 104, 204};
    private static final int[][] FINDER_PATTERNS;
    private static final int[][] FINDER_PATTERN_SEQUENCES;
    private static final int FINDER_PAT_A = 0;
    private static final int FINDER_PAT_B = 1;
    private static final int FINDER_PAT_C = 2;
    private static final int FINDER_PAT_D = 3;
    private static final int FINDER_PAT_E = 4;
    private static final int FINDER_PAT_F = 5;
    private static final int[] GSUM = {0, 348, 1388, 2948, 3988};
    private static final int LONGEST_SEQUENCE_SIZE = FINDER_PATTERN_SEQUENCES[FINDER_PATTERN_SEQUENCES.length - 1].length;
    private static final int MAX_PAIRS = 11;
    private static final int[] SYMBOL_WIDEST = {7, 5, 4, 3, 1};
    private static final int[][] WEIGHTS;
    private final int[] currentSequence = new int[LONGEST_SEQUENCE_SIZE];
    private final List<ExpandedPair> pairs;
    private final int[] startEnd = new int[2];

    public RSSExpandedReader() {
        List<ExpandedPair> list;
        new ArrayList(11);
        this.pairs = list;
    }

    static {
        int[][] iArr = new int[6][];
        iArr[0] = new int[]{1, 8, 4, 1};
        int[][] iArr2 = iArr;
        iArr2[1] = new int[]{3, 6, 4, 1};
        int[][] iArr3 = iArr2;
        iArr3[2] = new int[]{3, 4, 6, 1};
        int[][] iArr4 = iArr3;
        iArr4[3] = new int[]{3, 2, 8, 1};
        int[][] iArr5 = iArr4;
        iArr5[4] = new int[]{2, 6, 5, 1};
        int[][] iArr6 = iArr5;
        iArr6[5] = new int[]{2, 2, 9, 1};
        FINDER_PATTERNS = iArr6;
        int[][] iArr7 = new int[23][];
        iArr7[0] = new int[]{1, 3, 9, 27, 81, 32, 96, 77};
        int[][] iArr8 = iArr7;
        iArr8[1] = new int[]{20, 60, 180, 118, 143, 7, 21, 63};
        int[][] iArr9 = iArr8;
        iArr9[2] = new int[]{189, 145, 13, 39, 117, 140, 209, 205};
        int[][] iArr10 = iArr9;
        iArr10[3] = new int[]{193, 157, 49, 147, 19, 57, 171, 91};
        int[][] iArr11 = iArr10;
        iArr11[4] = new int[]{62, 186, 136, 197, 169, 85, 44, 132};
        int[][] iArr12 = iArr11;
        iArr12[5] = new int[]{185, 133, 188, 142, 4, 12, 36, 108};
        int[][] iArr13 = iArr12;
        iArr13[6] = new int[]{113, 128, 173, 97, 80, 29, 87, 50};
        int[][] iArr14 = iArr13;
        iArr14[7] = new int[]{150, 28, 84, 41, 123, 158, 52, 156};
        int[][] iArr15 = iArr14;
        iArr15[8] = new int[]{46, 138, 203, 187, 139, 206, 196, 166};
        int[][] iArr16 = iArr15;
        iArr16[9] = new int[]{76, 17, 51, 153, 37, 111, 122, 155};
        int[][] iArr17 = iArr16;
        iArr17[10] = new int[]{43, 129, 176, 106, 107, 110, 119, 146};
        int[][] iArr18 = iArr17;
        iArr18[11] = new int[]{16, 48, 144, 10, 30, 90, 59, 177};
        int[][] iArr19 = iArr18;
        iArr19[12] = new int[]{109, 116, 137, 200, 178, 112, 125, 164};
        int[][] iArr20 = iArr19;
        iArr20[13] = new int[]{70, 210, 208, 202, 184, 130, 179, 115};
        int[][] iArr21 = iArr20;
        iArr21[14] = new int[]{134, 191, 151, 31, 93, 68, 204, 190};
        int[][] iArr22 = iArr21;
        iArr22[15] = new int[]{148, 22, 66, 198, 172, 94, 71, 2};
        int[][] iArr23 = iArr22;
        iArr23[16] = new int[]{6, 18, 54, 162, 64, 192, 154, 40};
        int[][] iArr24 = iArr23;
        iArr24[17] = new int[]{120, 149, 25, 75, 14, 42, 126, 167};
        int[][] iArr25 = iArr24;
        iArr25[18] = new int[]{79, 26, 78, 23, 69, 207, 199, 175};
        int[][] iArr26 = iArr25;
        iArr26[19] = new int[]{103, 98, 83, 38, 114, 131, 182, 124};
        int[][] iArr27 = iArr26;
        iArr27[20] = new int[]{161, 61, 183, 127, 170, 88, 53, 159};
        int[][] iArr28 = iArr27;
        iArr28[21] = new int[]{55, 165, 73, 8, 24, 72, 5, 15};
        int[][] iArr29 = iArr28;
        iArr29[22] = new int[]{45, 135, 194, 160, 58, 174, 100, 89};
        WEIGHTS = iArr29;
        int[][] iArr30 = new int[10][];
        iArr30[0] = new int[]{0, 0};
        int[][] iArr31 = iArr30;
        iArr31[1] = new int[]{0, 1, 1};
        int[][] iArr32 = iArr31;
        iArr32[2] = new int[]{0, 2, 1, 3};
        int[][] iArr33 = iArr32;
        iArr33[3] = new int[]{0, 4, 1, 3, 2};
        int[][] iArr34 = iArr33;
        iArr34[4] = new int[]{0, 4, 1, 3, 3, 5};
        int[][] iArr35 = iArr34;
        iArr35[5] = new int[]{0, 4, 1, 3, 4, 5, 5};
        int[][] iArr36 = iArr35;
        iArr36[6] = new int[]{0, 0, 1, 1, 2, 2, 3, 3};
        int[][] iArr37 = iArr36;
        iArr37[7] = new int[]{0, 0, 1, 1, 2, 2, 3, 4, 4};
        int[][] iArr38 = iArr37;
        iArr38[8] = new int[]{0, 0, 1, 1, 2, 2, 3, 4, 5, 5};
        int[][] iArr39 = iArr38;
        iArr39[9] = new int[]{0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5};
        FINDER_PATTERN_SEQUENCES = iArr39;
    }

    public Result decodeRow(int rowNumber, BitArray row, Map<DecodeHintType, ?> map) throws NotFoundException {
        Map<DecodeHintType, ?> map2 = map;
        reset();
        List<ExpandedPair> decodeRow2pairs = decodeRow2pairs(rowNumber, row);
        return constructResult(this.pairs);
    }

    public void reset() {
        this.pairs.clear();
    }

    /* access modifiers changed from: package-private */
    public List<ExpandedPair> decodeRow2pairs(int i, BitArray bitArray) throws NotFoundException {
        int rowNumber = i;
        BitArray row = bitArray;
        while (true) {
            ExpandedPair nextPair = retrieveNextPair(row, this.pairs, rowNumber);
            boolean add = this.pairs.add(nextPair);
            if (nextPair.mayBeLast()) {
                if (checkChecksum()) {
                    return this.pairs;
                }
                if (nextPair.mustBeLast()) {
                    throw NotFoundException.getNotFoundInstance();
                }
            }
        }
    }

    private static Result constructResult(List<ExpandedPair> list) throws NotFoundException {
        Result result;
        List<ExpandedPair> pairs2 = list;
        String resultingString = AbstractExpandedDecoder.createDecoder(BitArrayBuilder.buildBitArray(pairs2)).parseInformation();
        ResultPoint[] firstPoints = pairs2.get(0).getFinderPattern().getResultPoints();
        ResultPoint[] lastPoints = pairs2.get(pairs2.size() - 1).getFinderPattern().getResultPoints();
        Result result2 = result;
        ResultPoint[] resultPointArr = new ResultPoint[4];
        resultPointArr[0] = firstPoints[0];
        ResultPoint[] resultPointArr2 = resultPointArr;
        resultPointArr2[1] = firstPoints[1];
        ResultPoint[] resultPointArr3 = resultPointArr2;
        resultPointArr3[2] = lastPoints[0];
        ResultPoint[] resultPointArr4 = resultPointArr3;
        resultPointArr4[3] = lastPoints[1];
        new Result(resultingString, (byte[]) null, resultPointArr4, BarcodeFormat.RSS_EXPANDED);
        return result2;
    }

    private boolean checkChecksum() {
        ExpandedPair firstPair = this.pairs.get(0);
        DataCharacter checkCharacter = firstPair.getLeftChar();
        int checksum = firstPair.getRightChar().getChecksumPortion();
        int s = 2;
        for (int i = 1; i < this.pairs.size(); i++) {
            ExpandedPair currentPair = this.pairs.get(i);
            checksum += currentPair.getLeftChar().getChecksumPortion();
            s++;
            DataCharacter currentRightChar = currentPair.getRightChar();
            if (currentRightChar != null) {
                checksum += currentRightChar.getChecksumPortion();
                s++;
            }
        }
        return (211 * (s + -4)) + (checksum % 211) == checkCharacter.getValue();
    }

    private static int getNextSecondBar(BitArray bitArray, int i) {
        int currentPos;
        BitArray row = bitArray;
        int initialPos = i;
        if (row.get(initialPos)) {
            currentPos = row.getNextSet(row.getNextUnset(initialPos));
        } else {
            currentPos = row.getNextUnset(row.getNextSet(initialPos));
        }
        return currentPos;
    }

    /* access modifiers changed from: package-private */
    public ExpandedPair retrieveNextPair(BitArray bitArray, List<ExpandedPair> list, int i) throws NotFoundException {
        FinderPattern pattern;
        DataCharacter rightChar;
        ExpandedPair expandedPair;
        BitArray row = bitArray;
        List<ExpandedPair> previousPairs = list;
        int rowNumber = i;
        boolean isOddPattern = previousPairs.size() % 2 == 0;
        boolean keepFinding = true;
        int forcedOffset = -1;
        do {
            findNextPair(row, previousPairs, forcedOffset);
            pattern = parseFoundFinderPattern(row, rowNumber, isOddPattern);
            if (pattern == null) {
                forcedOffset = getNextSecondBar(row, this.startEnd[0]);
            } else {
                keepFinding = false;
            }
        } while (keepFinding);
        boolean mayBeLast = checkPairSequence(previousPairs, pattern);
        DataCharacter leftChar = decodeDataCharacter(row, pattern, isOddPattern, true);
        try {
            rightChar = decodeDataCharacter(row, pattern, isOddPattern, false);
        } catch (NotFoundException e) {
            NotFoundException nfe = e;
            if (mayBeLast) {
                rightChar = null;
            } else {
                throw nfe;
            }
        }
        new ExpandedPair(leftChar, rightChar, pattern, mayBeLast);
        return expandedPair;
    }

    private boolean checkPairSequence(List<ExpandedPair> list, FinderPattern finderPattern) throws NotFoundException {
        List<ExpandedPair> previousPairs = list;
        FinderPattern pattern = finderPattern;
        int currentSequenceLength = previousPairs.size() + 1;
        if (currentSequenceLength > this.currentSequence.length) {
            throw NotFoundException.getNotFoundInstance();
        }
        for (int pos = 0; pos < previousPairs.size(); pos++) {
            this.currentSequence[pos] = previousPairs.get(pos).getFinderPattern().getValue();
        }
        this.currentSequence[currentSequenceLength - 1] = pattern.getValue();
        int[][] arr$ = FINDER_PATTERN_SEQUENCES;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            int[] validSequence = arr$[i$];
            if (validSequence.length >= currentSequenceLength) {
                boolean valid = true;
                int pos2 = 0;
                while (true) {
                    if (pos2 >= currentSequenceLength) {
                        break;
                    } else if (this.currentSequence[pos2] != validSequence[pos2]) {
                        valid = false;
                        break;
                    } else {
                        pos2++;
                    }
                }
                if (valid) {
                    return currentSequenceLength == validSequence.length;
                }
            }
        }
        throw NotFoundException.getNotFoundInstance();
    }

    private void findNextPair(BitArray bitArray, List<ExpandedPair> list, int i) throws NotFoundException {
        int rowOffset;
        BitArray row = bitArray;
        List<ExpandedPair> previousPairs = list;
        int forcedOffset = i;
        int[] counters = getDecodeFinderCounters();
        counters[0] = 0;
        counters[1] = 0;
        counters[2] = 0;
        counters[3] = 0;
        int width = row.getSize();
        if (forcedOffset >= 0) {
            rowOffset = forcedOffset;
        } else if (previousPairs.isEmpty()) {
            rowOffset = 0;
        } else {
            rowOffset = previousPairs.get(previousPairs.size() - 1).getFinderPattern().getStartEnd()[1];
        }
        boolean searchingEvenPair = previousPairs.size() % 2 != 0;
        boolean isWhite = false;
        while (rowOffset < width) {
            isWhite = !row.get(rowOffset);
            if (!isWhite) {
                break;
            }
            rowOffset++;
        }
        int counterPosition = 0;
        int patternStart = rowOffset;
        for (int x = rowOffset; x < width; x++) {
            if (row.get(x) ^ isWhite) {
                int[] iArr = counters;
                int i2 = counterPosition;
                iArr[i2] = iArr[i2] + 1;
            } else {
                if (counterPosition == 3) {
                    if (searchingEvenPair) {
                        reverseCounters(counters);
                    }
                    if (isFinderPattern(counters)) {
                        this.startEnd[0] = patternStart;
                        this.startEnd[1] = x;
                        return;
                    }
                    if (searchingEvenPair) {
                        reverseCounters(counters);
                    }
                    patternStart += counters[0] + counters[1];
                    counters[0] = counters[2];
                    counters[1] = counters[3];
                    counters[2] = 0;
                    counters[3] = 0;
                    counterPosition--;
                } else {
                    counterPosition++;
                }
                counters[counterPosition] = 1;
                isWhite = !isWhite;
            }
        }
        throw NotFoundException.getNotFoundInstance();
    }

    private static void reverseCounters(int[] iArr) {
        int[] counters = iArr;
        int length = counters.length;
        for (int i = 0; i < length / 2; i++) {
            int tmp = counters[i];
            counters[i] = counters[(length - i) - 1];
            counters[(length - i) - 1] = tmp;
        }
    }

    private FinderPattern parseFoundFinderPattern(BitArray bitArray, int i, boolean oddPattern) {
        int start;
        int end;
        int firstCounter;
        FinderPattern finderPattern;
        BitArray row = bitArray;
        int rowNumber = i;
        if (oddPattern) {
            int firstElementStart = this.startEnd[0] - 1;
            while (firstElementStart >= 0 && !row.get(firstElementStart)) {
                firstElementStart--;
            }
            int firstElementStart2 = firstElementStart + 1;
            firstCounter = this.startEnd[0] - firstElementStart2;
            start = firstElementStart2;
            end = this.startEnd[1];
        } else {
            start = this.startEnd[0];
            end = row.getNextUnset(this.startEnd[1] + 1);
            firstCounter = end - this.startEnd[1];
        }
        int[] counters = getDecodeFinderCounters();
        System.arraycopy(counters, 0, counters, 1, counters.length - 1);
        counters[0] = firstCounter;
        try {
            int value = parseFinderValue(counters, FINDER_PATTERNS);
            FinderPattern finderPattern2 = finderPattern;
            int[] iArr = new int[2];
            iArr[0] = start;
            int[] iArr2 = iArr;
            iArr2[1] = end;
            new FinderPattern(value, iArr2, start, end, rowNumber);
            return finderPattern2;
        } catch (NotFoundException e) {
            NotFoundException notFoundException = e;
            return null;
        }
    }

    /* access modifiers changed from: package-private */
    public DataCharacter decodeDataCharacter(BitArray bitArray, FinderPattern finderPattern, boolean z, boolean z2) throws NotFoundException {
        int i;
        DataCharacter dataCharacter;
        BitArray row = bitArray;
        FinderPattern pattern = finderPattern;
        boolean isOddPattern = z;
        boolean leftChar = z2;
        int[] counters = getDataCharacterCounters();
        counters[0] = 0;
        counters[1] = 0;
        counters[2] = 0;
        counters[3] = 0;
        counters[4] = 0;
        counters[5] = 0;
        counters[6] = 0;
        counters[7] = 0;
        if (leftChar) {
            recordPatternInReverse(row, pattern.getStartEnd()[0], counters);
        } else {
            recordPattern(row, pattern.getStartEnd()[1] + 1, counters);
            int i2 = 0;
            for (int j = counters.length - 1; i2 < j; j--) {
                int temp = counters[i2];
                counters[i2] = counters[j];
                counters[j] = temp;
                i2++;
            }
        }
        float elementWidth = ((float) count(counters)) / ((float) 17);
        int[] oddCounts = getOddCounts();
        int[] evenCounts = getEvenCounts();
        float[] oddRoundingErrors = getOddRoundingErrors();
        float[] evenRoundingErrors = getEvenRoundingErrors();
        for (int i3 = 0; i3 < counters.length; i3++) {
            float value = (1.0f * ((float) counters[i3])) / elementWidth;
            int count = (int) (value + 0.5f);
            if (count < 1) {
                count = 1;
            } else if (count > 8) {
                count = 8;
            }
            int offset = i3 >> 1;
            if ((i3 & 1) == 0) {
                oddCounts[offset] = count;
                oddRoundingErrors[offset] = value - ((float) count);
            } else {
                evenCounts[offset] = count;
                evenRoundingErrors[offset] = value - ((float) count);
            }
        }
        adjustOddEvenCounts(17);
        int value2 = (4 * pattern.getValue()) + (isOddPattern ? 0 : 2);
        if (leftChar) {
            i = 0;
        } else {
            i = 1;
        }
        int weightRowNumber = (value2 + i) - 1;
        int oddSum = 0;
        int oddChecksumPortion = 0;
        for (int i4 = oddCounts.length - 1; i4 >= 0; i4--) {
            if (isNotA1left(pattern, isOddPattern, leftChar)) {
                oddChecksumPortion += oddCounts[i4] * WEIGHTS[weightRowNumber][2 * i4];
            }
            oddSum += oddCounts[i4];
        }
        int evenChecksumPortion = 0;
        int evenSum = 0;
        for (int i5 = evenCounts.length - 1; i5 >= 0; i5--) {
            if (isNotA1left(pattern, isOddPattern, leftChar)) {
                evenChecksumPortion += evenCounts[i5] * WEIGHTS[weightRowNumber][(2 * i5) + 1];
            }
            evenSum += evenCounts[i5];
        }
        int checksumPortion = oddChecksumPortion + evenChecksumPortion;
        if ((oddSum & 1) != 0 || oddSum > 13 || oddSum < 4) {
            throw NotFoundException.getNotFoundInstance();
        }
        int group = (13 - oddSum) / 2;
        int oddWidest = SYMBOL_WIDEST[group];
        new DataCharacter((RSSUtils.getRSSvalue(oddCounts, oddWidest, true) * EVEN_TOTAL_SUBSET[group]) + RSSUtils.getRSSvalue(evenCounts, 9 - oddWidest, false) + GSUM[group], checksumPortion);
        return dataCharacter;
    }

    private static boolean isNotA1left(FinderPattern pattern, boolean isOddPattern, boolean leftChar) {
        return pattern.getValue() != 0 || !isOddPattern || !leftChar;
    }

    private void adjustOddEvenCounts(int numModules) throws NotFoundException {
        int oddSum = count(getOddCounts());
        int evenSum = count(getEvenCounts());
        int mismatch = (oddSum + evenSum) - numModules;
        boolean oddParityBad = (oddSum & 1) == 1;
        boolean evenParityBad = (evenSum & 1) == 0;
        boolean incrementOdd = false;
        boolean decrementOdd = false;
        if (oddSum > 13) {
            decrementOdd = true;
        } else if (oddSum < 4) {
            incrementOdd = true;
        }
        boolean incrementEven = false;
        boolean decrementEven = false;
        if (evenSum > 13) {
            decrementEven = true;
        } else if (evenSum < 4) {
            incrementEven = true;
        }
        if (mismatch == 1) {
            if (oddParityBad) {
                if (evenParityBad) {
                    throw NotFoundException.getNotFoundInstance();
                }
                decrementOdd = true;
            } else if (!evenParityBad) {
                throw NotFoundException.getNotFoundInstance();
            } else {
                decrementEven = true;
            }
        } else if (mismatch == -1) {
            if (oddParityBad) {
                if (evenParityBad) {
                    throw NotFoundException.getNotFoundInstance();
                }
                incrementOdd = true;
            } else if (!evenParityBad) {
                throw NotFoundException.getNotFoundInstance();
            } else {
                incrementEven = true;
            }
        } else if (mismatch != 0) {
            throw NotFoundException.getNotFoundInstance();
        } else if (oddParityBad) {
            if (!evenParityBad) {
                throw NotFoundException.getNotFoundInstance();
            } else if (oddSum < evenSum) {
                incrementOdd = true;
                decrementEven = true;
            } else {
                decrementOdd = true;
                incrementEven = true;
            }
        } else if (evenParityBad) {
            throw NotFoundException.getNotFoundInstance();
        }
        if (incrementOdd) {
            if (decrementOdd) {
                throw NotFoundException.getNotFoundInstance();
            }
            increment(getOddCounts(), getOddRoundingErrors());
        }
        if (decrementOdd) {
            decrement(getOddCounts(), getOddRoundingErrors());
        }
        if (incrementEven) {
            if (decrementEven) {
                throw NotFoundException.getNotFoundInstance();
            }
            increment(getEvenCounts(), getOddRoundingErrors());
        }
        if (decrementEven) {
            decrement(getEvenCounts(), getEvenRoundingErrors());
        }
    }
}
