package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.NotFoundException;
import com.google.zxing.common.BitArray;

public final class EAN13Reader extends UPCEANReader {
    static final int[] FIRST_DIGIT_ENCODINGS = {0, 11, 13, 14, 19, 25, 28, 21, 22, 26};
    private final int[] decodeMiddleCounters = new int[4];

    public EAN13Reader() {
    }

    /* access modifiers changed from: protected */
    public int decodeMiddle(BitArray bitArray, int[] startRange, StringBuilder sb) throws NotFoundException {
        BitArray row = bitArray;
        StringBuilder resultString = sb;
        int[] counters = this.decodeMiddleCounters;
        counters[0] = 0;
        counters[1] = 0;
        counters[2] = 0;
        counters[3] = 0;
        int end = row.getSize();
        int rowOffset = startRange[1];
        int lgPatternFound = 0;
        for (int x = 0; x < 6 && rowOffset < end; x++) {
            int bestMatch = decodeDigit(row, counters, rowOffset, L_AND_G_PATTERNS);
            StringBuilder append = resultString.append((char) (48 + (bestMatch % 10)));
            int[] arr$ = counters;
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                rowOffset += arr$[i$];
            }
            if (bestMatch >= 10) {
                lgPatternFound |= 1 << (5 - x);
            }
        }
        determineFirstDigit(resultString, lgPatternFound);
        int rowOffset2 = findGuardPattern(row, rowOffset, true, MIDDLE_PATTERN)[1];
        for (int x2 = 0; x2 < 6 && rowOffset2 < end; x2++) {
            StringBuilder append2 = resultString.append((char) (48 + decodeDigit(row, counters, rowOffset2, L_PATTERNS)));
            int[] arr$2 = counters;
            int len$2 = arr$2.length;
            for (int i$2 = 0; i$2 < len$2; i$2++) {
                rowOffset2 += arr$2[i$2];
            }
        }
        return rowOffset2;
    }

    /* access modifiers changed from: package-private */
    public BarcodeFormat getBarcodeFormat() {
        return BarcodeFormat.EAN_13;
    }

    private static void determineFirstDigit(StringBuilder sb, int i) throws NotFoundException {
        StringBuilder resultString = sb;
        int lgPatternFound = i;
        for (int d = 0; d < 10; d++) {
            if (lgPatternFound == FIRST_DIGIT_ENCODINGS[d]) {
                StringBuilder insert = resultString.insert(0, (char) (48 + d));
                return;
            }
        }
        throw NotFoundException.getNotFoundInstance();
    }
}
