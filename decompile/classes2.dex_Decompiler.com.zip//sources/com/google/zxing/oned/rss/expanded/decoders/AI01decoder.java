package com.google.zxing.oned.rss.expanded.decoders;

import com.google.zxing.common.BitArray;

abstract class AI01decoder extends AbstractExpandedDecoder {
    protected static final int GTIN_SIZE = 40;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    AI01decoder(BitArray information) {
        super(information);
    }

    /* access modifiers changed from: protected */
    public final void encodeCompressedGtin(StringBuilder sb, int currentPos) {
        StringBuilder buf = sb;
        StringBuilder append = buf.append("(01)");
        int initialPosition = buf.length();
        StringBuilder append2 = buf.append('9');
        encodeCompressedGtinWithoutAI(buf, currentPos, initialPosition);
    }

    /* access modifiers changed from: protected */
    public final void encodeCompressedGtinWithoutAI(StringBuilder sb, int i, int i2) {
        StringBuilder buf = sb;
        int currentPos = i;
        int initialBufferPosition = i2;
        for (int i3 = 0; i3 < 4; i3++) {
            int currentBlock = getGeneralDecoder().extractNumericValueFromBitArray(currentPos + (10 * i3), 10);
            if (currentBlock / 100 == 0) {
                StringBuilder append = buf.append('0');
            }
            if (currentBlock / 10 == 0) {
                StringBuilder append2 = buf.append('0');
            }
            StringBuilder append3 = buf.append(currentBlock);
        }
        appendCheckDigit(buf, initialBufferPosition);
    }

    private static void appendCheckDigit(StringBuilder sb, int i) {
        StringBuilder buf = sb;
        int currentPos = i;
        int checkDigit = 0;
        for (int i2 = 0; i2 < 13; i2++) {
            int digit = buf.charAt(i2 + currentPos) - '0';
            checkDigit += (i2 & 1) == 0 ? 3 * digit : digit;
        }
        int checkDigit2 = 10 - (checkDigit % 10);
        if (checkDigit2 == 10) {
            checkDigit2 = 0;
        }
        StringBuilder append = buf.append(checkDigit2);
    }
}
