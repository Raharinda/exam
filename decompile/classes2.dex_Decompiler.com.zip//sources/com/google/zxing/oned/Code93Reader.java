package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.ChecksumException;
import com.google.zxing.DecodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitArray;
import java.util.Map;

public final class Code93Reader extends OneDReader {
    private static final char[] ALPHABET = ALPHABET_STRING.toCharArray();
    private static final String ALPHABET_STRING = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%abcd*";
    private static final int ASTERISK_ENCODING = CHARACTER_ENCODINGS[47];
    private static final int[] CHARACTER_ENCODINGS = {276, 328, 324, 322, 296, 292, 290, 336, 274, 266, 424, 420, 418, 404, 402, 394, 360, 356, 354, 308, 282, 344, 332, 326, 300, 278, 436, 434, 428, 422, 406, 410, 364, 358, 310, 314, 302, 468, 466, 458, 366, 374, 430, 294, 474, 470, 306, 350};

    public Code93Reader() {
    }

    public Result decodeRow(int i, BitArray bitArray, Map<DecodeHintType, ?> map) throws NotFoundException, ChecksumException, FormatException {
        StringBuilder sb;
        char decodedChar;
        int lastStart;
        Result result;
        ResultPoint resultPoint;
        ResultPoint resultPoint2;
        int rowNumber = i;
        BitArray row = bitArray;
        Map<DecodeHintType, ?> map2 = map;
        int[] start = findAsteriskPattern(row);
        int nextStart = row.getNextSet(start[1]);
        int end = row.getSize();
        new StringBuilder(20);
        StringBuilder result2 = sb;
        int[] counters = new int[6];
        do {
            recordPattern(row, nextStart, counters);
            int pattern = toPattern(counters);
            if (pattern < 0) {
                throw NotFoundException.getNotFoundInstance();
            }
            decodedChar = patternToChar(pattern);
            StringBuilder append = result2.append(decodedChar);
            lastStart = nextStart;
            int[] arr$ = counters;
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                nextStart += arr$[i$];
            }
            nextStart = row.getNextSet(nextStart);
        } while (decodedChar != '*');
        StringBuilder deleteCharAt = result2.deleteCharAt(result2.length() - 1);
        if (nextStart == end || !row.get(nextStart)) {
            throw NotFoundException.getNotFoundInstance();
        } else if (result2.length() < 2) {
            throw NotFoundException.getNotFoundInstance();
        } else {
            checkChecksums(result2);
            result2.setLength(result2.length() - 2);
            String resultString = decodeExtended(result2);
            Result result3 = result;
            ResultPoint[] resultPointArr = new ResultPoint[2];
            new ResultPoint(((float) (start[1] + start[0])) / 2.0f, (float) rowNumber);
            resultPointArr[0] = resultPoint;
            ResultPoint[] resultPointArr2 = resultPointArr;
            new ResultPoint(((float) (nextStart + lastStart)) / 2.0f, (float) rowNumber);
            resultPointArr2[1] = resultPoint2;
            new Result(resultString, (byte[]) null, resultPointArr2, BarcodeFormat.CODE_93);
            return result3;
        }
    }

    private static int[] findAsteriskPattern(BitArray bitArray) throws NotFoundException {
        BitArray row = bitArray;
        int width = row.getSize();
        int rowOffset = row.getNextSet(0);
        int counterPosition = 0;
        int[] counters = new int[6];
        int patternStart = rowOffset;
        boolean isWhite = false;
        int patternLength = counters.length;
        for (int i = rowOffset; i < width; i++) {
            if (row.get(i) ^ isWhite) {
                int[] iArr = counters;
                int i2 = counterPosition;
                iArr[i2] = iArr[i2] + 1;
            } else {
                if (counterPosition != patternLength - 1) {
                    counterPosition++;
                } else if (toPattern(counters) == ASTERISK_ENCODING) {
                    int[] iArr2 = new int[2];
                    iArr2[0] = patternStart;
                    int[] iArr3 = iArr2;
                    iArr3[1] = i;
                    return iArr3;
                } else {
                    patternStart += counters[0] + counters[1];
                    System.arraycopy(counters, 2, counters, 0, patternLength - 2);
                    counters[patternLength - 2] = 0;
                    counters[patternLength - 1] = 0;
                    counterPosition--;
                }
                counters[counterPosition] = 1;
                isWhite = !isWhite;
            }
        }
        throw NotFoundException.getNotFoundInstance();
    }

    private static int toPattern(int[] iArr) {
        int[] counters = iArr;
        int max = counters.length;
        int sum = 0;
        int[] arr$ = counters;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            sum += arr$[i$];
        }
        int pattern = 0;
        for (int i = 0; i < max; i++) {
            int scaledShifted = ((counters[i] << 8) * 9) / sum;
            int scaledUnshifted = scaledShifted >> 8;
            if ((scaledShifted & 255) > 127) {
                scaledUnshifted++;
            }
            if (scaledUnshifted < 1 || scaledUnshifted > 4) {
                return -1;
            }
            if ((i & 1) == 0) {
                for (int j = 0; j < scaledUnshifted; j++) {
                    pattern = (pattern << 1) | 1;
                }
            } else {
                pattern <<= scaledUnshifted;
            }
        }
        return pattern;
    }

    private static char patternToChar(int i) throws NotFoundException {
        int pattern = i;
        for (int i2 = 0; i2 < CHARACTER_ENCODINGS.length; i2++) {
            if (CHARACTER_ENCODINGS[i2] == pattern) {
                return ALPHABET[i2];
            }
        }
        throw NotFoundException.getNotFoundInstance();
    }

    private static String decodeExtended(CharSequence charSequence) throws FormatException {
        StringBuilder sb;
        CharSequence encoded = charSequence;
        int length = encoded.length();
        new StringBuilder(length);
        StringBuilder decoded = sb;
        int i = 0;
        while (i < length) {
            char c = encoded.charAt(i);
            if (c < 'a' || c > 'd') {
                StringBuilder append = decoded.append(c);
            } else if (i >= length - 1) {
                throw FormatException.getFormatInstance();
            } else {
                char next = encoded.charAt(i + 1);
                char decodedChar = 0;
                switch (c) {
                    case 'a':
                        if (next >= 'A' && next <= 'Z') {
                            decodedChar = (char) (next - '@');
                            break;
                        } else {
                            throw FormatException.getFormatInstance();
                        }
                    case 'b':
                        if (next < 'A' || next > 'E') {
                            if (next >= 'F' && next <= 'W') {
                                decodedChar = (char) (next - 11);
                                break;
                            } else {
                                throw FormatException.getFormatInstance();
                            }
                        } else {
                            decodedChar = (char) (next - '&');
                            break;
                        }
                        break;
                    case 'c':
                        if (next >= 'A' && next <= 'O') {
                            decodedChar = (char) (next - ' ');
                            break;
                        } else if (next == 'Z') {
                            decodedChar = ':';
                            break;
                        } else {
                            throw FormatException.getFormatInstance();
                        }
                        break;
                    case 'd':
                        if (next >= 'A' && next <= 'Z') {
                            decodedChar = (char) (next + ' ');
                            break;
                        } else {
                            throw FormatException.getFormatInstance();
                        }
                        break;
                }
                StringBuilder append2 = decoded.append(decodedChar);
                i++;
            }
            i++;
        }
        return decoded.toString();
    }

    private static void checkChecksums(CharSequence charSequence) throws ChecksumException {
        CharSequence result = charSequence;
        int length = result.length();
        checkOneChecksum(result, length - 2, 20);
        checkOneChecksum(result, length - 1, 15);
    }

    private static void checkOneChecksum(CharSequence charSequence, int i, int i2) throws ChecksumException {
        CharSequence result = charSequence;
        int checkPosition = i;
        int weightMax = i2;
        int weight = 1;
        int total = 0;
        for (int i3 = checkPosition - 1; i3 >= 0; i3--) {
            total += weight * ALPHABET_STRING.indexOf(result.charAt(i3));
            weight++;
            if (weight > weightMax) {
                weight = 1;
            }
        }
        if (result.charAt(checkPosition) != ALPHABET[total % 47]) {
            throw ChecksumException.getChecksumInstance();
        }
    }
}
