package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import java.util.Map;

public final class Code39Writer extends OneDimensionalCodeWriter {
    public Code39Writer() {
    }

    public BitMatrix encode(String str, BarcodeFormat barcodeFormat, int i, int i2, Map<EncodeHintType, ?> map) throws WriterException {
        Throwable th;
        StringBuilder sb;
        String contents = str;
        BarcodeFormat format = barcodeFormat;
        int width = i;
        int height = i2;
        Map<EncodeHintType, ?> hints = map;
        if (format == BarcodeFormat.CODE_39) {
            return super.encode(contents, format, width, height, hints);
        }
        Throwable th2 = th;
        new StringBuilder();
        new IllegalArgumentException(sb.append("Can only encode CODE_39, but got ").append(format).toString());
        throw th2;
    }

    public boolean[] encode(String str) {
        Throwable th;
        StringBuilder sb;
        String contents = str;
        int length = contents.length();
        if (length > 80) {
            Throwable th2 = th;
            new StringBuilder();
            new IllegalArgumentException(sb.append("Requested contents should be less than 80 digits long, but got ").append(length).toString());
            throw th2;
        }
        int[] widths = new int[9];
        int codeWidth = 25 + length;
        for (int i = 0; i < length; i++) {
            toIntArray(Code39Reader.CHARACTER_ENCODINGS["0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. *$/+%".indexOf(contents.charAt(i))], widths);
            int[] arr$ = widths;
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                codeWidth += arr$[i$];
            }
        }
        boolean[] result = new boolean[codeWidth];
        toIntArray(Code39Reader.CHARACTER_ENCODINGS[39], widths);
        int pos = appendPattern(result, 0, widths, true);
        int[] narrowWhite = {1};
        int pos2 = pos + appendPattern(result, pos, narrowWhite, false);
        for (int i2 = length - 1; i2 >= 0; i2--) {
            toIntArray(Code39Reader.CHARACTER_ENCODINGS["0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. *$/+%".indexOf(contents.charAt(i2))], widths);
            int pos3 = pos2 + appendPattern(result, pos2, widths, true);
            pos2 = pos3 + appendPattern(result, pos3, narrowWhite, false);
        }
        toIntArray(Code39Reader.CHARACTER_ENCODINGS[39], widths);
        int pos4 = pos2 + appendPattern(result, pos2, widths, true);
        return result;
    }

    private static void toIntArray(int i, int[] iArr) {
        int a = i;
        int[] toReturn = iArr;
        for (int i2 = 0; i2 < 9; i2++) {
            toReturn[i2] = (a & (1 << i2)) == 0 ? 1 : 2;
        }
    }
}
