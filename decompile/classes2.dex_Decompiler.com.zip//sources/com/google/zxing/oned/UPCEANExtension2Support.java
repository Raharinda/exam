package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.ResultMetadataType;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitArray;
import java.util.EnumMap;
import java.util.Map;

final class UPCEANExtension2Support {
    private final int[] decodeMiddleCounters = new int[4];
    private final StringBuilder decodeRowStringBuffer;

    UPCEANExtension2Support() {
        StringBuilder sb;
        new StringBuilder();
        this.decodeRowStringBuffer = sb;
    }

    /* access modifiers changed from: package-private */
    public Result decodeRow(int i, BitArray row, int[] iArr) throws NotFoundException {
        Result result;
        ResultPoint resultPoint;
        ResultPoint resultPoint2;
        int rowNumber = i;
        int[] extensionStartRange = iArr;
        StringBuilder result2 = this.decodeRowStringBuffer;
        result2.setLength(0);
        int end = decodeMiddle(row, extensionStartRange, result2);
        String resultString = result2.toString();
        Map<ResultMetadataType, Object> extensionData = parseExtensionString(resultString);
        Result result3 = result;
        ResultPoint[] resultPointArr = new ResultPoint[2];
        new ResultPoint(((float) (extensionStartRange[0] + extensionStartRange[1])) / 2.0f, (float) rowNumber);
        resultPointArr[0] = resultPoint;
        ResultPoint[] resultPointArr2 = resultPointArr;
        new ResultPoint((float) end, (float) rowNumber);
        resultPointArr2[1] = resultPoint2;
        new Result(resultString, (byte[]) null, resultPointArr2, BarcodeFormat.UPC_EAN_EXTENSION);
        Result extensionResult = result3;
        if (extensionData != null) {
            extensionResult.putAllMetadata(extensionData);
        }
        return extensionResult;
    }

    /* access modifiers changed from: package-private */
    public int decodeMiddle(BitArray bitArray, int[] startRange, StringBuilder sb) throws NotFoundException {
        BitArray row = bitArray;
        StringBuilder resultString = sb;
        int[] counters = this.decodeMiddleCounters;
        counters[0] = 0;
        counters[1] = 0;
        counters[2] = 0;
        counters[3] = 0;
        int end = row.getSize();
        int rowOffset = startRange[1];
        int checkParity = 0;
        for (int x = 0; x < 2 && rowOffset < end; x++) {
            int bestMatch = UPCEANReader.decodeDigit(row, counters, rowOffset, UPCEANReader.L_AND_G_PATTERNS);
            StringBuilder append = resultString.append((char) (48 + (bestMatch % 10)));
            int[] arr$ = counters;
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                rowOffset += arr$[i$];
            }
            if (bestMatch >= 10) {
                checkParity |= 1 << (1 - x);
            }
            if (x != 1) {
                rowOffset = row.getNextUnset(row.getNextSet(rowOffset));
            }
        }
        if (resultString.length() != 2) {
            throw NotFoundException.getNotFoundInstance();
        } else if (Integer.parseInt(resultString.toString()) % 4 == checkParity) {
            return rowOffset;
        } else {
            throw NotFoundException.getNotFoundInstance();
        }
    }

    private static Map<ResultMetadataType, Object> parseExtensionString(String str) {
        Map<ResultMetadataType, Object> map;
        String raw = str;
        if (raw.length() != 2) {
            return null;
        }
        new EnumMap(ResultMetadataType.class);
        Map<ResultMetadataType, Object> result = map;
        Object put = result.put(ResultMetadataType.ISSUE_NUMBER, Integer.valueOf(raw));
        return result;
    }
}
