package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.ChecksumException;
import com.google.zxing.DecodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.ReaderException;
import com.google.zxing.Result;
import com.google.zxing.ResultMetadataType;
import com.google.zxing.ResultPoint;
import com.google.zxing.ResultPointCallback;
import com.google.zxing.common.BitArray;
import java.util.Arrays;
import java.util.Map;

public abstract class UPCEANReader extends OneDReader {
    static final int[][] L_AND_G_PATTERNS = new int[20][];
    static final int[][] L_PATTERNS;
    private static final int MAX_AVG_VARIANCE = 122;
    private static final int MAX_INDIVIDUAL_VARIANCE = 179;
    static final int[] MIDDLE_PATTERN = {1, 1, 1, 1, 1};
    static final int[] START_END_PATTERN = {1, 1, 1};
    private final StringBuilder decodeRowStringBuffer;
    private final EANManufacturerOrgSupport eanManSupport;
    private final UPCEANExtensionSupport extensionReader;

    /* access modifiers changed from: protected */
    public abstract int decodeMiddle(BitArray bitArray, int[] iArr, StringBuilder sb) throws NotFoundException;

    /* access modifiers changed from: package-private */
    public abstract BarcodeFormat getBarcodeFormat();

    static {
        int[][] iArr = new int[10][];
        iArr[0] = new int[]{3, 2, 1, 1};
        int[][] iArr2 = iArr;
        iArr2[1] = new int[]{2, 2, 2, 1};
        int[][] iArr3 = iArr2;
        iArr3[2] = new int[]{2, 1, 2, 2};
        int[][] iArr4 = iArr3;
        iArr4[3] = new int[]{1, 4, 1, 1};
        int[][] iArr5 = iArr4;
        iArr5[4] = new int[]{1, 1, 3, 2};
        int[][] iArr6 = iArr5;
        iArr6[5] = new int[]{1, 2, 3, 1};
        int[][] iArr7 = iArr6;
        iArr7[6] = new int[]{1, 1, 1, 4};
        int[][] iArr8 = iArr7;
        iArr8[7] = new int[]{1, 3, 1, 2};
        int[][] iArr9 = iArr8;
        iArr9[8] = new int[]{1, 2, 1, 3};
        int[][] iArr10 = iArr9;
        iArr10[9] = new int[]{3, 1, 1, 2};
        L_PATTERNS = iArr10;
        System.arraycopy(L_PATTERNS, 0, L_AND_G_PATTERNS, 0, 10);
        for (int i = 10; i < 20; i++) {
            int[] widths = L_PATTERNS[i - 10];
            int[] reversedWidths = new int[widths.length];
            for (int j = 0; j < widths.length; j++) {
                reversedWidths[j] = widths[(widths.length - j) - 1];
            }
            L_AND_G_PATTERNS[i] = reversedWidths;
        }
    }

    protected UPCEANReader() {
        StringBuilder sb;
        UPCEANExtensionSupport uPCEANExtensionSupport;
        EANManufacturerOrgSupport eANManufacturerOrgSupport;
        new StringBuilder(20);
        this.decodeRowStringBuffer = sb;
        new UPCEANExtensionSupport();
        this.extensionReader = uPCEANExtensionSupport;
        new EANManufacturerOrgSupport();
        this.eanManSupport = eANManufacturerOrgSupport;
    }

    static int[] findStartGuardPattern(BitArray bitArray) throws NotFoundException {
        BitArray row = bitArray;
        boolean foundStart = false;
        int[] startRange = null;
        int nextStart = 0;
        int[] counters = new int[START_END_PATTERN.length];
        while (!foundStart) {
            Arrays.fill(counters, 0, START_END_PATTERN.length, 0);
            startRange = findGuardPattern(row, nextStart, false, START_END_PATTERN, counters);
            int start = startRange[0];
            nextStart = startRange[1];
            int quietStart = start - (nextStart - start);
            if (quietStart >= 0) {
                foundStart = row.isRange(quietStart, start, false);
            }
        }
        return startRange;
    }

    public Result decodeRow(int rowNumber, BitArray bitArray, Map<DecodeHintType, ?> hints) throws NotFoundException, ChecksumException, FormatException {
        BitArray row = bitArray;
        return decodeRow(rowNumber, row, findStartGuardPattern(row), hints);
    }

    public Result decodeRow(int i, BitArray bitArray, int[] iArr, Map<DecodeHintType, ?> map) throws NotFoundException, ChecksumException, FormatException {
        ResultPointCallback resultPointCallback;
        Result result;
        ResultPoint resultPoint;
        ResultPoint resultPoint2;
        ResultPoint resultPoint3;
        ResultPoint resultPoint4;
        ResultPoint resultPoint5;
        int rowNumber = i;
        BitArray row = bitArray;
        int[] startGuardRange = iArr;
        Map<DecodeHintType, ?> hints = map;
        if (hints == null) {
            resultPointCallback = null;
        } else {
            resultPointCallback = (ResultPointCallback) hints.get(DecodeHintType.NEED_RESULT_POINT_CALLBACK);
        }
        ResultPointCallback resultPointCallback2 = resultPointCallback;
        if (resultPointCallback2 != null) {
            new ResultPoint(((float) (startGuardRange[0] + startGuardRange[1])) / 2.0f, (float) rowNumber);
            resultPointCallback2.foundPossibleResultPoint(resultPoint5);
        }
        StringBuilder result2 = this.decodeRowStringBuffer;
        result2.setLength(0);
        int endStart = decodeMiddle(row, startGuardRange, result2);
        if (resultPointCallback2 != null) {
            new ResultPoint((float) endStart, (float) rowNumber);
            resultPointCallback2.foundPossibleResultPoint(resultPoint4);
        }
        int[] endRange = decodeEnd(row, endStart);
        if (resultPointCallback2 != null) {
            new ResultPoint(((float) (endRange[0] + endRange[1])) / 2.0f, (float) rowNumber);
            resultPointCallback2.foundPossibleResultPoint(resultPoint3);
        }
        int end = endRange[1];
        int quietEnd = end + (end - endRange[0]);
        if (quietEnd >= row.getSize() || !row.isRange(end, quietEnd, false)) {
            throw NotFoundException.getNotFoundInstance();
        }
        String resultString = result2.toString();
        if (!checkChecksum(resultString)) {
            throw ChecksumException.getChecksumInstance();
        }
        float left = ((float) (startGuardRange[1] + startGuardRange[0])) / 2.0f;
        float right = ((float) (endRange[1] + endRange[0])) / 2.0f;
        BarcodeFormat format = getBarcodeFormat();
        Result result3 = result;
        ResultPoint[] resultPointArr = new ResultPoint[2];
        new ResultPoint(left, (float) rowNumber);
        resultPointArr[0] = resultPoint;
        ResultPoint[] resultPointArr2 = resultPointArr;
        new ResultPoint(right, (float) rowNumber);
        resultPointArr2[1] = resultPoint2;
        new Result(resultString, (byte[]) null, resultPointArr2, format);
        Result decodeResult = result3;
        try {
            Result extensionResult = this.extensionReader.decodeRow(rowNumber, row, endRange[1]);
            decodeResult.putMetadata(ResultMetadataType.UPC_EAN_EXTENSION, extensionResult.getText());
            decodeResult.putAllMetadata(extensionResult.getResultMetadata());
            decodeResult.addResultPoints(extensionResult.getResultPoints());
        } catch (ReaderException e) {
            ReaderException readerException = e;
        }
        if (format == BarcodeFormat.EAN_13 || format == BarcodeFormat.UPC_A) {
            String countryID = this.eanManSupport.lookupCountryIdentifier(resultString);
            if (countryID != null) {
                decodeResult.putMetadata(ResultMetadataType.POSSIBLE_COUNTRY, countryID);
            }
        }
        return decodeResult;
    }

    /* access modifiers changed from: package-private */
    public boolean checkChecksum(String s) throws ChecksumException, FormatException {
        return checkStandardUPCEANChecksum(s);
    }

    static boolean checkStandardUPCEANChecksum(CharSequence charSequence) throws FormatException {
        CharSequence s = charSequence;
        int length = s.length();
        if (length == 0) {
            return false;
        }
        int sum = 0;
        for (int i = length - 2; i >= 0; i -= 2) {
            int digit = s.charAt(i) - '0';
            if (digit < 0 || digit > 9) {
                throw FormatException.getFormatInstance();
            }
            sum += digit;
        }
        int sum2 = sum * 3;
        for (int i2 = length - 1; i2 >= 0; i2 -= 2) {
            int digit2 = s.charAt(i2) - '0';
            if (digit2 < 0 || digit2 > 9) {
                throw FormatException.getFormatInstance();
            }
            sum2 += digit2;
        }
        return sum2 % 10 == 0;
    }

    /* access modifiers changed from: package-private */
    public int[] decodeEnd(BitArray row, int endStart) throws NotFoundException {
        return findGuardPattern(row, endStart, false, START_END_PATTERN);
    }

    static int[] findGuardPattern(BitArray row, int rowOffset, boolean whiteFirst, int[] iArr) throws NotFoundException {
        int[] pattern = iArr;
        return findGuardPattern(row, rowOffset, whiteFirst, pattern, new int[pattern.length]);
    }

    private static int[] findGuardPattern(BitArray bitArray, int i, boolean z, int[] iArr, int[] iArr2) throws NotFoundException {
        BitArray row = bitArray;
        int rowOffset = i;
        boolean whiteFirst = z;
        int[] pattern = iArr;
        int[] counters = iArr2;
        int patternLength = pattern.length;
        int width = row.getSize();
        boolean isWhite = whiteFirst;
        int rowOffset2 = whiteFirst ? row.getNextUnset(rowOffset) : row.getNextSet(rowOffset);
        int counterPosition = 0;
        int patternStart = rowOffset2;
        for (int x = rowOffset2; x < width; x++) {
            if (row.get(x) ^ isWhite) {
                int[] iArr3 = counters;
                int i2 = counterPosition;
                iArr3[i2] = iArr3[i2] + 1;
            } else {
                if (counterPosition != patternLength - 1) {
                    counterPosition++;
                } else if (patternMatchVariance(counters, pattern, MAX_INDIVIDUAL_VARIANCE) < MAX_AVG_VARIANCE) {
                    int[] iArr4 = new int[2];
                    iArr4[0] = patternStart;
                    int[] iArr5 = iArr4;
                    iArr5[1] = x;
                    return iArr5;
                } else {
                    patternStart += counters[0] + counters[1];
                    System.arraycopy(counters, 2, counters, 0, patternLength - 2);
                    counters[patternLength - 2] = 0;
                    counters[patternLength - 1] = 0;
                    counterPosition--;
                }
                counters[counterPosition] = 1;
                isWhite = !isWhite;
            }
        }
        throw NotFoundException.getNotFoundInstance();
    }

    static int decodeDigit(BitArray row, int[] iArr, int rowOffset, int[][] iArr2) throws NotFoundException {
        int[] counters = iArr;
        int[][] patterns = iArr2;
        recordPattern(row, rowOffset, counters);
        int bestVariance = MAX_AVG_VARIANCE;
        int bestMatch = -1;
        int max = patterns.length;
        for (int i = 0; i < max; i++) {
            int variance = patternMatchVariance(counters, patterns[i], MAX_INDIVIDUAL_VARIANCE);
            if (variance < bestVariance) {
                bestVariance = variance;
                bestMatch = i;
            }
        }
        if (bestMatch >= 0) {
            return bestMatch;
        }
        throw NotFoundException.getNotFoundInstance();
    }
}
