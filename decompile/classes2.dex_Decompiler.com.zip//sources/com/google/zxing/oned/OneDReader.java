package com.google.zxing.oned;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.ChecksumException;
import com.google.zxing.DecodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.Reader;
import com.google.zxing.ReaderException;
import com.google.zxing.Result;
import com.google.zxing.ResultMetadataType;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitArray;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.Map;

public abstract class OneDReader implements Reader {
    protected static final int INTEGER_MATH_SHIFT = 8;
    protected static final int PATTERN_MATCH_RESULT_SCALE_FACTOR = 256;

    public abstract Result decodeRow(int i, BitArray bitArray, Map<DecodeHintType, ?> map) throws NotFoundException, ChecksumException, FormatException;

    public OneDReader() {
    }

    public Result decode(BinaryBitmap image) throws NotFoundException, FormatException {
        return decode(image, (Map<DecodeHintType, ?>) null);
    }

    public Result decode(BinaryBitmap binaryBitmap, Map<DecodeHintType, ?> map) throws NotFoundException, FormatException {
        ResultPoint resultPoint;
        BinaryBitmap image = binaryBitmap;
        Map<DecodeHintType, ?> hints = map;
        try {
            return doDecode(image, hints);
        } catch (NotFoundException e) {
            NotFoundException nfe = e;
            if (!(hints != null && hints.containsKey(DecodeHintType.TRY_HARDER)) || !image.isRotateSupported()) {
                throw nfe;
            }
            BinaryBitmap rotatedImage = image.rotateCounterClockwise();
            Result result = doDecode(rotatedImage, hints);
            Map<ResultMetadataType, Object> resultMetadata = result.getResultMetadata();
            int orientation = 270;
            if (resultMetadata != null && resultMetadata.containsKey(ResultMetadataType.ORIENTATION)) {
                orientation = (270 + ((Integer) resultMetadata.get(ResultMetadataType.ORIENTATION)).intValue()) % 360;
            }
            result.putMetadata(ResultMetadataType.ORIENTATION, Integer.valueOf(orientation));
            ResultPoint[] points = result.getResultPoints();
            if (points != null) {
                int height = rotatedImage.getHeight();
                for (int i = 0; i < points.length; i++) {
                    new ResultPoint((((float) height) - points[i].getY()) - 1.0f, points[i].getX());
                    points[i] = resultPoint;
                }
            }
            return result;
        }
    }

    public void reset() {
    }

    private Result doDecode(BinaryBitmap binaryBitmap, Map<DecodeHintType, ?> map) throws NotFoundException {
        BitArray bitArray;
        int maxLines;
        ResultPoint resultPoint;
        ResultPoint resultPoint2;
        Map<DecodeHintType, Object> map2;
        BinaryBitmap image = binaryBitmap;
        Map<DecodeHintType, Object> hints = map;
        int width = image.getWidth();
        int height = image.getHeight();
        new BitArray(width);
        BitArray row = bitArray;
        int middle = height >> 1;
        boolean tryHarder = hints != null && hints.containsKey(DecodeHintType.TRY_HARDER);
        int rowStep = Math.max(1, height >> (tryHarder ? 8 : 5));
        if (tryHarder) {
            maxLines = height;
        } else {
            maxLines = 15;
        }
        for (int x = 0; x < maxLines; x++) {
            int rowStepsAboveOrBelow = (x + 1) >> 1;
            int rowNumber = middle + (rowStep * ((x & 1) == 0 ? rowStepsAboveOrBelow : -rowStepsAboveOrBelow));
            if (rowNumber < 0 || rowNumber >= height) {
                break;
            }
            try {
                row = image.getBlackRow(rowNumber, row);
                int attempt = 0;
                while (attempt < 2) {
                    if (attempt == 1) {
                        row.reverse();
                        if (hints != null && hints.containsKey(DecodeHintType.NEED_RESULT_POINT_CALLBACK)) {
                            new EnumMap<>(DecodeHintType.class);
                            Map<DecodeHintType, Object> newHints = map2;
                            newHints.putAll(hints);
                            Object remove = newHints.remove(DecodeHintType.NEED_RESULT_POINT_CALLBACK);
                            hints = newHints;
                        }
                    }
                    try {
                        Result result = decodeRow(rowNumber, row, hints);
                        if (attempt == 1) {
                            result.putMetadata(ResultMetadataType.ORIENTATION, 180);
                            ResultPoint[] points = result.getResultPoints();
                            if (points != null) {
                                new ResultPoint((((float) width) - points[0].getX()) - 1.0f, points[0].getY());
                                points[0] = resultPoint;
                                new ResultPoint((((float) width) - points[1].getX()) - 1.0f, points[1].getY());
                                points[1] = resultPoint2;
                            }
                        }
                        return result;
                    } catch (ReaderException e) {
                        ReaderException readerException = e;
                        attempt++;
                    }
                }
                continue;
            } catch (NotFoundException e2) {
                NotFoundException notFoundException = e2;
            }
        }
        throw NotFoundException.getNotFoundInstance();
    }

    protected static void recordPattern(BitArray bitArray, int i, int[] iArr) throws NotFoundException {
        BitArray row = bitArray;
        int start = i;
        int[] counters = iArr;
        int numCounters = counters.length;
        Arrays.fill(counters, 0, numCounters, 0);
        int end = row.getSize();
        if (start >= end) {
            throw NotFoundException.getNotFoundInstance();
        }
        boolean isWhite = !row.get(start);
        int counterPosition = 0;
        int i2 = start;
        while (i2 < end) {
            if (row.get(i2) ^ isWhite) {
                int[] iArr2 = counters;
                int i3 = counterPosition;
                iArr2[i3] = iArr2[i3] + 1;
            } else {
                counterPosition++;
                if (counterPosition == numCounters) {
                    break;
                }
                counters[counterPosition] = 1;
                isWhite = !isWhite;
            }
            i2++;
        }
        if (counterPosition == numCounters) {
            return;
        }
        if (counterPosition != numCounters - 1 || i2 != end) {
            throw NotFoundException.getNotFoundInstance();
        }
    }

    protected static void recordPatternInReverse(BitArray bitArray, int i, int[] iArr) throws NotFoundException {
        BitArray row = bitArray;
        int start = i;
        int[] counters = iArr;
        int numTransitionsLeft = counters.length;
        boolean last = row.get(start);
        while (start > 0 && numTransitionsLeft >= 0) {
            start--;
            if (row.get(start) != last) {
                numTransitionsLeft--;
                last = !last;
            }
        }
        if (numTransitionsLeft >= 0) {
            throw NotFoundException.getNotFoundInstance();
        }
        recordPattern(row, start + 1, counters);
    }

    protected static int patternMatchVariance(int[] iArr, int[] iArr2, int i) {
        int[] counters = iArr;
        int[] pattern = iArr2;
        int maxIndividualVariance = i;
        int numCounters = counters.length;
        int total = 0;
        int patternLength = 0;
        for (int i2 = 0; i2 < numCounters; i2++) {
            total += counters[i2];
            patternLength += pattern[i2];
        }
        if (total < patternLength) {
            return Integer.MAX_VALUE;
        }
        int unitBarWidth = (total << 8) / patternLength;
        int maxIndividualVariance2 = (maxIndividualVariance * unitBarWidth) >> 8;
        int totalVariance = 0;
        for (int x = 0; x < numCounters; x++) {
            int counter = counters[x] << 8;
            int scaledPattern = pattern[x] * unitBarWidth;
            int variance = counter > scaledPattern ? counter - scaledPattern : scaledPattern - counter;
            if (variance > maxIndividualVariance2) {
                return Integer.MAX_VALUE;
            }
            totalVariance += variance;
        }
        return totalVariance / total;
    }
}
