package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import java.util.Map;

public final class EAN13Writer extends UPCEANWriter {
    private static final int CODE_WIDTH = 95;

    public EAN13Writer() {
    }

    public BitMatrix encode(String str, BarcodeFormat barcodeFormat, int i, int i2, Map<EncodeHintType, ?> map) throws WriterException {
        Throwable th;
        StringBuilder sb;
        String contents = str;
        BarcodeFormat format = barcodeFormat;
        int width = i;
        int height = i2;
        Map<EncodeHintType, ?> hints = map;
        if (format == BarcodeFormat.EAN_13) {
            return super.encode(contents, format, width, height, hints);
        }
        Throwable th2 = th;
        new StringBuilder();
        new IllegalArgumentException(sb.append("Can only encode EAN_13, but got ").append(format).toString());
        throw th2;
    }

    public boolean[] encode(String str) {
        Throwable th;
        Throwable th2;
        Throwable th3;
        StringBuilder sb;
        String contents = str;
        if (contents.length() != 13) {
            Throwable th4 = th3;
            new StringBuilder();
            new IllegalArgumentException(sb.append("Requested contents should be 13 digits long, but got ").append(contents.length()).toString());
            throw th4;
        }
        try {
            if (!UPCEANReader.checkStandardUPCEANChecksum(contents)) {
                Throwable th5 = th2;
                new IllegalArgumentException("Contents do not pass checksum");
                throw th5;
            }
            int parities = EAN13Reader.FIRST_DIGIT_ENCODINGS[Integer.parseInt(contents.substring(0, 1))];
            boolean[] result = new boolean[CODE_WIDTH];
            int pos = 0 + appendPattern(result, 0, UPCEANReader.START_END_PATTERN, true);
            for (int i = 1; i <= 6; i++) {
                int digit = Integer.parseInt(contents.substring(i, i + 1));
                if (((parities >> (6 - i)) & 1) == 1) {
                    digit += 10;
                }
                pos += appendPattern(result, pos, UPCEANReader.L_AND_G_PATTERNS[digit], false);
            }
            int pos2 = pos + appendPattern(result, pos, UPCEANReader.MIDDLE_PATTERN, false);
            for (int i2 = 7; i2 <= 12; i2++) {
                pos2 += appendPattern(result, pos2, UPCEANReader.L_PATTERNS[Integer.parseInt(contents.substring(i2, i2 + 1))], true);
            }
            int pos3 = pos2 + appendPattern(result, pos2, UPCEANReader.START_END_PATTERN, true);
            return result;
        } catch (FormatException e) {
            FormatException formatException = e;
            Throwable th6 = th;
            new IllegalArgumentException("Illegal contents");
            throw th6;
        }
    }
}
