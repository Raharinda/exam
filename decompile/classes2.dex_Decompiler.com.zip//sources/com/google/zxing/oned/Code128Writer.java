package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

public final class Code128Writer extends OneDimensionalCodeWriter {
    private static final int CODE_CODE_B = 100;
    private static final int CODE_CODE_C = 99;
    private static final int CODE_FNC_1 = 102;
    private static final int CODE_FNC_2 = 97;
    private static final int CODE_FNC_3 = 96;
    private static final int CODE_FNC_4_B = 100;
    private static final int CODE_START_B = 104;
    private static final int CODE_START_C = 105;
    private static final int CODE_STOP = 106;
    private static final char ESCAPE_FNC_1 = 'ñ';
    private static final char ESCAPE_FNC_2 = 'ò';
    private static final char ESCAPE_FNC_3 = 'ó';
    private static final char ESCAPE_FNC_4 = 'ô';

    public Code128Writer() {
    }

    public BitMatrix encode(String str, BarcodeFormat barcodeFormat, int i, int i2, Map<EncodeHintType, ?> map) throws WriterException {
        Throwable th;
        StringBuilder sb;
        String contents = str;
        BarcodeFormat format = barcodeFormat;
        int width = i;
        int height = i2;
        Map<EncodeHintType, ?> hints = map;
        if (format == BarcodeFormat.CODE_128) {
            return super.encode(contents, format, width, height, hints);
        }
        Throwable th2 = th;
        new StringBuilder();
        new IllegalArgumentException(sb.append("Can only encode CODE_128, but got ").append(format).toString());
        throw th2;
    }

    public boolean[] encode(String str) {
        Throwable th;
        StringBuilder sb;
        Collection<int[]> collection;
        int patternIndex;
        Throwable th2;
        StringBuilder sb2;
        String contents = str;
        int length = contents.length();
        if (length < 1 || length > 80) {
            Throwable th3 = th;
            new StringBuilder();
            new IllegalArgumentException(sb.append("Contents length should be between 1 and 80 characters, but got ").append(length).toString());
            throw th3;
        }
        for (int i = 0; i < length; i++) {
            char c = contents.charAt(i);
            if (c < ' ' || c > '~') {
                switch (c) {
                    case 241:
                    case 242:
                    case 243:
                    case 244:
                        break;
                    default:
                        Throwable th4 = th2;
                        new StringBuilder();
                        new IllegalArgumentException(sb2.append("Bad character in input: ").append(c).toString());
                        throw th4;
                }
            }
        }
        new ArrayList<>();
        Collection<int[]> patterns = collection;
        int checkSum = 0;
        int checkWeight = 1;
        int codeSet = 0;
        int position = 0;
        while (position < length) {
            int newCodeSet = isDigits(contents, position, codeSet == CODE_CODE_C ? 2 : 4) ? CODE_CODE_C : 100;
            if (newCodeSet == codeSet) {
                if (codeSet != 100) {
                    switch (contents.charAt(position)) {
                        case 241:
                            patternIndex = CODE_FNC_1;
                            position++;
                            break;
                        case 242:
                            patternIndex = CODE_FNC_2;
                            position++;
                            break;
                        case 243:
                            patternIndex = CODE_FNC_3;
                            position++;
                            break;
                        case 244:
                            patternIndex = 100;
                            position++;
                            break;
                        default:
                            patternIndex = Integer.parseInt(contents.substring(position, position + 2));
                            position += 2;
                            break;
                    }
                } else {
                    patternIndex = contents.charAt(position) - ' ';
                    position++;
                }
            } else {
                if (codeSet == 0) {
                    patternIndex = newCodeSet == 100 ? CODE_START_B : CODE_START_C;
                } else {
                    patternIndex = newCodeSet;
                }
                codeSet = newCodeSet;
            }
            boolean add = patterns.add(Code128Reader.CODE_PATTERNS[patternIndex]);
            checkSum += patternIndex * checkWeight;
            if (position != 0) {
                checkWeight++;
            }
        }
        boolean add2 = patterns.add(Code128Reader.CODE_PATTERNS[checkSum % 103]);
        boolean add3 = patterns.add(Code128Reader.CODE_PATTERNS[CODE_STOP]);
        int codeWidth = 0;
        for (int[] arr$ : patterns) {
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                codeWidth += arr$[i$];
            }
        }
        boolean[] result = new boolean[codeWidth];
        int pos = 0;
        for (int[] pattern : patterns) {
            pos += appendPattern(result, pos, pattern, true);
        }
        return result;
    }

    private static boolean isDigits(CharSequence charSequence, int i, int length) {
        CharSequence value = charSequence;
        int start = i;
        int end = start + length;
        int last = value.length();
        int i2 = start;
        while (i2 < end && i2 < last) {
            char c = value.charAt(i2);
            if (c < '0' || c > '9') {
                if (c != 241) {
                    return false;
                }
                end++;
            }
            i2++;
        }
        return end <= last;
    }
}
