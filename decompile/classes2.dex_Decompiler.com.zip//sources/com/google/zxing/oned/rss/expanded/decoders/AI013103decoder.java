package com.google.zxing.oned.rss.expanded.decoders;

import com.google.zxing.common.BitArray;

final class AI013103decoder extends AI013x0xDecoder {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    AI013103decoder(BitArray information) {
        super(information);
    }

    /* access modifiers changed from: protected */
    public void addWeightCode(StringBuilder buf, int i) {
        int i2 = i;
        StringBuilder append = buf.append("(3103)");
    }

    /* access modifiers changed from: protected */
    public int checkWeight(int weight) {
        return weight;
    }
}
