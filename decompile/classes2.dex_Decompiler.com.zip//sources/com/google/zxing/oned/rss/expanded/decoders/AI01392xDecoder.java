package com.google.zxing.oned.rss.expanded.decoders;

import com.google.zxing.NotFoundException;
import com.google.zxing.common.BitArray;

final class AI01392xDecoder extends AI01decoder {
    private static final int HEADER_SIZE = 8;
    private static final int LAST_DIGIT_SIZE = 2;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    AI01392xDecoder(BitArray information) {
        super(information);
    }

    public String parseInformation() throws NotFoundException {
        StringBuilder sb;
        if (getInformation().getSize() < 48) {
            throw NotFoundException.getNotFoundInstance();
        }
        new StringBuilder();
        StringBuilder buf = sb;
        encodeCompressedGtin(buf, 8);
        int lastAIdigit = getGeneralDecoder().extractNumericValueFromBitArray(48, 2);
        StringBuilder append = buf.append("(392");
        StringBuilder append2 = buf.append(lastAIdigit);
        StringBuilder append3 = buf.append(')');
        StringBuilder append4 = buf.append(getGeneralDecoder().decodeGeneralPurposeField(50, (String) null).getNewString());
        return buf.toString();
    }
}
