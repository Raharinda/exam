package com.google.zxing.oned.rss.expanded.decoders;

import com.google.zxing.common.BitArray;

abstract class AI01weightDecoder extends AI01decoder {
    /* access modifiers changed from: protected */
    public abstract void addWeightCode(StringBuilder sb, int i);

    /* access modifiers changed from: protected */
    public abstract int checkWeight(int i);

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    AI01weightDecoder(BitArray information) {
        super(information);
    }

    /* access modifiers changed from: protected */
    public final void encodeCompressedWeight(StringBuilder sb, int currentPos, int weightSize) {
        StringBuilder buf = sb;
        int originalWeightNumeric = getGeneralDecoder().extractNumericValueFromBitArray(currentPos, weightSize);
        addWeightCode(buf, originalWeightNumeric);
        int weightNumeric = checkWeight(originalWeightNumeric);
        int currentDivisor = 100000;
        for (int i = 0; i < 5; i++) {
            if (weightNumeric / currentDivisor == 0) {
                StringBuilder append = buf.append('0');
            }
            currentDivisor /= 10;
        }
        StringBuilder append2 = buf.append(weightNumeric);
    }
}
