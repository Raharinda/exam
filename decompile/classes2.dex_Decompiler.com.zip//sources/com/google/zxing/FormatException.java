package com.google.zxing;

public final class FormatException extends ReaderException {
    private static final FormatException instance;

    static {
        FormatException formatException;
        new FormatException();
        instance = formatException;
    }

    private FormatException() {
    }

    public static FormatException getFormatInstance() {
        return instance;
    }
}
