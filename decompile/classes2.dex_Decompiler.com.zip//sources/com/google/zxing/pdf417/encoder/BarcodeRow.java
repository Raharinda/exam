package com.google.zxing.pdf417.encoder;

final class BarcodeRow {
    private int currentLocation = 0;
    private final byte[] row;

    BarcodeRow(int width) {
        this.row = new byte[width];
    }

    /* access modifiers changed from: package-private */
    public void set(int x, byte value) {
        this.row[x] = value;
    }

    /* access modifiers changed from: package-private */
    public void set(int x, boolean black) {
        this.row[x] = (byte) (black ? 1 : 0);
    }

    /* access modifiers changed from: package-private */
    public void addBar(boolean z, int i) {
        boolean black = z;
        int width = i;
        for (int ii = 0; ii < width; ii++) {
            int i2 = this.currentLocation;
            int i3 = i2 + 1;
            this.currentLocation = i3;
            set(i2, black);
        }
    }

    /* access modifiers changed from: package-private */
    public byte[] getRow() {
        return this.row;
    }

    /* access modifiers changed from: package-private */
    public byte[] getScaledRow(int i) {
        int scale = i;
        byte[] output = new byte[(this.row.length * scale)];
        for (int i2 = 0; i2 < output.length; i2++) {
            output[i2] = this.row[i2 / scale];
        }
        return output;
    }
}
