package com.google.zxing.pdf417.encoder;

import java.lang.reflect.Array;

final class BarcodeMatrix {
    private int currentRow;
    private final int height;
    private final BarcodeRow[] matrix;
    private final int width;

    BarcodeMatrix(int i, int i2) {
        BarcodeRow barcodeRow;
        int height2 = i;
        int width2 = i2;
        this.matrix = new BarcodeRow[(height2 + 2)];
        int matrixLength = this.matrix.length;
        for (int i3 = 0; i3 < matrixLength; i3++) {
            new BarcodeRow(((width2 + 4) * 17) + 1);
            this.matrix[i3] = barcodeRow;
        }
        this.width = width2 * 17;
        this.height = height2 + 2;
        this.currentRow = 0;
    }

    /* access modifiers changed from: package-private */
    public void set(int x, int y, byte value) {
        this.matrix[y].set(x, value);
    }

    /* access modifiers changed from: package-private */
    public void setMatrix(int x, int y, boolean black) {
        set(x, y, (byte) (black ? 1 : 0));
    }

    /* access modifiers changed from: package-private */
    public void startRow() {
        this.currentRow++;
    }

    /* access modifiers changed from: package-private */
    public BarcodeRow getCurrentRow() {
        return this.matrix[this.currentRow];
    }

    /* access modifiers changed from: package-private */
    public byte[][] getMatrix() {
        return getScaledMatrix(1, 1);
    }

    /* access modifiers changed from: package-private */
    public byte[][] getScaledMatrix(int i) {
        int Scale = i;
        return getScaledMatrix(Scale, Scale);
    }

    /* access modifiers changed from: package-private */
    public byte[][] getScaledMatrix(int i, int i2) {
        int xScale = i;
        int yScale = i2;
        byte[][] matrixOut = (byte[][]) Array.newInstance(Byte.TYPE, new int[]{this.height * yScale, this.width * xScale});
        int yMax = this.height * yScale;
        for (int ii = 0; ii < yMax; ii++) {
            matrixOut[(yMax - ii) - 1] = this.matrix[ii / yScale].getScaledRow(xScale);
        }
        return matrixOut;
    }
}
