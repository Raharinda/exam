package com.google.zxing.pdf417.encoder;

import com.google.zxing.WriterException;
import java.math.BigInteger;
import java.util.Arrays;

final class PDF417HighLevelEncoder {
    private static final int BYTE_COMPACTION = 1;
    private static final int LATCH_TO_BYTE = 924;
    private static final int LATCH_TO_BYTE_PADDED = 901;
    private static final int LATCH_TO_NUMERIC = 902;
    private static final int LATCH_TO_TEXT = 900;
    private static final byte[] MIXED = new byte[128];
    private static final int NUMERIC_COMPACTION = 2;
    private static final byte[] PUNCTUATION = new byte[128];
    private static final int SHIFT_TO_BYTE = 913;
    private static final int SUBMODE_ALPHA = 0;
    private static final int SUBMODE_LOWER = 1;
    private static final int SUBMODE_MIXED = 2;
    private static final int SUBMODE_PUNCTUATION = 3;
    private static final int TEXT_COMPACTION = 0;
    private static final byte[] TEXT_MIXED_RAW = {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 38, 13, 9, 44, 58, 35, 45, 46, 36, 47, 43, 37, 42, 61, 94, 0, 32, 0, 0, 0};
    private static final byte[] TEXT_PUNCTUATION_RAW = {59, 60, 62, 64, 91, 92, 93, 95, 96, 126, 33, 13, 9, 44, 58, 10, 45, 46, 36, 47, 34, 124, 42, 40, 41, 63, 123, 125, 39, 0};

    static {
        Arrays.fill(MIXED, (byte) -1);
        byte b = 0;
        while (true) {
            byte i = b;
            if (i >= TEXT_MIXED_RAW.length) {
                break;
            }
            byte b2 = TEXT_MIXED_RAW[i];
            if (b2 > 0) {
                MIXED[b2] = i;
            }
            b = (byte) (i + 1);
        }
        Arrays.fill(PUNCTUATION, (byte) -1);
        byte b3 = 0;
        while (true) {
            byte i2 = b3;
            if (i2 < TEXT_PUNCTUATION_RAW.length) {
                byte b4 = TEXT_PUNCTUATION_RAW[i2];
                if (b4 > 0) {
                    PUNCTUATION[b4] = i2;
                }
                b3 = (byte) (i2 + 1);
            } else {
                return;
            }
        }
    }

    private PDF417HighLevelEncoder() {
    }

    private static byte[] getBytesForMessage(String msg) {
        return msg.getBytes();
    }

    static String encodeHighLevel(String str, Compaction compaction) throws WriterException {
        StringBuilder sb;
        String msg = str;
        Compaction compaction2 = compaction;
        byte[] bytes = null;
        new StringBuilder(msg.length());
        StringBuilder sb2 = sb;
        int len = msg.length();
        int p = 0;
        int textSubMode = 0;
        if (compaction2 == Compaction.TEXT) {
            int encodeText = encodeText(msg, 0, len, sb2, 0);
        } else if (compaction2 == Compaction.BYTE) {
            byte[] bytes2 = getBytesForMessage(msg);
            encodeBinary(bytes2, 0, bytes2.length, 1, sb2);
        } else if (compaction2 == Compaction.NUMERIC) {
            StringBuilder append = sb2.append(902);
            encodeNumeric(msg, 0, len, sb2);
        } else {
            int encodingMode = 0;
            while (p < len) {
                int n = determineConsecutiveDigitCount(msg, p);
                if (n >= 13) {
                    StringBuilder append2 = sb2.append(902);
                    encodingMode = 2;
                    textSubMode = 0;
                    encodeNumeric(msg, p, n, sb2);
                    p += n;
                } else {
                    int t = determineConsecutiveTextCount(msg, p);
                    if (t >= 5 || n == len) {
                        if (encodingMode != 0) {
                            StringBuilder append3 = sb2.append(900);
                            encodingMode = 0;
                            textSubMode = 0;
                        }
                        textSubMode = encodeText(msg, p, t, sb2, textSubMode);
                        p += t;
                    } else {
                        if (bytes == null) {
                            bytes = getBytesForMessage(msg);
                        }
                        int b = determineConsecutiveBinaryCount(msg, bytes, p);
                        if (b == 0) {
                            b = 1;
                        }
                        if (b == 1 && encodingMode == 0) {
                            encodeBinary(bytes, p, 1, 0, sb2);
                        } else {
                            encodeBinary(bytes, p, b, encodingMode, sb2);
                            encodingMode = 1;
                            textSubMode = 0;
                        }
                        p += b;
                    }
                }
            }
        }
        return sb2.toString();
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static int encodeText(java.lang.CharSequence r16, int r17, int r18, java.lang.StringBuilder r19, int r20) {
        /*
            r0 = r16
            r1 = r17
            r2 = r18
            r3 = r19
            r4 = r20
            java.lang.StringBuilder r12 = new java.lang.StringBuilder
            r15 = r12
            r12 = r15
            r13 = r15
            r14 = r2
            r13.<init>(r14)
            r5 = r12
            r12 = r4
            r6 = r12
            r12 = 0
            r7 = r12
        L_0x0018:
            r12 = r0
            r13 = r1
            r14 = r7
            int r13 = r13 + r14
            char r12 = r12.charAt(r13)
            r8 = r12
            r12 = r6
            switch(r12) {
                case 0: goto L_0x006d;
                case 1: goto L_0x00c5;
                case 2: goto L_0x0128;
                default: goto L_0x0025;
            }
        L_0x0025:
            r12 = r8
            boolean r12 = isPunctuation(r12)
            if (r12 == 0) goto L_0x019b
            r12 = r5
            byte[] r13 = PUNCTUATION
            r14 = r8
            byte r13 = r13[r14]
            char r13 = (char) r13
            java.lang.StringBuilder r12 = r12.append(r13)
        L_0x0037:
            int r7 = r7 + 1
            r12 = r7
            r13 = r2
            if (r12 < r13) goto L_0x01a6
            r12 = 0
            r8 = r12
            r12 = r5
            int r12 = r12.length()
            r9 = r12
            r12 = 0
            r10 = r12
        L_0x0047:
            r12 = r10
            r13 = r9
            if (r12 >= r13) goto L_0x01b4
            r12 = r10
            r13 = 2
            int r12 = r12 % 2
            if (r12 == 0) goto L_0x01a8
            r12 = 1
        L_0x0052:
            r11 = r12
            r12 = r11
            if (r12 == 0) goto L_0x01ab
            r12 = r8
            r13 = 30
            int r12 = r12 * 30
            r13 = r5
            r14 = r10
            char r13 = r13.charAt(r14)
            int r12 = r12 + r13
            char r12 = (char) r12
            r8 = r12
            r12 = r3
            r13 = r8
            java.lang.StringBuilder r12 = r12.append(r13)
        L_0x006a:
            int r10 = r10 + 1
            goto L_0x0047
        L_0x006d:
            r12 = r8
            boolean r12 = isAlphaUpper(r12)
            if (r12 == 0) goto L_0x008d
            r12 = r8
            r13 = 32
            if (r12 != r13) goto L_0x0081
            r12 = r5
            r13 = 26
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0037
        L_0x0081:
            r12 = r5
            r13 = r8
            r14 = 65
            int r13 = r13 + -65
            char r13 = (char) r13
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0037
        L_0x008d:
            r12 = r8
            boolean r12 = isAlphaLower(r12)
            if (r12 == 0) goto L_0x009f
            r12 = 1
            r6 = r12
            r12 = r5
            r13 = 27
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0018
        L_0x009f:
            r12 = r8
            boolean r12 = isMixed(r12)
            if (r12 == 0) goto L_0x00b1
            r12 = 2
            r6 = r12
            r12 = r5
            r13 = 28
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0018
        L_0x00b1:
            r12 = r5
            r13 = 29
            java.lang.StringBuilder r12 = r12.append(r13)
            r12 = r5
            byte[] r13 = PUNCTUATION
            r14 = r8
            byte r13 = r13[r14]
            char r13 = (char) r13
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0037
        L_0x00c5:
            r12 = r8
            boolean r12 = isAlphaLower(r12)
            if (r12 == 0) goto L_0x00e7
            r12 = r8
            r13 = 32
            if (r12 != r13) goto L_0x00da
            r12 = r5
            r13 = 26
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0037
        L_0x00da:
            r12 = r5
            r13 = r8
            r14 = 97
            int r13 = r13 + -97
            char r13 = (char) r13
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0037
        L_0x00e7:
            r12 = r8
            boolean r12 = isAlphaUpper(r12)
            if (r12 == 0) goto L_0x0102
            r12 = r5
            r13 = 27
            java.lang.StringBuilder r12 = r12.append(r13)
            r12 = r5
            r13 = r8
            r14 = 65
            int r13 = r13 + -65
            char r13 = (char) r13
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0037
        L_0x0102:
            r12 = r8
            boolean r12 = isMixed(r12)
            if (r12 == 0) goto L_0x0114
            r12 = 2
            r6 = r12
            r12 = r5
            r13 = 28
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0018
        L_0x0114:
            r12 = r5
            r13 = 29
            java.lang.StringBuilder r12 = r12.append(r13)
            r12 = r5
            byte[] r13 = PUNCTUATION
            r14 = r8
            byte r13 = r13[r14]
            char r13 = (char) r13
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0037
        L_0x0128:
            r12 = r8
            boolean r12 = isMixed(r12)
            if (r12 == 0) goto L_0x013c
            r12 = r5
            byte[] r13 = MIXED
            r14 = r8
            byte r13 = r13[r14]
            char r13 = (char) r13
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0037
        L_0x013c:
            r12 = r8
            boolean r12 = isAlphaUpper(r12)
            if (r12 == 0) goto L_0x014e
            r12 = 0
            r6 = r12
            r12 = r5
            r13 = 28
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0018
        L_0x014e:
            r12 = r8
            boolean r12 = isAlphaLower(r12)
            if (r12 == 0) goto L_0x0160
            r12 = 1
            r6 = r12
            r12 = r5
            r13 = 27
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0018
        L_0x0160:
            r12 = r1
            r13 = r7
            int r12 = r12 + r13
            r13 = 1
            int r12 = r12 + 1
            r13 = r2
            if (r12 >= r13) goto L_0x0187
            r12 = r0
            r13 = r1
            r14 = r7
            int r13 = r13 + r14
            r14 = 1
            int r13 = r13 + 1
            char r12 = r12.charAt(r13)
            r9 = r12
            r12 = r9
            boolean r12 = isPunctuation(r12)
            if (r12 == 0) goto L_0x0187
            r12 = 3
            r6 = r12
            r12 = r5
            r13 = 25
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0018
        L_0x0187:
            r12 = r5
            r13 = 29
            java.lang.StringBuilder r12 = r12.append(r13)
            r12 = r5
            byte[] r13 = PUNCTUATION
            r14 = r8
            byte r13 = r13[r14]
            char r13 = (char) r13
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0037
        L_0x019b:
            r12 = 0
            r6 = r12
            r12 = r5
            r13 = 29
            java.lang.StringBuilder r12 = r12.append(r13)
            goto L_0x0018
        L_0x01a6:
            goto L_0x0018
        L_0x01a8:
            r12 = 0
            goto L_0x0052
        L_0x01ab:
            r12 = r5
            r13 = r10
            char r12 = r12.charAt(r13)
            r8 = r12
            goto L_0x006a
        L_0x01b4:
            r12 = r9
            r13 = 2
            int r12 = r12 % 2
            if (r12 == 0) goto L_0x01c9
            r12 = r3
            r13 = r8
            r14 = 30
            int r13 = r13 * 30
            r14 = 29
            int r13 = r13 + 29
            char r13 = (char) r13
            java.lang.StringBuilder r12 = r12.append(r13)
        L_0x01c9:
            r12 = r6
            r0 = r12
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.pdf417.encoder.PDF417HighLevelEncoder.encodeText(java.lang.CharSequence, int, int, java.lang.StringBuilder, int):int");
    }

    private static void encodeBinary(byte[] bArr, int i, int i2, int i3, StringBuilder sb) {
        byte[] bytes = bArr;
        int startpos = i;
        int count = i2;
        int startmode = i3;
        StringBuilder sb2 = sb;
        if (count == 1 && startmode == 0) {
            StringBuilder append = sb2.append(913);
        }
        int idx = startpos;
        if (count >= 6) {
            StringBuilder append2 = sb2.append(924);
            char[] chars = new char[5];
            while ((startpos + count) - idx >= 6) {
                long t = 0;
                for (int i4 = 0; i4 < 6; i4++) {
                    t = (t << 8) + ((long) (bytes[idx + i4] & 255));
                }
                for (int i5 = 0; i5 < 5; i5++) {
                    chars[i5] = (char) ((int) (t % 900));
                    t /= 900;
                }
                for (int i6 = chars.length - 1; i6 >= 0; i6--) {
                    StringBuilder append3 = sb2.append(chars[i6]);
                }
                idx += 6;
            }
        }
        if (idx < startpos + count) {
            StringBuilder append4 = sb2.append(901);
        }
        for (int i7 = idx; i7 < startpos + count; i7++) {
            StringBuilder append5 = sb2.append((char) (bytes[i7] & 255));
        }
    }

    private static void encodeNumeric(String str, int i, int i2, StringBuilder sb) {
        StringBuilder sb2;
        StringBuilder sb3;
        BigInteger bigInteger;
        String msg = str;
        int startpos = i;
        int count = i2;
        StringBuilder sb4 = sb;
        int idx = 0;
        new StringBuilder((count / 3) + 1);
        StringBuilder tmp = sb2;
        BigInteger num900 = BigInteger.valueOf(900);
        BigInteger num0 = BigInteger.valueOf(0);
        while (idx < count - 1) {
            tmp.setLength(0);
            int len = Math.min(44, count - idx);
            new StringBuilder();
            new BigInteger(sb3.append('1').append(msg.substring(startpos + idx, startpos + idx + len)).toString());
            BigInteger bigint = bigInteger;
            do {
                StringBuilder append = tmp.append((char) bigint.mod(num900).intValue());
                bigint = bigint.divide(num900);
            } while (!bigint.equals(num0));
            for (int i3 = tmp.length() - 1; i3 >= 0; i3--) {
                StringBuilder append2 = sb4.append(tmp.charAt(i3));
            }
            idx += len;
        }
    }

    private static boolean isDigit(char c) {
        char ch = c;
        return ch >= '0' && ch <= '9';
    }

    private static boolean isAlphaUpper(char c) {
        char ch = c;
        return ch == ' ' || (ch >= 'A' && ch <= 'Z');
    }

    private static boolean isAlphaLower(char c) {
        char ch = c;
        return ch == ' ' || (ch >= 'a' && ch <= 'z');
    }

    private static boolean isMixed(char ch) {
        return MIXED[ch] != -1;
    }

    private static boolean isPunctuation(char ch) {
        return PUNCTUATION[ch] != -1;
    }

    private static boolean isText(char c) {
        char ch = c;
        return ch == 9 || ch == 10 || ch == 13 || (ch >= ' ' && ch <= '~');
    }

    private static int determineConsecutiveDigitCount(CharSequence charSequence, int startpos) {
        CharSequence msg = charSequence;
        int count = 0;
        int len = msg.length();
        int idx = startpos;
        if (idx < len) {
            char ch = msg.charAt(idx);
            while (isDigit(ch) && idx < len) {
                count++;
                idx++;
                if (idx < len) {
                    ch = msg.charAt(idx);
                }
            }
        }
        return count;
    }

    private static int determineConsecutiveTextCount(CharSequence charSequence, int i) {
        CharSequence msg = charSequence;
        int startpos = i;
        int len = msg.length();
        int idx = startpos;
        while (idx < len) {
            char ch = msg.charAt(idx);
            int numericCount = 0;
            while (numericCount < 13 && isDigit(ch) && idx < len) {
                numericCount++;
                idx++;
                if (idx < len) {
                    ch = msg.charAt(idx);
                }
            }
            if (numericCount >= 13) {
                return (idx - startpos) - numericCount;
            }
            if (numericCount <= 0) {
                if (!isText(msg.charAt(idx))) {
                    break;
                }
                idx++;
            }
        }
        return idx - startpos;
    }

    private static int determineConsecutiveBinaryCount(CharSequence charSequence, byte[] bArr, int i) throws WriterException {
        Throwable th;
        StringBuilder sb;
        CharSequence msg = charSequence;
        byte[] bytes = bArr;
        int startpos = i;
        int len = msg.length();
        int idx = startpos;
        while (idx < len) {
            char ch = msg.charAt(idx);
            int numericCount = 0;
            while (numericCount < 13 && isDigit(ch)) {
                numericCount++;
                int i2 = idx + numericCount;
                if (i2 >= len) {
                    break;
                }
                ch = msg.charAt(i2);
            }
            if (numericCount >= 13) {
                return idx - startpos;
            }
            int textCount = 0;
            while (textCount < 5 && isText(ch)) {
                textCount++;
                int i3 = idx + textCount;
                if (i3 >= len) {
                    break;
                }
                ch = msg.charAt(i3);
            }
            if (textCount >= 5) {
                return idx - startpos;
            }
            char ch2 = msg.charAt(idx);
            if (bytes[idx] != 63 || ch2 == '?') {
                idx++;
            } else {
                Throwable th2 = th;
                new StringBuilder();
                new WriterException(sb.append("Non-encodable character detected: ").append(ch2).append(" (Unicode: ").append(ch2).append(')').toString());
                throw th2;
            }
        }
        return idx - startpos;
    }
}
