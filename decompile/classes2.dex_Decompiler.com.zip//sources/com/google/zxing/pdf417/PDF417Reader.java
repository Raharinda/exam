package com.google.zxing.pdf417;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.ChecksumException;
import com.google.zxing.DecodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.Reader;
import com.google.zxing.Result;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.common.DetectorResult;
import com.google.zxing.pdf417.decoder.Decoder;
import com.google.zxing.pdf417.detector.Detector;
import java.util.Map;

public final class PDF417Reader implements Reader {
    private static final ResultPoint[] NO_POINTS = new ResultPoint[0];
    private final Decoder decoder;

    public PDF417Reader() {
        Decoder decoder2;
        new Decoder();
        this.decoder = decoder2;
    }

    public Result decode(BinaryBitmap image) throws NotFoundException, FormatException, ChecksumException {
        return decode(image, (Map<DecodeHintType, ?>) null);
    }

    public Result decode(BinaryBitmap binaryBitmap, Map<DecodeHintType, ?> map) throws NotFoundException, FormatException, ChecksumException {
        Detector detector;
        DecoderResult decoderResult;
        ResultPoint[] points;
        Result result;
        BinaryBitmap image = binaryBitmap;
        Map<DecodeHintType, ?> hints = map;
        if (hints == null || !hints.containsKey(DecodeHintType.PURE_BARCODE)) {
            new Detector(image);
            DetectorResult detectorResult = detector.detect();
            decoderResult = this.decoder.decode(detectorResult.getBits());
            points = detectorResult.getPoints();
        } else {
            decoderResult = this.decoder.decode(extractPureBits(image.getBlackMatrix()));
            points = NO_POINTS;
        }
        new Result(decoderResult.getText(), decoderResult.getRawBytes(), points, BarcodeFormat.PDF_417);
        return result;
    }

    public void reset() {
    }

    private static BitMatrix extractPureBits(BitMatrix bitMatrix) throws NotFoundException {
        BitMatrix bitMatrix2;
        BitMatrix image = bitMatrix;
        int[] leftTopBlack = image.getTopLeftOnBit();
        int[] rightBottomBlack = image.getBottomRightOnBit();
        if (leftTopBlack == null || rightBottomBlack == null) {
            throw NotFoundException.getNotFoundInstance();
        }
        int moduleSize = moduleSize(leftTopBlack, image);
        int top = leftTopBlack[1];
        int bottom = rightBottomBlack[1];
        int left = findPatternStart(leftTopBlack[0], top, image);
        int matrixWidth = ((findPatternEnd(leftTopBlack[0], top, image) - left) + 1) / moduleSize;
        int matrixHeight = ((bottom - top) + 1) / moduleSize;
        if (matrixWidth <= 0 || matrixHeight <= 0) {
            throw NotFoundException.getNotFoundInstance();
        }
        int nudge = moduleSize >> 1;
        int top2 = top + nudge;
        int left2 = left + nudge;
        new BitMatrix(matrixWidth, matrixHeight);
        BitMatrix bits = bitMatrix2;
        for (int y = 0; y < matrixHeight; y++) {
            int iOffset = top2 + (y * moduleSize);
            for (int x = 0; x < matrixWidth; x++) {
                if (image.get(left2 + (x * moduleSize), iOffset)) {
                    bits.set(x, y);
                }
            }
        }
        return bits;
    }

    private static int moduleSize(int[] iArr, BitMatrix bitMatrix) throws NotFoundException {
        int[] leftTopBlack = iArr;
        BitMatrix image = bitMatrix;
        int x = leftTopBlack[0];
        int y = leftTopBlack[1];
        int width = image.getWidth();
        while (x < width && image.get(x, y)) {
            x++;
        }
        if (x == width) {
            throw NotFoundException.getNotFoundInstance();
        }
        int moduleSize = (x - leftTopBlack[0]) >>> 3;
        if (moduleSize != 0) {
            return moduleSize;
        }
        throw NotFoundException.getNotFoundInstance();
    }

    private static int findPatternStart(int x, int i, BitMatrix bitMatrix) throws NotFoundException {
        int y = i;
        BitMatrix image = bitMatrix;
        int width = image.getWidth();
        int start = x;
        int transitions = 0;
        boolean z = true;
        while (true) {
            boolean black = z;
            if (start < width - 1 && transitions < 8) {
                start++;
                boolean newBlack = image.get(start, y);
                if (black != newBlack) {
                    transitions++;
                }
                z = newBlack;
            }
        }
        if (start != width - 1) {
            return start;
        }
        throw NotFoundException.getNotFoundInstance();
    }

    private static int findPatternEnd(int i, int i2, BitMatrix bitMatrix) throws NotFoundException {
        int x = i;
        int y = i2;
        BitMatrix image = bitMatrix;
        int end = image.getWidth() - 1;
        while (end > x && !image.get(end, y)) {
            end--;
        }
        int transitions = 0;
        boolean z = true;
        while (true) {
            boolean black = z;
            if (end > x && transitions < 9) {
                end--;
                boolean newBlack = image.get(end, y);
                if (black != newBlack) {
                    transitions++;
                }
                z = newBlack;
            }
        }
        if (end != x) {
            return end;
        }
        throw NotFoundException.getNotFoundInstance();
    }
}
