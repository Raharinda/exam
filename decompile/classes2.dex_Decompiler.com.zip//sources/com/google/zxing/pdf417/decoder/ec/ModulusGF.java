package com.google.zxing.pdf417.decoder.ec;

public final class ModulusGF {
    public static final ModulusGF PDF417_GF;
    private final int[] expTable;
    private final int[] logTable;
    private final int modulus;
    private final ModulusPoly one;
    private final ModulusPoly zero;

    static {
        ModulusGF modulusGF;
        new ModulusGF(929, 3);
        PDF417_GF = modulusGF;
    }

    public ModulusGF(int i, int i2) {
        ModulusPoly modulusPoly;
        ModulusPoly modulusPoly2;
        int modulus2 = i;
        int generator = i2;
        this.modulus = modulus2;
        this.expTable = new int[modulus2];
        this.logTable = new int[modulus2];
        int x = 1;
        for (int i3 = 0; i3 < modulus2; i3++) {
            this.expTable[i3] = x;
            x = (x * generator) % modulus2;
        }
        for (int i4 = 0; i4 < modulus2 - 1; i4++) {
            this.logTable[this.expTable[i4]] = i4;
        }
        new ModulusPoly(this, new int[]{0});
        this.zero = modulusPoly;
        new ModulusPoly(this, new int[]{1});
        this.one = modulusPoly2;
    }

    /* access modifiers changed from: package-private */
    public ModulusPoly getZero() {
        return this.zero;
    }

    /* access modifiers changed from: package-private */
    public ModulusPoly getOne() {
        return this.one;
    }

    /* access modifiers changed from: package-private */
    public ModulusPoly buildMonomial(int i, int i2) {
        ModulusPoly modulusPoly;
        Throwable th;
        int degree = i;
        int coefficient = i2;
        if (degree < 0) {
            Throwable th2 = th;
            new IllegalArgumentException();
            throw th2;
        } else if (coefficient == 0) {
            return this.zero;
        } else {
            int[] coefficients = new int[(degree + 1)];
            coefficients[0] = coefficient;
            new ModulusPoly(this, coefficients);
            return modulusPoly;
        }
    }

    /* access modifiers changed from: package-private */
    public int add(int a, int b) {
        return (a + b) % this.modulus;
    }

    /* access modifiers changed from: package-private */
    public int subtract(int a, int b) {
        return ((this.modulus + a) - b) % this.modulus;
    }

    /* access modifiers changed from: package-private */
    public int exp(int a) {
        return this.expTable[a];
    }

    /* access modifiers changed from: package-private */
    public int log(int i) {
        Throwable th;
        int a = i;
        if (a != 0) {
            return this.logTable[a];
        }
        Throwable th2 = th;
        new IllegalArgumentException();
        throw th2;
    }

    /* access modifiers changed from: package-private */
    public int inverse(int i) {
        Throwable th;
        int a = i;
        if (a != 0) {
            return this.expTable[(this.modulus - this.logTable[a]) - 1];
        }
        Throwable th2 = th;
        new ArithmeticException();
        throw th2;
    }

    /* access modifiers changed from: package-private */
    public int multiply(int i, int i2) {
        int a = i;
        int b = i2;
        if (a == 0 || b == 0) {
            return 0;
        }
        return this.expTable[(this.logTable[a] + this.logTable[b]) % (this.modulus - 1)];
    }

    /* access modifiers changed from: package-private */
    public int getSize() {
        return this.modulus;
    }
}
