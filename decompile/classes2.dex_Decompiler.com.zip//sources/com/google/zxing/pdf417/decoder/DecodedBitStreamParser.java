package com.google.zxing.pdf417.decoder;

import com.google.zxing.FormatException;
import com.google.zxing.common.DecoderResult;
import java.math.BigInteger;
import java.util.List;

final class DecodedBitStreamParser {
    private static final int AL = 28;
    private static final int AS = 27;
    private static final int BEGIN_MACRO_PDF417_CONTROL_BLOCK = 928;
    private static final int BEGIN_MACRO_PDF417_OPTIONAL_FIELD = 923;
    private static final int BYTE_COMPACTION_MODE_LATCH = 901;
    private static final int BYTE_COMPACTION_MODE_LATCH_6 = 924;
    private static final BigInteger[] EXP900 = new BigInteger[16];
    private static final int LL = 27;
    private static final int MACRO_PDF417_TERMINATOR = 922;
    private static final int MAX_NUMERIC_CODEWORDS = 15;
    private static final char[] MIXED_CHARS;
    private static final int ML = 28;
    private static final int MODE_SHIFT_TO_BYTE_COMPACTION_MODE = 913;
    private static final int NUMERIC_COMPACTION_MODE_LATCH = 902;
    private static final int PAL = 29;
    private static final int PL = 25;
    private static final int PS = 29;
    private static final char[] PUNCT_CHARS = {';', '<', '>', '@', '[', '\\', '}', '_', '`', '~', '!', 13, 9, ',', ':', 10, '-', '.', '$', '/', '\"', '|', '*', '(', ')', '?', '{', '}', '\''};
    private static final int TEXT_COMPACTION_MODE_LATCH = 900;

    private enum Mode {
    }

    static {
        char[] cArr = new char[PL];
        // fill-array-data instruction
        cArr[0] = 48;
        cArr[1] = 49;
        cArr[2] = 50;
        cArr[3] = 51;
        cArr[4] = 52;
        cArr[5] = 53;
        cArr[6] = 54;
        cArr[7] = 55;
        cArr[8] = 56;
        cArr[9] = 57;
        cArr[10] = 38;
        cArr[11] = 13;
        cArr[12] = 9;
        cArr[13] = 44;
        cArr[14] = 58;
        cArr[15] = 35;
        cArr[16] = 45;
        cArr[17] = 46;
        cArr[18] = 36;
        cArr[19] = 47;
        cArr[20] = 43;
        cArr[21] = 37;
        cArr[22] = 42;
        cArr[23] = 61;
        cArr[24] = 94;
        MIXED_CHARS = cArr;
        EXP900[0] = BigInteger.ONE;
        BigInteger nineHundred = BigInteger.valueOf(900);
        EXP900[1] = nineHundred;
        for (int i = 2; i < EXP900.length; i++) {
            EXP900[i] = EXP900[i - 1].multiply(nineHundred);
        }
    }

    private DecodedBitStreamParser() {
    }

    static DecoderResult decode(int[] iArr) throws FormatException {
        StringBuilder sb;
        DecoderResult decoderResult;
        int codeIndex;
        int[] codewords = iArr;
        new StringBuilder(100);
        StringBuilder result = sb;
        int codeIndex2 = 1 + 1;
        int i = codewords[1];
        while (true) {
            int code = i;
            if (codeIndex2 < codewords[0]) {
                switch (code) {
                    case TEXT_COMPACTION_MODE_LATCH /*900*/:
                        codeIndex = textCompaction(codewords, codeIndex2, result);
                        break;
                    case BYTE_COMPACTION_MODE_LATCH /*901*/:
                        codeIndex = byteCompaction(code, codewords, codeIndex2, result);
                        break;
                    case NUMERIC_COMPACTION_MODE_LATCH /*902*/:
                        codeIndex = numericCompaction(codewords, codeIndex2, result);
                        break;
                    case MODE_SHIFT_TO_BYTE_COMPACTION_MODE /*913*/:
                        codeIndex = byteCompaction(code, codewords, codeIndex2, result);
                        break;
                    case BYTE_COMPACTION_MODE_LATCH_6 /*924*/:
                        codeIndex = byteCompaction(code, codewords, codeIndex2, result);
                        break;
                    default:
                        codeIndex = textCompaction(codewords, codeIndex2 - 1, result);
                        break;
                }
                if (codeIndex < codewords.length) {
                    int i2 = codeIndex;
                    codeIndex2 = codeIndex + 1;
                    i = codewords[i2];
                } else {
                    throw FormatException.getFormatInstance();
                }
            } else if (result.length() == 0) {
                throw FormatException.getFormatInstance();
            } else {
                new DecoderResult((byte[]) null, result.toString(), (List<byte[]>) null, (String) null);
                return decoderResult;
            }
        }
    }

    private static int textCompaction(int[] iArr, int i, StringBuilder sb) {
        int[] codewords = iArr;
        int codeIndex = i;
        StringBuilder result = sb;
        int[] textCompactionData = new int[(codewords[0] << 1)];
        int[] byteCompactionData = new int[(codewords[0] << 1)];
        int index = 0;
        boolean end = false;
        while (codeIndex < codewords[0] && !end) {
            int i2 = codeIndex;
            codeIndex++;
            int code = codewords[i2];
            if (code >= TEXT_COMPACTION_MODE_LATCH) {
                switch (code) {
                    case TEXT_COMPACTION_MODE_LATCH /*900*/:
                        int i3 = index;
                        index++;
                        textCompactionData[i3] = TEXT_COMPACTION_MODE_LATCH;
                        break;
                    case BYTE_COMPACTION_MODE_LATCH /*901*/:
                        codeIndex--;
                        end = true;
                        break;
                    case NUMERIC_COMPACTION_MODE_LATCH /*902*/:
                        codeIndex--;
                        end = true;
                        break;
                    case MODE_SHIFT_TO_BYTE_COMPACTION_MODE /*913*/:
                        textCompactionData[index] = MODE_SHIFT_TO_BYTE_COMPACTION_MODE;
                        int i4 = codeIndex;
                        codeIndex++;
                        byteCompactionData[index] = codewords[i4];
                        index++;
                        break;
                    case BYTE_COMPACTION_MODE_LATCH_6 /*924*/:
                        codeIndex--;
                        end = true;
                        break;
                }
            } else {
                textCompactionData[index] = code / 30;
                textCompactionData[index + 1] = code % 30;
                index += 2;
            }
        }
        decodeTextCompaction(textCompactionData, byteCompactionData, index, result);
        return codeIndex;
    }

    private static void decodeTextCompaction(int[] iArr, int[] iArr2, int i, StringBuilder sb) {
        int[] textCompactionData = iArr;
        int[] byteCompactionData = iArr2;
        int length = i;
        StringBuilder result = sb;
        Mode subMode = Mode.ALPHA;
        Mode priorToShiftMode = Mode.ALPHA;
        for (int i2 = 0; i2 < length; i2++) {
            int subModeCh = textCompactionData[i2];
            char ch = 0;
            switch (subMode) {
                case ALPHA:
                    if (subModeCh >= 26) {
                        if (subModeCh != 26) {
                            if (subModeCh != 27) {
                                if (subModeCh != 28) {
                                    if (subModeCh != 29) {
                                        if (subModeCh != MODE_SHIFT_TO_BYTE_COMPACTION_MODE) {
                                            if (subModeCh == TEXT_COMPACTION_MODE_LATCH) {
                                                subMode = Mode.ALPHA;
                                                break;
                                            }
                                        } else {
                                            StringBuilder append = result.append((char) byteCompactionData[i2]);
                                            break;
                                        }
                                    } else {
                                        priorToShiftMode = subMode;
                                        subMode = Mode.PUNCT_SHIFT;
                                        break;
                                    }
                                } else {
                                    subMode = Mode.MIXED;
                                    break;
                                }
                            } else {
                                subMode = Mode.LOWER;
                                break;
                            }
                        } else {
                            ch = ' ';
                            break;
                        }
                    } else {
                        ch = (char) (65 + subModeCh);
                        break;
                    }
                    break;
                case LOWER:
                    if (subModeCh >= 26) {
                        if (subModeCh != 26) {
                            if (subModeCh != 27) {
                                if (subModeCh != 28) {
                                    if (subModeCh != 29) {
                                        if (subModeCh != MODE_SHIFT_TO_BYTE_COMPACTION_MODE) {
                                            if (subModeCh == TEXT_COMPACTION_MODE_LATCH) {
                                                subMode = Mode.ALPHA;
                                                break;
                                            }
                                        } else {
                                            StringBuilder append2 = result.append((char) byteCompactionData[i2]);
                                            break;
                                        }
                                    } else {
                                        priorToShiftMode = subMode;
                                        subMode = Mode.PUNCT_SHIFT;
                                        break;
                                    }
                                } else {
                                    subMode = Mode.MIXED;
                                    break;
                                }
                            } else {
                                priorToShiftMode = subMode;
                                subMode = Mode.ALPHA_SHIFT;
                                break;
                            }
                        } else {
                            ch = ' ';
                            break;
                        }
                    } else {
                        ch = (char) (97 + subModeCh);
                        break;
                    }
                    break;
                case MIXED:
                    if (subModeCh >= PL) {
                        if (subModeCh != PL) {
                            if (subModeCh != 26) {
                                if (subModeCh != 27) {
                                    if (subModeCh != 28) {
                                        if (subModeCh != 29) {
                                            if (subModeCh != MODE_SHIFT_TO_BYTE_COMPACTION_MODE) {
                                                if (subModeCh == TEXT_COMPACTION_MODE_LATCH) {
                                                    subMode = Mode.ALPHA;
                                                    break;
                                                }
                                            } else {
                                                StringBuilder append3 = result.append((char) byteCompactionData[i2]);
                                                break;
                                            }
                                        } else {
                                            priorToShiftMode = subMode;
                                            subMode = Mode.PUNCT_SHIFT;
                                            break;
                                        }
                                    } else {
                                        subMode = Mode.ALPHA;
                                        break;
                                    }
                                } else {
                                    subMode = Mode.LOWER;
                                    break;
                                }
                            } else {
                                ch = ' ';
                                break;
                            }
                        } else {
                            subMode = Mode.PUNCT;
                            break;
                        }
                    } else {
                        ch = MIXED_CHARS[subModeCh];
                        break;
                    }
                    break;
                case PUNCT:
                    if (subModeCh >= 29) {
                        if (subModeCh != 29) {
                            if (subModeCh != MODE_SHIFT_TO_BYTE_COMPACTION_MODE) {
                                if (subModeCh == TEXT_COMPACTION_MODE_LATCH) {
                                    subMode = Mode.ALPHA;
                                    break;
                                }
                            } else {
                                StringBuilder append4 = result.append((char) byteCompactionData[i2]);
                                break;
                            }
                        } else {
                            subMode = Mode.ALPHA;
                            break;
                        }
                    } else {
                        ch = PUNCT_CHARS[subModeCh];
                        break;
                    }
                    break;
                case ALPHA_SHIFT:
                    subMode = priorToShiftMode;
                    if (subModeCh >= 26) {
                        if (subModeCh != 26) {
                            if (subModeCh == TEXT_COMPACTION_MODE_LATCH) {
                                subMode = Mode.ALPHA;
                                break;
                            }
                        } else {
                            ch = ' ';
                            break;
                        }
                    } else {
                        ch = (char) (65 + subModeCh);
                        break;
                    }
                    break;
                case PUNCT_SHIFT:
                    subMode = priorToShiftMode;
                    if (subModeCh >= 29) {
                        if (subModeCh != 29) {
                            if (subModeCh != MODE_SHIFT_TO_BYTE_COMPACTION_MODE) {
                                if (subModeCh == TEXT_COMPACTION_MODE_LATCH) {
                                    subMode = Mode.ALPHA;
                                    break;
                                }
                            } else {
                                StringBuilder append5 = result.append((char) byteCompactionData[i2]);
                                break;
                            }
                        } else {
                            subMode = Mode.ALPHA;
                            break;
                        }
                    } else {
                        ch = PUNCT_CHARS[subModeCh];
                        break;
                    }
                    break;
            }
            if (ch != 0) {
                StringBuilder append6 = result.append(ch);
            }
        }
    }

    private static int byteCompaction(int i, int[] iArr, int i2, StringBuilder sb) {
        int mode = i;
        int[] codewords = iArr;
        int codeIndex = i2;
        StringBuilder result = sb;
        if (mode == BYTE_COMPACTION_MODE_LATCH) {
            int count = 0;
            long value = 0;
            char[] decodedData = new char[6];
            int[] byteCompactedCodewords = new int[6];
            boolean end = false;
            int i3 = codeIndex;
            codeIndex++;
            int nextCode = codewords[i3];
            while (codeIndex < codewords[0] && !end) {
                int i4 = count;
                count++;
                byteCompactedCodewords[i4] = nextCode;
                value = (900 * value) + ((long) nextCode);
                int i5 = codeIndex;
                codeIndex++;
                nextCode = codewords[i5];
                if (nextCode == TEXT_COMPACTION_MODE_LATCH || nextCode == BYTE_COMPACTION_MODE_LATCH || nextCode == NUMERIC_COMPACTION_MODE_LATCH || nextCode == BYTE_COMPACTION_MODE_LATCH_6 || nextCode == BEGIN_MACRO_PDF417_CONTROL_BLOCK || nextCode == BEGIN_MACRO_PDF417_OPTIONAL_FIELD || nextCode == MACRO_PDF417_TERMINATOR) {
                    codeIndex--;
                    end = true;
                } else if (count % 5 == 0 && count > 0) {
                    for (int j = 0; j < 6; j++) {
                        decodedData[5 - j] = (char) ((int) (value % 256));
                        value >>= 8;
                    }
                    StringBuilder append = result.append(decodedData);
                    count = 0;
                }
            }
            if (codeIndex == codewords[0] && nextCode < TEXT_COMPACTION_MODE_LATCH) {
                int i6 = count;
                count++;
                byteCompactedCodewords[i6] = nextCode;
            }
            for (int i7 = 0; i7 < count; i7++) {
                StringBuilder append2 = result.append((char) byteCompactedCodewords[i7]);
            }
        } else if (mode == BYTE_COMPACTION_MODE_LATCH_6) {
            int count2 = 0;
            long value2 = 0;
            boolean end2 = false;
            while (codeIndex < codewords[0] && !end2) {
                int i8 = codeIndex;
                int codeIndex2 = codeIndex + 1;
                int code = codewords[i8];
                if (code < TEXT_COMPACTION_MODE_LATCH) {
                    count2++;
                    value2 = (900 * value2) + ((long) code);
                } else if (code == TEXT_COMPACTION_MODE_LATCH || code == BYTE_COMPACTION_MODE_LATCH || code == NUMERIC_COMPACTION_MODE_LATCH || code == BYTE_COMPACTION_MODE_LATCH_6 || code == BEGIN_MACRO_PDF417_CONTROL_BLOCK || code == BEGIN_MACRO_PDF417_OPTIONAL_FIELD || code == MACRO_PDF417_TERMINATOR) {
                    codeIndex2--;
                    end2 = true;
                }
                if (count2 % 5 == 0 && count2 > 0) {
                    char[] decodedData2 = new char[6];
                    for (int j2 = 0; j2 < 6; j2++) {
                        decodedData2[5 - j2] = (char) ((int) (value2 & 255));
                        value2 >>= 8;
                    }
                    StringBuilder append3 = result.append(decodedData2);
                    count2 = 0;
                }
            }
        }
        return codeIndex;
    }

    private static int numericCompaction(int[] iArr, int i, StringBuilder sb) throws FormatException {
        int[] codewords = iArr;
        int codeIndex = i;
        StringBuilder result = sb;
        int count = 0;
        boolean end = false;
        int[] numericCodewords = new int[15];
        while (codeIndex < codewords[0] && !end) {
            int i2 = codeIndex;
            codeIndex++;
            int code = codewords[i2];
            if (codeIndex == codewords[0]) {
                end = true;
            }
            if (code < TEXT_COMPACTION_MODE_LATCH) {
                numericCodewords[count] = code;
                count++;
            } else if (code == TEXT_COMPACTION_MODE_LATCH || code == BYTE_COMPACTION_MODE_LATCH || code == BYTE_COMPACTION_MODE_LATCH_6 || code == BEGIN_MACRO_PDF417_CONTROL_BLOCK || code == BEGIN_MACRO_PDF417_OPTIONAL_FIELD || code == MACRO_PDF417_TERMINATOR) {
                codeIndex--;
                end = true;
            }
            if (count % 15 == 0 || code == NUMERIC_COMPACTION_MODE_LATCH || end) {
                StringBuilder append = result.append(decodeBase900toBase10(numericCodewords, count));
                count = 0;
            }
        }
        return codeIndex;
    }

    private static String decodeBase900toBase10(int[] iArr, int i) throws FormatException {
        int[] codewords = iArr;
        int count = i;
        BigInteger result = BigInteger.ZERO;
        for (int i2 = 0; i2 < count; i2++) {
            result = result.add(EXP900[(count - i2) - 1].multiply(BigInteger.valueOf((long) codewords[i2])));
        }
        String resultString = result.toString();
        if (resultString.charAt(0) == '1') {
            return resultString.substring(1);
        }
        throw FormatException.getFormatInstance();
    }
}
