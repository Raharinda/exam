package com.google.zxing.pdf417.encoder;

public enum Compaction {
}
