package com.google.zxing.pdf417.decoder.ec;

final class ModulusPoly {
    private final int[] coefficients;
    private final ModulusGF field;

    ModulusPoly(ModulusGF modulusGF, int[] iArr) {
        Throwable th;
        ModulusGF field2 = modulusGF;
        int[] coefficients2 = iArr;
        if (coefficients2.length == 0) {
            Throwable th2 = th;
            new IllegalArgumentException();
            throw th2;
        }
        this.field = field2;
        int coefficientsLength = coefficients2.length;
        if (coefficientsLength <= 1 || coefficients2[0] != 0) {
            this.coefficients = coefficients2;
            return;
        }
        int firstNonZero = 1;
        while (firstNonZero < coefficientsLength && coefficients2[firstNonZero] == 0) {
            firstNonZero++;
        }
        if (firstNonZero == coefficientsLength) {
            this.coefficients = field2.getZero().coefficients;
            return;
        }
        this.coefficients = new int[(coefficientsLength - firstNonZero)];
        System.arraycopy(coefficients2, firstNonZero, this.coefficients, 0, this.coefficients.length);
    }

    /* access modifiers changed from: package-private */
    public int[] getCoefficients() {
        return this.coefficients;
    }

    /* access modifiers changed from: package-private */
    public int getDegree() {
        return this.coefficients.length - 1;
    }

    /* access modifiers changed from: package-private */
    public boolean isZero() {
        return this.coefficients[0] == 0;
    }

    /* access modifiers changed from: package-private */
    public int getCoefficient(int degree) {
        return this.coefficients[(this.coefficients.length - 1) - degree];
    }

    /* access modifiers changed from: package-private */
    public int evaluateAt(int i) {
        int a = i;
        if (a == 0) {
            return getCoefficient(0);
        }
        int size = this.coefficients.length;
        if (a == 1) {
            int result = 0;
            int[] arr$ = this.coefficients;
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                result = this.field.add(result, arr$[i$]);
            }
            return result;
        }
        int result2 = this.coefficients[0];
        for (int i2 = 1; i2 < size; i2++) {
            result2 = this.field.add(this.field.multiply(a, result2), this.coefficients[i2]);
        }
        return result2;
    }

    /* access modifiers changed from: package-private */
    public ModulusPoly add(ModulusPoly modulusPoly) {
        ModulusPoly modulusPoly2;
        Throwable th;
        ModulusPoly other = modulusPoly;
        if (!this.field.equals(other.field)) {
            Throwable th2 = th;
            new IllegalArgumentException("ModulusPolys do not have same ModulusGF field");
            throw th2;
        } else if (isZero()) {
            return other;
        } else {
            if (other.isZero()) {
                return this;
            }
            int[] smallerCoefficients = this.coefficients;
            int[] largerCoefficients = other.coefficients;
            if (smallerCoefficients.length > largerCoefficients.length) {
                int[] temp = smallerCoefficients;
                smallerCoefficients = largerCoefficients;
                largerCoefficients = temp;
            }
            int[] sumDiff = new int[largerCoefficients.length];
            int lengthDiff = largerCoefficients.length - smallerCoefficients.length;
            System.arraycopy(largerCoefficients, 0, sumDiff, 0, lengthDiff);
            for (int i = lengthDiff; i < largerCoefficients.length; i++) {
                sumDiff[i] = this.field.add(smallerCoefficients[i - lengthDiff], largerCoefficients[i]);
            }
            new ModulusPoly(this.field, sumDiff);
            return modulusPoly2;
        }
    }

    /* access modifiers changed from: package-private */
    public ModulusPoly subtract(ModulusPoly modulusPoly) {
        Throwable th;
        ModulusPoly other = modulusPoly;
        if (!this.field.equals(other.field)) {
            Throwable th2 = th;
            new IllegalArgumentException("ModulusPolys do not have same ModulusGF field");
            throw th2;
        } else if (!other.isZero()) {
            return add(other.negative());
        } else {
            return this;
        }
    }

    /* access modifiers changed from: package-private */
    public ModulusPoly multiply(ModulusPoly modulusPoly) {
        ModulusPoly modulusPoly2;
        Throwable th;
        ModulusPoly other = modulusPoly;
        if (!this.field.equals(other.field)) {
            Throwable th2 = th;
            new IllegalArgumentException("ModulusPolys do not have same ModulusGF field");
            throw th2;
        } else if (isZero() || other.isZero()) {
            return this.field.getZero();
        } else {
            int[] aCoefficients = this.coefficients;
            int aLength = aCoefficients.length;
            int[] bCoefficients = other.coefficients;
            int bLength = bCoefficients.length;
            int[] product = new int[((aLength + bLength) - 1)];
            for (int i = 0; i < aLength; i++) {
                int aCoeff = aCoefficients[i];
                for (int j = 0; j < bLength; j++) {
                    product[i + j] = this.field.add(product[i + j], this.field.multiply(aCoeff, bCoefficients[j]));
                }
            }
            new ModulusPoly(this.field, product);
            return modulusPoly2;
        }
    }

    /* access modifiers changed from: package-private */
    public ModulusPoly negative() {
        ModulusPoly modulusPoly;
        int size = this.coefficients.length;
        int[] negativeCoefficients = new int[size];
        for (int i = 0; i < size; i++) {
            negativeCoefficients[i] = this.field.subtract(0, this.coefficients[i]);
        }
        new ModulusPoly(this.field, negativeCoefficients);
        return modulusPoly;
    }

    /* access modifiers changed from: package-private */
    public ModulusPoly multiply(int i) {
        ModulusPoly modulusPoly;
        int scalar = i;
        if (scalar == 0) {
            return this.field.getZero();
        }
        if (scalar == 1) {
            return this;
        }
        int size = this.coefficients.length;
        int[] product = new int[size];
        for (int i2 = 0; i2 < size; i2++) {
            product[i2] = this.field.multiply(this.coefficients[i2], scalar);
        }
        new ModulusPoly(this.field, product);
        return modulusPoly;
    }

    /* access modifiers changed from: package-private */
    public ModulusPoly multiplyByMonomial(int i, int i2) {
        ModulusPoly modulusPoly;
        Throwable th;
        int degree = i;
        int coefficient = i2;
        if (degree < 0) {
            Throwable th2 = th;
            new IllegalArgumentException();
            throw th2;
        } else if (coefficient == 0) {
            return this.field.getZero();
        } else {
            int size = this.coefficients.length;
            int[] product = new int[(size + degree)];
            for (int i3 = 0; i3 < size; i3++) {
                product[i3] = this.field.multiply(this.coefficients[i3], coefficient);
            }
            new ModulusPoly(this.field, product);
            return modulusPoly;
        }
    }

    /* access modifiers changed from: package-private */
    public ModulusPoly[] divide(ModulusPoly modulusPoly) {
        Throwable th;
        Throwable th2;
        ModulusPoly other = modulusPoly;
        if (!this.field.equals(other.field)) {
            Throwable th3 = th2;
            new IllegalArgumentException("ModulusPolys do not have same ModulusGF field");
            throw th3;
        } else if (other.isZero()) {
            Throwable th4 = th;
            new IllegalArgumentException("Divide by 0");
            throw th4;
        } else {
            ModulusPoly quotient = this.field.getZero();
            ModulusPoly remainder = this;
            int inverseDenominatorLeadingTerm = this.field.inverse(other.getCoefficient(other.getDegree()));
            while (remainder.getDegree() >= other.getDegree() && !remainder.isZero()) {
                int degreeDifference = remainder.getDegree() - other.getDegree();
                int scale = this.field.multiply(remainder.getCoefficient(remainder.getDegree()), inverseDenominatorLeadingTerm);
                ModulusPoly term = other.multiplyByMonomial(degreeDifference, scale);
                quotient = quotient.add(this.field.buildMonomial(degreeDifference, scale));
                remainder = remainder.subtract(term);
            }
            ModulusPoly[] modulusPolyArr = new ModulusPoly[2];
            modulusPolyArr[0] = quotient;
            ModulusPoly[] modulusPolyArr2 = modulusPolyArr;
            modulusPolyArr2[1] = remainder;
            return modulusPolyArr2;
        }
    }

    public String toString() {
        StringBuilder sb;
        new StringBuilder(8 * getDegree());
        StringBuilder result = sb;
        for (int degree = getDegree(); degree >= 0; degree--) {
            int coefficient = getCoefficient(degree);
            if (coefficient != 0) {
                if (coefficient < 0) {
                    StringBuilder append = result.append(" - ");
                    coefficient = -coefficient;
                } else if (result.length() > 0) {
                    StringBuilder append2 = result.append(" + ");
                }
                if (degree == 0 || coefficient != 1) {
                    StringBuilder append3 = result.append(coefficient);
                }
                if (degree != 0) {
                    if (degree == 1) {
                        StringBuilder append4 = result.append('x');
                    } else {
                        StringBuilder append5 = result.append("x^");
                        StringBuilder append6 = result.append(degree);
                    }
                }
            }
        }
        return result.toString();
    }
}
