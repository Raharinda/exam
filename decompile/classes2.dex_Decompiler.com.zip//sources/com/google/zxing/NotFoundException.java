package com.google.zxing;

public final class NotFoundException extends ReaderException {
    private static final NotFoundException instance;

    static {
        NotFoundException notFoundException;
        new NotFoundException();
        instance = notFoundException;
    }

    private NotFoundException() {
    }

    public static NotFoundException getNotFoundInstance() {
        return instance;
    }
}
