package com.google.zxing;

public enum EncodeHintType {
}
