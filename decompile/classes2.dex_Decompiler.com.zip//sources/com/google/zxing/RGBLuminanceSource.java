package com.google.zxing;

public final class RGBLuminanceSource extends LuminanceSource {
    private final int dataHeight;
    private final int dataWidth;
    private final int left;
    private final byte[] luminances;
    private final int top;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public RGBLuminanceSource(int r16, int r17, int[] r18) {
        /*
            r15 = this;
            r0 = r15
            r1 = r16
            r2 = r17
            r3 = r18
            r11 = r0
            r12 = r1
            r13 = r2
            r11.<init>(r12, r13)
            r11 = r0
            r12 = r1
            r11.dataWidth = r12
            r11 = r0
            r12 = r2
            r11.dataHeight = r12
            r11 = r0
            r12 = 0
            r11.left = r12
            r11 = r0
            r12 = 0
            r11.top = r12
            r11 = r0
            r12 = r1
            r13 = r2
            int r12 = r12 * r13
            byte[] r12 = new byte[r12]
            r11.luminances = r12
            r11 = 0
            r4 = r11
        L_0x0027:
            r11 = r4
            r12 = r2
            if (r11 >= r12) goto L_0x0082
            r11 = r4
            r12 = r1
            int r11 = r11 * r12
            r5 = r11
            r11 = 0
            r6 = r11
        L_0x0031:
            r11 = r6
            r12 = r1
            if (r11 >= r12) goto L_0x007f
            r11 = r3
            r12 = r5
            r13 = r6
            int r12 = r12 + r13
            r11 = r11[r12]
            r7 = r11
            r11 = r7
            r12 = 16
            int r11 = r11 >> 16
            r12 = 255(0xff, float:3.57E-43)
            r11 = r11 & 255(0xff, float:3.57E-43)
            r8 = r11
            r11 = r7
            r12 = 8
            int r11 = r11 >> 8
            r12 = 255(0xff, float:3.57E-43)
            r11 = r11 & 255(0xff, float:3.57E-43)
            r9 = r11
            r11 = r7
            r12 = 255(0xff, float:3.57E-43)
            r11 = r11 & 255(0xff, float:3.57E-43)
            r10 = r11
            r11 = r8
            r12 = r9
            if (r11 != r12) goto L_0x006b
            r11 = r9
            r12 = r10
            if (r11 != r12) goto L_0x006b
            r11 = r0
            byte[] r11 = r11.luminances
            r12 = r5
            r13 = r6
            int r12 = r12 + r13
            r13 = r8
            byte r13 = (byte) r13
            r11[r12] = r13
        L_0x0068:
            int r6 = r6 + 1
            goto L_0x0031
        L_0x006b:
            r11 = r0
            byte[] r11 = r11.luminances
            r12 = r5
            r13 = r6
            int r12 = r12 + r13
            r13 = r8
            r14 = r9
            int r13 = r13 + r14
            r14 = r9
            int r13 = r13 + r14
            r14 = r10
            int r13 = r13 + r14
            r14 = 2
            int r13 = r13 >> 2
            byte r13 = (byte) r13
            r11[r12] = r13
            goto L_0x0068
        L_0x007f:
            int r4 = r4 + 1
            goto L_0x0027
        L_0x0082:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.RGBLuminanceSource.<init>(int, int, int[]):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private RGBLuminanceSource(byte[] r13, int r14, int r15, int r16, int r17, int r18, int r19) {
        /*
            r12 = this;
            r0 = r12
            r1 = r13
            r2 = r14
            r3 = r15
            r4 = r16
            r5 = r17
            r6 = r18
            r7 = r19
            r8 = r0
            r9 = r6
            r10 = r7
            r8.<init>(r9, r10)
            r8 = r4
            r9 = r6
            int r8 = r8 + r9
            r9 = r2
            if (r8 > r9) goto L_0x001e
            r8 = r5
            r9 = r7
            int r8 = r8 + r9
            r9 = r3
            if (r8 <= r9) goto L_0x002a
        L_0x001e:
            java.lang.IllegalArgumentException r8 = new java.lang.IllegalArgumentException
            r11 = r8
            r8 = r11
            r9 = r11
            java.lang.String r10 = "Crop rectangle does not fit within image data."
            r9.<init>(r10)
            throw r8
        L_0x002a:
            r8 = r0
            r9 = r1
            r8.luminances = r9
            r8 = r0
            r9 = r2
            r8.dataWidth = r9
            r8 = r0
            r9 = r3
            r8.dataHeight = r9
            r8 = r0
            r9 = r4
            r8.left = r9
            r8 = r0
            r9 = r5
            r8.top = r9
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.RGBLuminanceSource.<init>(byte[], int, int, int, int, int, int):void");
    }

    public byte[] getRow(int i, byte[] bArr) {
        Throwable th;
        StringBuilder sb;
        int y = i;
        byte[] row = bArr;
        if (y < 0 || y >= getHeight()) {
            Throwable th2 = th;
            new StringBuilder();
            new IllegalArgumentException(sb.append("Requested row is outside the image: ").append(y).toString());
            throw th2;
        }
        int width = getWidth();
        if (row == null || row.length < width) {
            row = new byte[width];
        }
        System.arraycopy(this.luminances, ((y + this.top) * this.dataWidth) + this.left, row, 0, width);
        return row;
    }

    public byte[] getMatrix() {
        int width = getWidth();
        int height = getHeight();
        if (width == this.dataWidth && height == this.dataHeight) {
            return this.luminances;
        }
        int area = width * height;
        byte[] matrix = new byte[area];
        int inputOffset = (this.top * this.dataWidth) + this.left;
        if (width == this.dataWidth) {
            System.arraycopy(this.luminances, inputOffset, matrix, 0, area);
            return matrix;
        }
        byte[] rgb = this.luminances;
        for (int y = 0; y < height; y++) {
            System.arraycopy(rgb, inputOffset, matrix, y * width, width);
            inputOffset += this.dataWidth;
        }
        return matrix;
    }

    public boolean isCropSupported() {
        return true;
    }

    public LuminanceSource crop(int left2, int top2, int width, int height) {
        RGBLuminanceSource rGBLuminanceSource;
        new RGBLuminanceSource(this.luminances, this.dataWidth, this.dataHeight, this.left + left2, this.top + top2, width, height);
        return rGBLuminanceSource;
    }
}
