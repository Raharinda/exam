package com.google.zxing;

public interface ResultPointCallback {
    void foundPossibleResultPoint(ResultPoint resultPoint);
}
