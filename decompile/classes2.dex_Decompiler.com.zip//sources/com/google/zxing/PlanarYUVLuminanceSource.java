package com.google.zxing;

public final class PlanarYUVLuminanceSource extends LuminanceSource {
    private final int dataHeight;
    private final int dataWidth;
    private final int left;
    private final int top;
    private final byte[] yuvData;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public PlanarYUVLuminanceSource(byte[] r14, int r15, int r16, int r17, int r18, int r19, int r20, boolean r21) {
        /*
            r13 = this;
            r0 = r13
            r1 = r14
            r2 = r15
            r3 = r16
            r4 = r17
            r5 = r18
            r6 = r19
            r7 = r20
            r8 = r21
            r9 = r0
            r10 = r6
            r11 = r7
            r9.<init>(r10, r11)
            r9 = r4
            r10 = r6
            int r9 = r9 + r10
            r10 = r2
            if (r9 > r10) goto L_0x0021
            r9 = r5
            r10 = r7
            int r9 = r9 + r10
            r10 = r3
            if (r9 <= r10) goto L_0x002d
        L_0x0021:
            java.lang.IllegalArgumentException r9 = new java.lang.IllegalArgumentException
            r12 = r9
            r9 = r12
            r10 = r12
            java.lang.String r11 = "Crop rectangle does not fit within image data."
            r10.<init>(r11)
            throw r9
        L_0x002d:
            r9 = r0
            r10 = r1
            r9.yuvData = r10
            r9 = r0
            r10 = r2
            r9.dataWidth = r10
            r9 = r0
            r10 = r3
            r9.dataHeight = r10
            r9 = r0
            r10 = r4
            r9.left = r10
            r9 = r0
            r10 = r5
            r9.top = r10
            r9 = r8
            if (r9 == 0) goto L_0x004a
            r9 = r0
            r10 = r6
            r11 = r7
            r9.reverseHorizontal(r10, r11)
        L_0x004a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.PlanarYUVLuminanceSource.<init>(byte[], int, int, int, int, int, int, boolean):void");
    }

    public byte[] getRow(int i, byte[] bArr) {
        Throwable th;
        StringBuilder sb;
        int y = i;
        byte[] row = bArr;
        if (y < 0 || y >= getHeight()) {
            Throwable th2 = th;
            new StringBuilder();
            new IllegalArgumentException(sb.append("Requested row is outside the image: ").append(y).toString());
            throw th2;
        }
        int width = getWidth();
        if (row == null || row.length < width) {
            row = new byte[width];
        }
        System.arraycopy(this.yuvData, ((y + this.top) * this.dataWidth) + this.left, row, 0, width);
        return row;
    }

    public byte[] getMatrix() {
        int width = getWidth();
        int height = getHeight();
        if (width == this.dataWidth && height == this.dataHeight) {
            return this.yuvData;
        }
        int area = width * height;
        byte[] matrix = new byte[area];
        int inputOffset = (this.top * this.dataWidth) + this.left;
        if (width == this.dataWidth) {
            System.arraycopy(this.yuvData, inputOffset, matrix, 0, area);
            return matrix;
        }
        byte[] yuv = this.yuvData;
        for (int y = 0; y < height; y++) {
            System.arraycopy(yuv, inputOffset, matrix, y * width, width);
            inputOffset += this.dataWidth;
        }
        return matrix;
    }

    public boolean isCropSupported() {
        return true;
    }

    public LuminanceSource crop(int left2, int top2, int width, int height) {
        PlanarYUVLuminanceSource planarYUVLuminanceSource;
        new PlanarYUVLuminanceSource(this.yuvData, this.dataWidth, this.dataHeight, this.left + left2, this.top + top2, width, height, false);
        return planarYUVLuminanceSource;
    }

    public int[] renderCroppedGreyscaleBitmap() {
        int width = getWidth();
        int height = getHeight();
        int[] pixels = new int[(width * height)];
        byte[] yuv = this.yuvData;
        int inputOffset = (this.top * this.dataWidth) + this.left;
        for (int y = 0; y < height; y++) {
            int outputOffset = y * width;
            for (int x = 0; x < width; x++) {
                pixels[outputOffset + x] = -16777216 | ((yuv[inputOffset + x] & 255) * 65793);
            }
            inputOffset += this.dataWidth;
        }
        return pixels;
    }

    private void reverseHorizontal(int i, int i2) {
        int width = i;
        int height = i2;
        byte[] yuvData2 = this.yuvData;
        int y = 0;
        int i3 = this.top * this.dataWidth;
        int i4 = this.left;
        while (true) {
            int rowStart = i3 + i4;
            if (y < height) {
                int middle = rowStart + (width / 2);
                int x1 = rowStart;
                int x2 = (rowStart + width) - 1;
                while (x1 < middle) {
                    byte temp = yuvData2[x1];
                    yuvData2[x1] = yuvData2[x2];
                    yuvData2[x2] = temp;
                    x1++;
                    x2--;
                }
                y++;
                i3 = rowStart;
                i4 = this.dataWidth;
            } else {
                return;
            }
        }
    }
}
