package com.google.zxing.qrcode.detector;

import com.google.zxing.ResultPoint;

public final class AlignmentPattern extends ResultPoint {
    private final float estimatedModuleSize;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    AlignmentPattern(float posX, float posY, float estimatedModuleSize2) {
        super(posX, posY);
        this.estimatedModuleSize = estimatedModuleSize2;
    }

    /* access modifiers changed from: package-private */
    public boolean aboutEquals(float f, float i, float f2) {
        float moduleSize = f;
        float j = f2;
        if (Math.abs(i - getY()) > moduleSize || Math.abs(j - getX()) > moduleSize) {
            return false;
        }
        float moduleSizeDiff = Math.abs(moduleSize - this.estimatedModuleSize);
        return moduleSizeDiff <= 1.0f || moduleSizeDiff <= this.estimatedModuleSize;
    }

    /* access modifiers changed from: package-private */
    public AlignmentPattern combineEstimate(float i, float j, float newModuleSize) {
        AlignmentPattern alignmentPattern;
        new AlignmentPattern((getX() + j) / 2.0f, (getY() + i) / 2.0f, (this.estimatedModuleSize + newModuleSize) / 2.0f);
        return alignmentPattern;
    }
}
