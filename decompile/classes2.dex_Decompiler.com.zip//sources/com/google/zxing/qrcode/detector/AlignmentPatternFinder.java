package com.google.zxing.qrcode.detector;

import com.google.zxing.NotFoundException;
import com.google.zxing.ResultPointCallback;
import com.google.zxing.common.BitMatrix;
import java.util.ArrayList;
import java.util.List;

final class AlignmentPatternFinder {
    private final int[] crossCheckStateCount = new int[3];
    private final int height;
    private final BitMatrix image;
    private final float moduleSize;
    private final List<AlignmentPattern> possibleCenters;
    private final ResultPointCallback resultPointCallback;
    private final int startX;
    private final int startY;
    private final int width;

    AlignmentPatternFinder(BitMatrix image2, int startX2, int startY2, int width2, int height2, float moduleSize2, ResultPointCallback resultPointCallback2) {
        List<AlignmentPattern> list;
        this.image = image2;
        new ArrayList(5);
        this.possibleCenters = list;
        this.startX = startX2;
        this.startY = startY2;
        this.width = width2;
        this.height = height2;
        this.moduleSize = moduleSize2;
        this.resultPointCallback = resultPointCallback2;
    }

    /* access modifiers changed from: package-private */
    public AlignmentPattern find() throws NotFoundException {
        int i;
        AlignmentPattern confirmed;
        AlignmentPattern confirmed2;
        int startX2 = this.startX;
        int height2 = this.height;
        int maxJ = startX2 + this.width;
        int middleI = this.startY + (height2 >> 1);
        int[] stateCount = new int[3];
        for (int iGen = 0; iGen < height2; iGen++) {
            int i2 = middleI;
            if ((iGen & 1) == 0) {
                i = (iGen + 1) >> 1;
            } else {
                i = -((iGen + 1) >> 1);
            }
            int i3 = i2 + i;
            stateCount[0] = 0;
            stateCount[1] = 0;
            stateCount[2] = 0;
            int j = startX2;
            while (j < maxJ && !this.image.get(j, i3)) {
                j++;
            }
            int currentState = 0;
            while (j < maxJ) {
                if (!this.image.get(j, i3)) {
                    if (currentState == 1) {
                        currentState++;
                    }
                    int[] iArr = stateCount;
                    int i4 = currentState;
                    iArr[i4] = iArr[i4] + 1;
                } else if (currentState == 1) {
                    int[] iArr2 = stateCount;
                    int i5 = currentState;
                    iArr2[i5] = iArr2[i5] + 1;
                } else if (currentState != 2) {
                    currentState++;
                    int[] iArr3 = stateCount;
                    int i6 = currentState;
                    iArr3[i6] = iArr3[i6] + 1;
                } else if (foundPatternCross(stateCount) && (confirmed2 = handlePossibleCenter(stateCount, i3, j)) != null) {
                    return confirmed2;
                } else {
                    stateCount[0] = stateCount[2];
                    stateCount[1] = 1;
                    stateCount[2] = 0;
                    currentState = 1;
                }
                j++;
            }
            if (foundPatternCross(stateCount) && (confirmed = handlePossibleCenter(stateCount, i3, maxJ)) != null) {
                return confirmed;
            }
        }
        if (!this.possibleCenters.isEmpty()) {
            return this.possibleCenters.get(0);
        }
        throw NotFoundException.getNotFoundInstance();
    }

    private static float centerFromEnd(int[] iArr, int end) {
        int[] stateCount = iArr;
        return ((float) (end - stateCount[2])) - (((float) stateCount[1]) / 2.0f);
    }

    private boolean foundPatternCross(int[] iArr) {
        int[] stateCount = iArr;
        float moduleSize2 = this.moduleSize;
        float maxVariance = moduleSize2 / 2.0f;
        for (int i = 0; i < 3; i++) {
            if (Math.abs(moduleSize2 - ((float) stateCount[i])) >= maxVariance) {
                return false;
            }
        }
        return true;
    }

    private float crossCheckVertical(int i, int i2, int i3, int i4) {
        int startI = i;
        int centerJ = i2;
        int maxCount = i3;
        int originalStateCountTotal = i4;
        BitMatrix image2 = this.image;
        int maxI = image2.getHeight();
        int[] stateCount = this.crossCheckStateCount;
        stateCount[0] = 0;
        stateCount[1] = 0;
        stateCount[2] = 0;
        int i5 = startI;
        while (i5 >= 0 && image2.get(centerJ, i5) && stateCount[1] <= maxCount) {
            int[] iArr = stateCount;
            iArr[1] = iArr[1] + 1;
            i5--;
        }
        if (i5 < 0 || stateCount[1] > maxCount) {
            return Float.NaN;
        }
        while (i5 >= 0 && !image2.get(centerJ, i5) && stateCount[0] <= maxCount) {
            int[] iArr2 = stateCount;
            iArr2[0] = iArr2[0] + 1;
            i5--;
        }
        if (stateCount[0] > maxCount) {
            return Float.NaN;
        }
        int i6 = startI + 1;
        while (i6 < maxI && image2.get(centerJ, i6) && stateCount[1] <= maxCount) {
            int[] iArr3 = stateCount;
            iArr3[1] = iArr3[1] + 1;
            i6++;
        }
        if (i6 == maxI || stateCount[1] > maxCount) {
            return Float.NaN;
        }
        while (i6 < maxI && !image2.get(centerJ, i6) && stateCount[2] <= maxCount) {
            int[] iArr4 = stateCount;
            iArr4[2] = iArr4[2] + 1;
            i6++;
        }
        if (stateCount[2] > maxCount) {
            return Float.NaN;
        }
        if (5 * Math.abs(((stateCount[0] + stateCount[1]) + stateCount[2]) - originalStateCountTotal) >= 2 * originalStateCountTotal) {
            return Float.NaN;
        }
        return foundPatternCross(stateCount) ? centerFromEnd(stateCount, i6) : Float.NaN;
    }

    private AlignmentPattern handlePossibleCenter(int[] iArr, int i, int j) {
        AlignmentPattern alignmentPattern;
        int[] stateCount = iArr;
        int stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2];
        float centerJ = centerFromEnd(stateCount, j);
        float centerI = crossCheckVertical(i, (int) centerJ, 2 * stateCount[1], stateCountTotal);
        if (!Float.isNaN(centerI)) {
            float estimatedModuleSize = ((float) ((stateCount[0] + stateCount[1]) + stateCount[2])) / 3.0f;
            for (AlignmentPattern center : this.possibleCenters) {
                if (center.aboutEquals(estimatedModuleSize, centerI, centerJ)) {
                    return center.combineEstimate(centerI, centerJ, estimatedModuleSize);
                }
            }
            new AlignmentPattern(centerJ, centerI, estimatedModuleSize);
            AlignmentPattern point = alignmentPattern;
            boolean add = this.possibleCenters.add(point);
            if (this.resultPointCallback != null) {
                this.resultPointCallback.foundPossibleResultPoint(point);
            }
        }
        return null;
    }
}
