package com.google.zxing.qrcode;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.Writer;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.google.zxing.qrcode.encoder.ByteMatrix;
import com.google.zxing.qrcode.encoder.Encoder;
import com.google.zxing.qrcode.encoder.QRCode;
import java.util.Map;

public final class QRCodeWriter implements Writer {
    private static final int QUIET_ZONE_SIZE = 4;

    public QRCodeWriter() {
    }

    public BitMatrix encode(String contents, BarcodeFormat format, int width, int height) throws WriterException {
        return encode(contents, format, width, height, (Map<EncodeHintType, ?>) null);
    }

    public BitMatrix encode(String str, BarcodeFormat barcodeFormat, int i, int i2, Map<EncodeHintType, ?> map) throws WriterException {
        Throwable th;
        StringBuilder sb;
        Throwable th2;
        StringBuilder sb2;
        Throwable th3;
        String contents = str;
        BarcodeFormat format = barcodeFormat;
        int width = i;
        int height = i2;
        Map<EncodeHintType, ?> hints = map;
        if (contents.length() == 0) {
            Throwable th4 = th3;
            new IllegalArgumentException("Found empty contents");
            throw th4;
        } else if (format != BarcodeFormat.QR_CODE) {
            Throwable th5 = th2;
            new StringBuilder();
            new IllegalArgumentException(sb2.append("Can only encode QR_CODE, but got ").append(format).toString());
            throw th5;
        } else if (width < 0 || height < 0) {
            Throwable th6 = th;
            new StringBuilder();
            new IllegalArgumentException(sb.append("Requested dimensions are too small: ").append(width).append('x').append(height).toString());
            throw th6;
        } else {
            ErrorCorrectionLevel errorCorrectionLevel = ErrorCorrectionLevel.L;
            int quietZone = 4;
            if (hints != null) {
                ErrorCorrectionLevel requestedECLevel = (ErrorCorrectionLevel) hints.get(EncodeHintType.ERROR_CORRECTION);
                if (requestedECLevel != null) {
                    errorCorrectionLevel = requestedECLevel;
                }
                Integer quietZoneInt = (Integer) hints.get(EncodeHintType.MARGIN);
                if (quietZoneInt != null) {
                    quietZone = quietZoneInt.intValue();
                }
            }
            return renderResult(Encoder.encode(contents, errorCorrectionLevel, hints), width, height, quietZone);
        }
    }

    private static BitMatrix renderResult(QRCode code, int i, int i2, int i3) {
        BitMatrix bitMatrix;
        Throwable th;
        int width = i;
        int height = i2;
        int quietZone = i3;
        ByteMatrix input = code.getMatrix();
        if (input == null) {
            Throwable th2 = th;
            new IllegalStateException();
            throw th2;
        }
        int inputWidth = input.getWidth();
        int inputHeight = input.getHeight();
        int qrWidth = inputWidth + (quietZone << 1);
        int qrHeight = inputHeight + (quietZone << 1);
        int outputWidth = Math.max(width, qrWidth);
        int outputHeight = Math.max(height, qrHeight);
        int multiple = Math.min(outputWidth / qrWidth, outputHeight / qrHeight);
        int leftPadding = (outputWidth - (inputWidth * multiple)) / 2;
        new BitMatrix(outputWidth, outputHeight);
        BitMatrix output = bitMatrix;
        int inputY = 0;
        int i4 = (outputHeight - (inputHeight * multiple)) / 2;
        while (true) {
            int outputY = i4;
            if (inputY >= inputHeight) {
                return output;
            }
            int inputX = 0;
            int i5 = leftPadding;
            while (true) {
                int outputX = i5;
                if (inputX >= inputWidth) {
                    break;
                }
                if (input.get(inputX, inputY) == 1) {
                    output.setRegion(outputX, outputY, multiple, multiple);
                }
                inputX++;
                i5 = outputX + multiple;
            }
            inputY++;
            i4 = outputY + multiple;
        }
    }
}
