package com.google.zxing.qrcode.detector;

import com.google.zxing.ResultPoint;

public final class FinderPattern extends ResultPoint {
    private int count;
    private final float estimatedModuleSize;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    FinderPattern(float posX, float posY, float estimatedModuleSize2) {
        this(posX, posY, estimatedModuleSize2, 1);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    private FinderPattern(float posX, float posY, float estimatedModuleSize2, int count2) {
        super(posX, posY);
        this.estimatedModuleSize = estimatedModuleSize2;
        this.count = count2;
    }

    public float getEstimatedModuleSize() {
        return this.estimatedModuleSize;
    }

    /* access modifiers changed from: package-private */
    public int getCount() {
        return this.count;
    }

    /* access modifiers changed from: package-private */
    public void incrementCount() {
        this.count++;
    }

    /* access modifiers changed from: package-private */
    public boolean aboutEquals(float f, float i, float f2) {
        float moduleSize = f;
        float j = f2;
        if (Math.abs(i - getY()) > moduleSize || Math.abs(j - getX()) > moduleSize) {
            return false;
        }
        float moduleSizeDiff = Math.abs(moduleSize - this.estimatedModuleSize);
        return moduleSizeDiff <= 1.0f || moduleSizeDiff <= this.estimatedModuleSize;
    }

    /* access modifiers changed from: package-private */
    public FinderPattern combineEstimate(float i, float j, float newModuleSize) {
        FinderPattern finderPattern;
        int combinedCount = this.count + 1;
        new FinderPattern(((((float) this.count) * getX()) + j) / ((float) combinedCount), ((((float) this.count) * getY()) + i) / ((float) combinedCount), ((((float) this.count) * this.estimatedModuleSize) + newModuleSize) / ((float) combinedCount), combinedCount);
        return finderPattern;
    }
}
