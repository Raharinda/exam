package com.google.zxing.qrcode.decoder;

import com.google.zxing.common.BitMatrix;

abstract class DataMask {
    private static final DataMask[] DATA_MASKS;

    /* access modifiers changed from: package-private */
    public abstract boolean isMasked(int i, int i2);

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    /* synthetic */ DataMask(AnonymousClass1 r4) {
        this();
        AnonymousClass1 r1 = r4;
    }

    static {
        DataMask dataMask;
        DataMask dataMask2;
        DataMask dataMask3;
        DataMask dataMask4;
        DataMask dataMask5;
        DataMask dataMask6;
        DataMask dataMask7;
        DataMask dataMask8;
        DataMask[] dataMaskArr = new DataMask[8];
        new DataMask000((AnonymousClass1) null);
        dataMaskArr[0] = dataMask;
        DataMask[] dataMaskArr2 = dataMaskArr;
        new DataMask001((AnonymousClass1) null);
        dataMaskArr2[1] = dataMask2;
        DataMask[] dataMaskArr3 = dataMaskArr2;
        new DataMask010((AnonymousClass1) null);
        dataMaskArr3[2] = dataMask3;
        DataMask[] dataMaskArr4 = dataMaskArr3;
        new DataMask011((AnonymousClass1) null);
        dataMaskArr4[3] = dataMask4;
        DataMask[] dataMaskArr5 = dataMaskArr4;
        new DataMask100((AnonymousClass1) null);
        dataMaskArr5[4] = dataMask5;
        DataMask[] dataMaskArr6 = dataMaskArr5;
        new DataMask101((AnonymousClass1) null);
        dataMaskArr6[5] = dataMask6;
        DataMask[] dataMaskArr7 = dataMaskArr6;
        new DataMask110((AnonymousClass1) null);
        dataMaskArr7[6] = dataMask7;
        DataMask[] dataMaskArr8 = dataMaskArr7;
        new DataMask111((AnonymousClass1) null);
        dataMaskArr8[7] = dataMask8;
        DATA_MASKS = dataMaskArr8;
    }

    private DataMask() {
    }

    /* access modifiers changed from: package-private */
    public final void unmaskBitMatrix(BitMatrix bitMatrix, int i) {
        BitMatrix bits = bitMatrix;
        int dimension = i;
        for (int i2 = 0; i2 < dimension; i2++) {
            for (int j = 0; j < dimension; j++) {
                if (isMasked(i2, j)) {
                    bits.flip(j, i2);
                }
            }
        }
    }

    static DataMask forReference(int i) {
        Throwable th;
        int reference = i;
        if (reference >= 0 && reference <= 7) {
            return DATA_MASKS[reference];
        }
        Throwable th2 = th;
        new IllegalArgumentException();
        throw th2;
    }

    private static final class DataMask000 extends DataMask {
        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        private DataMask000() {
            super((AnonymousClass1) null);
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ DataMask000(AnonymousClass1 r4) {
            this();
            AnonymousClass1 r1 = r4;
        }

        /* access modifiers changed from: package-private */
        public boolean isMasked(int i, int j) {
            return ((i + j) & 1) == 0;
        }
    }

    private static final class DataMask001 extends DataMask {
        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        private DataMask001() {
            super((AnonymousClass1) null);
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ DataMask001(AnonymousClass1 r4) {
            this();
            AnonymousClass1 r1 = r4;
        }

        /* access modifiers changed from: package-private */
        public boolean isMasked(int i, int i2) {
            int i3 = i2;
            return (i & 1) == 0;
        }
    }

    private static final class DataMask010 extends DataMask {
        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        private DataMask010() {
            super((AnonymousClass1) null);
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ DataMask010(AnonymousClass1 r4) {
            this();
            AnonymousClass1 r1 = r4;
        }

        /* access modifiers changed from: package-private */
        public boolean isMasked(int i, int j) {
            int i2 = i;
            return j % 3 == 0;
        }
    }

    private static final class DataMask011 extends DataMask {
        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        private DataMask011() {
            super((AnonymousClass1) null);
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ DataMask011(AnonymousClass1 r4) {
            this();
            AnonymousClass1 r1 = r4;
        }

        /* access modifiers changed from: package-private */
        public boolean isMasked(int i, int j) {
            return (i + j) % 3 == 0;
        }
    }

    private static final class DataMask100 extends DataMask {
        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        private DataMask100() {
            super((AnonymousClass1) null);
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ DataMask100(AnonymousClass1 r4) {
            this();
            AnonymousClass1 r1 = r4;
        }

        /* access modifiers changed from: package-private */
        public boolean isMasked(int i, int j) {
            return (((i >>> 1) + (j / 3)) & 1) == 0;
        }
    }

    private static final class DataMask101 extends DataMask {
        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        private DataMask101() {
            super((AnonymousClass1) null);
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ DataMask101(AnonymousClass1 r4) {
            this();
            AnonymousClass1 r1 = r4;
        }

        /* access modifiers changed from: package-private */
        public boolean isMasked(int i, int j) {
            int temp = i * j;
            return (temp & 1) + (temp % 3) == 0;
        }
    }

    private static final class DataMask110 extends DataMask {
        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        private DataMask110() {
            super((AnonymousClass1) null);
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ DataMask110(AnonymousClass1 r4) {
            this();
            AnonymousClass1 r1 = r4;
        }

        /* access modifiers changed from: package-private */
        public boolean isMasked(int i, int j) {
            int temp = i * j;
            return (((temp & 1) + (temp % 3)) & 1) == 0;
        }
    }

    private static final class DataMask111 extends DataMask {
        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        private DataMask111() {
            super((AnonymousClass1) null);
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ DataMask111(AnonymousClass1 r4) {
            this();
            AnonymousClass1 r1 = r4;
        }

        /* access modifiers changed from: package-private */
        public boolean isMasked(int i, int i2) {
            int i3 = i;
            int j = i2;
            return ((((i3 + j) & 1) + ((i3 * j) % 3)) & 1) == 0;
        }
    }
}
