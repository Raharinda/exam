package com.google.zxing.qrcode.encoder;

import com.google.zxing.WriterException;
import com.google.zxing.common.BitArray;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.google.zxing.qrcode.decoder.Version;

final class MatrixUtil {
    private static final int[][] POSITION_ADJUSTMENT_PATTERN;
    private static final int[][] POSITION_ADJUSTMENT_PATTERN_COORDINATE_TABLE;
    private static final int[][] POSITION_DETECTION_PATTERN;
    private static final int[][] TYPE_INFO_COORDINATES;
    private static final int TYPE_INFO_MASK_PATTERN = 21522;
    private static final int TYPE_INFO_POLY = 1335;
    private static final int VERSION_INFO_POLY = 7973;

    private MatrixUtil() {
    }

    static {
        int[][] iArr = new int[7][];
        iArr[0] = new int[]{1, 1, 1, 1, 1, 1, 1};
        int[][] iArr2 = iArr;
        iArr2[1] = new int[]{1, 0, 0, 0, 0, 0, 1};
        int[][] iArr3 = iArr2;
        iArr3[2] = new int[]{1, 0, 1, 1, 1, 0, 1};
        int[][] iArr4 = iArr3;
        iArr4[3] = new int[]{1, 0, 1, 1, 1, 0, 1};
        int[][] iArr5 = iArr4;
        iArr5[4] = new int[]{1, 0, 1, 1, 1, 0, 1};
        int[][] iArr6 = iArr5;
        iArr6[5] = new int[]{1, 0, 0, 0, 0, 0, 1};
        int[][] iArr7 = iArr6;
        iArr7[6] = new int[]{1, 1, 1, 1, 1, 1, 1};
        POSITION_DETECTION_PATTERN = iArr7;
        int[][] iArr8 = new int[5][];
        iArr8[0] = new int[]{1, 1, 1, 1, 1};
        int[][] iArr9 = iArr8;
        iArr9[1] = new int[]{1, 0, 0, 0, 1};
        int[][] iArr10 = iArr9;
        iArr10[2] = new int[]{1, 0, 1, 0, 1};
        int[][] iArr11 = iArr10;
        iArr11[3] = new int[]{1, 0, 0, 0, 1};
        int[][] iArr12 = iArr11;
        iArr12[4] = new int[]{1, 1, 1, 1, 1};
        POSITION_ADJUSTMENT_PATTERN = iArr12;
        int[][] iArr13 = new int[40][];
        iArr13[0] = new int[]{-1, -1, -1, -1, -1, -1, -1};
        int[][] iArr14 = iArr13;
        iArr14[1] = new int[]{6, 18, -1, -1, -1, -1, -1};
        int[][] iArr15 = iArr14;
        iArr15[2] = new int[]{6, 22, -1, -1, -1, -1, -1};
        int[][] iArr16 = iArr15;
        iArr16[3] = new int[]{6, 26, -1, -1, -1, -1, -1};
        int[][] iArr17 = iArr16;
        iArr17[4] = new int[]{6, 30, -1, -1, -1, -1, -1};
        int[][] iArr18 = iArr17;
        iArr18[5] = new int[]{6, 34, -1, -1, -1, -1, -1};
        int[][] iArr19 = iArr18;
        iArr19[6] = new int[]{6, 22, 38, -1, -1, -1, -1};
        int[][] iArr20 = iArr19;
        iArr20[7] = new int[]{6, 24, 42, -1, -1, -1, -1};
        int[][] iArr21 = iArr20;
        iArr21[8] = new int[]{6, 26, 46, -1, -1, -1, -1};
        int[][] iArr22 = iArr21;
        iArr22[9] = new int[]{6, 28, 50, -1, -1, -1, -1};
        int[][] iArr23 = iArr22;
        iArr23[10] = new int[]{6, 30, 54, -1, -1, -1, -1};
        int[][] iArr24 = iArr23;
        iArr24[11] = new int[]{6, 32, 58, -1, -1, -1, -1};
        int[][] iArr25 = iArr24;
        iArr25[12] = new int[]{6, 34, 62, -1, -1, -1, -1};
        int[][] iArr26 = iArr25;
        iArr26[13] = new int[]{6, 26, 46, 66, -1, -1, -1};
        int[][] iArr27 = iArr26;
        iArr27[14] = new int[]{6, 26, 48, 70, -1, -1, -1};
        int[][] iArr28 = iArr27;
        iArr28[15] = new int[]{6, 26, 50, 74, -1, -1, -1};
        int[][] iArr29 = iArr28;
        iArr29[16] = new int[]{6, 30, 54, 78, -1, -1, -1};
        int[][] iArr30 = iArr29;
        iArr30[17] = new int[]{6, 30, 56, 82, -1, -1, -1};
        int[][] iArr31 = iArr30;
        iArr31[18] = new int[]{6, 30, 58, 86, -1, -1, -1};
        int[][] iArr32 = iArr31;
        iArr32[19] = new int[]{6, 34, 62, 90, -1, -1, -1};
        int[][] iArr33 = iArr32;
        iArr33[20] = new int[]{6, 28, 50, 72, 94, -1, -1};
        int[][] iArr34 = iArr33;
        iArr34[21] = new int[]{6, 26, 50, 74, 98, -1, -1};
        int[][] iArr35 = iArr34;
        iArr35[22] = new int[]{6, 30, 54, 78, 102, -1, -1};
        int[][] iArr36 = iArr35;
        iArr36[23] = new int[]{6, 28, 54, 80, 106, -1, -1};
        int[][] iArr37 = iArr36;
        iArr37[24] = new int[]{6, 32, 58, 84, 110, -1, -1};
        int[][] iArr38 = iArr37;
        iArr38[25] = new int[]{6, 30, 58, 86, 114, -1, -1};
        int[][] iArr39 = iArr38;
        iArr39[26] = new int[]{6, 34, 62, 90, 118, -1, -1};
        int[][] iArr40 = iArr39;
        iArr40[27] = new int[]{6, 26, 50, 74, 98, 122, -1};
        int[][] iArr41 = iArr40;
        iArr41[28] = new int[]{6, 30, 54, 78, 102, 126, -1};
        int[][] iArr42 = iArr41;
        iArr42[29] = new int[]{6, 26, 52, 78, 104, 130, -1};
        int[][] iArr43 = iArr42;
        iArr43[30] = new int[]{6, 30, 56, 82, 108, 134, -1};
        int[][] iArr44 = iArr43;
        iArr44[31] = new int[]{6, 34, 60, 86, 112, 138, -1};
        int[][] iArr45 = iArr44;
        iArr45[32] = new int[]{6, 30, 58, 86, 114, 142, -1};
        int[][] iArr46 = iArr45;
        iArr46[33] = new int[]{6, 34, 62, 90, 118, 146, -1};
        int[][] iArr47 = iArr46;
        iArr47[34] = new int[]{6, 30, 54, 78, 102, 126, 150};
        int[][] iArr48 = iArr47;
        iArr48[35] = new int[]{6, 24, 50, 76, 102, 128, 154};
        int[][] iArr49 = iArr48;
        iArr49[36] = new int[]{6, 28, 54, 80, 106, 132, 158};
        int[][] iArr50 = iArr49;
        iArr50[37] = new int[]{6, 32, 58, 84, 110, 136, 162};
        int[][] iArr51 = iArr50;
        iArr51[38] = new int[]{6, 26, 54, 82, 110, 138, 166};
        int[][] iArr52 = iArr51;
        iArr52[39] = new int[]{6, 30, 58, 86, 114, 142, 170};
        POSITION_ADJUSTMENT_PATTERN_COORDINATE_TABLE = iArr52;
        int[][] iArr53 = new int[15][];
        iArr53[0] = new int[]{8, 0};
        int[][] iArr54 = iArr53;
        iArr54[1] = new int[]{8, 1};
        int[][] iArr55 = iArr54;
        iArr55[2] = new int[]{8, 2};
        int[][] iArr56 = iArr55;
        iArr56[3] = new int[]{8, 3};
        int[][] iArr57 = iArr56;
        iArr57[4] = new int[]{8, 4};
        int[][] iArr58 = iArr57;
        iArr58[5] = new int[]{8, 5};
        int[][] iArr59 = iArr58;
        iArr59[6] = new int[]{8, 7};
        int[][] iArr60 = iArr59;
        iArr60[7] = new int[]{8, 8};
        int[][] iArr61 = iArr60;
        iArr61[8] = new int[]{7, 8};
        int[][] iArr62 = iArr61;
        iArr62[9] = new int[]{5, 8};
        int[][] iArr63 = iArr62;
        iArr63[10] = new int[]{4, 8};
        int[][] iArr64 = iArr63;
        iArr64[11] = new int[]{3, 8};
        int[][] iArr65 = iArr64;
        iArr65[12] = new int[]{2, 8};
        int[][] iArr66 = iArr65;
        iArr66[13] = new int[]{1, 8};
        int[][] iArr67 = iArr66;
        iArr67[14] = new int[]{0, 8};
        TYPE_INFO_COORDINATES = iArr67;
    }

    static void clearMatrix(ByteMatrix matrix) {
        matrix.clear((byte) -1);
    }

    static void buildMatrix(BitArray dataBits, ErrorCorrectionLevel ecLevel, Version version, int i, ByteMatrix byteMatrix) throws WriterException {
        Version version2 = version;
        int maskPattern = i;
        ByteMatrix matrix = byteMatrix;
        clearMatrix(matrix);
        embedBasicPatterns(version2, matrix);
        embedTypeInfo(ecLevel, maskPattern, matrix);
        maybeEmbedVersionInfo(version2, matrix);
        embedDataBits(dataBits, maskPattern, matrix);
    }

    static void embedBasicPatterns(Version version, ByteMatrix byteMatrix) throws WriterException {
        ByteMatrix matrix = byteMatrix;
        embedPositionDetectionPatternsAndSeparators(matrix);
        embedDarkDotAtLeftBottomCorner(matrix);
        maybeEmbedPositionAdjustmentPatterns(version, matrix);
        embedTimingPatterns(matrix);
    }

    static void embedTypeInfo(ErrorCorrectionLevel ecLevel, int maskPattern, ByteMatrix byteMatrix) throws WriterException {
        BitArray bitArray;
        ByteMatrix matrix = byteMatrix;
        new BitArray();
        BitArray typeInfoBits = bitArray;
        makeTypeInfoBits(ecLevel, maskPattern, typeInfoBits);
        for (int i = 0; i < typeInfoBits.getSize(); i++) {
            boolean bit = typeInfoBits.get((typeInfoBits.getSize() - 1) - i);
            matrix.set(TYPE_INFO_COORDINATES[i][0], TYPE_INFO_COORDINATES[i][1], bit);
            if (i < 8) {
                matrix.set((matrix.getWidth() - i) - 1, 8, bit);
            } else {
                matrix.set(8, (matrix.getHeight() - 7) + (i - 8), bit);
            }
        }
    }

    static void maybeEmbedVersionInfo(Version version, ByteMatrix byteMatrix) throws WriterException {
        BitArray bitArray;
        Version version2 = version;
        ByteMatrix matrix = byteMatrix;
        if (version2.getVersionNumber() >= 7) {
            new BitArray();
            BitArray versionInfoBits = bitArray;
            makeVersionInfoBits(version2, versionInfoBits);
            int bitIndex = 17;
            for (int i = 0; i < 6; i++) {
                for (int j = 0; j < 3; j++) {
                    boolean bit = versionInfoBits.get(bitIndex);
                    bitIndex--;
                    matrix.set(i, (matrix.getHeight() - 11) + j, bit);
                    matrix.set((matrix.getHeight() - 11) + j, i, bit);
                }
            }
        }
    }

    static void embedDataBits(BitArray bitArray, int i, ByteMatrix byteMatrix) throws WriterException {
        Throwable th;
        StringBuilder sb;
        boolean bit;
        BitArray dataBits = bitArray;
        int maskPattern = i;
        ByteMatrix matrix = byteMatrix;
        int bitIndex = 0;
        int direction = -1;
        int x = matrix.getWidth() - 1;
        int y = matrix.getHeight() - 1;
        while (x > 0) {
            if (x == 6) {
                x--;
            }
            while (y >= 0 && y < matrix.getHeight()) {
                for (int i2 = 0; i2 < 2; i2++) {
                    int xx = x - i2;
                    if (isEmpty(matrix.get(xx, y))) {
                        if (bitIndex < dataBits.getSize()) {
                            bit = dataBits.get(bitIndex);
                            bitIndex++;
                        } else {
                            bit = false;
                        }
                        if (maskPattern != -1 && MaskUtil.getDataMaskBit(maskPattern, xx, y)) {
                            bit = !bit;
                        }
                        matrix.set(xx, y, bit);
                    }
                }
                y += direction;
            }
            direction = -direction;
            y += direction;
            x -= 2;
        }
        if (bitIndex != dataBits.getSize()) {
            Throwable th2 = th;
            new StringBuilder();
            new WriterException(sb.append("Not all bits consumed: ").append(bitIndex).append('/').append(dataBits.getSize()).toString());
            throw th2;
        }
    }

    static int findMSBSet(int i) {
        int value = i;
        int numDigits = 0;
        while (value != 0) {
            value >>>= 1;
            numDigits++;
        }
        return numDigits;
    }

    static int calculateBCHCode(int value, int i) {
        int poly = i;
        int msbSetInPoly = findMSBSet(poly);
        int i2 = value << (msbSetInPoly - 1);
        while (true) {
            int value2 = i2;
            if (findMSBSet(value2) < msbSetInPoly) {
                return value2;
            }
            i2 = value2 ^ (poly << (findMSBSet(value2) - msbSetInPoly));
        }
    }

    static void makeTypeInfoBits(ErrorCorrectionLevel errorCorrectionLevel, int i, BitArray bitArray) throws WriterException {
        BitArray bitArray2;
        Throwable th;
        StringBuilder sb;
        Throwable th2;
        ErrorCorrectionLevel ecLevel = errorCorrectionLevel;
        int maskPattern = i;
        BitArray bits = bitArray;
        if (!QRCode.isValidMaskPattern(maskPattern)) {
            Throwable th3 = th2;
            new WriterException("Invalid mask pattern");
            throw th3;
        }
        int typeInfo = (ecLevel.getBits() << 3) | maskPattern;
        bits.appendBits(typeInfo, 5);
        bits.appendBits(calculateBCHCode(typeInfo, TYPE_INFO_POLY), 10);
        new BitArray();
        BitArray maskBits = bitArray2;
        maskBits.appendBits(TYPE_INFO_MASK_PATTERN, 15);
        bits.xor(maskBits);
        if (bits.getSize() != 15) {
            Throwable th4 = th;
            new StringBuilder();
            new WriterException(sb.append("should not happen but we got: ").append(bits.getSize()).toString());
            throw th4;
        }
    }

    static void makeVersionInfoBits(Version version, BitArray bitArray) throws WriterException {
        Throwable th;
        StringBuilder sb;
        Version version2 = version;
        BitArray bits = bitArray;
        bits.appendBits(version2.getVersionNumber(), 6);
        bits.appendBits(calculateBCHCode(version2.getVersionNumber(), VERSION_INFO_POLY), 12);
        if (bits.getSize() != 18) {
            Throwable th2 = th;
            new StringBuilder();
            new WriterException(sb.append("should not happen but we got: ").append(bits.getSize()).toString());
            throw th2;
        }
    }

    private static boolean isEmpty(int value) {
        return value == -1;
    }

    private static void embedTimingPatterns(ByteMatrix byteMatrix) {
        ByteMatrix matrix = byteMatrix;
        for (int i = 8; i < matrix.getWidth() - 8; i++) {
            int bit = (i + 1) % 2;
            if (isEmpty(matrix.get(i, 6))) {
                matrix.set(i, 6, bit);
            }
            if (isEmpty(matrix.get(6, i))) {
                matrix.set(6, i, bit);
            }
        }
    }

    private static void embedDarkDotAtLeftBottomCorner(ByteMatrix byteMatrix) throws WriterException {
        Throwable th;
        ByteMatrix matrix = byteMatrix;
        if (matrix.get(8, matrix.getHeight() - 8) == 0) {
            Throwable th2 = th;
            new WriterException();
            throw th2;
        }
        matrix.set(8, matrix.getHeight() - 8, 1);
    }

    private static void embedHorizontalSeparationPattern(int i, int i2, ByteMatrix byteMatrix) throws WriterException {
        Throwable th;
        int xStart = i;
        int yStart = i2;
        ByteMatrix matrix = byteMatrix;
        for (int x = 0; x < 8; x++) {
            if (!isEmpty(matrix.get(xStart + x, yStart))) {
                Throwable th2 = th;
                new WriterException();
                throw th2;
            }
            matrix.set(xStart + x, yStart, 0);
        }
    }

    private static void embedVerticalSeparationPattern(int i, int i2, ByteMatrix byteMatrix) throws WriterException {
        Throwable th;
        int xStart = i;
        int yStart = i2;
        ByteMatrix matrix = byteMatrix;
        for (int y = 0; y < 7; y++) {
            if (!isEmpty(matrix.get(xStart, yStart + y))) {
                Throwable th2 = th;
                new WriterException();
                throw th2;
            }
            matrix.set(xStart, yStart + y, 0);
        }
    }

    private static void embedPositionAdjustmentPattern(int i, int i2, ByteMatrix byteMatrix) {
        int xStart = i;
        int yStart = i2;
        ByteMatrix matrix = byteMatrix;
        for (int y = 0; y < 5; y++) {
            for (int x = 0; x < 5; x++) {
                matrix.set(xStart + x, yStart + y, POSITION_ADJUSTMENT_PATTERN[y][x]);
            }
        }
    }

    private static void embedPositionDetectionPattern(int i, int i2, ByteMatrix byteMatrix) {
        int xStart = i;
        int yStart = i2;
        ByteMatrix matrix = byteMatrix;
        for (int y = 0; y < 7; y++) {
            for (int x = 0; x < 7; x++) {
                matrix.set(xStart + x, yStart + y, POSITION_DETECTION_PATTERN[y][x]);
            }
        }
    }

    private static void embedPositionDetectionPatternsAndSeparators(ByteMatrix byteMatrix) throws WriterException {
        ByteMatrix matrix = byteMatrix;
        int pdpWidth = POSITION_DETECTION_PATTERN[0].length;
        embedPositionDetectionPattern(0, 0, matrix);
        embedPositionDetectionPattern(matrix.getWidth() - pdpWidth, 0, matrix);
        embedPositionDetectionPattern(0, matrix.getWidth() - pdpWidth, matrix);
        embedHorizontalSeparationPattern(0, 8 - 1, matrix);
        embedHorizontalSeparationPattern(matrix.getWidth() - 8, 8 - 1, matrix);
        embedHorizontalSeparationPattern(0, matrix.getWidth() - 8, matrix);
        embedVerticalSeparationPattern(7, 0, matrix);
        embedVerticalSeparationPattern((matrix.getHeight() - 7) - 1, 0, matrix);
        embedVerticalSeparationPattern(7, matrix.getHeight() - 7, matrix);
    }

    private static void maybeEmbedPositionAdjustmentPatterns(Version version, ByteMatrix byteMatrix) {
        Version version2 = version;
        ByteMatrix matrix = byteMatrix;
        if (version2.getVersionNumber() >= 2) {
            int index = version2.getVersionNumber() - 1;
            int[] coordinates = POSITION_ADJUSTMENT_PATTERN_COORDINATE_TABLE[index];
            int numCoordinates = POSITION_ADJUSTMENT_PATTERN_COORDINATE_TABLE[index].length;
            for (int i = 0; i < numCoordinates; i++) {
                for (int j = 0; j < numCoordinates; j++) {
                    int y = coordinates[i];
                    int x = coordinates[j];
                    if (!(x == -1 || y == -1 || !isEmpty(matrix.get(x, y)))) {
                        embedPositionAdjustmentPattern(x - 2, y - 2, matrix);
                    }
                }
            }
        }
    }
}
