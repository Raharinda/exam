package com.google.zxing.qrcode.encoder;

import java.lang.reflect.Array;

public final class ByteMatrix {
    private final byte[][] bytes;
    private final int height;
    private final int width;

    public ByteMatrix(int i, int i2) {
        int width2 = i;
        int height2 = i2;
        this.bytes = (byte[][]) Array.newInstance(Byte.TYPE, new int[]{height2, width2});
        this.width = width2;
        this.height = height2;
    }

    public int getHeight() {
        return this.height;
    }

    public int getWidth() {
        return this.width;
    }

    public byte get(int x, int y) {
        return this.bytes[y][x];
    }

    public byte[][] getArray() {
        return this.bytes;
    }

    public void set(int x, int y, byte value) {
        this.bytes[y][x] = value;
    }

    public void set(int x, int y, int value) {
        this.bytes[y][x] = (byte) value;
    }

    public void set(int x, int y, boolean value) {
        this.bytes[y][x] = (byte) (value ? 1 : 0);
    }

    public void clear(byte b) {
        byte value = b;
        for (int y = 0; y < this.height; y++) {
            for (int x = 0; x < this.width; x++) {
                this.bytes[y][x] = value;
            }
        }
    }

    public String toString() {
        StringBuilder sb;
        new StringBuilder((2 * this.width * this.height) + 2);
        StringBuilder result = sb;
        for (int y = 0; y < this.height; y++) {
            for (int x = 0; x < this.width; x++) {
                switch (this.bytes[y][x]) {
                    case 0:
                        StringBuilder append = result.append(" 0");
                        break;
                    case 1:
                        StringBuilder append2 = result.append(" 1");
                        break;
                    default:
                        StringBuilder append3 = result.append("  ");
                        break;
                }
            }
            StringBuilder append4 = result.append(10);
        }
        return result.toString();
    }
}
