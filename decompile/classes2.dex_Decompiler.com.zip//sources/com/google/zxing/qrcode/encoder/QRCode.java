package com.google.zxing.qrcode.encoder;

import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.google.zxing.qrcode.decoder.Mode;
import com.google.zxing.qrcode.decoder.Version;

public final class QRCode {
    public static final int NUM_MASK_PATTERNS = 8;
    private ErrorCorrectionLevel ecLevel;
    private int maskPattern = -1;
    private ByteMatrix matrix;
    private Mode mode;
    private Version version;

    public QRCode() {
    }

    public Mode getMode() {
        return this.mode;
    }

    public ErrorCorrectionLevel getECLevel() {
        return this.ecLevel;
    }

    public Version getVersion() {
        return this.version;
    }

    public int getMaskPattern() {
        return this.maskPattern;
    }

    public ByteMatrix getMatrix() {
        return this.matrix;
    }

    public String toString() {
        StringBuilder sb;
        new StringBuilder(200);
        StringBuilder result = sb;
        StringBuilder append = result.append("<<\n");
        StringBuilder append2 = result.append(" mode: ");
        StringBuilder append3 = result.append(this.mode);
        StringBuilder append4 = result.append("\n ecLevel: ");
        StringBuilder append5 = result.append(this.ecLevel);
        StringBuilder append6 = result.append("\n version: ");
        StringBuilder append7 = result.append(this.version);
        StringBuilder append8 = result.append("\n maskPattern: ");
        StringBuilder append9 = result.append(this.maskPattern);
        if (this.matrix == null) {
            StringBuilder append10 = result.append("\n matrix: null\n");
        } else {
            StringBuilder append11 = result.append("\n matrix:\n");
            StringBuilder append12 = result.append(this.matrix.toString());
        }
        StringBuilder append13 = result.append(">>\n");
        return result.toString();
    }

    public void setMode(Mode value) {
        Mode mode2 = value;
        this.mode = mode2;
    }

    public void setECLevel(ErrorCorrectionLevel value) {
        ErrorCorrectionLevel errorCorrectionLevel = value;
        this.ecLevel = errorCorrectionLevel;
    }

    public void setVersion(Version version2) {
        Version version3 = version2;
        this.version = version3;
    }

    public void setMaskPattern(int value) {
        int i = value;
        this.maskPattern = i;
    }

    public void setMatrix(ByteMatrix value) {
        ByteMatrix byteMatrix = value;
        this.matrix = byteMatrix;
    }

    public static boolean isValidMaskPattern(int i) {
        int maskPattern2 = i;
        return maskPattern2 >= 0 && maskPattern2 < 8;
    }
}
