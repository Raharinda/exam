package com.google.zxing.qrcode.decoder;

public enum ErrorCorrectionLevel {
    ;
    
    private static final ErrorCorrectionLevel[] FOR_BITS = null;
    private final int bits;

    static {
        ErrorCorrectionLevel[] errorCorrectionLevelArr = new ErrorCorrectionLevel[4];
        errorCorrectionLevelArr[0] = M;
        ErrorCorrectionLevel[] errorCorrectionLevelArr2 = errorCorrectionLevelArr;
        errorCorrectionLevelArr2[1] = L;
        ErrorCorrectionLevel[] errorCorrectionLevelArr3 = errorCorrectionLevelArr2;
        errorCorrectionLevelArr3[2] = H;
        ErrorCorrectionLevel[] errorCorrectionLevelArr4 = errorCorrectionLevelArr3;
        errorCorrectionLevelArr4[3] = Q;
        FOR_BITS = errorCorrectionLevelArr4;
    }

    private ErrorCorrectionLevel(int bits2) {
        String str = r8;
        int i = r9;
        this.bits = bits2;
    }

    public int getBits() {
        return this.bits;
    }

    public static ErrorCorrectionLevel forBits(int i) {
        Throwable th;
        int bits2 = i;
        if (bits2 >= 0 && bits2 < FOR_BITS.length) {
            return FOR_BITS[bits2];
        }
        Throwable th2 = th;
        new IllegalArgumentException();
        throw th2;
    }
}
