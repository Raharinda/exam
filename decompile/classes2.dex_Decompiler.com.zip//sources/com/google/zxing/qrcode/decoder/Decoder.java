package com.google.zxing.qrcode.decoder;

import com.google.zxing.ChecksumException;
import com.google.zxing.DecodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.common.reedsolomon.GenericGF;
import com.google.zxing.common.reedsolomon.ReedSolomonDecoder;
import com.google.zxing.common.reedsolomon.ReedSolomonException;
import java.util.Map;

public final class Decoder {
    private final ReedSolomonDecoder rsDecoder;

    public Decoder() {
        ReedSolomonDecoder reedSolomonDecoder;
        new ReedSolomonDecoder(GenericGF.QR_CODE_FIELD_256);
        this.rsDecoder = reedSolomonDecoder;
    }

    public DecoderResult decode(boolean[][] image) throws ChecksumException, FormatException {
        return decode(image, (Map<DecodeHintType, ?>) null);
    }

    public DecoderResult decode(boolean[][] zArr, Map<DecodeHintType, ?> map) throws ChecksumException, FormatException {
        BitMatrix bitMatrix;
        boolean[][] image = zArr;
        Map<DecodeHintType, ?> hints = map;
        int dimension = image.length;
        new BitMatrix(dimension);
        BitMatrix bits = bitMatrix;
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                if (image[i][j]) {
                    bits.set(j, i);
                }
            }
        }
        return decode(bits, hints);
    }

    public DecoderResult decode(BitMatrix bits) throws ChecksumException, FormatException {
        return decode(bits, (Map<DecodeHintType, ?>) null);
    }

    public DecoderResult decode(BitMatrix bits, Map<DecodeHintType, ?> map) throws FormatException, ChecksumException {
        BitMatrixParser bitMatrixParser;
        Map<DecodeHintType, ?> hints = map;
        new BitMatrixParser(bits);
        BitMatrixParser parser = bitMatrixParser;
        Version version = parser.readVersion();
        ErrorCorrectionLevel ecLevel = parser.readFormatInformation().getErrorCorrectionLevel();
        DataBlock[] dataBlocks = DataBlock.getDataBlocks(parser.readCodewords(), version, ecLevel);
        int totalBytes = 0;
        DataBlock[] arr$ = dataBlocks;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            totalBytes += arr$[i$].getNumDataCodewords();
        }
        byte[] resultBytes = new byte[totalBytes];
        int resultOffset = 0;
        DataBlock[] arr$2 = dataBlocks;
        int len$2 = arr$2.length;
        for (int i$2 = 0; i$2 < len$2; i$2++) {
            DataBlock dataBlock = arr$2[i$2];
            byte[] codewordBytes = dataBlock.getCodewords();
            int numDataCodewords = dataBlock.getNumDataCodewords();
            correctErrors(codewordBytes, numDataCodewords);
            for (int i = 0; i < numDataCodewords; i++) {
                int i2 = resultOffset;
                resultOffset++;
                resultBytes[i2] = codewordBytes[i];
            }
        }
        return DecodedBitStreamParser.decode(resultBytes, version, ecLevel, hints);
    }

    private void correctErrors(byte[] bArr, int i) throws ChecksumException {
        byte[] codewordBytes = bArr;
        int numDataCodewords = i;
        int numCodewords = codewordBytes.length;
        int[] codewordsInts = new int[numCodewords];
        for (int i2 = 0; i2 < numCodewords; i2++) {
            codewordsInts[i2] = codewordBytes[i2] & 255;
        }
        try {
            this.rsDecoder.decode(codewordsInts, codewordBytes.length - numDataCodewords);
            for (int i3 = 0; i3 < numDataCodewords; i3++) {
                codewordBytes[i3] = (byte) codewordsInts[i3];
            }
        } catch (ReedSolomonException e) {
            ReedSolomonException reedSolomonException = e;
            throw ChecksumException.getChecksumInstance();
        }
    }
}
