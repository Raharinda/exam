package com.google.zxing.qrcode.detector;

import com.google.zxing.DecodeHintType;
import com.google.zxing.NotFoundException;
import com.google.zxing.ResultPoint;
import com.google.zxing.ResultPointCallback;
import com.google.zxing.common.BitMatrix;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class FinderPatternFinder {
    private static final int CENTER_QUORUM = 2;
    private static final int INTEGER_MATH_SHIFT = 8;
    protected static final int MAX_MODULES = 57;
    protected static final int MIN_SKIP = 3;
    private final int[] crossCheckStateCount;
    private boolean hasSkipped;
    private final BitMatrix image;
    private final List<FinderPattern> possibleCenters;
    private final ResultPointCallback resultPointCallback;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public FinderPatternFinder(BitMatrix image2) {
        this(image2, (ResultPointCallback) null);
    }

    public FinderPatternFinder(BitMatrix image2, ResultPointCallback resultPointCallback2) {
        List<FinderPattern> list;
        this.image = image2;
        new ArrayList();
        this.possibleCenters = list;
        this.crossCheckStateCount = new int[5];
        this.resultPointCallback = resultPointCallback2;
    }

    /* access modifiers changed from: protected */
    public final BitMatrix getImage() {
        return this.image;
    }

    /* access modifiers changed from: protected */
    public final List<FinderPattern> getPossibleCenters() {
        return this.possibleCenters;
    }

    /* access modifiers changed from: package-private */
    public final FinderPatternInfo find(Map<DecodeHintType, ?> map) throws NotFoundException {
        FinderPatternInfo finderPatternInfo;
        Map<DecodeHintType, ?> hints = map;
        boolean tryHarder = hints != null && hints.containsKey(DecodeHintType.TRY_HARDER);
        int maxI = this.image.getHeight();
        int maxJ = this.image.getWidth();
        int iSkip = (3 * maxI) / 228;
        if (iSkip < 3 || tryHarder) {
            iSkip = 3;
        }
        boolean done = false;
        int[] stateCount = new int[5];
        int i = iSkip - 1;
        while (true) {
            int i2 = i;
            if (i2 >= maxI || done) {
                FinderPattern[] patternInfo = selectBestPatterns();
                ResultPoint.orderBestPatterns(patternInfo);
                new FinderPatternInfo(patternInfo);
            } else {
                stateCount[0] = 0;
                stateCount[1] = 0;
                stateCount[2] = 0;
                stateCount[3] = 0;
                stateCount[4] = 0;
                int currentState = 0;
                int j = 0;
                while (j < maxJ) {
                    if (this.image.get(j, i2)) {
                        if ((currentState & 1) == 1) {
                            currentState++;
                        }
                        int[] iArr = stateCount;
                        int i3 = currentState;
                        iArr[i3] = iArr[i3] + 1;
                    } else if ((currentState & 1) != 0) {
                        int[] iArr2 = stateCount;
                        int i4 = currentState;
                        iArr2[i4] = iArr2[i4] + 1;
                    } else if (currentState != 4) {
                        currentState++;
                        int[] iArr3 = stateCount;
                        int i5 = currentState;
                        iArr3[i5] = iArr3[i5] + 1;
                    } else if (!foundPatternCross(stateCount)) {
                        stateCount[0] = stateCount[2];
                        stateCount[1] = stateCount[3];
                        stateCount[2] = stateCount[4];
                        stateCount[3] = 1;
                        stateCount[4] = 0;
                        currentState = 3;
                    } else if (handlePossibleCenter(stateCount, i2, j)) {
                        iSkip = 2;
                        if (this.hasSkipped) {
                            done = haveMultiplyConfirmedCenters();
                        } else {
                            int rowSkip = findRowSkip();
                            if (rowSkip > stateCount[2]) {
                                i2 += (rowSkip - stateCount[2]) - 2;
                                j = maxJ - 1;
                            }
                        }
                        currentState = 0;
                        stateCount[0] = 0;
                        stateCount[1] = 0;
                        stateCount[2] = 0;
                        stateCount[3] = 0;
                        stateCount[4] = 0;
                    } else {
                        stateCount[0] = stateCount[2];
                        stateCount[1] = stateCount[3];
                        stateCount[2] = stateCount[4];
                        stateCount[3] = 1;
                        stateCount[4] = 0;
                        currentState = 3;
                    }
                    j++;
                }
                if (foundPatternCross(stateCount) && handlePossibleCenter(stateCount, i2, maxJ)) {
                    iSkip = stateCount[0];
                    if (this.hasSkipped) {
                        done = haveMultiplyConfirmedCenters();
                    }
                }
                i = i2 + iSkip;
            }
        }
        FinderPattern[] patternInfo2 = selectBestPatterns();
        ResultPoint.orderBestPatterns(patternInfo2);
        new FinderPatternInfo(patternInfo2);
        return finderPatternInfo;
    }

    private static float centerFromEnd(int[] iArr, int end) {
        int[] stateCount = iArr;
        return ((float) ((end - stateCount[4]) - stateCount[3])) - (((float) stateCount[2]) / 2.0f);
    }

    protected static boolean foundPatternCross(int[] iArr) {
        int[] stateCount = iArr;
        int totalModuleSize = 0;
        for (int i = 0; i < 5; i++) {
            int count = stateCount[i];
            if (count == 0) {
                return false;
            }
            totalModuleSize += count;
        }
        if (totalModuleSize < 7) {
            return false;
        }
        int moduleSize = (totalModuleSize << 8) / 7;
        int maxVariance = moduleSize / 2;
        return Math.abs(moduleSize - (stateCount[0] << 8)) < maxVariance && Math.abs(moduleSize - (stateCount[1] << 8)) < maxVariance && Math.abs((3 * moduleSize) - (stateCount[2] << 8)) < 3 * maxVariance && Math.abs(moduleSize - (stateCount[3] << 8)) < maxVariance && Math.abs(moduleSize - (stateCount[4] << 8)) < maxVariance;
    }

    private int[] getCrossCheckStateCount() {
        this.crossCheckStateCount[0] = 0;
        this.crossCheckStateCount[1] = 0;
        this.crossCheckStateCount[2] = 0;
        this.crossCheckStateCount[3] = 0;
        this.crossCheckStateCount[4] = 0;
        return this.crossCheckStateCount;
    }

    private float crossCheckVertical(int i, int i2, int i3, int i4) {
        int startI = i;
        int centerJ = i2;
        int maxCount = i3;
        int originalStateCountTotal = i4;
        BitMatrix image2 = this.image;
        int maxI = image2.getHeight();
        int[] stateCount = getCrossCheckStateCount();
        int i5 = startI;
        while (i5 >= 0 && image2.get(centerJ, i5)) {
            int[] iArr = stateCount;
            iArr[2] = iArr[2] + 1;
            i5--;
        }
        if (i5 < 0) {
            return Float.NaN;
        }
        while (i5 >= 0 && !image2.get(centerJ, i5) && stateCount[1] <= maxCount) {
            int[] iArr2 = stateCount;
            iArr2[1] = iArr2[1] + 1;
            i5--;
        }
        if (i5 < 0 || stateCount[1] > maxCount) {
            return Float.NaN;
        }
        while (i5 >= 0 && image2.get(centerJ, i5) && stateCount[0] <= maxCount) {
            int[] iArr3 = stateCount;
            iArr3[0] = iArr3[0] + 1;
            i5--;
        }
        if (stateCount[0] > maxCount) {
            return Float.NaN;
        }
        int i6 = startI + 1;
        while (i6 < maxI && image2.get(centerJ, i6)) {
            int[] iArr4 = stateCount;
            iArr4[2] = iArr4[2] + 1;
            i6++;
        }
        if (i6 == maxI) {
            return Float.NaN;
        }
        while (i6 < maxI && !image2.get(centerJ, i6) && stateCount[3] < maxCount) {
            int[] iArr5 = stateCount;
            iArr5[3] = iArr5[3] + 1;
            i6++;
        }
        if (i6 == maxI || stateCount[3] >= maxCount) {
            return Float.NaN;
        }
        while (i6 < maxI && image2.get(centerJ, i6) && stateCount[4] < maxCount) {
            int[] iArr6 = stateCount;
            iArr6[4] = iArr6[4] + 1;
            i6++;
        }
        if (stateCount[4] >= maxCount) {
            return Float.NaN;
        }
        if (5 * Math.abs(((((stateCount[0] + stateCount[1]) + stateCount[2]) + stateCount[3]) + stateCount[4]) - originalStateCountTotal) >= 2 * originalStateCountTotal) {
            return Float.NaN;
        }
        return foundPatternCross(stateCount) ? centerFromEnd(stateCount, i6) : Float.NaN;
    }

    private float crossCheckHorizontal(int i, int i2, int i3, int i4) {
        int startJ = i;
        int centerI = i2;
        int maxCount = i3;
        int originalStateCountTotal = i4;
        BitMatrix image2 = this.image;
        int maxJ = image2.getWidth();
        int[] stateCount = getCrossCheckStateCount();
        int j = startJ;
        while (j >= 0 && image2.get(j, centerI)) {
            int[] iArr = stateCount;
            iArr[2] = iArr[2] + 1;
            j--;
        }
        if (j < 0) {
            return Float.NaN;
        }
        while (j >= 0 && !image2.get(j, centerI) && stateCount[1] <= maxCount) {
            int[] iArr2 = stateCount;
            iArr2[1] = iArr2[1] + 1;
            j--;
        }
        if (j < 0 || stateCount[1] > maxCount) {
            return Float.NaN;
        }
        while (j >= 0 && image2.get(j, centerI) && stateCount[0] <= maxCount) {
            int[] iArr3 = stateCount;
            iArr3[0] = iArr3[0] + 1;
            j--;
        }
        if (stateCount[0] > maxCount) {
            return Float.NaN;
        }
        int j2 = startJ + 1;
        while (j2 < maxJ && image2.get(j2, centerI)) {
            int[] iArr4 = stateCount;
            iArr4[2] = iArr4[2] + 1;
            j2++;
        }
        if (j2 == maxJ) {
            return Float.NaN;
        }
        while (j2 < maxJ && !image2.get(j2, centerI) && stateCount[3] < maxCount) {
            int[] iArr5 = stateCount;
            iArr5[3] = iArr5[3] + 1;
            j2++;
        }
        if (j2 == maxJ || stateCount[3] >= maxCount) {
            return Float.NaN;
        }
        while (j2 < maxJ && image2.get(j2, centerI) && stateCount[4] < maxCount) {
            int[] iArr6 = stateCount;
            iArr6[4] = iArr6[4] + 1;
            j2++;
        }
        if (stateCount[4] >= maxCount) {
            return Float.NaN;
        }
        if (5 * Math.abs(((((stateCount[0] + stateCount[1]) + stateCount[2]) + stateCount[3]) + stateCount[4]) - originalStateCountTotal) >= originalStateCountTotal) {
            return Float.NaN;
        }
        return foundPatternCross(stateCount) ? centerFromEnd(stateCount, j2) : Float.NaN;
    }

    /* access modifiers changed from: protected */
    public final boolean handlePossibleCenter(int[] iArr, int i, int j) {
        FinderPattern finderPattern;
        int[] stateCount = iArr;
        int stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2] + stateCount[3] + stateCount[4];
        float centerJ = centerFromEnd(stateCount, j);
        float centerI = crossCheckVertical(i, (int) centerJ, stateCount[2], stateCountTotal);
        if (!Float.isNaN(centerI)) {
            float centerJ2 = crossCheckHorizontal((int) centerJ, (int) centerI, stateCount[2], stateCountTotal);
            if (!Float.isNaN(centerJ2)) {
                float estimatedModuleSize = ((float) stateCountTotal) / 7.0f;
                boolean found = false;
                int index = 0;
                while (true) {
                    if (index >= this.possibleCenters.size()) {
                        break;
                    }
                    FinderPattern center = this.possibleCenters.get(index);
                    if (center.aboutEquals(estimatedModuleSize, centerI, centerJ2)) {
                        FinderPattern finderPattern2 = this.possibleCenters.set(index, center.combineEstimate(centerI, centerJ2, estimatedModuleSize));
                        found = true;
                        break;
                    }
                    index++;
                }
                if (!found) {
                    new FinderPattern(centerJ2, centerI, estimatedModuleSize);
                    FinderPattern point = finderPattern;
                    boolean add = this.possibleCenters.add(point);
                    if (this.resultPointCallback != null) {
                        this.resultPointCallback.foundPossibleResultPoint(point);
                    }
                }
                return true;
            }
        }
        return false;
    }

    private int findRowSkip() {
        if (this.possibleCenters.size() <= 1) {
            return 0;
        }
        FinderPattern firstConfirmedCenter = null;
        for (FinderPattern center : this.possibleCenters) {
            if (center.getCount() >= 2) {
                if (firstConfirmedCenter == null) {
                    firstConfirmedCenter = center;
                } else {
                    this.hasSkipped = true;
                    return ((int) (Math.abs(firstConfirmedCenter.getX() - center.getX()) - Math.abs(firstConfirmedCenter.getY() - center.getY()))) / 2;
                }
            }
        }
        return 0;
    }

    private boolean haveMultiplyConfirmedCenters() {
        int confirmedCount = 0;
        float totalModuleSize = 0.0f;
        int max = this.possibleCenters.size();
        for (FinderPattern pattern : this.possibleCenters) {
            if (pattern.getCount() >= 2) {
                confirmedCount++;
                totalModuleSize += pattern.getEstimatedModuleSize();
            }
        }
        if (confirmedCount < 3) {
            return false;
        }
        float average = totalModuleSize / ((float) max);
        float totalDeviation = 0.0f;
        for (FinderPattern pattern2 : this.possibleCenters) {
            totalDeviation += Math.abs(pattern2.getEstimatedModuleSize() - average);
        }
        return totalDeviation <= 0.05f * totalModuleSize;
    }

    private FinderPattern[] selectBestPatterns() throws NotFoundException {
        Comparator comparator;
        Comparator comparator2;
        int startSize = this.possibleCenters.size();
        if (startSize < 3) {
            throw NotFoundException.getNotFoundInstance();
        }
        if (startSize > 3) {
            float totalModuleSize = 0.0f;
            float square = 0.0f;
            for (FinderPattern center : this.possibleCenters) {
                float size = center.getEstimatedModuleSize();
                totalModuleSize += size;
                square += size * size;
            }
            float average = totalModuleSize / ((float) startSize);
            float stdDev = (float) Math.sqrt((double) ((square / ((float) startSize)) - (average * average)));
            new FurthestFromAverageComparator(average, (AnonymousClass1) null);
            Collections.sort(this.possibleCenters, comparator2);
            float limit = Math.max(0.2f * average, stdDev);
            int i = 0;
            while (i < this.possibleCenters.size() && this.possibleCenters.size() > 3) {
                if (Math.abs(this.possibleCenters.get(i).getEstimatedModuleSize() - average) > limit) {
                    FinderPattern remove = this.possibleCenters.remove(i);
                    i--;
                }
                i++;
            }
        }
        if (this.possibleCenters.size() > 3) {
            float totalModuleSize2 = 0.0f;
            for (FinderPattern possibleCenter : this.possibleCenters) {
                totalModuleSize2 += possibleCenter.getEstimatedModuleSize();
            }
            new CenterComparator(totalModuleSize2 / ((float) this.possibleCenters.size()), (AnonymousClass1) null);
            Collections.sort(this.possibleCenters, comparator);
            this.possibleCenters.subList(3, this.possibleCenters.size()).clear();
        }
        FinderPattern[] finderPatternArr = new FinderPattern[3];
        finderPatternArr[0] = this.possibleCenters.get(0);
        FinderPattern[] finderPatternArr2 = finderPatternArr;
        finderPatternArr2[1] = this.possibleCenters.get(1);
        FinderPattern[] finderPatternArr3 = finderPatternArr2;
        finderPatternArr3[2] = this.possibleCenters.get(2);
        return finderPatternArr3;
    }

    private static final class FurthestFromAverageComparator implements Comparator<FinderPattern>, Serializable {
        private final float average;

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ FurthestFromAverageComparator(float x0, AnonymousClass1 r7) {
            this(x0);
            AnonymousClass1 r2 = r7;
        }

        private FurthestFromAverageComparator(float f) {
            this.average = f;
        }

        public int compare(FinderPattern center1, FinderPattern center2) {
            float dA = Math.abs(center2.getEstimatedModuleSize() - this.average);
            float dB = Math.abs(center1.getEstimatedModuleSize() - this.average);
            return dA < dB ? -1 : dA == dB ? 0 : 1;
        }
    }

    private static final class CenterComparator implements Comparator<FinderPattern>, Serializable {
        private final float average;

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ CenterComparator(float x0, AnonymousClass1 r7) {
            this(x0);
            AnonymousClass1 r2 = r7;
        }

        private CenterComparator(float f) {
            this.average = f;
        }

        public int compare(FinderPattern finderPattern, FinderPattern finderPattern2) {
            FinderPattern center1 = finderPattern;
            FinderPattern center2 = finderPattern2;
            if (center2.getCount() != center1.getCount()) {
                return center2.getCount() - center1.getCount();
            }
            float dA = Math.abs(center2.getEstimatedModuleSize() - this.average);
            float dB = Math.abs(center1.getEstimatedModuleSize() - this.average);
            return dA < dB ? 1 : dA == dB ? 0 : -1;
        }
    }
}
