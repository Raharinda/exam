package com.google.zxing.qrcode.decoder;

import org.jose4j.jwt.consumer.ErrorCodes;

public enum Mode {
    ;
    
    private final int bits;
    private final int[] characterCountBitsForVersions;

    private Mode(int[] characterCountBitsForVersions2, int bits2) {
        String str = r9;
        int i = r10;
        this.characterCountBitsForVersions = characterCountBitsForVersions2;
        this.bits = bits2;
    }

    public static Mode forBits(int bits2) {
        Throwable th;
        switch (bits2) {
            case 0:
                return TERMINATOR;
            case 1:
                return NUMERIC;
            case 2:
                return ALPHANUMERIC;
            case 3:
                return STRUCTURED_APPEND;
            case 4:
                return BYTE;
            case 5:
                return FNC1_FIRST_POSITION;
            case ErrorCodes.AUDIENCE_MISSING /*7*/:
                return ECI;
            case 8:
                return KANJI;
            case ErrorCodes.SIGNATURE_INVALID /*9*/:
                return FNC1_SECOND_POSITION;
            case ErrorCodes.JWT_ID_MISSING /*13*/:
                return HANZI;
            default:
                Throwable th2 = th;
                new IllegalArgumentException();
                throw th2;
        }
    }

    public int getCharacterCountBits(Version version) {
        int offset;
        int number = version.getVersionNumber();
        if (number <= 9) {
            offset = 0;
        } else if (number <= 26) {
            offset = true;
        } else {
            offset = 2;
        }
        return this.characterCountBitsForVersions[offset];
    }

    public int getBits() {
        return this.bits;
    }
}
