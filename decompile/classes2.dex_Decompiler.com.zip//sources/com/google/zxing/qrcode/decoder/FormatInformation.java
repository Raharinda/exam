package com.google.zxing.qrcode.decoder;

final class FormatInformation {
    private static final int[] BITS_SET_IN_HALF_BYTE = {0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4};
    private static final int[][] FORMAT_INFO_DECODE_LOOKUP;
    private static final int FORMAT_INFO_MASK_QR = 21522;
    private final byte dataMask;
    private final ErrorCorrectionLevel errorCorrectionLevel;

    static {
        int[][] iArr = new int[32][];
        iArr[0] = new int[]{FORMAT_INFO_MASK_QR, 0};
        int[][] iArr2 = iArr;
        iArr2[1] = new int[]{20773, 1};
        int[][] iArr3 = iArr2;
        iArr3[2] = new int[]{24188, 2};
        int[][] iArr4 = iArr3;
        iArr4[3] = new int[]{23371, 3};
        int[][] iArr5 = iArr4;
        iArr5[4] = new int[]{17913, 4};
        int[][] iArr6 = iArr5;
        iArr6[5] = new int[]{16590, 5};
        int[][] iArr7 = iArr6;
        iArr7[6] = new int[]{20375, 6};
        int[][] iArr8 = iArr7;
        iArr8[7] = new int[]{19104, 7};
        int[][] iArr9 = iArr8;
        iArr9[8] = new int[]{30660, 8};
        int[][] iArr10 = iArr9;
        iArr10[9] = new int[]{29427, 9};
        int[][] iArr11 = iArr10;
        iArr11[10] = new int[]{32170, 10};
        int[][] iArr12 = iArr11;
        iArr12[11] = new int[]{30877, 11};
        int[][] iArr13 = iArr12;
        iArr13[12] = new int[]{26159, 12};
        int[][] iArr14 = iArr13;
        iArr14[13] = new int[]{25368, 13};
        int[][] iArr15 = iArr14;
        iArr15[14] = new int[]{27713, 14};
        int[][] iArr16 = iArr15;
        iArr16[15] = new int[]{26998, 15};
        int[][] iArr17 = iArr16;
        iArr17[16] = new int[]{5769, 16};
        int[][] iArr18 = iArr17;
        iArr18[17] = new int[]{5054, 17};
        int[][] iArr19 = iArr18;
        iArr19[18] = new int[]{7399, 18};
        int[][] iArr20 = iArr19;
        iArr20[19] = new int[]{6608, 19};
        int[][] iArr21 = iArr20;
        iArr21[20] = new int[]{1890, 20};
        int[][] iArr22 = iArr21;
        iArr22[21] = new int[]{597, 21};
        int[][] iArr23 = iArr22;
        iArr23[22] = new int[]{3340, 22};
        int[][] iArr24 = iArr23;
        iArr24[23] = new int[]{2107, 23};
        int[][] iArr25 = iArr24;
        iArr25[24] = new int[]{13663, 24};
        int[][] iArr26 = iArr25;
        iArr26[25] = new int[]{12392, 25};
        int[][] iArr27 = iArr26;
        iArr27[26] = new int[]{16177, 26};
        int[][] iArr28 = iArr27;
        iArr28[27] = new int[]{14854, 27};
        int[][] iArr29 = iArr28;
        iArr29[28] = new int[]{9396, 28};
        int[][] iArr30 = iArr29;
        iArr30[29] = new int[]{8579, 29};
        int[][] iArr31 = iArr30;
        iArr31[30] = new int[]{11994, 30};
        int[][] iArr32 = iArr31;
        iArr32[31] = new int[]{11245, 31};
        FORMAT_INFO_DECODE_LOOKUP = iArr32;
    }

    private FormatInformation(int i) {
        int formatInfo = i;
        this.errorCorrectionLevel = ErrorCorrectionLevel.forBits((formatInfo >> 3) & 3);
        this.dataMask = (byte) (formatInfo & 7);
    }

    static int numBitsDiffering(int a, int b) {
        int a2 = a ^ b;
        return BITS_SET_IN_HALF_BYTE[a2 & 15] + BITS_SET_IN_HALF_BYTE[(a2 >>> 4) & 15] + BITS_SET_IN_HALF_BYTE[(a2 >>> 8) & 15] + BITS_SET_IN_HALF_BYTE[(a2 >>> 12) & 15] + BITS_SET_IN_HALF_BYTE[(a2 >>> 16) & 15] + BITS_SET_IN_HALF_BYTE[(a2 >>> 20) & 15] + BITS_SET_IN_HALF_BYTE[(a2 >>> 24) & 15] + BITS_SET_IN_HALF_BYTE[(a2 >>> 28) & 15];
    }

    static FormatInformation decodeFormatInformation(int i, int i2) {
        int maskedFormatInfo1 = i;
        int maskedFormatInfo2 = i2;
        FormatInformation formatInfo = doDecodeFormatInformation(maskedFormatInfo1, maskedFormatInfo2);
        if (formatInfo != null) {
            return formatInfo;
        }
        return doDecodeFormatInformation(maskedFormatInfo1 ^ FORMAT_INFO_MASK_QR, maskedFormatInfo2 ^ FORMAT_INFO_MASK_QR);
    }

    private static FormatInformation doDecodeFormatInformation(int i, int i2) {
        FormatInformation formatInformation;
        FormatInformation formatInformation2;
        int bitsDifference;
        int maskedFormatInfo1 = i;
        int maskedFormatInfo2 = i2;
        int bestDifference = Integer.MAX_VALUE;
        int bestFormatInfo = 0;
        int[][] arr$ = FORMAT_INFO_DECODE_LOOKUP;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            int[] decodeInfo = arr$[i$];
            int targetInfo = decodeInfo[0];
            if (targetInfo == maskedFormatInfo1 || targetInfo == maskedFormatInfo2) {
                new FormatInformation(decodeInfo[1]);
                return formatInformation2;
            }
            int bitsDifference2 = numBitsDiffering(maskedFormatInfo1, targetInfo);
            if (bitsDifference2 < bestDifference) {
                bestFormatInfo = decodeInfo[1];
                bestDifference = bitsDifference2;
            }
            if (maskedFormatInfo1 != maskedFormatInfo2 && (bitsDifference = numBitsDiffering(maskedFormatInfo2, targetInfo)) < bestDifference) {
                bestFormatInfo = decodeInfo[1];
                bestDifference = bitsDifference;
            }
        }
        if (bestDifference > 3) {
            return null;
        }
        new FormatInformation(bestFormatInfo);
        return formatInformation;
    }

    /* access modifiers changed from: package-private */
    public ErrorCorrectionLevel getErrorCorrectionLevel() {
        return this.errorCorrectionLevel;
    }

    /* access modifiers changed from: package-private */
    public byte getDataMask() {
        return this.dataMask;
    }

    public int hashCode() {
        return (this.errorCorrectionLevel.ordinal() << 3) | this.dataMask;
    }

    public boolean equals(Object obj) {
        Object o = obj;
        if (!(o instanceof FormatInformation)) {
            return false;
        }
        FormatInformation other = (FormatInformation) o;
        return this.errorCorrectionLevel == other.errorCorrectionLevel && this.dataMask == other.dataMask;
    }
}
