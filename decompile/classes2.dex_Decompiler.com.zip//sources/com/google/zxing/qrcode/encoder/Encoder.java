package com.google.zxing.qrcode.encoder;

import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitArray;
import com.google.zxing.common.CharacterSetECI;
import com.google.zxing.common.reedsolomon.GenericGF;
import com.google.zxing.common.reedsolomon.ReedSolomonEncoder;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.google.zxing.qrcode.decoder.Mode;
import com.google.zxing.qrcode.decoder.Version;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

public final class Encoder {
    private static final int[] ALPHANUMERIC_TABLE = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 36, -1, -1, -1, 37, 38, -1, -1, -1, -1, 39, 40, -1, 41, 42, 43, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 44, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, -1, -1, -1, -1, -1};
    static final String DEFAULT_BYTE_MODE_ENCODING = "ISO-8859-1";

    private Encoder() {
    }

    private static int calculateMaskPenalty(ByteMatrix byteMatrix) {
        ByteMatrix matrix = byteMatrix;
        return MaskUtil.applyMaskPenaltyRule1(matrix) + MaskUtil.applyMaskPenaltyRule2(matrix) + MaskUtil.applyMaskPenaltyRule3(matrix) + MaskUtil.applyMaskPenaltyRule4(matrix);
    }

    public static QRCode encode(String content, ErrorCorrectionLevel ecLevel) throws WriterException {
        return encode(content, ecLevel, (Map<EncodeHintType, ?>) null);
    }

    public static QRCode encode(String str, ErrorCorrectionLevel errorCorrectionLevel, Map<EncodeHintType, ?> map) throws WriterException {
        String str2;
        BitArray bitArray;
        BitArray bitArray2;
        BitArray bitArray3;
        QRCode qRCode;
        ByteMatrix byteMatrix;
        CharacterSetECI eci;
        String content = str;
        ErrorCorrectionLevel ecLevel = errorCorrectionLevel;
        Map<EncodeHintType, ?> hints = map;
        if (hints == null) {
            str2 = null;
        } else {
            str2 = (String) hints.get(EncodeHintType.CHARACTER_SET);
        }
        String encoding = str2;
        if (encoding == null) {
            encoding = DEFAULT_BYTE_MODE_ENCODING;
        }
        Mode mode = chooseMode(content, encoding);
        new BitArray();
        BitArray headerBits = bitArray;
        if (mode == Mode.BYTE && !DEFAULT_BYTE_MODE_ENCODING.equals(encoding) && (eci = CharacterSetECI.getCharacterSetECIByName(encoding)) != null) {
            appendECI(eci, headerBits);
        }
        appendModeInfo(mode, headerBits);
        new BitArray();
        BitArray dataBits = bitArray2;
        appendBytes(content, mode, dataBits, encoding);
        Version version = chooseVersion(headerBits.getSize() + mode.getCharacterCountBits(chooseVersion(headerBits.getSize() + mode.getCharacterCountBits(Version.getVersionForNumber(1)) + dataBits.getSize(), ecLevel)) + dataBits.getSize(), ecLevel);
        new BitArray();
        BitArray headerAndDataBits = bitArray3;
        headerAndDataBits.appendBitArray(headerBits);
        appendLengthInfo(mode == Mode.BYTE ? dataBits.getSizeInBytes() : content.length(), version, mode, headerAndDataBits);
        headerAndDataBits.appendBitArray(dataBits);
        Version.ECBlocks ecBlocks = version.getECBlocksForLevel(ecLevel);
        int numDataBytes = version.getTotalCodewords() - ecBlocks.getTotalECCodewords();
        terminateBits(numDataBytes, headerAndDataBits);
        BitArray finalBits = interleaveWithECBytes(headerAndDataBits, version.getTotalCodewords(), numDataBytes, ecBlocks.getNumBlocks());
        new QRCode();
        QRCode qrCode = qRCode;
        qrCode.setECLevel(ecLevel);
        qrCode.setMode(mode);
        qrCode.setVersion(version);
        int dimension = version.getDimensionForVersion();
        new ByteMatrix(dimension, dimension);
        ByteMatrix matrix = byteMatrix;
        int maskPattern = chooseMaskPattern(finalBits, ecLevel, version, matrix);
        qrCode.setMaskPattern(maskPattern);
        MatrixUtil.buildMatrix(finalBits, ecLevel, version, maskPattern, matrix);
        qrCode.setMatrix(matrix);
        return qrCode;
    }

    static int getAlphanumericCode(int i) {
        int code = i;
        if (code < ALPHANUMERIC_TABLE.length) {
            return ALPHANUMERIC_TABLE[code];
        }
        return -1;
    }

    public static Mode chooseMode(String content) {
        return chooseMode(content, (String) null);
    }

    private static Mode chooseMode(String str, String encoding) {
        Mode mode;
        String content = str;
        if ("Shift_JIS".equals(encoding)) {
            if (isOnlyDoubleByteKanji(content)) {
                mode = Mode.KANJI;
            } else {
                mode = Mode.BYTE;
            }
            return mode;
        }
        boolean hasNumeric = false;
        boolean hasAlphanumeric = false;
        for (int i = 0; i < content.length(); i++) {
            char c = content.charAt(i);
            if (c >= '0' && c <= '9') {
                hasNumeric = true;
            } else if (getAlphanumericCode(c) == -1) {
                return Mode.BYTE;
            } else {
                hasAlphanumeric = true;
            }
        }
        if (hasAlphanumeric) {
            return Mode.ALPHANUMERIC;
        }
        if (hasNumeric) {
            return Mode.NUMERIC;
        }
        return Mode.BYTE;
    }

    private static boolean isOnlyDoubleByteKanji(String content) {
        try {
            byte[] bytes = content.getBytes("Shift_JIS");
            int length = bytes.length;
            if (length % 2 != 0) {
                return false;
            }
            for (int i = 0; i < length; i += 2) {
                int byte1 = bytes[i] & 255;
                if ((byte1 < 129 || byte1 > 159) && (byte1 < 224 || byte1 > 235)) {
                    return false;
                }
            }
            return true;
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException unsupportedEncodingException = e;
            return false;
        }
    }

    private static int chooseMaskPattern(BitArray bitArray, ErrorCorrectionLevel errorCorrectionLevel, Version version, ByteMatrix byteMatrix) throws WriterException {
        BitArray bits = bitArray;
        ErrorCorrectionLevel ecLevel = errorCorrectionLevel;
        Version version2 = version;
        ByteMatrix matrix = byteMatrix;
        int minPenalty = Integer.MAX_VALUE;
        int bestMaskPattern = -1;
        for (int maskPattern = 0; maskPattern < 8; maskPattern++) {
            MatrixUtil.buildMatrix(bits, ecLevel, version2, maskPattern, matrix);
            int penalty = calculateMaskPenalty(matrix);
            if (penalty < minPenalty) {
                minPenalty = penalty;
                bestMaskPattern = maskPattern;
            }
        }
        return bestMaskPattern;
    }

    private static Version chooseVersion(int i, ErrorCorrectionLevel errorCorrectionLevel) throws WriterException {
        Throwable th;
        int numInputBits = i;
        ErrorCorrectionLevel ecLevel = errorCorrectionLevel;
        for (int versionNum = 1; versionNum <= 40; versionNum++) {
            Version version = Version.getVersionForNumber(versionNum);
            if (version.getTotalCodewords() - version.getECBlocksForLevel(ecLevel).getTotalECCodewords() >= (numInputBits + 7) / 8) {
                return version;
            }
        }
        Throwable th2 = th;
        new WriterException("Data too big");
        throw th2;
    }

    static void terminateBits(int i, BitArray bitArray) throws WriterException {
        Throwable th;
        Throwable th2;
        StringBuilder sb;
        int numDataBytes = i;
        BitArray bits = bitArray;
        int capacity = numDataBytes << 3;
        if (bits.getSize() > capacity) {
            Throwable th3 = th2;
            new StringBuilder();
            new WriterException(sb.append("data bits cannot fit in the QR Code").append(bits.getSize()).append(" > ").append(capacity).toString());
            throw th3;
        }
        for (int i2 = 0; i2 < 4 && bits.getSize() < capacity; i2++) {
            bits.appendBit(false);
        }
        int numBitsInLastByte = bits.getSize() & 7;
        if (numBitsInLastByte > 0) {
            for (int i3 = numBitsInLastByte; i3 < 8; i3++) {
                bits.appendBit(false);
            }
        }
        int numPaddingBytes = numDataBytes - bits.getSizeInBytes();
        for (int i4 = 0; i4 < numPaddingBytes; i4++) {
            bits.appendBits((i4 & 1) == 0 ? 236 : 17, 8);
        }
        if (bits.getSize() != capacity) {
            Throwable th4 = th;
            new WriterException("Bits size does not equal capacity");
            throw th4;
        }
    }

    static void getNumDataBytesAndNumECBytesForBlockID(int i, int i2, int i3, int i4, int[] iArr, int[] iArr2) throws WriterException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        int numTotalBytes = i;
        int numDataBytes = i2;
        int numRSBlocks = i3;
        int blockID = i4;
        int[] numDataBytesInBlock = iArr;
        int[] numECBytesInBlock = iArr2;
        if (blockID >= numRSBlocks) {
            Throwable th5 = th4;
            new WriterException("Block ID too large");
            throw th5;
        }
        int numRsBlocksInGroup2 = numTotalBytes % numRSBlocks;
        int numRsBlocksInGroup1 = numRSBlocks - numRsBlocksInGroup2;
        int numTotalBytesInGroup1 = numTotalBytes / numRSBlocks;
        int numDataBytesInGroup1 = numDataBytes / numRSBlocks;
        int numDataBytesInGroup2 = numDataBytesInGroup1 + 1;
        int numEcBytesInGroup1 = numTotalBytesInGroup1 - numDataBytesInGroup1;
        int numEcBytesInGroup2 = (numTotalBytesInGroup1 + 1) - numDataBytesInGroup2;
        if (numEcBytesInGroup1 != numEcBytesInGroup2) {
            Throwable th6 = th3;
            new WriterException("EC bytes mismatch");
            throw th6;
        } else if (numRSBlocks != numRsBlocksInGroup1 + numRsBlocksInGroup2) {
            Throwable th7 = th2;
            new WriterException("RS blocks mismatch");
            throw th7;
        } else if (numTotalBytes != ((numDataBytesInGroup1 + numEcBytesInGroup1) * numRsBlocksInGroup1) + ((numDataBytesInGroup2 + numEcBytesInGroup2) * numRsBlocksInGroup2)) {
            Throwable th8 = th;
            new WriterException("Total bytes mismatch");
            throw th8;
        } else if (blockID < numRsBlocksInGroup1) {
            numDataBytesInBlock[0] = numDataBytesInGroup1;
            numECBytesInBlock[0] = numEcBytesInGroup1;
        } else {
            numDataBytesInBlock[0] = numDataBytesInGroup2;
            numECBytesInBlock[0] = numEcBytesInGroup2;
        }
    }

    static BitArray interleaveWithECBytes(BitArray bitArray, int i, int i2, int i3) throws WriterException {
        Collection<BlockPair> collection;
        BitArray bitArray2;
        Throwable th;
        StringBuilder sb;
        Throwable th2;
        Object obj;
        Throwable th3;
        BitArray bits = bitArray;
        int numTotalBytes = i;
        int numDataBytes = i2;
        int numRSBlocks = i3;
        if (bits.getSizeInBytes() != numDataBytes) {
            Throwable th4 = th3;
            new WriterException("Number of bits and data bytes does not match");
            throw th4;
        }
        int dataBytesOffset = 0;
        int maxNumDataBytes = 0;
        int maxNumEcBytes = 0;
        new ArrayList<>(numRSBlocks);
        Collection<BlockPair> blocks = collection;
        for (int i4 = 0; i4 < numRSBlocks; i4++) {
            int[] numDataBytesInBlock = new int[1];
            int[] numEcBytesInBlock = new int[1];
            getNumDataBytesAndNumECBytesForBlockID(numTotalBytes, numDataBytes, numRSBlocks, i4, numDataBytesInBlock, numEcBytesInBlock);
            int size = numDataBytesInBlock[0];
            byte[] dataBytes = new byte[size];
            bits.toBytes(8 * dataBytesOffset, dataBytes, 0, size);
            byte[] ecBytes = generateECBytes(dataBytes, numEcBytesInBlock[0]);
            new BlockPair(dataBytes, ecBytes);
            boolean add = blocks.add(obj);
            maxNumDataBytes = Math.max(maxNumDataBytes, size);
            maxNumEcBytes = Math.max(maxNumEcBytes, ecBytes.length);
            dataBytesOffset += numDataBytesInBlock[0];
        }
        if (numDataBytes != dataBytesOffset) {
            Throwable th5 = th2;
            new WriterException("Data bytes does not match offset");
            throw th5;
        }
        new BitArray();
        BitArray result = bitArray2;
        for (int i5 = 0; i5 < maxNumDataBytes; i5++) {
            for (BlockPair block : blocks) {
                byte[] dataBytes2 = block.getDataBytes();
                if (i5 < dataBytes2.length) {
                    result.appendBits(dataBytes2[i5], 8);
                }
            }
        }
        for (int i6 = 0; i6 < maxNumEcBytes; i6++) {
            for (BlockPair block2 : blocks) {
                byte[] ecBytes2 = block2.getErrorCorrectionBytes();
                if (i6 < ecBytes2.length) {
                    result.appendBits(ecBytes2[i6], 8);
                }
            }
        }
        if (numTotalBytes == result.getSizeInBytes()) {
            return result;
        }
        Throwable th6 = th;
        new StringBuilder();
        new WriterException(sb.append("Interleaving error: ").append(numTotalBytes).append(" and ").append(result.getSizeInBytes()).append(" differ.").toString());
        throw th6;
    }

    static byte[] generateECBytes(byte[] bArr, int i) {
        ReedSolomonEncoder reedSolomonEncoder;
        byte[] dataBytes = bArr;
        int numEcBytesInBlock = i;
        int numDataBytes = dataBytes.length;
        int[] toEncode = new int[(numDataBytes + numEcBytesInBlock)];
        for (int i2 = 0; i2 < numDataBytes; i2++) {
            toEncode[i2] = dataBytes[i2] & 255;
        }
        new ReedSolomonEncoder(GenericGF.QR_CODE_FIELD_256);
        reedSolomonEncoder.encode(toEncode, numEcBytesInBlock);
        byte[] ecBytes = new byte[numEcBytesInBlock];
        for (int i3 = 0; i3 < numEcBytesInBlock; i3++) {
            ecBytes[i3] = (byte) toEncode[numDataBytes + i3];
        }
        return ecBytes;
    }

    static void appendModeInfo(Mode mode, BitArray bits) {
        bits.appendBits(mode.getBits(), 4);
    }

    static void appendLengthInfo(int i, Version version, Mode mode, BitArray bitArray) throws WriterException {
        Throwable th;
        StringBuilder sb;
        int numLetters = i;
        BitArray bits = bitArray;
        int numBits = mode.getCharacterCountBits(version);
        if (numLetters >= (1 << numBits)) {
            Throwable th2 = th;
            new StringBuilder();
            new WriterException(sb.append(numLetters).append(" is bigger than ").append((1 << numBits) - 1).toString());
            throw th2;
        }
        bits.appendBits(numLetters, numBits);
    }

    static void appendBytes(String str, Mode mode, BitArray bitArray, String str2) throws WriterException {
        Throwable th;
        StringBuilder sb;
        String content = str;
        Mode mode2 = mode;
        BitArray bits = bitArray;
        String encoding = str2;
        switch (mode2) {
            case NUMERIC:
                appendNumericBytes(content, bits);
                return;
            case ALPHANUMERIC:
                appendAlphanumericBytes(content, bits);
                return;
            case BYTE:
                append8BitBytes(content, bits, encoding);
                return;
            case KANJI:
                appendKanjiBytes(content, bits);
                return;
            default:
                Throwable th2 = th;
                new StringBuilder();
                new WriterException(sb.append("Invalid mode: ").append(mode2).toString());
                throw th2;
        }
    }

    static void appendNumericBytes(CharSequence charSequence, BitArray bitArray) {
        CharSequence content = charSequence;
        BitArray bits = bitArray;
        int length = content.length();
        int i = 0;
        while (i < length) {
            int num1 = content.charAt(i) - '0';
            if (i + 2 < length) {
                bits.appendBits((num1 * 100) + ((content.charAt(i + 1) - '0') * 10) + (content.charAt(i + 2) - '0'), 10);
                i += 3;
            } else if (i + 1 < length) {
                bits.appendBits((num1 * 10) + (content.charAt(i + 1) - '0'), 7);
                i += 2;
            } else {
                bits.appendBits(num1, 4);
                i++;
            }
        }
    }

    static void appendAlphanumericBytes(CharSequence charSequence, BitArray bitArray) throws WriterException {
        Throwable th;
        Throwable th2;
        CharSequence content = charSequence;
        BitArray bits = bitArray;
        int length = content.length();
        int i = 0;
        while (i < length) {
            int code1 = getAlphanumericCode(content.charAt(i));
            if (code1 == -1) {
                Throwable th3 = th;
                new WriterException();
                throw th3;
            } else if (i + 1 < length) {
                int code2 = getAlphanumericCode(content.charAt(i + 1));
                if (code2 == -1) {
                    Throwable th4 = th2;
                    new WriterException();
                    throw th4;
                }
                bits.appendBits((code1 * 45) + code2, 11);
                i += 2;
            } else {
                bits.appendBits(code1, 6);
                i++;
            }
        }
    }

    static void append8BitBytes(String content, BitArray bitArray, String encoding) throws WriterException {
        Throwable th;
        BitArray bits = bitArray;
        try {
            byte[] arr$ = content.getBytes(encoding);
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                bits.appendBits(arr$[i$], 8);
            }
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException uee = e;
            Throwable th2 = th;
            new WriterException((Throwable) uee);
            throw th2;
        }
    }

    static void appendKanjiBytes(String content, BitArray bitArray) throws WriterException {
        Throwable th;
        Throwable th2;
        BitArray bits = bitArray;
        try {
            byte[] bytes = content.getBytes("Shift_JIS");
            int length = bytes.length;
            for (int i = 0; i < length; i += 2) {
                int code = ((bytes[i] & 255) << 8) | (bytes[i + 1] & 255);
                int subtracted = -1;
                if (code >= 33088 && code <= 40956) {
                    subtracted = code - 33088;
                } else if (code >= 57408 && code <= 60351) {
                    subtracted = code - 49472;
                }
                if (subtracted == -1) {
                    Throwable th3 = th2;
                    new WriterException("Invalid byte sequence");
                    throw th3;
                }
                bits.appendBits(((subtracted >> 8) * 192) + (subtracted & 255), 13);
            }
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException uee = e;
            Throwable th4 = th;
            new WriterException((Throwable) uee);
            throw th4;
        }
    }

    private static void appendECI(CharacterSetECI eci, BitArray bitArray) {
        BitArray bits = bitArray;
        bits.appendBits(Mode.ECI.getBits(), 4);
        bits.appendBits(eci.getValue(), 8);
    }
}
