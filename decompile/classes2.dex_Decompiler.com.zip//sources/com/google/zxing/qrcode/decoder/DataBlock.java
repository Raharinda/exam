package com.google.zxing.qrcode.decoder;

import com.google.zxing.qrcode.decoder.Version;

final class DataBlock {
    private final byte[] codewords;
    private final int numDataCodewords;

    private DataBlock(int numDataCodewords2, byte[] codewords2) {
        this.numDataCodewords = numDataCodewords2;
        this.codewords = codewords2;
    }

    static DataBlock[] getDataBlocks(byte[] bArr, Version version, ErrorCorrectionLevel errorCorrectionLevel) {
        DataBlock dataBlock;
        Throwable th;
        byte[] rawCodewords = bArr;
        Version version2 = version;
        ErrorCorrectionLevel ecLevel = errorCorrectionLevel;
        if (rawCodewords.length != version2.getTotalCodewords()) {
            Throwable th2 = th;
            new IllegalArgumentException();
            throw th2;
        }
        Version.ECBlocks ecBlocks = version2.getECBlocksForLevel(ecLevel);
        int totalBlocks = 0;
        Version.ECB[] ecBlockArray = ecBlocks.getECBlocks();
        Version.ECB[] arr$ = ecBlockArray;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            totalBlocks += arr$[i$].getCount();
        }
        DataBlock[] result = new DataBlock[totalBlocks];
        int numResultBlocks = 0;
        Version.ECB[] arr$2 = ecBlockArray;
        int len$2 = arr$2.length;
        for (int i$2 = 0; i$2 < len$2; i$2++) {
            Version.ECB ecBlock = arr$2[i$2];
            for (int i = 0; i < ecBlock.getCount(); i++) {
                int numDataCodewords2 = ecBlock.getDataCodewords();
                int i2 = numResultBlocks;
                numResultBlocks++;
                new DataBlock(numDataCodewords2, new byte[(ecBlocks.getECCodewordsPerBlock() + numDataCodewords2)]);
                result[i2] = dataBlock;
            }
        }
        int shorterBlocksTotalCodewords = result[0].codewords.length;
        int longerBlocksStartAt = result.length - 1;
        while (longerBlocksStartAt >= 0 && result[longerBlocksStartAt].codewords.length != shorterBlocksTotalCodewords) {
            longerBlocksStartAt--;
        }
        int longerBlocksStartAt2 = longerBlocksStartAt + 1;
        int shorterBlocksNumDataCodewords = shorterBlocksTotalCodewords - ecBlocks.getECCodewordsPerBlock();
        int rawCodewordsOffset = 0;
        for (int i3 = 0; i3 < shorterBlocksNumDataCodewords; i3++) {
            for (int j = 0; j < numResultBlocks; j++) {
                int i4 = rawCodewordsOffset;
                rawCodewordsOffset++;
                result[j].codewords[i3] = rawCodewords[i4];
            }
        }
        for (int j2 = longerBlocksStartAt2; j2 < numResultBlocks; j2++) {
            int i5 = rawCodewordsOffset;
            rawCodewordsOffset++;
            result[j2].codewords[shorterBlocksNumDataCodewords] = rawCodewords[i5];
        }
        int max = result[0].codewords.length;
        for (int i6 = shorterBlocksNumDataCodewords; i6 < max; i6++) {
            int j3 = 0;
            while (j3 < numResultBlocks) {
                int i7 = rawCodewordsOffset;
                rawCodewordsOffset++;
                result[j3].codewords[j3 < longerBlocksStartAt2 ? i6 : i6 + 1] = rawCodewords[i7];
                j3++;
            }
        }
        return result;
    }

    /* access modifiers changed from: package-private */
    public int getNumDataCodewords() {
        return this.numDataCodewords;
    }

    /* access modifiers changed from: package-private */
    public byte[] getCodewords() {
        return this.codewords;
    }
}
