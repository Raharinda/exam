package com.google.zxing.common;

public final class BitMatrix {
    private final int[] bits;
    private final int height;
    private final int rowSize;
    private final int width;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public BitMatrix(int r6) {
        /*
            r5 = this;
            r0 = r5
            r1 = r6
            r2 = r0
            r3 = r1
            r4 = r1
            r2.<init>(r3, r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.common.BitMatrix.<init>(int):void");
    }

    public BitMatrix(int i, int i2) {
        Throwable th;
        int width2 = i;
        int height2 = i2;
        if (width2 < 1 || height2 < 1) {
            Throwable th2 = th;
            new IllegalArgumentException("Both dimensions must be greater than 0");
            throw th2;
        }
        this.width = width2;
        this.height = height2;
        this.rowSize = (width2 + 31) >> 5;
        this.bits = new int[(this.rowSize * height2)];
    }

    public boolean get(int i, int y) {
        int x = i;
        return ((this.bits[(y * this.rowSize) + (x >> 5)] >>> (x & 31)) & 1) != 0;
    }

    public void set(int i, int y) {
        int x = i;
        int offset = (y * this.rowSize) + (x >> 5);
        int[] iArr = this.bits;
        int i2 = offset;
        iArr[i2] = iArr[i2] | (1 << (x & 31));
    }

    public void flip(int i, int y) {
        int x = i;
        int offset = (y * this.rowSize) + (x >> 5);
        int[] iArr = this.bits;
        int i2 = offset;
        iArr[i2] = iArr[i2] ^ (1 << (x & 31));
    }

    public void clear() {
        int max = this.bits.length;
        for (int i = 0; i < max; i++) {
            this.bits[i] = 0;
        }
    }

    public void setRegion(int i, int i2, int i3, int i4) {
        Throwable th;
        Throwable th2;
        Throwable th3;
        int left = i;
        int top = i2;
        int width2 = i3;
        int height2 = i4;
        if (top < 0 || left < 0) {
            Throwable th4 = th;
            new IllegalArgumentException("Left and top must be nonnegative");
            throw th4;
        } else if (height2 < 1 || width2 < 1) {
            Throwable th5 = th2;
            new IllegalArgumentException("Height and width must be at least 1");
            throw th5;
        } else {
            int right = left + width2;
            int bottom = top + height2;
            if (bottom > this.height || right > this.width) {
                Throwable th6 = th3;
                new IllegalArgumentException("The region must fit inside the matrix");
                throw th6;
            }
            for (int y = top; y < bottom; y++) {
                int offset = y * this.rowSize;
                for (int x = left; x < right; x++) {
                    int[] iArr = this.bits;
                    int i5 = offset + (x >> 5);
                    iArr[i5] = iArr[i5] | (1 << (x & 31));
                }
            }
        }
    }

    public BitArray getRow(int i, BitArray bitArray) {
        BitArray bitArray2;
        int y = i;
        BitArray row = bitArray;
        if (row == null || row.getSize() < this.width) {
            new BitArray(this.width);
            row = bitArray2;
        }
        int offset = y * this.rowSize;
        for (int x = 0; x < this.rowSize; x++) {
            row.setBulk(x << 5, this.bits[offset + x]);
        }
        return row;
    }

    public void setRow(int y, BitArray row) {
        System.arraycopy(row.getBitArray(), 0, this.bits, y * this.rowSize, this.rowSize);
    }

    public int[] getEnclosingRectangle() {
        int left = this.width;
        int top = this.height;
        int right = -1;
        int bottom = -1;
        for (int y = 0; y < this.height; y++) {
            for (int x32 = 0; x32 < this.rowSize; x32++) {
                int theBits = this.bits[(y * this.rowSize) + x32];
                if (theBits != 0) {
                    if (y < top) {
                        top = y;
                    }
                    if (y > bottom) {
                        bottom = y;
                    }
                    if (x32 * 32 < left) {
                        int bit = 0;
                        while ((theBits << (31 - bit)) == 0) {
                            bit++;
                        }
                        if ((x32 * 32) + bit < left) {
                            left = (x32 * 32) + bit;
                        }
                    }
                    if ((x32 * 32) + 31 > right) {
                        int bit2 = 31;
                        while ((theBits >>> bit2) == 0) {
                            bit2--;
                        }
                        if ((x32 * 32) + bit2 > right) {
                            right = (x32 * 32) + bit2;
                        }
                    }
                }
            }
        }
        int width2 = right - left;
        int height2 = bottom - top;
        if (width2 < 0 || height2 < 0) {
            return null;
        }
        int[] iArr = new int[4];
        iArr[0] = left;
        int[] iArr2 = iArr;
        iArr2[1] = top;
        int[] iArr3 = iArr2;
        iArr3[2] = width2;
        int[] iArr4 = iArr3;
        iArr4[3] = height2;
        return iArr4;
    }

    public int[] getTopLeftOnBit() {
        int bitsOffset = 0;
        while (bitsOffset < this.bits.length && this.bits[bitsOffset] == 0) {
            bitsOffset++;
        }
        if (bitsOffset == this.bits.length) {
            return null;
        }
        int y = bitsOffset / this.rowSize;
        int x = (bitsOffset % this.rowSize) << 5;
        int bit = 0;
        while ((this.bits[bitsOffset] << (31 - bit)) == 0) {
            bit++;
        }
        int[] iArr = new int[2];
        iArr[0] = x + bit;
        int[] iArr2 = iArr;
        iArr2[1] = y;
        return iArr2;
    }

    public int[] getBottomRightOnBit() {
        int bitsOffset = this.bits.length - 1;
        while (bitsOffset >= 0 && this.bits[bitsOffset] == 0) {
            bitsOffset--;
        }
        if (bitsOffset < 0) {
            return null;
        }
        int y = bitsOffset / this.rowSize;
        int x = (bitsOffset % this.rowSize) << 5;
        int bit = 31;
        while ((this.bits[bitsOffset] >>> bit) == 0) {
            bit--;
        }
        int[] iArr = new int[2];
        iArr[0] = x + bit;
        int[] iArr2 = iArr;
        iArr2[1] = y;
        return iArr2;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public boolean equals(Object obj) {
        Object o = obj;
        if (!(o instanceof BitMatrix)) {
            return false;
        }
        BitMatrix other = (BitMatrix) o;
        if (this.width != other.width || this.height != other.height || this.rowSize != other.rowSize || this.bits.length != other.bits.length) {
            return false;
        }
        for (int i = 0; i < this.bits.length; i++) {
            if (this.bits[i] != other.bits[i]) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        int hash = (31 * ((31 * ((31 * this.width) + this.width)) + this.height)) + this.rowSize;
        int[] arr$ = this.bits;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            hash = (31 * hash) + arr$[i$];
        }
        return hash;
    }

    public String toString() {
        StringBuilder sb;
        new StringBuilder(this.height * (this.width + 1));
        StringBuilder result = sb;
        for (int y = 0; y < this.height; y++) {
            for (int x = 0; x < this.width; x++) {
                StringBuilder append = result.append(get(x, y) ? "X " : "  ");
            }
            StringBuilder append2 = result.append(10);
        }
        return result.toString();
    }
}
