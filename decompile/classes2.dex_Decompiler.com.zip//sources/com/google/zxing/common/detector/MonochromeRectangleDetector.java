package com.google.zxing.common.detector;

import com.google.zxing.NotFoundException;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitMatrix;

public final class MonochromeRectangleDetector {
    private static final int MAX_MODULES = 32;
    private final BitMatrix image;

    public MonochromeRectangleDetector(BitMatrix image2) {
        this.image = image2;
    }

    public ResultPoint[] detect() throws NotFoundException {
        int height = this.image.getHeight();
        int width = this.image.getWidth();
        int halfHeight = height >> 1;
        int halfWidth = width >> 1;
        int deltaY = Math.max(1, height / 256);
        int deltaX = Math.max(1, width / 256);
        int bottom = height;
        int right = width;
        int top = ((int) findCornerFromCenter(halfWidth, 0, 0, right, halfHeight, -deltaY, 0, bottom, halfWidth >> 1).getY()) - 1;
        ResultPoint pointB = findCornerFromCenter(halfWidth, -deltaX, 0, right, halfHeight, 0, top, bottom, halfHeight >> 1);
        int left = ((int) pointB.getX()) - 1;
        ResultPoint pointC = findCornerFromCenter(halfWidth, deltaX, left, right, halfHeight, 0, top, bottom, halfHeight >> 1);
        int right2 = ((int) pointC.getX()) + 1;
        ResultPoint pointD = findCornerFromCenter(halfWidth, 0, left, right2, halfHeight, deltaY, top, bottom, halfWidth >> 1);
        ResultPoint[] resultPointArr = new ResultPoint[4];
        resultPointArr[0] = findCornerFromCenter(halfWidth, 0, left, right2, halfHeight, -deltaY, top, ((int) pointD.getY()) + 1, halfWidth >> 2);
        ResultPoint[] resultPointArr2 = resultPointArr;
        resultPointArr2[1] = pointB;
        ResultPoint[] resultPointArr3 = resultPointArr2;
        resultPointArr3[2] = pointC;
        ResultPoint[] resultPointArr4 = resultPointArr3;
        resultPointArr4[3] = pointD;
        return resultPointArr4;
    }

    private ResultPoint findCornerFromCenter(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) throws NotFoundException {
        int[] range;
        ResultPoint resultPoint;
        ResultPoint resultPoint2;
        ResultPoint resultPoint3;
        ResultPoint resultPoint4;
        float f;
        int centerX = i;
        int deltaX = i2;
        int left = i3;
        int right = i4;
        int centerY = i5;
        int deltaY = i6;
        int top = i7;
        int bottom = i8;
        int maxWhiteRun = i9;
        int[] lastRange = null;
        int y = centerY;
        int i10 = centerX;
        while (true) {
            int x = i10;
            if (y < bottom && y >= top && x < right && x >= left) {
                if (deltaX == 0) {
                    range = blackWhiteRange(y, maxWhiteRun, left, right, true);
                } else {
                    range = blackWhiteRange(x, maxWhiteRun, top, bottom, false);
                }
                if (range != null) {
                    lastRange = range;
                    y += deltaY;
                    i10 = x + deltaX;
                } else if (lastRange == null) {
                    throw NotFoundException.getNotFoundInstance();
                } else if (deltaX == 0) {
                    int lastY = y - deltaY;
                    if (lastRange[0] >= centerX) {
                        new ResultPoint((float) lastRange[1], (float) lastY);
                        return resultPoint3;
                    } else if (lastRange[1] > centerX) {
                        ResultPoint resultPoint5 = r23;
                        if (deltaY > 0) {
                            f = (float) lastRange[0];
                        } else {
                            f = (float) lastRange[1];
                        }
                        ResultPoint resultPoint6 = new ResultPoint(f, (float) lastY);
                        return resultPoint5;
                    } else {
                        new ResultPoint((float) lastRange[0], (float) lastY);
                        return resultPoint4;
                    }
                } else {
                    int lastX = x - deltaX;
                    if (lastRange[0] >= centerY) {
                        new ResultPoint((float) lastX, (float) lastRange[1]);
                        return resultPoint;
                    } else if (lastRange[1] > centerY) {
                        ResultPoint resultPoint7 = r23;
                        ResultPoint resultPoint8 = new ResultPoint((float) lastX, deltaX < 0 ? (float) lastRange[0] : (float) lastRange[1]);
                        return resultPoint7;
                    } else {
                        new ResultPoint((float) lastX, (float) lastRange[0]);
                        return resultPoint2;
                    }
                }
            }
        }
        throw NotFoundException.getNotFoundInstance();
    }

    private int[] blackWhiteRange(int i, int i2, int i3, int i4, boolean z) {
        int[] iArr;
        int whiteRunStart;
        int fixedDimension = i;
        int maxWhiteRun = i2;
        int minDim = i3;
        int maxDim = i4;
        boolean horizontal = z;
        int center = (minDim + maxDim) >> 1;
        int start = center;
        while (true) {
            if (start < minDim) {
                break;
            } else if (!horizontal ? this.image.get(fixedDimension, start) : this.image.get(start, fixedDimension)) {
                start--;
            } else {
                int whiteRunStart2 = start;
                while (true) {
                    start--;
                    if (start < minDim) {
                        break;
                    } else if (horizontal) {
                        if (this.image.get(start, fixedDimension)) {
                            break;
                        }
                    } else if (this.image.get(fixedDimension, start)) {
                        break;
                    }
                }
                int whiteRunSize = whiteRunStart2 - start;
                if (start < minDim || whiteRunSize > maxWhiteRun) {
                    start = whiteRunStart2;
                }
            }
        }
        int start2 = start + 1;
        int end = center;
        while (true) {
            if (end >= maxDim) {
                break;
            } else if (!horizontal ? this.image.get(fixedDimension, end) : this.image.get(end, fixedDimension)) {
                end++;
            } else {
                whiteRunStart = end;
                while (true) {
                    end++;
                    if (end >= maxDim) {
                        break;
                    } else if (horizontal) {
                        if (this.image.get(end, fixedDimension)) {
                            break;
                        }
                    } else if (this.image.get(fixedDimension, end)) {
                        break;
                    }
                }
                int whiteRunSize2 = end - whiteRunStart;
                if (end >= maxDim || whiteRunSize2 > maxWhiteRun) {
                    end = whiteRunStart;
                }
            }
        }
        end = whiteRunStart;
        int end2 = end - 1;
        if (end2 > start2) {
            int[] iArr2 = new int[2];
            iArr2[0] = start2;
            int[] iArr3 = iArr2;
            iArr = iArr3;
            iArr3[1] = end2;
        } else {
            iArr = null;
        }
        return iArr;
    }
}
