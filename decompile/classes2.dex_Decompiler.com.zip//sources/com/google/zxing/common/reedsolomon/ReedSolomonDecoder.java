package com.google.zxing.common.reedsolomon;

public final class ReedSolomonDecoder {
    private final GenericGF field;

    public ReedSolomonDecoder(GenericGF field2) {
        this.field = field2;
    }

    public void decode(int[] iArr, int i) throws ReedSolomonException {
        GenericGFPoly genericGFPoly;
        GenericGFPoly syndrome;
        Throwable th;
        int[] received = iArr;
        int twoS = i;
        new GenericGFPoly(this.field, received);
        GenericGFPoly poly = genericGFPoly;
        int[] syndromeCoefficients = new int[twoS];
        boolean dataMatrix = this.field.equals(GenericGF.DATA_MATRIX_FIELD_256);
        boolean noError = true;
        for (int i2 = 0; i2 < twoS; i2++) {
            int eval = poly.evaluateAt(this.field.exp(dataMatrix ? i2 + 1 : i2));
            syndromeCoefficients[(syndromeCoefficients.length - 1) - i2] = eval;
            if (eval != 0) {
                noError = false;
            }
        }
        if (!noError) {
            new GenericGFPoly(this.field, syndromeCoefficients);
            GenericGFPoly[] sigmaOmega = runEuclideanAlgorithm(this.field.buildMonomial(twoS, 1), syndrome, twoS);
            GenericGFPoly sigma = sigmaOmega[0];
            GenericGFPoly omega = sigmaOmega[1];
            int[] errorLocations = findErrorLocations(sigma);
            int[] errorMagnitudes = findErrorMagnitudes(omega, errorLocations, dataMatrix);
            for (int i3 = 0; i3 < errorLocations.length; i3++) {
                int position = (received.length - 1) - this.field.log(errorLocations[i3]);
                if (position < 0) {
                    Throwable th2 = th;
                    new ReedSolomonException("Bad error location");
                    throw th2;
                }
                received[position] = GenericGF.addOrSubtract(received[position], errorMagnitudes[i3]);
            }
        }
    }

    private GenericGFPoly[] runEuclideanAlgorithm(GenericGFPoly genericGFPoly, GenericGFPoly genericGFPoly2, int i) throws ReedSolomonException {
        Throwable th;
        Throwable th2;
        GenericGFPoly a = genericGFPoly;
        GenericGFPoly b = genericGFPoly2;
        int R = i;
        if (a.getDegree() < b.getDegree()) {
            GenericGFPoly temp = a;
            a = b;
            b = temp;
        }
        GenericGFPoly rLast = a;
        GenericGFPoly r = b;
        GenericGFPoly tLast = this.field.getZero();
        GenericGFPoly one = this.field.getOne();
        while (true) {
            GenericGFPoly t = one;
            if (r.getDegree() >= R / 2) {
                GenericGFPoly rLastLast = rLast;
                GenericGFPoly tLastLast = tLast;
                rLast = r;
                tLast = t;
                if (rLast.isZero()) {
                    Throwable th3 = th2;
                    new ReedSolomonException("r_{i-1} was zero");
                    throw th3;
                }
                r = rLastLast;
                GenericGFPoly q = this.field.getZero();
                int dltInverse = this.field.inverse(rLast.getCoefficient(rLast.getDegree()));
                while (r.getDegree() >= rLast.getDegree() && !r.isZero()) {
                    int degreeDiff = r.getDegree() - rLast.getDegree();
                    int scale = this.field.multiply(r.getCoefficient(r.getDegree()), dltInverse);
                    q = q.addOrSubtract(this.field.buildMonomial(degreeDiff, scale));
                    r = r.addOrSubtract(rLast.multiplyByMonomial(degreeDiff, scale));
                }
                one = q.multiply(tLast).addOrSubtract(tLastLast);
            } else {
                int sigmaTildeAtZero = t.getCoefficient(0);
                if (sigmaTildeAtZero == 0) {
                    Throwable th4 = th;
                    new ReedSolomonException("sigmaTilde(0) was zero");
                    throw th4;
                }
                int inverse = this.field.inverse(sigmaTildeAtZero);
                GenericGFPoly sigma = t.multiply(inverse);
                GenericGFPoly omega = r.multiply(inverse);
                GenericGFPoly[] genericGFPolyArr = new GenericGFPoly[2];
                genericGFPolyArr[0] = sigma;
                GenericGFPoly[] genericGFPolyArr2 = genericGFPolyArr;
                genericGFPolyArr2[1] = omega;
                return genericGFPolyArr2;
            }
        }
    }

    private int[] findErrorLocations(GenericGFPoly genericGFPoly) throws ReedSolomonException {
        Throwable th;
        GenericGFPoly errorLocator = genericGFPoly;
        int numErrors = errorLocator.getDegree();
        if (numErrors == 1) {
            return new int[]{errorLocator.getCoefficient(1)};
        }
        int[] result = new int[numErrors];
        int e = 0;
        for (int i = 1; i < this.field.getSize() && e < numErrors; i++) {
            if (errorLocator.evaluateAt(i) == 0) {
                result[e] = this.field.inverse(i);
                e++;
            }
        }
        if (e == numErrors) {
            return result;
        }
        Throwable th2 = th;
        new ReedSolomonException("Error locator degree does not match number of roots");
        throw th2;
    }

    private int[] findErrorMagnitudes(GenericGFPoly genericGFPoly, int[] iArr, boolean z) {
        GenericGFPoly errorEvaluator = genericGFPoly;
        int[] errorLocations = iArr;
        boolean dataMatrix = z;
        int s = errorLocations.length;
        int[] result = new int[s];
        for (int i = 0; i < s; i++) {
            int xiInverse = this.field.inverse(errorLocations[i]);
            int denominator = 1;
            for (int j = 0; j < s; j++) {
                if (i != j) {
                    int term = this.field.multiply(errorLocations[j], xiInverse);
                    denominator = this.field.multiply(denominator, (term & 1) == 0 ? term | 1 : term & -2);
                }
            }
            result[i] = this.field.multiply(errorEvaluator.evaluateAt(xiInverse), this.field.inverse(denominator));
            if (dataMatrix) {
                result[i] = this.field.multiply(result[i], xiInverse);
            }
        }
        return result;
    }
}
