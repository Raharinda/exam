package com.google.zxing.common.detector;

import com.google.zxing.NotFoundException;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitMatrix;

public final class WhiteRectangleDetector {
    private static final int CORR = 1;
    private static final int INIT_SIZE = 30;
    private final int downInit;
    private final int height;
    private final BitMatrix image;
    private final int leftInit;
    private final int rightInit;
    private final int upInit;
    private final int width;

    public WhiteRectangleDetector(BitMatrix bitMatrix) throws NotFoundException {
        BitMatrix image2 = bitMatrix;
        this.image = image2;
        this.height = image2.getHeight();
        this.width = image2.getWidth();
        this.leftInit = (this.width - 30) >> 1;
        this.rightInit = (this.width + 30) >> 1;
        this.upInit = (this.height - 30) >> 1;
        this.downInit = (this.height + 30) >> 1;
        if (this.upInit < 0 || this.leftInit < 0 || this.downInit >= this.height || this.rightInit >= this.width) {
            throw NotFoundException.getNotFoundInstance();
        }
    }

    public WhiteRectangleDetector(BitMatrix bitMatrix, int initSize, int i, int i2) throws NotFoundException {
        BitMatrix image2 = bitMatrix;
        int x = i;
        int y = i2;
        this.image = image2;
        this.height = image2.getHeight();
        this.width = image2.getWidth();
        int halfsize = initSize >> 1;
        this.leftInit = x - halfsize;
        this.rightInit = x + halfsize;
        this.upInit = y - halfsize;
        this.downInit = y + halfsize;
        if (this.upInit < 0 || this.leftInit < 0 || this.downInit >= this.height || this.rightInit >= this.width) {
            throw NotFoundException.getNotFoundInstance();
        }
    }

    public ResultPoint[] detect() throws NotFoundException {
        int left = this.leftInit;
        int right = this.rightInit;
        int up = this.upInit;
        int down = this.downInit;
        boolean sizeExceeded = false;
        boolean aBlackPointFoundOnBorder = true;
        boolean atLeastOneBlackPointFoundOnBorder = false;
        while (true) {
            if (!aBlackPointFoundOnBorder) {
                break;
            }
            aBlackPointFoundOnBorder = false;
            boolean rightBorderNotWhite = true;
            while (rightBorderNotWhite) {
                if (right >= this.width) {
                    break;
                }
                rightBorderNotWhite = containsBlackPoint(up, down, right, false);
                if (rightBorderNotWhite) {
                    right++;
                    aBlackPointFoundOnBorder = true;
                }
            }
            if (right >= this.width) {
                sizeExceeded = true;
                break;
            }
            boolean bottomBorderNotWhite = true;
            while (bottomBorderNotWhite) {
                if (down >= this.height) {
                    break;
                }
                bottomBorderNotWhite = containsBlackPoint(left, right, down, true);
                if (bottomBorderNotWhite) {
                    down++;
                    aBlackPointFoundOnBorder = true;
                }
            }
            if (down >= this.height) {
                sizeExceeded = true;
                break;
            }
            boolean leftBorderNotWhite = true;
            while (leftBorderNotWhite && left >= 0) {
                leftBorderNotWhite = containsBlackPoint(up, down, left, false);
                if (leftBorderNotWhite) {
                    left--;
                    aBlackPointFoundOnBorder = true;
                }
            }
            if (left < 0) {
                sizeExceeded = true;
                break;
            }
            boolean topBorderNotWhite = true;
            while (topBorderNotWhite && up >= 0) {
                topBorderNotWhite = containsBlackPoint(left, right, up, true);
                if (topBorderNotWhite) {
                    up--;
                    aBlackPointFoundOnBorder = true;
                }
            }
            if (up < 0) {
                sizeExceeded = true;
                break;
            } else if (aBlackPointFoundOnBorder) {
                atLeastOneBlackPointFoundOnBorder = true;
            }
        }
        if (sizeExceeded || !atLeastOneBlackPointFoundOnBorder) {
            throw NotFoundException.getNotFoundInstance();
        }
        int maxSize = right - left;
        ResultPoint z = null;
        for (int i = 1; i < maxSize; i++) {
            z = getBlackPointOnSegment((float) left, (float) (down - i), (float) (left + i), (float) down);
            if (z != null) {
                break;
            }
        }
        if (z == null) {
            throw NotFoundException.getNotFoundInstance();
        }
        ResultPoint t = null;
        for (int i2 = 1; i2 < maxSize; i2++) {
            t = getBlackPointOnSegment((float) left, (float) (up + i2), (float) (left + i2), (float) up);
            if (t != null) {
                break;
            }
        }
        if (t == null) {
            throw NotFoundException.getNotFoundInstance();
        }
        ResultPoint x = null;
        for (int i3 = 1; i3 < maxSize; i3++) {
            x = getBlackPointOnSegment((float) right, (float) (up + i3), (float) (right - i3), (float) up);
            if (x != null) {
                break;
            }
        }
        if (x == null) {
            throw NotFoundException.getNotFoundInstance();
        }
        ResultPoint y = null;
        for (int i4 = 1; i4 < maxSize; i4++) {
            y = getBlackPointOnSegment((float) right, (float) (down - i4), (float) (right - i4), (float) down);
            if (y != null) {
                break;
            }
        }
        if (y != null) {
            return centerEdges(y, z, x, t);
        }
        throw NotFoundException.getNotFoundInstance();
    }

    private ResultPoint getBlackPointOnSegment(float f, float f2, float f3, float f4) {
        ResultPoint resultPoint;
        float aX = f;
        float aY = f2;
        float bX = f3;
        float bY = f4;
        int dist = MathUtils.round(MathUtils.distance(aX, aY, bX, bY));
        float xStep = (bX - aX) / ((float) dist);
        float yStep = (bY - aY) / ((float) dist);
        for (int i = 0; i < dist; i++) {
            int x = MathUtils.round(aX + (((float) i) * xStep));
            int y = MathUtils.round(aY + (((float) i) * yStep));
            if (this.image.get(x, y)) {
                new ResultPoint((float) x, (float) y);
                return resultPoint;
            }
        }
        return null;
    }

    private ResultPoint[] centerEdges(ResultPoint resultPoint, ResultPoint resultPoint2, ResultPoint resultPoint3, ResultPoint resultPoint4) {
        ResultPoint resultPoint5;
        ResultPoint resultPoint6;
        ResultPoint resultPoint7;
        ResultPoint resultPoint8;
        ResultPoint resultPoint9;
        ResultPoint resultPoint10;
        ResultPoint resultPoint11;
        ResultPoint resultPoint12;
        ResultPoint y = resultPoint;
        ResultPoint z = resultPoint2;
        ResultPoint x = resultPoint3;
        ResultPoint t = resultPoint4;
        float yi = y.getX();
        float yj = y.getY();
        float zi = z.getX();
        float zj = z.getY();
        float xi = x.getX();
        float xj = x.getY();
        float ti = t.getX();
        float tj = t.getY();
        if (yi < ((float) (this.width / 2))) {
            ResultPoint[] resultPointArr = new ResultPoint[4];
            new ResultPoint(ti - 1.0f, tj + 1.0f);
            resultPointArr[0] = resultPoint9;
            ResultPoint[] resultPointArr2 = resultPointArr;
            new ResultPoint(zi + 1.0f, zj + 1.0f);
            resultPointArr2[1] = resultPoint10;
            ResultPoint[] resultPointArr3 = resultPointArr2;
            new ResultPoint(xi - 1.0f, xj - 1.0f);
            resultPointArr3[2] = resultPoint11;
            ResultPoint[] resultPointArr4 = resultPointArr3;
            new ResultPoint(yi + 1.0f, yj - 1.0f);
            resultPointArr4[3] = resultPoint12;
            return resultPointArr4;
        }
        ResultPoint[] resultPointArr5 = new ResultPoint[4];
        new ResultPoint(ti + 1.0f, tj + 1.0f);
        resultPointArr5[0] = resultPoint5;
        ResultPoint[] resultPointArr6 = resultPointArr5;
        new ResultPoint(zi + 1.0f, zj - 1.0f);
        resultPointArr6[1] = resultPoint6;
        ResultPoint[] resultPointArr7 = resultPointArr6;
        new ResultPoint(xi - 1.0f, xj + 1.0f);
        resultPointArr7[2] = resultPoint7;
        ResultPoint[] resultPointArr8 = resultPointArr7;
        new ResultPoint(yi - 1.0f, yj - 1.0f);
        resultPointArr8[3] = resultPoint8;
        return resultPointArr8;
    }

    private boolean containsBlackPoint(int i, int i2, int i3, boolean horizontal) {
        int a = i;
        int b = i2;
        int fixed = i3;
        if (horizontal) {
            for (int x = a; x <= b; x++) {
                if (this.image.get(x, fixed)) {
                    return true;
                }
            }
        } else {
            for (int y = a; y <= b; y++) {
                if (this.image.get(fixed, y)) {
                    return true;
                }
            }
        }
        return false;
    }
}
