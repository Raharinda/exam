package com.google.zxing.common;

import com.google.zxing.Binarizer;
import com.google.zxing.LuminanceSource;
import com.google.zxing.NotFoundException;

public class GlobalHistogramBinarizer extends Binarizer {
    private static final byte[] EMPTY = new byte[0];
    private static final int LUMINANCE_BITS = 5;
    private static final int LUMINANCE_BUCKETS = 32;
    private static final int LUMINANCE_SHIFT = 3;
    private final int[] buckets = new int[LUMINANCE_BUCKETS];
    private byte[] luminances = EMPTY;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public GlobalHistogramBinarizer(LuminanceSource source) {
        super(source);
    }

    public BitArray getBlackRow(int i, BitArray bitArray) throws NotFoundException {
        BitArray bitArray2;
        int y = i;
        BitArray row = bitArray;
        LuminanceSource source = getLuminanceSource();
        int width = source.getWidth();
        if (row == null || row.getSize() < width) {
            new BitArray(width);
            row = bitArray2;
        } else {
            row.clear();
        }
        initArrays(width);
        byte[] localLuminances = source.getRow(y, this.luminances);
        int[] localBuckets = this.buckets;
        for (int x = 0; x < width; x++) {
            int[] iArr = localBuckets;
            int i2 = (localLuminances[x] & 255) >> 3;
            iArr[i2] = iArr[i2] + 1;
        }
        int x2 = estimateBlackPoint(localBuckets);
        int left = localLuminances[0] & 255;
        int center = localLuminances[1] & 255;
        for (int x3 = 1; x3 < width - 1; x3++) {
            int right = localLuminances[x3 + 1] & 255;
            if (((((center << 2) - left) - right) >> 1) < x2) {
                row.set(x3);
            }
            left = center;
            center = right;
        }
        return row;
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.google.zxing.common.BitMatrix getBlackMatrix() throws com.google.zxing.NotFoundException {
        /*
            r18 = this;
            r0 = r18
            r12 = r0
            com.google.zxing.LuminanceSource r12 = r12.getLuminanceSource()
            r1 = r12
            r12 = r1
            int r12 = r12.getWidth()
            r2 = r12
            r12 = r1
            int r12 = r12.getHeight()
            r3 = r12
            com.google.zxing.common.BitMatrix r12 = new com.google.zxing.common.BitMatrix
            r16 = r12
            r12 = r16
            r13 = r16
            r14 = r2
            r15 = r3
            r13.<init>(r14, r15)
            r4 = r12
            r12 = r0
            r13 = r2
            r12.initArrays(r13)
            r12 = r0
            int[] r12 = r12.buckets
            r5 = r12
            r12 = 1
            r6 = r12
        L_0x002d:
            r12 = r6
            r13 = 5
            if (r12 >= r13) goto L_0x007a
            r12 = r3
            r13 = r6
            int r12 = r12 * r13
            r13 = 5
            int r12 = r12 / 5
            r7 = r12
            r12 = r1
            r13 = r7
            r14 = r0
            byte[] r14 = r14.luminances
            byte[] r12 = r12.getRow(r13, r14)
            r8 = r12
            r12 = r2
            r13 = 2
            int r12 = r12 << 2
            r13 = 5
            int r12 = r12 / 5
            r9 = r12
            r12 = r2
            r13 = 5
            int r12 = r12 / 5
            r10 = r12
        L_0x004f:
            r12 = r10
            r13 = r9
            if (r12 >= r13) goto L_0x0077
            r12 = r8
            r13 = r10
            byte r12 = r12[r13]
            r13 = 255(0xff, float:3.57E-43)
            r12 = r12 & 255(0xff, float:3.57E-43)
            r11 = r12
            r12 = r5
            r13 = r11
            r14 = 3
            int r13 = r13 >> 3
            r16 = r12
            r17 = r13
            r12 = r16
            r13 = r17
            r14 = r16
            r15 = r17
            r14 = r14[r15]
            r15 = 1
            int r14 = r14 + 1
            r12[r13] = r14
            int r10 = r10 + 1
            goto L_0x004f
        L_0x0077:
            int r6 = r6 + 1
            goto L_0x002d
        L_0x007a:
            r12 = r5
            int r12 = estimateBlackPoint(r12)
            r6 = r12
            r12 = r1
            byte[] r12 = r12.getMatrix()
            r7 = r12
            r12 = 0
            r8 = r12
        L_0x0088:
            r12 = r8
            r13 = r3
            if (r12 >= r13) goto L_0x00b1
            r12 = r8
            r13 = r2
            int r12 = r12 * r13
            r9 = r12
            r12 = 0
            r10 = r12
        L_0x0092:
            r12 = r10
            r13 = r2
            if (r12 >= r13) goto L_0x00ae
            r12 = r7
            r13 = r9
            r14 = r10
            int r13 = r13 + r14
            byte r12 = r12[r13]
            r13 = 255(0xff, float:3.57E-43)
            r12 = r12 & 255(0xff, float:3.57E-43)
            r11 = r12
            r12 = r11
            r13 = r6
            if (r12 >= r13) goto L_0x00ab
            r12 = r4
            r13 = r10
            r14 = r8
            r12.set(r13, r14)
        L_0x00ab:
            int r10 = r10 + 1
            goto L_0x0092
        L_0x00ae:
            int r8 = r8 + 1
            goto L_0x0088
        L_0x00b1:
            r12 = r4
            r0 = r12
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.common.GlobalHistogramBinarizer.getBlackMatrix():com.google.zxing.common.BitMatrix");
    }

    public Binarizer createBinarizer(LuminanceSource source) {
        GlobalHistogramBinarizer globalHistogramBinarizer;
        new GlobalHistogramBinarizer(source);
        return globalHistogramBinarizer;
    }

    private void initArrays(int i) {
        int luminanceSize = i;
        if (this.luminances.length < luminanceSize) {
            this.luminances = new byte[luminanceSize];
        }
        for (int x = 0; x < LUMINANCE_BUCKETS; x++) {
            this.buckets[x] = 0;
        }
    }

    private static int estimateBlackPoint(int[] iArr) throws NotFoundException {
        int[] buckets2 = iArr;
        int numBuckets = buckets2.length;
        int maxBucketCount = 0;
        int firstPeak = 0;
        int firstPeakSize = 0;
        for (int x = 0; x < numBuckets; x++) {
            if (buckets2[x] > firstPeakSize) {
                firstPeak = x;
                firstPeakSize = buckets2[x];
            }
            if (buckets2[x] > maxBucketCount) {
                maxBucketCount = buckets2[x];
            }
        }
        int secondPeak = 0;
        int secondPeakScore = 0;
        for (int x2 = 0; x2 < numBuckets; x2++) {
            int distanceToBiggest = x2 - firstPeak;
            int score = buckets2[x2] * distanceToBiggest * distanceToBiggest;
            if (score > secondPeakScore) {
                secondPeak = x2;
                secondPeakScore = score;
            }
        }
        if (firstPeak > secondPeak) {
            int x3 = firstPeak;
            firstPeak = secondPeak;
            secondPeak = x3;
        }
        if (secondPeak - firstPeak <= (numBuckets >> 4)) {
            throw NotFoundException.getNotFoundInstance();
        }
        int bestValley = secondPeak - 1;
        int bestValleyScore = -1;
        for (int x4 = secondPeak - 1; x4 > firstPeak; x4--) {
            int fromFirst = x4 - firstPeak;
            int score2 = fromFirst * fromFirst * (secondPeak - x4) * (maxBucketCount - buckets2[x4]);
            if (score2 > bestValleyScore) {
                bestValley = x4;
                bestValleyScore = score2;
            }
        }
        return bestValley << 3;
    }
}
