package com.google.zxing.common;

public final class BitSource {
    private int bitOffset;
    private int byteOffset;
    private final byte[] bytes;

    public BitSource(byte[] bytes2) {
        this.bytes = bytes2;
    }

    public int getBitOffset() {
        return this.bitOffset;
    }

    public int getByteOffset() {
        return this.byteOffset;
    }

    public int readBits(int i) {
        Throwable th;
        int numBits = i;
        if (numBits < 1 || numBits > 32 || numBits > available()) {
            Throwable th2 = th;
            new IllegalArgumentException(String.valueOf(numBits));
            throw th2;
        }
        int result = 0;
        if (this.bitOffset > 0) {
            int bitsLeft = 8 - this.bitOffset;
            int toRead = numBits < bitsLeft ? numBits : bitsLeft;
            int bitsToNotRead = bitsLeft - toRead;
            result = (this.bytes[this.byteOffset] & ((255 >> (8 - toRead)) << bitsToNotRead)) >> bitsToNotRead;
            numBits -= toRead;
            this.bitOffset += toRead;
            if (this.bitOffset == 8) {
                this.bitOffset = 0;
                this.byteOffset++;
            }
        }
        if (numBits > 0) {
            while (numBits >= 8) {
                result = (result << 8) | (this.bytes[this.byteOffset] & 255);
                this.byteOffset++;
                numBits -= 8;
            }
            if (numBits > 0) {
                int bitsToNotRead2 = 8 - numBits;
                result = (result << numBits) | ((this.bytes[this.byteOffset] & ((255 >> bitsToNotRead2) << bitsToNotRead2)) >> bitsToNotRead2);
                this.bitOffset += numBits;
            }
        }
        return result;
    }

    public int available() {
        return (8 * (this.bytes.length - this.byteOffset)) - this.bitOffset;
    }
}
