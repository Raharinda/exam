package com.google.zxing.common.reedsolomon;

public final class GenericGF {
    public static final GenericGF AZTEC_DATA_10;
    public static final GenericGF AZTEC_DATA_12;
    public static final GenericGF AZTEC_DATA_6;
    public static final GenericGF AZTEC_DATA_8 = DATA_MATRIX_FIELD_256;
    public static final GenericGF AZTEC_PARAM;
    public static final GenericGF DATA_MATRIX_FIELD_256;
    private static final int INITIALIZATION_THRESHOLD = 0;
    public static final GenericGF MAXICODE_FIELD_64 = AZTEC_DATA_6;
    public static final GenericGF QR_CODE_FIELD_256;
    private int[] expTable;
    private boolean initialized = false;
    private int[] logTable;
    private GenericGFPoly one;
    private final int primitive;
    private final int size;
    private GenericGFPoly zero;

    static {
        GenericGF genericGF;
        GenericGF genericGF2;
        GenericGF genericGF3;
        GenericGF genericGF4;
        GenericGF genericGF5;
        GenericGF genericGF6;
        new GenericGF(4201, 4096);
        AZTEC_DATA_12 = genericGF;
        new GenericGF(1033, 1024);
        AZTEC_DATA_10 = genericGF2;
        new GenericGF(67, 64);
        AZTEC_DATA_6 = genericGF3;
        new GenericGF(19, 16);
        AZTEC_PARAM = genericGF4;
        new GenericGF(285, 256);
        QR_CODE_FIELD_256 = genericGF5;
        new GenericGF(301, 256);
        DATA_MATRIX_FIELD_256 = genericGF6;
    }

    public GenericGF(int primitive2, int i) {
        int size2 = i;
        this.primitive = primitive2;
        this.size = size2;
        if (size2 <= 0) {
            initialize();
        }
    }

    private void initialize() {
        GenericGFPoly genericGFPoly;
        GenericGFPoly genericGFPoly2;
        this.expTable = new int[this.size];
        this.logTable = new int[this.size];
        int x = 1;
        for (int i = 0; i < this.size; i++) {
            this.expTable[i] = x;
            x <<= 1;
            if (x >= this.size) {
                x = (x ^ this.primitive) & (this.size - 1);
            }
        }
        for (int i2 = 0; i2 < this.size - 1; i2++) {
            this.logTable[this.expTable[i2]] = i2;
        }
        new GenericGFPoly(this, new int[]{0});
        this.zero = genericGFPoly;
        new GenericGFPoly(this, new int[]{1});
        this.one = genericGFPoly2;
        this.initialized = true;
    }

    private void checkInit() {
        if (!this.initialized) {
            initialize();
        }
    }

    /* access modifiers changed from: package-private */
    public GenericGFPoly getZero() {
        checkInit();
        return this.zero;
    }

    /* access modifiers changed from: package-private */
    public GenericGFPoly getOne() {
        checkInit();
        return this.one;
    }

    /* access modifiers changed from: package-private */
    public GenericGFPoly buildMonomial(int i, int i2) {
        GenericGFPoly genericGFPoly;
        Throwable th;
        int degree = i;
        int coefficient = i2;
        checkInit();
        if (degree < 0) {
            Throwable th2 = th;
            new IllegalArgumentException();
            throw th2;
        } else if (coefficient == 0) {
            return this.zero;
        } else {
            int[] coefficients = new int[(degree + 1)];
            coefficients[0] = coefficient;
            new GenericGFPoly(this, coefficients);
            return genericGFPoly;
        }
    }

    static int addOrSubtract(int a, int b) {
        return a ^ b;
    }

    /* access modifiers changed from: package-private */
    public int exp(int a) {
        checkInit();
        return this.expTable[a];
    }

    /* access modifiers changed from: package-private */
    public int log(int i) {
        Throwable th;
        int a = i;
        checkInit();
        if (a != 0) {
            return this.logTable[a];
        }
        Throwable th2 = th;
        new IllegalArgumentException();
        throw th2;
    }

    /* access modifiers changed from: package-private */
    public int inverse(int i) {
        Throwable th;
        int a = i;
        checkInit();
        if (a != 0) {
            return this.expTable[(this.size - this.logTable[a]) - 1];
        }
        Throwable th2 = th;
        new ArithmeticException();
        throw th2;
    }

    /* access modifiers changed from: package-private */
    public int multiply(int i, int i2) {
        int a = i;
        int b = i2;
        checkInit();
        if (a == 0 || b == 0) {
            return 0;
        }
        return this.expTable[(this.logTable[a] + this.logTable[b]) % (this.size - 1)];
    }

    public int getSize() {
        return this.size;
    }
}
