package com.google.zxing.common;

import com.google.zxing.Binarizer;
import com.google.zxing.LuminanceSource;
import com.google.zxing.NotFoundException;

public final class HybridBinarizer extends GlobalHistogramBinarizer {
    private static final int BLOCK_SIZE = 8;
    private static final int BLOCK_SIZE_MASK = 7;
    private static final int BLOCK_SIZE_POWER = 3;
    private static final int MINIMUM_DIMENSION = 40;
    private static final int MIN_DYNAMIC_RANGE = 24;
    private BitMatrix matrix;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HybridBinarizer(LuminanceSource source) {
        super(source);
    }

    public BitMatrix getBlackMatrix() throws NotFoundException {
        BitMatrix bitMatrix;
        if (this.matrix != null) {
            return this.matrix;
        }
        LuminanceSource source = getLuminanceSource();
        int width = source.getWidth();
        int height = source.getHeight();
        if (width < 40 || height < 40) {
            this.matrix = super.getBlackMatrix();
        } else {
            byte[] luminances = source.getMatrix();
            int subWidth = width >> 3;
            if ((width & 7) != 0) {
                subWidth++;
            }
            int subHeight = height >> 3;
            if ((height & 7) != 0) {
                subHeight++;
            }
            int[][] blackPoints = calculateBlackPoints(luminances, subWidth, subHeight, width, height);
            new BitMatrix(width, height);
            BitMatrix newMatrix = bitMatrix;
            calculateThresholdForBlock(luminances, subWidth, subHeight, width, height, blackPoints, newMatrix);
            this.matrix = newMatrix;
        }
        return this.matrix;
    }

    public Binarizer createBinarizer(LuminanceSource source) {
        HybridBinarizer hybridBinarizer;
        new HybridBinarizer(source);
        return hybridBinarizer;
    }

    private static void calculateThresholdForBlock(byte[] bArr, int i, int i2, int i3, int i4, int[][] iArr, BitMatrix bitMatrix) {
        byte[] luminances = bArr;
        int subWidth = i;
        int subHeight = i2;
        int width = i3;
        int height = i4;
        int[][] blackPoints = iArr;
        BitMatrix matrix2 = bitMatrix;
        for (int y = 0; y < subHeight; y++) {
            int yoffset = y << 3;
            int maxYOffset = height - 8;
            if (yoffset > maxYOffset) {
                yoffset = maxYOffset;
            }
            for (int x = 0; x < subWidth; x++) {
                int xoffset = x << 3;
                int maxXOffset = width - 8;
                if (xoffset > maxXOffset) {
                    xoffset = maxXOffset;
                }
                int left = cap(x, 2, subWidth - 3);
                int top = cap(y, 2, subHeight - 3);
                int sum = 0;
                for (int z = -2; z <= 2; z++) {
                    int[] blackRow = blackPoints[top + z];
                    sum += blackRow[left - 2] + blackRow[left - 1] + blackRow[left] + blackRow[left + 1] + blackRow[left + 2];
                }
                thresholdBlock(luminances, xoffset, yoffset, sum / 25, width, matrix2);
            }
        }
    }

    private static int cap(int i, int i2, int i3) {
        int value = i;
        int min = i2;
        int max = i3;
        return value < min ? min : value > max ? max : value;
    }

    private static void thresholdBlock(byte[] bArr, int i, int i2, int i3, int i4, BitMatrix bitMatrix) {
        byte[] luminances = bArr;
        int xoffset = i;
        int yoffset = i2;
        int threshold = i3;
        int stride = i4;
        BitMatrix matrix2 = bitMatrix;
        int y = 0;
        int i5 = yoffset * stride;
        int i6 = xoffset;
        while (true) {
            int offset = i5 + i6;
            if (y < 8) {
                for (int x = 0; x < 8; x++) {
                    if ((luminances[offset + x] & 255) <= threshold) {
                        matrix2.set(xoffset + x, yoffset + y);
                    }
                }
                y++;
                i5 = offset;
                i6 = stride;
            } else {
                return;
            }
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v0, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v1, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r17v2, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r17v3, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r17v4, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v1, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r22v29, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v6, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r21v45, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r17v5, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v2, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v3, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v4, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v5, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r21v56, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v6, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v7, resolved type: byte} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static int[][] calculateBlackPoints(byte[] r26, int r27, int r28, int r29, int r30) {
        /*
            r2 = r26
            r3 = r27
            r4 = r28
            r5 = r29
            r6 = r30
            r21 = r4
            r22 = r3
            int[] r22 = new int[]{r21, r22}
            java.lang.Class r21 = java.lang.Integer.TYPE
            java.lang.Object r21 = java.lang.reflect.Array.newInstance(r21, r22)
            int[][] r21 = (int[][]) r21
            r7 = r21
            r21 = 0
            r8 = r21
        L_0x0020:
            r21 = r8
            r22 = r4
            r0 = r21
            r1 = r22
            if (r0 >= r1) goto L_0x01c9
            r21 = r8
            r22 = 3
            int r21 = r21 << 3
            r9 = r21
            r21 = r6
            r22 = 8
            int r21 = r21 + -8
            r10 = r21
            r21 = r9
            r22 = r10
            r0 = r21
            r1 = r22
            if (r0 <= r1) goto L_0x0048
            r21 = r10
            r9 = r21
        L_0x0048:
            r21 = 0
            r11 = r21
        L_0x004c:
            r21 = r11
            r22 = r3
            r0 = r21
            r1 = r22
            if (r0 >= r1) goto L_0x01c5
            r21 = r11
            r22 = 3
            int r21 = r21 << 3
            r12 = r21
            r21 = r5
            r22 = 8
            int r21 = r21 + -8
            r13 = r21
            r21 = r12
            r22 = r13
            r0 = r21
            r1 = r22
            if (r0 <= r1) goto L_0x0074
            r21 = r13
            r12 = r21
        L_0x0074:
            r21 = 0
            r14 = r21
            r21 = 255(0xff, float:3.57E-43)
            r15 = r21
            r21 = 0
            r16 = r21
            r21 = 0
            r17 = r21
            r21 = r9
            r22 = r5
            int r21 = r21 * r22
            r22 = r12
            int r21 = r21 + r22
            r18 = r21
        L_0x0090:
            r21 = r17
            r22 = 8
            r0 = r21
            r1 = r22
            if (r0 >= r1) goto L_0x0145
            r21 = 0
            r19 = r21
        L_0x009e:
            r21 = r19
            r22 = 8
            r0 = r21
            r1 = r22
            if (r0 >= r1) goto L_0x00e3
            r21 = r2
            r22 = r18
            r23 = r19
            int r22 = r22 + r23
            byte r21 = r21[r22]
            r22 = 255(0xff, float:3.57E-43)
            r0 = r21
            r0 = r0 & 255(0xff, float:3.57E-43)
            r21 = r0
            r20 = r21
            r21 = r14
            r22 = r20
            int r21 = r21 + r22
            r14 = r21
            r21 = r20
            r22 = r15
            r0 = r21
            r1 = r22
            if (r0 >= r1) goto L_0x00d2
            r21 = r20
            r15 = r21
        L_0x00d2:
            r21 = r20
            r22 = r16
            r0 = r21
            r1 = r22
            if (r0 <= r1) goto L_0x00e0
            r21 = r20
            r16 = r21
        L_0x00e0:
            int r19 = r19 + 1
            goto L_0x009e
        L_0x00e3:
            r21 = r16
            r22 = r15
            int r21 = r21 - r22
            r22 = 24
            r0 = r21
            r1 = r22
            if (r0 <= r1) goto L_0x0139
            int r17 = r17 + 1
            r21 = r18
            r22 = r5
            int r21 = r21 + r22
            r18 = r21
        L_0x00fb:
            r21 = r17
            r22 = 8
            r0 = r21
            r1 = r22
            if (r0 >= r1) goto L_0x0139
            r21 = 0
            r19 = r21
        L_0x0109:
            r21 = r19
            r22 = 8
            r0 = r21
            r1 = r22
            if (r0 >= r1) goto L_0x012e
            r21 = r14
            r22 = r2
            r23 = r18
            r24 = r19
            int r23 = r23 + r24
            byte r22 = r22[r23]
            r23 = 255(0xff, float:3.57E-43)
            r0 = r22
            r0 = r0 & 255(0xff, float:3.57E-43)
            r22 = r0
            int r21 = r21 + r22
            r14 = r21
            int r19 = r19 + 1
            goto L_0x0109
        L_0x012e:
            int r17 = r17 + 1
            r21 = r18
            r22 = r5
            int r21 = r21 + r22
            r18 = r21
            goto L_0x00fb
        L_0x0139:
            int r17 = r17 + 1
            r21 = r18
            r22 = r5
            int r21 = r21 + r22
            r18 = r21
            goto L_0x0090
        L_0x0145:
            r21 = r14
            r22 = 6
            int r21 = r21 >> 6
            r17 = r21
            r21 = r16
            r22 = r15
            int r21 = r21 - r22
            r22 = 24
            r0 = r21
            r1 = r22
            if (r0 > r1) goto L_0x01b5
            r21 = r15
            r22 = 1
            int r21 = r21 >> 1
            r17 = r21
            r21 = r8
            if (r21 <= 0) goto L_0x01b5
            r21 = r11
            if (r21 <= 0) goto L_0x01b5
            r21 = r7
            r22 = r8
            r23 = 1
            int r22 = r22 + -1
            r21 = r21[r22]
            r22 = r11
            r21 = r21[r22]
            r22 = 2
            r23 = r7
            r24 = r8
            r23 = r23[r24]
            r24 = r11
            r25 = 1
            int r24 = r24 + -1
            r23 = r23[r24]
            int r22 = r22 * r23
            int r21 = r21 + r22
            r22 = r7
            r23 = r8
            r24 = 1
            int r23 = r23 + -1
            r22 = r22[r23]
            r23 = r11
            r24 = 1
            int r23 = r23 + -1
            r22 = r22[r23]
            int r21 = r21 + r22
            r22 = 2
            int r21 = r21 >> 2
            r18 = r21
            r21 = r15
            r22 = r18
            r0 = r21
            r1 = r22
            if (r0 >= r1) goto L_0x01b5
            r21 = r18
            r17 = r21
        L_0x01b5:
            r21 = r7
            r22 = r8
            r21 = r21[r22]
            r22 = r11
            r23 = r17
            r21[r22] = r23
            int r11 = r11 + 1
            goto L_0x004c
        L_0x01c5:
            int r8 = r8 + 1
            goto L_0x0020
        L_0x01c9:
            r21 = r7
            r2 = r21
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.common.HybridBinarizer.calculateBlackPoints(byte[], int, int, int, int):int[][]");
    }
}
