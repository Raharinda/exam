package com.google.zxing.common;

import com.google.zxing.FormatException;
import java.util.HashMap;
import java.util.Map;

public enum CharacterSetECI {
    ;
    
    private static final Map<String, CharacterSetECI> NAME_TO_ECI = null;
    private static final Map<Integer, CharacterSetECI> VALUE_TO_ECI = null;
    private final String[] otherEncodingNames;
    private final int[] values;

    static {
        Map<Integer, CharacterSetECI> map;
        Map<String, CharacterSetECI> map2;
        new HashMap();
        VALUE_TO_ECI = map;
        new HashMap();
        NAME_TO_ECI = map2;
        CharacterSetECI[] arr$ = values();
        int length = arr$.length;
        for (int i$ = 0; i$ < length; i$++) {
            CharacterSetECI eci = arr$[i$];
            int[] arr$2 = eci.values;
            int len$ = arr$2.length;
            for (int i$2 = 0; i$2 < len$; i$2++) {
                CharacterSetECI put = VALUE_TO_ECI.put(Integer.valueOf(arr$2[i$2]), eci);
            }
            CharacterSetECI put2 = NAME_TO_ECI.put(eci.name(), eci);
            String[] arr$3 = eci.otherEncodingNames;
            int len$2 = arr$3.length;
            for (int i$3 = 0; i$3 < len$2; i$3++) {
                CharacterSetECI put3 = NAME_TO_ECI.put(arr$3[i$3], eci);
            }
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    private CharacterSetECI(int value) {
        this(r13, r14, new int[]{value}, new String[0]);
    }

    private CharacterSetECI(int value, String... otherEncodingNames2) {
        String str = r12;
        int i = r13;
        int[] iArr = new int[1];
        iArr[0] = value;
        this.values = iArr;
        this.otherEncodingNames = otherEncodingNames2;
    }

    private CharacterSetECI(int[] values2, String... otherEncodingNames2) {
        String str = r9;
        int i = r10;
        this.values = values2;
        this.otherEncodingNames = otherEncodingNames2;
    }

    public int getValue() {
        return this.values[0];
    }

    public static CharacterSetECI getCharacterSetECIByValue(int i) throws FormatException {
        int value = i;
        if (value >= 0 && value < 900) {
            return VALUE_TO_ECI.get(Integer.valueOf(value));
        }
        throw FormatException.getFormatInstance();
    }

    public static CharacterSetECI getCharacterSetECIByName(String name) {
        return NAME_TO_ECI.get(name);
    }
}
