package com.google.zxing.common.reedsolomon;

import java.util.ArrayList;
import java.util.List;

public final class ReedSolomonEncoder {
    private final List<GenericGFPoly> cachedGenerators;
    private final GenericGF field;

    public ReedSolomonEncoder(GenericGF genericGF) {
        List<GenericGFPoly> list;
        Object obj;
        Throwable th;
        GenericGF field2 = genericGF;
        if (!GenericGF.QR_CODE_FIELD_256.equals(field2)) {
            Throwable th2 = th;
            new IllegalArgumentException("Only QR Code is supported at this time");
            throw th2;
        }
        this.field = field2;
        new ArrayList();
        this.cachedGenerators = list;
        List<GenericGFPoly> list2 = this.cachedGenerators;
        Object obj2 = obj;
        new GenericGFPoly(field2, new int[]{1});
        boolean add = list2.add(obj2);
    }

    private GenericGFPoly buildGenerator(int i) {
        GenericGFPoly genericGFPoly;
        int degree = i;
        if (degree >= this.cachedGenerators.size()) {
            GenericGFPoly lastGenerator = this.cachedGenerators.get(this.cachedGenerators.size() - 1);
            for (int d = this.cachedGenerators.size(); d <= degree; d++) {
                GenericGFPoly genericGFPoly2 = genericGFPoly;
                GenericGF genericGF = this.field;
                int[] iArr = new int[2];
                iArr[0] = 1;
                int[] iArr2 = iArr;
                iArr2[1] = this.field.exp(d - 1);
                new GenericGFPoly(genericGF, iArr2);
                GenericGFPoly nextGenerator = lastGenerator.multiply(genericGFPoly2);
                boolean add = this.cachedGenerators.add(nextGenerator);
                lastGenerator = nextGenerator;
            }
        }
        return this.cachedGenerators.get(degree);
    }

    public void encode(int[] iArr, int i) {
        GenericGFPoly info;
        Throwable th;
        Throwable th2;
        int[] toEncode = iArr;
        int ecBytes = i;
        if (ecBytes == 0) {
            Throwable th3 = th2;
            new IllegalArgumentException("No error correction bytes");
            throw th3;
        }
        int dataBytes = toEncode.length - ecBytes;
        if (dataBytes <= 0) {
            Throwable th4 = th;
            new IllegalArgumentException("No data bytes provided");
            throw th4;
        }
        GenericGFPoly generator = buildGenerator(ecBytes);
        int[] infoCoefficients = new int[dataBytes];
        System.arraycopy(toEncode, 0, infoCoefficients, 0, dataBytes);
        new GenericGFPoly(this.field, infoCoefficients);
        int[] coefficients = info.multiplyByMonomial(ecBytes, 1).divide(generator)[1].getCoefficients();
        int numZeroCoefficients = ecBytes - coefficients.length;
        for (int i2 = 0; i2 < numZeroCoefficients; i2++) {
            toEncode[dataBytes + i2] = 0;
        }
        System.arraycopy(coefficients, 0, toEncode, dataBytes + numZeroCoefficients, coefficients.length);
    }
}
