package com.google.zxing.common.reedsolomon;

public final class ReedSolomonException extends Exception {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ReedSolomonException(String message) {
        super(message);
    }
}
