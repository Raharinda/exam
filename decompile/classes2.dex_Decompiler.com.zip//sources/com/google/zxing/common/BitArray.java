package com.google.zxing.common;

public final class BitArray {
    private int[] bits;
    private int size;

    public BitArray() {
        this.size = 0;
        this.bits = new int[1];
    }

    public BitArray(int i) {
        int size2 = i;
        this.size = size2;
        this.bits = makeArray(size2);
    }

    public int getSize() {
        return this.size;
    }

    public int getSizeInBytes() {
        return (this.size + 7) >> 3;
    }

    private void ensureCapacity(int i) {
        int size2 = i;
        if (size2 > (this.bits.length << 5)) {
            int[] newBits = makeArray(size2);
            System.arraycopy(this.bits, 0, newBits, 0, this.bits.length);
            this.bits = newBits;
        }
    }

    public boolean get(int i) {
        int i2 = i;
        return (this.bits[i2 >> 5] & (1 << (i2 & 31))) != 0;
    }

    public void set(int i) {
        int i2 = i;
        int[] iArr = this.bits;
        int i3 = i2 >> 5;
        iArr[i3] = iArr[i3] | (1 << (i2 & 31));
    }

    public void flip(int i) {
        int i2 = i;
        int[] iArr = this.bits;
        int i3 = i2 >> 5;
        iArr[i3] = iArr[i3] ^ (1 << (i2 & 31));
    }

    public int getNextSet(int i) {
        int from = i;
        if (from >= this.size) {
            return this.size;
        }
        int bitsOffset = from >> 5;
        int i2 = this.bits[bitsOffset] & (((1 << (from & 31)) - 1) ^ -1);
        while (true) {
            int currentBits = i2;
            if (currentBits == 0) {
                bitsOffset++;
                if (bitsOffset == this.bits.length) {
                    return this.size;
                }
                i2 = this.bits[bitsOffset];
            } else {
                int result = (bitsOffset << 5) + Integer.numberOfTrailingZeros(currentBits);
                return result > this.size ? this.size : result;
            }
        }
    }

    public int getNextUnset(int i) {
        int from = i;
        if (from >= this.size) {
            return this.size;
        }
        int bitsOffset = from >> 5;
        int i2 = (this.bits[bitsOffset] ^ -1) & (((1 << (from & 31)) - 1) ^ -1);
        while (true) {
            int currentBits = i2;
            if (currentBits == 0) {
                bitsOffset++;
                if (bitsOffset == this.bits.length) {
                    return this.size;
                }
                i2 = this.bits[bitsOffset] ^ -1;
            } else {
                int result = (bitsOffset << 5) + Integer.numberOfTrailingZeros(currentBits);
                return result > this.size ? this.size : result;
            }
        }
    }

    public void setBulk(int i, int newBits) {
        this.bits[i >> 5] = newBits;
    }

    public void setRange(int i, int i2) {
        int mask;
        Throwable th;
        int start = i;
        int end = i2;
        if (end < start) {
            Throwable th2 = th;
            new IllegalArgumentException();
            throw th2;
        } else if (end != start) {
            int end2 = end - 1;
            int firstInt = start >> 5;
            int lastInt = end2 >> 5;
            int i3 = firstInt;
            while (i3 <= lastInt) {
                int firstBit = i3 > firstInt ? 0 : start & 31;
                int lastBit = i3 < lastInt ? 31 : end2 & 31;
                if (firstBit == 0 && lastBit == 31) {
                    mask = -1;
                } else {
                    mask = 0;
                    for (int j = firstBit; j <= lastBit; j++) {
                        mask |= 1 << j;
                    }
                }
                int[] iArr = this.bits;
                int i4 = i3;
                iArr[i4] = iArr[i4] | mask;
                i3++;
            }
        }
    }

    public void clear() {
        int max = this.bits.length;
        for (int i = 0; i < max; i++) {
            this.bits[i] = 0;
        }
    }

    public boolean isRange(int i, int i2, boolean z) {
        int mask;
        Throwable th;
        int start = i;
        int end = i2;
        boolean value = z;
        if (end < start) {
            Throwable th2 = th;
            new IllegalArgumentException();
            throw th2;
        } else if (end == start) {
            return true;
        } else {
            int end2 = end - 1;
            int firstInt = start >> 5;
            int lastInt = end2 >> 5;
            int i3 = firstInt;
            while (i3 <= lastInt) {
                int firstBit = i3 > firstInt ? 0 : start & 31;
                int lastBit = i3 < lastInt ? 31 : end2 & 31;
                if (firstBit == 0 && lastBit == 31) {
                    mask = -1;
                } else {
                    mask = 0;
                    for (int j = firstBit; j <= lastBit; j++) {
                        mask |= 1 << j;
                    }
                }
                if ((this.bits[i3] & mask) != (value ? mask : 0)) {
                    return false;
                }
                i3++;
            }
            return true;
        }
    }

    public void appendBit(boolean bit) {
        ensureCapacity(this.size + 1);
        if (bit) {
            int[] iArr = this.bits;
            int i = this.size >> 5;
            iArr[i] = iArr[i] | (1 << (this.size & 31));
        }
        this.size++;
    }

    public void appendBits(int i, int i2) {
        Throwable th;
        int value = i;
        int numBits = i2;
        if (numBits < 0 || numBits > 32) {
            Throwable th2 = th;
            new IllegalArgumentException("Num bits must be between 0 and 32");
            throw th2;
        }
        ensureCapacity(this.size + numBits);
        for (int numBitsLeft = numBits; numBitsLeft > 0; numBitsLeft--) {
            appendBit(((value >> (numBitsLeft + -1)) & 1) == 1);
        }
    }

    public void appendBitArray(BitArray bitArray) {
        BitArray other = bitArray;
        int otherSize = other.size;
        ensureCapacity(this.size + otherSize);
        for (int i = 0; i < otherSize; i++) {
            appendBit(other.get(i));
        }
    }

    public void xor(BitArray bitArray) {
        Throwable th;
        BitArray other = bitArray;
        if (this.bits.length != other.bits.length) {
            Throwable th2 = th;
            new IllegalArgumentException("Sizes don't match");
            throw th2;
        }
        for (int i = 0; i < this.bits.length; i++) {
            int[] iArr = this.bits;
            int i2 = i;
            iArr[i2] = iArr[i2] ^ other.bits[i];
        }
    }

    public void toBytes(int i, byte[] bArr, int i2, int i3) {
        int bitOffset = i;
        byte[] array = bArr;
        int offset = i2;
        int numBytes = i3;
        for (int i4 = 0; i4 < numBytes; i4++) {
            int theByte = 0;
            for (int j = 0; j < 8; j++) {
                if (get(bitOffset)) {
                    theByte |= 1 << (7 - j);
                }
                bitOffset++;
            }
            array[offset + i4] = (byte) theByte;
        }
    }

    public int[] getBitArray() {
        return this.bits;
    }

    public void reverse() {
        int[] newBits = new int[this.bits.length];
        int size2 = this.size;
        for (int i = 0; i < size2; i++) {
            if (get((size2 - i) - 1)) {
                int[] iArr = newBits;
                int i2 = i >> 5;
                iArr[i2] = iArr[i2] | (1 << (i & 31));
            }
        }
        this.bits = newBits;
    }

    private static int[] makeArray(int size2) {
        return new int[((size2 + 31) >> 5)];
    }

    public String toString() {
        StringBuilder sb;
        new StringBuilder(this.size);
        StringBuilder result = sb;
        for (int i = 0; i < this.size; i++) {
            if ((i & 7) == 0) {
                StringBuilder append = result.append(' ');
            }
            StringBuilder append2 = result.append(get(i) ? 'X' : '.');
        }
        return result.toString();
    }
}
