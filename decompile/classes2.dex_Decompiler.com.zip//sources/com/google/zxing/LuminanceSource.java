package com.google.zxing;

public abstract class LuminanceSource {
    private final int height;
    private final int width;

    public abstract byte[] getMatrix();

    public abstract byte[] getRow(int i, byte[] bArr);

    protected LuminanceSource(int width2, int height2) {
        this.width = width2;
        this.height = height2;
    }

    public final int getWidth() {
        return this.width;
    }

    public final int getHeight() {
        return this.height;
    }

    public boolean isCropSupported() {
        return false;
    }

    public LuminanceSource crop(int i, int i2, int i3, int i4) {
        Throwable th;
        int i5 = i;
        int i6 = i2;
        int i7 = i3;
        int i8 = i4;
        Throwable th2 = th;
        new UnsupportedOperationException("This luminance source does not support cropping.");
        throw th2;
    }

    public boolean isRotateSupported() {
        return false;
    }

    public LuminanceSource rotateCounterClockwise() {
        Throwable th;
        Throwable th2 = th;
        new UnsupportedOperationException("This luminance source does not support rotation by 90 degrees.");
        throw th2;
    }

    public LuminanceSource rotateCounterClockwise45() {
        Throwable th;
        Throwable th2 = th;
        new UnsupportedOperationException("This luminance source does not support rotation by 45 degrees.");
        throw th2;
    }

    public final String toString() {
        StringBuilder sb;
        char c;
        byte[] row = new byte[this.width];
        new StringBuilder(this.height * (this.width + 1));
        StringBuilder result = sb;
        for (int y = 0; y < this.height; y++) {
            row = getRow(y, row);
            for (int x = 0; x < this.width; x++) {
                int luminance = row[x] & 255;
                if (luminance < 64) {
                    c = '#';
                } else if (luminance < 128) {
                    c = '+';
                } else if (luminance < 192) {
                    c = '.';
                } else {
                    c = ' ';
                }
                StringBuilder append = result.append(c);
            }
            StringBuilder append2 = result.append(10);
        }
        return result.toString();
    }
}
