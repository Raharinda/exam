package com.google.zxing;

import com.google.zxing.common.detector.MathUtils;

public class ResultPoint {
    private final float x;
    private final float y;

    public ResultPoint(float x2, float y2) {
        this.x = x2;
        this.y = y2;
    }

    public final float getX() {
        return this.x;
    }

    public final float getY() {
        return this.y;
    }

    public final boolean equals(Object obj) {
        Object other = obj;
        if (!(other instanceof ResultPoint)) {
            return false;
        }
        ResultPoint otherPoint = (ResultPoint) other;
        return this.x == otherPoint.x && this.y == otherPoint.y;
    }

    public final int hashCode() {
        return (31 * Float.floatToIntBits(this.x)) + Float.floatToIntBits(this.y);
    }

    public final String toString() {
        StringBuilder sb;
        new StringBuilder(25);
        StringBuilder result = sb;
        StringBuilder append = result.append('(');
        StringBuilder append2 = result.append(this.x);
        StringBuilder append3 = result.append(',');
        StringBuilder append4 = result.append(this.y);
        StringBuilder append5 = result.append(')');
        return result.toString();
    }

    public static void orderBestPatterns(ResultPoint[] resultPointArr) {
        ResultPoint pointB;
        ResultPoint pointA;
        ResultPoint pointC;
        ResultPoint[] patterns = resultPointArr;
        float zeroOneDistance = distance(patterns[0], patterns[1]);
        float oneTwoDistance = distance(patterns[1], patterns[2]);
        float zeroTwoDistance = distance(patterns[0], patterns[2]);
        if (oneTwoDistance >= zeroOneDistance && oneTwoDistance >= zeroTwoDistance) {
            pointB = patterns[0];
            pointA = patterns[1];
            pointC = patterns[2];
        } else if (zeroTwoDistance < oneTwoDistance || zeroTwoDistance < zeroOneDistance) {
            pointB = patterns[2];
            pointA = patterns[0];
            pointC = patterns[1];
        } else {
            pointB = patterns[1];
            pointA = patterns[0];
            pointC = patterns[2];
        }
        if (crossProductZ(pointA, pointB, pointC) < 0.0f) {
            ResultPoint temp = pointA;
            pointA = pointC;
            pointC = temp;
        }
        patterns[0] = pointA;
        patterns[1] = pointB;
        patterns[2] = pointC;
    }

    public static float distance(ResultPoint resultPoint, ResultPoint resultPoint2) {
        ResultPoint pattern1 = resultPoint;
        ResultPoint pattern2 = resultPoint2;
        return MathUtils.distance(pattern1.x, pattern1.y, pattern2.x, pattern2.y);
    }

    private static float crossProductZ(ResultPoint resultPoint, ResultPoint resultPoint2, ResultPoint resultPoint3) {
        ResultPoint pointA = resultPoint;
        ResultPoint pointB = resultPoint2;
        ResultPoint pointC = resultPoint3;
        float bX = pointB.x;
        float bY = pointB.y;
        return ((pointC.x - bX) * (pointA.y - bY)) - ((pointC.y - bY) * (pointA.x - bX));
    }
}
