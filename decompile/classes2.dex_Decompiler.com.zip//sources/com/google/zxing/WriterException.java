package com.google.zxing;

public final class WriterException extends Exception {
    public WriterException() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WriterException(String message) {
        super(message);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WriterException(Throwable cause) {
        super(cause);
    }
}
