package com.google.zxing.datamatrix.decoder;

import com.google.zxing.FormatException;

public final class Version {
    private static final Version[] VERSIONS = buildVersions();
    private final int dataRegionSizeColumns;
    private final int dataRegionSizeRows;
    private final ECBlocks ecBlocks;
    private final int symbolSizeColumns;
    private final int symbolSizeRows;
    private final int totalCodewords;
    private final int versionNumber;

    private Version(int versionNumber2, int symbolSizeRows2, int symbolSizeColumns2, int dataRegionSizeRows2, int dataRegionSizeColumns2, ECBlocks eCBlocks) {
        ECBlocks ecBlocks2 = eCBlocks;
        this.versionNumber = versionNumber2;
        this.symbolSizeRows = symbolSizeRows2;
        this.symbolSizeColumns = symbolSizeColumns2;
        this.dataRegionSizeRows = dataRegionSizeRows2;
        this.dataRegionSizeColumns = dataRegionSizeColumns2;
        this.ecBlocks = ecBlocks2;
        int total = 0;
        int ecCodewords = ecBlocks2.getECCodewords();
        ECB[] arr$ = ecBlocks2.getECBlocks();
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            ECB ecBlock = arr$[i$];
            total += ecBlock.getCount() * (ecBlock.getDataCodewords() + ecCodewords);
        }
        this.totalCodewords = total;
    }

    public int getVersionNumber() {
        return this.versionNumber;
    }

    public int getSymbolSizeRows() {
        return this.symbolSizeRows;
    }

    public int getSymbolSizeColumns() {
        return this.symbolSizeColumns;
    }

    public int getDataRegionSizeRows() {
        return this.dataRegionSizeRows;
    }

    public int getDataRegionSizeColumns() {
        return this.dataRegionSizeColumns;
    }

    public int getTotalCodewords() {
        return this.totalCodewords;
    }

    /* access modifiers changed from: package-private */
    public ECBlocks getECBlocks() {
        return this.ecBlocks;
    }

    public static Version getVersionForDimensions(int i, int i2) throws FormatException {
        int numRows = i;
        int numColumns = i2;
        if ((numRows & 1) == 0 && (numColumns & 1) == 0) {
            Version[] arr$ = VERSIONS;
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                Version version = arr$[i$];
                if (version.symbolSizeRows == numRows && version.symbolSizeColumns == numColumns) {
                    return version;
                }
            }
            throw FormatException.getFormatInstance();
        }
        throw FormatException.getFormatInstance();
    }

    static final class ECBlocks {
        private final ECB[] ecBlocks;
        private final int ecCodewords;

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ ECBlocks(int x0, ECB x1, AnonymousClass1 r10) {
            this(x0, x1);
            AnonymousClass1 r3 = r10;
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ ECBlocks(int x0, ECB x1, ECB x2, AnonymousClass1 r13) {
            this(x0, x1, x2);
            AnonymousClass1 r4 = r13;
        }

        private ECBlocks(int ecCodewords2, ECB ecBlocks2) {
            this.ecCodewords = ecCodewords2;
            ECB[] ecbArr = new ECB[1];
            ecbArr[0] = ecBlocks2;
            this.ecBlocks = ecbArr;
        }

        private ECBlocks(int ecCodewords2, ECB ecBlocks1, ECB ecBlocks2) {
            this.ecCodewords = ecCodewords2;
            ECB[] ecbArr = new ECB[2];
            ecbArr[0] = ecBlocks1;
            ECB[] ecbArr2 = ecbArr;
            ecbArr2[1] = ecBlocks2;
            this.ecBlocks = ecbArr2;
        }

        /* access modifiers changed from: package-private */
        public int getECCodewords() {
            return this.ecCodewords;
        }

        /* access modifiers changed from: package-private */
        public ECB[] getECBlocks() {
            return this.ecBlocks;
        }
    }

    static final class ECB {
        private final int count;
        private final int dataCodewords;

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ ECB(int x0, int x1, AnonymousClass1 r10) {
            this(x0, x1);
            AnonymousClass1 r3 = r10;
        }

        private ECB(int count2, int dataCodewords2) {
            this.count = count2;
            this.dataCodewords = dataCodewords2;
        }

        /* access modifiers changed from: package-private */
        public int getCount() {
            return this.count;
        }

        /* access modifiers changed from: package-private */
        public int getDataCodewords() {
            return this.dataCodewords;
        }
    }

    public String toString() {
        return String.valueOf(this.versionNumber);
    }

    private static Version[] buildVersions() {
        Version version;
        ECBlocks eCBlocks;
        ECB ecb;
        Version version2;
        ECBlocks eCBlocks2;
        ECB ecb2;
        Version version3;
        ECBlocks eCBlocks3;
        ECB ecb3;
        Version version4;
        ECBlocks eCBlocks4;
        ECB ecb4;
        Version version5;
        ECBlocks eCBlocks5;
        ECB ecb5;
        Version version6;
        ECBlocks eCBlocks6;
        ECB ecb6;
        Version version7;
        ECBlocks eCBlocks7;
        ECB ecb7;
        Version version8;
        ECBlocks eCBlocks8;
        ECB ecb8;
        Version version9;
        ECBlocks eCBlocks9;
        ECB ecb9;
        Version version10;
        ECBlocks eCBlocks10;
        ECB ecb10;
        Version version11;
        ECBlocks eCBlocks11;
        ECB ecb11;
        Version version12;
        ECBlocks eCBlocks12;
        ECB ecb12;
        Version version13;
        ECBlocks eCBlocks13;
        ECB ecb13;
        Version version14;
        ECBlocks eCBlocks14;
        ECB ecb14;
        Version version15;
        ECBlocks eCBlocks15;
        ECB ecb15;
        Version version16;
        ECBlocks eCBlocks16;
        ECB ecb16;
        Version version17;
        ECBlocks eCBlocks17;
        ECB ecb17;
        Version version18;
        ECBlocks eCBlocks18;
        ECB ecb18;
        Version version19;
        ECBlocks eCBlocks19;
        ECB ecb19;
        Version version20;
        ECBlocks eCBlocks20;
        ECB ecb20;
        Version version21;
        ECBlocks eCBlocks21;
        ECB ecb21;
        Version version22;
        ECBlocks eCBlocks22;
        ECB ecb22;
        Version version23;
        ECBlocks eCBlocks23;
        ECB ecb23;
        Version version24;
        ECBlocks eCBlocks24;
        ECB ecb24;
        ECB ecb25;
        Version version25;
        ECBlocks eCBlocks25;
        ECB ecb26;
        Version version26;
        ECBlocks eCBlocks26;
        ECB ecb27;
        Version version27;
        ECBlocks eCBlocks27;
        ECB ecb28;
        Version version28;
        ECBlocks eCBlocks28;
        ECB ecb29;
        Version version29;
        ECBlocks eCBlocks29;
        ECB ecb30;
        Version version30;
        ECBlocks eCBlocks30;
        ECB ecb31;
        Version[] versionArr = new Version[30];
        new ECB(1, 3, (AnonymousClass1) null);
        new ECBlocks(5, ecb, (AnonymousClass1) null);
        new Version(1, 10, 10, 8, 8, eCBlocks);
        versionArr[0] = version;
        Version[] versionArr2 = versionArr;
        new ECB(1, 5, (AnonymousClass1) null);
        new ECBlocks(7, ecb2, (AnonymousClass1) null);
        new Version(2, 12, 12, 10, 10, eCBlocks2);
        versionArr2[1] = version2;
        Version[] versionArr3 = versionArr2;
        new ECB(1, 8, (AnonymousClass1) null);
        new ECBlocks(10, ecb3, (AnonymousClass1) null);
        new Version(3, 14, 14, 12, 12, eCBlocks3);
        versionArr3[2] = version3;
        Version[] versionArr4 = versionArr3;
        new ECB(1, 12, (AnonymousClass1) null);
        new ECBlocks(12, ecb4, (AnonymousClass1) null);
        new Version(4, 16, 16, 14, 14, eCBlocks4);
        versionArr4[3] = version4;
        Version[] versionArr5 = versionArr4;
        new ECB(1, 18, (AnonymousClass1) null);
        new ECBlocks(14, ecb5, (AnonymousClass1) null);
        new Version(5, 18, 18, 16, 16, eCBlocks5);
        versionArr5[4] = version5;
        Version[] versionArr6 = versionArr5;
        new ECB(1, 22, (AnonymousClass1) null);
        new ECBlocks(18, ecb6, (AnonymousClass1) null);
        new Version(6, 20, 20, 18, 18, eCBlocks6);
        versionArr6[5] = version6;
        Version[] versionArr7 = versionArr6;
        new ECB(1, 30, (AnonymousClass1) null);
        new ECBlocks(20, ecb7, (AnonymousClass1) null);
        new Version(7, 22, 22, 20, 20, eCBlocks7);
        versionArr7[6] = version7;
        Version[] versionArr8 = versionArr7;
        new ECB(1, 36, (AnonymousClass1) null);
        new ECBlocks(24, ecb8, (AnonymousClass1) null);
        new Version(8, 24, 24, 22, 22, eCBlocks8);
        versionArr8[7] = version8;
        Version[] versionArr9 = versionArr8;
        new ECB(1, 44, (AnonymousClass1) null);
        new ECBlocks(28, ecb9, (AnonymousClass1) null);
        new Version(9, 26, 26, 24, 24, eCBlocks9);
        versionArr9[8] = version9;
        Version[] versionArr10 = versionArr9;
        new ECB(1, 62, (AnonymousClass1) null);
        new ECBlocks(36, ecb10, (AnonymousClass1) null);
        new Version(10, 32, 32, 14, 14, eCBlocks10);
        versionArr10[9] = version10;
        Version[] versionArr11 = versionArr10;
        new ECB(1, 86, (AnonymousClass1) null);
        new ECBlocks(42, ecb11, (AnonymousClass1) null);
        new Version(11, 36, 36, 16, 16, eCBlocks11);
        versionArr11[10] = version11;
        Version[] versionArr12 = versionArr11;
        new ECB(1, 114, (AnonymousClass1) null);
        new ECBlocks(48, ecb12, (AnonymousClass1) null);
        new Version(12, 40, 40, 18, 18, eCBlocks12);
        versionArr12[11] = version12;
        Version[] versionArr13 = versionArr12;
        new ECB(1, 144, (AnonymousClass1) null);
        new ECBlocks(56, ecb13, (AnonymousClass1) null);
        new Version(13, 44, 44, 20, 20, eCBlocks13);
        versionArr13[12] = version13;
        Version[] versionArr14 = versionArr13;
        new ECB(1, 174, (AnonymousClass1) null);
        new ECBlocks(68, ecb14, (AnonymousClass1) null);
        new Version(14, 48, 48, 22, 22, eCBlocks14);
        versionArr14[13] = version14;
        Version[] versionArr15 = versionArr14;
        new ECB(2, 102, (AnonymousClass1) null);
        new ECBlocks(42, ecb15, (AnonymousClass1) null);
        new Version(15, 52, 52, 24, 24, eCBlocks15);
        versionArr15[14] = version15;
        Version[] versionArr16 = versionArr15;
        new ECB(2, 140, (AnonymousClass1) null);
        new ECBlocks(56, ecb16, (AnonymousClass1) null);
        new Version(16, 64, 64, 14, 14, eCBlocks16);
        versionArr16[15] = version16;
        Version[] versionArr17 = versionArr16;
        new ECB(4, 92, (AnonymousClass1) null);
        new ECBlocks(36, ecb17, (AnonymousClass1) null);
        new Version(17, 72, 72, 16, 16, eCBlocks17);
        versionArr17[16] = version17;
        Version[] versionArr18 = versionArr17;
        new ECB(4, 114, (AnonymousClass1) null);
        new ECBlocks(48, ecb18, (AnonymousClass1) null);
        new Version(18, 80, 80, 18, 18, eCBlocks18);
        versionArr18[17] = version18;
        Version[] versionArr19 = versionArr18;
        new ECB(4, 144, (AnonymousClass1) null);
        new ECBlocks(56, ecb19, (AnonymousClass1) null);
        new Version(19, 88, 88, 20, 20, eCBlocks19);
        versionArr19[18] = version19;
        Version[] versionArr20 = versionArr19;
        new ECB(4, 174, (AnonymousClass1) null);
        new ECBlocks(68, ecb20, (AnonymousClass1) null);
        new Version(20, 96, 96, 22, 22, eCBlocks20);
        versionArr20[19] = version20;
        Version[] versionArr21 = versionArr20;
        new ECB(6, 136, (AnonymousClass1) null);
        new ECBlocks(56, ecb21, (AnonymousClass1) null);
        new Version(21, 104, 104, 24, 24, eCBlocks21);
        versionArr21[20] = version21;
        Version[] versionArr22 = versionArr21;
        new ECB(6, 175, (AnonymousClass1) null);
        new ECBlocks(68, ecb22, (AnonymousClass1) null);
        new Version(22, 120, 120, 18, 18, eCBlocks22);
        versionArr22[21] = version22;
        Version[] versionArr23 = versionArr22;
        new ECB(8, 163, (AnonymousClass1) null);
        new ECBlocks(62, ecb23, (AnonymousClass1) null);
        new Version(23, 132, 132, 20, 20, eCBlocks23);
        versionArr23[22] = version23;
        Version[] versionArr24 = versionArr23;
        new ECB(8, 156, (AnonymousClass1) null);
        new ECB(2, 155, (AnonymousClass1) null);
        new ECBlocks(62, ecb24, ecb25, (AnonymousClass1) null);
        new Version(24, 144, 144, 22, 22, eCBlocks24);
        versionArr24[23] = version24;
        Version[] versionArr25 = versionArr24;
        new ECB(1, 5, (AnonymousClass1) null);
        new ECBlocks(7, ecb26, (AnonymousClass1) null);
        new Version(25, 8, 18, 6, 16, eCBlocks25);
        versionArr25[24] = version25;
        Version[] versionArr26 = versionArr25;
        new ECB(1, 10, (AnonymousClass1) null);
        new ECBlocks(11, ecb27, (AnonymousClass1) null);
        new Version(26, 8, 32, 6, 14, eCBlocks26);
        versionArr26[25] = version26;
        Version[] versionArr27 = versionArr26;
        new ECB(1, 16, (AnonymousClass1) null);
        new ECBlocks(14, ecb28, (AnonymousClass1) null);
        new Version(27, 12, 26, 10, 24, eCBlocks27);
        versionArr27[26] = version27;
        Version[] versionArr28 = versionArr27;
        new ECB(1, 22, (AnonymousClass1) null);
        new ECBlocks(18, ecb29, (AnonymousClass1) null);
        new Version(28, 12, 36, 10, 16, eCBlocks28);
        versionArr28[27] = version28;
        Version[] versionArr29 = versionArr28;
        new ECB(1, 32, (AnonymousClass1) null);
        new ECBlocks(24, ecb30, (AnonymousClass1) null);
        new Version(29, 16, 36, 14, 16, eCBlocks29);
        versionArr29[28] = version29;
        Version[] versionArr30 = versionArr29;
        Version[] versionArr31 = versionArr30;
        new ECB(1, 49, (AnonymousClass1) null);
        new ECBlocks(28, ecb31, (AnonymousClass1) null);
        new Version(30, 16, 48, 14, 22, eCBlocks30);
        versionArr30[29] = version30;
        return versionArr31;
    }
}
