package com.google.zxing.datamatrix.decoder;

import com.google.zxing.FormatException;
import com.google.zxing.common.BitSource;
import java.io.UnsupportedEncodingException;
import java.util.Collection;

final class DecodedBitStreamParser {
    private static final char[] C40_BASIC_SET_CHARS = {'*', '*', '*', ' ', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
    private static final char[] C40_SHIFT2_SET_CHARS = {'!', '\"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_'};
    private static final char[] TEXT_BASIC_SET_CHARS = {'*', '*', '*', ' ', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
    private static final char[] TEXT_SHIFT3_SET_CHARS = {'\'', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '{', '|', '}', '~', 127};

    private enum Mode {
    }

    private DecodedBitStreamParser() {
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x004d  */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x0069  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0070  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x00a3  */
    /* JADX WARNING: Removed duplicated region for block: B:3:0x0032  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static com.google.zxing.common.DecoderResult decode(byte[] r13) throws com.google.zxing.FormatException {
        /*
            r0 = r13
            com.google.zxing.common.BitSource r6 = new com.google.zxing.common.BitSource
            r12 = r6
            r6 = r12
            r7 = r12
            r8 = r0
            r7.<init>(r8)
            r1 = r6
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r12 = r6
            r6 = r12
            r7 = r12
            r8 = 100
            r7.<init>(r8)
            r2 = r6
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r12 = r6
            r6 = r12
            r7 = r12
            r8 = 0
            r7.<init>(r8)
            r3 = r6
            java.util.ArrayList r6 = new java.util.ArrayList
            r12 = r6
            r6 = r12
            r7 = r12
            r8 = 1
            r7.<init>(r8)
            r4 = r6
            com.google.zxing.datamatrix.decoder.DecodedBitStreamParser$Mode r6 = com.google.zxing.datamatrix.decoder.DecodedBitStreamParser.Mode.ASCII_ENCODE
            r5 = r6
        L_0x002d:
            r6 = r5
            com.google.zxing.datamatrix.decoder.DecodedBitStreamParser$Mode r7 = com.google.zxing.datamatrix.decoder.DecodedBitStreamParser.Mode.ASCII_ENCODE
            if (r6 != r7) goto L_0x0070
            r6 = r1
            r7 = r2
            r8 = r3
            com.google.zxing.datamatrix.decoder.DecodedBitStreamParser$Mode r6 = decodeAsciiSegment(r6, r7, r8)
            r5 = r6
        L_0x003a:
            r6 = r5
            com.google.zxing.datamatrix.decoder.DecodedBitStreamParser$Mode r7 = com.google.zxing.datamatrix.decoder.DecodedBitStreamParser.Mode.PAD_ENCODE
            if (r6 == r7) goto L_0x0046
            r6 = r1
            int r6 = r6.available()
            if (r6 > 0) goto L_0x002d
        L_0x0046:
            r6 = r3
            int r6 = r6.length()
            if (r6 <= 0) goto L_0x0057
            r6 = r2
            r7 = r3
            java.lang.String r7 = r7.toString()
            java.lang.StringBuilder r6 = r6.append(r7)
        L_0x0057:
            com.google.zxing.common.DecoderResult r6 = new com.google.zxing.common.DecoderResult
            r12 = r6
            r6 = r12
            r7 = r12
            r8 = r0
            r9 = r2
            java.lang.String r9 = r9.toString()
            r10 = r4
            boolean r10 = r10.isEmpty()
            if (r10 == 0) goto L_0x00a3
            r10 = 0
        L_0x006a:
            r11 = 0
            r7.<init>(r8, r9, r10, r11)
            r0 = r6
            return r0
        L_0x0070:
            int[] r6 = com.google.zxing.datamatrix.decoder.DecodedBitStreamParser.AnonymousClass1.$SwitchMap$com$google$zxing$datamatrix$decoder$DecodedBitStreamParser$Mode
            r7 = r5
            int r7 = r7.ordinal()
            r6 = r6[r7]
            switch(r6) {
                case 1: goto L_0x0081;
                case 2: goto L_0x008a;
                case 3: goto L_0x0090;
                case 4: goto L_0x0096;
                case 5: goto L_0x009c;
                default: goto L_0x007c;
            }
        L_0x007c:
            com.google.zxing.FormatException r6 = com.google.zxing.FormatException.getFormatInstance()
            throw r6
        L_0x0081:
            r6 = r1
            r7 = r2
            decodeC40Segment(r6, r7)
        L_0x0086:
            com.google.zxing.datamatrix.decoder.DecodedBitStreamParser$Mode r6 = com.google.zxing.datamatrix.decoder.DecodedBitStreamParser.Mode.ASCII_ENCODE
            r5 = r6
            goto L_0x003a
        L_0x008a:
            r6 = r1
            r7 = r2
            decodeTextSegment(r6, r7)
            goto L_0x0086
        L_0x0090:
            r6 = r1
            r7 = r2
            decodeAnsiX12Segment(r6, r7)
            goto L_0x0086
        L_0x0096:
            r6 = r1
            r7 = r2
            decodeEdifactSegment(r6, r7)
            goto L_0x0086
        L_0x009c:
            r6 = r1
            r7 = r2
            r8 = r4
            decodeBase256Segment(r6, r7, r8)
            goto L_0x0086
        L_0x00a3:
            r10 = r4
            goto L_0x006a
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.datamatrix.decoder.DecodedBitStreamParser.decode(byte[]):com.google.zxing.common.DecoderResult");
    }

    private static Mode decodeAsciiSegment(BitSource bitSource, StringBuilder sb, StringBuilder sb2) throws FormatException {
        BitSource bits = bitSource;
        StringBuilder result = sb;
        StringBuilder resultTrailer = sb2;
        boolean upperShift = false;
        do {
            int oneByte = bits.readBits(8);
            if (oneByte == 0) {
                throw FormatException.getFormatInstance();
            } else if (oneByte <= 128) {
                if (upperShift) {
                    oneByte += 128;
                }
                StringBuilder append = result.append((char) (oneByte - 1));
                return Mode.ASCII_ENCODE;
            } else if (oneByte == 129) {
                return Mode.PAD_ENCODE;
            } else {
                if (oneByte <= 229) {
                    int value = oneByte - 130;
                    if (value < 10) {
                        StringBuilder append2 = result.append('0');
                    }
                    StringBuilder append3 = result.append(value);
                } else if (oneByte == 230) {
                    return Mode.C40_ENCODE;
                } else {
                    if (oneByte == 231) {
                        return Mode.BASE256_ENCODE;
                    }
                    if (oneByte == 232) {
                        StringBuilder append4 = result.append(29);
                    } else if (!(oneByte == 233 || oneByte == 234)) {
                        if (oneByte == 235) {
                            upperShift = true;
                        } else if (oneByte == 236) {
                            StringBuilder append5 = result.append("[)>\u001e05\u001d");
                            StringBuilder insert = resultTrailer.insert(0, "\u001e\u0004");
                        } else if (oneByte == 237) {
                            StringBuilder append6 = result.append("[)>\u001e06\u001d");
                            StringBuilder insert2 = resultTrailer.insert(0, "\u001e\u0004");
                        } else if (oneByte == 238) {
                            return Mode.ANSIX12_ENCODE;
                        } else {
                            if (oneByte == 239) {
                                return Mode.TEXT_ENCODE;
                            }
                            if (oneByte == 240) {
                                return Mode.EDIFACT_ENCODE;
                            }
                            if (!(oneByte == 241 || oneByte < 242 || (oneByte == 254 && bits.available() == 0))) {
                                throw FormatException.getFormatInstance();
                            }
                        }
                    }
                }
            }
        } while (bits.available() > 0);
        return Mode.ASCII_ENCODE;
    }

    private static void decodeC40Segment(BitSource bitSource, StringBuilder sb) throws FormatException {
        int firstByte;
        BitSource bits = bitSource;
        StringBuilder result = sb;
        boolean upperShift = false;
        int[] cValues = new int[3];
        int shift = 0;
        while (bits.available() != 8 && (firstByte = bits.readBits(8)) != 254) {
            parseTwoBytes(firstByte, bits.readBits(8), cValues);
            for (int i = 0; i < 3; i++) {
                int cValue = cValues[i];
                switch (shift) {
                    case 0:
                        if (cValue < 3) {
                            shift = cValue + 1;
                            break;
                        } else if (cValue < C40_BASIC_SET_CHARS.length) {
                            char c40char = C40_BASIC_SET_CHARS[cValue];
                            if (!upperShift) {
                                StringBuilder append = result.append(c40char);
                                break;
                            } else {
                                StringBuilder append2 = result.append((char) (c40char + 128));
                                upperShift = false;
                                break;
                            }
                        } else {
                            throw FormatException.getFormatInstance();
                        }
                    case 1:
                        if (upperShift) {
                            StringBuilder append3 = result.append((char) (cValue + 128));
                            upperShift = false;
                        } else {
                            StringBuilder append4 = result.append((char) cValue);
                        }
                        shift = 0;
                        break;
                    case 2:
                        if (cValue < C40_SHIFT2_SET_CHARS.length) {
                            char c40char2 = C40_SHIFT2_SET_CHARS[cValue];
                            if (upperShift) {
                                StringBuilder append5 = result.append((char) (c40char2 + 128));
                                upperShift = false;
                            } else {
                                StringBuilder append6 = result.append(c40char2);
                            }
                        } else if (cValue == 27) {
                            StringBuilder append7 = result.append(29);
                        } else if (cValue == 30) {
                            upperShift = true;
                        } else {
                            throw FormatException.getFormatInstance();
                        }
                        shift = 0;
                        break;
                    case 3:
                        if (upperShift) {
                            StringBuilder append8 = result.append((char) (cValue + 224));
                            upperShift = false;
                        } else {
                            StringBuilder append9 = result.append((char) (cValue + 96));
                        }
                        shift = 0;
                        break;
                    default:
                        throw FormatException.getFormatInstance();
                }
            }
            if (bits.available() <= 0) {
                return;
            }
        }
    }

    private static void decodeTextSegment(BitSource bitSource, StringBuilder sb) throws FormatException {
        int firstByte;
        BitSource bits = bitSource;
        StringBuilder result = sb;
        boolean upperShift = false;
        int[] cValues = new int[3];
        int shift = 0;
        while (bits.available() != 8 && (firstByte = bits.readBits(8)) != 254) {
            parseTwoBytes(firstByte, bits.readBits(8), cValues);
            for (int i = 0; i < 3; i++) {
                int cValue = cValues[i];
                switch (shift) {
                    case 0:
                        if (cValue < 3) {
                            shift = cValue + 1;
                            break;
                        } else if (cValue < TEXT_BASIC_SET_CHARS.length) {
                            char textChar = TEXT_BASIC_SET_CHARS[cValue];
                            if (!upperShift) {
                                StringBuilder append = result.append(textChar);
                                break;
                            } else {
                                StringBuilder append2 = result.append((char) (textChar + 128));
                                upperShift = false;
                                break;
                            }
                        } else {
                            throw FormatException.getFormatInstance();
                        }
                    case 1:
                        if (upperShift) {
                            StringBuilder append3 = result.append((char) (cValue + 128));
                            upperShift = false;
                        } else {
                            StringBuilder append4 = result.append((char) cValue);
                        }
                        shift = 0;
                        break;
                    case 2:
                        if (cValue < C40_SHIFT2_SET_CHARS.length) {
                            char c40char = C40_SHIFT2_SET_CHARS[cValue];
                            if (upperShift) {
                                StringBuilder append5 = result.append((char) (c40char + 128));
                                upperShift = false;
                            } else {
                                StringBuilder append6 = result.append(c40char);
                            }
                        } else if (cValue == 27) {
                            StringBuilder append7 = result.append(29);
                        } else if (cValue == 30) {
                            upperShift = true;
                        } else {
                            throw FormatException.getFormatInstance();
                        }
                        shift = 0;
                        break;
                    case 3:
                        if (cValue < TEXT_SHIFT3_SET_CHARS.length) {
                            char textChar2 = TEXT_SHIFT3_SET_CHARS[cValue];
                            if (upperShift) {
                                StringBuilder append8 = result.append((char) (textChar2 + 128));
                                upperShift = false;
                            } else {
                                StringBuilder append9 = result.append(textChar2);
                            }
                            shift = 0;
                            break;
                        } else {
                            throw FormatException.getFormatInstance();
                        }
                    default:
                        throw FormatException.getFormatInstance();
                }
            }
            if (bits.available() <= 0) {
                return;
            }
        }
    }

    private static void decodeAnsiX12Segment(BitSource bitSource, StringBuilder sb) throws FormatException {
        int firstByte;
        BitSource bits = bitSource;
        StringBuilder result = sb;
        int[] cValues = new int[3];
        while (bits.available() != 8 && (firstByte = bits.readBits(8)) != 254) {
            parseTwoBytes(firstByte, bits.readBits(8), cValues);
            for (int i = 0; i < 3; i++) {
                int cValue = cValues[i];
                if (cValue == 0) {
                    StringBuilder append = result.append(13);
                } else if (cValue == 1) {
                    StringBuilder append2 = result.append('*');
                } else if (cValue == 2) {
                    StringBuilder append3 = result.append('>');
                } else if (cValue == 3) {
                    StringBuilder append4 = result.append(' ');
                } else if (cValue < 14) {
                    StringBuilder append5 = result.append((char) (cValue + 44));
                } else if (cValue < 40) {
                    StringBuilder append6 = result.append((char) (cValue + 51));
                } else {
                    throw FormatException.getFormatInstance();
                }
            }
            if (bits.available() <= 0) {
                return;
            }
        }
    }

    private static void parseTwoBytes(int firstByte, int secondByte, int[] iArr) {
        int[] result = iArr;
        int fullBitValue = ((firstByte << 8) + secondByte) - 1;
        int temp = fullBitValue / 1600;
        result[0] = temp;
        int fullBitValue2 = fullBitValue - (temp * 1600);
        int temp2 = fullBitValue2 / 40;
        result[1] = temp2;
        result[2] = fullBitValue2 - (temp2 * 40);
    }

    private static void decodeEdifactSegment(BitSource bitSource, StringBuilder sb) {
        BitSource bits = bitSource;
        StringBuilder result = sb;
        while (bits.available() > 16) {
            for (int i = 0; i < 4; i++) {
                int edifactValue = bits.readBits(6);
                if (edifactValue == 31) {
                    int bitsLeft = 8 - bits.getBitOffset();
                    if (bitsLeft != 8) {
                        int readBits = bits.readBits(bitsLeft);
                        return;
                    }
                    return;
                }
                if ((edifactValue & 32) == 0) {
                    edifactValue |= 64;
                }
                StringBuilder append = result.append((char) edifactValue);
            }
            if (bits.available() <= 0) {
                return;
            }
        }
    }

    private static void decodeBase256Segment(BitSource bitSource, StringBuilder sb, Collection<byte[]> collection) throws FormatException {
        int count;
        Throwable th;
        StringBuilder sb2;
        String str;
        BitSource bits = bitSource;
        StringBuilder result = sb;
        Collection<byte[]> byteSegments = collection;
        int codewordPosition = 1 + bits.getByteOffset();
        int i = codewordPosition;
        int codewordPosition2 = codewordPosition + 1;
        int d1 = unrandomize255State(bits.readBits(8), i);
        if (d1 == 0) {
            count = bits.available() / 8;
        } else if (d1 < 250) {
            count = d1;
        } else {
            int i2 = codewordPosition2;
            codewordPosition2++;
            count = (250 * (d1 - 249)) + unrandomize255State(bits.readBits(8), i2);
        }
        if (count < 0) {
            throw FormatException.getFormatInstance();
        }
        byte[] bytes = new byte[count];
        for (int i3 = 0; i3 < count; i3++) {
            if (bits.available() < 8) {
                throw FormatException.getFormatInstance();
            }
            int i4 = codewordPosition2;
            codewordPosition2++;
            bytes[i3] = (byte) unrandomize255State(bits.readBits(8), i4);
        }
        boolean add = byteSegments.add(bytes);
        StringBuilder sb3 = result;
        try {
            new String(bytes, "ISO8859_1");
            StringBuilder append = sb3.append(str);
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException uee = e;
            Throwable th2 = th;
            new StringBuilder();
            new IllegalStateException(sb2.append("Platform does not support required encoding: ").append(uee).toString());
            throw th2;
        }
    }

    private static int unrandomize255State(int randomizedBase256Codeword, int base256CodewordPosition) {
        int tempVariable = randomizedBase256Codeword - (((149 * base256CodewordPosition) % 255) + 1);
        return tempVariable >= 0 ? tempVariable : tempVariable + 256;
    }
}
