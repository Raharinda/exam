package com.google.zxing.datamatrix.detector;

import com.google.zxing.NotFoundException;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DetectorResult;
import com.google.zxing.common.GridSampler;
import com.google.zxing.common.detector.MathUtils;
import com.google.zxing.common.detector.WhiteRectangleDetector;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Detector {
    private final BitMatrix image;
    private final WhiteRectangleDetector rectangleDetector;

    public Detector(BitMatrix bitMatrix) throws NotFoundException {
        WhiteRectangleDetector whiteRectangleDetector;
        BitMatrix image2 = bitMatrix;
        this.image = image2;
        new WhiteRectangleDetector(image2);
        this.rectangleDetector = whiteRectangleDetector;
    }

    public DetectorResult detect() throws NotFoundException {
        List<ResultPointsAndTransitions> list;
        Comparator comparator;
        Map<ResultPoint, Integer> map;
        ResultPoint topRight;
        ResultPoint correctedTopRight;
        BitMatrix bits;
        DetectorResult detectorResult;
        ResultPoint[] cornerPoints = this.rectangleDetector.detect();
        ResultPoint pointA = cornerPoints[0];
        ResultPoint pointB = cornerPoints[1];
        ResultPoint pointC = cornerPoints[2];
        ResultPoint pointD = cornerPoints[3];
        new ArrayList<>(4);
        List<ResultPointsAndTransitions> transitions = list;
        boolean add = transitions.add(transitionsBetween(pointA, pointB));
        boolean add2 = transitions.add(transitionsBetween(pointA, pointC));
        boolean add3 = transitions.add(transitionsBetween(pointB, pointD));
        boolean add4 = transitions.add(transitionsBetween(pointC, pointD));
        new ResultPointsAndTransitionsComparator((AnonymousClass1) null);
        Collections.sort(transitions, comparator);
        ResultPointsAndTransitions lSideOne = transitions.get(0);
        ResultPointsAndTransitions lSideTwo = transitions.get(1);
        new HashMap<>();
        Map<ResultPoint, Integer> pointCount = map;
        increment(pointCount, lSideOne.getFrom());
        increment(pointCount, lSideOne.getTo());
        increment(pointCount, lSideTwo.getFrom());
        increment(pointCount, lSideTwo.getTo());
        ResultPoint maybeTopLeft = null;
        ResultPoint bottomLeft = null;
        ResultPoint maybeBottomRight = null;
        for (Map.Entry<ResultPoint, Integer> entry : pointCount.entrySet()) {
            ResultPoint point = entry.getKey();
            if (entry.getValue().intValue() == 2) {
                bottomLeft = point;
            } else if (maybeTopLeft == null) {
                maybeTopLeft = point;
            } else {
                maybeBottomRight = point;
            }
        }
        if (maybeTopLeft == null || bottomLeft == null || maybeBottomRight == null) {
            throw NotFoundException.getNotFoundInstance();
        }
        ResultPoint[] resultPointArr = new ResultPoint[3];
        resultPointArr[0] = maybeTopLeft;
        ResultPoint[] resultPointArr2 = resultPointArr;
        resultPointArr2[1] = bottomLeft;
        ResultPoint[] resultPointArr3 = resultPointArr2;
        resultPointArr3[2] = maybeBottomRight;
        ResultPoint[] corners = resultPointArr3;
        ResultPoint.orderBestPatterns(corners);
        ResultPoint bottomRight = corners[0];
        ResultPoint bottomLeft2 = corners[1];
        ResultPoint topLeft = corners[2];
        if (!pointCount.containsKey(pointA)) {
            topRight = pointA;
        } else if (!pointCount.containsKey(pointB)) {
            topRight = pointB;
        } else if (!pointCount.containsKey(pointC)) {
            topRight = pointC;
        } else {
            topRight = pointD;
        }
        int dimensionTop = transitionsBetween(topLeft, topRight).getTransitions();
        int dimensionRight = transitionsBetween(bottomRight, topRight).getTransitions();
        if ((dimensionTop & 1) == 1) {
            dimensionTop++;
        }
        int dimensionTop2 = dimensionTop + 2;
        if ((dimensionRight & 1) == 1) {
            dimensionRight++;
        }
        int dimensionRight2 = dimensionRight + 2;
        if (4 * dimensionTop2 >= 7 * dimensionRight2 || 4 * dimensionRight2 >= 7 * dimensionTop2) {
            ResultPoint correctedTopRight2 = correctTopRightRectangular(bottomLeft2, bottomRight, topLeft, topRight, dimensionTop2, dimensionRight2);
            if (correctedTopRight2 == null) {
                correctedTopRight2 = topRight;
            }
            int dimensionTop3 = transitionsBetween(topLeft, correctedTopRight).getTransitions();
            int dimensionRight3 = transitionsBetween(bottomRight, correctedTopRight).getTransitions();
            if ((dimensionTop3 & 1) == 1) {
                dimensionTop3++;
            }
            if ((dimensionRight3 & 1) == 1) {
                dimensionRight3++;
            }
            bits = sampleGrid(this.image, topLeft, bottomLeft2, bottomRight, correctedTopRight, dimensionTop3, dimensionRight3);
        } else {
            correctedTopRight = correctTopRight(bottomLeft2, bottomRight, topLeft, topRight, Math.min(dimensionRight2, dimensionTop2));
            if (correctedTopRight == null) {
                correctedTopRight = topRight;
            }
            int dimensionCorrected = Math.max(transitionsBetween(topLeft, correctedTopRight).getTransitions(), transitionsBetween(bottomRight, correctedTopRight).getTransitions()) + 1;
            if ((dimensionCorrected & 1) == 1) {
                dimensionCorrected++;
            }
            bits = sampleGrid(this.image, topLeft, bottomLeft2, bottomRight, correctedTopRight, dimensionCorrected, dimensionCorrected);
        }
        DetectorResult detectorResult2 = detectorResult;
        ResultPoint[] resultPointArr4 = new ResultPoint[4];
        resultPointArr4[0] = topLeft;
        ResultPoint[] resultPointArr5 = resultPointArr4;
        resultPointArr5[1] = bottomLeft2;
        ResultPoint[] resultPointArr6 = resultPointArr5;
        resultPointArr6[2] = bottomRight;
        ResultPoint[] resultPointArr7 = resultPointArr6;
        resultPointArr7[3] = correctedTopRight;
        new DetectorResult(bits, resultPointArr7);
        return detectorResult2;
    }

    private ResultPoint correctTopRightRectangular(ResultPoint resultPoint, ResultPoint resultPoint2, ResultPoint resultPoint3, ResultPoint resultPoint4, int i, int i2) {
        ResultPoint resultPoint5;
        ResultPoint resultPoint6;
        ResultPoint bottomLeft = resultPoint;
        ResultPoint bottomRight = resultPoint2;
        ResultPoint topLeft = resultPoint3;
        ResultPoint topRight = resultPoint4;
        int dimensionTop = i;
        int dimensionRight = i2;
        float corr = ((float) distance(bottomLeft, bottomRight)) / ((float) dimensionTop);
        int norm = distance(topLeft, topRight);
        new ResultPoint(topRight.getX() + (corr * ((topRight.getX() - topLeft.getX()) / ((float) norm))), topRight.getY() + (corr * ((topRight.getY() - topLeft.getY()) / ((float) norm))));
        ResultPoint c1 = resultPoint5;
        float corr2 = ((float) distance(bottomLeft, topLeft)) / ((float) dimensionRight);
        int norm2 = distance(bottomRight, topRight);
        new ResultPoint(topRight.getX() + (corr2 * ((topRight.getX() - bottomRight.getX()) / ((float) norm2))), topRight.getY() + (corr2 * ((topRight.getY() - bottomRight.getY()) / ((float) norm2))));
        ResultPoint c2 = resultPoint6;
        if (!isValid(c1)) {
            if (isValid(c2)) {
                return c2;
            }
            return null;
        } else if (!isValid(c2)) {
            return c1;
        } else {
            if (Math.abs(dimensionTop - transitionsBetween(topLeft, c1).getTransitions()) + Math.abs(dimensionRight - transitionsBetween(bottomRight, c1).getTransitions()) <= Math.abs(dimensionTop - transitionsBetween(topLeft, c2).getTransitions()) + Math.abs(dimensionRight - transitionsBetween(bottomRight, c2).getTransitions())) {
                return c1;
            }
            return c2;
        }
    }

    private ResultPoint correctTopRight(ResultPoint resultPoint, ResultPoint resultPoint2, ResultPoint resultPoint3, ResultPoint resultPoint4, int i) {
        ResultPoint resultPoint5;
        ResultPoint resultPoint6;
        ResultPoint bottomLeft = resultPoint;
        ResultPoint bottomRight = resultPoint2;
        ResultPoint topLeft = resultPoint3;
        ResultPoint topRight = resultPoint4;
        int dimension = i;
        float corr = ((float) distance(bottomLeft, bottomRight)) / ((float) dimension);
        int norm = distance(topLeft, topRight);
        new ResultPoint(topRight.getX() + (corr * ((topRight.getX() - topLeft.getX()) / ((float) norm))), topRight.getY() + (corr * ((topRight.getY() - topLeft.getY()) / ((float) norm))));
        ResultPoint c1 = resultPoint5;
        float corr2 = ((float) distance(bottomLeft, topLeft)) / ((float) dimension);
        int norm2 = distance(bottomRight, topRight);
        new ResultPoint(topRight.getX() + (corr2 * ((topRight.getX() - bottomRight.getX()) / ((float) norm2))), topRight.getY() + (corr2 * ((topRight.getY() - bottomRight.getY()) / ((float) norm2))));
        ResultPoint c2 = resultPoint6;
        if (!isValid(c1)) {
            if (isValid(c2)) {
                return c2;
            }
            return null;
        } else if (!isValid(c2)) {
            return c1;
        } else {
            return Math.abs(transitionsBetween(topLeft, c1).getTransitions() - transitionsBetween(bottomRight, c1).getTransitions()) <= Math.abs(transitionsBetween(topLeft, c2).getTransitions() - transitionsBetween(bottomRight, c2).getTransitions()) ? c1 : c2;
        }
    }

    private boolean isValid(ResultPoint resultPoint) {
        ResultPoint p = resultPoint;
        return p.getX() >= 0.0f && p.getX() < ((float) this.image.getWidth()) && p.getY() > 0.0f && p.getY() < ((float) this.image.getHeight());
    }

    private static int distance(ResultPoint a, ResultPoint b) {
        return MathUtils.round(ResultPoint.distance(a, b));
    }

    private static void increment(Map<ResultPoint, Integer> map, ResultPoint resultPoint) {
        Map<ResultPoint, Integer> table = map;
        ResultPoint key = resultPoint;
        Integer value = table.get(key);
        Integer put = table.put(key, Integer.valueOf(value == null ? 1 : value.intValue() + 1));
    }

    private static BitMatrix sampleGrid(BitMatrix image2, ResultPoint resultPoint, ResultPoint resultPoint2, ResultPoint resultPoint3, ResultPoint resultPoint4, int i, int i2) throws NotFoundException {
        ResultPoint topLeft = resultPoint;
        ResultPoint bottomLeft = resultPoint2;
        ResultPoint bottomRight = resultPoint3;
        ResultPoint topRight = resultPoint4;
        int dimensionX = i;
        int dimensionY = i2;
        return GridSampler.getInstance().sampleGrid(image2, dimensionX, dimensionY, 0.5f, 0.5f, ((float) dimensionX) - 0.5f, 0.5f, ((float) dimensionX) - 0.5f, ((float) dimensionY) - 0.5f, 0.5f, ((float) dimensionY) - 0.5f, topLeft.getX(), topLeft.getY(), topRight.getX(), topRight.getY(), bottomRight.getX(), bottomRight.getY(), bottomLeft.getX(), bottomLeft.getY());
    }

    private ResultPointsAndTransitions transitionsBetween(ResultPoint resultPoint, ResultPoint resultPoint2) {
        ResultPointsAndTransitions resultPointsAndTransitions;
        ResultPoint from = resultPoint;
        ResultPoint to = resultPoint2;
        int fromX = (int) from.getX();
        int fromY = (int) from.getY();
        int toX = (int) to.getX();
        int toY = (int) to.getY();
        boolean steep = Math.abs(toY - fromY) > Math.abs(toX - fromX);
        if (steep) {
            int temp = fromX;
            fromX = fromY;
            fromY = temp;
            int temp2 = toX;
            toX = toY;
            toY = temp2;
        }
        int dx = Math.abs(toX - fromX);
        int dy = Math.abs(toY - fromY);
        int error = (-dx) >> 1;
        int ystep = fromY < toY ? 1 : -1;
        int xstep = fromX < toX ? 1 : -1;
        int transitions = 0;
        boolean inBlack = this.image.get(steep ? fromY : fromX, steep ? fromX : fromY);
        int y = fromY;
        for (int x = fromX; x != toX; x += xstep) {
            boolean isBlack = this.image.get(steep ? y : x, steep ? x : y);
            if (isBlack != inBlack) {
                transitions++;
                inBlack = isBlack;
            }
            error += dy;
            if (error > 0) {
                if (y == toY) {
                    break;
                }
                y += ystep;
                error -= dx;
            }
        }
        new ResultPointsAndTransitions(from, to, transitions, (AnonymousClass1) null);
        return resultPointsAndTransitions;
    }

    private static final class ResultPointsAndTransitions {
        private final ResultPoint from;
        private final ResultPoint to;
        private final int transitions;

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ ResultPointsAndTransitions(ResultPoint x0, ResultPoint x1, int x2, AnonymousClass1 r13) {
            this(x0, x1, x2);
            AnonymousClass1 r4 = r13;
        }

        private ResultPointsAndTransitions(ResultPoint from2, ResultPoint to2, int transitions2) {
            this.from = from2;
            this.to = to2;
            this.transitions = transitions2;
        }

        /* access modifiers changed from: package-private */
        public ResultPoint getFrom() {
            return this.from;
        }

        /* access modifiers changed from: package-private */
        public ResultPoint getTo() {
            return this.to;
        }

        public int getTransitions() {
            return this.transitions;
        }

        public String toString() {
            StringBuilder sb;
            new StringBuilder();
            return sb.append(this.from).append("/").append(this.to).append('/').append(this.transitions).toString();
        }
    }

    private static final class ResultPointsAndTransitionsComparator implements Comparator<ResultPointsAndTransitions>, Serializable {
        private ResultPointsAndTransitionsComparator() {
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ ResultPointsAndTransitionsComparator(AnonymousClass1 r4) {
            this();
            AnonymousClass1 r1 = r4;
        }

        public int compare(ResultPointsAndTransitions o1, ResultPointsAndTransitions o2) {
            return o1.getTransitions() - o2.getTransitions();
        }
    }
}
