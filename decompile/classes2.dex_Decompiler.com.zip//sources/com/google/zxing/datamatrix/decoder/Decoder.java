package com.google.zxing.datamatrix.decoder;

import com.google.zxing.ChecksumException;
import com.google.zxing.FormatException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.common.reedsolomon.GenericGF;
import com.google.zxing.common.reedsolomon.ReedSolomonDecoder;
import com.google.zxing.common.reedsolomon.ReedSolomonException;

public final class Decoder {
    private final ReedSolomonDecoder rsDecoder;

    public Decoder() {
        ReedSolomonDecoder reedSolomonDecoder;
        new ReedSolomonDecoder(GenericGF.DATA_MATRIX_FIELD_256);
        this.rsDecoder = reedSolomonDecoder;
    }

    public DecoderResult decode(boolean[][] zArr) throws FormatException, ChecksumException {
        BitMatrix bitMatrix;
        boolean[][] image = zArr;
        int dimension = image.length;
        new BitMatrix(dimension);
        BitMatrix bits = bitMatrix;
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                if (image[i][j]) {
                    bits.set(j, i);
                }
            }
        }
        return decode(bits);
    }

    public DecoderResult decode(BitMatrix bits) throws FormatException, ChecksumException {
        BitMatrixParser bitMatrixParser;
        new BitMatrixParser(bits);
        BitMatrixParser parser = bitMatrixParser;
        DataBlock[] dataBlocks = DataBlock.getDataBlocks(parser.readCodewords(), parser.getVersion());
        int dataBlocksCount = dataBlocks.length;
        int totalBytes = 0;
        DataBlock[] arr$ = dataBlocks;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            totalBytes += arr$[i$].getNumDataCodewords();
        }
        byte[] resultBytes = new byte[totalBytes];
        for (int j = 0; j < dataBlocksCount; j++) {
            DataBlock dataBlock = dataBlocks[j];
            byte[] codewordBytes = dataBlock.getCodewords();
            int numDataCodewords = dataBlock.getNumDataCodewords();
            correctErrors(codewordBytes, numDataCodewords);
            for (int i = 0; i < numDataCodewords; i++) {
                resultBytes[(i * dataBlocksCount) + j] = codewordBytes[i];
            }
        }
        return DecodedBitStreamParser.decode(resultBytes);
    }

    private void correctErrors(byte[] bArr, int i) throws ChecksumException {
        byte[] codewordBytes = bArr;
        int numDataCodewords = i;
        int numCodewords = codewordBytes.length;
        int[] codewordsInts = new int[numCodewords];
        for (int i2 = 0; i2 < numCodewords; i2++) {
            codewordsInts[i2] = codewordBytes[i2] & 255;
        }
        try {
            this.rsDecoder.decode(codewordsInts, codewordBytes.length - numDataCodewords);
            for (int i3 = 0; i3 < numDataCodewords; i3++) {
                codewordBytes[i3] = (byte) codewordsInts[i3];
            }
        } catch (ReedSolomonException e) {
            ReedSolomonException reedSolomonException = e;
            throw ChecksumException.getChecksumInstance();
        }
    }
}
