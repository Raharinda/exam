package com.google.zxing.datamatrix.decoder;

import com.google.zxing.datamatrix.decoder.Version;

final class DataBlock {
    private final byte[] codewords;
    private final int numDataCodewords;

    private DataBlock(int numDataCodewords2, byte[] codewords2) {
        this.numDataCodewords = numDataCodewords2;
        this.codewords = codewords2;
    }

    static DataBlock[] getDataBlocks(byte[] bArr, Version version) {
        Throwable th;
        DataBlock dataBlock;
        byte[] rawCodewords = bArr;
        Version version2 = version;
        Version.ECBlocks ecBlocks = version2.getECBlocks();
        int totalBlocks = 0;
        Version.ECB[] ecBlockArray = ecBlocks.getECBlocks();
        Version.ECB[] arr$ = ecBlockArray;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            totalBlocks += arr$[i$].getCount();
        }
        DataBlock[] result = new DataBlock[totalBlocks];
        int numResultBlocks = 0;
        Version.ECB[] arr$2 = ecBlockArray;
        int len$2 = arr$2.length;
        for (int i$2 = 0; i$2 < len$2; i$2++) {
            Version.ECB ecBlock = arr$2[i$2];
            for (int i = 0; i < ecBlock.getCount(); i++) {
                int numDataCodewords2 = ecBlock.getDataCodewords();
                int i2 = numResultBlocks;
                numResultBlocks++;
                new DataBlock(numDataCodewords2, new byte[(ecBlocks.getECCodewords() + numDataCodewords2)]);
                result[i2] = dataBlock;
            }
        }
        int longerBlocksNumDataCodewords = result[0].codewords.length - ecBlocks.getECCodewords();
        int shorterBlocksNumDataCodewords = longerBlocksNumDataCodewords - 1;
        int rawCodewordsOffset = 0;
        for (int i3 = 0; i3 < shorterBlocksNumDataCodewords; i3++) {
            for (int j = 0; j < numResultBlocks; j++) {
                int i4 = rawCodewordsOffset;
                rawCodewordsOffset++;
                result[j].codewords[i3] = rawCodewords[i4];
            }
        }
        boolean specialVersion = version2.getVersionNumber() == 24;
        int numLongerBlocks = specialVersion ? 8 : numResultBlocks;
        for (int j2 = 0; j2 < numLongerBlocks; j2++) {
            int i5 = rawCodewordsOffset;
            rawCodewordsOffset++;
            result[j2].codewords[longerBlocksNumDataCodewords - 1] = rawCodewords[i5];
        }
        int max = result[0].codewords.length;
        for (int i6 = longerBlocksNumDataCodewords; i6 < max; i6++) {
            int j3 = 0;
            while (j3 < numResultBlocks) {
                int i7 = rawCodewordsOffset;
                rawCodewordsOffset++;
                result[j3].codewords[(!specialVersion || j3 <= 7) ? i6 : i6 - 1] = rawCodewords[i7];
                j3++;
            }
        }
        if (rawCodewordsOffset == rawCodewords.length) {
            return result;
        }
        Throwable th2 = th;
        new IllegalArgumentException();
        throw th2;
    }

    /* access modifiers changed from: package-private */
    public int getNumDataCodewords() {
        return this.numDataCodewords;
    }

    /* access modifiers changed from: package-private */
    public byte[] getCodewords() {
        return this.codewords;
    }
}
