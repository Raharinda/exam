package com.google.zxing.aztec;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.Reader;
import com.google.zxing.Result;
import com.google.zxing.ResultMetadataType;
import com.google.zxing.ResultPoint;
import com.google.zxing.ResultPointCallback;
import com.google.zxing.aztec.decoder.Decoder;
import com.google.zxing.aztec.detector.Detector;
import com.google.zxing.common.DecoderResult;
import java.util.List;
import java.util.Map;

public final class AztecReader implements Reader {
    public AztecReader() {
    }

    public Result decode(BinaryBitmap image) throws NotFoundException, FormatException {
        return decode(image, (Map<DecodeHintType, ?>) null);
    }

    public Result decode(BinaryBitmap image, Map<DecodeHintType, ?> map) throws NotFoundException, FormatException {
        Detector detector;
        Decoder decoder;
        Result result;
        ResultPointCallback rpcb;
        Map<DecodeHintType, ?> hints = map;
        new Detector(image.getBlackMatrix());
        AztecDetectorResult detectorResult = detector.detect();
        ResultPoint[] points = detectorResult.getPoints();
        if (!(hints == null || (rpcb = (ResultPointCallback) hints.get(DecodeHintType.NEED_RESULT_POINT_CALLBACK)) == null)) {
            ResultPoint[] arr$ = points;
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                rpcb.foundPossibleResultPoint(arr$[i$]);
            }
        }
        new Decoder();
        DecoderResult decoderResult = decoder.decode(detectorResult);
        new Result(decoderResult.getText(), decoderResult.getRawBytes(), points, BarcodeFormat.AZTEC);
        Result result2 = result;
        List<byte[]> byteSegments = decoderResult.getByteSegments();
        if (byteSegments != null) {
            result2.putMetadata(ResultMetadataType.BYTE_SEGMENTS, byteSegments);
        }
        String ecLevel = decoderResult.getECLevel();
        if (ecLevel != null) {
            result2.putMetadata(ResultMetadataType.ERROR_CORRECTION_LEVEL, ecLevel);
        }
        return result2;
    }

    public void reset() {
    }
}
