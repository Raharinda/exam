package com.google.zxing.aztec;

import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DetectorResult;

public final class AztecDetectorResult extends DetectorResult {
    private final boolean compact;
    private final int nbDatablocks;
    private final int nbLayers;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AztecDetectorResult(BitMatrix bits, ResultPoint[] points, boolean compact2, int nbDatablocks2, int nbLayers2) {
        super(bits, points);
        this.compact = compact2;
        this.nbDatablocks = nbDatablocks2;
        this.nbLayers = nbLayers2;
    }

    public int getNbLayers() {
        return this.nbLayers;
    }

    public int getNbDatablocks() {
        return this.nbDatablocks;
    }

    public boolean isCompact() {
        return this.compact;
    }
}
