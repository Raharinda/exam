package com.google.zxing.aztec.decoder;

import com.google.zxing.FormatException;
import com.google.zxing.aztec.AztecDetectorResult;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DecoderResult;
import java.util.List;
import org.jose4j.base64url.internal.apache.commons.codec.binary.BaseNCodec;
import org.jose4j.jwk.EllipticCurveJsonWebKey;
import org.jose4j.jwk.OctetSequenceJsonWebKey;
import org.jose4j.jwk.RsaJsonWebKey;
import org.slf4j.Marker;

public final class Decoder {
    private static final String[] DIGIT_TABLE;
    private static final String[] LOWER_TABLE;
    private static final String[] MIXED_TABLE;
    private static final int[] NB_BITS = {0, 128, 288, 480, 704, 960, 1248, 1568, 1920, 2304, 2720, 3168, 3648, 4160, 4704, 5280, 5888, 6528, 7200, 7904, 8640, 9408, 10208, 11040, 11904, 12800, 13728, 14688, 15680, 16704, 17760, 18848, 19968};
    private static final int[] NB_BITS_COMPACT = {0, 104, 240, 408, 608};
    private static final int[] NB_DATABLOCK = {0, 21, 48, 60, 88, 120, 156, 196, 240, 230, 272, 316, 364, 416, 470, 528, 588, 652, 720, 790, 864, 940, 1020, 920, 992, 1066, 1144, 1224, 1306, 1392, 1480, 1570, 1664};
    private static final int[] NB_DATABLOCK_COMPACT = {0, 17, 40, 51, 76};
    private static final String[] PUNCT_TABLE;
    private static final String[] UPPER_TABLE;
    private int codewordSize;
    private AztecDetectorResult ddata;
    private int invertedBitCount;
    private int numCodewords;

    private enum Table {
    }

    public Decoder() {
    }

    static {
        String[] strArr = new String[32];
        strArr[0] = "CTRL_PS";
        String[] strArr2 = strArr;
        strArr2[1] = " ";
        String[] strArr3 = strArr2;
        strArr3[2] = "A";
        String[] strArr4 = strArr3;
        strArr4[3] = "B";
        String[] strArr5 = strArr4;
        strArr5[4] = "C";
        String[] strArr6 = strArr5;
        strArr6[5] = "D";
        String[] strArr7 = strArr6;
        strArr7[6] = "E";
        String[] strArr8 = strArr7;
        strArr8[7] = "F";
        String[] strArr9 = strArr8;
        strArr9[8] = "G";
        String[] strArr10 = strArr9;
        strArr10[9] = "H";
        String[] strArr11 = strArr10;
        strArr11[10] = "I";
        String[] strArr12 = strArr11;
        strArr12[11] = "J";
        String[] strArr13 = strArr12;
        strArr13[12] = "K";
        String[] strArr14 = strArr13;
        strArr14[13] = "L";
        String[] strArr15 = strArr14;
        strArr15[14] = "M";
        String[] strArr16 = strArr15;
        strArr16[15] = "N";
        String[] strArr17 = strArr16;
        strArr17[16] = "O";
        String[] strArr18 = strArr17;
        strArr18[17] = "P";
        String[] strArr19 = strArr18;
        strArr19[18] = "Q";
        String[] strArr20 = strArr19;
        strArr20[19] = "R";
        String[] strArr21 = strArr20;
        strArr21[20] = "S";
        String[] strArr22 = strArr21;
        strArr22[21] = "T";
        String[] strArr23 = strArr22;
        strArr23[22] = "U";
        String[] strArr24 = strArr23;
        strArr24[23] = "V";
        String[] strArr25 = strArr24;
        strArr25[24] = "W";
        String[] strArr26 = strArr25;
        strArr26[25] = "X";
        String[] strArr27 = strArr26;
        strArr27[26] = "Y";
        String[] strArr28 = strArr27;
        strArr28[27] = "Z";
        String[] strArr29 = strArr28;
        strArr29[28] = "CTRL_LL";
        String[] strArr30 = strArr29;
        strArr30[29] = "CTRL_ML";
        String[] strArr31 = strArr30;
        strArr31[30] = "CTRL_DL";
        String[] strArr32 = strArr31;
        strArr32[31] = "CTRL_BS";
        UPPER_TABLE = strArr32;
        String[] strArr33 = new String[32];
        strArr33[0] = "CTRL_PS";
        String[] strArr34 = strArr33;
        strArr34[1] = " ";
        String[] strArr35 = strArr34;
        strArr35[2] = "a";
        String[] strArr36 = strArr35;
        strArr36[3] = "b";
        String[] strArr37 = strArr36;
        strArr37[4] = "c";
        String[] strArr38 = strArr37;
        strArr38[5] = "d";
        String[] strArr39 = strArr38;
        strArr39[6] = RsaJsonWebKey.EXPONENT_MEMBER_NAME;
        String[] strArr40 = strArr39;
        strArr40[7] = "f";
        String[] strArr41 = strArr40;
        strArr41[8] = "g";
        String[] strArr42 = strArr41;
        strArr42[9] = "h";
        String[] strArr43 = strArr42;
        strArr43[10] = "i";
        String[] strArr44 = strArr43;
        strArr44[11] = "j";
        String[] strArr45 = strArr44;
        strArr45[12] = OctetSequenceJsonWebKey.KEY_VALUE_MEMBER_NAME;
        String[] strArr46 = strArr45;
        strArr46[13] = "l";
        String[] strArr47 = strArr46;
        strArr47[14] = "m";
        String[] strArr48 = strArr47;
        strArr48[15] = RsaJsonWebKey.MODULUS_MEMBER_NAME;
        String[] strArr49 = strArr48;
        strArr49[16] = "o";
        String[] strArr50 = strArr49;
        strArr50[17] = RsaJsonWebKey.FIRST_PRIME_FACTOR_MEMBER_NAME;
        String[] strArr51 = strArr50;
        strArr51[18] = RsaJsonWebKey.SECOND_PRIME_FACTOR_MEMBER_NAME;
        String[] strArr52 = strArr51;
        strArr52[19] = RsaJsonWebKey.PRIME_FACTOR_OTHER_MEMBER_NAME;
        String[] strArr53 = strArr52;
        strArr53[20] = "s";
        String[] strArr54 = strArr53;
        strArr54[21] = RsaJsonWebKey.FACTOR_CRT_COEFFICIENT;
        String[] strArr55 = strArr54;
        strArr55[22] = "u";
        String[] strArr56 = strArr55;
        strArr56[23] = "v";
        String[] strArr57 = strArr56;
        strArr57[24] = "w";
        String[] strArr58 = strArr57;
        strArr58[25] = EllipticCurveJsonWebKey.X_MEMBER_NAME;
        String[] strArr59 = strArr58;
        strArr59[26] = EllipticCurveJsonWebKey.Y_MEMBER_NAME;
        String[] strArr60 = strArr59;
        strArr60[27] = "z";
        String[] strArr61 = strArr60;
        strArr61[28] = "CTRL_US";
        String[] strArr62 = strArr61;
        strArr62[29] = "CTRL_ML";
        String[] strArr63 = strArr62;
        strArr63[30] = "CTRL_DL";
        String[] strArr64 = strArr63;
        strArr64[31] = "CTRL_BS";
        LOWER_TABLE = strArr64;
        String[] strArr65 = new String[32];
        strArr65[0] = "CTRL_PS";
        String[] strArr66 = strArr65;
        strArr66[1] = " ";
        String[] strArr67 = strArr66;
        strArr67[2] = "\u0001";
        String[] strArr68 = strArr67;
        strArr68[3] = "\u0002";
        String[] strArr69 = strArr68;
        strArr69[4] = "\u0003";
        String[] strArr70 = strArr69;
        strArr70[5] = "\u0004";
        String[] strArr71 = strArr70;
        strArr71[6] = "\u0005";
        String[] strArr72 = strArr71;
        strArr72[7] = "\u0006";
        String[] strArr73 = strArr72;
        strArr73[8] = "\u0007";
        String[] strArr74 = strArr73;
        strArr74[9] = "\b";
        String[] strArr75 = strArr74;
        strArr75[10] = "\t";
        String[] strArr76 = strArr75;
        strArr76[11] = "\n";
        String[] strArr77 = strArr76;
        strArr77[12] = "\u000b";
        String[] strArr78 = strArr77;
        strArr78[13] = "\f";
        String[] strArr79 = strArr78;
        strArr79[14] = "\r";
        String[] strArr80 = strArr79;
        strArr80[15] = "\u001b";
        String[] strArr81 = strArr80;
        strArr81[16] = "\u001c";
        String[] strArr82 = strArr81;
        strArr82[17] = "\u001d";
        String[] strArr83 = strArr82;
        strArr83[18] = "\u001e";
        String[] strArr84 = strArr83;
        strArr84[19] = "\u001f";
        String[] strArr85 = strArr84;
        strArr85[20] = "@";
        String[] strArr86 = strArr85;
        strArr86[21] = "\\";
        String[] strArr87 = strArr86;
        strArr87[22] = "^";
        String[] strArr88 = strArr87;
        strArr88[23] = "_";
        String[] strArr89 = strArr88;
        strArr89[24] = "`";
        String[] strArr90 = strArr89;
        strArr90[25] = "|";
        String[] strArr91 = strArr90;
        strArr91[26] = "~";
        String[] strArr92 = strArr91;
        strArr92[27] = "";
        String[] strArr93 = strArr92;
        strArr93[28] = "CTRL_LL";
        String[] strArr94 = strArr93;
        strArr94[29] = "CTRL_UL";
        String[] strArr95 = strArr94;
        strArr95[30] = "CTRL_PL";
        String[] strArr96 = strArr95;
        strArr96[31] = "CTRL_BS";
        MIXED_TABLE = strArr96;
        String[] strArr97 = new String[32];
        strArr97[0] = "";
        String[] strArr98 = strArr97;
        strArr98[1] = "\r";
        String[] strArr99 = strArr98;
        strArr99[2] = "\r\n";
        String[] strArr100 = strArr99;
        strArr100[3] = ". ";
        String[] strArr101 = strArr100;
        strArr101[4] = ", ";
        String[] strArr102 = strArr101;
        strArr102[5] = ": ";
        String[] strArr103 = strArr102;
        strArr103[6] = "!";
        String[] strArr104 = strArr103;
        strArr104[7] = "\"";
        String[] strArr105 = strArr104;
        strArr105[8] = "#";
        String[] strArr106 = strArr105;
        strArr106[9] = "$";
        String[] strArr107 = strArr106;
        strArr107[10] = "%";
        String[] strArr108 = strArr107;
        strArr108[11] = "&";
        String[] strArr109 = strArr108;
        strArr109[12] = "'";
        String[] strArr110 = strArr109;
        strArr110[13] = "(";
        String[] strArr111 = strArr110;
        strArr111[14] = ")";
        String[] strArr112 = strArr111;
        strArr112[15] = Marker.ANY_MARKER;
        String[] strArr113 = strArr112;
        strArr113[16] = Marker.ANY_NON_NULL_MARKER;
        String[] strArr114 = strArr113;
        strArr114[17] = ",";
        String[] strArr115 = strArr114;
        strArr115[18] = "-";
        String[] strArr116 = strArr115;
        strArr116[19] = ".";
        String[] strArr117 = strArr116;
        strArr117[20] = "/";
        String[] strArr118 = strArr117;
        strArr118[21] = ":";
        String[] strArr119 = strArr118;
        strArr119[22] = ";";
        String[] strArr120 = strArr119;
        strArr120[23] = "<";
        String[] strArr121 = strArr120;
        strArr121[24] = "=";
        String[] strArr122 = strArr121;
        strArr122[25] = ">";
        String[] strArr123 = strArr122;
        strArr123[26] = "?";
        String[] strArr124 = strArr123;
        strArr124[27] = "[";
        String[] strArr125 = strArr124;
        strArr125[28] = "]";
        String[] strArr126 = strArr125;
        strArr126[29] = "{";
        String[] strArr127 = strArr126;
        strArr127[30] = "}";
        String[] strArr128 = strArr127;
        strArr128[31] = "CTRL_UL";
        PUNCT_TABLE = strArr128;
        String[] strArr129 = new String[16];
        strArr129[0] = "CTRL_PS";
        String[] strArr130 = strArr129;
        strArr130[1] = " ";
        String[] strArr131 = strArr130;
        strArr131[2] = "0";
        String[] strArr132 = strArr131;
        strArr132[3] = "1";
        String[] strArr133 = strArr132;
        strArr133[4] = "2";
        String[] strArr134 = strArr133;
        strArr134[5] = "3";
        String[] strArr135 = strArr134;
        strArr135[6] = "4";
        String[] strArr136 = strArr135;
        strArr136[7] = "5";
        String[] strArr137 = strArr136;
        strArr137[8] = "6";
        String[] strArr138 = strArr137;
        strArr138[9] = "7";
        String[] strArr139 = strArr138;
        strArr139[10] = "8";
        String[] strArr140 = strArr139;
        strArr140[11] = "9";
        String[] strArr141 = strArr140;
        strArr141[12] = ",";
        String[] strArr142 = strArr141;
        strArr142[13] = ".";
        String[] strArr143 = strArr142;
        strArr143[14] = "CTRL_UL";
        String[] strArr144 = strArr143;
        strArr144[15] = "CTRL_US";
        DIGIT_TABLE = strArr144;
    }

    public DecoderResult decode(AztecDetectorResult aztecDetectorResult) throws FormatException {
        DecoderResult decoderResult;
        AztecDetectorResult detectorResult = aztecDetectorResult;
        this.ddata = detectorResult;
        BitMatrix matrix = detectorResult.getBits();
        if (!this.ddata.isCompact()) {
            matrix = removeDashedLines(this.ddata.getBits());
        }
        new DecoderResult((byte[]) null, getEncodedData(correctBits(extractBits(matrix))), (List<byte[]>) null, (String) null);
        return decoderResult;
    }

    private String getEncodedData(boolean[] zArr) throws FormatException {
        StringBuilder sb;
        boolean[] correctedBits = zArr;
        int endIndex = (this.codewordSize * this.ddata.getNbDatablocks()) - this.invertedBitCount;
        if (endIndex > correctedBits.length) {
            throw FormatException.getFormatInstance();
        }
        Table lastTable = Table.UPPER;
        Table table = Table.UPPER;
        int startIndex = 0;
        new StringBuilder(20);
        StringBuilder result = sb;
        boolean end = false;
        boolean shift = false;
        boolean switchShift = false;
        boolean binaryShift = false;
        while (!end) {
            if (shift) {
                switchShift = true;
            } else {
                lastTable = table;
            }
            if (binaryShift) {
                if (endIndex - startIndex < 5) {
                    break;
                }
                int length = readCode(correctedBits, startIndex, 5);
                startIndex += 5;
                if (length == 0) {
                    if (endIndex - startIndex < 11) {
                        break;
                    }
                    length = readCode(correctedBits, startIndex, 11) + 31;
                    startIndex += 11;
                }
                int charCount = 0;
                while (true) {
                    if (charCount >= length) {
                        break;
                    } else if (endIndex - startIndex < 8) {
                        end = true;
                        break;
                    } else {
                        StringBuilder append = result.append((char) readCode(correctedBits, startIndex, 8));
                        startIndex += 8;
                        charCount++;
                    }
                }
                binaryShift = false;
            } else if (table != Table.BINARY) {
                int size = 5;
                if (table == Table.DIGIT) {
                    size = 4;
                }
                if (endIndex - startIndex < size) {
                    break;
                }
                int code = readCode(correctedBits, startIndex, size);
                startIndex += size;
                String str = getCharacter(table, code);
                if (str.startsWith("CTRL_")) {
                    table = getTable(str.charAt(5));
                    if (str.charAt(6) == 'S') {
                        shift = true;
                        if (str.charAt(5) == 'B') {
                            binaryShift = true;
                        }
                    }
                } else {
                    StringBuilder append2 = result.append(str);
                }
            } else if (endIndex - startIndex < 8) {
                break;
            } else {
                int code2 = readCode(correctedBits, startIndex, 8);
                startIndex += 8;
                StringBuilder append3 = result.append((char) code2);
            }
            if (switchShift) {
                table = lastTable;
                shift = false;
                switchShift = false;
            }
        }
        return result.toString();
    }

    private static Table getTable(char t) {
        switch (t) {
            case 'B':
                return Table.BINARY;
            case 'D':
                return Table.DIGIT;
            case BaseNCodec.MIME_CHUNK_SIZE /*76*/:
                return Table.LOWER;
            case 'M':
                return Table.MIXED;
            case 'P':
                return Table.PUNCT;
            default:
                return Table.UPPER;
        }
    }

    private static String getCharacter(Table table, int i) {
        int code = i;
        switch (table) {
            case UPPER:
                return UPPER_TABLE[code];
            case LOWER:
                return LOWER_TABLE[code];
            case MIXED:
                return MIXED_TABLE[code];
            case PUNCT:
                return PUNCT_TABLE[code];
            case DIGIT:
                return DIGIT_TABLE[code];
            default:
                return "";
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:53:0x0229, code lost:
        r9 = r9 + 1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean[] correctBits(boolean[] r22) throws com.google.zxing.FormatException {
        /*
            r21 = this;
            r1 = r21
            r2 = r22
            r15 = r1
            com.google.zxing.aztec.AztecDetectorResult r15 = r15.ddata
            int r15 = r15.getNbLayers()
            r16 = 2
            r0 = r16
            if (r15 > r0) goto L_0x00cf
            r15 = r1
            r16 = 6
            r0 = r16
            r15.codewordSize = r0
            com.google.zxing.common.reedsolomon.GenericGF r15 = com.google.zxing.common.reedsolomon.GenericGF.AZTEC_DATA_6
            r3 = r15
        L_0x001b:
            r15 = r1
            com.google.zxing.aztec.AztecDetectorResult r15 = r15.ddata
            int r15 = r15.getNbDatablocks()
            r4 = r15
            r15 = r1
            com.google.zxing.aztec.AztecDetectorResult r15 = r15.ddata
            boolean r15 = r15.isCompact()
            if (r15 == 0) goto L_0x010d
            int[] r15 = NB_BITS_COMPACT
            r16 = r1
            r0 = r16
            com.google.zxing.aztec.AztecDetectorResult r0 = r0.ddata
            r16 = r0
            int r16 = r16.getNbLayers()
            r15 = r15[r16]
            r16 = r1
            r0 = r16
            int r0 = r0.numCodewords
            r16 = r0
            r17 = r1
            r0 = r17
            int r0 = r0.codewordSize
            r17 = r0
            int r16 = r16 * r17
            int r15 = r15 - r16
            r6 = r15
            int[] r15 = NB_DATABLOCK_COMPACT
            r16 = r1
            r0 = r16
            com.google.zxing.aztec.AztecDetectorResult r0 = r0.ddata
            r16 = r0
            int r16 = r16.getNbLayers()
            r15 = r15[r16]
            r16 = r4
            int r15 = r15 - r16
            r5 = r15
        L_0x0066:
            r15 = r1
            int r15 = r15.numCodewords
            int[] r15 = new int[r15]
            r7 = r15
            r15 = 0
            r8 = r15
        L_0x006e:
            r15 = r8
            r16 = r1
            r0 = r16
            int r0 = r0.numCodewords
            r16 = r0
            r0 = r16
            if (r15 >= r0) goto L_0x014d
            r15 = 1
            r9 = r15
            r15 = 1
            r10 = r15
        L_0x007f:
            r15 = r10
            r16 = r1
            r0 = r16
            int r0 = r0.codewordSize
            r16 = r0
            r0 = r16
            if (r15 > r0) goto L_0x0149
            r15 = r2
            r16 = r1
            r0 = r16
            int r0 = r0.codewordSize
            r16 = r0
            r17 = r8
            int r16 = r16 * r17
            r17 = r1
            r0 = r17
            int r0 = r0.codewordSize
            r17 = r0
            int r16 = r16 + r17
            r17 = r10
            int r16 = r16 - r17
            r17 = r6
            int r16 = r16 + r17
            boolean r15 = r15[r16]
            if (r15 == 0) goto L_0x00c6
            r15 = r7
            r16 = r8
            r19 = r15
            r20 = r16
            r15 = r19
            r16 = r20
            r17 = r19
            r18 = r20
            r17 = r17[r18]
            r18 = r9
            int r17 = r17 + r18
            r15[r16] = r17
        L_0x00c6:
            r15 = r9
            r16 = 1
            int r15 = r15 << 1
            r9 = r15
            int r10 = r10 + 1
            goto L_0x007f
        L_0x00cf:
            r15 = r1
            com.google.zxing.aztec.AztecDetectorResult r15 = r15.ddata
            int r15 = r15.getNbLayers()
            r16 = 8
            r0 = r16
            if (r15 > r0) goto L_0x00e8
            r15 = r1
            r16 = 8
            r0 = r16
            r15.codewordSize = r0
            com.google.zxing.common.reedsolomon.GenericGF r15 = com.google.zxing.common.reedsolomon.GenericGF.AZTEC_DATA_8
            r3 = r15
            goto L_0x001b
        L_0x00e8:
            r15 = r1
            com.google.zxing.aztec.AztecDetectorResult r15 = r15.ddata
            int r15 = r15.getNbLayers()
            r16 = 22
            r0 = r16
            if (r15 > r0) goto L_0x0101
            r15 = r1
            r16 = 10
            r0 = r16
            r15.codewordSize = r0
            com.google.zxing.common.reedsolomon.GenericGF r15 = com.google.zxing.common.reedsolomon.GenericGF.AZTEC_DATA_10
            r3 = r15
            goto L_0x001b
        L_0x0101:
            r15 = r1
            r16 = 12
            r0 = r16
            r15.codewordSize = r0
            com.google.zxing.common.reedsolomon.GenericGF r15 = com.google.zxing.common.reedsolomon.GenericGF.AZTEC_DATA_12
            r3 = r15
            goto L_0x001b
        L_0x010d:
            int[] r15 = NB_BITS
            r16 = r1
            r0 = r16
            com.google.zxing.aztec.AztecDetectorResult r0 = r0.ddata
            r16 = r0
            int r16 = r16.getNbLayers()
            r15 = r15[r16]
            r16 = r1
            r0 = r16
            int r0 = r0.numCodewords
            r16 = r0
            r17 = r1
            r0 = r17
            int r0 = r0.codewordSize
            r17 = r0
            int r16 = r16 * r17
            int r15 = r15 - r16
            r6 = r15
            int[] r15 = NB_DATABLOCK
            r16 = r1
            r0 = r16
            com.google.zxing.aztec.AztecDetectorResult r0 = r0.ddata
            r16 = r0
            int r16 = r16.getNbLayers()
            r15 = r15[r16]
            r16 = r4
            int r15 = r15 - r16
            r5 = r15
            goto L_0x0066
        L_0x0149:
            int r8 = r8 + 1
            goto L_0x006e
        L_0x014d:
            com.google.zxing.common.reedsolomon.ReedSolomonDecoder r15 = new com.google.zxing.common.reedsolomon.ReedSolomonDecoder     // Catch:{ ReedSolomonException -> 0x01d4 }
            r19 = r15
            r15 = r19
            r16 = r19
            r17 = r3
            r16.<init>(r17)     // Catch:{ ReedSolomonException -> 0x01d4 }
            r8 = r15
            r15 = r8
            r16 = r7
            r17 = r5
            r15.decode(r16, r17)     // Catch:{ ReedSolomonException -> 0x01d4 }
            r15 = 0
            r6 = r15
            r15 = r1
            r16 = 0
            r0 = r16
            r15.invertedBitCount = r0
            r15 = r4
            r16 = r1
            r0 = r16
            int r0 = r0.codewordSize
            r16 = r0
            int r15 = r15 * r16
            boolean[] r15 = new boolean[r15]
            r8 = r15
            r15 = 0
            r9 = r15
        L_0x017c:
            r15 = r9
            r16 = r4
            r0 = r16
            if (r15 >= r0) goto L_0x022d
            r15 = 0
            r10 = r15
            r15 = 0
            r11 = r15
            r15 = 1
            r16 = r1
            r0 = r16
            int r0 = r0.codewordSize
            r16 = r0
            r17 = 1
            int r16 = r16 + -1
            int r15 = r15 << r16
            r12 = r15
            r15 = 0
            r13 = r15
        L_0x0199:
            r15 = r13
            r16 = r1
            r0 = r16
            int r0 = r0.codewordSize
            r16 = r0
            r0 = r16
            if (r15 >= r0) goto L_0x0229
            r15 = r7
            r16 = r9
            r15 = r15[r16]
            r16 = r12
            r15 = r15 & r16
            r16 = r12
            r0 = r16
            if (r15 != r0) goto L_0x01db
            r15 = 1
        L_0x01b6:
            r14 = r15
            r15 = r11
            r16 = r1
            r0 = r16
            int r0 = r0.codewordSize
            r16 = r0
            r17 = 1
            int r16 = r16 + -1
            r0 = r16
            if (r15 != r0) goto L_0x0201
            r15 = r14
            r16 = r10
            r0 = r16
            if (r15 != r0) goto L_0x01dd
            com.google.zxing.FormatException r15 = com.google.zxing.FormatException.getFormatInstance()
            throw r15
        L_0x01d4:
            r15 = move-exception
            r8 = r15
            com.google.zxing.FormatException r15 = com.google.zxing.FormatException.getFormatInstance()
            throw r15
        L_0x01db:
            r15 = 0
            goto L_0x01b6
        L_0x01dd:
            r15 = 0
            r10 = r15
            r15 = 0
            r11 = r15
            int r6 = r6 + 1
            r15 = r1
            r19 = r15
            r15 = r19
            r16 = r19
            r0 = r16
            int r0 = r0.invertedBitCount
            r16 = r0
            r17 = 1
            int r16 = r16 + 1
            r0 = r16
            r15.invertedBitCount = r0
        L_0x01f8:
            r15 = r12
            r16 = 1
            int r15 = r15 >>> 1
            r12 = r15
            int r13 = r13 + 1
            goto L_0x0199
        L_0x0201:
            r15 = r10
            r16 = r14
            r0 = r16
            if (r15 != r0) goto L_0x0224
            int r11 = r11 + 1
        L_0x020a:
            r15 = r8
            r16 = r9
            r17 = r1
            r0 = r17
            int r0 = r0.codewordSize
            r17 = r0
            int r16 = r16 * r17
            r17 = r13
            int r16 = r16 + r17
            r17 = r6
            int r16 = r16 - r17
            r17 = r14
            r15[r16] = r17
            goto L_0x01f8
        L_0x0224:
            r15 = 1
            r11 = r15
            r15 = r14
            r10 = r15
            goto L_0x020a
        L_0x0229:
            int r9 = r9 + 1
            goto L_0x017c
        L_0x022d:
            r15 = r8
            r1 = r15
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.aztec.decoder.Decoder.correctBits(boolean[]):boolean[]");
    }

    private boolean[] extractBits(BitMatrix bitMatrix) throws FormatException {
        boolean[] rawbits;
        BitMatrix matrix = bitMatrix;
        if (this.ddata.isCompact()) {
            if (this.ddata.getNbLayers() > NB_BITS_COMPACT.length) {
                throw FormatException.getFormatInstance();
            }
            rawbits = new boolean[NB_BITS_COMPACT[this.ddata.getNbLayers()]];
            this.numCodewords = NB_DATABLOCK_COMPACT[this.ddata.getNbLayers()];
        } else if (this.ddata.getNbLayers() > NB_BITS.length) {
            throw FormatException.getFormatInstance();
        } else {
            rawbits = new boolean[NB_BITS[this.ddata.getNbLayers()]];
            this.numCodewords = NB_DATABLOCK[this.ddata.getNbLayers()];
        }
        int layer = this.ddata.getNbLayers();
        int size = matrix.getHeight();
        int rawbitsOffset = 0;
        int matrixOffset = 0;
        while (layer != 0) {
            int flip = 0;
            for (int i = 0; i < (2 * size) - 4; i++) {
                rawbits[rawbitsOffset + i] = matrix.get(matrixOffset + flip, matrixOffset + (i / 2));
                rawbits[((rawbitsOffset + (2 * size)) - 4) + i] = matrix.get(matrixOffset + (i / 2), ((matrixOffset + size) - 1) - flip);
                flip = (flip + 1) % 2;
            }
            int flip2 = 0;
            for (int i2 = (2 * size) + 1; i2 > 5; i2--) {
                rawbits[((rawbitsOffset + (4 * size)) - 8) + ((2 * size) - i2) + 1] = matrix.get(((matrixOffset + size) - 1) - flip2, (matrixOffset + (i2 / 2)) - 1);
                rawbits[((rawbitsOffset + (6 * size)) - 12) + ((2 * size) - i2) + 1] = matrix.get((matrixOffset + (i2 / 2)) - 1, matrixOffset + flip2);
                flip2 = (flip2 + 1) % 2;
            }
            matrixOffset += 2;
            rawbitsOffset += (8 * size) - 16;
            layer--;
            size -= 4;
        }
        return rawbits;
    }

    private static BitMatrix removeDashedLines(BitMatrix bitMatrix) {
        BitMatrix bitMatrix2;
        BitMatrix matrix = bitMatrix;
        int nbDashed = 1 + (2 * (((matrix.getWidth() - 1) / 2) / 16));
        new BitMatrix(matrix.getWidth() - nbDashed, matrix.getHeight() - nbDashed);
        BitMatrix newMatrix = bitMatrix2;
        int nx = 0;
        for (int x = 0; x < matrix.getWidth(); x++) {
            if (((matrix.getWidth() / 2) - x) % 16 != 0) {
                int ny = 0;
                for (int y = 0; y < matrix.getHeight(); y++) {
                    if (((matrix.getWidth() / 2) - y) % 16 != 0) {
                        if (matrix.get(x, y)) {
                            newMatrix.set(nx, ny);
                        }
                        ny++;
                    }
                }
                nx++;
            }
        }
        return newMatrix;
    }

    private static int readCode(boolean[] zArr, int i, int i2) {
        boolean[] rawbits = zArr;
        int startIndex = i;
        int length = i2;
        int res = 0;
        for (int i3 = startIndex; i3 < startIndex + length; i3++) {
            res <<= 1;
            if (rawbits[i3]) {
                res++;
            }
        }
        return res;
    }
}
