package com.google.zxing.aztec.detector;

import com.google.zxing.NotFoundException;
import com.google.zxing.ResultPoint;
import com.google.zxing.aztec.AztecDetectorResult;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.GridSampler;
import com.google.zxing.common.detector.MathUtils;
import com.google.zxing.common.detector.WhiteRectangleDetector;
import com.google.zxing.common.reedsolomon.GenericGF;
import com.google.zxing.common.reedsolomon.ReedSolomonDecoder;
import com.google.zxing.common.reedsolomon.ReedSolomonException;

public final class Detector {
    private boolean compact;
    private final BitMatrix image;
    private int nbCenterLayers;
    private int nbDataBlocks;
    private int nbLayers;
    private int shift;

    public Detector(BitMatrix image2) {
        this.image = image2;
    }

    public AztecDetectorResult detect() throws NotFoundException {
        AztecDetectorResult aztecDetectorResult;
        Point[] bullEyeCornerPoints = getBullEyeCornerPoints(getMatrixCenter());
        extractParameters(bullEyeCornerPoints);
        ResultPoint[] corners = getMatrixCornerPoints(bullEyeCornerPoints);
        new AztecDetectorResult(sampleGrid(this.image, corners[this.shift % 4], corners[(this.shift + 3) % 4], corners[(this.shift + 2) % 4], corners[(this.shift + 1) % 4]), corners, this.compact, this.nbDataBlocks, this.nbLayers);
        return aztecDetectorResult;
    }

    private void extractParameters(Point[] pointArr) throws NotFoundException {
        boolean[] parameterData;
        Point[] bullEyeCornerPoints = pointArr;
        boolean[] resab = sampleLine(bullEyeCornerPoints[0], bullEyeCornerPoints[1], (2 * this.nbCenterLayers) + 1);
        boolean[] resbc = sampleLine(bullEyeCornerPoints[1], bullEyeCornerPoints[2], (2 * this.nbCenterLayers) + 1);
        boolean[] rescd = sampleLine(bullEyeCornerPoints[2], bullEyeCornerPoints[3], (2 * this.nbCenterLayers) + 1);
        boolean[] resda = sampleLine(bullEyeCornerPoints[3], bullEyeCornerPoints[0], (2 * this.nbCenterLayers) + 1);
        if (resab[0] && resab[2 * this.nbCenterLayers]) {
            this.shift = 0;
        } else if (resbc[0] && resbc[2 * this.nbCenterLayers]) {
            this.shift = 1;
        } else if (rescd[0] && rescd[2 * this.nbCenterLayers]) {
            this.shift = 2;
        } else if (!resda[0] || !resda[2 * this.nbCenterLayers]) {
            throw NotFoundException.getNotFoundInstance();
        } else {
            this.shift = 3;
        }
        if (this.compact) {
            boolean[] shiftedParameterData = new boolean[28];
            for (int i = 0; i < 7; i++) {
                shiftedParameterData[i] = resab[2 + i];
                shiftedParameterData[i + 7] = resbc[2 + i];
                shiftedParameterData[i + 14] = rescd[2 + i];
                shiftedParameterData[i + 21] = resda[2 + i];
            }
            parameterData = new boolean[28];
            for (int i2 = 0; i2 < 28; i2++) {
                parameterData[i2] = shiftedParameterData[(i2 + (this.shift * 7)) % 28];
            }
        } else {
            boolean[] shiftedParameterData2 = new boolean[40];
            for (int i3 = 0; i3 < 11; i3++) {
                if (i3 < 5) {
                    shiftedParameterData2[i3] = resab[2 + i3];
                    shiftedParameterData2[i3 + 10] = resbc[2 + i3];
                    shiftedParameterData2[i3 + 20] = rescd[2 + i3];
                    shiftedParameterData2[i3 + 30] = resda[2 + i3];
                }
                if (i3 > 5) {
                    shiftedParameterData2[i3 - 1] = resab[2 + i3];
                    shiftedParameterData2[(i3 + 10) - 1] = resbc[2 + i3];
                    shiftedParameterData2[(i3 + 20) - 1] = rescd[2 + i3];
                    shiftedParameterData2[(i3 + 30) - 1] = resda[2 + i3];
                }
            }
            parameterData = new boolean[40];
            for (int i4 = 0; i4 < 40; i4++) {
                parameterData[i4] = shiftedParameterData2[(i4 + (this.shift * 10)) % 40];
            }
        }
        correctParameterData(parameterData, this.compact);
        getParameters(parameterData);
    }

    private ResultPoint[] getMatrixCornerPoints(Point[] pointArr) throws NotFoundException {
        ResultPoint resultPoint;
        ResultPoint resultPoint2;
        ResultPoint resultPoint3;
        ResultPoint resultPoint4;
        Point[] bullEyeCornerPoints = pointArr;
        float ratio = ((float) (((2 * this.nbLayers) + (this.nbLayers > 4 ? 1 : 0)) + ((this.nbLayers - 4) / 8))) / (2.0f * ((float) this.nbCenterLayers));
        int dx = bullEyeCornerPoints[0].x - bullEyeCornerPoints[2].x;
        int dx2 = dx + (dx > 0 ? 1 : -1);
        int dy = bullEyeCornerPoints[0].y - bullEyeCornerPoints[2].y;
        int dy2 = dy + (dy > 0 ? 1 : -1);
        int targetcx = MathUtils.round(((float) bullEyeCornerPoints[2].x) - (ratio * ((float) dx2)));
        int targetcy = MathUtils.round(((float) bullEyeCornerPoints[2].y) - (ratio * ((float) dy2)));
        int targetax = MathUtils.round(((float) bullEyeCornerPoints[0].x) + (ratio * ((float) dx2)));
        int targetay = MathUtils.round(((float) bullEyeCornerPoints[0].y) + (ratio * ((float) dy2)));
        int dx3 = bullEyeCornerPoints[1].x - bullEyeCornerPoints[3].x;
        int dx4 = dx3 + (dx3 > 0 ? 1 : -1);
        int dy3 = bullEyeCornerPoints[1].y - bullEyeCornerPoints[3].y;
        int dy4 = dy3 + (dy3 > 0 ? 1 : -1);
        int targetdx = MathUtils.round(((float) bullEyeCornerPoints[3].x) - (ratio * ((float) dx4)));
        int targetdy = MathUtils.round(((float) bullEyeCornerPoints[3].y) - (ratio * ((float) dy4)));
        int targetbx = MathUtils.round(((float) bullEyeCornerPoints[1].x) + (ratio * ((float) dx4)));
        int targetby = MathUtils.round(((float) bullEyeCornerPoints[1].y) + (ratio * ((float) dy4)));
        if (!isValid(targetax, targetay) || !isValid(targetbx, targetby) || !isValid(targetcx, targetcy) || !isValid(targetdx, targetdy)) {
            throw NotFoundException.getNotFoundInstance();
        }
        ResultPoint[] resultPointArr = new ResultPoint[4];
        new ResultPoint((float) targetax, (float) targetay);
        resultPointArr[0] = resultPoint;
        ResultPoint[] resultPointArr2 = resultPointArr;
        new ResultPoint((float) targetbx, (float) targetby);
        resultPointArr2[1] = resultPoint2;
        ResultPoint[] resultPointArr3 = resultPointArr2;
        new ResultPoint((float) targetcx, (float) targetcy);
        resultPointArr3[2] = resultPoint3;
        ResultPoint[] resultPointArr4 = resultPointArr3;
        new ResultPoint((float) targetdx, (float) targetdy);
        resultPointArr4[3] = resultPoint4;
        return resultPointArr4;
    }

    private static void correctParameterData(boolean[] zArr, boolean compact2) throws NotFoundException {
        int numCodewords;
        int numDataCodewords;
        ReedSolomonDecoder rsDecoder;
        boolean[] parameterData = zArr;
        if (compact2) {
            numCodewords = 7;
            numDataCodewords = 2;
        } else {
            numCodewords = 10;
            numDataCodewords = 4;
        }
        int numECCodewords = numCodewords - numDataCodewords;
        int[] parameterWords = new int[numCodewords];
        for (int i = 0; i < numCodewords; i++) {
            int flag = 1;
            for (int j = 1; j <= 4; j++) {
                if (parameterData[((4 * i) + 4) - j]) {
                    int[] iArr = parameterWords;
                    int i2 = i;
                    iArr[i2] = iArr[i2] + flag;
                }
                flag <<= 1;
            }
        }
        try {
            new ReedSolomonDecoder(GenericGF.AZTEC_PARAM);
            rsDecoder.decode(parameterWords, numECCodewords);
            for (int i3 = 0; i3 < numDataCodewords; i3++) {
                int flag2 = 1;
                for (int j2 = 1; j2 <= 4; j2++) {
                    parameterData[((i3 * 4) + 4) - j2] = (parameterWords[i3] & flag2) == flag2;
                    flag2 <<= 1;
                }
            }
        } catch (ReedSolomonException e) {
            ReedSolomonException reedSolomonException = e;
            throw NotFoundException.getNotFoundInstance();
        }
    }

    private Point[] getBullEyeCornerPoints(Point point) throws NotFoundException {
        Point point2;
        Point point3;
        Point point4;
        Point point5;
        boolean z;
        Point pCenter = point;
        Point pina = pCenter;
        Point pinb = pCenter;
        Point pinc = pCenter;
        Point pind = pCenter;
        boolean color = true;
        this.nbCenterLayers = 1;
        while (true) {
            if (this.nbCenterLayers >= 9) {
                break;
            }
            Point pouta = getFirstDifferent(pina, color, 1, -1);
            Point poutb = getFirstDifferent(pinb, color, 1, 1);
            Point poutc = getFirstDifferent(pinc, color, -1, 1);
            Point poutd = getFirstDifferent(pind, color, -1, -1);
            if (this.nbCenterLayers > 2) {
                float q = (distance(poutd, pouta) * ((float) this.nbCenterLayers)) / (distance(pind, pina) * ((float) (this.nbCenterLayers + 2)));
                if (((double) q) >= 0.75d) {
                    if (((double) q) <= 1.25d) {
                        if (!isWhiteOrBlackRectangle(pouta, poutb, poutc, poutd)) {
                            break;
                        }
                    } else {
                        break;
                    }
                } else {
                    break;
                }
            }
            pina = pouta;
            pinb = poutb;
            pinc = poutc;
            pind = poutd;
            if (!color) {
                z = true;
            } else {
                z = false;
            }
            color = z;
            this.nbCenterLayers++;
        }
        if (this.nbCenterLayers != 5) {
            if (this.nbCenterLayers != 7) {
                throw NotFoundException.getNotFoundInstance();
            }
        }
        this.compact = this.nbCenterLayers == 5;
        float ratio = 1.5f / ((float) ((2 * this.nbCenterLayers) - 3));
        int dx = pina.x - pinc.x;
        int dy = pina.y - pinc.y;
        int targetcx = MathUtils.round(((float) pinc.x) - (ratio * ((float) dx)));
        int targetcy = MathUtils.round(((float) pinc.y) - (ratio * ((float) dy)));
        int targetax = MathUtils.round(((float) pina.x) + (ratio * ((float) dx)));
        int targetay = MathUtils.round(((float) pina.y) + (ratio * ((float) dy)));
        int dx2 = pinb.x - pind.x;
        int dy2 = pinb.y - pind.y;
        int targetdx = MathUtils.round(((float) pind.x) - (ratio * ((float) dx2)));
        int targetdy = MathUtils.round(((float) pind.y) - (ratio * ((float) dy2)));
        int targetbx = MathUtils.round(((float) pinb.x) + (ratio * ((float) dx2)));
        int targetby = MathUtils.round(((float) pinb.y) + (ratio * ((float) dy2)));
        if (!isValid(targetax, targetay) || !isValid(targetbx, targetby) || !isValid(targetcx, targetcy) || !isValid(targetdx, targetdy)) {
            throw NotFoundException.getNotFoundInstance();
        }
        new Point(targetax, targetay, (AnonymousClass1) null);
        Point pa = point2;
        new Point(targetbx, targetby, (AnonymousClass1) null);
        Point pb = point3;
        new Point(targetcx, targetcy, (AnonymousClass1) null);
        Point pc = point4;
        new Point(targetdx, targetdy, (AnonymousClass1) null);
        Point pd = point5;
        Point[] pointArr = new Point[4];
        pointArr[0] = pa;
        Point[] pointArr2 = pointArr;
        pointArr2[1] = pb;
        Point[] pointArr3 = pointArr2;
        pointArr3[2] = pc;
        Point[] pointArr4 = pointArr3;
        pointArr4[3] = pd;
        return pointArr4;
    }

    private Point getMatrixCenter() {
        Point point;
        ResultPoint pointA;
        Point point2;
        ResultPoint pointB;
        Point point3;
        ResultPoint pointC;
        Point point4;
        ResultPoint pointD;
        Point point5;
        ResultPoint pointA2;
        Point point6;
        ResultPoint pointB2;
        Point point7;
        ResultPoint pointC2;
        Point point8;
        ResultPoint pointD2;
        Point point9;
        WhiteRectangleDetector whiteRectangleDetector;
        WhiteRectangleDetector whiteRectangleDetector2;
        try {
            new WhiteRectangleDetector(this.image);
            ResultPoint[] cornerPoints = whiteRectangleDetector2.detect();
            pointA = cornerPoints[0];
            pointB = cornerPoints[1];
            pointC = cornerPoints[2];
            pointD = cornerPoints[3];
        } catch (NotFoundException e) {
            NotFoundException notFoundException = e;
            int cx = this.image.getWidth() / 2;
            int cy = this.image.getHeight() / 2;
            new Point(cx + 7, cy - 7, (AnonymousClass1) null);
            pointA = getFirstDifferent(point, false, 1, -1).toResultPoint();
            new Point(cx + 7, cy + 7, (AnonymousClass1) null);
            pointB = getFirstDifferent(point2, false, 1, 1).toResultPoint();
            new Point(cx - 7, cy + 7, (AnonymousClass1) null);
            pointC = getFirstDifferent(point3, false, -1, 1).toResultPoint();
            new Point(cx - 7, cy - 7, (AnonymousClass1) null);
            pointD = getFirstDifferent(point4, false, -1, -1).toResultPoint();
        }
        int cx2 = MathUtils.round((((pointA.getX() + pointD.getX()) + pointB.getX()) + pointC.getX()) / 4.0f);
        int cy2 = MathUtils.round((((pointA.getY() + pointD.getY()) + pointB.getY()) + pointC.getY()) / 4.0f);
        try {
            new WhiteRectangleDetector(this.image, 15, cx2, cy2);
            ResultPoint[] cornerPoints2 = whiteRectangleDetector.detect();
            pointA2 = cornerPoints2[0];
            pointB2 = cornerPoints2[1];
            pointC2 = cornerPoints2[2];
            pointD2 = cornerPoints2[3];
        } catch (NotFoundException e2) {
            NotFoundException notFoundException2 = e2;
            new Point(cx2 + 7, cy2 - 7, (AnonymousClass1) null);
            pointA2 = getFirstDifferent(point5, false, 1, -1).toResultPoint();
            new Point(cx2 + 7, cy2 + 7, (AnonymousClass1) null);
            pointB2 = getFirstDifferent(point6, false, 1, 1).toResultPoint();
            new Point(cx2 - 7, cy2 + 7, (AnonymousClass1) null);
            pointC2 = getFirstDifferent(point7, false, -1, 1).toResultPoint();
            new Point(cx2 - 7, cy2 - 7, (AnonymousClass1) null);
            pointD2 = getFirstDifferent(point8, false, -1, -1).toResultPoint();
        }
        new Point(MathUtils.round((((pointA2.getX() + pointD2.getX()) + pointB2.getX()) + pointC2.getX()) / 4.0f), MathUtils.round((((pointA2.getY() + pointD2.getY()) + pointB2.getY()) + pointC2.getY()) / 4.0f), (AnonymousClass1) null);
        return point9;
    }

    private BitMatrix sampleGrid(BitMatrix bitMatrix, ResultPoint resultPoint, ResultPoint resultPoint2, ResultPoint resultPoint3, ResultPoint resultPoint4) throws NotFoundException {
        int dimension;
        BitMatrix image2 = bitMatrix;
        ResultPoint topLeft = resultPoint;
        ResultPoint bottomLeft = resultPoint2;
        ResultPoint bottomRight = resultPoint3;
        ResultPoint topRight = resultPoint4;
        if (this.compact) {
            dimension = (4 * this.nbLayers) + 11;
        } else if (this.nbLayers <= 4) {
            dimension = (4 * this.nbLayers) + 15;
        } else {
            dimension = (4 * this.nbLayers) + (2 * (((this.nbLayers - 4) / 8) + 1)) + 15;
        }
        return GridSampler.getInstance().sampleGrid(image2, dimension, dimension, 0.5f, 0.5f, ((float) dimension) - 0.5f, 0.5f, ((float) dimension) - 0.5f, ((float) dimension) - 0.5f, 0.5f, ((float) dimension) - 0.5f, topLeft.getX(), topLeft.getY(), topRight.getX(), topRight.getY(), bottomRight.getX(), bottomRight.getY(), bottomLeft.getX(), bottomLeft.getY());
    }

    private void getParameters(boolean[] zArr) {
        int nbBitsForNbLayers;
        int nbBitsForNbDatablocks;
        boolean[] parameterData = zArr;
        if (this.compact) {
            nbBitsForNbLayers = 2;
            nbBitsForNbDatablocks = 6;
        } else {
            nbBitsForNbLayers = 5;
            nbBitsForNbDatablocks = 11;
        }
        for (int i = 0; i < nbBitsForNbLayers; i++) {
            this.nbLayers <<= 1;
            if (parameterData[i]) {
                this.nbLayers++;
            }
        }
        for (int i2 = nbBitsForNbLayers; i2 < nbBitsForNbLayers + nbBitsForNbDatablocks; i2++) {
            this.nbDataBlocks <<= 1;
            if (parameterData[i2]) {
                this.nbDataBlocks++;
            }
        }
        this.nbLayers++;
        this.nbDataBlocks++;
    }

    private boolean[] sampleLine(Point point, Point point2, int i) {
        Point p1 = point;
        Point p2 = point2;
        int size = i;
        boolean[] res = new boolean[size];
        float d = distance(p1, p2);
        float moduleSize = d / ((float) (size - 1));
        float dx = (moduleSize * ((float) (p2.x - p1.x))) / d;
        float dy = (moduleSize * ((float) (p2.y - p1.y))) / d;
        float px = (float) p1.x;
        float py = (float) p1.y;
        for (int i2 = 0; i2 < size; i2++) {
            res[i2] = this.image.get(MathUtils.round(px), MathUtils.round(py));
            px += dx;
            py += dy;
        }
        return res;
    }

    private boolean isWhiteOrBlackRectangle(Point point, Point point2, Point point3, Point point4) {
        Point point5;
        Point point6;
        Point point7;
        Point point8;
        Point p1 = point;
        Point p2 = point2;
        Point p3 = point3;
        Point p4 = point4;
        new Point(p1.x - 3, p1.y + 3, (AnonymousClass1) null);
        Point p12 = point5;
        new Point(p2.x - 3, p2.y - 3, (AnonymousClass1) null);
        Point p22 = point6;
        new Point(p3.x + 3, p3.y - 3, (AnonymousClass1) null);
        Point p32 = point7;
        new Point(p4.x + 3, p4.y + 3, (AnonymousClass1) null);
        Point p42 = point8;
        int cInit = getColor(p42, p12);
        if (cInit == 0) {
            return false;
        }
        if (getColor(p12, p22) != cInit) {
            return false;
        }
        if (getColor(p22, p32) != cInit) {
            return false;
        }
        return getColor(p32, p42) == cInit;
    }

    private int getColor(Point point, Point point2) {
        Point p1 = point;
        Point p2 = point2;
        float d = distance(p1, p2);
        float dx = ((float) (p2.x - p1.x)) / d;
        float dy = ((float) (p2.y - p1.y)) / d;
        int error = 0;
        float px = (float) p1.x;
        float py = (float) p1.y;
        boolean colorModel = this.image.get(p1.x, p1.y);
        for (int i = 0; ((float) i) < d; i++) {
            px += dx;
            py += dy;
            if (this.image.get(MathUtils.round(px), MathUtils.round(py)) != colorModel) {
                error++;
            }
        }
        float errRatio = ((float) error) / d;
        if (((double) errRatio) > 0.1d && ((double) errRatio) < 0.9d) {
            return 0;
        }
        if (((double) errRatio) <= 0.1d) {
            return colorModel ? 1 : -1;
        }
        return colorModel ? -1 : 1;
    }

    private Point getFirstDifferent(Point point, boolean z, int i, int i2) {
        int y;
        Point point2;
        Point init = point;
        boolean color = z;
        int dx = i;
        int dy = i2;
        int x = init.x + dx;
        int i3 = init.y;
        while (true) {
            y = i3 + dy;
            if (!isValid(x, y) || this.image.get(x, y) != color) {
                int x2 = x - dx;
                int y2 = y - dy;
            } else {
                x += dx;
                i3 = y;
            }
        }
        int x22 = x - dx;
        int y22 = y - dy;
        while (isValid(x22, y22) && this.image.get(x22, y22) == color) {
            x22 += dx;
        }
        int x3 = x22 - dx;
        while (isValid(x3, y22) && this.image.get(x3, y22) == color) {
            y22 += dy;
        }
        new Point(x3, y22 - dy, (AnonymousClass1) null);
        return point2;
    }

    private static final class Point {
        public final int x;
        public final int y;

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ Point(int x0, int x1, AnonymousClass1 r10) {
            this(x0, x1);
            AnonymousClass1 r3 = r10;
        }

        public ResultPoint toResultPoint() {
            ResultPoint resultPoint;
            new ResultPoint((float) this.x, (float) this.y);
            return resultPoint;
        }

        private Point(int x2, int y2) {
            this.x = x2;
            this.y = y2;
        }
    }

    private boolean isValid(int i, int i2) {
        int x = i;
        int y = i2;
        return x >= 0 && x < this.image.getWidth() && y > 0 && y < this.image.getHeight();
    }

    private static float distance(Point point, Point point2) {
        Point a = point;
        Point b = point2;
        return MathUtils.distance(a.x, a.y, b.x, b.y);
    }
}
