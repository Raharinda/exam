package com.google.zxing.client.result;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Pattern;

public final class CalendarParsedResult extends ParsedResult {
    private static final DateFormat DATE_FORMAT;
    private static final Pattern DATE_TIME = Pattern.compile("[0-9]{8}(T[0-9]{6}Z?)?");
    private static final DateFormat DATE_TIME_FORMAT;
    private final String[] attendees;
    private final String description;
    private final Date end;
    private final boolean endAllDay;
    private final double latitude;
    private final String location;
    private final double longitude;
    private final String organizer;
    private final Date start;
    private final boolean startAllDay;
    private final String summary;

    static {
        DateFormat dateFormat;
        DateFormat dateFormat2;
        new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH);
        DATE_FORMAT = dateFormat;
        DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("GMT"));
        new SimpleDateFormat("yyyyMMdd'T'HHmmss", Locale.ENGLISH);
        DATE_TIME_FORMAT = dateFormat2;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CalendarParsedResult(String summary2, String str, String str2, String str3, String str4, String[] strArr, String str5, double d, double d2) {
        super(ParsedResultType.CALENDAR);
        Throwable th;
        String startString = str;
        String endString = str2;
        String location2 = str3;
        String organizer2 = str4;
        String[] attendees2 = strArr;
        String description2 = str5;
        double latitude2 = d;
        double longitude2 = d2;
        this.summary = summary2;
        try {
            this.start = parseDate(startString);
            this.end = endString == null ? null : parseDate(endString);
            this.startAllDay = startString.length() == 8;
            this.endAllDay = endString != null && endString.length() == 8;
            this.location = location2;
            this.organizer = organizer2;
            this.attendees = attendees2;
            this.description = description2;
            this.latitude = latitude2;
            this.longitude = longitude2;
        } catch (ParseException e) {
            ParseException pe = e;
            Throwable th2 = th;
            new IllegalArgumentException(pe.toString());
            throw th2;
        }
    }

    public String getSummary() {
        return this.summary;
    }

    public Date getStart() {
        return this.start;
    }

    public boolean isStartAllDay() {
        return this.startAllDay;
    }

    public Date getEnd() {
        return this.end;
    }

    public boolean isEndAllDay() {
        return this.endAllDay;
    }

    public String getLocation() {
        return this.location;
    }

    public String getOrganizer() {
        return this.organizer;
    }

    public String[] getAttendees() {
        return this.attendees;
    }

    public String getDescription() {
        return this.description;
    }

    public double getLatitude() {
        return this.latitude;
    }

    public double getLongitude() {
        return this.longitude;
    }

    public String getDisplayResult() {
        StringBuilder sb;
        new StringBuilder(100);
        StringBuilder result = sb;
        maybeAppend(this.summary, result);
        maybeAppend(format(this.startAllDay, this.start), result);
        maybeAppend(format(this.endAllDay, this.end), result);
        maybeAppend(this.location, result);
        maybeAppend(this.organizer, result);
        maybeAppend(this.attendees, result);
        maybeAppend(this.description, result);
        return result.toString();
    }

    private static Date parseDate(String str) throws ParseException {
        Date date;
        Calendar calendar;
        Date date2;
        Date date3;
        Throwable th;
        String when = str;
        if (!DATE_TIME.matcher(when).matches()) {
            Throwable th2 = th;
            new ParseException(when, 0);
            throw th2;
        } else if (when.length() == 8) {
            return DATE_FORMAT.parse(when);
        } else {
            if (when.length() == 16 && when.charAt(15) == 'Z') {
                Date date4 = DATE_TIME_FORMAT.parse(when.substring(0, 15));
                new GregorianCalendar();
                Calendar calendar2 = calendar;
                long milliseconds = date4.getTime() + ((long) calendar2.get(15));
                new Date(milliseconds);
                calendar2.setTime(date2);
                new Date(milliseconds + ((long) calendar2.get(16)));
                date = date3;
            } else {
                date = DATE_TIME_FORMAT.parse(when);
            }
            return date;
        }
    }

    private static String format(boolean z, Date date) {
        boolean allDay = z;
        Date date2 = date;
        if (date2 == null) {
            return null;
        }
        return (allDay ? DateFormat.getDateInstance(2) : DateFormat.getDateTimeInstance(2, 2)).format(date2);
    }
}
