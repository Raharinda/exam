package com.google.zxing.client.android.camera;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Camera;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.util.Log;
import com.google.zxing.client.android.common.executor.AsyncTaskExecInterface;
import com.google.zxing.client.android.common.executor.AsyncTaskExecManager;
import java.util.ArrayList;
import java.util.Collection;

final class AutoFocusManager implements Camera.AutoFocusCallback {
    private static final long AUTO_FOCUS_INTERVAL_MS = 2000;
    private static final Collection<String> FOCUS_MODES_CALLING_AF;
    private static final String TAG = AutoFocusManager.class.getSimpleName();
    /* access modifiers changed from: private */
    public boolean active;
    private final Camera camera;
    private AutoFocusTask outstandingTask;
    private final AsyncTaskExecInterface taskExec;
    private final boolean useAutoFocus;

    static {
        Collection<String> collection;
        new ArrayList(2);
        FOCUS_MODES_CALLING_AF = collection;
        boolean add = FOCUS_MODES_CALLING_AF.add("auto");
        boolean add2 = FOCUS_MODES_CALLING_AF.add("macro");
    }

    AutoFocusManager(Context context, Camera camera2) {
        AsyncTaskExecManager asyncTaskExecManager;
        StringBuilder sb;
        Camera camera3 = camera2;
        this.camera = camera3;
        new AsyncTaskExecManager();
        this.taskExec = (AsyncTaskExecInterface) asyncTaskExecManager.build();
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String currentFocusMode = camera3.getParameters().getFocusMode();
        this.useAutoFocus = FOCUS_MODES_CALLING_AF.contains(currentFocusMode);
        String str = TAG;
        new StringBuilder();
        int i = Log.i(str, sb.append("Current focus mode '").append(currentFocusMode).append("'; use auto focus? ").append(this.useAutoFocus).toString());
        start();
    }

    public synchronized void onAutoFocus(boolean z, Camera camera2) {
        AutoFocusTask autoFocusTask;
        boolean z2 = z;
        Camera camera3 = camera2;
        synchronized (this) {
            if (this.active) {
                new AutoFocusTask(this, (AnonymousClass1) null);
                this.outstandingTask = autoFocusTask;
                this.taskExec.execute(this.outstandingTask, new Object[0]);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public synchronized void start() {
        synchronized (this) {
            if (this.useAutoFocus) {
                this.active = true;
                try {
                    this.camera.autoFocus(this);
                } catch (RuntimeException e) {
                    int w = Log.w(TAG, "Unexpected exception while focusing", e);
                }
            }
        }
        return;
    }

    /* access modifiers changed from: package-private */
    public synchronized void stop() {
        synchronized (this) {
            if (this.useAutoFocus) {
                try {
                    this.camera.cancelAutoFocus();
                } catch (RuntimeException e) {
                    int w = Log.w(TAG, "Unexpected exception while cancelling focusing", e);
                }
            }
            if (this.outstandingTask != null) {
                boolean cancel = this.outstandingTask.cancel(true);
                this.outstandingTask = null;
            }
            this.active = false;
        }
        return;
    }

    private final class AutoFocusTask extends AsyncTask<Object, Object, Object> {
        final /* synthetic */ AutoFocusManager this$0;

        private AutoFocusTask(AutoFocusManager autoFocusManager) {
            this.this$0 = autoFocusManager;
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ AutoFocusTask(AutoFocusManager x0, AnonymousClass1 r7) {
            this(x0);
            AnonymousClass1 r2 = r7;
        }

        /* access modifiers changed from: protected */
        public Object doInBackground(Object... objArr) {
            AutoFocusManager autoFocusManager;
            Object[] objArr2 = objArr;
            try {
                Thread.sleep(AutoFocusManager.AUTO_FOCUS_INTERVAL_MS);
            } catch (InterruptedException e) {
                InterruptedException interruptedException = e;
            } catch (Throwable th) {
                Throwable th2 = th;
                AutoFocusManager autoFocusManager2 = autoFocusManager;
                throw th2;
            }
            AutoFocusManager autoFocusManager3 = this.this$0;
            autoFocusManager = autoFocusManager3;
            synchronized (autoFocusManager3) {
                if (this.this$0.active) {
                    this.this$0.start();
                }
                return null;
            }
        }
    }
}
