package com.google.zxing.client.result;

import com.google.zxing.Result;

public final class TelResultParser extends ResultParser {
    public TelResultParser() {
    }

    public TelParsedResult parse(Result result) {
        String str;
        TelParsedResult telParsedResult;
        StringBuilder sb;
        String rawText = getMassagedText(result);
        if (!rawText.startsWith("tel:") && !rawText.startsWith("TEL:")) {
            return null;
        }
        if (rawText.startsWith("TEL:")) {
            new StringBuilder();
            str = sb.append("tel:").append(rawText.substring(4)).toString();
        } else {
            str = rawText;
        }
        String telURI = str;
        int queryStart = rawText.indexOf(63, 4);
        new TelParsedResult(queryStart < 0 ? rawText.substring(4) : rawText.substring(4, queryStart), telURI, (String) null);
        return telParsedResult;
    }
}
