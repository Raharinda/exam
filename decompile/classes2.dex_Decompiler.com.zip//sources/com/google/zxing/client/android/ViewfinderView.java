package com.google.zxing.client.android;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import com.google.zxing.ResultPoint;
import com.google.zxing.client.android.camera.CameraManager;
import java.util.ArrayList;
import java.util.List;

public final class ViewfinderView extends View {
    private static final long ANIMATION_DELAY = 80;
    private static final int CURRENT_POINT_OPACITY = 160;
    private static final int MAX_RESULT_POINTS = 20;
    private static final int POINT_SIZE = 6;
    private static final int[] SCANNER_ALPHA = {0, 64, 128, 192, 255, 192, 128, 64};
    private CameraManager cameraManager;
    private final int laserColor = -3407872;
    private List<ResultPoint> lastPossibleResultPoints;
    private final int maskColor = 1610612736;
    private final Paint paint;
    private List<ResultPoint> possibleResultPoints;
    private Bitmap resultBitmap;
    private final int resultColor = -1;
    private final int resultPointColor = -1063662592;
    private int scannerAlpha = 0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ViewfinderView(Context context, AttributeSet attrs) {
        super(context, attrs);
        Paint paint2;
        List<ResultPoint> list;
        new Paint(1);
        this.paint = paint2;
        new ArrayList(5);
        this.possibleResultPoints = list;
        this.lastPossibleResultPoints = null;
    }

    public void setCameraManager(CameraManager cameraManager2) {
        CameraManager cameraManager3 = cameraManager2;
        this.cameraManager = cameraManager3;
    }

    /* JADX INFO: finally extract failed */
    public void onDraw(Canvas canvas) {
        int i;
        List<ResultPoint> list;
        Canvas canvas2 = canvas;
        if (this.cameraManager != null) {
            Rect frame = this.cameraManager.getFramingRect();
            if (frame != null) {
                int width = canvas2.getWidth();
                int height = canvas2.getHeight();
                Paint paint2 = this.paint;
                if (this.resultBitmap != null) {
                    i = this.resultColor;
                } else {
                    i = this.maskColor;
                }
                paint2.setColor(i);
                canvas2.drawRect(0.0f, 0.0f, (float) width, (float) frame.top, this.paint);
                canvas2.drawRect(0.0f, (float) frame.top, (float) frame.left, (float) (frame.bottom + 1), this.paint);
                canvas2.drawRect((float) (frame.right + 1), (float) frame.top, (float) width, (float) (frame.bottom + 1), this.paint);
                canvas2.drawRect(0.0f, (float) (frame.bottom + 1), (float) width, (float) height, this.paint);
                this.paint.setColor(-1);
                canvas2.drawRect((float) (frame.left - 20), (float) (frame.top - 20), (float) frame.left, (float) (frame.top + 60), this.paint);
                canvas2.drawRect((float) frame.left, (float) (frame.top - 20), (float) (frame.left + 60), (float) frame.top, this.paint);
                canvas2.drawRect((float) frame.right, (float) (frame.top - 20), (float) (frame.right + 20), (float) (frame.top + 60), this.paint);
                canvas2.drawRect((float) (frame.right - 60), (float) (frame.top - 20), (float) frame.right, (float) frame.top, this.paint);
                canvas2.drawRect((float) (frame.left - 20), (float) (frame.bottom - 60), (float) frame.left, (float) (frame.bottom + 20), this.paint);
                canvas2.drawRect((float) frame.left, (float) frame.bottom, (float) (frame.left + 60), (float) (frame.bottom + 20), this.paint);
                canvas2.drawRect((float) frame.right, (float) (frame.bottom - 60), (float) (frame.right + 20), (float) (frame.bottom + 20), this.paint);
                canvas2.drawRect((float) (frame.right - 60), (float) frame.bottom, (float) frame.right, (float) (frame.bottom + 20), this.paint);
                this.paint.setAlpha(CURRENT_POINT_OPACITY);
                canvas2.drawLine((float) frame.left, (float) frame.top, (float) frame.right, (float) frame.top, this.paint);
                canvas2.drawLine((float) frame.left, (float) frame.bottom, (float) frame.right, (float) frame.bottom, this.paint);
                canvas2.drawLine((float) frame.left, (float) frame.top, (float) frame.left, (float) frame.bottom, this.paint);
                canvas2.drawLine((float) frame.right, (float) frame.top, (float) frame.right, (float) frame.bottom, this.paint);
                if (this.resultBitmap != null) {
                    this.paint.setAlpha(CURRENT_POINT_OPACITY);
                    canvas2.drawBitmap(this.resultBitmap, (Rect) null, frame, this.paint);
                    return;
                }
                this.paint.setColor(this.laserColor);
                this.paint.setAlpha(SCANNER_ALPHA[this.scannerAlpha]);
                this.scannerAlpha = (this.scannerAlpha + 1) % SCANNER_ALPHA.length;
                int middle = (frame.height() / 2) + frame.top;
                canvas2.drawRect((float) (frame.left + 2), (float) (middle - 1), (float) (frame.right - 1), (float) (middle + 2), this.paint);
                Rect previewFrame = this.cameraManager.getFramingRectInPreview();
                float scaleX = ((float) frame.width()) / ((float) previewFrame.width());
                float scaleY = ((float) frame.height()) / ((float) previewFrame.height());
                List<ResultPoint> currentPossible = this.possibleResultPoints;
                List<ResultPoint> currentLast = this.lastPossibleResultPoints;
                int frameLeft = frame.left;
                int frameTop = frame.top;
                if (currentPossible.isEmpty()) {
                    this.lastPossibleResultPoints = null;
                } else {
                    new ArrayList(5);
                    this.possibleResultPoints = list;
                    this.lastPossibleResultPoints = currentPossible;
                    this.paint.setAlpha(CURRENT_POINT_OPACITY);
                    this.paint.setColor(this.resultPointColor);
                    List<ResultPoint> list2 = currentPossible;
                    List<ResultPoint> list3 = list2;
                    synchronized (list2) {
                        try {
                            for (ResultPoint point : currentPossible) {
                                canvas2.drawCircle((float) (frameLeft + ((int) (point.getX() * scaleX))), (float) (frameTop + ((int) (point.getY() * scaleY))), 6.0f, this.paint);
                            }
                        } catch (Throwable th) {
                            Throwable th2 = th;
                            List<ResultPoint> list4 = list3;
                            throw th2;
                        }
                    }
                }
                if (currentLast != null) {
                    this.paint.setAlpha(80);
                    this.paint.setColor(this.resultPointColor);
                    List<ResultPoint> list5 = currentLast;
                    List<ResultPoint> list6 = list5;
                    synchronized (list5) {
                        try {
                            for (ResultPoint point2 : currentLast) {
                                canvas2.drawCircle((float) (frameLeft + ((int) (point2.getX() * scaleX))), (float) (frameTop + ((int) (point2.getY() * scaleY))), 3.0f, this.paint);
                            }
                        } catch (Throwable th3) {
                            while (true) {
                                Throwable th4 = th3;
                                List<ResultPoint> list7 = list6;
                                throw th4;
                            }
                        }
                    }
                }
                postInvalidateDelayed(ANIMATION_DELAY, frame.left - 6, frame.top - 6, frame.right + 6, frame.bottom + 6);
            }
        }
    }

    public void drawViewfinder() {
        Bitmap resultBitmap2 = this.resultBitmap;
        this.resultBitmap = null;
        if (resultBitmap2 != null) {
            resultBitmap2.recycle();
        }
        invalidate();
    }

    public void drawResultBitmap(Bitmap barcode) {
        this.resultBitmap = barcode;
        invalidate();
    }

    /* JADX INFO: finally extract failed */
    public void addPossibleResultPoint(ResultPoint resultPoint) {
        ResultPoint point = resultPoint;
        List<ResultPoint> points = this.possibleResultPoints;
        List<ResultPoint> list = points;
        List<ResultPoint> list2 = list;
        synchronized (list) {
            try {
                boolean add = points.add(point);
                int size = points.size();
                if (size > 20) {
                    points.subList(0, size - 10).clear();
                }
            } catch (Throwable th) {
                Throwable th2 = th;
                List<ResultPoint> list3 = list2;
                throw th2;
            }
        }
    }
}
