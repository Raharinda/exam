package com.google.zxing.client.result;

import com.google.zxing.Result;

public final class AddressBookDoCoMoResultParser extends AbstractDoCoMoResultParser {
    public AddressBookDoCoMoResultParser() {
    }

    public AddressBookParsedResult parse(Result result) {
        AddressBookParsedResult addressBookParsedResult;
        String rawText = getMassagedText(result);
        if (!rawText.startsWith("MECARD:")) {
            return null;
        }
        String[] rawName = matchDoCoMoPrefixedField("N:", rawText, true);
        if (rawName == null) {
            return null;
        }
        String name = parseName(rawName[0]);
        String pronunciation = matchSingleDoCoMoPrefixedField("SOUND:", rawText, true);
        String[] phoneNumbers = matchDoCoMoPrefixedField("TEL:", rawText, true);
        String[] emails = matchDoCoMoPrefixedField("EMAIL:", rawText, true);
        String note = matchSingleDoCoMoPrefixedField("NOTE:", rawText, false);
        String[] addresses = matchDoCoMoPrefixedField("ADR:", rawText, true);
        String birthday = matchSingleDoCoMoPrefixedField("BDAY:", rawText, true);
        if (birthday != null && !isStringOfDigits(birthday, 8)) {
            birthday = null;
        }
        new AddressBookParsedResult(maybeWrap(name), pronunciation, phoneNumbers, (String[]) null, emails, (String[]) null, (String) null, note, addresses, (String[]) null, matchSingleDoCoMoPrefixedField("ORG:", rawText, true), birthday, (String) null, matchSingleDoCoMoPrefixedField("URL:", rawText, true));
        return addressBookParsedResult;
    }

    private static String parseName(String str) {
        StringBuilder sb;
        String name = str;
        int comma = name.indexOf(44);
        if (comma < 0) {
            return name;
        }
        new StringBuilder();
        return sb.append(name.substring(comma + 1)).append(' ').append(name.substring(0, comma)).toString();
    }
}
