package com.google.zxing.client.android;

public class Constants {
    public static final int decode = 1;
    public static final int decode_failed = 2;
    public static final int decode_succeeded = 3;
    public static final int quit = 4;
    public static final int restart_preview = 5;
    public static final int return_scan_result = 6;

    public Constants() {
    }
}
