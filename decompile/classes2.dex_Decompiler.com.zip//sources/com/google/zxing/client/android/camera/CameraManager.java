package com.google.zxing.client.android.camera;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.hardware.Camera;
import android.os.Handler;
import android.util.Log;
import android.view.SurfaceHolder;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.client.android.camera.open.OpenCameraInterface;
import com.google.zxing.client.android.camera.open.OpenCameraManager;
import java.io.IOException;

public final class CameraManager {
    private static final int MIN_FRAME_HEIGHT = 240;
    private static final int MIN_FRAME_WIDTH = 240;
    private static final String TAG = CameraManager.class.getSimpleName();
    private AutoFocusManager autoFocusManager;
    private Camera camera;
    private final CameraConfigurationManager configManager;
    private final Context context;
    private Rect framingRect;
    private Rect framingRectInPreview;
    private boolean initialized;
    private final PreviewCallback previewCallback;
    private boolean previewing;
    private int requestedFramingRectHeight;
    private int requestedFramingRectWidth;

    public CameraManager(Context context2) {
        CameraConfigurationManager cameraConfigurationManager;
        PreviewCallback previewCallback2;
        Context context3 = context2;
        this.context = context3;
        new CameraConfigurationManager(context3);
        this.configManager = cameraConfigurationManager;
        new PreviewCallback(this.configManager);
        this.previewCallback = previewCallback2;
    }

    public synchronized void openDriver(SurfaceHolder surfaceHolder) throws IOException {
        StringBuilder sb;
        OpenCameraManager openCameraManager;
        Throwable th;
        SurfaceHolder holder = surfaceHolder;
        synchronized (this) {
            Camera theCamera = this.camera;
            if (theCamera == null) {
                new OpenCameraManager();
                theCamera = ((OpenCameraInterface) openCameraManager.build()).open();
                if (theCamera == null) {
                    Throwable th2 = th;
                    new IOException();
                    throw th2;
                }
                this.camera = theCamera;
            }
            theCamera.setPreviewDisplay(holder);
            if (!this.initialized) {
                this.initialized = true;
                this.configManager.initFromCameraParameters(theCamera);
                if (this.requestedFramingRectWidth > 0 && this.requestedFramingRectHeight > 0) {
                    setManualFramingRect(this.requestedFramingRectWidth, this.requestedFramingRectHeight);
                    this.requestedFramingRectWidth = 0;
                    this.requestedFramingRectHeight = 0;
                }
            }
            Camera.Parameters parameters = theCamera.getParameters();
            String parametersFlattened = parameters == null ? null : parameters.flatten();
            try {
                this.configManager.setDesiredCameraParameters(theCamera, false);
            } catch (RuntimeException e) {
                RuntimeException runtimeException = e;
                int w = Log.w(TAG, "Camera rejected parameters. Setting only minimal safe-mode parameters");
                String str = TAG;
                new StringBuilder();
                int i = Log.i(str, sb.append("Resetting to saved camera params: ").append(parametersFlattened).toString());
                if (parametersFlattened != null) {
                    Camera.Parameters parameters2 = theCamera.getParameters();
                    parameters2.unflatten(parametersFlattened);
                    try {
                        theCamera.setParameters(parameters2);
                        this.configManager.setDesiredCameraParameters(theCamera, true);
                    } catch (RuntimeException e2) {
                        RuntimeException runtimeException2 = e2;
                        int w2 = Log.w(TAG, "Camera rejected even safe-mode parameters! No configuration");
                    }
                }
            }
        }
        return;
    }

    public synchronized boolean isOpen() {
        boolean z;
        synchronized (this) {
            z = this.camera != null;
        }
        return z;
    }

    public synchronized void closeDriver() {
        synchronized (this) {
            if (this.camera != null) {
                this.camera.release();
                this.camera = null;
                this.framingRect = null;
                this.framingRectInPreview = null;
            }
        }
    }

    public synchronized void startPreview() {
        AutoFocusManager autoFocusManager2;
        synchronized (this) {
            Camera theCamera = this.camera;
            if (theCamera != null && !this.previewing) {
                theCamera.startPreview();
                this.previewing = true;
                new AutoFocusManager(this.context, this.camera);
                this.autoFocusManager = autoFocusManager2;
            }
        }
    }

    public synchronized void stopPreview() {
        synchronized (this) {
            if (this.autoFocusManager != null) {
                this.autoFocusManager.stop();
                this.autoFocusManager = null;
            }
            if (this.camera != null && this.previewing) {
                this.camera.stopPreview();
                this.previewCallback.setHandler((Handler) null, 0);
                this.previewing = false;
            }
        }
    }

    public synchronized void setTorch(boolean z) {
        boolean newSetting = z;
        synchronized (this) {
            if (this.camera != null) {
                if (this.autoFocusManager != null) {
                    this.autoFocusManager.stop();
                }
                this.configManager.setTorch(this.camera, newSetting);
                if (this.autoFocusManager != null) {
                    this.autoFocusManager.start();
                }
            }
        }
    }

    public synchronized void requestPreviewFrame(Handler handler, int i) {
        Handler handler2 = handler;
        int message = i;
        synchronized (this) {
            Camera theCamera = this.camera;
            if (theCamera != null && this.previewing) {
                this.previewCallback.setHandler(handler2, message);
                theCamera.setOneShotPreviewCallback(this.previewCallback);
            }
        }
    }

    public synchronized Rect getFramingRect() {
        Rect rect;
        Rect rect2;
        StringBuilder sb;
        synchronized (this) {
            if (this.framingRect == null) {
                if (this.camera == null) {
                    rect = null;
                } else {
                    Point screenResolution = this.configManager.getScreenResolution();
                    if (screenResolution == null) {
                        rect = null;
                    } else {
                        int width = (screenResolution.x * 3) / 4;
                        if (width < 240) {
                            width = 240;
                        }
                        int height = width;
                        int leftOffset = (screenResolution.x - width) / 2;
                        int topOffset = (screenResolution.y - height) / 2;
                        new Rect(leftOffset, topOffset, leftOffset + width, topOffset + height);
                        this.framingRect = rect2;
                        String str = TAG;
                        new StringBuilder();
                        int d = Log.d(str, sb.append("Calculated framing rect: ").append(this.framingRect).toString());
                    }
                }
            }
            rect = this.framingRect;
        }
        return rect;
    }

    public synchronized Rect getFramingRectInPreview() {
        Rect rect;
        Rect rect2;
        synchronized (this) {
            if (this.framingRectInPreview == null) {
                Rect framingRect2 = getFramingRect();
                if (framingRect2 == null) {
                    rect = null;
                } else {
                    new Rect(framingRect2);
                    Rect rect3 = rect2;
                    Point cameraResolution = this.configManager.getCameraResolution();
                    Point screenResolution = this.configManager.getScreenResolution();
                    if (cameraResolution == null || screenResolution == null) {
                        rect = null;
                    } else {
                        rect3.left = (rect3.left * cameraResolution.y) / screenResolution.x;
                        rect3.right = (rect3.right * cameraResolution.y) / screenResolution.x;
                        rect3.top = (rect3.top * cameraResolution.x) / screenResolution.y;
                        rect3.bottom = (rect3.bottom * cameraResolution.x) / screenResolution.y;
                        this.framingRectInPreview = rect3;
                    }
                }
            }
            rect = this.framingRectInPreview;
        }
        return rect;
    }

    public synchronized void setManualFramingRect(int i, int i2) {
        Rect rect;
        StringBuilder sb;
        int width = i;
        int height = i2;
        synchronized (this) {
            if (this.initialized) {
                Point screenResolution = this.configManager.getScreenResolution();
                if (width > screenResolution.x) {
                    width = screenResolution.x;
                }
                if (height > screenResolution.y) {
                    height = screenResolution.y;
                }
                int leftOffset = (screenResolution.x - width) / 2;
                int topOffset = (screenResolution.y - height) / 2;
                new Rect(leftOffset, topOffset, leftOffset + width, topOffset + height);
                this.framingRect = rect;
                String str = TAG;
                new StringBuilder();
                int d = Log.d(str, sb.append("Calculated manual framing rect: ").append(this.framingRect).toString());
                this.framingRectInPreview = null;
            } else {
                this.requestedFramingRectWidth = width;
                this.requestedFramingRectHeight = height;
            }
        }
    }

    public PlanarYUVLuminanceSource buildLuminanceSource(byte[] bArr, int i, int i2) {
        PlanarYUVLuminanceSource planarYUVLuminanceSource;
        byte[] data = bArr;
        int width = i;
        int height = i2;
        Rect rect = getFramingRectInPreview();
        if (rect == null) {
            return null;
        }
        new PlanarYUVLuminanceSource(data, width, height, rect.left, rect.top, rect.width(), rect.height(), false);
        return planarYUVLuminanceSource;
    }
}
