package com.google.zxing.client.result;

import com.google.zxing.Result;

public final class BookmarkDoCoMoResultParser extends AbstractDoCoMoResultParser {
    public BookmarkDoCoMoResultParser() {
    }

    public URIParsedResult parse(Result result) {
        URIParsedResult uRIParsedResult;
        URIParsedResult uRIParsedResult2;
        String rawText = result.getText();
        if (!rawText.startsWith("MEBKM:")) {
            return null;
        }
        String title = matchSingleDoCoMoPrefixedField("TITLE:", rawText, true);
        String[] rawUri = matchDoCoMoPrefixedField("URL:", rawText, true);
        if (rawUri == null) {
            return null;
        }
        String uri = rawUri[0];
        if (URIResultParser.isBasicallyValidURI(uri)) {
            uRIParsedResult = uRIParsedResult2;
            new URIParsedResult(uri, title);
        } else {
            uRIParsedResult = null;
        }
        return uRIParsedResult;
    }
}
