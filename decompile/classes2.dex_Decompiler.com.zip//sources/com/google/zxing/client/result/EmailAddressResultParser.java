package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.Map;

public final class EmailAddressResultParser extends ResultParser {
    public EmailAddressResultParser() {
    }

    public EmailAddressParsedResult parse(Result result) {
        EmailAddressParsedResult emailAddressParsedResult;
        EmailAddressParsedResult emailAddressParsedResult2;
        StringBuilder sb;
        String rawText = getMassagedText(result);
        if (rawText.startsWith("mailto:") || rawText.startsWith("MAILTO:")) {
            String emailAddress = rawText.substring(7);
            int queryStart = emailAddress.indexOf(63);
            if (queryStart >= 0) {
                emailAddress = emailAddress.substring(0, queryStart);
            }
            Map<String, String> nameValues = parseNameValuePairs(rawText);
            String subject = null;
            String body = null;
            if (nameValues != null) {
                if (emailAddress.length() == 0) {
                    emailAddress = nameValues.get("to");
                }
                subject = nameValues.get("subject");
                body = nameValues.get("body");
            }
            new EmailAddressParsedResult(emailAddress, subject, body, rawText);
            return emailAddressParsedResult;
        } else if (!EmailDoCoMoResultParser.isBasicallyValidEmailAddress(rawText)) {
            return null;
        } else {
            String emailAddress2 = rawText;
            new StringBuilder();
            new EmailAddressParsedResult(emailAddress2, (String) null, (String) null, sb.append("mailto:").append(emailAddress2).toString());
            return emailAddressParsedResult2;
        }
    }
}
