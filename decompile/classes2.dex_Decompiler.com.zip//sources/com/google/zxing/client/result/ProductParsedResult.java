package com.google.zxing.client.result;

public final class ProductParsedResult extends ParsedResult {
    private final String normalizedProductID;
    private final String productID;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    ProductParsedResult(java.lang.String r6) {
        /*
            r5 = this;
            r0 = r5
            r1 = r6
            r2 = r0
            r3 = r1
            r4 = r1
            r2.<init>(r3, r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.client.result.ProductParsedResult.<init>(java.lang.String):void");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    ProductParsedResult(String productID2, String normalizedProductID2) {
        super(ParsedResultType.PRODUCT);
        this.productID = productID2;
        this.normalizedProductID = normalizedProductID2;
    }

    public String getProductID() {
        return this.productID;
    }

    public String getNormalizedProductID() {
        return this.normalizedProductID;
    }

    public String getDisplayResult() {
        return this.productID;
    }
}
