package com.google.zxing.client.android.camera.open;

import android.hardware.Camera;

public interface OpenCameraInterface {
    Camera open();
}
