package com.google.zxing.client.android;

import android.util.Log;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;

public final class HttpHelper {
    private static final Collection<String> REDIRECTOR_DOMAINS;
    private static final String TAG = HttpHelper.class.getSimpleName();

    public enum ContentType {
    }

    static {
        Collection<String> collection;
        Collection<String> collection2 = collection;
        String[] strArr = new String[16];
        strArr[0] = "amzn.to";
        String[] strArr2 = strArr;
        strArr2[1] = "bit.ly";
        String[] strArr3 = strArr2;
        strArr3[2] = "bitly.com";
        String[] strArr4 = strArr3;
        strArr4[3] = "fb.me";
        String[] strArr5 = strArr4;
        strArr5[4] = "goo.gl";
        String[] strArr6 = strArr5;
        strArr6[5] = "is.gd";
        String[] strArr7 = strArr6;
        strArr7[6] = "j.mp";
        String[] strArr8 = strArr7;
        strArr8[7] = "lnkd.in";
        String[] strArr9 = strArr8;
        strArr9[8] = "ow.ly";
        String[] strArr10 = strArr9;
        strArr10[9] = "R.BEETAGG.COM";
        String[] strArr11 = strArr10;
        strArr11[10] = "r.beetagg.com";
        String[] strArr12 = strArr11;
        strArr12[11] = "SCN.BY";
        String[] strArr13 = strArr12;
        strArr13[12] = "su.pr";
        String[] strArr14 = strArr13;
        strArr14[13] = "t.co";
        String[] strArr15 = strArr14;
        strArr15[14] = "tinyurl.com";
        String[] strArr16 = strArr15;
        strArr16[15] = "tr.im";
        new HashSet(Arrays.asList(strArr16));
        REDIRECTOR_DOMAINS = collection2;
    }

    private HttpHelper() {
    }

    public static CharSequence downloadViaHttp(String uri, ContentType type) throws IOException {
        return downloadViaHttp(uri, type, Integer.MAX_VALUE);
    }

    public static CharSequence downloadViaHttp(String str, ContentType type, int i) throws IOException {
        String contentTypes;
        String uri = str;
        int maxChars = i;
        switch (type) {
            case HTML:
                contentTypes = "application/xhtml+xml,text/html,text/*,*/*";
                break;
            case JSON:
                contentTypes = "application/json,text/*,*/*";
                break;
            default:
                contentTypes = "text/*,*/*";
                break;
        }
        return downloadViaHttp(uri, contentTypes, maxChars);
    }

    private static CharSequence downloadViaHttp(String str, String str2, int i) throws IOException {
        StringBuilder sb;
        URL url;
        StringBuilder sb2;
        Throwable th;
        StringBuilder sb3;
        Throwable th2;
        StringBuilder sb4;
        Throwable th3;
        StringBuilder sb5;
        Throwable th4;
        StringBuilder sb6;
        Throwable th5;
        String uri = str;
        String contentTypes = str2;
        int maxChars = i;
        String str3 = TAG;
        new StringBuilder();
        int i2 = Log.i(str3, sb.append("Downloading ").append(uri).toString());
        new URL(uri);
        URLConnection conn = url.openConnection();
        if (!(conn instanceof HttpURLConnection)) {
            Throwable th6 = th5;
            new IOException();
            throw th6;
        }
        HttpURLConnection connection = (HttpURLConnection) conn;
        connection.setRequestProperty("Accept", contentTypes);
        connection.setRequestProperty("Accept-Charset", "utf-8,*");
        connection.setRequestProperty("User-Agent", "ZXing (Android)");
        try {
            connection.connect();
            int responseCode = connection.getResponseCode();
            if (responseCode != 200) {
                Throwable th7 = th4;
                new StringBuilder();
                new IOException(sb6.append("Bad HTTP response: ").append(responseCode).toString());
                throw th7;
            }
            String str4 = TAG;
            new StringBuilder();
            int i3 = Log.i(str4, sb5.append("Consuming ").append(uri).toString());
            CharSequence consume = consume(connection, maxChars);
            connection.disconnect();
            return consume;
        } catch (NullPointerException e) {
            NullPointerException npe = e;
            String str5 = TAG;
            new StringBuilder();
            int w = Log.w(str5, sb4.append("Bad URI? ").append(uri).toString());
            Throwable th8 = th3;
            new IOException(npe);
            throw th8;
        } catch (NullPointerException e2) {
            NullPointerException npe2 = e2;
            String str6 = TAG;
            new StringBuilder();
            int w2 = Log.w(str6, sb3.append("Bad URI? ").append(uri).toString());
            Throwable th9 = th2;
            new IOException(npe2);
            throw th9;
        } catch (IllegalArgumentException e3) {
            IllegalArgumentException iae = e3;
            String str7 = TAG;
            new StringBuilder();
            int w3 = Log.w(str7, sb2.append("Bad URI? ").append(uri).toString());
            Throwable th10 = th;
            new IOException(iae);
            throw th10;
        } catch (Throwable th11) {
            Throwable th12 = th11;
            connection.disconnect();
            throw th12;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x000d, code lost:
        r2 = r1.indexOf("charset=");
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static java.lang.String getEncoding(java.net.URLConnection r6) {
        /*
            r0 = r6
            r3 = r0
            java.lang.String r4 = "Content-Type"
            java.lang.String r3 = r3.getHeaderField(r4)
            r1 = r3
            r3 = r1
            if (r3 == 0) goto L_0x0029
            r3 = r1
            java.lang.String r4 = "charset="
            int r3 = r3.indexOf(r4)
            r2 = r3
            r3 = r2
            if (r3 < 0) goto L_0x0029
            r3 = r1
            r4 = r2
            java.lang.String r5 = "charset="
            int r5 = r5.length()
            int r4 = r4 + r5
            java.lang.String r3 = r3.substring(r4)
            r0 = r3
        L_0x0028:
            return r0
        L_0x0029:
            java.lang.String r3 = "UTF-8"
            r0 = r3
            goto L_0x0028
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.client.android.HttpHelper.getEncoding(java.net.URLConnection):java.lang.String");
    }

    /* JADX INFO: finally extract failed */
    private static CharSequence consume(URLConnection uRLConnection, int i) throws IOException {
        StringBuilder sb;
        Reader reader;
        URLConnection connection = uRLConnection;
        int maxChars = i;
        String encoding = getEncoding(connection);
        new StringBuilder();
        StringBuilder out = sb;
        try {
            new InputStreamReader(connection.getInputStream(), encoding);
            Reader in = reader;
            char[] buffer = new char[1024];
            while (out.length() < maxChars) {
                int read = in.read(buffer);
                int charsRead = read;
                if (read <= 0) {
                    break;
                }
                StringBuilder append = out.append(buffer, 0, charsRead);
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    IOException iOException = e;
                } catch (NullPointerException e2) {
                    NullPointerException nullPointerException = e2;
                }
            }
            return out;
        } catch (Throwable th) {
            Throwable th2 = th;
            if (0 != 0) {
                Reader reader2 = null;
                try {
                    reader2.close();
                } catch (IOException e3) {
                    IOException iOException2 = e3;
                } catch (NullPointerException e4) {
                    NullPointerException nullPointerException2 = e4;
                }
            }
            throw th2;
        }
    }

    public static URI unredirect(URI uri) throws IOException {
        StringBuilder sb;
        Throwable th;
        StringBuilder sb2;
        Throwable th2;
        StringBuilder sb3;
        Throwable th3;
        URI uri2;
        Throwable th4;
        URI uri3 = uri;
        if (!REDIRECTOR_DOMAINS.contains(uri3.getHost())) {
            return uri3;
        }
        URLConnection conn = uri3.toURL().openConnection();
        if (!(conn instanceof HttpURLConnection)) {
            Throwable th5 = th4;
            new IOException();
            throw th5;
        }
        HttpURLConnection connection = (HttpURLConnection) conn;
        connection.setInstanceFollowRedirects(false);
        connection.setDoInput(false);
        connection.setRequestMethod("HEAD");
        connection.setRequestProperty("User-Agent", "ZXing (Android)");
        try {
            connection.connect();
            switch (connection.getResponseCode()) {
                case 300:
                case 301:
                case 302:
                case 303:
                case 307:
                    String location = connection.getHeaderField("Location");
                    if (location != null) {
                        try {
                            URI uri4 = uri2;
                            new URI(location);
                            URI uri5 = uri4;
                            connection.disconnect();
                            return uri5;
                        } catch (URISyntaxException e) {
                            URISyntaxException uRISyntaxException = e;
                            break;
                        }
                    }
                    break;
            }
            URI uri6 = uri3;
            connection.disconnect();
            return uri6;
        } catch (NullPointerException e2) {
            NullPointerException npe = e2;
            String str = TAG;
            new StringBuilder();
            int w = Log.w(str, sb3.append("Bad URI? ").append(uri3).toString());
            Throwable th6 = th3;
            new IOException(npe);
            throw th6;
        } catch (NullPointerException e3) {
            NullPointerException npe2 = e3;
            String str2 = TAG;
            new StringBuilder();
            int w2 = Log.w(str2, sb2.append("Bad URI? ").append(uri3).toString());
            Throwable th7 = th2;
            new IOException(npe2);
            throw th7;
        } catch (IllegalArgumentException e4) {
            IllegalArgumentException iae = e4;
            String str3 = TAG;
            new StringBuilder();
            int w3 = Log.w(str3, sb.append("Bad URI? ").append(uri3).toString());
            Throwable th8 = th;
            new IOException(iae);
            throw th8;
        } catch (Throwable th9) {
            Throwable th10 = th9;
            connection.disconnect();
            throw th10;
        }
    }
}
