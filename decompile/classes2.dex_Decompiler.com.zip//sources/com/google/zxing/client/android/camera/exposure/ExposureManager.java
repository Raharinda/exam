package com.google.zxing.client.android.camera.exposure;

import com.google.zxing.client.android.common.PlatformSupportManager;

public final class ExposureManager extends PlatformSupportManager<ExposureInterface> {
    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ExposureManager() {
        /*
            r6 = this;
            r0 = r6
            r1 = r0
            java.lang.Class<com.google.zxing.client.android.camera.exposure.ExposureInterface> r2 = com.google.zxing.client.android.camera.exposure.ExposureInterface.class
            com.google.zxing.client.android.camera.exposure.DefaultExposureInterface r3 = new com.google.zxing.client.android.camera.exposure.DefaultExposureInterface
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r1.<init>(r2, r3)
            r1 = r0
            r2 = 8
            java.lang.String r3 = "com.google.zxing.client.android.camera.exposure.FroyoExposureInterface"
            r1.addImplementationClass(r2, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.client.android.camera.exposure.ExposureManager.<init>():void");
    }
}
