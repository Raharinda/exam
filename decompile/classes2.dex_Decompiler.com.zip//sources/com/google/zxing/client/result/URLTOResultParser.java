package com.google.zxing.client.result;

import com.google.zxing.Result;

public final class URLTOResultParser extends ResultParser {
    public URLTOResultParser() {
    }

    public URIParsedResult parse(Result result) {
        URIParsedResult uRIParsedResult;
        String rawText = getMassagedText(result);
        if (!rawText.startsWith("urlto:") && !rawText.startsWith("URLTO:")) {
            return null;
        }
        int titleEnd = rawText.indexOf(58, 6);
        if (titleEnd < 0) {
            return null;
        }
        new URIParsedResult(rawText.substring(titleEnd + 1), titleEnd <= 6 ? null : rawText.substring(6, titleEnd));
        return uRIParsedResult;
    }
}
