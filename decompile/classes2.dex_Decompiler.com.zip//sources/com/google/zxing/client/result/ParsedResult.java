package com.google.zxing.client.result;

public abstract class ParsedResult {
    private final ParsedResultType type;

    public abstract String getDisplayResult();

    protected ParsedResult(ParsedResultType type2) {
        this.type = type2;
    }

    public final ParsedResultType getType() {
        return this.type;
    }

    public final String toString() {
        return getDisplayResult();
    }

    public static void maybeAppend(String str, StringBuilder sb) {
        String value = str;
        StringBuilder result = sb;
        if (value != null && value.length() > 0) {
            if (result.length() > 0) {
                StringBuilder append = result.append(10);
            }
            StringBuilder append2 = result.append(value);
        }
    }

    public static void maybeAppend(String[] strArr, StringBuilder sb) {
        String[] value = strArr;
        StringBuilder result = sb;
        if (value != null) {
            String[] arr$ = value;
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                String s = arr$[i$];
                if (s != null && s.length() > 0) {
                    if (result.length() > 0) {
                        StringBuilder append = result.append(10);
                    }
                    StringBuilder append2 = result.append(s);
                }
            }
        }
    }
}
