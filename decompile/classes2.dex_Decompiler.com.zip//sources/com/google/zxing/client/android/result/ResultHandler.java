package com.google.zxing.client.android.result;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import com.google.zxing.Result;
import com.google.zxing.client.android.Contents;
import com.google.zxing.client.android.LocaleManager;
import com.google.zxing.client.result.ParsedResult;
import com.google.zxing.client.result.ParsedResultType;
import com.google.zxing.client.result.ResultParser;
import java.util.Locale;

public abstract class ResultHandler {
    private static final String[] ADDRESS_TYPE_STRINGS;
    private static final int[] ADDRESS_TYPE_VALUES = {1, 2};
    private static final String[] EMAIL_TYPE_STRINGS;
    private static final int[] EMAIL_TYPE_VALUES = {1, 2, 4};
    private static final String GOOGLE_SHOPPER_ACTIVITY = "com.google.android.apps.shopper.results.SearchResultsActivity";
    private static final String GOOGLE_SHOPPER_PACKAGE = "com.google.android.apps.shopper";
    private static final String MARKET_REFERRER_SUFFIX = "&referrer=utm_source%3Dbarcodescanner%26utm_medium%3Dapps%26utm_campaign%3Dscan";
    private static final String MARKET_URI_PREFIX = "market://details?id=";
    public static final int MAX_BUTTON_COUNT = 4;
    private static final int NO_TYPE = -1;
    private static final String[] PHONE_TYPE_STRINGS;
    private static final int[] PHONE_TYPE_VALUES = {1, 3, 2, 4, 6, 12};
    private static final String TAG = ResultHandler.class.getSimpleName();
    private final Activity activity;
    private final String customProductSearch;
    private final Result rawResult;
    private final ParsedResult result;
    private final DialogInterface.OnClickListener shopperMarketListener;

    public abstract int getButtonCount();

    public abstract int getButtonText(int i);

    public abstract int getDisplayTitle();

    public abstract void handleButtonPress(int i);

    static {
        String[] strArr = new String[3];
        strArr[0] = "home";
        String[] strArr2 = strArr;
        strArr2[1] = "work";
        String[] strArr3 = strArr2;
        strArr3[2] = "mobile";
        EMAIL_TYPE_STRINGS = strArr3;
        String[] strArr4 = new String[6];
        strArr4[0] = "home";
        String[] strArr5 = strArr4;
        strArr5[1] = "work";
        String[] strArr6 = strArr5;
        strArr6[2] = "mobile";
        String[] strArr7 = strArr6;
        strArr7[3] = "fax";
        String[] strArr8 = strArr7;
        strArr8[4] = "pager";
        String[] strArr9 = strArr8;
        strArr9[5] = "main";
        PHONE_TYPE_STRINGS = strArr9;
        String[] strArr10 = new String[2];
        strArr10[0] = "home";
        String[] strArr11 = strArr10;
        strArr11[1] = "work";
        ADDRESS_TYPE_STRINGS = strArr11;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    ResultHandler(Activity activity2, ParsedResult result2) {
        this(activity2, result2, (Result) null);
    }

    ResultHandler(Activity activity2, ParsedResult result2, Result rawResult2) {
        DialogInterface.OnClickListener onClickListener;
        new DialogInterface.OnClickListener(this) {
            final /* synthetic */ ResultHandler this$0;

            {
                this.this$0 = this$0;
            }

            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent;
                DialogInterface dialogInterface2 = dialogInterface;
                int i2 = i;
                new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.google.android.apps.shopper&referrer=utm_source%3Dbarcodescanner%26utm_medium%3Dapps%26utm_campaign%3Dscan"));
                this.this$0.launchIntent(intent);
            }
        };
        this.shopperMarketListener = onClickListener;
        this.result = result2;
        this.activity = activity2;
        this.rawResult = rawResult2;
        this.customProductSearch = parseCustomSearchURL();
    }

    public ParsedResult getResult() {
        return this.result;
    }

    /* access modifiers changed from: package-private */
    public boolean hasCustomProductSearch() {
        return this.customProductSearch != null;
    }

    /* access modifiers changed from: package-private */
    public Activity getActivity() {
        return this.activity;
    }

    public boolean areContentsSecure() {
        return false;
    }

    /* access modifiers changed from: package-private */
    public void showGoogleShopperButton(View.OnClickListener listener) {
    }

    public CharSequence getDisplayContents() {
        return this.result.getDisplayResult().replace("\r", "");
    }

    public final ParsedResultType getType() {
        return this.result.getType();
    }

    /* access modifiers changed from: package-private */
    public final void addPhoneOnlyContact(String[] phoneNumbers, String[] phoneTypes) {
        addContact((String[]) null, (String) null, phoneNumbers, phoneTypes, (String[]) null, (String[]) null, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null);
    }

    /* access modifiers changed from: package-private */
    public final void addEmailOnlyContact(String[] emails, String[] emailTypes) {
        addContact((String[]) null, (String) null, (String[]) null, (String[]) null, emails, emailTypes, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null);
    }

    /* access modifiers changed from: package-private */
    public final void addContact(String[] strArr, String str, String[] strArr2, String[] strArr3, String[] strArr4, String[] strArr5, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9) {
        Intent intent;
        StringBuilder sb;
        int type;
        int type2;
        int type3;
        String[] names = strArr;
        String pronunciation = str;
        String[] phoneNumbers = strArr2;
        String[] phoneTypes = strArr3;
        String[] emails = strArr4;
        String[] emailTypes = strArr5;
        String note = str2;
        String instantMessenger = str3;
        String address = str4;
        String addressType = str5;
        String org2 = str6;
        String title = str7;
        String url = str8;
        String birthday = str9;
        new Intent("android.intent.action.INSERT_OR_EDIT", ContactsContract.Contacts.CONTENT_URI);
        Intent intent2 = intent;
        Intent type4 = intent2.setType("vnd.android.cursor.item/contact");
        putExtra(intent2, "name", names != null ? names[0] : null);
        putExtra(intent2, "phonetic_name", pronunciation);
        int phoneCount = Math.min(phoneNumbers != null ? phoneNumbers.length : 0, Contents.PHONE_KEYS.length);
        for (int x = 0; x < phoneCount; x++) {
            putExtra(intent2, Contents.PHONE_KEYS[x], phoneNumbers[x]);
            if (phoneTypes != null && x < phoneTypes.length && (type3 = toPhoneContractType(phoneTypes[x])) >= 0) {
                Intent putExtra = intent2.putExtra(Contents.PHONE_TYPE_KEYS[x], type3);
            }
        }
        int emailCount = Math.min(emails != null ? emails.length : 0, Contents.EMAIL_KEYS.length);
        for (int x2 = 0; x2 < emailCount; x2++) {
            putExtra(intent2, Contents.EMAIL_KEYS[x2], emails[x2]);
            if (emailTypes != null && x2 < emailTypes.length && (type2 = toEmailContractType(emailTypes[x2])) >= 0) {
                Intent putExtra2 = intent2.putExtra(Contents.EMAIL_TYPE_KEYS[x2], type2);
            }
        }
        new StringBuilder();
        StringBuilder aggregatedNotes = sb;
        String[] strArr6 = new String[3];
        strArr6[0] = url;
        String[] strArr7 = strArr6;
        strArr7[1] = birthday;
        String[] strArr8 = strArr7;
        strArr8[2] = note;
        String[] strArr9 = strArr8;
        int length = strArr9.length;
        for (int i = 0; i < length; i++) {
            String aNote = strArr9[i];
            if (aNote != null) {
                if (aggregatedNotes.length() > 0) {
                    StringBuilder append = aggregatedNotes.append(10);
                }
                StringBuilder append2 = aggregatedNotes.append(aNote);
            }
        }
        if (aggregatedNotes.length() > 0) {
            putExtra(intent2, "notes", aggregatedNotes.toString());
        }
        putExtra(intent2, "im_handle", instantMessenger);
        putExtra(intent2, "postal", address);
        if (addressType != null && (type = toAddressContractType(addressType)) >= 0) {
            Intent putExtra3 = intent2.putExtra("postal_type", type);
        }
        putExtra(intent2, "company", org2);
        putExtra(intent2, "job_title", title);
        launchIntent(intent2);
    }

    private static int toEmailContractType(String typeString) {
        return doToContractType(typeString, EMAIL_TYPE_STRINGS, EMAIL_TYPE_VALUES);
    }

    private static int toPhoneContractType(String typeString) {
        return doToContractType(typeString, PHONE_TYPE_STRINGS, PHONE_TYPE_VALUES);
    }

    private static int toAddressContractType(String typeString) {
        return doToContractType(typeString, ADDRESS_TYPE_STRINGS, ADDRESS_TYPE_VALUES);
    }

    private static int doToContractType(String str, String[] strArr, int[] iArr) {
        String typeString = str;
        String[] types = strArr;
        int[] values = iArr;
        if (typeString == null) {
            return -1;
        }
        for (int i = 0; i < types.length; i++) {
            String type = types[i];
            if (typeString.startsWith(type) || typeString.startsWith(type.toUpperCase(Locale.ENGLISH))) {
                return values[i];
            }
        }
        return -1;
    }

    /* access modifiers changed from: package-private */
    public final void shareByEmail(String contents) {
    }

    /* access modifiers changed from: package-private */
    public final void sendEmail(String str, String subject, String body) {
        StringBuilder sb;
        String address = str;
        new StringBuilder();
        sendEmailFromUri(sb.append("mailto:").append(address).toString(), address, subject, body);
    }

    /* access modifiers changed from: package-private */
    public final void sendEmailFromUri(String uri, String str, String str2, String str3) {
        Intent intent;
        String email = str;
        String subject = str2;
        String body = str3;
        new Intent("android.intent.action.SEND", Uri.parse(uri));
        Intent intent2 = intent;
        if (email != null) {
            Intent putExtra = intent2.putExtra("android.intent.extra.EMAIL", new String[]{email});
        }
        putExtra(intent2, "android.intent.extra.SUBJECT", subject);
        putExtra(intent2, "android.intent.extra.TEXT", body);
        Intent type = intent2.setType("text/plain");
        launchIntent(intent2);
    }

    /* access modifiers changed from: package-private */
    public final void shareBySMS(String contents) {
    }

    /* access modifiers changed from: package-private */
    public final void sendSMS(String phoneNumber, String body) {
        StringBuilder sb;
        new StringBuilder();
        sendSMSFromUri(sb.append("smsto:").append(phoneNumber).toString(), body);
    }

    /* access modifiers changed from: package-private */
    public final void sendSMSFromUri(String uri, String body) {
        Intent intent;
        new Intent("android.intent.action.SENDTO", Uri.parse(uri));
        Intent intent2 = intent;
        putExtra(intent2, "sms_body", body);
        Intent putExtra = intent2.putExtra("compose_mode", true);
        launchIntent(intent2);
    }

    /* access modifiers changed from: package-private */
    public final void sendMMS(String phoneNumber, String subject, String body) {
        StringBuilder sb;
        new StringBuilder();
        sendMMSFromUri(sb.append("mmsto:").append(phoneNumber).toString(), subject, body);
    }

    /* access modifiers changed from: package-private */
    public final void sendMMSFromUri(String uri, String subject, String body) {
    }

    /* access modifiers changed from: package-private */
    public final void dialPhone(String phoneNumber) {
        Intent intent;
        StringBuilder sb;
        new StringBuilder();
        new Intent("android.intent.action.DIAL", Uri.parse(sb.append("tel:").append(phoneNumber).toString()));
        launchIntent(intent);
    }

    /* access modifiers changed from: package-private */
    public final void dialPhoneFromUri(String uri) {
        Intent intent;
        new Intent("android.intent.action.DIAL", Uri.parse(uri));
        launchIntent(intent);
    }

    /* access modifiers changed from: package-private */
    public final void openMap(String geoURI) {
        Intent intent;
        new Intent("android.intent.action.VIEW", Uri.parse(geoURI));
        launchIntent(intent);
    }

    /* access modifiers changed from: package-private */
    public final void searchMap(String address, CharSequence charSequence) {
        Intent intent;
        StringBuilder sb;
        StringBuilder sb2;
        CharSequence title = charSequence;
        String query = address;
        if (title != null && title.length() > 0) {
            new StringBuilder();
            query = sb2.append(query).append(" (").append(title).append(')').toString();
        }
        new StringBuilder();
        new Intent("android.intent.action.VIEW", Uri.parse(sb.append("geo:0,0?q=").append(Uri.encode(query)).toString()));
        launchIntent(intent);
    }

    /* access modifiers changed from: package-private */
    public final void getDirections(double latitude, double longitude) {
        Intent intent;
        StringBuilder sb;
        new StringBuilder();
        new Intent("android.intent.action.VIEW", Uri.parse(sb.append("http://maps.google.").append(LocaleManager.getCountryTLD(this.activity)).append("/maps?f=d&daddr=").append(latitude).append(',').append(longitude).toString()));
        launchIntent(intent);
    }

    /* access modifiers changed from: package-private */
    public final void openProductSearch(String upc) {
        StringBuilder sb;
        Intent intent;
        new StringBuilder();
        new Intent("android.intent.action.VIEW", Uri.parse(sb.append("http://www.google.").append(LocaleManager.getProductSearchCountryTLD(this.activity)).append("/m/products?q=").append(upc).append("&source=zxing").toString()));
        launchIntent(intent);
    }

    /* access modifiers changed from: package-private */
    public final void openBookSearch(String isbn) {
        StringBuilder sb;
        Intent intent;
        new StringBuilder();
        new Intent("android.intent.action.VIEW", Uri.parse(sb.append("http://books.google.").append(LocaleManager.getBookSearchCountryTLD(this.activity)).append("/books?vid=isbn").append(isbn).toString()));
        launchIntent(intent);
    }

    /* access modifiers changed from: package-private */
    public final void searchBookContents(String isbnOrUrl) {
    }

    /* access modifiers changed from: package-private */
    public final void openURL(String str) {
        StringBuilder sb;
        Intent intent;
        StringBuilder sb2;
        StringBuilder sb3;
        String url = str;
        if (url.startsWith("HTTP://")) {
            new StringBuilder();
            url = sb3.append("http").append(url.substring(4)).toString();
        } else if (url.startsWith("HTTPS://")) {
            new StringBuilder();
            url = sb.append("https").append(url.substring(5)).toString();
        }
        new Intent("android.intent.action.VIEW", Uri.parse(url));
        Intent intent2 = intent;
        try {
            launchIntent(intent2);
        } catch (ActivityNotFoundException e) {
            ActivityNotFoundException activityNotFoundException = e;
            String str2 = TAG;
            new StringBuilder();
            int w = Log.w(str2, sb2.append("Nothing available to handle ").append(intent2).toString());
        }
    }

    /* access modifiers changed from: package-private */
    public final void webSearch(String query) {
        Intent intent;
        new Intent("android.intent.action.WEB_SEARCH");
        Intent intent2 = intent;
        Intent putExtra = intent2.putExtra("query", query);
        launchIntent(intent2);
    }

    /* access modifiers changed from: package-private */
    public final void openGoogleShopper(String query) {
    }

    /* access modifiers changed from: package-private */
    public void rawLaunchIntent(Intent intent) {
        StringBuilder sb;
        Intent intent2 = intent;
        if (intent2 != null) {
            Intent addFlags = intent2.addFlags(524288);
            String str = TAG;
            new StringBuilder();
            int d = Log.d(str, sb.append("Launching intent: ").append(intent2).append(" with extras: ").append(intent2.getExtras()).toString());
            this.activity.startActivity(intent2);
        }
    }

    /* access modifiers changed from: package-private */
    public void launchIntent(Intent intent) {
        try {
            rawLaunchIntent(intent);
        } catch (ActivityNotFoundException e) {
            ActivityNotFoundException activityNotFoundException = e;
        }
    }

    private static void putExtra(Intent intent, String str, String str2) {
        Intent intent2 = intent;
        String key = str;
        String value = str2;
        if (value != null && value.length() > 0) {
            Intent putExtra = intent2.putExtra(key, value);
        }
    }

    private String parseCustomSearchURL() {
        return null;
    }

    /* access modifiers changed from: package-private */
    public String fillInCustomSearchURL(String str) {
        String text = str;
        if (this.customProductSearch == null) {
            return text;
        }
        String url = this.customProductSearch.replace("%s", text);
        if (this.rawResult != null) {
            url = url.replace("%f", this.rawResult.getBarcodeFormat().toString());
            if (url.contains("%t")) {
                url = url.replace("%t", ResultParser.parseResult(this.rawResult).getType().toString());
            }
        }
        return url;
    }
}
