package com.google.zxing.client.android.common;

import android.os.Build;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.SortedMap;
import java.util.TreeMap;

public abstract class PlatformSupportManager<T> {
    private static final String TAG = PlatformSupportManager.class.getSimpleName();
    private final T defaultImplementation;
    private final SortedMap<Integer, String> implementations;
    private final Class<T> managedInterface;

    protected PlatformSupportManager(Class<T> cls, T t) {
        SortedMap<Integer, String> sortedMap;
        Throwable th;
        Throwable th2;
        Class<T> managedInterface2 = cls;
        T defaultImplementation2 = t;
        if (!managedInterface2.isInterface()) {
            Throwable th3 = th2;
            new IllegalArgumentException();
            throw th3;
        } else if (!managedInterface2.isInstance(defaultImplementation2)) {
            Throwable th4 = th;
            new IllegalArgumentException();
            throw th4;
        } else {
            this.managedInterface = managedInterface2;
            this.defaultImplementation = defaultImplementation2;
            new TreeMap(Collections.reverseOrder());
            this.implementations = sortedMap;
        }
    }

    /* access modifiers changed from: protected */
    public void addImplementationClass(int minVersion, String className) {
        Object put = this.implementations.put(Integer.valueOf(minVersion), className);
    }

    public T build() {
        StringBuilder sb;
        StringBuilder sb2;
        for (Integer minVersion : this.implementations.keySet()) {
            if (Build.VERSION.SDK_INT >= minVersion.intValue()) {
                try {
                    Class<? extends U> asSubclass = Class.forName((String) this.implementations.get(minVersion)).asSubclass(this.managedInterface);
                    String str = TAG;
                    new StringBuilder();
                    int i = Log.i(str, sb2.append("Using implementation ").append(asSubclass).append(" of ").append(this.managedInterface).append(" for SDK ").append(minVersion).toString());
                    return asSubclass.getConstructor(new Class[0]).newInstance(new Object[0]);
                } catch (ClassNotFoundException e) {
                    int w = Log.w(TAG, e);
                } catch (IllegalAccessException e2) {
                    int w2 = Log.w(TAG, e2);
                } catch (InstantiationException e3) {
                    int w3 = Log.w(TAG, e3);
                } catch (NoSuchMethodException e4) {
                    int w4 = Log.w(TAG, e4);
                } catch (InvocationTargetException e5) {
                    int w5 = Log.w(TAG, e5);
                }
            }
        }
        String str2 = TAG;
        new StringBuilder();
        int i2 = Log.i(str2, sb.append("Using default implementation ").append(this.defaultImplementation.getClass()).append(" of ").append(this.managedInterface).toString());
        return this.defaultImplementation;
    }
}
