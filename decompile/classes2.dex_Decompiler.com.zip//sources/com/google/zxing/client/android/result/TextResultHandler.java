package com.google.zxing.client.android.result;

import android.app.Activity;
import com.google.zxing.Result;
import com.google.zxing.client.result.ParsedResult;

public final class TextResultHandler extends ResultHandler {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public TextResultHandler(Activity activity, ParsedResult result, Result rawResult) {
        super(activity, result, rawResult);
    }

    public int getButtonCount() {
        return 0;
    }

    public int getButtonText(int i) {
        int i2 = i;
        return 0;
    }

    public void handleButtonPress(int index) {
    }

    public int getDisplayTitle() {
        return 0;
    }
}
