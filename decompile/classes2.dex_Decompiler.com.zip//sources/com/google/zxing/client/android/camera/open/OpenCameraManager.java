package com.google.zxing.client.android.camera.open;

import com.google.zxing.client.android.common.PlatformSupportManager;

public final class OpenCameraManager extends PlatformSupportManager<OpenCameraInterface> {
    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public OpenCameraManager() {
        /*
            r6 = this;
            r0 = r6
            r1 = r0
            java.lang.Class<com.google.zxing.client.android.camera.open.OpenCameraInterface> r2 = com.google.zxing.client.android.camera.open.OpenCameraInterface.class
            com.google.zxing.client.android.camera.open.DefaultOpenCameraInterface r3 = new com.google.zxing.client.android.camera.open.DefaultOpenCameraInterface
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r1.<init>(r2, r3)
            r1 = r0
            r2 = 9
            java.lang.String r3 = "com.google.zxing.client.android.camera.open.GingerbreadOpenCameraInterface"
            r1.addImplementationClass(r2, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.client.android.camera.open.OpenCameraManager.<init>():void");
    }
}
