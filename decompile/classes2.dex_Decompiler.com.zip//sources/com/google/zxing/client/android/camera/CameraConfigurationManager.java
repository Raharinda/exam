package com.google.zxing.client.android.camera;

import android.content.Context;
import android.graphics.Point;
import android.hardware.Camera;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

final class CameraConfigurationManager {
    private static final int AREA_PER_1000 = 400;
    private static final double MAX_ASPECT_DISTORTION = 0.15d;
    private static final float MAX_EXPOSURE_COMPENSATION = 1.5f;
    private static final int MAX_FPS = 20;
    private static final float MIN_EXPOSURE_COMPENSATION = 0.0f;
    private static final int MIN_FPS = 10;
    private static final int MIN_PREVIEW_PIXELS = 153600;
    private static final String TAG = "CameraConfiguration";
    private Point cameraResolution;
    private final Context context;
    private Point screenResolution;

    CameraConfigurationManager(Context context2) {
        this.context = context2;
    }

    /* access modifiers changed from: package-private */
    public void initFromCameraParameters(Camera camera) {
        Point point;
        StringBuilder sb;
        StringBuilder sb2;
        Camera.Parameters parameters = camera.getParameters();
        Display display = ((WindowManager) this.context.getSystemService("window")).getDefaultDisplay();
        new Point();
        this.screenResolution = point;
        HoneycombMR2Util.getSize(display, this.screenResolution);
        new StringBuilder();
        int i = Log.i(TAG, sb.append("Screen resolution: ").append(this.screenResolution).toString());
        this.cameraResolution = findBestPreviewSizeValue(parameters, this.screenResolution);
        new StringBuilder();
        int i2 = Log.i(TAG, sb2.append("Camera resolution: ").append(this.cameraResolution).toString());
    }

    /* access modifiers changed from: package-private */
    public void setDesiredCameraParameters(Camera camera, boolean z) {
        StringBuilder sb;
        String focusMode;
        StringBuilder sb2;
        Camera camera2 = camera;
        boolean safeMode = z;
        Camera.Parameters parameters = camera2.getParameters();
        if (parameters == null) {
            int w = Log.w(TAG, "Device error: no camera parameters are available. Proceeding without configuration.");
            return;
        }
        new StringBuilder();
        int i = Log.i(TAG, sb.append("Initial camera parameters: ").append(parameters.flatten()).toString());
        if (safeMode) {
            int w2 = Log.w(TAG, "In camera config safe mode -- most settings will not be honored");
        }
        initializeTorch(parameters, safeMode);
        if (safeMode) {
            focusMode = findSettableValue(parameters.getSupportedFocusModes(), "auto");
        } else {
            List<String> supportedFocusModes = parameters.getSupportedFocusModes();
            String[] strArr = new String[3];
            strArr[0] = "continuous-picture";
            String[] strArr2 = strArr;
            strArr2[1] = "continuous-video";
            String[] strArr3 = strArr2;
            strArr3[2] = "auto";
            focusMode = findSettableValue(supportedFocusModes, strArr3);
        }
        if (!safeMode && focusMode == null) {
            List<String> supportedFocusModes2 = parameters.getSupportedFocusModes();
            String[] strArr4 = new String[2];
            strArr4[0] = "macro";
            String[] strArr5 = strArr4;
            strArr5[1] = "edof";
            focusMode = findSettableValue(supportedFocusModes2, strArr5);
        }
        if (focusMode != null) {
            parameters.setFocusMode(focusMode);
        }
        new StringBuilder();
        int i2 = Log.i(TAG, sb2.append("Setting Camera Preview Size to: ").append(this.cameraResolution).toString());
        parameters.setPreviewSize(this.cameraResolution.x, this.cameraResolution.y);
        camera2.setParameters(parameters);
        camera2.setDisplayOrientation(90);
    }

    /* access modifiers changed from: package-private */
    public Point getCameraResolution() {
        return this.cameraResolution;
    }

    /* access modifiers changed from: package-private */
    public Point getScreenResolution() {
        return this.screenResolution;
    }

    /* access modifiers changed from: package-private */
    public void setTorch(Camera camera, boolean newSetting) {
        Camera camera2 = camera;
        Camera.Parameters parameters = camera2.getParameters();
        doSetTorch(parameters, newSetting, false);
        camera2.setParameters(parameters);
    }

    private void initializeTorch(Camera.Parameters parameters, boolean safeMode) {
        doSetTorch(parameters, false, safeMode);
    }

    private void doSetTorch(Camera.Parameters parameters, boolean newSetting, boolean z) {
        String flashMode;
        Camera.Parameters parameters2 = parameters;
        boolean z2 = z;
        if (newSetting) {
            List<String> supportedFlashModes = parameters2.getSupportedFlashModes();
            String[] strArr = new String[2];
            strArr[0] = "torch";
            String[] strArr2 = strArr;
            strArr2[1] = "on";
            flashMode = findSettableValue(supportedFlashModes, strArr2);
        } else {
            flashMode = findSettableValue(parameters2.getSupportedFlashModes(), "off");
        }
        if (flashMode != null) {
            parameters2.setFlashMode(flashMode);
        }
    }

    private Point findBestPreviewSizeValue(Camera.Parameters parameters, Point point) {
        List<Camera.Size> list;
        Comparator comparator;
        Point point2;
        StringBuilder sb;
        Throwable th;
        Point point3;
        StringBuilder sb2;
        Point point4;
        StringBuilder sb3;
        StringBuilder sb4;
        StringBuilder sb5;
        Point point5;
        Throwable th2;
        Camera.Parameters parameters2 = parameters;
        Point screenResolution2 = point;
        List<Camera.Size> rawSupportedSizes = parameters2.getSupportedPreviewSizes();
        if (rawSupportedSizes == null) {
            int w = Log.w(TAG, "Device returned no supported preview sizes; using default");
            Camera.Size defaultSize = parameters2.getPreviewSize();
            if (defaultSize == null) {
                Throwable th3 = th2;
                new IllegalStateException("Parameters contained no preview size!");
                throw th3;
            }
            new Point(defaultSize.width, defaultSize.height);
            return point5;
        }
        new ArrayList<>(rawSupportedSizes);
        List<Camera.Size> supportedPreviewSizes = list;
        new Comparator<Camera.Size>(this) {
            final /* synthetic */ CameraConfigurationManager this$0;

            {
                this.this$0 = this$0;
            }

            public int compare(Camera.Size size, Camera.Size size2) {
                Camera.Size a = size;
                Camera.Size b = size2;
                int aPixels = a.height * a.width;
                int bPixels = b.height * b.width;
                if (bPixels < aPixels) {
                    return -1;
                }
                if (bPixels > aPixels) {
                    return 1;
                }
                return 0;
            }
        };
        Collections.sort(supportedPreviewSizes, comparator);
        if (Log.isLoggable(TAG, 4)) {
            new StringBuilder();
            StringBuilder previewSizesString = sb4;
            for (Camera.Size supportedPreviewSize : supportedPreviewSizes) {
                StringBuilder append = previewSizesString.append(supportedPreviewSize.width).append('x').append(supportedPreviewSize.height).append(' ');
            }
            new StringBuilder();
            int i = Log.i(TAG, sb5.append("Supported preview sizes: ").append(previewSizesString).toString());
        }
        double screenAspectRatio = ((double) screenResolution2.x) / ((double) screenResolution2.y);
        Iterator<Camera.Size> it = supportedPreviewSizes.iterator();
        while (it.hasNext()) {
            Camera.Size supportedPreviewSize2 = it.next();
            int realWidth = supportedPreviewSize2.width;
            int realHeight = supportedPreviewSize2.height;
            if (realWidth * realHeight < MIN_PREVIEW_PIXELS) {
                it.remove();
            } else {
                boolean isCandidatePortrait = realWidth < realHeight;
                int maybeFlippedWidth = isCandidatePortrait ? realHeight : realWidth;
                int maybeFlippedHeight = isCandidatePortrait ? realWidth : realHeight;
                if (Math.abs((((double) maybeFlippedWidth) / ((double) maybeFlippedHeight)) - screenAspectRatio) > MAX_ASPECT_DISTORTION) {
                    it.remove();
                } else {
                    if (maybeFlippedWidth == screenResolution2.x && maybeFlippedHeight == screenResolution2.y) {
                        new Point(realWidth, realHeight);
                        Point exactPoint = point4;
                        new StringBuilder();
                        int i2 = Log.i(TAG, sb3.append("Found preview size exactly matching screen size: ").append(exactPoint).toString());
                        return exactPoint;
                    }
                }
            }
        }
        if (!supportedPreviewSizes.isEmpty()) {
            Camera.Size largestPreview = supportedPreviewSizes.get(0);
            new Point(largestPreview.width, largestPreview.height);
            Point largestSize = point3;
            new StringBuilder();
            int i3 = Log.i(TAG, sb2.append("Using largest suitable preview size: ").append(largestSize).toString());
            return largestSize;
        }
        Camera.Size defaultPreview = parameters2.getPreviewSize();
        if (defaultPreview == null) {
            Throwable th4 = th;
            new IllegalStateException("Parameters contained no preview size!");
            throw th4;
        }
        new Point(defaultPreview.width, defaultPreview.height);
        Point defaultSize2 = point2;
        new StringBuilder();
        int i4 = Log.i(TAG, sb.append("No suitable preview sizes, using default: ").append(defaultSize2).toString());
        return defaultSize2;
    }

    private static String findSettableValue(Collection<String> collection, String... strArr) {
        StringBuilder sb;
        StringBuilder sb2;
        Collection<String> supportedValues = collection;
        String[] desiredValues = strArr;
        new StringBuilder();
        int i = Log.i(TAG, sb.append("Supported values: ").append(supportedValues).toString());
        String result = null;
        if (supportedValues != null) {
            String[] strArr2 = desiredValues;
            int length = strArr2.length;
            int i2 = 0;
            while (true) {
                if (i2 >= length) {
                    break;
                }
                String desiredValue = strArr2[i2];
                if (supportedValues.contains(desiredValue)) {
                    result = desiredValue;
                    break;
                }
                i2++;
            }
        }
        new StringBuilder();
        int i3 = Log.i(TAG, sb2.append("Settable value: ").append(result).toString());
        return result;
    }
}
