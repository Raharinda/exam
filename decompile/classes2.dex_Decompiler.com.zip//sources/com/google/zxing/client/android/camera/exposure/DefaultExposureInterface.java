package com.google.zxing.client.android.camera.exposure;

import android.hardware.Camera;

public final class DefaultExposureInterface implements ExposureInterface {
    public DefaultExposureInterface() {
    }

    public void setExposure(Camera.Parameters parameters, boolean lightOn) {
    }
}
