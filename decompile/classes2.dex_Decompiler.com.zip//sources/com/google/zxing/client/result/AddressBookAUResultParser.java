package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.ArrayList;
import java.util.List;

public final class AddressBookAUResultParser extends ResultParser {
    public AddressBookAUResultParser() {
    }

    public AddressBookParsedResult parse(Result result) {
        String[] addresses;
        AddressBookParsedResult addressBookParsedResult;
        String rawText = getMassagedText(result);
        if (!rawText.contains("MEMORY") || !rawText.contains("\r\n")) {
            return null;
        }
        String name = matchSinglePrefixedField("NAME1:", rawText, 13, true);
        String pronunciation = matchSinglePrefixedField("NAME2:", rawText, 13, true);
        String[] phoneNumbers = matchMultipleValuePrefix("TEL", 3, rawText, true);
        String[] emails = matchMultipleValuePrefix("MAIL", 3, rawText, true);
        String note = matchSinglePrefixedField("MEMORY:", rawText, 13, false);
        String address = matchSinglePrefixedField("ADD:", rawText, 13, true);
        if (address == null) {
            addresses = null;
        } else {
            String[] strArr = new String[1];
            addresses = strArr;
            strArr[0] = address;
        }
        new AddressBookParsedResult(maybeWrap(name), pronunciation, phoneNumbers, (String[]) null, emails, (String[]) null, (String) null, note, addresses, (String[]) null, (String) null, (String) null, (String) null, (String) null);
        return addressBookParsedResult;
    }

    private static String[] matchMultipleValuePrefix(String str, int i, String str2, boolean z) {
        StringBuilder sb;
        List<String> list;
        String prefix = str;
        int max = i;
        String rawText = str2;
        boolean trim = z;
        List<String> values = null;
        for (int i2 = 1; i2 <= max; i2++) {
            new StringBuilder();
            String value = matchSinglePrefixedField(sb.append(prefix).append(i2).append(':').toString(), rawText, 13, trim);
            if (value == null) {
                break;
            }
            if (values == null) {
                new ArrayList<>(max);
                values = list;
            }
            boolean add = values.add(value);
        }
        if (values == null) {
            return null;
        }
        return (String[]) values.toArray(new String[values.size()]);
    }
}
