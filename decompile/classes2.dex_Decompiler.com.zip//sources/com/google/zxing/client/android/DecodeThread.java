package com.google.zxing.client.android;

import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.DecodeHintType;
import com.google.zxing.ResultPointCallback;
import java.util.Collection;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

final class DecodeThread extends Thread {
    public static final String BARCODE_BITMAP = "barcode_bitmap";
    private final AppInvCaptureActivity activity;
    private Handler handler;
    private final CountDownLatch handlerInitLatch;
    private final Map<DecodeHintType, Object> hints;

    DecodeThread(AppInvCaptureActivity appInvCaptureActivity, Collection<BarcodeFormat> collection, String str, ResultPointCallback resultPointCallback) {
        CountDownLatch countDownLatch;
        Map<DecodeHintType, Object> map;
        AppInvCaptureActivity activity2 = appInvCaptureActivity;
        Collection<BarcodeFormat> decodeFormats = collection;
        String characterSet = str;
        ResultPointCallback resultPointCallback2 = resultPointCallback;
        this.activity = activity2;
        new CountDownLatch(1);
        this.handlerInitLatch = countDownLatch;
        new EnumMap(DecodeHintType.class);
        this.hints = map;
        if (decodeFormats == null || decodeFormats.isEmpty()) {
            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(activity2);
            decodeFormats = EnumSet.noneOf(BarcodeFormat.class);
            boolean addAll = decodeFormats.addAll(DecodeFormatManager.ONE_D_FORMATS);
            boolean addAll2 = decodeFormats.addAll(DecodeFormatManager.QR_CODE_FORMATS);
        }
        Object put = this.hints.put(DecodeHintType.POSSIBLE_FORMATS, decodeFormats);
        if (characterSet != null) {
            Object put2 = this.hints.put(DecodeHintType.CHARACTER_SET, characterSet);
        }
        Object put3 = this.hints.put(DecodeHintType.NEED_RESULT_POINT_CALLBACK, resultPointCallback2);
    }

    /* access modifiers changed from: package-private */
    public Handler getHandler() {
        try {
            this.handlerInitLatch.await();
        } catch (InterruptedException e) {
            InterruptedException interruptedException = e;
        }
        return this.handler;
    }

    public void run() {
        Handler handler2;
        Looper.prepare();
        new DecodeHandler(this.activity, this.hints);
        this.handler = handler2;
        this.handlerInitLatch.countDown();
        Looper.loop();
    }
}
