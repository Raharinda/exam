package com.google.zxing.client.android;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.util.Log;
import com.google.zxing.client.android.common.executor.AsyncTaskExecInterface;
import com.google.zxing.client.android.common.executor.AsyncTaskExecManager;

final class InactivityTimer {
    private static final long INACTIVITY_DELAY_MS = 300000;
    /* access modifiers changed from: private */
    public static final String TAG = InactivityTimer.class.getSimpleName();
    /* access modifiers changed from: private */
    public final Activity activity;
    private InactivityAsyncTask inactivityTask;
    private final BroadcastReceiver powerStatusReceiver;
    private final AsyncTaskExecInterface taskExec;

    InactivityTimer(Activity activity2) {
        AsyncTaskExecManager asyncTaskExecManager;
        BroadcastReceiver broadcastReceiver;
        this.activity = activity2;
        new AsyncTaskExecManager();
        this.taskExec = (AsyncTaskExecInterface) asyncTaskExecManager.build();
        new PowerStatusReceiver(this, (AnonymousClass1) null);
        this.powerStatusReceiver = broadcastReceiver;
        onActivity();
    }

    /* access modifiers changed from: package-private */
    public synchronized void onActivity() {
        InactivityAsyncTask inactivityAsyncTask;
        synchronized (this) {
            cancel();
            new InactivityAsyncTask(this, (AnonymousClass1) null);
            this.inactivityTask = inactivityAsyncTask;
            this.taskExec.execute(this.inactivityTask, new Object[0]);
        }
    }

    public void onPause() {
        cancel();
        this.activity.unregisterReceiver(this.powerStatusReceiver);
    }

    public void onResume() {
        IntentFilter intentFilter;
        new IntentFilter("android.intent.action.BATTERY_CHANGED");
        Intent registerReceiver = this.activity.registerReceiver(this.powerStatusReceiver, intentFilter);
        onActivity();
    }

    /* access modifiers changed from: private */
    public synchronized void cancel() {
        synchronized (this) {
            AsyncTask<?, ?, ?> task = this.inactivityTask;
            if (task != null) {
                boolean cancel = task.cancel(true);
                this.inactivityTask = null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void shutdown() {
        cancel();
    }

    private final class PowerStatusReceiver extends BroadcastReceiver {
        final /* synthetic */ InactivityTimer this$0;

        private PowerStatusReceiver(InactivityTimer inactivityTimer) {
            this.this$0 = inactivityTimer;
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ PowerStatusReceiver(InactivityTimer x0, AnonymousClass1 r7) {
            this(x0);
            AnonymousClass1 r2 = r7;
        }

        public void onReceive(Context context, Intent intent) {
            Context context2 = context;
            Intent intent2 = intent;
            if ("android.intent.action.BATTERY_CHANGED".equals(intent2.getAction())) {
                if (intent2.getIntExtra("plugged", -1) <= 0) {
                    this.this$0.onActivity();
                } else {
                    this.this$0.cancel();
                }
            }
        }
    }

    private final class InactivityAsyncTask extends AsyncTask<Object, Object, Object> {
        final /* synthetic */ InactivityTimer this$0;

        private InactivityAsyncTask(InactivityTimer inactivityTimer) {
            this.this$0 = inactivityTimer;
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ InactivityAsyncTask(InactivityTimer x0, AnonymousClass1 r7) {
            this(x0);
            AnonymousClass1 r2 = r7;
        }

        /* access modifiers changed from: protected */
        public Object doInBackground(Object... objArr) {
            Object[] objArr2 = objArr;
            try {
                Thread.sleep(InactivityTimer.INACTIVITY_DELAY_MS);
                int i = Log.i(InactivityTimer.TAG, "Finishing activity due to inactivity");
                this.this$0.activity.finish();
            } catch (InterruptedException e) {
                InterruptedException interruptedException = e;
            }
            return null;
        }
    }
}
