package com.google.zxing.client.result;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;

public final class ISBNResultParser extends ResultParser {
    public ISBNResultParser() {
    }

    public ISBNParsedResult parse(Result result) {
        ISBNParsedResult iSBNParsedResult;
        Result result2 = result;
        if (result2.getBarcodeFormat() != BarcodeFormat.EAN_13) {
            return null;
        }
        String rawText = getMassagedText(result2);
        if (rawText.length() != 13) {
            return null;
        }
        if (!rawText.startsWith("978") && !rawText.startsWith("979")) {
            return null;
        }
        new ISBNParsedResult(rawText);
        return iSBNParsedResult;
    }
}
