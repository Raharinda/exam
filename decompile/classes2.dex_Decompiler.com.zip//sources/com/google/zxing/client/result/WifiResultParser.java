package com.google.zxing.client.result;

import com.google.zxing.Result;

public final class WifiResultParser extends ResultParser {
    public WifiResultParser() {
    }

    public WifiParsedResult parse(Result result) {
        WifiParsedResult wifiParsedResult;
        String rawText = getMassagedText(result);
        if (!rawText.startsWith("WIFI:")) {
            return null;
        }
        String ssid = matchSinglePrefixedField("S:", rawText, ';', false);
        if (ssid == null || ssid.length() == 0) {
            return null;
        }
        String pass = matchSinglePrefixedField("P:", rawText, ';', false);
        String type = matchSinglePrefixedField("T:", rawText, ';', false);
        if (type == null) {
            type = "nopass";
        }
        new WifiParsedResult(type, ssid, pass, Boolean.parseBoolean(matchSinglePrefixedField("B:", rawText, ';', false)));
        return wifiParsedResult;
    }
}
