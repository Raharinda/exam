package com.google.zxing.client.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.ClipboardManager;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;
import com.google.zxing.ResultMetadataType;
import com.google.zxing.ResultPoint;
import com.google.zxing.client.android.Intents;
import com.google.zxing.client.android.camera.CameraManager;
import com.google.zxing.client.android.result.ResultHandler;
import java.io.IOException;
import java.util.Collection;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import org.jose4j.jwt.consumer.ErrorCodes;

public final class AppInvCaptureActivity extends Activity implements SurfaceHolder.Callback {
    private static final long BULK_MODE_SCAN_DELAY_MS = 1000;
    private static final long DEFAULT_INTENT_RESULT_DURATION_MS = 1500;
    private static final Set<ResultMetadataType> DISPLAYABLE_METADATA_TYPES = EnumSet.of(ResultMetadataType.ISSUE_NUMBER, ResultMetadataType.SUGGESTED_PRICE, ResultMetadataType.ERROR_CORRECTION_LEVEL, ResultMetadataType.POSSIBLE_COUNTRY);
    private static final String RAW_PARAM = "raw";
    private static final String RETURN_CODE_PLACEHOLDER = "{CODE}";
    private static final String RETURN_URL_PARAM = "ret";
    private static final String TAG = AppInvCaptureActivity.class.getSimpleName();
    private BeepManager beepManager;
    private CameraManager cameraManager;
    private String characterSet;
    private boolean copyToClipboard;
    private Collection<BarcodeFormat> decodeFormats;
    private FrameLayout frameLayout;
    private CaptureActivityHandler handler;
    private boolean hasSurface;
    private Result lastResult;
    private boolean returnRaw;
    private String returnUrlTemplate;
    private Result savedResultToShow;
    private IntentSource source;
    private String sourceUrl;
    private SurfaceView surfaceView;
    private LinearLayout viewLayout;
    private ViewfinderView viewfinderView;

    public AppInvCaptureActivity() {
    }

    /* access modifiers changed from: package-private */
    public ViewfinderView getViewfinderView() {
        return this.viewfinderView;
    }

    public Handler getHandler() {
        return this.handler;
    }

    /* access modifiers changed from: package-private */
    public CameraManager getCameraManager() {
        return this.cameraManager;
    }

    public void onCreate(Bundle icicle) {
        LinearLayout linearLayout;
        FrameLayout frameLayout2;
        ViewGroup.LayoutParams layoutParams;
        super.onCreate(icicle);
        getWindow().addFlags(128);
        new LinearLayout(this);
        this.viewLayout = linearLayout;
        this.viewLayout.setOrientation(0);
        new FrameLayout(this);
        this.frameLayout = frameLayout2;
        new ViewGroup.LayoutParams(-1, -1);
        this.frameLayout.addView(this.viewLayout, layoutParams);
        this.frameLayout.setBackgroundColor(-1);
        setContentView(this.frameLayout);
        this.frameLayout.requestLayout();
        this.hasSurface = false;
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        CameraManager cameraManager2;
        ViewfinderView viewfinderView2;
        SurfaceView surfaceView2;
        super.onResume();
        new CameraManager(getApplication());
        this.cameraManager = cameraManager2;
        new ViewfinderView(this, (AttributeSet) null);
        this.viewfinderView = viewfinderView2;
        this.viewfinderView.setCameraManager(this.cameraManager);
        this.frameLayout.addView(this.viewfinderView);
        this.handler = null;
        this.lastResult = null;
        if (this.surfaceView == null) {
            new SurfaceView(this);
            this.surfaceView = surfaceView2;
            this.viewLayout.addView(this.surfaceView);
        }
        SurfaceHolder surfaceHolder = this.surfaceView.getHolder();
        if (this.hasSurface) {
            initCamera(surfaceHolder);
        } else {
            surfaceHolder.addCallback(this);
            surfaceHolder.setType(3);
        }
        this.surfaceView.setVisibility(0);
        Intent intent = getIntent();
        this.copyToClipboard = true;
        this.source = IntentSource.NONE;
        this.decodeFormats = null;
        this.characterSet = null;
        if (intent != null) {
            String action = intent.getAction();
            String dataString = intent.getDataString();
            if (Intents.Scan.ACTION.equals(action)) {
                this.source = IntentSource.NATIVE_APP_INTENT;
                this.decodeFormats = DecodeFormatManager.parseDecodeFormats(intent);
                if (intent.hasExtra(Intents.Scan.WIDTH) && intent.hasExtra(Intents.Scan.HEIGHT)) {
                    int width = intent.getIntExtra(Intents.Scan.WIDTH, 0);
                    int height = intent.getIntExtra(Intents.Scan.HEIGHT, 0);
                    if (width > 0 && height > 0) {
                        this.cameraManager.setManualFramingRect(width, height);
                    }
                }
            }
            this.characterSet = intent.getStringExtra(Intents.Scan.CHARACTER_SET);
        }
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        SurfaceView surfaceView2;
        if (this.handler != null) {
            this.handler.quitSynchronously();
            this.handler = null;
        }
        this.cameraManager.closeDriver();
        if (!this.hasSurface) {
            new SurfaceView(this);
            this.surfaceView = surfaceView2;
            this.surfaceView.getHolder().removeCallback(this);
        }
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        int keyCode = i;
        KeyEvent event = keyEvent;
        switch (keyCode) {
            case 4:
                if (this.source == IntentSource.NATIVE_APP_INTENT) {
                    setResult(0);
                    finish();
                    return true;
                } else if ((this.source == IntentSource.NONE || this.source == IntentSource.ZXING_LINK) && this.lastResult != null) {
                    restartPreviewAfterDelay(0);
                    return true;
                }
            case ErrorCodes.ISSUED_AT_INVALID_PAST /*24*/:
                this.cameraManager.setTorch(true);
                return true;
            case 25:
                this.cameraManager.setTorch(false);
                return true;
            case 27:
            case 80:
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void decodeOrStoreSavedBitmap(Bitmap bitmap, Result result) {
        Bitmap bitmap2 = bitmap;
        Result result2 = result;
        if (this.handler == null) {
            this.savedResultToShow = result2;
            return;
        }
        if (result2 != null) {
            this.savedResultToShow = result2;
        }
        this.savedResultToShow = null;
    }

    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        SurfaceHolder holder = surfaceHolder;
        if (holder == null) {
            int e = Log.e(TAG, "*** WARNING *** surfaceCreated() gave us a null surface!");
        }
        if (!this.hasSurface) {
            this.hasSurface = true;
            initCamera(holder);
        }
    }

    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        SurfaceHolder surfaceHolder2 = surfaceHolder;
        this.hasSurface = false;
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    /*  JADX ERROR: NullPointerException in pass: CodeShrinkVisitor
        java.lang.NullPointerException
        */
    public void handleDecode(com.google.zxing.Result r12, android.graphics.Bitmap r13) {
        /*
            r11 = this;
            r1 = r11
            r2 = r12
            r3 = r13
            r7 = r1
            r8 = r2
            r7.lastResult = r8
            r7 = r1
            r8 = r2
            com.google.zxing.client.android.result.ResultHandler r7 = com.google.zxing.client.android.result.ResultHandlerFactory.makeResultHandler(r7, r8)
            r4 = r7
            r7 = r3
            if (r7 == 0) goto L_0x002b
            r7 = 1
        L_0x0012:
            r5 = r7
            r7 = r5
            if (r7 == 0) goto L_0x001c
            r7 = r1
            r8 = r3
            r9 = r2
            r7.drawResultPoints(r8, r9)
        L_0x001c:
            int[] r7 = com.google.zxing.client.android.AppInvCaptureActivity.AnonymousClass1.$SwitchMap$com$google$zxing$client$android$IntentSource
            r8 = r1
            com.google.zxing.client.android.IntentSource r8 = r8.source
            int r8 = r8.ordinal()
            r7 = r7[r8]
            switch(r7) {
                case 1: goto L_0x002d;
                case 2: goto L_0x002d;
                case 3: goto L_0x0035;
                default: goto L_0x002a;
            }
        L_0x002a:
            return
        L_0x002b:
            r7 = 0
            goto L_0x0012
        L_0x002d:
            r7 = r1
            r8 = r2
            r9 = r4
            r10 = r3
            r7.handleDecodeExternally(r8, r9, r10)
            goto L_0x002a
        L_0x0035:
            r7 = r5
            if (r7 == 0) goto L_0x002a
            java.lang.String r7 = " (bulk scan)"
            r6 = r7
            r7 = r1
            r8 = r6
            r9 = 0
            android.widget.Toast r7 = android.widget.Toast.makeText(r7, r8, r9)
            r7.show()
            r7 = r1
            r8 = 1000(0x3e8, double:4.94E-321)
            r7.restartPreviewAfterDelay(r8)
            goto L_0x002a
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.zxing.client.android.AppInvCaptureActivity.handleDecode(com.google.zxing.Result, android.graphics.Bitmap):void");
    }

    /* renamed from: com.google.zxing.client.android.AppInvCaptureActivity$1  reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$com$google$zxing$client$android$IntentSource = new int[IntentSource.values().length];

        static {
            try {
                $SwitchMap$com$google$zxing$client$android$IntentSource[IntentSource.NATIVE_APP_INTENT.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
                NoSuchFieldError noSuchFieldError = e;
            }
            try {
                $SwitchMap$com$google$zxing$client$android$IntentSource[IntentSource.PRODUCT_SEARCH_LINK.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
                NoSuchFieldError noSuchFieldError2 = e2;
            }
            try {
                $SwitchMap$com$google$zxing$client$android$IntentSource[IntentSource.NONE.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
                NoSuchFieldError noSuchFieldError3 = e3;
            }
        }
    }

    private void drawResultPoints(Bitmap bitmap, Result result) {
        Canvas canvas;
        Paint paint;
        Bitmap barcode = bitmap;
        Result rawResult = result;
        ResultPoint[] points = rawResult.getResultPoints();
        if (points != null && points.length > 0) {
            new Canvas(barcode);
            Canvas canvas2 = canvas;
            new Paint();
            Paint paint2 = paint;
            paint2.setColor(-1063662592);
            if (points.length == 2) {
                paint2.setStrokeWidth(4.0f);
                drawLine(canvas2, paint2, points[0], points[1]);
            } else if (points.length == 4 && (rawResult.getBarcodeFormat() == BarcodeFormat.UPC_A || rawResult.getBarcodeFormat() == BarcodeFormat.EAN_13)) {
                drawLine(canvas2, paint2, points[0], points[1]);
                drawLine(canvas2, paint2, points[2], points[3]);
            } else {
                paint2.setStrokeWidth(10.0f);
                ResultPoint[] resultPointArr = points;
                int length = resultPointArr.length;
                for (int i = 0; i < length; i++) {
                    ResultPoint point = resultPointArr[i];
                    canvas2.drawPoint(point.getX(), point.getY(), paint2);
                }
            }
        }
    }

    private static void drawLine(Canvas canvas, Paint paint, ResultPoint resultPoint, ResultPoint resultPoint2) {
        ResultPoint a = resultPoint;
        ResultPoint b = resultPoint2;
        canvas.drawLine(a.getX(), a.getY(), b.getX(), b.getY(), paint);
    }

    private void handleDecodeExternally(Result result, ResultHandler resultHandler, Bitmap bitmap) {
        long resultDurationMS;
        Intent intent;
        StringBuilder sb;
        Result rawResult = result;
        ResultHandler resultHandler2 = resultHandler;
        Bitmap barcode = bitmap;
        if (barcode != null) {
            this.viewfinderView.drawResultBitmap(barcode);
        }
        if (getIntent() == null) {
            resultDurationMS = 1500;
        } else {
            resultDurationMS = getIntent().getLongExtra(Intents.Scan.RESULT_DISPLAY_DURATION_MS, DEFAULT_INTENT_RESULT_DURATION_MS);
        }
        if (this.copyToClipboard && !resultHandler2.areContentsSecure()) {
            ClipboardManager clipboard = (ClipboardManager) getSystemService("clipboard");
            CharSequence text = resultHandler2.getDisplayContents();
            if (text != null) {
                clipboard.setText(text);
            }
        }
        if (this.source == IntentSource.NATIVE_APP_INTENT) {
            new Intent(getIntent().getAction());
            Intent intent2 = intent;
            Intent addFlags = intent2.addFlags(524288);
            Intent putExtra = intent2.putExtra(Intents.Scan.RESULT, rawResult.toString());
            Intent putExtra2 = intent2.putExtra(Intents.Scan.RESULT_FORMAT, rawResult.getBarcodeFormat().toString());
            byte[] rawBytes = rawResult.getRawBytes();
            if (rawBytes != null && rawBytes.length > 0) {
                Intent putExtra3 = intent2.putExtra(Intents.Scan.RESULT_BYTES, rawBytes);
            }
            Map<ResultMetadataType, Object> resultMetadata = rawResult.getResultMetadata();
            if (resultMetadata != null) {
                if (resultMetadata.containsKey(ResultMetadataType.UPC_EAN_EXTENSION)) {
                    Intent putExtra4 = intent2.putExtra(Intents.Scan.RESULT_UPC_EAN_EXTENSION, resultMetadata.get(ResultMetadataType.UPC_EAN_EXTENSION).toString());
                }
                Integer orientation = (Integer) resultMetadata.get(ResultMetadataType.ORIENTATION);
                if (orientation != null) {
                    Intent putExtra5 = intent2.putExtra(Intents.Scan.RESULT_ORIENTATION, orientation.intValue());
                }
                String ecLevel = (String) resultMetadata.get(ResultMetadataType.ERROR_CORRECTION_LEVEL);
                if (ecLevel != null) {
                    Intent putExtra6 = intent2.putExtra(Intents.Scan.RESULT_ERROR_CORRECTION_LEVEL, ecLevel);
                }
                Iterable<byte[]> byteSegments = (Iterable) resultMetadata.get(ResultMetadataType.BYTE_SEGMENTS);
                if (byteSegments != null) {
                    int i = 0;
                    for (byte[] byteSegment : byteSegments) {
                        new StringBuilder();
                        Intent putExtra7 = intent2.putExtra(sb.append(Intents.Scan.RESULT_BYTE_SEGMENTS_PREFIX).append(i).toString(), byteSegment);
                        i++;
                    }
                }
            }
            sendReplyMessage(6, intent2, resultDurationMS);
        }
    }

    private void sendReplyMessage(int id, Object arg, long j) {
        long delayMS = j;
        Message message = Message.obtain(this.handler, id, arg);
        if (delayMS > 0) {
            boolean sendMessageDelayed = this.handler.sendMessageDelayed(message, delayMS);
        } else {
            boolean sendMessage = this.handler.sendMessage(message);
        }
    }

    private void initCamera(SurfaceHolder surfaceHolder) {
        CaptureActivityHandler captureActivityHandler;
        Throwable th;
        SurfaceHolder surfaceHolder2 = surfaceHolder;
        int w = Log.w(TAG, "initCamera() was called");
        if (surfaceHolder2 == null) {
            Throwable th2 = th;
            new IllegalStateException("No SurfaceHolder provided");
            throw th2;
        } else if (this.cameraManager.isOpen()) {
            int w2 = Log.w(TAG, "initCamera() while already open -- late SurfaceView callback?");
        } else {
            try {
                this.cameraManager.openDriver(surfaceHolder2);
                if (this.handler == null) {
                    new CaptureActivityHandler(this, this.decodeFormats, this.characterSet, this.cameraManager);
                    this.handler = captureActivityHandler;
                }
                decodeOrStoreSavedBitmap((Bitmap) null, (Result) null);
            } catch (IOException e) {
                int w3 = Log.w(TAG, e);
                displayFrameworkBugMessageAndExit();
            } catch (RuntimeException e2) {
                int w4 = Log.w(TAG, "Unexpected error initializing camera", e2);
                displayFrameworkBugMessageAndExit();
            }
        }
    }

    private void displayFrameworkBugMessageAndExit() {
        AlertDialog.Builder builder;
        new AlertDialog.Builder(this);
        AlertDialog.Builder builder2 = builder;
        AlertDialog.Builder title = builder2.setTitle("Scanner");
        AlertDialog.Builder message = builder2.setMessage("Camera Framework Bug");
        AlertDialog show = builder2.show();
    }

    public void restartPreviewAfterDelay(long j) {
        long delayMS = j;
        if (this.handler != null) {
            boolean sendEmptyMessageDelayed = this.handler.sendEmptyMessageDelayed(5, delayMS);
        }
    }

    public void drawViewfinder() {
        this.viewfinderView.drawViewfinder();
    }
}
