package com.google.zxing.client.result;

public final class SMSParsedResult extends ParsedResult {
    private final String body;
    private final String[] numbers;
    private final String subject;
    private final String[] vias;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public SMSParsedResult(String number, String via, String subject2, String body2) {
        super(ParsedResultType.SMS);
        String[] strArr = new String[1];
        strArr[0] = number;
        this.numbers = strArr;
        String[] strArr2 = new String[1];
        strArr2[0] = via;
        this.vias = strArr2;
        this.subject = subject2;
        this.body = body2;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public SMSParsedResult(String[] numbers2, String[] vias2, String subject2, String body2) {
        super(ParsedResultType.SMS);
        this.numbers = numbers2;
        this.vias = vias2;
        this.subject = subject2;
        this.body = body2;
    }

    public String getSMSURI() {
        StringBuilder sb;
        new StringBuilder();
        StringBuilder result = sb;
        StringBuilder append = result.append("sms:");
        boolean first = true;
        for (int i = 0; i < this.numbers.length; i++) {
            if (first) {
                first = false;
            } else {
                StringBuilder append2 = result.append(',');
            }
            StringBuilder append3 = result.append(this.numbers[i]);
            if (!(this.vias == null || this.vias[i] == null)) {
                StringBuilder append4 = result.append(";via=");
                StringBuilder append5 = result.append(this.vias[i]);
            }
        }
        boolean hasBody = this.body != null;
        boolean hasSubject = this.subject != null;
        if (hasBody || hasSubject) {
            StringBuilder append6 = result.append('?');
            if (hasBody) {
                StringBuilder append7 = result.append("body=");
                StringBuilder append8 = result.append(this.body);
            }
            if (hasSubject) {
                if (hasBody) {
                    StringBuilder append9 = result.append('&');
                }
                StringBuilder append10 = result.append("subject=");
                StringBuilder append11 = result.append(this.subject);
            }
        }
        return result.toString();
    }

    public String[] getNumbers() {
        return this.numbers;
    }

    public String[] getVias() {
        return this.vias;
    }

    public String getSubject() {
        return this.subject;
    }

    public String getBody() {
        return this.body;
    }

    public String getDisplayResult() {
        StringBuilder sb;
        new StringBuilder(100);
        StringBuilder result = sb;
        maybeAppend(this.numbers, result);
        maybeAppend(this.subject, result);
        maybeAppend(this.body, result);
        return result.toString();
    }
}
