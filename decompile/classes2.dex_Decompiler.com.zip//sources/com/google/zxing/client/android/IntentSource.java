package com.google.zxing.client.android;

enum IntentSource {
}
