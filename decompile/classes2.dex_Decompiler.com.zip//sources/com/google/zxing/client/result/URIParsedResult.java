package com.google.zxing.client.result;

import java.util.regex.Pattern;

public final class URIParsedResult extends ParsedResult {
    private static final Pattern USER_IN_HOST = Pattern.compile(":/*([^/@]+)@[^/]+");
    private final String title;
    private final String uri;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public URIParsedResult(String uri2, String title2) {
        super(ParsedResultType.URI);
        this.uri = massageURI(uri2);
        this.title = title2;
    }

    public String getURI() {
        return this.uri;
    }

    public String getTitle() {
        return this.title;
    }

    public boolean isPossiblyMaliciousURI() {
        return USER_IN_HOST.matcher(this.uri).find();
    }

    public String getDisplayResult() {
        StringBuilder sb;
        new StringBuilder(30);
        StringBuilder result = sb;
        maybeAppend(this.title, result);
        maybeAppend(this.uri, result);
        return result.toString();
    }

    private static String massageURI(String uri2) {
        StringBuilder sb;
        StringBuilder sb2;
        String uri3 = uri2.trim();
        int protocolEnd = uri3.indexOf(58);
        if (protocolEnd < 0) {
            new StringBuilder();
            uri3 = sb2.append("http://").append(uri3).toString();
        } else if (isColonFollowedByPortNumber(uri3, protocolEnd)) {
            new StringBuilder();
            uri3 = sb.append("http://").append(uri3).toString();
        }
        return uri3;
    }

    private static boolean isColonFollowedByPortNumber(String str, int i) {
        String uri2 = str;
        int protocolEnd = i;
        int nextSlash = uri2.indexOf(47, protocolEnd + 1);
        if (nextSlash < 0) {
            nextSlash = uri2.length();
        }
        if (nextSlash <= protocolEnd + 1) {
            return false;
        }
        for (int x = protocolEnd + 1; x < nextSlash; x++) {
            if (uri2.charAt(x) < '0' || uri2.charAt(x) > '9') {
                return false;
            }
        }
        return true;
    }
}
