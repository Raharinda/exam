package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class URIResultParser extends ResultParser {
    private static final String ALPHANUM_PART = "[a-zA-Z0-9\\-]";
    private static final Pattern URL_WITHOUT_PROTOCOL_PATTERN = Pattern.compile("([a-zA-Z0-9\\-]+\\.)+[a-zA-Z0-9\\-]{2,}(:\\d{1,5})?(/|\\?|$)");
    private static final Pattern URL_WITH_PROTOCOL_PATTERN = Pattern.compile("[a-zA-Z0-9]{2,}:");

    public URIResultParser() {
    }

    public URIParsedResult parse(Result result) {
        URIParsedResult uRIParsedResult;
        URIParsedResult uRIParsedResult2;
        URIParsedResult uRIParsedResult3;
        String rawText = getMassagedText(result);
        if (rawText.startsWith("URL:") || rawText.startsWith("URI:")) {
            new URIParsedResult(rawText.substring(4).trim(), (String) null);
            return uRIParsedResult;
        }
        String rawText2 = rawText.trim();
        if (isBasicallyValidURI(rawText2)) {
            uRIParsedResult2 = uRIParsedResult3;
            new URIParsedResult(rawText2, (String) null);
        } else {
            uRIParsedResult2 = null;
        }
        return uRIParsedResult2;
    }

    static boolean isBasicallyValidURI(CharSequence charSequence) {
        CharSequence uri = charSequence;
        Matcher m = URL_WITH_PROTOCOL_PATTERN.matcher(uri);
        if (m.find() && m.start() == 0) {
            return true;
        }
        Matcher m2 = URL_WITHOUT_PROTOCOL_PATTERN.matcher(uri);
        return m2.find() && m2.start() == 0;
    }
}
