package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public final class SMSMMSResultParser extends ResultParser {
    public SMSMMSResultParser() {
    }

    public SMSParsedResult parse(Result result) {
        String smsURIWithoutQuery;
        List<String> list;
        List<String> list2;
        SMSParsedResult sMSParsedResult;
        String rawText = getMassagedText(result);
        if (!rawText.startsWith("sms:") && !rawText.startsWith("SMS:") && !rawText.startsWith("mms:") && !rawText.startsWith("MMS:")) {
            return null;
        }
        Map<String, String> nameValuePairs = parseNameValuePairs(rawText);
        String subject = null;
        String body = null;
        boolean querySyntax = false;
        if (nameValuePairs != null && !nameValuePairs.isEmpty()) {
            subject = nameValuePairs.get("subject");
            body = nameValuePairs.get("body");
            querySyntax = true;
        }
        int queryStart = rawText.indexOf(63, 4);
        if (queryStart < 0 || !querySyntax) {
            smsURIWithoutQuery = rawText.substring(4);
        } else {
            smsURIWithoutQuery = rawText.substring(4, queryStart);
        }
        int lastComma = -1;
        new ArrayList<>(1);
        List<String> numbers = list;
        new ArrayList<>(1);
        List<String> vias = list2;
        while (true) {
            int indexOf = smsURIWithoutQuery.indexOf(44, lastComma + 1);
            int comma = indexOf;
            if (indexOf > lastComma) {
                addNumberVia(numbers, vias, smsURIWithoutQuery.substring(lastComma + 1, comma));
                lastComma = comma;
            } else {
                addNumberVia(numbers, vias, smsURIWithoutQuery.substring(lastComma + 1));
                new SMSParsedResult((String[]) numbers.toArray(new String[numbers.size()]), (String[]) vias.toArray(new String[vias.size()]), subject, body);
                return sMSParsedResult;
            }
        }
    }

    private static void addNumberVia(Collection<String> collection, Collection<String> collection2, String str) {
        String via;
        Collection<String> numbers = collection;
        Collection<String> vias = collection2;
        String numberPart = str;
        int numberEnd = numberPart.indexOf(59);
        if (numberEnd < 0) {
            boolean add = numbers.add(numberPart);
            boolean add2 = vias.add((Object) null);
            return;
        }
        boolean add3 = numbers.add(numberPart.substring(0, numberEnd));
        String maybeVia = numberPart.substring(numberEnd + 1);
        if (maybeVia.startsWith("via=")) {
            via = maybeVia.substring(4);
        } else {
            via = null;
        }
        boolean add4 = vias.add(via);
    }
}
