package com.google.zxing.client.android;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.zxing.Binarizer;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.ReaderException;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;
import java.util.Map;

final class DecodeHandler extends Handler {
    private static final String TAG = DecodeHandler.class.getSimpleName();
    private final AppInvCaptureActivity activity;
    private final MultiFormatReader multiFormatReader;
    private boolean running = true;

    DecodeHandler(AppInvCaptureActivity activity2, Map<DecodeHintType, Object> hints) {
        MultiFormatReader multiFormatReader2;
        new MultiFormatReader();
        this.multiFormatReader = multiFormatReader2;
        this.multiFormatReader.setHints(hints);
        this.activity = activity2;
    }

    public void handleMessage(Message message) {
        Message message2 = message;
        if (this.running) {
            switch (message2.what) {
                case 1:
                    decode((byte[]) message2.obj, message2.arg1, message2.arg2);
                    return;
                case 4:
                    this.running = false;
                    Looper.myLooper().quit();
                    return;
                default:
                    return;
            }
        }
    }

    private void decode(byte[] bArr, int i, int i2) {
        StringBuilder sb;
        Bundle bundle;
        BinaryBitmap bitmap;
        Binarizer binarizer;
        byte[] data = bArr;
        int width = i;
        int height = i2;
        long start = System.currentTimeMillis();
        Result rawResult = null;
        byte[] rotatedData = new byte[data.length];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                rotatedData[(((x * height) + height) - y) - 1] = data[x + (y * width)];
            }
        }
        PlanarYUVLuminanceSource source = this.activity.getCameraManager().buildLuminanceSource(rotatedData, height, width);
        if (source != null) {
            new HybridBinarizer(source);
            new BinaryBitmap(binarizer);
            try {
                rawResult = this.multiFormatReader.decodeWithState(bitmap);
                this.multiFormatReader.reset();
            } catch (ReaderException e) {
                ReaderException readerException = e;
                this.multiFormatReader.reset();
            } catch (Throwable th) {
                Throwable th2 = th;
                this.multiFormatReader.reset();
                throw th2;
            }
        }
        Handler handler = this.activity.getHandler();
        if (rawResult != null) {
            long end = System.currentTimeMillis();
            String str = TAG;
            new StringBuilder();
            int d = Log.d(str, sb.append("Found barcode in ").append(end - start).append(" ms").toString());
            if (handler != null) {
                Message message = Message.obtain(handler, 3, rawResult);
                new Bundle();
                Bundle bundle2 = bundle;
                bundle2.putParcelable(DecodeThread.BARCODE_BITMAP, toBitmap(source, source.renderCroppedGreyscaleBitmap()));
                message.setData(bundle2);
                message.sendToTarget();
            }
        } else if (handler != null) {
            Message.obtain(handler, 2).sendToTarget();
        }
    }

    private static Bitmap toBitmap(LuminanceSource luminanceSource, int[] pixels) {
        LuminanceSource source = luminanceSource;
        int width = source.getWidth();
        int height = source.getHeight();
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
        return bitmap;
    }
}
