package com.google.zxing.client.result;

public final class EmailAddressParsedResult extends ParsedResult {
    private final String body;
    private final String emailAddress;
    private final String mailtoURI;
    private final String subject;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    EmailAddressParsedResult(String emailAddress2, String subject2, String body2, String mailtoURI2) {
        super(ParsedResultType.EMAIL_ADDRESS);
        this.emailAddress = emailAddress2;
        this.subject = subject2;
        this.body = body2;
        this.mailtoURI = mailtoURI2;
    }

    public String getEmailAddress() {
        return this.emailAddress;
    }

    public String getSubject() {
        return this.subject;
    }

    public String getBody() {
        return this.body;
    }

    public String getMailtoURI() {
        return this.mailtoURI;
    }

    public String getDisplayResult() {
        StringBuilder sb;
        new StringBuilder(30);
        StringBuilder result = sb;
        maybeAppend(this.emailAddress, result);
        maybeAppend(this.subject, result);
        maybeAppend(this.body, result);
        return result.toString();
    }
}
