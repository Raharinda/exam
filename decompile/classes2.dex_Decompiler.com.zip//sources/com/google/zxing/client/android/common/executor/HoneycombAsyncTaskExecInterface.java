package com.google.zxing.client.android.common.executor;

import android.os.AsyncTask;

public final class HoneycombAsyncTaskExecInterface implements AsyncTaskExecInterface {
    public HoneycombAsyncTaskExecInterface() {
    }

    public <T> void execute(AsyncTask<T, ?, ?> asyncTask, T... tArr) {
        AsyncTask<T, ?, ?> task = asyncTask;
        T[] args = tArr;
        try {
            Object[] objArr = new Object[2];
            objArr[0] = AsyncTask.class.getField("THREAD_POOL_EXECUTOR");
            Object[] objArr2 = objArr;
            objArr2[1] = args;
            Object invoke = task.getClass().getMethod("executeOnExecutor", new Class[0]).invoke(task, objArr2);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
