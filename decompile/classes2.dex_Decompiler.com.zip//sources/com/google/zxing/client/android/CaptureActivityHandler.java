package com.google.zxing.client.android;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;
import com.google.zxing.ResultPointCallback;
import com.google.zxing.client.android.camera.CameraManager;
import java.util.Collection;

public final class CaptureActivityHandler extends Handler {
    private static final String TAG = CaptureActivityHandler.class.getSimpleName();
    private final AppInvCaptureActivity activity;
    private final CameraManager cameraManager;
    private final DecodeThread decodeThread;
    private State state = State.SUCCESS;

    private enum State {
    }

    CaptureActivityHandler(AppInvCaptureActivity appInvCaptureActivity, Collection<BarcodeFormat> decodeFormats, String characterSet, CameraManager cameraManager2) {
        DecodeThread decodeThread2;
        ResultPointCallback resultPointCallback;
        AppInvCaptureActivity activity2 = appInvCaptureActivity;
        CameraManager cameraManager3 = cameraManager2;
        this.activity = activity2;
        new ViewfinderResultPointCallback(activity2.getViewfinderView());
        new DecodeThread(activity2, decodeFormats, characterSet, resultPointCallback);
        this.decodeThread = decodeThread2;
        this.decodeThread.start();
        this.cameraManager = cameraManager3;
        cameraManager3.startPreview();
        restartPreviewAndDecode();
    }

    public void handleMessage(Message message) {
        Bitmap barcode;
        Message message2 = message;
        switch (message2.what) {
            case 2:
                this.state = State.PREVIEW;
                this.cameraManager.requestPreviewFrame(this.decodeThread.getHandler(), 1);
                return;
            case 3:
                int d = Log.d(TAG, "Got decode succeeded message");
                this.state = State.SUCCESS;
                Bundle bundle = message2.getData();
                if (bundle == null) {
                    barcode = null;
                } else {
                    barcode = (Bitmap) bundle.getParcelable(DecodeThread.BARCODE_BITMAP);
                }
                this.activity.handleDecode((Result) message2.obj, barcode);
                return;
            case 5:
                int d2 = Log.d(TAG, "Got restart preview message");
                restartPreviewAndDecode();
                return;
            case 6:
                int d3 = Log.d(TAG, "Got return scan result message");
                this.activity.setResult(-1, (Intent) message2.obj);
                this.activity.finish();
                return;
            default:
                return;
        }
    }

    public void quitSynchronously() {
        this.state = State.DONE;
        this.cameraManager.stopPreview();
        Message.obtain(this.decodeThread.getHandler(), 4).sendToTarget();
        try {
            this.decodeThread.join(500);
        } catch (InterruptedException e) {
            InterruptedException interruptedException = e;
        }
        removeMessages(3);
        removeMessages(2);
    }

    private void restartPreviewAndDecode() {
        if (this.state == State.SUCCESS) {
            this.state = State.PREVIEW;
            this.cameraManager.requestPreviewFrame(this.decodeThread.getHandler(), 1);
            this.activity.drawViewfinder();
        }
    }
}
