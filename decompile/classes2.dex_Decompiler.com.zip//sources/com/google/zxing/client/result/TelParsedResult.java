package com.google.zxing.client.result;

public final class TelParsedResult extends ParsedResult {
    private final String number;
    private final String telURI;
    private final String title;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public TelParsedResult(String number2, String telURI2, String title2) {
        super(ParsedResultType.TEL);
        this.number = number2;
        this.telURI = telURI2;
        this.title = title2;
    }

    public String getNumber() {
        return this.number;
    }

    public String getTelURI() {
        return this.telURI;
    }

    public String getTitle() {
        return this.title;
    }

    public String getDisplayResult() {
        StringBuilder sb;
        new StringBuilder(20);
        StringBuilder result = sb;
        maybeAppend(this.number, result);
        maybeAppend(this.title, result);
        return result.toString();
    }
}
