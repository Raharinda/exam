package com.google.zxing.client.android.camera.open;

import android.hardware.Camera;
import android.util.Log;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public final class GingerbreadOpenCameraInterface implements OpenCameraInterface {
    private static final String TAG = "GingerbreadOpenCamera";

    public GingerbreadOpenCameraInterface() {
    }

    public Camera open() {
        Throwable th;
        StringBuilder sb;
        try {
            Class AndroidCamera = Class.forName("android.hardware.Camera");
            int numCameras = ((Integer) invokeStaticMethod(getMethod(AndroidCamera, "getNumberOfCameras"))).intValue();
            if (numCameras == 0) {
                int w = Log.w(TAG, "No cameras!");
                return null;
            }
            int index = 0;
            Class CameraInfo = Class.forName("android.hardware.Camera$CameraInfo");
            Field facingField = CameraInfo.getField("facing");
            while (index < numCameras) {
                Object cameraInfo = CameraInfo.getConstructor(new Class[0]).newInstance(new Object[0]);
                Class[] clsArr = new Class[2];
                clsArr[0] = Integer.TYPE;
                Class[] clsArr2 = clsArr;
                clsArr2[1] = CameraInfo;
                Method method = AndroidCamera.getMethod("getCameraInfo", clsArr2);
                Object[] objArr = new Object[2];
                objArr[0] = Integer.valueOf(index);
                Object[] objArr2 = objArr;
                objArr2[1] = cameraInfo;
                Object invoke = method.invoke((Object) null, objArr2);
                if (facingField.getInt(cameraInfo) == CameraInfo.getDeclaredField("CAMERA_FACING_BACK").getInt(CameraInfo)) {
                    break;
                }
                index++;
            }
            if (index < numCameras) {
                new StringBuilder();
                int i = Log.i(TAG, sb.append("Opening camera #").append(index).toString());
            } else {
                int i2 = Log.i(TAG, "No camera facing back; returning camera #0");
                index = 0;
            }
            return (Camera) getMethod(AndroidCamera, "open", Integer.TYPE).invoke((Object) null, new Object[]{Integer.valueOf(index)});
        } catch (Exception e) {
            Exception e2 = e;
            e2.printStackTrace();
            Throwable th2 = th;
            new RuntimeException(e2);
            throw th2;
        }
    }

    private static Method getMethod(Class clazz, String name) {
        Throwable th;
        try {
            return clazz.getMethod(name, new Class[0]);
        } catch (NoSuchMethodException e) {
            NoSuchMethodException e2 = e;
            Throwable th2 = th;
            new RuntimeException(e2);
            throw th2;
        }
    }

    private static Method getMethod(Class clazz, String name, Class<?>... parameterTypes) {
        Throwable th;
        try {
            return clazz.getMethod(name, parameterTypes);
        } catch (NoSuchMethodException e) {
            NoSuchMethodException e2 = e;
            Throwable th2 = th;
            new RuntimeException(e2);
            throw th2;
        }
    }

    private static Object invokeStaticMethod(Method method) {
        Throwable th;
        Throwable th2;
        try {
            return method.invoke((Object) null, new Object[0]);
        } catch (IllegalAccessException e) {
            IllegalAccessException e2 = e;
            Throwable th3 = th2;
            new RuntimeException(e2);
            throw th3;
        } catch (InvocationTargetException e3) {
            Throwable cause = e3.getCause();
            cause.printStackTrace();
            if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            }
            Throwable th4 = th;
            new RuntimeException(cause);
            throw th4;
        }
    }

    private static Object invokeMethod(Method method, Object thisObject, Object... args) {
        Throwable th;
        Throwable th2;
        try {
            return method.invoke(thisObject, args);
        } catch (IllegalAccessException e) {
            IllegalAccessException e2 = e;
            Throwable th3 = th2;
            new RuntimeException(e2);
            throw th3;
        } catch (InvocationTargetException e3) {
            Throwable cause = e3.getCause();
            cause.printStackTrace();
            if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            }
            Throwable th4 = th;
            new RuntimeException(cause);
            throw th4;
        }
    }

    private static Object invokeMethodThrowsIllegalArgumentException(Method method, Object thisObject, Object... args) throws IllegalArgumentException {
        Throwable th;
        Throwable th2;
        try {
            return method.invoke(thisObject, args);
        } catch (IllegalAccessException e) {
            IllegalAccessException e2 = e;
            Throwable th3 = th2;
            new RuntimeException(e2);
            throw th3;
        } catch (InvocationTargetException e3) {
            InvocationTargetException e4 = e3;
            Throwable cause = e4.getCause();
            cause.printStackTrace();
            if (cause instanceof IllegalArgumentException) {
                throw ((IllegalArgumentException) cause);
            } else if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            } else {
                Throwable th4 = th;
                new RuntimeException(e4);
                throw th4;
            }
        }
    }

    private static Object invokeMethodThrowsIOException(Method method, Object thisObject, Object... args) throws IOException {
        Throwable th;
        Throwable th2;
        try {
            return method.invoke(thisObject, args);
        } catch (IllegalAccessException e) {
            IllegalAccessException e2 = e;
            Throwable th3 = th2;
            new RuntimeException(e2);
            throw th3;
        } catch (InvocationTargetException e3) {
            InvocationTargetException e4 = e3;
            Throwable cause = e4.getCause();
            cause.printStackTrace();
            if (cause instanceof IOException) {
                throw ((IOException) cause);
            } else if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            } else {
                Throwable th4 = th;
                new RuntimeException(e4);
                throw th4;
            }
        }
    }
}
