package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.jose4j.lang.StringUtil;

public abstract class ResultParser {
    private static final Pattern ALPHANUM = Pattern.compile("[a-zA-Z0-9]*");
    private static final Pattern AMPERSAND = Pattern.compile("&");
    private static final String BYTE_ORDER_MARK = "﻿";
    private static final Pattern DIGITS = Pattern.compile("\\d*");
    private static final Pattern EQUALS = Pattern.compile("=");
    private static final ResultParser[] PARSERS;

    public abstract ParsedResult parse(Result result);

    public ResultParser() {
    }

    static {
        ResultParser resultParser;
        ResultParser resultParser2;
        ResultParser resultParser3;
        ResultParser resultParser4;
        ResultParser resultParser5;
        ResultParser resultParser6;
        ResultParser resultParser7;
        ResultParser resultParser8;
        ResultParser resultParser9;
        ResultParser resultParser10;
        ResultParser resultParser11;
        ResultParser resultParser12;
        ResultParser resultParser13;
        ResultParser resultParser14;
        ResultParser resultParser15;
        ResultParser resultParser16;
        ResultParser resultParser17;
        ResultParser resultParser18;
        ResultParser resultParser19;
        ResultParser[] resultParserArr = new ResultParser[19];
        new BookmarkDoCoMoResultParser();
        resultParserArr[0] = resultParser;
        ResultParser[] resultParserArr2 = resultParserArr;
        new AddressBookDoCoMoResultParser();
        resultParserArr2[1] = resultParser2;
        ResultParser[] resultParserArr3 = resultParserArr2;
        new EmailDoCoMoResultParser();
        resultParserArr3[2] = resultParser3;
        ResultParser[] resultParserArr4 = resultParserArr3;
        new AddressBookAUResultParser();
        resultParserArr4[3] = resultParser4;
        ResultParser[] resultParserArr5 = resultParserArr4;
        new VCardResultParser();
        resultParserArr5[4] = resultParser5;
        ResultParser[] resultParserArr6 = resultParserArr5;
        new BizcardResultParser();
        resultParserArr6[5] = resultParser6;
        ResultParser[] resultParserArr7 = resultParserArr6;
        new VEventResultParser();
        resultParserArr7[6] = resultParser7;
        ResultParser[] resultParserArr8 = resultParserArr7;
        new EmailAddressResultParser();
        resultParserArr8[7] = resultParser8;
        ResultParser[] resultParserArr9 = resultParserArr8;
        new SMTPResultParser();
        resultParserArr9[8] = resultParser9;
        ResultParser[] resultParserArr10 = resultParserArr9;
        new TelResultParser();
        resultParserArr10[9] = resultParser10;
        ResultParser[] resultParserArr11 = resultParserArr10;
        new SMSMMSResultParser();
        resultParserArr11[10] = resultParser11;
        ResultParser[] resultParserArr12 = resultParserArr11;
        new SMSTOMMSTOResultParser();
        resultParserArr12[11] = resultParser12;
        ResultParser[] resultParserArr13 = resultParserArr12;
        new GeoResultParser();
        resultParserArr13[12] = resultParser13;
        ResultParser[] resultParserArr14 = resultParserArr13;
        new WifiResultParser();
        resultParserArr14[13] = resultParser14;
        ResultParser[] resultParserArr15 = resultParserArr14;
        new URLTOResultParser();
        resultParserArr15[14] = resultParser15;
        ResultParser[] resultParserArr16 = resultParserArr15;
        new URIResultParser();
        resultParserArr16[15] = resultParser16;
        ResultParser[] resultParserArr17 = resultParserArr16;
        new ISBNResultParser();
        resultParserArr17[16] = resultParser17;
        ResultParser[] resultParserArr18 = resultParserArr17;
        new ProductResultParser();
        resultParserArr18[17] = resultParser18;
        ResultParser[] resultParserArr19 = resultParserArr18;
        new ExpandedProductResultParser();
        resultParserArr19[18] = resultParser19;
        PARSERS = resultParserArr19;
    }

    protected static String getMassagedText(Result result) {
        String text = result.getText();
        if (text.startsWith(BYTE_ORDER_MARK)) {
            text = text.substring(1);
        }
        return text;
    }

    public static ParsedResult parseResult(Result result) {
        ParsedResult parsedResult;
        Result theResult = result;
        ResultParser[] arr$ = PARSERS;
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            ParsedResult result2 = arr$[i$].parse(theResult);
            if (result2 != null) {
                return result2;
            }
        }
        new TextParsedResult(theResult.getText(), (String) null);
        return parsedResult;
    }

    protected static void maybeAppend(String str, StringBuilder sb) {
        String value = str;
        StringBuilder result = sb;
        if (value != null) {
            StringBuilder append = result.append(10);
            StringBuilder append2 = result.append(value);
        }
    }

    protected static void maybeAppend(String[] strArr, StringBuilder sb) {
        String[] value = strArr;
        StringBuilder result = sb;
        if (value != null) {
            String[] arr$ = value;
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                String s = arr$[i$];
                StringBuilder append = result.append(10);
                StringBuilder append2 = result.append(s);
            }
        }
    }

    protected static String[] maybeWrap(String str) {
        String[] strArr;
        String value = str;
        if (value == null) {
            strArr = null;
        } else {
            String[] strArr2 = new String[1];
            strArr = strArr2;
            strArr2[0] = value;
        }
        return strArr;
    }

    protected static String unescapeBackslash(String str) {
        StringBuilder sb;
        boolean z;
        String escaped = str;
        int backslash = escaped.indexOf(92);
        if (backslash < 0) {
            return escaped;
        }
        int max = escaped.length();
        new StringBuilder(max - 1);
        StringBuilder unescaped = sb;
        StringBuilder append = unescaped.append(escaped.toCharArray(), 0, backslash);
        boolean nextIsEscaped = false;
        for (int i = backslash; i < max; i++) {
            char c = escaped.charAt(i);
            if (nextIsEscaped || c != '\\') {
                StringBuilder append2 = unescaped.append(c);
                z = false;
            } else {
                z = true;
            }
            nextIsEscaped = z;
        }
        return unescaped.toString();
    }

    protected static int parseHexDigit(char c) {
        char c2 = c;
        if (c2 >= '0' && c2 <= '9') {
            return c2 - '0';
        }
        if (c2 >= 'a' && c2 <= 'f') {
            return 10 + (c2 - 'a');
        }
        if (c2 < 'A' || c2 > 'F') {
            return -1;
        }
        return 10 + (c2 - 'A');
    }

    protected static boolean isStringOfDigits(CharSequence charSequence, int length) {
        CharSequence value = charSequence;
        return value != null && length == value.length() && DIGITS.matcher(value).matches();
    }

    protected static boolean isSubstringOfDigits(CharSequence charSequence, int i, int i2) {
        CharSequence value = charSequence;
        int offset = i;
        int length = i2;
        if (value == null) {
            return false;
        }
        int max = offset + length;
        return value.length() >= max && DIGITS.matcher(value.subSequence(offset, max)).matches();
    }

    protected static boolean isSubstringOfAlphaNumeric(CharSequence charSequence, int i, int i2) {
        CharSequence value = charSequence;
        int offset = i;
        int length = i2;
        if (value == null) {
            return false;
        }
        int max = offset + length;
        return value.length() >= max && ALPHANUM.matcher(value.subSequence(offset, max)).matches();
    }

    static Map<String, String> parseNameValuePairs(String str) {
        Map<String, String> map;
        String uri = str;
        int paramStart = uri.indexOf(63);
        if (paramStart < 0) {
            return null;
        }
        new HashMap(3);
        Map<String, String> result = map;
        String[] arr$ = AMPERSAND.split(uri.substring(paramStart + 1));
        int len$ = arr$.length;
        for (int i$ = 0; i$ < len$; i$++) {
            appendKeyValue(arr$[i$], result);
        }
        return result;
    }

    private static void appendKeyValue(CharSequence keyValue, Map<String, String> map) {
        Throwable th;
        Map<String, String> result = map;
        String[] keyValueTokens = EQUALS.split(keyValue, 2);
        if (keyValueTokens.length == 2) {
            String key = keyValueTokens[0];
            try {
                String put = result.put(key, URLDecoder.decode(keyValueTokens[1], StringUtil.UTF_8));
            } catch (UnsupportedEncodingException e) {
                UnsupportedEncodingException uee = e;
                Throwable th2 = th;
                new IllegalStateException(uee);
                throw th2;
            } catch (IllegalArgumentException e2) {
                IllegalArgumentException illegalArgumentException = e2;
            }
        }
    }

    static String[] matchPrefixedField(String str, String str2, char c, boolean z) {
        int i;
        List<String> list;
        String prefix = str;
        String rawText = str2;
        char endChar = c;
        boolean trim = z;
        List<String> matches = null;
        int i2 = 0;
        int max = rawText.length();
        while (i2 < max && (i = rawText.indexOf(prefix, i2)) >= 0) {
            i2 = i + prefix.length();
            int start = i2;
            boolean more = true;
            while (more) {
                int i3 = rawText.indexOf(endChar, i2);
                if (i3 < 0) {
                    i2 = rawText.length();
                    more = false;
                } else if (rawText.charAt(i3 - 1) == '\\') {
                    i2 = i3 + 1;
                } else {
                    if (matches == null) {
                        new ArrayList<>(3);
                        matches = list;
                    }
                    String element = unescapeBackslash(rawText.substring(start, i3));
                    if (trim) {
                        element = element.trim();
                    }
                    boolean add = matches.add(element);
                    i2 = i3 + 1;
                    more = false;
                }
            }
        }
        if (matches == null || matches.isEmpty()) {
            return null;
        }
        return (String[]) matches.toArray(new String[matches.size()]);
    }

    static String matchSinglePrefixedField(String prefix, String rawText, char endChar, boolean trim) {
        String[] matches = matchPrefixedField(prefix, rawText, endChar, trim);
        return matches == null ? null : matches[0];
    }
}
