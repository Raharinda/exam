package com.google.zxing.client.android.camera.exposure;

import android.hardware.Camera;
import android.util.Log;

public final class FroyoExposureInterface implements ExposureInterface {
    private static final float MAX_EXPOSURE_COMPENSATION = 1.5f;
    private static final float MIN_EXPOSURE_COMPENSATION = 0.0f;
    private static final String TAG = FroyoExposureInterface.class.getSimpleName();

    public FroyoExposureInterface() {
    }

    public void setExposure(Camera.Parameters parameters, boolean z) {
        int desiredCompensation;
        StringBuilder sb;
        Camera.Parameters parameters2 = parameters;
        boolean lightOn = z;
        int minExposure = parameters2.getMinExposureCompensation();
        int maxExposure = parameters2.getMaxExposureCompensation();
        if (minExposure == 0 && maxExposure == 0) {
            int i = Log.i(TAG, "Camera does not support exposure compensation");
            return;
        }
        float step = parameters2.getExposureCompensationStep();
        if (lightOn) {
            desiredCompensation = Math.max((int) (0.0f / step), minExposure);
        } else {
            desiredCompensation = Math.min((int) (MAX_EXPOSURE_COMPENSATION / step), maxExposure);
        }
        String str = TAG;
        new StringBuilder();
        int i2 = Log.i(str, sb.append("Setting exposure compensation to ").append(desiredCompensation).append(" / ").append(step * ((float) desiredCompensation)).toString());
        parameters2.setExposureCompensation(desiredCompensation);
    }
}
