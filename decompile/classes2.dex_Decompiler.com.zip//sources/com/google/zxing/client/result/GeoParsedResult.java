package com.google.zxing.client.result;

public final class GeoParsedResult extends ParsedResult {
    private final double altitude;
    private final double latitude;
    private final double longitude;
    private final String query;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    GeoParsedResult(double latitude2, double longitude2, double altitude2, String query2) {
        super(ParsedResultType.GEO);
        this.latitude = latitude2;
        this.longitude = longitude2;
        this.altitude = altitude2;
        this.query = query2;
    }

    public String getGeoURI() {
        StringBuilder sb;
        new StringBuilder();
        StringBuilder result = sb;
        StringBuilder append = result.append("geo:");
        StringBuilder append2 = result.append(this.latitude);
        StringBuilder append3 = result.append(',');
        StringBuilder append4 = result.append(this.longitude);
        if (this.altitude > 0.0d) {
            StringBuilder append5 = result.append(',');
            StringBuilder append6 = result.append(this.altitude);
        }
        if (this.query != null) {
            StringBuilder append7 = result.append('?');
            StringBuilder append8 = result.append(this.query);
        }
        return result.toString();
    }

    public double getLatitude() {
        return this.latitude;
    }

    public double getLongitude() {
        return this.longitude;
    }

    public double getAltitude() {
        return this.altitude;
    }

    public String getQuery() {
        return this.query;
    }

    public String getDisplayResult() {
        StringBuilder sb;
        new StringBuilder(20);
        StringBuilder result = sb;
        StringBuilder append = result.append(this.latitude);
        StringBuilder append2 = result.append(", ");
        StringBuilder append3 = result.append(this.longitude);
        if (this.altitude > 0.0d) {
            StringBuilder append4 = result.append(", ");
            StringBuilder append5 = result.append(this.altitude);
            StringBuilder append6 = result.append('m');
        }
        if (this.query != null) {
            StringBuilder append7 = result.append(" (");
            StringBuilder append8 = result.append(this.query);
            StringBuilder append9 = result.append(')');
        }
        return result.toString();
    }
}
