package com.google.zxing.client.android;

public final class Contents {
    public static final String[] EMAIL_KEYS;
    public static final String[] EMAIL_TYPE_KEYS;
    public static final String NOTE_KEY = "NOTE_KEY";
    public static final String[] PHONE_KEYS;
    public static final String[] PHONE_TYPE_KEYS;
    public static final String URL_KEY = "URL_KEY";

    private Contents() {
    }

    public static final class Type {
        public static final String CONTACT = "CONTACT_TYPE";
        public static final String EMAIL = "EMAIL_TYPE";
        public static final String LOCATION = "LOCATION_TYPE";
        public static final String PHONE = "PHONE_TYPE";
        public static final String SMS = "SMS_TYPE";
        public static final String TEXT = "TEXT_TYPE";

        private Type() {
        }
    }

    static {
        String[] strArr = new String[3];
        strArr[0] = "phone";
        String[] strArr2 = strArr;
        strArr2[1] = "secondary_phone";
        String[] strArr3 = strArr2;
        strArr3[2] = "tertiary_phone";
        PHONE_KEYS = strArr3;
        String[] strArr4 = new String[3];
        strArr4[0] = "phone_type";
        String[] strArr5 = strArr4;
        strArr5[1] = "secondary_phone_type";
        String[] strArr6 = strArr5;
        strArr6[2] = "tertiary_phone_type";
        PHONE_TYPE_KEYS = strArr6;
        String[] strArr7 = new String[3];
        strArr7[0] = "email";
        String[] strArr8 = strArr7;
        strArr8[1] = "secondary_email";
        String[] strArr9 = strArr8;
        strArr9[2] = "tertiary_email";
        EMAIL_KEYS = strArr9;
        String[] strArr10 = new String[3];
        strArr10[0] = "email_type";
        String[] strArr11 = strArr10;
        strArr11[1] = "secondary_email_type";
        String[] strArr12 = strArr11;
        strArr12[2] = "tertiary_email_type";
        EMAIL_TYPE_KEYS = strArr12;
    }
}
