package com.google.zxing.client.android;

import android.content.Context;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class LocaleManager {
    private static final String DEFAULT_COUNTRY = "US";
    private static final String DEFAULT_LANGUAGE = "en";
    private static final String DEFAULT_TLD = "com";
    private static final Map<String, String> GOOGLE_BOOK_SEARCH_COUNTRY_TLD = GOOGLE_COUNTRY_TLD;
    private static final Map<String, String> GOOGLE_COUNTRY_TLD;
    private static final Map<String, String> GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD;
    private static final Collection<String> TRANSLATED_HELP_ASSET_LANGUAGES;

    static {
        Map<String, String> map;
        Map<String, String> map2;
        new HashMap();
        GOOGLE_COUNTRY_TLD = map;
        String put = GOOGLE_COUNTRY_TLD.put("AR", "com.ar");
        String put2 = GOOGLE_COUNTRY_TLD.put("AU", "com.au");
        String put3 = GOOGLE_COUNTRY_TLD.put("BR", "com.br");
        String put4 = GOOGLE_COUNTRY_TLD.put("BG", "bg");
        String put5 = GOOGLE_COUNTRY_TLD.put(Locale.CANADA.getCountry(), "ca");
        String put6 = GOOGLE_COUNTRY_TLD.put(Locale.CHINA.getCountry(), "cn");
        String put7 = GOOGLE_COUNTRY_TLD.put("CZ", "cz");
        String put8 = GOOGLE_COUNTRY_TLD.put("DK", "dk");
        String put9 = GOOGLE_COUNTRY_TLD.put("FI", "fi");
        String put10 = GOOGLE_COUNTRY_TLD.put(Locale.FRANCE.getCountry(), "fr");
        String put11 = GOOGLE_COUNTRY_TLD.put(Locale.GERMANY.getCountry(), "de");
        String put12 = GOOGLE_COUNTRY_TLD.put("GR", "gr");
        String put13 = GOOGLE_COUNTRY_TLD.put("HU", "hu");
        String put14 = GOOGLE_COUNTRY_TLD.put("ID", "co.id");
        String put15 = GOOGLE_COUNTRY_TLD.put("IL", "co.il");
        String put16 = GOOGLE_COUNTRY_TLD.put(Locale.ITALY.getCountry(), "it");
        String put17 = GOOGLE_COUNTRY_TLD.put(Locale.JAPAN.getCountry(), "co.jp");
        String put18 = GOOGLE_COUNTRY_TLD.put(Locale.KOREA.getCountry(), "co.kr");
        String put19 = GOOGLE_COUNTRY_TLD.put("NL", "nl");
        String put20 = GOOGLE_COUNTRY_TLD.put("PL", "pl");
        String put21 = GOOGLE_COUNTRY_TLD.put("PT", "pt");
        String put22 = GOOGLE_COUNTRY_TLD.put("RU", "ru");
        String put23 = GOOGLE_COUNTRY_TLD.put("SK", "sk");
        String put24 = GOOGLE_COUNTRY_TLD.put("SI", "si");
        String put25 = GOOGLE_COUNTRY_TLD.put("ES", "es");
        String put26 = GOOGLE_COUNTRY_TLD.put("SE", "se");
        String put27 = GOOGLE_COUNTRY_TLD.put(Locale.TAIWAN.getCountry(), "tw");
        String put28 = GOOGLE_COUNTRY_TLD.put("TR", "com.tr");
        String put29 = GOOGLE_COUNTRY_TLD.put(Locale.UK.getCountry(), "co.uk");
        String put30 = GOOGLE_COUNTRY_TLD.put(Locale.US.getCountry(), DEFAULT_TLD);
        new HashMap();
        GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD = map2;
        String put31 = GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put("AU", "com.au");
        String put32 = GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put(Locale.CHINA.getCountry(), "cn");
        String put33 = GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put(Locale.FRANCE.getCountry(), "fr");
        String put34 = GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put(Locale.GERMANY.getCountry(), "de");
        String put35 = GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put(Locale.ITALY.getCountry(), "it");
        String put36 = GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put(Locale.JAPAN.getCountry(), "co.jp");
        String put37 = GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put("NL", "nl");
        String put38 = GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put("ES", "es");
        String put39 = GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put(Locale.UK.getCountry(), "co.uk");
        String put40 = GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put(Locale.US.getCountry(), DEFAULT_TLD);
        String[] strArr = new String[12];
        strArr[0] = "de";
        String[] strArr2 = strArr;
        strArr2[1] = DEFAULT_LANGUAGE;
        String[] strArr3 = strArr2;
        strArr3[2] = "es";
        String[] strArr4 = strArr3;
        strArr4[3] = "fr";
        String[] strArr5 = strArr4;
        strArr5[4] = "it";
        String[] strArr6 = strArr5;
        strArr6[5] = "ja";
        String[] strArr7 = strArr6;
        strArr7[6] = "ko";
        String[] strArr8 = strArr7;
        strArr8[7] = "nl";
        String[] strArr9 = strArr8;
        strArr9[8] = "pt";
        String[] strArr10 = strArr9;
        strArr10[9] = "ru";
        String[] strArr11 = strArr10;
        strArr11[10] = "zh-rCN";
        String[] strArr12 = strArr11;
        strArr12[11] = "zh-rTW";
        TRANSLATED_HELP_ASSET_LANGUAGES = Arrays.asList(strArr12);
    }

    private LocaleManager() {
    }

    public static String getCountryTLD(Context context) {
        return doGetTLD(GOOGLE_COUNTRY_TLD, context);
    }

    public static String getProductSearchCountryTLD(Context context) {
        return doGetTLD(GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD, context);
    }

    public static String getBookSearchCountryTLD(Context context) {
        return doGetTLD(GOOGLE_BOOK_SEARCH_COUNTRY_TLD, context);
    }

    public static boolean isBookSearchUrl(String str) {
        String url = str;
        return url.startsWith("http://google.com/books") || url.startsWith("http://books.google.");
    }

    private static String getSystemCountry() {
        Locale locale = Locale.getDefault();
        return locale == null ? DEFAULT_COUNTRY : locale.getCountry();
    }

    private static String getSystemLanguage() {
        StringBuilder sb;
        Locale locale = Locale.getDefault();
        if (locale == null) {
            return DEFAULT_LANGUAGE;
        }
        String language = locale.getLanguage();
        if (!Locale.SIMPLIFIED_CHINESE.getLanguage().equals(language)) {
            return language;
        }
        new StringBuilder();
        return sb.append(language).append("-r").append(getSystemCountry()).toString();
    }

    public static String getTranslatedAssetLanguage() {
        return getSystemLanguage();
    }

    private static String doGetTLD(Map<String, String> map, Context context) {
        Map<String, String> map2 = map;
        Context context2 = context;
        return DEFAULT_TLD;
    }
}
