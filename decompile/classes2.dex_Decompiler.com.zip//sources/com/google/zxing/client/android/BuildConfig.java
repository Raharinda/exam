package com.google.zxing.client.android;

public final class BuildConfig {
    public static final boolean DEBUG = true;

    public BuildConfig() {
    }
}
