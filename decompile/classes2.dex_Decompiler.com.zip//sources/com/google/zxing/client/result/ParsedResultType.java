package com.google.zxing.client.result;

public enum ParsedResultType {
}
