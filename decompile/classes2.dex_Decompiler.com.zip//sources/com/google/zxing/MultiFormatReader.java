package com.google.zxing;

import com.google.zxing.aztec.AztecReader;
import com.google.zxing.datamatrix.DataMatrixReader;
import com.google.zxing.maxicode.MaxiCodeReader;
import com.google.zxing.oned.MultiFormatOneDReader;
import com.google.zxing.pdf417.PDF417Reader;
import com.google.zxing.qrcode.QRCodeReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

public final class MultiFormatReader implements Reader {
    private Map<DecodeHintType, ?> hints;
    private Reader[] readers;

    public MultiFormatReader() {
    }

    public Result decode(BinaryBitmap image) throws NotFoundException {
        setHints((Map<DecodeHintType, ?>) null);
        return decodeInternal(image);
    }

    public Result decode(BinaryBitmap image, Map<DecodeHintType, ?> hints2) throws NotFoundException {
        setHints(hints2);
        return decodeInternal(image);
    }

    public Result decodeWithState(BinaryBitmap binaryBitmap) throws NotFoundException {
        BinaryBitmap image = binaryBitmap;
        if (this.readers == null) {
            setHints((Map<DecodeHintType, ?>) null);
        }
        return decodeInternal(image);
    }

    public void setHints(Map<DecodeHintType, ?> map) {
        Collection<Reader> collection;
        Object obj;
        Object obj2;
        Object obj3;
        Object obj4;
        Object obj5;
        Object obj6;
        Object obj7;
        boolean z;
        Object obj8;
        Object obj9;
        Object obj10;
        Object obj11;
        Object obj12;
        Object obj13;
        Object obj14;
        Map<DecodeHintType, ?> hints2 = map;
        this.hints = hints2;
        boolean tryHarder = hints2 != null && hints2.containsKey(DecodeHintType.TRY_HARDER);
        Collection<BarcodeFormat> formats = hints2 == null ? null : (Collection) hints2.get(DecodeHintType.POSSIBLE_FORMATS);
        new ArrayList<>();
        Collection<Reader> readers2 = collection;
        if (formats != null) {
            if (formats.contains(BarcodeFormat.UPC_A) || formats.contains(BarcodeFormat.UPC_E) || formats.contains(BarcodeFormat.EAN_13) || formats.contains(BarcodeFormat.EAN_8) || formats.contains(BarcodeFormat.CODABAR) || formats.contains(BarcodeFormat.CODE_39) || formats.contains(BarcodeFormat.CODE_93) || formats.contains(BarcodeFormat.CODE_128) || formats.contains(BarcodeFormat.ITF) || formats.contains(BarcodeFormat.RSS_14) || formats.contains(BarcodeFormat.RSS_EXPANDED)) {
                z = true;
            } else {
                z = false;
            }
            boolean addOneDReader = z;
            if (addOneDReader && !tryHarder) {
                new MultiFormatOneDReader(hints2);
                boolean add = readers2.add(obj14);
            }
            if (formats.contains(BarcodeFormat.QR_CODE)) {
                new QRCodeReader();
                boolean add2 = readers2.add(obj13);
            }
            if (formats.contains(BarcodeFormat.DATA_MATRIX)) {
                new DataMatrixReader();
                boolean add3 = readers2.add(obj12);
            }
            if (formats.contains(BarcodeFormat.AZTEC)) {
                new AztecReader();
                boolean add4 = readers2.add(obj11);
            }
            if (formats.contains(BarcodeFormat.PDF_417)) {
                new PDF417Reader();
                boolean add5 = readers2.add(obj10);
            }
            if (formats.contains(BarcodeFormat.MAXICODE)) {
                new MaxiCodeReader();
                boolean add6 = readers2.add(obj9);
            }
            if (addOneDReader && tryHarder) {
                new MultiFormatOneDReader(hints2);
                boolean add7 = readers2.add(obj8);
            }
        }
        if (readers2.isEmpty()) {
            if (!tryHarder) {
                new MultiFormatOneDReader(hints2);
                boolean add8 = readers2.add(obj7);
            }
            new QRCodeReader();
            boolean add9 = readers2.add(obj);
            new DataMatrixReader();
            boolean add10 = readers2.add(obj2);
            new AztecReader();
            boolean add11 = readers2.add(obj3);
            new PDF417Reader();
            boolean add12 = readers2.add(obj4);
            new MaxiCodeReader();
            boolean add13 = readers2.add(obj5);
            if (tryHarder) {
                new MultiFormatOneDReader(hints2);
                boolean add14 = readers2.add(obj6);
            }
        }
        this.readers = (Reader[]) readers2.toArray(new Reader[readers2.size()]);
    }

    public void reset() {
        if (this.readers != null) {
            Reader[] arr$ = this.readers;
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                arr$[i$].reset();
            }
        }
    }

    private Result decodeInternal(BinaryBitmap binaryBitmap) throws NotFoundException {
        BinaryBitmap image = binaryBitmap;
        if (this.readers != null) {
            Reader[] arr$ = this.readers;
            int len$ = arr$.length;
            int i$ = 0;
            while (i$ < len$) {
                try {
                    return arr$[i$].decode(image, this.hints);
                } catch (ReaderException e) {
                    ReaderException readerException = e;
                    i$++;
                }
            }
        }
        throw NotFoundException.getNotFoundInstance();
    }
}
