package com.google.zxing.maxicode;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.ChecksumException;
import com.google.zxing.DecodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.Reader;
import com.google.zxing.Result;
import com.google.zxing.ResultMetadataType;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.maxicode.decoder.Decoder;
import java.util.Map;

public final class MaxiCodeReader implements Reader {
    private static final int MATRIX_HEIGHT = 33;
    private static final int MATRIX_WIDTH = 30;
    private static final ResultPoint[] NO_POINTS = new ResultPoint[0];
    private final Decoder decoder;

    public MaxiCodeReader() {
        Decoder decoder2;
        new Decoder();
        this.decoder = decoder2;
    }

    /* access modifiers changed from: package-private */
    public Decoder getDecoder() {
        return this.decoder;
    }

    public Result decode(BinaryBitmap image) throws NotFoundException, ChecksumException, FormatException {
        return decode(image, (Map<DecodeHintType, ?>) null);
    }

    public Result decode(BinaryBitmap binaryBitmap, Map<DecodeHintType, ?> map) throws NotFoundException, ChecksumException, FormatException {
        Result result;
        BinaryBitmap image = binaryBitmap;
        Map<DecodeHintType, ?> hints = map;
        if (hints == null || !hints.containsKey(DecodeHintType.PURE_BARCODE)) {
            throw NotFoundException.getNotFoundInstance();
        }
        DecoderResult decoderResult = this.decoder.decode(extractPureBits(image.getBlackMatrix()), hints);
        new Result(decoderResult.getText(), decoderResult.getRawBytes(), NO_POINTS, BarcodeFormat.MAXICODE);
        Result result2 = result;
        String ecLevel = decoderResult.getECLevel();
        if (ecLevel != null) {
            result2.putMetadata(ResultMetadataType.ERROR_CORRECTION_LEVEL, ecLevel);
        }
        return result2;
    }

    public void reset() {
    }

    private static BitMatrix extractPureBits(BitMatrix bitMatrix) throws NotFoundException {
        BitMatrix bitMatrix2;
        BitMatrix image = bitMatrix;
        int[] enclosingRectangle = image.getEnclosingRectangle();
        if (enclosingRectangle == null) {
            throw NotFoundException.getNotFoundInstance();
        }
        int left = enclosingRectangle[0];
        int top = enclosingRectangle[1];
        int width = enclosingRectangle[2];
        int height = enclosingRectangle[3];
        new BitMatrix(30, MATRIX_HEIGHT);
        BitMatrix bits = bitMatrix2;
        for (int y = 0; y < MATRIX_HEIGHT; y++) {
            int iy = top + (((y * height) + (height / 2)) / MATRIX_HEIGHT);
            for (int x = 0; x < 30; x++) {
                if (image.get(left + ((((x * width) + (width / 2)) + (((y & 1) * width) / 2)) / 30), iy)) {
                    bits.set(x, y);
                }
            }
        }
        return bits;
    }
}
