package com.google.zxing.maxicode.decoder;

import com.google.zxing.ChecksumException;
import com.google.zxing.DecodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.common.reedsolomon.GenericGF;
import com.google.zxing.common.reedsolomon.ReedSolomonDecoder;
import com.google.zxing.common.reedsolomon.ReedSolomonException;
import java.util.Map;

public final class Decoder {
    private static final int ALL = 0;
    private static final int EVEN = 1;
    private static final int ODD = 2;
    private final ReedSolomonDecoder rsDecoder;

    public Decoder() {
        ReedSolomonDecoder reedSolomonDecoder;
        new ReedSolomonDecoder(GenericGF.MAXICODE_FIELD_64);
        this.rsDecoder = reedSolomonDecoder;
    }

    public DecoderResult decode(BitMatrix bits) throws ChecksumException, FormatException {
        return decode(bits, (Map<DecodeHintType, ?>) null);
    }

    public DecoderResult decode(BitMatrix bits, Map<DecodeHintType, ?> map) throws FormatException, ChecksumException {
        BitMatrixParser parser;
        byte[] datawords;
        Map<DecodeHintType, ?> map2 = map;
        new BitMatrixParser(bits);
        byte[] codewords = parser.readCodewords();
        correctErrors(codewords, 0, 10, 10, 0);
        int mode = codewords[0] & 15;
        switch (mode) {
            case 2:
            case 3:
            case 4:
                correctErrors(codewords, 20, 84, 40, 1);
                correctErrors(codewords, 20, 84, 40, 2);
                datawords = new byte[94];
                break;
            case 5:
                correctErrors(codewords, 20, 68, 56, 1);
                correctErrors(codewords, 20, 68, 56, 2);
                datawords = new byte[78];
                break;
            default:
                throw FormatException.getFormatInstance();
        }
        System.arraycopy(codewords, 0, datawords, 0, 10);
        System.arraycopy(codewords, 20, datawords, 10, datawords.length - 10);
        return DecodedBitStreamParser.decode(datawords, mode);
    }

    private void correctErrors(byte[] bArr, int i, int i2, int i3, int i4) throws ChecksumException {
        byte[] codewordBytes = bArr;
        int start = i;
        int dataCodewords = i2;
        int ecCodewords = i3;
        int mode = i4;
        int codewords = dataCodewords + ecCodewords;
        int divisor = mode == 0 ? 1 : 2;
        int[] codewordsInts = new int[(codewords / divisor)];
        for (int i5 = 0; i5 < codewords; i5++) {
            if (mode == 0 || i5 % 2 == mode - 1) {
                codewordsInts[i5 / divisor] = codewordBytes[i5 + start] & 255;
            }
        }
        try {
            this.rsDecoder.decode(codewordsInts, ecCodewords / divisor);
            for (int i6 = 0; i6 < dataCodewords; i6++) {
                if (mode == 0 || i6 % 2 == mode - 1) {
                    codewordBytes[i6 + start] = (byte) codewordsInts[i6 / divisor];
                }
            }
        } catch (ReedSolomonException e) {
            ReedSolomonException reedSolomonException = e;
            throw ChecksumException.getChecksumInstance();
        }
    }
}
