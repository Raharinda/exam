package com.google.zxing.maxicode.decoder;

import com.google.zxing.common.DecoderResult;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;

final class DecodedBitStreamParser {
    private static final char ECI = '￺';
    private static final char FS = '\u001c';
    private static final char GS = '\u001d';
    private static final char LATCHA = '￷';
    private static final char LATCHB = '￸';
    private static final char LOCK = '￹';
    private static final NumberFormat NINE_DIGITS;
    private static final char NS = '￻';
    private static final char PAD = '￼';
    private static final char RS = '\u001e';
    private static final String[] SETS;
    private static final char SHIFTA = '￰';
    private static final char SHIFTB = '￱';
    private static final char SHIFTC = '￲';
    private static final char SHIFTD = '￳';
    private static final char SHIFTE = '￴';
    private static final char THREESHIFTA = '￶';
    private static final NumberFormat THREE_DIGITS;
    private static final char TWOSHIFTA = '￵';

    static {
        NumberFormat numberFormat;
        NumberFormat numberFormat2;
        new DecimalFormat("000000000");
        NINE_DIGITS = numberFormat;
        new DecimalFormat("000");
        THREE_DIGITS = numberFormat2;
        String[] strArr = new String[6];
        strArr[0] = "\nABCDEFGHIJKLMNOPQRSTUVWXYZ￺\u001c\u001d\u001e￻ ￼\"#$%&'()*+,-./0123456789:￱￲￳￴￸";
        String[] strArr2 = strArr;
        strArr2[1] = "`abcdefghijklmnopqrstuvwxyz￺\u001c\u001d\u001e￻{￼}~;<=>?[\\]^_ ,./:@!|￼￵￶￼￰￲￳￴￷";
        String[] strArr3 = strArr2;
        strArr3[2] = "ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚ￺\u001c\u001d\u001eÛÜÝÞßª¬±²³µ¹º¼½¾￷ ￹￳￴￸";
        String[] strArr4 = strArr3;
        strArr4[3] = "àáâãäåæçèéêëìíîïðñòóôõö÷øùú￺\u001c\u001d\u001e￻ûüýþÿ¡¨«¯°´·¸»¿￷ ￲￹￴￸";
        String[] strArr5 = strArr4;
        strArr5[4] = "\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\b\t\n\u000b\f\r\u000e\u000f\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001a￺￼￼\u001b￻\u001c\u001d\u001e\u001f ¢£¤¥¦§©­®¶￷ ￲￳￹￸";
        String[] strArr6 = strArr5;
        strArr6[5] = "\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\b\t\n\u000b\f\r\u000e\u000f\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001a\u001b\u001c\u001d\u001e\u001f !\"#$%&'()*+,-./0123456789:;<=>?";
        SETS = strArr6;
    }

    private DecodedBitStreamParser() {
    }

    static DecoderResult decode(byte[] bArr, int i) {
        StringBuilder sb;
        String postcode;
        StringBuilder sb2;
        StringBuilder sb3;
        NumberFormat df;
        DecoderResult decoderResult;
        byte[] bytes = bArr;
        int mode = i;
        new StringBuilder(144);
        StringBuilder result = sb;
        switch (mode) {
            case 2:
            case 3:
                if (mode == 2) {
                    int pc = getPostCode2(bytes);
                    new DecimalFormat("0000000000".substring(0, getPostCode2Length(bytes)));
                    postcode = df.format((long) pc);
                } else {
                    postcode = getPostCode3(bytes);
                }
                String country = THREE_DIGITS.format((long) getCountry(bytes));
                String service = THREE_DIGITS.format((long) getServiceClass(bytes));
                StringBuilder append = result.append(getMessage(bytes, 10, 84));
                if (!result.toString().startsWith("[)>\u001e01\u001d")) {
                    new StringBuilder();
                    StringBuilder insert = result.insert(0, sb2.append(postcode).append(GS).append(country).append(GS).append(service).append(GS).toString());
                    break;
                } else {
                    new StringBuilder();
                    StringBuilder insert2 = result.insert(9, sb3.append(postcode).append(GS).append(country).append(GS).append(service).append(GS).toString());
                    break;
                }
            case 4:
                StringBuilder append2 = result.append(getMessage(bytes, 1, 93));
                break;
            case 5:
                StringBuilder append3 = result.append(getMessage(bytes, 1, 77));
                break;
        }
        new DecoderResult(bytes, result.toString(), (List<byte[]>) null, String.valueOf(mode));
        return decoderResult;
    }

    private static int getBit(int bit, byte[] bytes) {
        int bit2 = bit - 1;
        return (bytes[bit2 / 6] & (1 << (5 - (bit2 % 6)))) == 0 ? 0 : 1;
    }

    private static int getInt(byte[] bArr, byte[] bArr2) {
        byte[] bytes = bArr;
        byte[] x = bArr2;
        int val = 0;
        for (int i = 0; i < x.length; i++) {
            val += getBit(x[i], bytes) << ((x.length - i) - 1);
        }
        return val;
    }

    private static int getCountry(byte[] bytes) {
        return getInt(bytes, new byte[]{53, 54, 43, 44, 45, 46, 47, 48, 37, 38});
    }

    private static int getServiceClass(byte[] bytes) {
        return getInt(bytes, new byte[]{55, 56, 57, 58, 59, 60, 49, 50, 51, 52});
    }

    private static int getPostCode2Length(byte[] bytes) {
        return getInt(bytes, new byte[]{39, 40, 41, 42, 31, 32});
    }

    private static int getPostCode2(byte[] bytes) {
        return getInt(bytes, new byte[]{33, 34, 35, 36, 25, 26, 27, 28, 29, 30, 19, 20, 21, 22, 23, 24, 13, 14, 15, 16, 17, 18, 7, 8, 9, 10, 11, 12, 1, 2});
    }

    private static String getPostCode3(byte[] bArr) {
        byte[] bytes = bArr;
        char[] cArr = new char[6];
        cArr[0] = SETS[0].charAt(getInt(bytes, new byte[]{39, 40, 41, 42, 31, 32}));
        char[] cArr2 = cArr;
        cArr2[1] = SETS[0].charAt(getInt(bytes, new byte[]{33, 34, 35, 36, 25, 26}));
        char[] cArr3 = cArr2;
        cArr3[2] = SETS[0].charAt(getInt(bytes, new byte[]{27, 28, 29, 30, 19, 20}));
        char[] cArr4 = cArr3;
        cArr4[3] = SETS[0].charAt(getInt(bytes, new byte[]{21, 22, 23, 24, 13, 14}));
        char[] cArr5 = cArr4;
        cArr5[4] = SETS[0].charAt(getInt(bytes, new byte[]{15, 16, 17, 18, 7, 8}));
        char[] cArr6 = cArr5;
        cArr6[5] = SETS[0].charAt(getInt(bytes, new byte[]{9, 10, 11, 12, 1, 2}));
        return String.valueOf(cArr6);
    }

    private static String getMessage(byte[] bArr, int i, int i2) {
        StringBuilder sb;
        byte[] bytes = bArr;
        int start = i;
        int len = i2;
        new StringBuilder();
        StringBuilder sb2 = sb;
        int shift = -1;
        int set = 0;
        int lastset = 0;
        int i3 = start;
        while (i3 < start + len) {
            char c = SETS[set].charAt(bytes[i3]);
            switch (c) {
                case 65520:
                case 65521:
                case 65522:
                case 65523:
                case 65524:
                    lastset = set;
                    set = c - SHIFTA;
                    shift = 1;
                    break;
                case 65525:
                    lastset = set;
                    set = 0;
                    shift = 2;
                    break;
                case 65526:
                    lastset = set;
                    set = 0;
                    shift = 3;
                    break;
                case 65527:
                    set = 0;
                    shift = -1;
                    break;
                case 65528:
                    set = 1;
                    shift = -1;
                    break;
                case 65529:
                    shift = -1;
                    break;
                case 65531:
                    int i4 = i3 + 1;
                    int i5 = i4 + 1;
                    int i6 = i5 + 1;
                    int i7 = i6 + 1;
                    i3 = i7 + 1;
                    StringBuilder append = sb2.append(NINE_DIGITS.format((long) ((bytes[i4] << 24) + (bytes[i5] << 18) + (bytes[i6] << 12) + (bytes[i7] << 6) + bytes[i3])));
                    break;
                default:
                    StringBuilder append2 = sb2.append(c);
                    break;
            }
            int i8 = shift;
            shift--;
            if (i8 == 0) {
                set = lastset;
            }
            i3++;
        }
        while (sb2.length() > 0 && sb2.charAt(sb2.length() - 1) == 65532) {
            sb2.setLength(sb2.length() - 1);
        }
        return sb2.toString();
    }
}
