package com.github.ybq.android.spinkit;

public enum Style {
    ;
    
    private int value;

    private Style(int value2) {
        String str = r8;
        int i = r9;
        this.value = value2;
    }
}
