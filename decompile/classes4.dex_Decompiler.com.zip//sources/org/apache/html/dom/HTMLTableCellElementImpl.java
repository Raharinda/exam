package org.apache.html.dom;

import org.w3c.dom.Node;
import org.w3c.dom.html.HTMLTableCellElement;
import org.w3c.dom.html.HTMLTableRowElement;

public class HTMLTableCellElementImpl extends HTMLElementImpl implements HTMLTableCellElement {
    private static final long serialVersionUID = -2406518157464313922L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLTableCellElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getAbbr() {
        return getAttribute("abbr");
    }

    public String getAlign() {
        return capitalize(getAttribute("align"));
    }

    public String getAxis() {
        return getAttribute("axis");
    }

    public String getBgColor() {
        return getAttribute("bgcolor");
    }

    public int getCellIndex() {
        Node parentNode = getParentNode();
        int i = 0;
        if (parentNode instanceof HTMLTableRowElement) {
            Node firstChild = parentNode.getFirstChild();
            while (true) {
                Node node = firstChild;
                if (node == null) {
                    break;
                }
                if (node instanceof HTMLTableCellElement) {
                    if (node == this) {
                        return i;
                    }
                    i++;
                }
                firstChild = node.getNextSibling();
            }
        }
        return -1;
    }

    public String getCh() {
        String attribute = getAttribute("char");
        if (attribute != null && attribute.length() > 1) {
            attribute = attribute.substring(0, 1);
        }
        return attribute;
    }

    public String getChOff() {
        return getAttribute("charoff");
    }

    public int getColSpan() {
        return getInteger(getAttribute("colspan"));
    }

    public String getHeaders() {
        return getAttribute("headers");
    }

    public String getHeight() {
        return getAttribute("height");
    }

    public boolean getNoWrap() {
        return getBinary("nowrap");
    }

    public int getRowSpan() {
        return getInteger(getAttribute("rowspan"));
    }

    public String getScope() {
        return getAttribute("scope");
    }

    public String getVAlign() {
        return capitalize(getAttribute("valign"));
    }

    public String getWidth() {
        return getAttribute("width");
    }

    public void setAbbr(String str) {
        setAttribute("abbr", str);
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }

    public void setAxis(String str) {
        setAttribute("axis", str);
    }

    public void setBgColor(String str) {
        setAttribute("bgcolor", str);
    }

    public void setCellIndex(int i) {
        int i2 = i;
        Node parentNode = getParentNode();
        if (parentNode instanceof HTMLTableRowElement) {
            Node firstChild = parentNode.getFirstChild();
            while (true) {
                Node node = firstChild;
                if (node == null) {
                    break;
                }
                if (node instanceof HTMLTableCellElement) {
                    if (i2 != 0) {
                        i2--;
                    } else if (this != node) {
                        Node insertBefore = parentNode.insertBefore(this, node);
                        return;
                    } else {
                        return;
                    }
                }
                firstChild = node.getNextSibling();
            }
        }
        Node appendChild = parentNode.appendChild(this);
    }

    public void setCh(String str) {
        String str2 = str;
        if (str2 != null && str2.length() > 1) {
            str2 = str2.substring(0, 1);
        }
        setAttribute("char", str2);
    }

    public void setChOff(String str) {
        setAttribute("charoff", str);
    }

    public void setColSpan(int i) {
        setAttribute("colspan", String.valueOf(i));
    }

    public void setHeaders(String str) {
        setAttribute("headers", str);
    }

    public void setHeight(String str) {
        setAttribute("height", str);
    }

    public void setNoWrap(boolean z) {
        setAttribute("nowrap", z);
    }

    public void setRowSpan(int i) {
        setAttribute("rowspan", String.valueOf(i));
    }

    public void setScope(String str) {
        setAttribute("scope", str);
    }

    public void setVAlign(String str) {
        setAttribute("valign", str);
    }

    public void setWidth(String str) {
        setAttribute("width", str);
    }
}
