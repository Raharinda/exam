package org.apache.html.dom;

import org.w3c.dom.html.HTMLHRElement;

public class HTMLHRElementImpl extends HTMLElementImpl implements HTMLHRElement {
    private static final long serialVersionUID = -4210053417678939270L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLHRElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getAlign() {
        return capitalize(getAttribute("align"));
    }

    public boolean getNoShade() {
        return getBinary("noshade");
    }

    public String getSize() {
        return getAttribute("size");
    }

    public String getWidth() {
        return getAttribute("width");
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }

    public void setNoShade(boolean z) {
        setAttribute("noshade", z);
    }

    public void setSize(String str) {
        setAttribute("size", str);
    }

    public void setWidth(String str) {
        setAttribute("width", str);
    }
}
