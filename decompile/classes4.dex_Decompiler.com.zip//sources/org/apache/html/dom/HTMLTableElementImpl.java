package org.apache.html.dom;

import org.w3c.dom.Node;
import org.w3c.dom.html.HTMLCollection;
import org.w3c.dom.html.HTMLElement;
import org.w3c.dom.html.HTMLTableCaptionElement;
import org.w3c.dom.html.HTMLTableElement;
import org.w3c.dom.html.HTMLTableRowElement;
import org.w3c.dom.html.HTMLTableSectionElement;

public class HTMLTableElementImpl extends HTMLElementImpl implements HTMLTableElement {
    private static final long serialVersionUID = -1824053099870917532L;
    private HTMLCollectionImpl _bodies;
    private HTMLCollectionImpl _rows;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLTableElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public Node cloneNode(boolean z) {
        HTMLTableElementImpl hTMLTableElementImpl = (HTMLTableElementImpl) super.cloneNode(z);
        hTMLTableElementImpl._rows = null;
        hTMLTableElementImpl._bodies = null;
        return hTMLTableElementImpl;
    }

    public synchronized HTMLElement createCaption() {
        HTMLTableCaptionElement hTMLTableCaptionElement;
        HTMLTableCaptionElement hTMLTableCaptionElement2;
        synchronized (this) {
            HTMLTableCaptionElement caption = getCaption();
            if (caption != null) {
                hTMLTableCaptionElement2 = caption;
            } else {
                new HTMLTableCaptionElementImpl((HTMLDocumentImpl) getOwnerDocument(), "CAPTION");
                HTMLTableCaptionElement hTMLTableCaptionElement3 = hTMLTableCaptionElement;
                Node appendChild = appendChild(hTMLTableCaptionElement3);
                hTMLTableCaptionElement2 = hTMLTableCaptionElement3;
            }
        }
        return hTMLTableCaptionElement2;
    }

    public synchronized HTMLElement createTFoot() {
        HTMLTableSectionElement hTMLTableSectionElement;
        HTMLTableSectionElement hTMLTableSectionElement2;
        synchronized (this) {
            HTMLTableSectionElement tFoot = getTFoot();
            if (tFoot != null) {
                hTMLTableSectionElement2 = tFoot;
            } else {
                new HTMLTableSectionElementImpl((HTMLDocumentImpl) getOwnerDocument(), "TFOOT");
                HTMLTableSectionElement hTMLTableSectionElement3 = hTMLTableSectionElement;
                Node appendChild = appendChild(hTMLTableSectionElement3);
                hTMLTableSectionElement2 = hTMLTableSectionElement3;
            }
        }
        return hTMLTableSectionElement2;
    }

    public synchronized HTMLElement createTHead() {
        HTMLTableSectionElement hTMLTableSectionElement;
        HTMLTableSectionElement hTMLTableSectionElement2;
        synchronized (this) {
            HTMLTableSectionElement tHead = getTHead();
            if (tHead != null) {
                hTMLTableSectionElement2 = tHead;
            } else {
                new HTMLTableSectionElementImpl((HTMLDocumentImpl) getOwnerDocument(), "THEAD");
                HTMLTableSectionElement hTMLTableSectionElement3 = hTMLTableSectionElement;
                Node appendChild = appendChild(hTMLTableSectionElement3);
                hTMLTableSectionElement2 = hTMLTableSectionElement3;
            }
        }
        return hTMLTableSectionElement2;
    }

    public synchronized void deleteCaption() {
        synchronized (this) {
            HTMLTableCaptionElement caption = getCaption();
            if (caption != null) {
                Node removeChild = removeChild(caption);
            }
        }
    }

    public synchronized void deleteRow(int i) {
        int i2 = i;
        synchronized (this) {
            Node firstChild = getFirstChild();
            while (true) {
                if (firstChild == null) {
                    break;
                }
                if (firstChild instanceof HTMLTableRowElement) {
                    if (i2 == 0) {
                        Node removeChild = removeChild(firstChild);
                        break;
                    }
                    i2--;
                } else if (firstChild instanceof HTMLTableSectionElementImpl) {
                    i2 = ((HTMLTableSectionElementImpl) firstChild).deleteRowX(i2);
                    if (i2 < 0) {
                        break;
                    }
                } else {
                    continue;
                }
                firstChild = firstChild.getNextSibling();
            }
        }
    }

    public synchronized void deleteTFoot() {
        synchronized (this) {
            HTMLTableSectionElement tFoot = getTFoot();
            if (tFoot != null) {
                Node removeChild = removeChild(tFoot);
            }
        }
    }

    public synchronized void deleteTHead() {
        synchronized (this) {
            HTMLTableSectionElement tHead = getTHead();
            if (tHead != null) {
                Node removeChild = removeChild(tHead);
            }
        }
    }

    public String getAlign() {
        return capitalize(getAttribute("align"));
    }

    public String getBgColor() {
        return getAttribute("bgcolor");
    }

    public String getBorder() {
        return getAttribute("border");
    }

    public synchronized HTMLTableCaptionElement getCaption() {
        HTMLTableCaptionElement hTMLTableCaptionElement;
        synchronized (this) {
            HTMLTableCaptionElement firstChild = getFirstChild();
            while (true) {
                Node node = firstChild;
                if (node != null) {
                    if ((node instanceof HTMLTableCaptionElement) && node.getNodeName().equals("CAPTION")) {
                        hTMLTableCaptionElement = node;
                        break;
                    }
                    firstChild = node.getNextSibling();
                } else {
                    hTMLTableCaptionElement = null;
                    break;
                }
            }
        }
        return hTMLTableCaptionElement;
    }

    public String getCellPadding() {
        return getAttribute("cellpadding");
    }

    public String getCellSpacing() {
        return getAttribute("cellspacing");
    }

    public String getFrame() {
        return capitalize(getAttribute("frame"));
    }

    public HTMLCollection getRows() {
        HTMLCollectionImpl hTMLCollectionImpl;
        if (this._rows == null) {
            new HTMLCollectionImpl(this, 7);
            this._rows = hTMLCollectionImpl;
        }
        return this._rows;
    }

    public String getRules() {
        return capitalize(getAttribute("rules"));
    }

    public String getSummary() {
        return getAttribute("summary");
    }

    public HTMLCollection getTBodies() {
        HTMLCollectionImpl hTMLCollectionImpl;
        if (this._bodies == null) {
            new HTMLCollectionImpl(this, -2);
            this._bodies = hTMLCollectionImpl;
        }
        return this._bodies;
    }

    public synchronized HTMLTableSectionElement getTFoot() {
        HTMLTableSectionElement hTMLTableSectionElement;
        synchronized (this) {
            HTMLTableSectionElement firstChild = getFirstChild();
            while (true) {
                Node node = firstChild;
                if (node != null) {
                    if ((node instanceof HTMLTableSectionElement) && node.getNodeName().equals("TFOOT")) {
                        hTMLTableSectionElement = node;
                        break;
                    }
                    firstChild = node.getNextSibling();
                } else {
                    hTMLTableSectionElement = null;
                    break;
                }
            }
        }
        return hTMLTableSectionElement;
    }

    public synchronized HTMLTableSectionElement getTHead() {
        HTMLTableSectionElement hTMLTableSectionElement;
        synchronized (this) {
            HTMLTableSectionElement firstChild = getFirstChild();
            while (true) {
                Node node = firstChild;
                if (node != null) {
                    if ((node instanceof HTMLTableSectionElement) && node.getNodeName().equals("THEAD")) {
                        hTMLTableSectionElement = node;
                        break;
                    }
                    firstChild = node.getNextSibling();
                } else {
                    hTMLTableSectionElement = null;
                    break;
                }
            }
        }
        return hTMLTableSectionElement;
    }

    public String getWidth() {
        return getAttribute("width");
    }

    public HTMLElement insertRow(int i) {
        HTMLTableRowElementImpl hTMLTableRowElementImpl;
        new HTMLTableRowElementImpl((HTMLDocumentImpl) getOwnerDocument(), "TR");
        HTMLTableRowElementImpl hTMLTableRowElementImpl2 = hTMLTableRowElementImpl;
        insertRowX(i, hTMLTableRowElementImpl2);
        return hTMLTableRowElementImpl2;
    }

    /* access modifiers changed from: package-private */
    public void insertRowX(int i, HTMLTableRowElementImpl hTMLTableRowElementImpl) {
        int i2 = i;
        HTMLTableRowElementImpl hTMLTableRowElementImpl2 = hTMLTableRowElementImpl;
        Node node = null;
        Node firstChild = getFirstChild();
        while (true) {
            Node node2 = firstChild;
            if (node2 != null) {
                if (node2 instanceof HTMLTableRowElement) {
                    if (i2 == 0) {
                        Node insertBefore = insertBefore(hTMLTableRowElementImpl2, node2);
                        return;
                    }
                } else if (node2 instanceof HTMLTableSectionElementImpl) {
                    node = node2;
                    i2 = ((HTMLTableSectionElementImpl) node2).insertRowX(i2, hTMLTableRowElementImpl2);
                    if (i2 < 0) {
                        return;
                    }
                } else {
                    continue;
                }
                firstChild = node2.getNextSibling();
            } else if (node != null) {
                Node appendChild = node.appendChild(hTMLTableRowElementImpl2);
                return;
            } else {
                Node appendChild2 = appendChild(hTMLTableRowElementImpl2);
                return;
            }
        }
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }

    public void setBgColor(String str) {
        setAttribute("bgcolor", str);
    }

    public void setBorder(String str) {
        setAttribute("border", str);
    }

    public synchronized void setCaption(HTMLTableCaptionElement hTMLTableCaptionElement) {
        Throwable th;
        HTMLTableCaptionElement hTMLTableCaptionElement2 = hTMLTableCaptionElement;
        synchronized (this) {
            if (hTMLTableCaptionElement2 != null) {
                if (!hTMLTableCaptionElement2.getTagName().equals("CAPTION")) {
                    Throwable th2 = th;
                    new IllegalArgumentException("HTM016 Argument 'caption' is not an element of type <CAPTION>.");
                    throw th2;
                }
            }
            deleteCaption();
            if (hTMLTableCaptionElement2 != null) {
                Node appendChild = appendChild(hTMLTableCaptionElement2);
            }
        }
    }

    public void setCellPadding(String str) {
        setAttribute("cellpadding", str);
    }

    public void setCellSpacing(String str) {
        setAttribute("cellspacing", str);
    }

    public void setFrame(String str) {
        setAttribute("frame", str);
    }

    public void setRules(String str) {
        setAttribute("rules", str);
    }

    public void setSummary(String str) {
        setAttribute("summary", str);
    }

    public synchronized void setTFoot(HTMLTableSectionElement hTMLTableSectionElement) {
        Throwable th;
        HTMLTableSectionElement hTMLTableSectionElement2 = hTMLTableSectionElement;
        synchronized (this) {
            if (hTMLTableSectionElement2 != null) {
                if (!hTMLTableSectionElement2.getTagName().equals("TFOOT")) {
                    Throwable th2 = th;
                    new IllegalArgumentException("HTM018 Argument 'tFoot' is not an element of type <TFOOT>.");
                    throw th2;
                }
            }
            deleteTFoot();
            if (hTMLTableSectionElement2 != null) {
                Node appendChild = appendChild(hTMLTableSectionElement2);
            }
        }
    }

    public synchronized void setTHead(HTMLTableSectionElement hTMLTableSectionElement) {
        Throwable th;
        HTMLTableSectionElement hTMLTableSectionElement2 = hTMLTableSectionElement;
        synchronized (this) {
            if (hTMLTableSectionElement2 != null) {
                if (!hTMLTableSectionElement2.getTagName().equals("THEAD")) {
                    Throwable th2 = th;
                    new IllegalArgumentException("HTM017 Argument 'tHead' is not an element of type <THEAD>.");
                    throw th2;
                }
            }
            deleteTHead();
            if (hTMLTableSectionElement2 != null) {
                Node appendChild = appendChild(hTMLTableSectionElement2);
            }
        }
    }

    public void setWidth(String str) {
        setAttribute("width", str);
    }
}
