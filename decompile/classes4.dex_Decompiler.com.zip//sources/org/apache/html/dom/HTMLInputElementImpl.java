package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.html.HTMLInputElement;

public class HTMLInputElementImpl extends HTMLElementImpl implements HTMLInputElement, HTMLFormControl {
    private static final long serialVersionUID = 640139325394332007L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLInputElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public void blur() {
    }

    public void click() {
    }

    public void focus() {
    }

    public String getAccept() {
        return getAttribute("accept");
    }

    public String getAccessKey() {
        String attribute = getAttribute("accesskey");
        if (attribute != null && attribute.length() > 1) {
            attribute = attribute.substring(0, 1);
        }
        return attribute;
    }

    public String getAlign() {
        return capitalize(getAttribute("align"));
    }

    public String getAlt() {
        return getAttribute("alt");
    }

    public boolean getChecked() {
        return getBinary("checked");
    }

    public boolean getDefaultChecked() {
        return getBinary("defaultChecked");
    }

    public String getDefaultValue() {
        return getAttribute("defaultValue");
    }

    public boolean getDisabled() {
        return getBinary("disabled");
    }

    public int getMaxLength() {
        return getInteger(getAttribute("maxlength"));
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public boolean getReadOnly() {
        return getBinary("readonly");
    }

    public String getSize() {
        return getAttribute("size");
    }

    public String getSrc() {
        return getAttribute("src");
    }

    public int getTabIndex() {
        try {
            return Integer.parseInt(getAttribute("tabindex"));
        } catch (NumberFormatException e) {
            NumberFormatException numberFormatException = e;
            return 0;
        }
    }

    public String getType() {
        return getAttribute(CommonProperties.TYPE);
    }

    public String getUseMap() {
        return getAttribute("useMap");
    }

    public String getValue() {
        return getAttribute(CommonProperties.VALUE);
    }

    public void select() {
    }

    public void setAccept(String str) {
        setAttribute("accept", str);
    }

    public void setAccessKey(String str) {
        String str2 = str;
        if (str2 != null && str2.length() > 1) {
            str2 = str2.substring(0, 1);
        }
        setAttribute("accesskey", str2);
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }

    public void setAlt(String str) {
        setAttribute("alt", str);
    }

    public void setChecked(boolean z) {
        setAttribute("checked", z);
    }

    public void setDefaultChecked(boolean z) {
        setAttribute("defaultChecked", z);
    }

    public void setDefaultValue(String str) {
        setAttribute("defaultValue", str);
    }

    public void setDisabled(boolean z) {
        setAttribute("disabled", z);
    }

    public void setMaxLength(int i) {
        setAttribute("maxlength", String.valueOf(i));
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setReadOnly(boolean z) {
        setAttribute("readonly", z);
    }

    public void setSize(String str) {
        setAttribute("size", str);
    }

    public void setSrc(String str) {
        setAttribute("src", str);
    }

    public void setTabIndex(int i) {
        setAttribute("tabindex", String.valueOf(i));
    }

    public void setUseMap(String str) {
        setAttribute("useMap", str);
    }

    public void setValue(String str) {
        setAttribute(CommonProperties.VALUE, str);
    }
}
