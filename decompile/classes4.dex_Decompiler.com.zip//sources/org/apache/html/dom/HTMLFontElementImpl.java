package org.apache.html.dom;

import org.w3c.dom.html.HTMLFontElement;

public class HTMLFontElementImpl extends HTMLElementImpl implements HTMLFontElement {
    private static final long serialVersionUID = -415914342045846318L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLFontElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getColor() {
        return capitalize(getAttribute("color"));
    }

    public String getFace() {
        return capitalize(getAttribute("face"));
    }

    public String getSize() {
        return getAttribute("size");
    }

    public void setColor(String str) {
        setAttribute("color", str);
    }

    public void setFace(String str) {
        setAttribute("face", str);
    }

    public void setSize(String str) {
        setAttribute("size", str);
    }
}
