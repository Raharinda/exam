package org.apache.html.dom;

import org.w3c.dom.html.HTMLAreaElement;

public class HTMLAreaElementImpl extends HTMLElementImpl implements HTMLAreaElement {
    private static final long serialVersionUID = 7164004431531608995L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLAreaElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getAccessKey() {
        String attribute = getAttribute("accesskey");
        if (attribute != null && attribute.length() > 1) {
            attribute = attribute.substring(0, 1);
        }
        return attribute;
    }

    public String getAlt() {
        return getAttribute("alt");
    }

    public String getCoords() {
        return getAttribute("coords");
    }

    public String getHref() {
        return getAttribute("href");
    }

    public boolean getNoHref() {
        return getBinary("nohref");
    }

    public String getShape() {
        return capitalize(getAttribute("shape"));
    }

    public int getTabIndex() {
        return getInteger(getAttribute("tabindex"));
    }

    public String getTarget() {
        return getAttribute("target");
    }

    public void setAccessKey(String str) {
        String str2 = str;
        if (str2 != null && str2.length() > 1) {
            str2 = str2.substring(0, 1);
        }
        setAttribute("accesskey", str2);
    }

    public void setAlt(String str) {
        setAttribute("alt", str);
    }

    public void setCoords(String str) {
        setAttribute("coords", str);
    }

    public void setHref(String str) {
        setAttribute("href", str);
    }

    public void setNoHref(boolean z) {
        setAttribute("nohref", z);
    }

    public void setShape(String str) {
        setAttribute("shape", str);
    }

    public void setTabIndex(int i) {
        setAttribute("tabindex", String.valueOf(i));
    }

    public void setTarget(String str) {
        setAttribute("target", str);
    }
}
