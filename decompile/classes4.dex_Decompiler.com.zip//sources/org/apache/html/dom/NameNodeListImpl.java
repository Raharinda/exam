package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.xerces.dom.DeepNodeListImpl;
import org.apache.xerces.dom.ElementImpl;
import org.apache.xerces.dom.NodeImpl;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class NameNodeListImpl extends DeepNodeListImpl implements NodeList {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NameNodeListImpl(NodeImpl nodeImpl, String str) {
        super(nodeImpl, str);
    }

    /* access modifiers changed from: protected */
    public Node nextMatchingElementAfter(Node node) {
        ElementImpl elementImpl = node;
        while (elementImpl != null) {
            if (elementImpl.hasChildNodes()) {
                elementImpl = elementImpl.getFirstChild();
            } else {
                if (elementImpl != this.rootNode) {
                    Node nextSibling = elementImpl.getNextSibling();
                    Node node2 = nextSibling;
                    if (null != nextSibling) {
                        elementImpl = node2;
                    }
                }
                ElementImpl elementImpl2 = null;
                while (elementImpl != this.rootNode) {
                    elementImpl2 = elementImpl.getNextSibling();
                    if (elementImpl2 != null) {
                        break;
                    }
                    elementImpl = elementImpl.getParentNode();
                }
                elementImpl = elementImpl2;
            }
            if (!(elementImpl == this.rootNode || elementImpl == null || elementImpl.getNodeType() != 1)) {
                String attribute = elementImpl.getAttribute(CommonProperties.NAME);
                if (attribute.equals("*") || attribute.equals(this.tagName)) {
                    return elementImpl;
                }
            }
        }
        return null;
    }
}
