package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.html.HTMLButtonElement;

public class HTMLButtonElementImpl extends HTMLElementImpl implements HTMLButtonElement, HTMLFormControl {
    private static final long serialVersionUID = -753685852948076730L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLButtonElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getAccessKey() {
        String attribute = getAttribute("accesskey");
        if (attribute != null && attribute.length() > 1) {
            attribute = attribute.substring(0, 1);
        }
        return attribute;
    }

    public boolean getDisabled() {
        return getBinary("disabled");
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public int getTabIndex() {
        try {
            return Integer.parseInt(getAttribute("tabindex"));
        } catch (NumberFormatException e) {
            NumberFormatException numberFormatException = e;
            return 0;
        }
    }

    public String getType() {
        return capitalize(getAttribute(CommonProperties.TYPE));
    }

    public String getValue() {
        return getAttribute(CommonProperties.VALUE);
    }

    public void setAccessKey(String str) {
        String str2 = str;
        if (str2 != null && str2.length() > 1) {
            str2 = str2.substring(0, 1);
        }
        setAttribute("accesskey", str2);
    }

    public void setDisabled(boolean z) {
        setAttribute("disabled", z);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setTabIndex(int i) {
        setAttribute("tabindex", String.valueOf(i));
    }

    public void setValue(String str) {
        setAttribute(CommonProperties.VALUE, str);
    }
}
