package org.apache.html.dom;

import org.w3c.dom.html.HTMLHtmlElement;

public class HTMLHtmlElementImpl extends HTMLElementImpl implements HTMLHtmlElement {
    private static final long serialVersionUID = -4489734201536616166L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLHtmlElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getVersion() {
        return capitalize(getAttribute("version"));
    }

    public void setVersion(String str) {
        setAttribute("version", str);
    }
}
