package org.apache.html.dom;

import org.w3c.dom.html.HTMLPreElement;

public class HTMLPreElementImpl extends HTMLElementImpl implements HTMLPreElement {
    private static final long serialVersionUID = -4195360849946217644L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLPreElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public int getWidth() {
        return getInteger(getAttribute("width"));
    }

    public void setWidth(int i) {
        setAttribute("width", String.valueOf(i));
    }
}
