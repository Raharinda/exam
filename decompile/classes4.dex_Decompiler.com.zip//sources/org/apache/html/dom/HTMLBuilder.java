package org.apache.html.dom;

import java.util.Vector;
import org.apache.xerces.dom.CoreDocumentImpl;
import org.apache.xerces.dom.ElementImpl;
import org.apache.xerces.dom.ProcessingInstructionImpl;
import org.w3c.dom.Node;
import org.w3c.dom.html.HTMLDocument;
import org.xml.sax.AttributeList;
import org.xml.sax.DocumentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

public class HTMLBuilder implements DocumentHandler {
    protected ElementImpl _current;
    protected HTMLDocumentImpl _document;
    private boolean _done = true;
    private boolean _ignoreWhitespace = true;
    protected Vector _preRootNodes;

    public HTMLBuilder() {
    }

    public void characters(String str) throws SAXException {
        Throwable th;
        String str2 = str;
        if (this._current == null) {
            Throwable th2 = th;
            new SAXException("HTM009 State error: character data found outside of root element.");
            throw th2;
        }
        Node appendChild = this._current.appendChild(this._document.createTextNode(str2));
    }

    public void characters(char[] cArr, int i, int i2) throws SAXException {
        String str;
        Throwable th;
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        if (this._current == null) {
            Throwable th2 = th;
            new SAXException("HTM010 State error: character data found outside of root element.");
            throw th2;
        }
        ElementImpl elementImpl = this._current;
        new String(cArr2, i3, i4);
        Node appendChild = elementImpl.appendChild(this._document.createTextNode(str));
    }

    public void endDocument() throws SAXException {
        Throwable th;
        Throwable th2;
        if (this._document == null) {
            Throwable th3 = th2;
            new SAXException("HTM002 State error: document never started or missing document element.");
            throw th3;
        } else if (this._current != null) {
            Throwable th4 = th;
            new SAXException("HTM003 State error: document ended before end of document element.");
            throw th4;
        } else {
            this._current = null;
            this._done = true;
        }
    }

    public void endElement(String str) throws SAXException {
        Throwable th;
        StringBuffer stringBuffer;
        Throwable th2;
        String str2 = str;
        if (this._current == null) {
            Throwable th3 = th2;
            new SAXException("HTM007 State error: endElement called with no current node.");
            throw th3;
        } else if (!this._current.getNodeName().equalsIgnoreCase(str2)) {
            Throwable th4 = th;
            new StringBuffer();
            new SAXException(stringBuffer.append("HTM008 State error: mismatch in closing tag name ").append(str2).append("\n").append(str2).toString());
            throw th4;
        } else if (this._current.getParentNode() == this._current.getOwnerDocument()) {
            this._current = null;
        } else {
            this._current = (ElementImpl) this._current.getParentNode();
        }
    }

    public HTMLDocument getHTMLDocument() {
        return this._document;
    }

    public void ignorableWhitespace(char[] cArr, int i, int i2) throws SAXException {
        String str;
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        if (!this._ignoreWhitespace) {
            ElementImpl elementImpl = this._current;
            new String(cArr2, i3, i4);
            Node appendChild = elementImpl.appendChild(this._document.createTextNode(str));
        }
    }

    public void processingInstruction(String str, String str2) throws SAXException {
        Object obj;
        Vector vector;
        String str3 = str;
        String str4 = str2;
        if (this._current == null && this._document == null) {
            if (this._preRootNodes == null) {
                new Vector();
                this._preRootNodes = vector;
            }
            new ProcessingInstructionImpl((CoreDocumentImpl) null, str3, str4);
            this._preRootNodes.addElement(obj);
        } else if (this._current != null || this._document == null) {
            Node appendChild = this._current.appendChild(this._document.createProcessingInstruction(str3, str4));
        } else {
            Node appendChild2 = this._document.appendChild(this._document.createProcessingInstruction(str3, str4));
        }
    }

    public void setDocumentLocator(Locator locator) {
    }

    public void startDocument() throws SAXException {
        Throwable th;
        if (!this._done) {
            Throwable th2 = th;
            new SAXException("HTM001 State error: startDocument fired twice on one builder.");
            throw th2;
        }
        this._document = null;
        this._done = false;
    }

    public synchronized void startElement(String str, AttributeList attributeList) throws SAXException {
        ElementImpl elementImpl;
        Throwable th;
        HTMLDocumentImpl hTMLDocumentImpl;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        AttributeList attributeList2 = attributeList;
        synchronized (this) {
            if (str2 == null) {
                Throwable th4 = th3;
                new SAXException("HTM004 Argument 'tagName' is null.");
                throw th4;
            }
            if (this._document == null) {
                new HTMLDocumentImpl();
                this._document = hTMLDocumentImpl;
                elementImpl = (ElementImpl) this._document.getDocumentElement();
                this._current = elementImpl;
                if (this._current == null) {
                    Throwable th5 = th2;
                    new SAXException("HTM005 State error: Document.getDocumentElement returns null.");
                    throw th5;
                } else if (this._preRootNodes != null) {
                    int size = this._preRootNodes.size();
                    while (true) {
                        int i = size;
                        size = i - 1;
                        if (i <= 0) {
                            this._preRootNodes = null;
                            break;
                        }
                        Node insertBefore = this._document.insertBefore((Node) this._preRootNodes.elementAt(size), elementImpl);
                    }
                }
            } else if (this._current == null) {
                Throwable th6 = th;
                new SAXException("HTM006 State error: startElement called after end of document element.");
                throw th6;
            } else {
                elementImpl = (ElementImpl) this._document.createElement(str2);
                Node appendChild = this._current.appendChild(elementImpl);
                this._current = elementImpl;
            }
            if (attributeList2 != null) {
                for (int i2 = 0; i2 < attributeList2.getLength(); i2++) {
                    elementImpl.setAttribute(attributeList2.getName(i2), attributeList2.getValue(i2));
                }
            }
        }
    }
}
