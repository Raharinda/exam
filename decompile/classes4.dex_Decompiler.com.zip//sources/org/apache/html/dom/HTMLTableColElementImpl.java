package org.apache.html.dom;

import org.w3c.dom.html.HTMLTableColElement;

public class HTMLTableColElementImpl extends HTMLElementImpl implements HTMLTableColElement {
    private static final long serialVersionUID = -6189626162811911792L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLTableColElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getAlign() {
        return capitalize(getAttribute("align"));
    }

    public String getCh() {
        String attribute = getAttribute("char");
        if (attribute != null && attribute.length() > 1) {
            attribute = attribute.substring(0, 1);
        }
        return attribute;
    }

    public String getChOff() {
        return getAttribute("charoff");
    }

    public int getSpan() {
        return getInteger(getAttribute("span"));
    }

    public String getVAlign() {
        return capitalize(getAttribute("valign"));
    }

    public String getWidth() {
        return getAttribute("width");
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }

    public void setCh(String str) {
        String str2 = str;
        if (str2 != null && str2.length() > 1) {
            str2 = str2.substring(0, 1);
        }
        setAttribute("char", str2);
    }

    public void setChOff(String str) {
        setAttribute("charoff", str);
    }

    public void setSpan(int i) {
        setAttribute("span", String.valueOf(i));
    }

    public void setVAlign(String str) {
        setAttribute("valign", str);
    }

    public void setWidth(String str) {
        setAttribute("width", str);
    }
}
