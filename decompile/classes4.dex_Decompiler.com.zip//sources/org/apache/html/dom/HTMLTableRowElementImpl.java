package org.apache.html.dom;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.html.HTMLCollection;
import org.w3c.dom.html.HTMLElement;
import org.w3c.dom.html.HTMLTableCellElement;
import org.w3c.dom.html.HTMLTableElement;
import org.w3c.dom.html.HTMLTableRowElement;
import org.w3c.dom.html.HTMLTableSectionElement;

public class HTMLTableRowElementImpl extends HTMLElementImpl implements HTMLTableRowElement {
    private static final long serialVersionUID = 5409562635656244263L;
    HTMLCollection _cells;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLTableRowElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public Node cloneNode(boolean z) {
        HTMLTableRowElementImpl hTMLTableRowElementImpl = (HTMLTableRowElementImpl) super.cloneNode(z);
        hTMLTableRowElementImpl._cells = null;
        return hTMLTableRowElementImpl;
    }

    public void deleteCell(int i) {
        int i2 = i;
        Node firstChild = getFirstChild();
        while (true) {
            Node node = firstChild;
            if (node != null) {
                if (node instanceof HTMLTableCellElement) {
                    if (i2 == 0) {
                        Node removeChild = removeChild(node);
                        return;
                    }
                    i2--;
                }
                firstChild = node.getNextSibling();
            } else {
                return;
            }
        }
    }

    public String getAlign() {
        return capitalize(getAttribute("align"));
    }

    public String getBgColor() {
        return getAttribute("bgcolor");
    }

    public HTMLCollection getCells() {
        HTMLCollection hTMLCollection;
        if (this._cells == null) {
            new HTMLCollectionImpl(this, -3);
            this._cells = hTMLCollection;
        }
        return this._cells;
    }

    public String getCh() {
        String attribute = getAttribute("char");
        if (attribute != null && attribute.length() > 1) {
            attribute = attribute.substring(0, 1);
        }
        return attribute;
    }

    public String getChOff() {
        return getAttribute("charoff");
    }

    public int getRowIndex() {
        Node parentNode = getParentNode();
        if (parentNode instanceof HTMLTableSectionElement) {
            parentNode = parentNode.getParentNode();
        }
        if (parentNode instanceof HTMLTableElement) {
            return getRowIndex(parentNode);
        }
        return -1;
    }

    /* access modifiers changed from: package-private */
    public int getRowIndex(Node node) {
        NodeList elementsByTagName = ((HTMLElement) node).getElementsByTagName("TR");
        for (int i = 0; i < elementsByTagName.getLength(); i++) {
            if (elementsByTagName.item(i) == this) {
                return i;
            }
        }
        return -1;
    }

    public int getSectionRowIndex() {
        Node parentNode = getParentNode();
        if (parentNode instanceof HTMLTableSectionElement) {
            return getRowIndex(parentNode);
        }
        return -1;
    }

    public String getVAlign() {
        return capitalize(getAttribute("valign"));
    }

    public HTMLElement insertCell(int i) {
        Node node;
        int i2 = i;
        new HTMLTableCellElementImpl((HTMLDocumentImpl) getOwnerDocument(), "TD");
        Node node2 = node;
        Node firstChild = getFirstChild();
        while (true) {
            Node node3 = firstChild;
            if (node3 == null) {
                Node appendChild = appendChild(node2);
                return node2;
            }
            if (node3 instanceof HTMLTableCellElement) {
                if (i2 == 0) {
                    Node insertBefore = insertBefore(node2, node3);
                    return node2;
                }
                i2--;
            }
            firstChild = node3.getNextSibling();
        }
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }

    public void setBgColor(String str) {
        setAttribute("bgcolor", str);
    }

    public void setCells(HTMLCollection hTMLCollection) {
        HTMLCollection hTMLCollection2 = hTMLCollection;
        Node firstChild = getFirstChild();
        while (true) {
            Node node = firstChild;
            if (node == null) {
                break;
            }
            Node removeChild = removeChild(node);
            firstChild = node.getNextSibling();
        }
        int i = 0;
        Node item = hTMLCollection2.item(0);
        while (true) {
            Node node2 = item;
            if (node2 != null) {
                Node appendChild = appendChild(node2);
                i++;
                item = hTMLCollection2.item(i);
            } else {
                return;
            }
        }
    }

    public void setCh(String str) {
        String str2 = str;
        if (str2 != null && str2.length() > 1) {
            str2 = str2.substring(0, 1);
        }
        setAttribute("char", str2);
    }

    public void setChOff(String str) {
        setAttribute("charoff", str);
    }

    public void setRowIndex(int i) {
        int i2 = i;
        Node parentNode = getParentNode();
        if (parentNode instanceof HTMLTableSectionElement) {
            parentNode = parentNode.getParentNode();
        }
        if (parentNode instanceof HTMLTableElement) {
            ((HTMLTableElementImpl) parentNode).insertRowX(i2, this);
        }
    }

    public void setSectionRowIndex(int i) {
        int i2 = i;
        Node parentNode = getParentNode();
        if (parentNode instanceof HTMLTableSectionElement) {
            int insertRowX = ((HTMLTableSectionElementImpl) parentNode).insertRowX(i2, this);
        }
    }

    public void setVAlign(String str) {
        setAttribute("valign", str);
    }
}
