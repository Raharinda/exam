package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.Node;
import org.w3c.dom.html.HTMLCollection;
import org.w3c.dom.html.HTMLMapElement;

public class HTMLMapElementImpl extends HTMLElementImpl implements HTMLMapElement {
    private static final long serialVersionUID = 7520887584251976392L;
    private HTMLCollection _areas;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLMapElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public Node cloneNode(boolean z) {
        HTMLMapElementImpl hTMLMapElementImpl = (HTMLMapElementImpl) super.cloneNode(z);
        hTMLMapElementImpl._areas = null;
        return hTMLMapElementImpl;
    }

    public HTMLCollection getAreas() {
        HTMLCollection hTMLCollection;
        if (this._areas == null) {
            new HTMLCollectionImpl(this, -1);
            this._areas = hTMLCollection;
        }
        return this._areas;
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }
}
