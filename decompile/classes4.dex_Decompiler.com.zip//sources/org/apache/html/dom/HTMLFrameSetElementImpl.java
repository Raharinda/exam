package org.apache.html.dom;

import org.w3c.dom.html.HTMLFrameSetElement;

public class HTMLFrameSetElementImpl extends HTMLElementImpl implements HTMLFrameSetElement {
    private static final long serialVersionUID = 8403143821972586708L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLFrameSetElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getCols() {
        return getAttribute("cols");
    }

    public String getRows() {
        return getAttribute("rows");
    }

    public void setCols(String str) {
        setAttribute("cols", str);
    }

    public void setRows(String str) {
        setAttribute("rows", str);
    }
}
