package org.apache.html.dom;

import org.w3c.dom.html.HTMLDivElement;

public class HTMLDivElementImpl extends HTMLElementImpl implements HTMLDivElement {
    private static final long serialVersionUID = 2327098984177358833L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLDivElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getAlign() {
        return capitalize(getAttribute("align"));
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }
}
