package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.html.HTMLStyleElement;

public class HTMLStyleElementImpl extends HTMLElementImpl implements HTMLStyleElement {
    private static final long serialVersionUID = -9001815754196124532L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLStyleElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public boolean getDisabled() {
        return getBinary("disabled");
    }

    public String getMedia() {
        return getAttribute("media");
    }

    public String getType() {
        return getAttribute(CommonProperties.TYPE);
    }

    public void setDisabled(boolean z) {
        setAttribute("disabled", z);
    }

    public void setMedia(String str) {
        setAttribute("media", str);
    }

    public void setType(String str) {
        setAttribute(CommonProperties.TYPE, str);
    }
}
