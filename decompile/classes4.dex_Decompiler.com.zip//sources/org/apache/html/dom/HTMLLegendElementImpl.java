package org.apache.html.dom;

import org.w3c.dom.html.HTMLLegendElement;

public class HTMLLegendElementImpl extends HTMLElementImpl implements HTMLLegendElement {
    private static final long serialVersionUID = -621849164029630762L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLLegendElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getAccessKey() {
        String attribute = getAttribute("accesskey");
        if (attribute != null && attribute.length() > 1) {
            attribute = attribute.substring(0, 1);
        }
        return attribute;
    }

    public String getAlign() {
        return getAttribute("align");
    }

    public void setAccessKey(String str) {
        String str2 = str;
        if (str2 != null && str2.length() > 1) {
            str2 = str2.substring(0, 1);
        }
        setAttribute("accesskey", str2);
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }
}
