package org.apache.html.dom;

import org.w3c.dom.html.HTMLOptGroupElement;

public class HTMLOptGroupElementImpl extends HTMLElementImpl implements HTMLOptGroupElement {
    private static final long serialVersionUID = -8807098641226171501L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLOptGroupElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public boolean getDisabled() {
        return getBinary("disabled");
    }

    public String getLabel() {
        return capitalize(getAttribute("label"));
    }

    public void setDisabled(boolean z) {
        setAttribute("disabled", z);
    }

    public void setLabel(String str) {
        setAttribute("label", str);
    }
}
