package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.html.HTMLOListElement;

public class HTMLOListElementImpl extends HTMLElementImpl implements HTMLOListElement {
    private static final long serialVersionUID = 1293750546025862146L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLOListElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public boolean getCompact() {
        return getBinary("compact");
    }

    public int getStart() {
        return getInteger(getAttribute("start"));
    }

    public String getType() {
        return getAttribute(CommonProperties.TYPE);
    }

    public void setCompact(boolean z) {
        setAttribute("compact", z);
    }

    public void setStart(int i) {
        setAttribute("start", String.valueOf(i));
    }

    public void setType(String str) {
        setAttribute(CommonProperties.TYPE, str);
    }
}
