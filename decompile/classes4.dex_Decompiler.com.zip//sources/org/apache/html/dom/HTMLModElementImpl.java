package org.apache.html.dom;

import org.w3c.dom.html.HTMLModElement;

public class HTMLModElementImpl extends HTMLElementImpl implements HTMLModElement {
    private static final long serialVersionUID = 6424581972706750120L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLModElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getCite() {
        return getAttribute("cite");
    }

    public String getDateTime() {
        return getAttribute("datetime");
    }

    public void setCite(String str) {
        setAttribute("cite", str);
    }

    public void setDateTime(String str) {
        setAttribute("datetime", str);
    }
}
