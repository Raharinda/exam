package org.apache.html.dom;

import org.apache.xerces.dom.DOMImplementationImpl;
import org.w3c.dom.html.HTMLDOMImplementation;

public class HTMLDOMImplementationImpl extends DOMImplementationImpl implements HTMLDOMImplementation {
    private static final HTMLDOMImplementation _instance;

    static {
        HTMLDOMImplementation hTMLDOMImplementation;
        new HTMLDOMImplementationImpl();
        _instance = hTMLDOMImplementation;
    }

    private HTMLDOMImplementationImpl() {
    }

    public static HTMLDOMImplementation getHTMLDOMImplementation() {
        return _instance;
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final org.w3c.dom.html.HTMLDocument createHTMLDocument(java.lang.String r8) throws org.w3c.dom.DOMException {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r3 = r1
            if (r3 != 0) goto L_0x0011
            java.lang.NullPointerException r3 = new java.lang.NullPointerException
            r6 = r3
            r3 = r6
            r4 = r6
            java.lang.String r5 = "HTM014 Argument 'title' is null."
            r4.<init>(r5)
            throw r3
        L_0x0011:
            org.apache.html.dom.HTMLDocumentImpl r3 = new org.apache.html.dom.HTMLDocumentImpl
            r6 = r3
            r3 = r6
            r4 = r6
            r4.<init>()
            r2 = r3
            r3 = r2
            r4 = r1
            r3.setTitle(r4)
            r3 = r2
            r0 = r3
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.html.dom.HTMLDOMImplementationImpl.createHTMLDocument(java.lang.String):org.w3c.dom.html.HTMLDocument");
    }
}
