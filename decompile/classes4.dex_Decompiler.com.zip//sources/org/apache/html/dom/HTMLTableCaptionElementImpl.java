package org.apache.html.dom;

import org.w3c.dom.html.HTMLTableCaptionElement;

public class HTMLTableCaptionElementImpl extends HTMLElementImpl implements HTMLTableCaptionElement {
    private static final long serialVersionUID = 183703024771848940L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLTableCaptionElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getAlign() {
        return getAttribute("align");
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }
}
