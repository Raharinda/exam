package org.apache.html.dom;

import org.w3c.dom.html.HTMLQuoteElement;

public class HTMLQuoteElementImpl extends HTMLElementImpl implements HTMLQuoteElement {
    private static final long serialVersionUID = -67544811597906132L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLQuoteElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getCite() {
        return getAttribute("cite");
    }

    public void setCite(String str) {
        setAttribute("cite", str);
    }
}
