package org.apache.html.dom;

import org.w3c.dom.html.HTMLHeadingElement;

public class HTMLHeadingElementImpl extends HTMLElementImpl implements HTMLHeadingElement {
    private static final long serialVersionUID = 6605827989383069095L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLHeadingElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getAlign() {
        return getCapitalized("align");
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }
}
