package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import java.io.Serializable;
import net.lingala.zip4j.util.Zip4jConstants;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.html.HTMLAnchorElement;
import org.w3c.dom.html.HTMLAppletElement;
import org.w3c.dom.html.HTMLAreaElement;
import org.w3c.dom.html.HTMLCollection;
import org.w3c.dom.html.HTMLElement;
import org.w3c.dom.html.HTMLFormElement;
import org.w3c.dom.html.HTMLImageElement;
import org.w3c.dom.html.HTMLObjectElement;
import org.w3c.dom.html.HTMLOptionElement;
import org.w3c.dom.html.HTMLTableCellElement;
import org.w3c.dom.html.HTMLTableRowElement;
import org.w3c.dom.html.HTMLTableSectionElement;

class HTMLCollectionImpl implements HTMLCollection, Serializable {
    static final short ANCHOR = 1;
    static final short APPLET = 4;
    static final short AREA = -1;
    static final short CELL = -3;
    static final short ELEMENT = 8;
    static final short FORM = 2;
    static final short IMAGE = 3;
    static final short LINK = 5;
    static final short OPTION = 6;
    static final short ROW = 7;
    static final short TBODY = -2;
    private static final long serialVersionUID = 9112122196669185082L;
    private short _lookingFor;
    private Element _topLevel;

    HTMLCollectionImpl(HTMLElement hTMLElement, short s) {
        Throwable th;
        HTMLElement hTMLElement2 = hTMLElement;
        short s2 = s;
        if (hTMLElement2 == null) {
            Throwable th2 = th;
            new NullPointerException("HTM011 Argument 'topLevel' is null.");
            throw th2;
        }
        this._topLevel = hTMLElement2;
        this._lookingFor = s2;
    }

    /* JADX INFO: finally extract failed */
    private int getLength(Element element) {
        int i;
        Element element2 = element;
        Element element3 = element2;
        synchronized (element3) {
            i = 0;
            try {
                for (Node firstChild = element2.getFirstChild(); firstChild != null; firstChild = firstChild.getNextSibling()) {
                    if (firstChild instanceof Element) {
                        if (collectionMatch((Element) firstChild, (String) null)) {
                            i++;
                        } else if (recurse()) {
                            i += getLength((Element) firstChild);
                        }
                    }
                }
            } catch (Throwable th) {
                Throwable th2 = th;
                Element element4 = element3;
                throw th2;
            }
        }
        return i;
    }

    /* JADX INFO: finally extract failed */
    private Node item(Element element, CollectionIndex collectionIndex) {
        Node item;
        Element element2 = element;
        CollectionIndex collectionIndex2 = collectionIndex;
        Element element3 = element2;
        synchronized (element3) {
            try {
                for (Node firstChild = element2.getFirstChild(); firstChild != null; firstChild = firstChild.getNextSibling()) {
                    if (firstChild instanceof Element) {
                        if (collectionMatch((Element) firstChild, (String) null)) {
                            if (collectionIndex2.isZero()) {
                                Node node = firstChild;
                                return node;
                            }
                            collectionIndex2.decrement();
                        } else if (recurse() && (item = item((Element) firstChild, collectionIndex2)) != null) {
                            Node node2 = item;
                            return node2;
                        }
                    }
                }
                return null;
            } catch (Throwable th) {
                Throwable th2 = th;
                Element element4 = element3;
                throw th2;
            }
        }
    }

    /* JADX INFO: finally extract failed */
    private Node namedItem(Element element, String str) {
        Node namedItem;
        Element element2 = element;
        String str2 = str;
        Element element3 = element2;
        synchronized (element3) {
            try {
                Node firstChild = element2.getFirstChild();
                while (true) {
                    Node node = firstChild;
                    if (node == null) {
                        Node node2 = node;
                        return node2;
                    }
                    if (node instanceof Element) {
                        if (collectionMatch((Element) node, str2)) {
                            Node node3 = node;
                            return node3;
                        } else if (recurse() && (namedItem = namedItem((Element) node, str2)) != null) {
                            Node node4 = namedItem;
                            return node4;
                        }
                    }
                    firstChild = node.getNextSibling();
                }
            } catch (Throwable th) {
                Throwable th2 = th;
                Element element4 = element3;
                throw th2;
            }
        }
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: protected */
    public boolean collectionMatch(Element element, String str) {
        Element element2 = element;
        String str2 = str;
        Element element3 = element2;
        synchronized (element3) {
            boolean z = false;
            try {
                switch (this._lookingFor) {
                    case -3:
                        z = element2 instanceof HTMLTableCellElement;
                        break;
                    case -2:
                        z = (element2 instanceof HTMLTableSectionElement) && element2.getTagName().equals("TBODY");
                        break;
                    case -1:
                        z = element2 instanceof HTMLAreaElement;
                        break;
                    case 1:
                        z = (element2 instanceof HTMLAnchorElement) && element2.getAttribute(CommonProperties.NAME).length() > 0;
                        break;
                    case 2:
                        z = element2 instanceof HTMLFormElement;
                        break;
                    case 3:
                        z = element2 instanceof HTMLImageElement;
                        break;
                    case 4:
                        z = (element2 instanceof HTMLAppletElement) || ((element2 instanceof HTMLObjectElement) && ("application/java".equals(element2.getAttribute("codetype")) || element2.getAttribute("classid").startsWith("java:")));
                        break;
                    case 5:
                        z = ((element2 instanceof HTMLAnchorElement) || (element2 instanceof HTMLAreaElement)) && element2.getAttribute("href").length() > 0;
                        break;
                    case 6:
                        z = element2 instanceof HTMLOptionElement;
                        break;
                    case Zip4jConstants.DEFLATE_LEVEL_MAXIMUM:
                        z = element2 instanceof HTMLTableRowElement;
                        break;
                    case 8:
                        z = element2 instanceof HTMLFormControl;
                        break;
                }
                if (z && str2 != null) {
                    if ((element2 instanceof HTMLAnchorElement) && str2.equals(element2.getAttribute(CommonProperties.NAME))) {
                        return true;
                    }
                    z = str2.equals(element2.getAttribute(CommonProperties.ID));
                }
                return z;
            } catch (Throwable th) {
                Throwable th2 = th;
                Element element4 = element3;
                throw th2;
            }
        }
    }

    public final int getLength() {
        return getLength(this._topLevel);
    }

    public final Node item(int i) {
        CollectionIndex collectionIndex;
        Throwable th;
        int i2 = i;
        if (i2 < 0) {
            Throwable th2 = th;
            new IllegalArgumentException("HTM012 Argument 'index' is negative.");
            throw th2;
        }
        new CollectionIndex(i2);
        return item(this._topLevel, collectionIndex);
    }

    public final Node namedItem(String str) {
        Throwable th;
        String str2 = str;
        if (str2 != null) {
            return namedItem(this._topLevel, str2);
        }
        Throwable th2 = th;
        new NullPointerException("HTM013 Argument 'name' is null.");
        throw th2;
    }

    /* access modifiers changed from: protected */
    public boolean recurse() {
        return this._lookingFor > 0;
    }
}
