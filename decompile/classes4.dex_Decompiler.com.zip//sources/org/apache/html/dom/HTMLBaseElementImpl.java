package org.apache.html.dom;

import org.w3c.dom.html.HTMLBaseElement;

public class HTMLBaseElementImpl extends HTMLElementImpl implements HTMLBaseElement {
    private static final long serialVersionUID = -396648580810072153L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLBaseElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getHref() {
        return getAttribute("href");
    }

    public String getTarget() {
        return getAttribute("target");
    }

    public void setHref(String str) {
        setAttribute("href", str);
    }

    public void setTarget(String str) {
        setAttribute("target", str);
    }
}
