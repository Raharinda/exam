package org.apache.html.dom;

import org.w3c.dom.Node;
import org.w3c.dom.Text;
import org.w3c.dom.html.HTMLTitleElement;

public class HTMLTitleElementImpl extends HTMLElementImpl implements HTMLTitleElement {
    private static final long serialVersionUID = 879646303512367875L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLTitleElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getText() {
        StringBuffer stringBuffer;
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        Node firstChild = getFirstChild();
        while (true) {
            Node node = firstChild;
            if (node == null) {
                return stringBuffer2.toString();
            }
            if (node instanceof Text) {
                StringBuffer append = stringBuffer2.append(((Text) node).getData());
            }
            firstChild = node.getNextSibling();
        }
    }

    public void setText(String str) {
        String str2 = str;
        Node firstChild = getFirstChild();
        while (true) {
            Node node = firstChild;
            if (node == null) {
                Node insertBefore = insertBefore(getOwnerDocument().createTextNode(str2), getFirstChild());
                return;
            }
            Node nextSibling = node.getNextSibling();
            Node removeChild = removeChild(node);
            firstChild = nextSibling;
        }
    }
}
