package org.apache.html.dom;

import org.apache.xml.serialize.Method;
import org.w3c.dom.html.HTMLBodyElement;

public class HTMLBodyElementImpl extends HTMLElementImpl implements HTMLBodyElement {
    private static final long serialVersionUID = 9058852459426595202L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLBodyElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getALink() {
        return getAttribute("alink");
    }

    public String getBackground() {
        return getAttribute("background");
    }

    public String getBgColor() {
        return getAttribute("bgcolor");
    }

    public String getLink() {
        return getAttribute("link");
    }

    public String getText() {
        return getAttribute(Method.TEXT);
    }

    public String getVLink() {
        return getAttribute("vlink");
    }

    public void setALink(String str) {
        setAttribute("alink", str);
    }

    public void setBackground(String str) {
        setAttribute("background", str);
    }

    public void setBgColor(String str) {
        setAttribute("bgcolor", str);
    }

    public void setLink(String str) {
        setAttribute("link", str);
    }

    public void setText(String str) {
        setAttribute(Method.TEXT, str);
    }

    public void setVLink(String str) {
        setAttribute("vlink", str);
    }
}
