package org.apache.html.dom;

public interface HTMLFormControl {
}
