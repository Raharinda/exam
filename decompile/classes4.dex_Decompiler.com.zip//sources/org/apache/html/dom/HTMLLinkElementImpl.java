package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.html.HTMLLinkElement;

public class HTMLLinkElementImpl extends HTMLElementImpl implements HTMLLinkElement {
    private static final long serialVersionUID = 874345520063418879L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLLinkElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getCharset() {
        return getAttribute("charset");
    }

    public boolean getDisabled() {
        return getBinary("disabled");
    }

    public String getHref() {
        return getAttribute("href");
    }

    public String getHreflang() {
        return getAttribute("hreflang");
    }

    public String getMedia() {
        return getAttribute("media");
    }

    public String getRel() {
        return getAttribute("rel");
    }

    public String getRev() {
        return getAttribute("rev");
    }

    public String getTarget() {
        return getAttribute("target");
    }

    public String getType() {
        return getAttribute(CommonProperties.TYPE);
    }

    public void setCharset(String str) {
        setAttribute("charset", str);
    }

    public void setDisabled(boolean z) {
        setAttribute("disabled", z);
    }

    public void setHref(String str) {
        setAttribute("href", str);
    }

    public void setHreflang(String str) {
        setAttribute("hreflang", str);
    }

    public void setMedia(String str) {
        setAttribute("media", str);
    }

    public void setRel(String str) {
        setAttribute("rel", str);
    }

    public void setRev(String str) {
        setAttribute("rev", str);
    }

    public void setTarget(String str) {
        setAttribute("target", str);
    }

    public void setType(String str) {
        setAttribute(CommonProperties.TYPE, str);
    }
}
