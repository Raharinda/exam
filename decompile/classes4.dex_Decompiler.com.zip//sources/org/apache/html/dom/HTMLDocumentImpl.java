package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import java.io.StringWriter;
import java.util.Hashtable;
import java.util.Locale;
import org.apache.xerces.dom.CoreDocumentImpl;
import org.apache.xerces.dom.DocumentImpl;
import org.apache.xerces.dom.ElementImpl;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.html.HTMLCollection;
import org.w3c.dom.html.HTMLDocument;
import org.w3c.dom.html.HTMLElement;
import org.w3c.dom.html.HTMLHtmlElement;
import org.w3c.dom.html.HTMLTitleElement;

public class HTMLDocumentImpl extends DocumentImpl implements HTMLDocument {
    private static final Class[] _elemClassSigHTML;
    private static Hashtable _elementTypesHTML = null;
    static Class class$java$lang$String = null;
    static Class class$org$apache$html$dom$HTMLDocumentImpl = null;
    private static final long serialVersionUID = 4285791750126227180L;
    private HTMLCollectionImpl _anchors;
    private HTMLCollectionImpl _applets;
    private HTMLCollectionImpl _forms;
    private HTMLCollectionImpl _images;
    private HTMLCollectionImpl _links;
    private StringWriter _writer;

    static {
        Class cls;
        Class cls2;
        Class[] clsArr = new Class[2];
        Class[] clsArr2 = clsArr;
        Class[] clsArr3 = clsArr;
        if (class$org$apache$html$dom$HTMLDocumentImpl == null) {
            Class class$ = class$("org.apache.html.dom.HTMLDocumentImpl");
            cls = class$;
            class$org$apache$html$dom$HTMLDocumentImpl = class$;
        } else {
            cls = class$org$apache$html$dom$HTMLDocumentImpl;
        }
        clsArr3[0] = cls;
        Class[] clsArr4 = clsArr2;
        Class[] clsArr5 = clsArr4;
        Class[] clsArr6 = clsArr4;
        if (class$java$lang$String == null) {
            Class class$2 = class$("java.lang.String");
            cls2 = class$2;
            class$java$lang$String = class$2;
        } else {
            cls2 = class$java$lang$String;
        }
        clsArr6[1] = cls2;
        _elemClassSigHTML = clsArr5;
    }

    public HTMLDocumentImpl() {
        populateElementTypes();
    }

    static Class class$(String str) {
        Throwable th;
        try {
            return Class.forName(str);
        } catch (ClassNotFoundException e) {
            ClassNotFoundException classNotFoundException = e;
            Throwable th2 = th;
            new NoClassDefFoundError(classNotFoundException.getMessage());
            throw th2;
        }
    }

    private Element getElementById(String str, Node node) {
        String str2 = str;
        Node firstChild = node.getFirstChild();
        while (true) {
            Node node2 = firstChild;
            if (node2 == null) {
                return null;
            }
            if (node2 instanceof Element) {
                if (str2.equals(((Element) node2).getAttribute(CommonProperties.ID))) {
                    return (Element) node2;
                }
                Element elementById = getElementById(str2, node2);
                if (elementById != null) {
                    return elementById;
                }
            }
            firstChild = node2.getNextSibling();
        }
    }

    private static void populateElementType(String str, String str2) {
        Throwable th;
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        Class cls;
        String str3 = str;
        String str4 = str2;
        try {
            Hashtable hashtable = _elementTypesHTML;
            String str5 = str3;
            new StringBuffer();
            String stringBuffer3 = stringBuffer2.append("org.apache.html.dom.").append(str4).toString();
            if (class$org$apache$html$dom$HTMLDocumentImpl == null) {
                Class class$ = class$("org.apache.html.dom.HTMLDocumentImpl");
                cls = class$;
                class$org$apache$html$dom$HTMLDocumentImpl = class$;
            } else {
                cls = class$org$apache$html$dom$HTMLDocumentImpl;
            }
            Object put = hashtable.put(str5, ObjectFactory.findProviderClass(stringBuffer3, cls.getClassLoader(), true));
        } catch (Exception e) {
            Exception exc = e;
            Throwable th2 = th;
            new StringBuffer();
            new RuntimeException(stringBuffer.append("HTM019 OpenXML Error: Could not find or execute class ").append(str4).append(" implementing HTML element ").append(str3).append("\n").append(str4).append("\t").append(str3).toString());
            throw th2;
        }
    }

    private static synchronized void populateElementTypes() {
        Hashtable hashtable;
        synchronized (HTMLDocumentImpl.class) {
            if (_elementTypesHTML == null) {
                new Hashtable(63);
                _elementTypesHTML = hashtable;
                populateElementType("A", "HTMLAnchorElementImpl");
                populateElementType("APPLET", "HTMLAppletElementImpl");
                populateElementType("AREA", "HTMLAreaElementImpl");
                populateElementType("BASE", "HTMLBaseElementImpl");
                populateElementType("BASEFONT", "HTMLBaseFontElementImpl");
                populateElementType("BLOCKQUOTE", "HTMLQuoteElementImpl");
                populateElementType("BODY", "HTMLBodyElementImpl");
                populateElementType("BR", "HTMLBRElementImpl");
                populateElementType("BUTTON", "HTMLButtonElementImpl");
                populateElementType("DEL", "HTMLModElementImpl");
                populateElementType("DIR", "HTMLDirectoryElementImpl");
                populateElementType("DIV", "HTMLDivElementImpl");
                populateElementType("DL", "HTMLDListElementImpl");
                populateElementType("FIELDSET", "HTMLFieldSetElementImpl");
                populateElementType("FONT", "HTMLFontElementImpl");
                populateElementType("FORM", "HTMLFormElementImpl");
                populateElementType("FRAME", "HTMLFrameElementImpl");
                populateElementType("FRAMESET", "HTMLFrameSetElementImpl");
                populateElementType("HEAD", "HTMLHeadElementImpl");
                populateElementType("H1", "HTMLHeadingElementImpl");
                populateElementType("H2", "HTMLHeadingElementImpl");
                populateElementType("H3", "HTMLHeadingElementImpl");
                populateElementType("H4", "HTMLHeadingElementImpl");
                populateElementType("H5", "HTMLHeadingElementImpl");
                populateElementType("H6", "HTMLHeadingElementImpl");
                populateElementType("HR", "HTMLHRElementImpl");
                populateElementType("HTML", "HTMLHtmlElementImpl");
                populateElementType("IFRAME", "HTMLIFrameElementImpl");
                populateElementType("IMG", "HTMLImageElementImpl");
                populateElementType("INPUT", "HTMLInputElementImpl");
                populateElementType("INS", "HTMLModElementImpl");
                populateElementType("ISINDEX", "HTMLIsIndexElementImpl");
                populateElementType("LABEL", "HTMLLabelElementImpl");
                populateElementType("LEGEND", "HTMLLegendElementImpl");
                populateElementType("LI", "HTMLLIElementImpl");
                populateElementType("LINK", "HTMLLinkElementImpl");
                populateElementType("MAP", "HTMLMapElementImpl");
                populateElementType("MENU", "HTMLMenuElementImpl");
                populateElementType("META", "HTMLMetaElementImpl");
                populateElementType("OBJECT", "HTMLObjectElementImpl");
                populateElementType("OL", "HTMLOListElementImpl");
                populateElementType("OPTGROUP", "HTMLOptGroupElementImpl");
                populateElementType("OPTION", "HTMLOptionElementImpl");
                populateElementType("P", "HTMLParagraphElementImpl");
                populateElementType("PARAM", "HTMLParamElementImpl");
                populateElementType("PRE", "HTMLPreElementImpl");
                populateElementType("Q", "HTMLQuoteElementImpl");
                populateElementType("SCRIPT", "HTMLScriptElementImpl");
                populateElementType("SELECT", "HTMLSelectElementImpl");
                populateElementType("STYLE", "HTMLStyleElementImpl");
                populateElementType("TABLE", "HTMLTableElementImpl");
                populateElementType("CAPTION", "HTMLTableCaptionElementImpl");
                populateElementType("TD", "HTMLTableCellElementImpl");
                populateElementType("TH", "HTMLTableCellElementImpl");
                populateElementType("COL", "HTMLTableColElementImpl");
                populateElementType("COLGROUP", "HTMLTableColElementImpl");
                populateElementType("TR", "HTMLTableRowElementImpl");
                populateElementType("TBODY", "HTMLTableSectionElementImpl");
                populateElementType("THEAD", "HTMLTableSectionElementImpl");
                populateElementType("TFOOT", "HTMLTableSectionElementImpl");
                populateElementType("TEXTAREA", "HTMLTextAreaElementImpl");
                populateElementType("TITLE", "HTMLTitleElementImpl");
                populateElementType("UL", "HTMLUListElementImpl");
            }
        }
    }

    /* access modifiers changed from: protected */
    public boolean canRenameElements(String str, String str2, ElementImpl elementImpl) {
        String str3 = str;
        String str4 = str2;
        ElementImpl elementImpl2 = elementImpl;
        if (elementImpl2.getNamespaceURI() != null) {
            return str3 != null;
        }
        return ((Class) _elementTypesHTML.get(str4.toUpperCase(Locale.ENGLISH))) == ((Class) _elementTypesHTML.get(elementImpl2.getTagName()));
    }

    public Node cloneNode(boolean z) {
        CoreDocumentImpl coreDocumentImpl;
        new HTMLDocumentImpl();
        CoreDocumentImpl coreDocumentImpl2 = coreDocumentImpl;
        callUserDataHandlers(this, coreDocumentImpl2, 1);
        cloneNode(coreDocumentImpl2, z);
        return coreDocumentImpl2;
    }

    public void close() {
        if (this._writer != null) {
            this._writer = null;
        }
    }

    public Attr createAttribute(String str) throws DOMException {
        return super.createAttribute(str.toLowerCase(Locale.ENGLISH));
    }

    public Element createElement(String str) throws DOMException {
        Element element;
        Throwable th;
        StringBuffer stringBuffer;
        String upperCase = str.toUpperCase(Locale.ENGLISH);
        Class cls = (Class) _elementTypesHTML.get(upperCase);
        if (cls != null) {
            Class cls2 = cls;
            try {
                Object[] objArr = new Object[2];
                objArr[0] = this;
                Object[] objArr2 = objArr;
                objArr2[1] = upperCase;
                return (Element) cls2.getConstructor(_elemClassSigHTML).newInstance(objArr2);
            } catch (Exception e) {
                Exception exc = e;
                Throwable th2 = th;
                new StringBuffer();
                new IllegalStateException(stringBuffer.append("HTM15 Tag '").append(upperCase).append("' associated with an Element class that failed to construct.\n").append(upperCase).toString());
                throw th2;
            }
        } else {
            new HTMLElementImpl(this, upperCase);
            return element;
        }
    }

    public Element createElementNS(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        return (str3 == null || str3.length() == 0) ? createElement(str4) : super.createElementNS(str3, str4);
    }

    public Element createElementNS(String str, String str2, String str3) throws DOMException {
        String str4 = str3;
        return createElementNS(str, str2);
    }

    public HTMLCollection getAnchors() {
        HTMLCollectionImpl hTMLCollectionImpl;
        if (this._anchors == null) {
            new HTMLCollectionImpl(getBody(), 1);
            this._anchors = hTMLCollectionImpl;
        }
        return this._anchors;
    }

    public HTMLCollection getApplets() {
        HTMLCollectionImpl hTMLCollectionImpl;
        if (this._applets == null) {
            new HTMLCollectionImpl(getBody(), 4);
            this._applets = hTMLCollectionImpl;
        }
        return this._applets;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:43:0x0063, code lost:
        r10 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x0068, code lost:
        throw r10;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized org.w3c.dom.html.HTMLElement getBody() {
        /*
            r16 = this;
            r0 = r16
            r14 = r16
            monitor-enter(r14)
            r10 = r0
            org.w3c.dom.Element r10 = r10.getDocumentElement()     // Catch:{ all -> 0x006f }
            r1 = r10
            r10 = r0
            org.w3c.dom.html.HTMLElement r10 = r10.getHead()     // Catch:{ all -> 0x006f }
            r2 = r10
            r10 = r1
            r6 = r10
            r10 = r6
            monitor-enter(r10)     // Catch:{ all -> 0x006f }
            r10 = r2
            org.w3c.dom.Node r10 = r10.getNextSibling()     // Catch:{ all -> 0x0069 }
            r3 = r10
        L_0x001b:
            r10 = r3
            if (r10 == 0) goto L_0x0028
            r10 = r3
            boolean r10 = r10 instanceof org.w3c.dom.html.HTMLBodyElement     // Catch:{ all -> 0x0069 }
            if (r10 != 0) goto L_0x0028
            r10 = r3
            boolean r10 = r10 instanceof org.w3c.dom.html.HTMLFrameSetElement     // Catch:{ all -> 0x0069 }
            if (r10 == 0) goto L_0x0048
        L_0x0028:
            r10 = r3
            if (r10 == 0) goto L_0x0072
            r10 = r3
            r7 = r10
            r10 = r7
            monitor-enter(r10)     // Catch:{ all -> 0x0069 }
            r10 = r2
            org.w3c.dom.Node r10 = r10.getNextSibling()     // Catch:{ all -> 0x0063 }
            r4 = r10
        L_0x0035:
            r10 = r4
            if (r10 == 0) goto L_0x003c
            r10 = r4
            r11 = r3
            if (r10 != r11) goto L_0x004f
        L_0x003c:
            r10 = r7
            monitor-exit(r10)     // Catch:{ all -> 0x0063 }
            r10 = r3
            org.w3c.dom.html.HTMLElement r10 = (org.w3c.dom.html.HTMLElement) r10     // Catch:{ all -> 0x0069 }
            r8 = r10
            r10 = r6
            monitor-exit(r10)     // Catch:{ all -> 0x0069 }
            r10 = r8
            r0 = r10
        L_0x0046:
            monitor-exit(r14)
            return r0
        L_0x0048:
            r10 = r3
            org.w3c.dom.Node r10 = r10.getNextSibling()     // Catch:{ all -> 0x0069 }
            r3 = r10
            goto L_0x001b
        L_0x004f:
            r10 = r4
            org.w3c.dom.Node r10 = r10.getNextSibling()     // Catch:{ all -> 0x0063 }
            r5 = r10
            r10 = r3
            r11 = r4
            r12 = r3
            org.w3c.dom.Node r12 = r12.getFirstChild()     // Catch:{ all -> 0x0063 }
            org.w3c.dom.Node r10 = r10.insertBefore(r11, r12)     // Catch:{ all -> 0x0063 }
            r10 = r5
            r4 = r10
            goto L_0x0035
        L_0x0063:
            r10 = move-exception
            r8 = r10
            r10 = r7
            monitor-exit(r10)     // Catch:{ all -> 0x0069 }
            r10 = r8
            throw r10     // Catch:{ all -> 0x0069 }
        L_0x0069:
            r10 = move-exception
            r9 = r10
            r10 = r6
            monitor-exit(r10)     // Catch:{ all -> 0x006f }
            r10 = r9
            throw r10     // Catch:{ all -> 0x006f }
        L_0x006f:
            r0 = move-exception
            monitor-exit(r14)
            throw r0
        L_0x0072:
            org.apache.html.dom.HTMLBodyElementImpl r10 = new org.apache.html.dom.HTMLBodyElementImpl     // Catch:{ all -> 0x0069 }
            r15 = r10
            r10 = r15
            r11 = r15
            r12 = r0
            java.lang.String r13 = "BODY"
            r11.<init>(r12, r13)     // Catch:{ all -> 0x0069 }
            r3 = r10
            r10 = r1
            r11 = r3
            org.w3c.dom.Node r10 = r10.appendChild(r11)     // Catch:{ all -> 0x0069 }
            r10 = r6
            monitor-exit(r10)     // Catch:{ all -> 0x0069 }
            r10 = r3
            org.w3c.dom.html.HTMLElement r10 = (org.w3c.dom.html.HTMLElement) r10     // Catch:{ all -> 0x006f }
            r0 = r10
            goto L_0x0046
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.html.dom.HTMLDocumentImpl.getBody():org.w3c.dom.html.HTMLElement");
    }

    public String getCookie() {
        return null;
    }

    public synchronized Element getDocumentElement() {
        Node node;
        Element element;
        synchronized (this) {
            Node firstChild = getFirstChild();
            while (true) {
                if (firstChild == null) {
                    new HTMLHtmlElementImpl(this, "HTML");
                    Node node2 = node;
                    Node firstChild2 = getFirstChild();
                    while (true) {
                        Node node3 = firstChild2;
                        if (node3 == null) {
                            break;
                        }
                        Node nextSibling = node3.getNextSibling();
                        Node appendChild = node2.appendChild(node3);
                        firstChild2 = nextSibling;
                    }
                    Node appendChild2 = appendChild(node2);
                    element = (HTMLElement) node2;
                } else if (firstChild instanceof HTMLHtmlElement) {
                    element = firstChild;
                    break;
                } else {
                    firstChild = firstChild.getNextSibling();
                }
            }
        }
        return element;
    }

    public String getDomain() {
        return null;
    }

    public synchronized Element getElementById(String str) {
        Element elementById;
        String str2 = str;
        synchronized (this) {
            Element elementById2 = super.getElementById(str2);
            elementById = elementById2 != null ? elementById2 : getElementById(str2, this);
        }
        return elementById;
    }

    public NodeList getElementsByName(String str) {
        NodeList nodeList;
        new NameNodeListImpl(this, str);
        return nodeList;
    }

    public final NodeList getElementsByTagName(String str) {
        return super.getElementsByTagName(str.toUpperCase(Locale.ENGLISH));
    }

    public final NodeList getElementsByTagNameNS(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        return (str3 == null || str3.length() <= 0) ? super.getElementsByTagName(str4.toUpperCase(Locale.ENGLISH)) : super.getElementsByTagNameNS(str3, str4.toUpperCase(Locale.ENGLISH));
    }

    public HTMLCollection getForms() {
        HTMLCollectionImpl hTMLCollectionImpl;
        if (this._forms == null) {
            new HTMLCollectionImpl(getBody(), 2);
            this._forms = hTMLCollectionImpl;
        }
        return this._forms;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:41:0x0056, code lost:
        r9 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x005b, code lost:
        throw r9;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized org.w3c.dom.html.HTMLElement getHead() {
        /*
            r15 = this;
            r0 = r15
            r13 = r15
            monitor-enter(r13)
            r9 = r0
            org.w3c.dom.Element r9 = r9.getDocumentElement()     // Catch:{ all -> 0x0062 }
            r2 = r9
            r9 = r2
            r5 = r9
            r9 = r5
            monitor-enter(r9)     // Catch:{ all -> 0x0062 }
            r9 = r2
            org.w3c.dom.Node r9 = r9.getFirstChild()     // Catch:{ all -> 0x005c }
            r1 = r9
        L_0x0013:
            r9 = r1
            if (r9 == 0) goto L_0x001b
            r9 = r1
            boolean r9 = r9 instanceof org.w3c.dom.html.HTMLHeadElement     // Catch:{ all -> 0x005c }
            if (r9 == 0) goto L_0x003b
        L_0x001b:
            r9 = r1
            if (r9 == 0) goto L_0x0065
            r9 = r1
            r6 = r9
            r9 = r6
            monitor-enter(r9)     // Catch:{ all -> 0x005c }
            r9 = r2
            org.w3c.dom.Node r9 = r9.getFirstChild()     // Catch:{ all -> 0x0056 }
            r3 = r9
        L_0x0028:
            r9 = r3
            if (r9 == 0) goto L_0x002f
            r9 = r3
            r10 = r1
            if (r9 != r10) goto L_0x0042
        L_0x002f:
            r9 = r6
            monitor-exit(r9)     // Catch:{ all -> 0x0056 }
            r9 = r1
            org.w3c.dom.html.HTMLElement r9 = (org.w3c.dom.html.HTMLElement) r9     // Catch:{ all -> 0x005c }
            r7 = r9
            r9 = r5
            monitor-exit(r9)     // Catch:{ all -> 0x005c }
            r9 = r7
            r0 = r9
        L_0x0039:
            monitor-exit(r13)
            return r0
        L_0x003b:
            r9 = r1
            org.w3c.dom.Node r9 = r9.getNextSibling()     // Catch:{ all -> 0x005c }
            r1 = r9
            goto L_0x0013
        L_0x0042:
            r9 = r3
            org.w3c.dom.Node r9 = r9.getNextSibling()     // Catch:{ all -> 0x0056 }
            r4 = r9
            r9 = r1
            r10 = r3
            r11 = r1
            org.w3c.dom.Node r11 = r11.getFirstChild()     // Catch:{ all -> 0x0056 }
            org.w3c.dom.Node r9 = r9.insertBefore(r10, r11)     // Catch:{ all -> 0x0056 }
            r9 = r4
            r3 = r9
            goto L_0x0028
        L_0x0056:
            r9 = move-exception
            r7 = r9
            r9 = r6
            monitor-exit(r9)     // Catch:{ all -> 0x005c }
            r9 = r7
            throw r9     // Catch:{ all -> 0x005c }
        L_0x005c:
            r9 = move-exception
            r8 = r9
            r9 = r5
            monitor-exit(r9)     // Catch:{ all -> 0x0062 }
            r9 = r8
            throw r9     // Catch:{ all -> 0x0062 }
        L_0x0062:
            r0 = move-exception
            monitor-exit(r13)
            throw r0
        L_0x0065:
            org.apache.html.dom.HTMLHeadElementImpl r9 = new org.apache.html.dom.HTMLHeadElementImpl     // Catch:{ all -> 0x005c }
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r0
            java.lang.String r12 = "HEAD"
            r10.<init>(r11, r12)     // Catch:{ all -> 0x005c }
            r1 = r9
            r9 = r2
            r10 = r1
            r11 = r2
            org.w3c.dom.Node r11 = r11.getFirstChild()     // Catch:{ all -> 0x005c }
            org.w3c.dom.Node r9 = r9.insertBefore(r10, r11)     // Catch:{ all -> 0x005c }
            r9 = r5
            monitor-exit(r9)     // Catch:{ all -> 0x005c }
            r9 = r1
            org.w3c.dom.html.HTMLElement r9 = (org.w3c.dom.html.HTMLElement) r9     // Catch:{ all -> 0x0062 }
            r0 = r9
            goto L_0x0039
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.html.dom.HTMLDocumentImpl.getHead():org.w3c.dom.html.HTMLElement");
    }

    public HTMLCollection getImages() {
        HTMLCollectionImpl hTMLCollectionImpl;
        if (this._images == null) {
            new HTMLCollectionImpl(getBody(), 3);
            this._images = hTMLCollectionImpl;
        }
        return this._images;
    }

    public HTMLCollection getLinks() {
        HTMLCollectionImpl hTMLCollectionImpl;
        if (this._links == null) {
            new HTMLCollectionImpl(getBody(), 5);
            this._links = hTMLCollectionImpl;
        }
        return this._links;
    }

    public String getReferrer() {
        return null;
    }

    public synchronized String getTitle() {
        String text;
        synchronized (this) {
            NodeList elementsByTagName = getHead().getElementsByTagName("TITLE");
            text = elementsByTagName.getLength() > 0 ? elementsByTagName.item(0).getText() : "";
        }
        return text;
    }

    public String getURL() {
        return null;
    }

    public void open() {
        StringWriter stringWriter;
        if (this._writer == null) {
            new StringWriter();
            this._writer = stringWriter;
        }
    }

    /* JADX INFO: finally extract failed */
    /* JADX WARNING: Code restructure failed: missing block: B:20:?, code lost:
        r13 = r2.appendChild(r1);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void setBody(org.w3c.dom.html.HTMLElement r18) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            r16 = r17
            monitor-enter(r16)
            r13 = r1
            r7 = r13
            r13 = r7
            monitor-enter(r13)     // Catch:{ all -> 0x0081 }
            r13 = r0
            org.w3c.dom.Element r13 = r13.getDocumentElement()     // Catch:{ all -> 0x007b }
            r2 = r13
            r13 = r0
            org.w3c.dom.html.HTMLElement r13 = r13.getHead()     // Catch:{ all -> 0x007b }
            r4 = r13
            r13 = r2
            r8 = r13
            r13 = r8
            monitor-enter(r13)     // Catch:{ all -> 0x007b }
            r13 = r0
            java.lang.String r14 = "BODY"
            org.w3c.dom.NodeList r13 = r13.getElementsByTagName(r14)     // Catch:{ all -> 0x0075 }
            r6 = r13
            r13 = r6
            int r13 = r13.getLength()     // Catch:{ all -> 0x0075 }
            if (r13 <= 0) goto L_0x0084
            r13 = r6
            r14 = 0
            org.w3c.dom.Node r13 = r13.item(r14)     // Catch:{ all -> 0x0075 }
            r3 = r13
            r13 = r3
            r9 = r13
            r13 = r9
            monitor-enter(r13)     // Catch:{ all -> 0x0075 }
            r13 = r4
            r5 = r13
        L_0x0038:
            r13 = r5
            if (r13 != 0) goto L_0x0049
            r13 = r2
            r14 = r1
            org.w3c.dom.Node r13 = r13.appendChild(r14)     // Catch:{ all -> 0x006f }
            r13 = r9
            monitor-exit(r13)     // Catch:{ all -> 0x006f }
            r13 = r8
            monitor-exit(r13)     // Catch:{ all -> 0x0075 }
            r13 = r7
            monitor-exit(r13)     // Catch:{ all -> 0x0075 }
        L_0x0047:
            monitor-exit(r16)
            return
        L_0x0049:
            r13 = r5
            boolean r13 = r13 instanceof org.w3c.dom.Element     // Catch:{ all -> 0x006f }
            if (r13 == 0) goto L_0x0068
            r13 = r5
            r14 = r3
            if (r13 == r14) goto L_0x0060
            r13 = r2
            r14 = r1
            r15 = r5
            org.w3c.dom.Node r13 = r13.insertBefore(r14, r15)     // Catch:{ all -> 0x006f }
        L_0x0059:
            r13 = r9
            monitor-exit(r13)     // Catch:{ all -> 0x006f }
            r13 = r8
            monitor-exit(r13)     // Catch:{ all -> 0x006f }
            r13 = r7
            monitor-exit(r13)     // Catch:{ all -> 0x006f }
            goto L_0x0047
        L_0x0060:
            r13 = r2
            r14 = r1
            r15 = r3
            org.w3c.dom.Node r13 = r13.replaceChild(r14, r15)     // Catch:{ all -> 0x006f }
            goto L_0x0059
        L_0x0068:
            r13 = r5
            org.w3c.dom.Node r13 = r13.getNextSibling()     // Catch:{ all -> 0x006f }
            r5 = r13
            goto L_0x0038
        L_0x006f:
            r13 = move-exception
            r10 = r13
            r13 = r9
            monitor-exit(r13)     // Catch:{ all -> 0x0075 }
            r13 = r10
            throw r13     // Catch:{ all -> 0x0075 }
        L_0x0075:
            r13 = move-exception
            r11 = r13
            r13 = r8
            monitor-exit(r13)     // Catch:{ all -> 0x007b }
            r13 = r11
            throw r13     // Catch:{ all -> 0x007b }
        L_0x007b:
            r13 = move-exception
            r12 = r13
            r13 = r7
            monitor-exit(r13)     // Catch:{ all -> 0x0081 }
            r13 = r12
            throw r13     // Catch:{ all -> 0x0081 }
        L_0x0081:
            r0 = move-exception
            monitor-exit(r16)
            throw r0
        L_0x0084:
            r13 = r2
            r14 = r1
            org.w3c.dom.Node r13 = r13.appendChild(r14)     // Catch:{ all -> 0x0075 }
            r13 = r8
            monitor-exit(r13)     // Catch:{ all -> 0x0075 }
            r13 = r7
            monitor-exit(r13)     // Catch:{ all -> 0x007b }
            goto L_0x0047
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.html.dom.HTMLDocumentImpl.setBody(org.w3c.dom.html.HTMLElement):void");
    }

    public void setCookie(String str) {
    }

    public synchronized void setTitle(String str) {
        HTMLTitleElement hTMLTitleElement;
        String str2 = str;
        synchronized (this) {
            Node head = getHead();
            NodeList elementsByTagName = head.getElementsByTagName("TITLE");
            if (elementsByTagName.getLength() > 0) {
                Node item = elementsByTagName.item(0);
                if (item.getParentNode() != head) {
                    Node appendChild = head.appendChild(item);
                }
                item.setText(str2);
            } else {
                new HTMLTitleElementImpl(this, "TITLE");
                HTMLTitleElement hTMLTitleElement2 = hTMLTitleElement;
                hTMLTitleElement2.setText(str2);
                Node appendChild2 = head.appendChild(hTMLTitleElement2);
            }
        }
    }

    public void write(String str) {
        String str2 = str;
        if (this._writer != null) {
            this._writer.write(str2);
        }
    }

    public void writeln(String str) {
        StringBuffer stringBuffer;
        String str2 = str;
        if (this._writer != null) {
            StringWriter stringWriter = this._writer;
            new StringBuffer();
            stringWriter.write(stringBuffer.append(str2).append("\n").toString());
        }
    }
}
