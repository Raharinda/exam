package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.html.HTMLFrameElement;

public class HTMLFrameElementImpl extends HTMLElementImpl implements HTMLFrameElement {
    private static final long serialVersionUID = 635237057173695984L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLFrameElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getFrameBorder() {
        return getAttribute("frameborder");
    }

    public String getLongDesc() {
        return getAttribute("longdesc");
    }

    public String getMarginHeight() {
        return getAttribute("marginheight");
    }

    public String getMarginWidth() {
        return getAttribute("marginwidth");
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public boolean getNoResize() {
        return getBinary("noresize");
    }

    public String getScrolling() {
        return capitalize(getAttribute("scrolling"));
    }

    public String getSrc() {
        return getAttribute("src");
    }

    public void setFrameBorder(String str) {
        setAttribute("frameborder", str);
    }

    public void setLongDesc(String str) {
        setAttribute("longdesc", str);
    }

    public void setMarginHeight(String str) {
        setAttribute("marginheight", str);
    }

    public void setMarginWidth(String str) {
        setAttribute("marginwidth", str);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setNoResize(boolean z) {
        setAttribute("noresize", z);
    }

    public void setScrolling(String str) {
        setAttribute("scrolling", str);
    }

    public void setSrc(String str) {
        setAttribute("src", str);
    }
}
