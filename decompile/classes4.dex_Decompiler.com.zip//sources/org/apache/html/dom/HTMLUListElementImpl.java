package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.html.HTMLUListElement;

public class HTMLUListElementImpl extends HTMLElementImpl implements HTMLUListElement {
    private static final long serialVersionUID = -3220401442015109211L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLUListElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public boolean getCompact() {
        return getBinary("compact");
    }

    public String getType() {
        return getAttribute(CommonProperties.TYPE);
    }

    public void setCompact(boolean z) {
        setAttribute("compact", z);
    }

    public void setType(String str) {
        setAttribute(CommonProperties.TYPE, str);
    }
}
