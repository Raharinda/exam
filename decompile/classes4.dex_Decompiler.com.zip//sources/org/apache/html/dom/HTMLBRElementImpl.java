package org.apache.html.dom;

import org.w3c.dom.html.HTMLBRElement;

public class HTMLBRElementImpl extends HTMLElementImpl implements HTMLBRElement {
    private static final long serialVersionUID = 311960206282154750L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLBRElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getClear() {
        return capitalize(getAttribute("clear"));
    }

    public void setClear(String str) {
        setAttribute("clear", str);
    }
}
