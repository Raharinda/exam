package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.html.HTMLAnchorElement;

public class HTMLAnchorElementImpl extends HTMLElementImpl implements HTMLAnchorElement {
    private static final long serialVersionUID = -140558580924061847L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLAnchorElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public void blur() {
    }

    public void focus() {
    }

    public String getAccessKey() {
        String attribute = getAttribute("accesskey");
        if (attribute != null && attribute.length() > 1) {
            attribute = attribute.substring(0, 1);
        }
        return attribute;
    }

    public String getCharset() {
        return getAttribute("charset");
    }

    public String getCoords() {
        return getAttribute("coords");
    }

    public String getHref() {
        return getAttribute("href");
    }

    public String getHreflang() {
        return getAttribute("hreflang");
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public String getRel() {
        return getAttribute("rel");
    }

    public String getRev() {
        return getAttribute("rev");
    }

    public String getShape() {
        return capitalize(getAttribute("shape"));
    }

    public int getTabIndex() {
        return getInteger(getAttribute("tabindex"));
    }

    public String getTarget() {
        return getAttribute("target");
    }

    public String getType() {
        return getAttribute(CommonProperties.TYPE);
    }

    public void setAccessKey(String str) {
        String str2 = str;
        if (str2 != null && str2.length() > 1) {
            str2 = str2.substring(0, 1);
        }
        setAttribute("accesskey", str2);
    }

    public void setCharset(String str) {
        setAttribute("charset", str);
    }

    public void setCoords(String str) {
        setAttribute("coords", str);
    }

    public void setHref(String str) {
        setAttribute("href", str);
    }

    public void setHreflang(String str) {
        setAttribute("hreflang", str);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setRel(String str) {
        setAttribute("rel", str);
    }

    public void setRev(String str) {
        setAttribute("rev", str);
    }

    public void setShape(String str) {
        setAttribute("shape", str);
    }

    public void setTabIndex(int i) {
        setAttribute("tabindex", String.valueOf(i));
    }

    public void setTarget(String str) {
        setAttribute("target", str);
    }

    public void setType(String str) {
        setAttribute(CommonProperties.TYPE, str);
    }
}
