package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.html.HTMLParamElement;

public class HTMLParamElementImpl extends HTMLElementImpl implements HTMLParamElement {
    private static final long serialVersionUID = -8513050483880341412L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLParamElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public String getType() {
        return getAttribute(CommonProperties.TYPE);
    }

    public String getValue() {
        return getAttribute(CommonProperties.VALUE);
    }

    public String getValueType() {
        return capitalize(getAttribute("valuetype"));
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setType(String str) {
        setAttribute(CommonProperties.TYPE, str);
    }

    public void setValue(String str) {
        setAttribute(CommonProperties.VALUE, str);
    }

    public void setValueType(String str) {
        setAttribute("valuetype", str);
    }
}
