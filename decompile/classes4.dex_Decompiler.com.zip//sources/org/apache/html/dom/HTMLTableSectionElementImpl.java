package org.apache.html.dom;

import org.w3c.dom.Node;
import org.w3c.dom.html.HTMLCollection;
import org.w3c.dom.html.HTMLElement;
import org.w3c.dom.html.HTMLTableRowElement;
import org.w3c.dom.html.HTMLTableSectionElement;

public class HTMLTableSectionElementImpl extends HTMLElementImpl implements HTMLTableSectionElement {
    private static final long serialVersionUID = 1016412997716618027L;
    private HTMLCollectionImpl _rows;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLTableSectionElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public Node cloneNode(boolean z) {
        HTMLTableSectionElementImpl hTMLTableSectionElementImpl = (HTMLTableSectionElementImpl) super.cloneNode(z);
        hTMLTableSectionElementImpl._rows = null;
        return hTMLTableSectionElementImpl;
    }

    public void deleteRow(int i) {
        int deleteRowX = deleteRowX(i);
    }

    /* access modifiers changed from: package-private */
    public int deleteRowX(int i) {
        int i2 = i;
        Node firstChild = getFirstChild();
        while (true) {
            Node node = firstChild;
            if (node == null) {
                return i2;
            }
            if (node instanceof HTMLTableRowElement) {
                if (i2 == 0) {
                    Node removeChild = removeChild(node);
                    return -1;
                }
                i2--;
            }
            firstChild = node.getNextSibling();
        }
    }

    public String getAlign() {
        return capitalize(getAttribute("align"));
    }

    public String getCh() {
        String attribute = getAttribute("char");
        if (attribute != null && attribute.length() > 1) {
            attribute = attribute.substring(0, 1);
        }
        return attribute;
    }

    public String getChOff() {
        return getAttribute("charoff");
    }

    public HTMLCollection getRows() {
        HTMLCollectionImpl hTMLCollectionImpl;
        if (this._rows == null) {
            new HTMLCollectionImpl(this, 7);
            this._rows = hTMLCollectionImpl;
        }
        return this._rows;
    }

    public String getVAlign() {
        return capitalize(getAttribute("valign"));
    }

    public HTMLElement insertRow(int i) {
        HTMLTableRowElementImpl hTMLTableRowElementImpl;
        new HTMLTableRowElementImpl((HTMLDocumentImpl) getOwnerDocument(), "TR");
        HTMLTableRowElementImpl hTMLTableRowElementImpl2 = hTMLTableRowElementImpl;
        HTMLElement insertCell = hTMLTableRowElementImpl2.insertCell(0);
        if (insertRowX(i, hTMLTableRowElementImpl2) >= 0) {
            Node appendChild = appendChild(hTMLTableRowElementImpl2);
        }
        return hTMLTableRowElementImpl2;
    }

    /* access modifiers changed from: package-private */
    public int insertRowX(int i, HTMLTableRowElementImpl hTMLTableRowElementImpl) {
        int i2 = i;
        HTMLTableRowElementImpl hTMLTableRowElementImpl2 = hTMLTableRowElementImpl;
        Node firstChild = getFirstChild();
        while (true) {
            Node node = firstChild;
            if (node == null) {
                return i2;
            }
            if (node instanceof HTMLTableRowElement) {
                if (i2 == 0) {
                    Node insertBefore = insertBefore(hTMLTableRowElementImpl2, node);
                    return -1;
                }
                i2--;
            }
            firstChild = node.getNextSibling();
        }
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }

    public void setCh(String str) {
        String str2 = str;
        if (str2 != null && str2.length() > 1) {
            str2 = str2.substring(0, 1);
        }
        setAttribute("char", str2);
    }

    public void setChOff(String str) {
        setAttribute("charoff", str);
    }

    public void setVAlign(String str) {
        setAttribute("valign", str);
    }
}
