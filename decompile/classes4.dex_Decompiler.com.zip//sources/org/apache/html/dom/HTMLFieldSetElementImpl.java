package org.apache.html.dom;

import org.w3c.dom.html.HTMLFieldSetElement;

public class HTMLFieldSetElementImpl extends HTMLElementImpl implements HTMLFieldSetElement, HTMLFormControl {
    private static final long serialVersionUID = 1146145578073441343L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLFieldSetElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }
}
