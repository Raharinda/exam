package org.apache.html.dom;

import org.w3c.dom.html.HTMLIsIndexElement;

public class HTMLIsIndexElementImpl extends HTMLElementImpl implements HTMLIsIndexElement {
    private static final long serialVersionUID = 3073521742049689699L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLIsIndexElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getPrompt() {
        return getAttribute("prompt");
    }

    public void setPrompt(String str) {
        setAttribute("prompt", str);
    }
}
