package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import java.util.Locale;
import org.apache.xerces.dom.ElementImpl;
import org.w3c.dom.Attr;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.html.HTMLElement;
import org.w3c.dom.html.HTMLFormElement;

public class HTMLElementImpl extends ElementImpl implements HTMLElement {
    private static final long serialVersionUID = 5283925246324423495L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str.toUpperCase(Locale.ENGLISH));
    }

    /* access modifiers changed from: package-private */
    public String capitalize(String str) {
        String str2 = str;
        char[] charArray = str2.toCharArray();
        if (charArray.length <= 0) {
            return str2;
        }
        charArray[0] = Character.toUpperCase(charArray[0]);
        for (int i = 1; i < charArray.length; i++) {
            charArray[i] = Character.toLowerCase(charArray[i]);
        }
        return String.valueOf(charArray);
    }

    public String getAttribute(String str) {
        return super.getAttribute(str.toLowerCase(Locale.ENGLISH));
    }

    public String getAttributeNS(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        return (str3 == null || str3.length() <= 0) ? super.getAttribute(str4.toLowerCase(Locale.ENGLISH)) : super.getAttributeNS(str3, str4);
    }

    public Attr getAttributeNode(String str) {
        return super.getAttributeNode(str.toLowerCase(Locale.ENGLISH));
    }

    public Attr getAttributeNodeNS(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        return (str3 == null || str3.length() <= 0) ? super.getAttributeNode(str4.toLowerCase(Locale.ENGLISH)) : super.getAttributeNodeNS(str3, str4);
    }

    /* access modifiers changed from: package-private */
    public boolean getBinary(String str) {
        return getAttributeNode(str) != null;
    }

    /* access modifiers changed from: package-private */
    public String getCapitalized(String str) {
        String attribute = getAttribute(str);
        if (attribute != null) {
            char[] charArray = attribute.toCharArray();
            if (charArray.length > 0) {
                charArray[0] = Character.toUpperCase(charArray[0]);
                for (int i = 1; i < charArray.length; i++) {
                    charArray[i] = Character.toLowerCase(charArray[i]);
                }
                return String.valueOf(charArray);
            }
        }
        return attribute;
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getDir() {
        return getAttribute("dir");
    }

    public final NodeList getElementsByTagName(String str) {
        return super.getElementsByTagName(str.toUpperCase(Locale.ENGLISH));
    }

    public final NodeList getElementsByTagNameNS(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        return (str3 == null || str3.length() <= 0) ? super.getElementsByTagName(str4.toUpperCase(Locale.ENGLISH)) : super.getElementsByTagNameNS(str3, str4.toUpperCase(Locale.ENGLISH));
    }

    public HTMLFormElement getForm() {
        HTMLFormElement parentNode = getParentNode();
        while (true) {
            Node node = parentNode;
            if (node == null) {
                return null;
            }
            if (node instanceof HTMLFormElement) {
                return node;
            }
            parentNode = node.getParentNode();
        }
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    /* access modifiers changed from: package-private */
    public int getInteger(String str) {
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException e) {
            NumberFormatException numberFormatException = e;
            return 0;
        }
    }

    public String getLang() {
        return getAttribute("lang");
    }

    public String getTitle() {
        return getAttribute("title");
    }

    /* access modifiers changed from: package-private */
    public void setAttribute(String str, boolean z) {
        String str2 = str;
        if (z) {
            setAttribute(str2, str2);
        } else {
            removeAttribute(str2);
        }
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setDir(String str) {
        setAttribute("dir", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setLang(String str) {
        setAttribute("lang", str);
    }

    public void setTitle(String str) {
        setAttribute("title", str);
    }
}
