package org.apache.html.dom;

class CollectionIndex {
    private int _index;

    CollectionIndex(int i) {
        this._index = i;
    }

    /* access modifiers changed from: package-private */
    public void decrement() {
        this._index--;
    }

    /* access modifiers changed from: package-private */
    public int getIndex() {
        return this._index;
    }

    /* access modifiers changed from: package-private */
    public boolean isZero() {
        return this._index <= 0;
    }
}
