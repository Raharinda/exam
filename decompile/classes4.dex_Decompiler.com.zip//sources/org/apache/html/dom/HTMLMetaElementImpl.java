package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.html.HTMLMetaElement;

public class HTMLMetaElementImpl extends HTMLElementImpl implements HTMLMetaElement {
    private static final long serialVersionUID = -2401961905874264272L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLMetaElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getContent() {
        return getAttribute("content");
    }

    public String getHttpEquiv() {
        return getAttribute("http-equiv");
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public String getScheme() {
        return getAttribute("scheme");
    }

    public void setContent(String str) {
        setAttribute("content", str);
    }

    public void setHttpEquiv(String str) {
        setAttribute("http-equiv", str);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setScheme(String str) {
        setAttribute("scheme", str);
    }
}
