package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.w3c.dom.html.HTMLElement;
import org.w3c.dom.html.HTMLOptionElement;
import org.w3c.dom.html.HTMLSelectElement;

public class HTMLOptionElementImpl extends HTMLElementImpl implements HTMLOptionElement {
    private static final long serialVersionUID = -4486774554137530907L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLOptionElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public boolean getDefaultSelected() {
        return getBinary("default-selected");
    }

    public boolean getDisabled() {
        return getBinary("disabled");
    }

    public int getIndex() {
        Node node;
        HTMLElement parentNode = getParentNode();
        while (true) {
            node = parentNode;
            if (node != null && !(node instanceof HTMLSelectElement)) {
                parentNode = node.getParentNode();
            }
        }
        if (node != null) {
            NodeList elementsByTagName = node.getElementsByTagName("OPTION");
            for (int i = 0; i < elementsByTagName.getLength(); i++) {
                if (elementsByTagName.item(i) == this) {
                    return i;
                }
            }
        }
        return -1;
    }

    public String getLabel() {
        return capitalize(getAttribute("label"));
    }

    public boolean getSelected() {
        return getBinary("selected");
    }

    public String getText() {
        StringBuffer stringBuffer;
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        Node firstChild = getFirstChild();
        while (true) {
            Node node = firstChild;
            if (node == null) {
                return stringBuffer2.toString();
            }
            if (node instanceof Text) {
                StringBuffer append = stringBuffer2.append(((Text) node).getData());
            }
            firstChild = node.getNextSibling();
        }
    }

    public String getValue() {
        return getAttribute(CommonProperties.VALUE);
    }

    public void setDefaultSelected(boolean z) {
        setAttribute("default-selected", z);
    }

    public void setDisabled(boolean z) {
        setAttribute("disabled", z);
    }

    public void setIndex(int i) {
        Node node;
        int i2 = i;
        HTMLElement parentNode = getParentNode();
        while (true) {
            node = parentNode;
            if (node != null && !(node instanceof HTMLSelectElement)) {
                parentNode = node.getParentNode();
            }
        }
        if (node != null) {
            NodeList elementsByTagName = node.getElementsByTagName("OPTION");
            if (elementsByTagName.item(i2) != this) {
                Node removeChild = getParentNode().removeChild(this);
                Node item = elementsByTagName.item(i2);
                Node insertBefore = item.getParentNode().insertBefore(this, item);
            }
        }
    }

    public void setLabel(String str) {
        setAttribute("label", str);
    }

    public void setSelected(boolean z) {
        setAttribute("selected", z);
    }

    public void setText(String str) {
        String str2 = str;
        Node firstChild = getFirstChild();
        while (true) {
            Node node = firstChild;
            if (node == null) {
                Node insertBefore = insertBefore(getOwnerDocument().createTextNode(str2), getFirstChild());
                return;
            }
            Node nextSibling = node.getNextSibling();
            Node removeChild = removeChild(node);
            firstChild = nextSibling;
        }
    }

    public void setValue(String str) {
        setAttribute(CommonProperties.VALUE, str);
    }
}
