package org.apache.html.dom;

import org.w3c.dom.html.HTMLDListElement;

public class HTMLDListElementImpl extends HTMLElementImpl implements HTMLDListElement {
    private static final long serialVersionUID = -2130005642453038604L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLDListElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public boolean getCompact() {
        return getBinary("compact");
    }

    public void setCompact(boolean z) {
        setAttribute("compact", z);
    }
}
