package org.apache.html.dom;

import org.w3c.dom.html.HTMLMenuElement;

public class HTMLMenuElementImpl extends HTMLElementImpl implements HTMLMenuElement {
    private static final long serialVersionUID = -1489696654903916901L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLMenuElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public boolean getCompact() {
        return getBinary("compact");
    }

    public void setCompact(boolean z) {
        setAttribute("compact", z);
    }
}
