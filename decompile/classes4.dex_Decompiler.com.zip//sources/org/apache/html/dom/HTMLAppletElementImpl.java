package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.html.HTMLAppletElement;

public class HTMLAppletElementImpl extends HTMLElementImpl implements HTMLAppletElement {
    private static final long serialVersionUID = 8375794094117740967L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLAppletElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getAlign() {
        return getAttribute("align");
    }

    public String getAlt() {
        return getAttribute("alt");
    }

    public String getArchive() {
        return getAttribute("archive");
    }

    public String getCode() {
        return getAttribute("code");
    }

    public String getCodeBase() {
        return getAttribute("codebase");
    }

    public String getHeight() {
        return getAttribute("height");
    }

    public String getHspace() {
        return getAttribute("height");
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public String getObject() {
        return getAttribute("object");
    }

    public String getVspace() {
        return getAttribute("vspace");
    }

    public String getWidth() {
        return getAttribute("width");
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }

    public void setAlt(String str) {
        setAttribute("alt", str);
    }

    public void setArchive(String str) {
        setAttribute("archive", str);
    }

    public void setCode(String str) {
        setAttribute("code", str);
    }

    public void setCodeBase(String str) {
        setAttribute("codebase", str);
    }

    public void setHeight(String str) {
        setAttribute("height", str);
    }

    public void setHspace(String str) {
        setAttribute("height", str);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setObject(String str) {
        setAttribute("object", str);
    }

    public void setVspace(String str) {
        setAttribute("vspace", str);
    }

    public void setWidth(String str) {
        setAttribute("width", str);
    }
}
