package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.html.HTMLCollection;
import org.w3c.dom.html.HTMLElement;
import org.w3c.dom.html.HTMLSelectElement;

public class HTMLSelectElementImpl extends HTMLElementImpl implements HTMLSelectElement, HTMLFormControl {
    private static final long serialVersionUID = -6998282711006968187L;
    private HTMLCollection _options;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLSelectElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public void add(HTMLElement hTMLElement, HTMLElement hTMLElement2) {
        Node insertBefore = insertBefore(hTMLElement, hTMLElement2);
    }

    public void blur() {
    }

    public Node cloneNode(boolean z) {
        HTMLSelectElementImpl hTMLSelectElementImpl = (HTMLSelectElementImpl) super.cloneNode(z);
        hTMLSelectElementImpl._options = null;
        return hTMLSelectElementImpl;
    }

    public void focus() {
    }

    public NodeList getChildNodes() {
        return getChildNodesUnoptimized();
    }

    public boolean getDisabled() {
        return getBinary("disabled");
    }

    public int getLength() {
        return getOptions().getLength();
    }

    public boolean getMultiple() {
        return getBinary("multiple");
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public HTMLCollection getOptions() {
        HTMLCollection hTMLCollection;
        if (this._options == null) {
            new HTMLCollectionImpl(this, 6);
            this._options = hTMLCollection;
        }
        return this._options;
    }

    public int getSelectedIndex() {
        NodeList elementsByTagName = getElementsByTagName("OPTION");
        for (int i = 0; i < elementsByTagName.getLength(); i++) {
            if (elementsByTagName.item(i).getSelected()) {
                return i;
            }
        }
        return -1;
    }

    public int getSize() {
        return getInteger(getAttribute("size"));
    }

    public int getTabIndex() {
        return getInteger(getAttribute("tabindex"));
    }

    public String getType() {
        return getAttribute(CommonProperties.TYPE);
    }

    public String getValue() {
        return getAttribute(CommonProperties.VALUE);
    }

    public void remove(int i) {
        Node item = getElementsByTagName("OPTION").item(i);
        if (item != null) {
            Node removeChild = item.getParentNode().removeChild(item);
        }
    }

    public void setDisabled(boolean z) {
        setAttribute("disabled", z);
    }

    public void setMultiple(boolean z) {
        setAttribute("multiple", z);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setSelectedIndex(int i) {
        int i2 = i;
        NodeList elementsByTagName = getElementsByTagName("OPTION");
        int i3 = 0;
        while (i3 < elementsByTagName.getLength()) {
            ((HTMLOptionElementImpl) elementsByTagName.item(i3)).setSelected(i3 == i2);
            i3++;
        }
    }

    public void setSize(int i) {
        setAttribute("size", String.valueOf(i));
    }

    public void setTabIndex(int i) {
        setAttribute("tabindex", String.valueOf(i));
    }

    public void setValue(String str) {
        setAttribute(CommonProperties.VALUE, str);
    }
}
