package org.apache.html.dom;

import org.w3c.dom.html.HTMLDirectoryElement;

public class HTMLDirectoryElementImpl extends HTMLElementImpl implements HTMLDirectoryElement {
    private static final long serialVersionUID = -1010376135190194454L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLDirectoryElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public boolean getCompact() {
        return getBinary("compact");
    }

    public void setCompact(boolean z) {
        setAttribute("compact", z);
    }
}
