package org.apache.html.dom;

import com.microsoft.appcenter.analytics.ingestion.models.EventLog;
import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.Node;
import org.w3c.dom.Text;
import org.w3c.dom.html.HTMLScriptElement;

public class HTMLScriptElementImpl extends HTMLElementImpl implements HTMLScriptElement {
    private static final long serialVersionUID = 5090330049085326558L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLScriptElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getCharset() {
        return getAttribute("charset");
    }

    public boolean getDefer() {
        return getBinary("defer");
    }

    public String getEvent() {
        return getAttribute(EventLog.TYPE);
    }

    public String getHtmlFor() {
        return getAttribute("for");
    }

    public String getSrc() {
        return getAttribute("src");
    }

    public String getText() {
        StringBuffer stringBuffer;
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        Node firstChild = getFirstChild();
        while (true) {
            Node node = firstChild;
            if (node == null) {
                return stringBuffer2.toString();
            }
            if (node instanceof Text) {
                StringBuffer append = stringBuffer2.append(((Text) node).getData());
            }
            firstChild = node.getNextSibling();
        }
    }

    public String getType() {
        return getAttribute(CommonProperties.TYPE);
    }

    public void setCharset(String str) {
        setAttribute("charset", str);
    }

    public void setDefer(boolean z) {
        setAttribute("defer", z);
    }

    public void setEvent(String str) {
        setAttribute(EventLog.TYPE, str);
    }

    public void setHtmlFor(String str) {
        setAttribute("for", str);
    }

    public void setSrc(String str) {
        setAttribute("src", str);
    }

    public void setText(String str) {
        String str2 = str;
        Node firstChild = getFirstChild();
        while (true) {
            Node node = firstChild;
            if (node == null) {
                Node insertBefore = insertBefore(getOwnerDocument().createTextNode(str2), getFirstChild());
                return;
            }
            Node nextSibling = node.getNextSibling();
            Node removeChild = removeChild(node);
            firstChild = nextSibling;
        }
    }

    public void setType(String str) {
        setAttribute(CommonProperties.TYPE, str);
    }
}
