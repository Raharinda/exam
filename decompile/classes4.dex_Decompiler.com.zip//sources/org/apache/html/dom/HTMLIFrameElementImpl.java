package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.html.HTMLIFrameElement;

public class HTMLIFrameElementImpl extends HTMLElementImpl implements HTMLIFrameElement {
    private static final long serialVersionUID = 2393622754706230429L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLIFrameElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getAlign() {
        return capitalize(getAttribute("align"));
    }

    public String getFrameBorder() {
        return getAttribute("frameborder");
    }

    public String getHeight() {
        return getAttribute("height");
    }

    public String getLongDesc() {
        return getAttribute("longdesc");
    }

    public String getMarginHeight() {
        return getAttribute("marginheight");
    }

    public String getMarginWidth() {
        return getAttribute("marginwidth");
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public String getScrolling() {
        return capitalize(getAttribute("scrolling"));
    }

    public String getSrc() {
        return getAttribute("src");
    }

    public String getWidth() {
        return getAttribute("width");
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }

    public void setFrameBorder(String str) {
        setAttribute("frameborder", str);
    }

    public void setHeight(String str) {
        setAttribute("height", str);
    }

    public void setLongDesc(String str) {
        setAttribute("longdesc", str);
    }

    public void setMarginHeight(String str) {
        setAttribute("marginheight", str);
    }

    public void setMarginWidth(String str) {
        setAttribute("marginwidth", str);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setScrolling(String str) {
        setAttribute("scrolling", str);
    }

    public void setSrc(String str) {
        setAttribute("src", str);
    }

    public void setWidth(String str) {
        setAttribute("width", str);
    }
}
