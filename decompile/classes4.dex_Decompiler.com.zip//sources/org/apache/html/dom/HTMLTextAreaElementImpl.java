package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.html.HTMLTextAreaElement;

public class HTMLTextAreaElementImpl extends HTMLElementImpl implements HTMLTextAreaElement, HTMLFormControl {
    private static final long serialVersionUID = -6737778308542678104L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLTextAreaElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public void blur() {
    }

    public void focus() {
    }

    public String getAccessKey() {
        String attribute = getAttribute("accesskey");
        if (attribute != null && attribute.length() > 1) {
            attribute = attribute.substring(0, 1);
        }
        return attribute;
    }

    public int getCols() {
        return getInteger(getAttribute("cols"));
    }

    public String getDefaultValue() {
        return getAttribute("default-value");
    }

    public boolean getDisabled() {
        return getBinary("disabled");
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public boolean getReadOnly() {
        return getBinary("readonly");
    }

    public int getRows() {
        return getInteger(getAttribute("rows"));
    }

    public int getTabIndex() {
        return getInteger(getAttribute("tabindex"));
    }

    public String getType() {
        return getAttribute(CommonProperties.TYPE);
    }

    public String getValue() {
        return getAttribute(CommonProperties.VALUE);
    }

    public void select() {
    }

    public void setAccessKey(String str) {
        String str2 = str;
        if (str2 != null && str2.length() > 1) {
            str2 = str2.substring(0, 1);
        }
        setAttribute("accesskey", str2);
    }

    public void setCols(int i) {
        setAttribute("cols", String.valueOf(i));
    }

    public void setDefaultValue(String str) {
        setAttribute("default-value", str);
    }

    public void setDisabled(boolean z) {
        setAttribute("disabled", z);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setReadOnly(boolean z) {
        setAttribute("readonly", z);
    }

    public void setRows(int i) {
        setAttribute("rows", String.valueOf(i));
    }

    public void setTabIndex(int i) {
        setAttribute("tabindex", String.valueOf(i));
    }

    public void setValue(String str) {
        setAttribute(CommonProperties.VALUE, str);
    }
}
