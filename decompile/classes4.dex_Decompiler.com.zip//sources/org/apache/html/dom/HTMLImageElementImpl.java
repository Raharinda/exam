package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.html.HTMLImageElement;

public class HTMLImageElementImpl extends HTMLElementImpl implements HTMLImageElement {
    private static final long serialVersionUID = 1424360710977241315L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLImageElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public String getAlign() {
        return capitalize(getAttribute("align"));
    }

    public String getAlt() {
        return getAttribute("alt");
    }

    public String getBorder() {
        return getAttribute("border");
    }

    public String getHeight() {
        return getAttribute("height");
    }

    public String getHspace() {
        return getAttribute("hspace");
    }

    public boolean getIsMap() {
        return getBinary("ismap");
    }

    public String getLongDesc() {
        return getAttribute("longdesc");
    }

    public String getLowSrc() {
        return getAttribute("lowsrc");
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public String getSrc() {
        return getAttribute("src");
    }

    public String getUseMap() {
        return getAttribute("useMap");
    }

    public String getVspace() {
        return getAttribute("vspace");
    }

    public String getWidth() {
        return getAttribute("width");
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }

    public void setAlt(String str) {
        setAttribute("alt", str);
    }

    public void setBorder(String str) {
        setAttribute("border", str);
    }

    public void setHeight(String str) {
        setAttribute("height", str);
    }

    public void setHspace(String str) {
        setAttribute("hspace", str);
    }

    public void setIsMap(boolean z) {
        setAttribute("ismap", z);
    }

    public void setLongDesc(String str) {
        setAttribute("longdesc", str);
    }

    public void setLowSrc(String str) {
        setAttribute("lowsrc", str);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setSrc(String str) {
        setAttribute("src", str);
    }

    public void setUseMap(String str) {
        setAttribute("useMap", str);
    }

    public void setVspace(String str) {
        setAttribute("vspace", str);
    }

    public void setWidth(String str) {
        setAttribute("width", str);
    }
}
