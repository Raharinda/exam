package org.apache.html.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.html.HTMLCollection;
import org.w3c.dom.html.HTMLFormElement;

public class HTMLFormElementImpl extends HTMLElementImpl implements HTMLFormElement {
    private static final long serialVersionUID = -7324749629151493210L;
    private HTMLCollectionImpl _elements;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTMLFormElementImpl(HTMLDocumentImpl hTMLDocumentImpl, String str) {
        super(hTMLDocumentImpl, str);
    }

    public Node cloneNode(boolean z) {
        HTMLFormElementImpl hTMLFormElementImpl = (HTMLFormElementImpl) super.cloneNode(z);
        hTMLFormElementImpl._elements = null;
        return hTMLFormElementImpl;
    }

    public String getAcceptCharset() {
        return getAttribute("accept-charset");
    }

    public String getAction() {
        return getAttribute("action");
    }

    public NodeList getChildNodes() {
        return getChildNodesUnoptimized();
    }

    public HTMLCollection getElements() {
        HTMLCollectionImpl hTMLCollectionImpl;
        if (this._elements == null) {
            new HTMLCollectionImpl(this, 8);
            this._elements = hTMLCollectionImpl;
        }
        return this._elements;
    }

    public String getEnctype() {
        return getAttribute("enctype");
    }

    public int getLength() {
        return getElements().getLength();
    }

    public String getMethod() {
        return capitalize(getAttribute("method"));
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public String getTarget() {
        return getAttribute("target");
    }

    public void reset() {
    }

    public void setAcceptCharset(String str) {
        setAttribute("accept-charset", str);
    }

    public void setAction(String str) {
        setAttribute("action", str);
    }

    public void setEnctype(String str) {
        setAttribute("enctype", str);
    }

    public void setMethod(String str) {
        setAttribute("method", str);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setTarget(String str) {
        setAttribute("target", str);
    }

    public void submit() {
    }
}
