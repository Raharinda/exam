package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLTdElement;

public class WMLTdElementImpl extends WMLElementImpl implements WMLTdElement {
    private static final long serialVersionUID = 6074218675876025710L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLTdElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public String getXmlLang() {
        return getAttribute("xml:lang");
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setXmlLang(String str) {
        setAttribute("xml:lang", str);
    }
}
