package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLTableElement;

public class WMLTableElementImpl extends WMLElementImpl implements WMLTableElement {
    private static final long serialVersionUID = 7676208849347355339L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLTableElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getAlign() {
        return getAttribute("align");
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public int getColumns() {
        return getAttribute("columns", 0);
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public String getTitle() {
        return getAttribute("title");
    }

    public String getXmlLang() {
        return getAttribute("xml:lang");
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setColumns(int i) {
        setAttribute("columns", i);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setTitle(String str) {
        setAttribute("title", str);
    }

    public void setXmlLang(String str) {
        setAttribute("xml:lang", str);
    }
}
