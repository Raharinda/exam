package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLSetvarElement;

public class WMLSetvarElementImpl extends WMLElementImpl implements WMLSetvarElement {
    private static final long serialVersionUID = -1944519734782236471L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLSetvarElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public String getValue() {
        return getAttribute(CommonProperties.VALUE);
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setValue(String str) {
        setAttribute(CommonProperties.VALUE, str);
    }
}
