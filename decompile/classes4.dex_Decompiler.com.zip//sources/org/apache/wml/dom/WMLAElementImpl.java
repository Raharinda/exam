package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLAElement;

public class WMLAElementImpl extends WMLElementImpl implements WMLAElement {
    private static final long serialVersionUID = 2628169803370301255L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLAElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getHref() {
        return getAttribute("href");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public String getTitle() {
        return getAttribute("title");
    }

    public String getXmlLang() {
        return getAttribute("xml:lang");
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setHref(String str) {
        setAttribute("href", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setTitle(String str) {
        setAttribute("title", str);
    }

    public void setXmlLang(String str) {
        setAttribute("xml:lang", str);
    }
}
