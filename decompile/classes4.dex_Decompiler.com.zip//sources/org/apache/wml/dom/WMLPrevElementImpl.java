package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLPrevElement;

public class WMLPrevElementImpl extends WMLElementImpl implements WMLPrevElement {
    private static final long serialVersionUID = -1545713716925433554L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLPrevElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }
}
