package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLStrongElement;

public class WMLStrongElementImpl extends WMLElementImpl implements WMLStrongElement {
    private static final long serialVersionUID = 8451363815747099580L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLStrongElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public String getXmlLang() {
        return getAttribute("xml:lang");
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setXmlLang(String str) {
        setAttribute("xml:lang", str);
    }
}
