package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLTemplateElement;

public class WMLTemplateElementImpl extends WMLElementImpl implements WMLTemplateElement {
    private static final long serialVersionUID = 4231732841621131049L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLTemplateElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public String getOnEnterBackward() {
        return getAttribute("onenterbackward");
    }

    public String getOnEnterForward() {
        return getAttribute("onenterforward");
    }

    public String getOnTimer() {
        return getAttribute("ontimer");
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setOnEnterBackward(String str) {
        setAttribute("onenterbackward", str);
    }

    public void setOnEnterForward(String str) {
        setAttribute("onenterforward", str);
    }

    public void setOnTimer(String str) {
        setAttribute("ontimer", str);
    }
}
