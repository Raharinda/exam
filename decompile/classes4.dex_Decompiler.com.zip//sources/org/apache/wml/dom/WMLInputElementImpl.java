package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLInputElement;

public class WMLInputElementImpl extends WMLElementImpl implements WMLInputElement {
    private static final long serialVersionUID = 2897319793637966619L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLInputElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public boolean getEmptyOk() {
        return getAttribute("emptyok", false);
    }

    public String getFormat() {
        return getAttribute("format");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public int getMaxLength() {
        return getAttribute("maxlength", 0);
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public int getSize() {
        return getAttribute("size", 0);
    }

    public int getTabIndex() {
        return getAttribute("tabindex", 0);
    }

    public String getTitle() {
        return getAttribute("title");
    }

    public String getType() {
        return getAttribute(CommonProperties.TYPE);
    }

    public String getValue() {
        return getAttribute(CommonProperties.VALUE);
    }

    public String getXmlLang() {
        return getAttribute("xml:lang");
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setEmptyOk(boolean z) {
        setAttribute("emptyok", z);
    }

    public void setFormat(String str) {
        setAttribute("format", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setMaxLength(int i) {
        setAttribute("maxlength", i);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setSize(int i) {
        setAttribute("size", i);
    }

    public void setTabIndex(int i) {
        setAttribute("tabindex", i);
    }

    public void setTitle(String str) {
        setAttribute("title", str);
    }

    public void setType(String str) {
        setAttribute(CommonProperties.TYPE, str);
    }

    public void setValue(String str) {
        setAttribute(CommonProperties.VALUE, str);
    }

    public void setXmlLang(String str) {
        setAttribute("xml:lang", str);
    }
}
