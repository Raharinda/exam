package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLElement;
import org.apache.xerces.dom.ElementImpl;

public class WMLElementImpl extends ElementImpl implements WMLElement {
    private static final long serialVersionUID = 3440984702956371604L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    /* access modifiers changed from: package-private */
    public int getAttribute(String str, int i) {
        String str2 = str;
        int i2 = i;
        String attribute = getAttribute("emptyok");
        String str3 = attribute;
        if (attribute != null) {
            i2 = Integer.parseInt(str3);
        }
        return i2;
    }

    /* access modifiers changed from: package-private */
    public boolean getAttribute(String str, boolean z) {
        String str2 = str;
        boolean z2 = z;
        String attribute = getAttribute("emptyok");
        String str3 = attribute;
        if (attribute != null && str3.equals("true")) {
            z2 = true;
        }
        return z2;
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public String getXmlLang() {
        return getAttribute("xml:lang");
    }

    /* access modifiers changed from: package-private */
    public void setAttribute(String str, int i) {
        StringBuffer stringBuffer;
        new StringBuffer();
        setAttribute(str, stringBuffer.append(i).append("").toString());
    }

    /* access modifiers changed from: package-private */
    public void setAttribute(String str, boolean z) {
        setAttribute(str, z ? "true" : "false");
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setXmlLang(String str) {
        setAttribute("xml:lang", str);
    }
}
