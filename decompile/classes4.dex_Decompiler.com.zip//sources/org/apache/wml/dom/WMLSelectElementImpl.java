package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLSelectElement;

public class WMLSelectElementImpl extends WMLElementImpl implements WMLSelectElement {
    private static final long serialVersionUID = 6489112443257247261L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLSelectElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getIName() {
        return getAttribute("iname");
    }

    public String getIValue() {
        return getAttribute("ivalue");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public boolean getMultiple() {
        return getAttribute("multiple", false);
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public int getTabIndex() {
        return getAttribute("tabindex", 0);
    }

    public String getTitle() {
        return getAttribute("title");
    }

    public String getValue() {
        return getAttribute(CommonProperties.VALUE);
    }

    public String getXmlLang() {
        return getAttribute("xml:lang");
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setIName(String str) {
        setAttribute("iname", str);
    }

    public void setIValue(String str) {
        setAttribute("ivalue", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setMultiple(boolean z) {
        setAttribute("multiple", z);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setTabIndex(int i) {
        setAttribute("tabindex", i);
    }

    public void setTitle(String str) {
        setAttribute("title", str);
    }

    public void setValue(String str) {
        setAttribute(CommonProperties.VALUE, str);
    }

    public void setXmlLang(String str) {
        setAttribute("xml:lang", str);
    }
}
