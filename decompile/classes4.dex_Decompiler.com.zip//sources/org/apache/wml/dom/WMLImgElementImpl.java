package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLImgElement;

public class WMLImgElementImpl extends WMLElementImpl implements WMLImgElement {
    private static final long serialVersionUID = -500092034867051550L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLImgElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getAlign() {
        return getAttribute("align");
    }

    public String getAlt() {
        return getAttribute("alt");
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getHeight() {
        return getAttribute("height");
    }

    public String getHspace() {
        return getAttribute("hspace");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public String getLocalSrc() {
        return getAttribute("localsrc");
    }

    public String getSrc() {
        return getAttribute("src");
    }

    public String getVspace() {
        return getAttribute("vspace");
    }

    public String getWidth() {
        return getAttribute("width");
    }

    public String getXmlLang() {
        return getAttribute("xml:lang");
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }

    public void setAlt(String str) {
        setAttribute("alt", str);
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setHeight(String str) {
        setAttribute("height", str);
    }

    public void setHspace(String str) {
        setAttribute("hspace", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setLocalSrc(String str) {
        setAttribute("localsrc", str);
    }

    public void setSrc(String str) {
        setAttribute("src", str);
    }

    public void setVspace(String str) {
        setAttribute("vspace", str);
    }

    public void setWidth(String str) {
        setAttribute("width", str);
    }

    public void setXmlLang(String str) {
        setAttribute("xml:lang", str);
    }
}
