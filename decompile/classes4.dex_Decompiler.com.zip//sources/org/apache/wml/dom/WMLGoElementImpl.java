package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLGoElement;

public class WMLGoElementImpl extends WMLElementImpl implements WMLGoElement {
    private static final long serialVersionUID = -2052250142899797905L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLGoElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getAcceptCharset() {
        return getAttribute("accept-charset");
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getHref() {
        return getAttribute("href");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public String getMethod() {
        return getAttribute("method");
    }

    public String getSendreferer() {
        return getAttribute("sendreferer");
    }

    public void setAcceptCharset(String str) {
        setAttribute("accept-charset", str);
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setHref(String str) {
        setAttribute("href", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setMethod(String str) {
        setAttribute("method", str);
    }

    public void setSendreferer(String str) {
        setAttribute("sendreferer", str);
    }
}
