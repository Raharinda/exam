package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLOneventElement;

public class WMLOneventElementImpl extends WMLElementImpl implements WMLOneventElement {
    private static final long serialVersionUID = -4279215241146570871L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLOneventElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public String getType() {
        return getAttribute(CommonProperties.TYPE);
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setType(String str) {
        setAttribute(CommonProperties.TYPE, str);
    }
}
