package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLCardElement;

public class WMLCardElementImpl extends WMLElementImpl implements WMLCardElement {
    private static final long serialVersionUID = -3571126568344328924L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLCardElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public boolean getNewContext() {
        return getAttribute("newcontext", false);
    }

    public String getOnEnterBackward() {
        return getAttribute("onenterbackward");
    }

    public String getOnEnterForward() {
        return getAttribute("onenterforward");
    }

    public String getOnTimer() {
        return getAttribute("ontimer");
    }

    public boolean getOrdered() {
        return getAttribute("ordered", true);
    }

    public String getTitle() {
        return getAttribute("title");
    }

    public String getXmlLang() {
        return getAttribute("xml:lang");
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setNewContext(boolean z) {
        setAttribute("newcontext", z);
    }

    public void setOnEnterBackward(String str) {
        setAttribute("onenterbackward", str);
    }

    public void setOnEnterForward(String str) {
        setAttribute("onenterforward", str);
    }

    public void setOnTimer(String str) {
        setAttribute("ontimer", str);
    }

    public void setOrdered(boolean z) {
        setAttribute("ordered", z);
    }

    public void setTitle(String str) {
        setAttribute("title", str);
    }

    public void setXmlLang(String str) {
        setAttribute("xml:lang", str);
    }
}
