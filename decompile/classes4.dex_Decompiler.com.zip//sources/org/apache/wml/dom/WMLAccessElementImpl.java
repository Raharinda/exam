package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLAccessElement;

public class WMLAccessElementImpl extends WMLElementImpl implements WMLAccessElement {
    private static final long serialVersionUID = -235627181817012806L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLAccessElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getDomain() {
        return getAttribute("domain");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public String getPath() {
        return getAttribute("path");
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setDomain(String str) {
        setAttribute("domain", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setPath(String str) {
        setAttribute("path", str);
    }
}
