package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLMetaElement;

public class WMLMetaElementImpl extends WMLElementImpl implements WMLMetaElement {
    private static final long serialVersionUID = -2791663042188681846L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLMetaElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getContent() {
        return getAttribute("content");
    }

    public boolean getForua() {
        return getAttribute("forua", false);
    }

    public String getHttpEquiv() {
        return getAttribute("http-equiv");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public String getName() {
        return getAttribute(CommonProperties.NAME);
    }

    public String getScheme() {
        return getAttribute("scheme");
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setContent(String str) {
        setAttribute("content", str);
    }

    public void setForua(boolean z) {
        setAttribute("forua", z);
    }

    public void setHttpEquiv(String str) {
        setAttribute("http-equiv", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setName(String str) {
        setAttribute(CommonProperties.NAME, str);
    }

    public void setScheme(String str) {
        setAttribute("scheme", str);
    }
}
