package org.apache.wml.dom;

import com.microsoft.appcenter.ingestion.models.CommonProperties;
import org.apache.wml.WMLPElement;

public class WMLPElementImpl extends WMLElementImpl implements WMLPElement {
    private static final long serialVersionUID = 4263257796458499960L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLPElementImpl(WMLDocumentImpl wMLDocumentImpl, String str) {
        super(wMLDocumentImpl, str);
    }

    public String getAlign() {
        return getAttribute("align");
    }

    public String getClassName() {
        return getAttribute("class");
    }

    public String getId() {
        return getAttribute(CommonProperties.ID);
    }

    public String getMode() {
        return getAttribute("mode");
    }

    public String getXmlLang() {
        return getAttribute("xml:lang");
    }

    public void setAlign(String str) {
        setAttribute("align", str);
    }

    public void setClassName(String str) {
        setAttribute("class", str);
    }

    public void setId(String str) {
        setAttribute(CommonProperties.ID, str);
    }

    public void setMode(String str) {
        setAttribute("mode", str);
    }

    public void setXmlLang(String str) {
        setAttribute("xml:lang", str);
    }
}
