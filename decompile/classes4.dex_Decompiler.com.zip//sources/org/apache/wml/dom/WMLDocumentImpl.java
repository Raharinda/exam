package org.apache.wml.dom;

import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.util.Hashtable;
import org.apache.wml.WMLDocument;
import org.apache.xerces.dom.DocumentImpl;
import org.apache.xerces.dom.ElementImpl;
import org.w3c.dom.DOMException;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;

public class WMLDocumentImpl extends DocumentImpl implements WMLDocument {
    private static final Class[] _elemClassSigWML;
    private static Hashtable _elementTypesWML = null;
    static Class class$java$lang$String = null;
    static Class class$org$apache$wml$dom$WMLAElementImpl = null;
    static Class class$org$apache$wml$dom$WMLAccessElementImpl = null;
    static Class class$org$apache$wml$dom$WMLAnchorElementImpl = null;
    static Class class$org$apache$wml$dom$WMLBElementImpl = null;
    static Class class$org$apache$wml$dom$WMLBigElementImpl = null;
    static Class class$org$apache$wml$dom$WMLBrElementImpl = null;
    static Class class$org$apache$wml$dom$WMLCardElementImpl = null;
    static Class class$org$apache$wml$dom$WMLDoElementImpl = null;
    static Class class$org$apache$wml$dom$WMLDocumentImpl = null;
    static Class class$org$apache$wml$dom$WMLEmElementImpl = null;
    static Class class$org$apache$wml$dom$WMLFieldsetElementImpl = null;
    static Class class$org$apache$wml$dom$WMLGoElementImpl = null;
    static Class class$org$apache$wml$dom$WMLHeadElementImpl = null;
    static Class class$org$apache$wml$dom$WMLIElementImpl = null;
    static Class class$org$apache$wml$dom$WMLImgElementImpl = null;
    static Class class$org$apache$wml$dom$WMLInputElementImpl = null;
    static Class class$org$apache$wml$dom$WMLMetaElementImpl = null;
    static Class class$org$apache$wml$dom$WMLNoopElementImpl = null;
    static Class class$org$apache$wml$dom$WMLOneventElementImpl = null;
    static Class class$org$apache$wml$dom$WMLOptgroupElementImpl = null;
    static Class class$org$apache$wml$dom$WMLOptionElementImpl = null;
    static Class class$org$apache$wml$dom$WMLPElementImpl = null;
    static Class class$org$apache$wml$dom$WMLPostfieldElementImpl = null;
    static Class class$org$apache$wml$dom$WMLPrevElementImpl = null;
    static Class class$org$apache$wml$dom$WMLRefreshElementImpl = null;
    static Class class$org$apache$wml$dom$WMLSelectElementImpl = null;
    static Class class$org$apache$wml$dom$WMLSetvarElementImpl = null;
    static Class class$org$apache$wml$dom$WMLSmallElementImpl = null;
    static Class class$org$apache$wml$dom$WMLStrongElementImpl = null;
    static Class class$org$apache$wml$dom$WMLTableElementImpl = null;
    static Class class$org$apache$wml$dom$WMLTdElementImpl = null;
    static Class class$org$apache$wml$dom$WMLTemplateElementImpl = null;
    static Class class$org$apache$wml$dom$WMLTimerElementImpl = null;
    static Class class$org$apache$wml$dom$WMLTrElementImpl = null;
    static Class class$org$apache$wml$dom$WMLUElementImpl = null;
    static Class class$org$apache$wml$dom$WMLWmlElementImpl = null;
    private static final long serialVersionUID = -6582904849512384104L;

    static {
        Class cls;
        Class cls2;
        Hashtable hashtable;
        Class cls3;
        Class cls4;
        Class cls5;
        Class cls6;
        Class cls7;
        Class cls8;
        Class cls9;
        Class cls10;
        Class cls11;
        Class cls12;
        Class cls13;
        Class cls14;
        Class cls15;
        Class cls16;
        Class cls17;
        Class cls18;
        Class cls19;
        Class cls20;
        Class cls21;
        Class cls22;
        Class cls23;
        Class cls24;
        Class cls25;
        Class cls26;
        Class cls27;
        Class cls28;
        Class cls29;
        Class cls30;
        Class cls31;
        Class cls32;
        Class cls33;
        Class cls34;
        Class cls35;
        Class cls36;
        Class cls37;
        Class[] clsArr = new Class[2];
        Class[] clsArr2 = clsArr;
        Class[] clsArr3 = clsArr;
        if (class$org$apache$wml$dom$WMLDocumentImpl == null) {
            Class class$ = class$("org.apache.wml.dom.WMLDocumentImpl");
            cls = class$;
            class$org$apache$wml$dom$WMLDocumentImpl = class$;
        } else {
            cls = class$org$apache$wml$dom$WMLDocumentImpl;
        }
        clsArr3[0] = cls;
        Class[] clsArr4 = clsArr2;
        Class[] clsArr5 = clsArr4;
        Class[] clsArr6 = clsArr4;
        if (class$java$lang$String == null) {
            Class class$2 = class$("java.lang.String");
            cls2 = class$2;
            class$java$lang$String = class$2;
        } else {
            cls2 = class$java$lang$String;
        }
        clsArr6[1] = cls2;
        _elemClassSigWML = clsArr5;
        new Hashtable();
        _elementTypesWML = hashtable;
        Hashtable hashtable2 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLBElementImpl == null) {
            Class class$3 = class$("org.apache.wml.dom.WMLBElementImpl");
            cls3 = class$3;
            class$org$apache$wml$dom$WMLBElementImpl = class$3;
        } else {
            cls3 = class$org$apache$wml$dom$WMLBElementImpl;
        }
        Object put = hashtable2.put("b", cls3);
        Hashtable hashtable3 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLNoopElementImpl == null) {
            Class class$4 = class$("org.apache.wml.dom.WMLNoopElementImpl");
            cls4 = class$4;
            class$org$apache$wml$dom$WMLNoopElementImpl = class$4;
        } else {
            cls4 = class$org$apache$wml$dom$WMLNoopElementImpl;
        }
        Object put2 = hashtable3.put("noop", cls4);
        Hashtable hashtable4 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLAElementImpl == null) {
            Class class$5 = class$("org.apache.wml.dom.WMLAElementImpl");
            cls5 = class$5;
            class$org$apache$wml$dom$WMLAElementImpl = class$5;
        } else {
            cls5 = class$org$apache$wml$dom$WMLAElementImpl;
        }
        Object put3 = hashtable4.put("a", cls5);
        Hashtable hashtable5 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLSetvarElementImpl == null) {
            Class class$6 = class$("org.apache.wml.dom.WMLSetvarElementImpl");
            cls6 = class$6;
            class$org$apache$wml$dom$WMLSetvarElementImpl = class$6;
        } else {
            cls6 = class$org$apache$wml$dom$WMLSetvarElementImpl;
        }
        Object put4 = hashtable5.put("setvar", cls6);
        Hashtable hashtable6 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLAccessElementImpl == null) {
            Class class$7 = class$("org.apache.wml.dom.WMLAccessElementImpl");
            cls7 = class$7;
            class$org$apache$wml$dom$WMLAccessElementImpl = class$7;
        } else {
            cls7 = class$org$apache$wml$dom$WMLAccessElementImpl;
        }
        Object put5 = hashtable6.put("access", cls7);
        Hashtable hashtable7 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLStrongElementImpl == null) {
            Class class$8 = class$("org.apache.wml.dom.WMLStrongElementImpl");
            cls8 = class$8;
            class$org$apache$wml$dom$WMLStrongElementImpl = class$8;
        } else {
            cls8 = class$org$apache$wml$dom$WMLStrongElementImpl;
        }
        Object put6 = hashtable7.put("strong", cls8);
        Hashtable hashtable8 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLPostfieldElementImpl == null) {
            Class class$9 = class$("org.apache.wml.dom.WMLPostfieldElementImpl");
            cls9 = class$9;
            class$org$apache$wml$dom$WMLPostfieldElementImpl = class$9;
        } else {
            cls9 = class$org$apache$wml$dom$WMLPostfieldElementImpl;
        }
        Object put7 = hashtable8.put("postfield", cls9);
        Hashtable hashtable9 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLDoElementImpl == null) {
            Class class$10 = class$("org.apache.wml.dom.WMLDoElementImpl");
            cls10 = class$10;
            class$org$apache$wml$dom$WMLDoElementImpl = class$10;
        } else {
            cls10 = class$org$apache$wml$dom$WMLDoElementImpl;
        }
        Object put8 = hashtable9.put("do", cls10);
        Hashtable hashtable10 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLWmlElementImpl == null) {
            Class class$11 = class$("org.apache.wml.dom.WMLWmlElementImpl");
            cls11 = class$11;
            class$org$apache$wml$dom$WMLWmlElementImpl = class$11;
        } else {
            cls11 = class$org$apache$wml$dom$WMLWmlElementImpl;
        }
        Object put9 = hashtable10.put("wml", cls11);
        Hashtable hashtable11 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLTrElementImpl == null) {
            Class class$12 = class$("org.apache.wml.dom.WMLTrElementImpl");
            cls12 = class$12;
            class$org$apache$wml$dom$WMLTrElementImpl = class$12;
        } else {
            cls12 = class$org$apache$wml$dom$WMLTrElementImpl;
        }
        Object put10 = hashtable11.put("tr", cls12);
        Hashtable hashtable12 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLGoElementImpl == null) {
            Class class$13 = class$("org.apache.wml.dom.WMLGoElementImpl");
            cls13 = class$13;
            class$org$apache$wml$dom$WMLGoElementImpl = class$13;
        } else {
            cls13 = class$org$apache$wml$dom$WMLGoElementImpl;
        }
        Object put11 = hashtable12.put("go", cls13);
        Hashtable hashtable13 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLBigElementImpl == null) {
            Class class$14 = class$("org.apache.wml.dom.WMLBigElementImpl");
            cls14 = class$14;
            class$org$apache$wml$dom$WMLBigElementImpl = class$14;
        } else {
            cls14 = class$org$apache$wml$dom$WMLBigElementImpl;
        }
        Object put12 = hashtable13.put("big", cls14);
        Hashtable hashtable14 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLAnchorElementImpl == null) {
            Class class$15 = class$("org.apache.wml.dom.WMLAnchorElementImpl");
            cls15 = class$15;
            class$org$apache$wml$dom$WMLAnchorElementImpl = class$15;
        } else {
            cls15 = class$org$apache$wml$dom$WMLAnchorElementImpl;
        }
        Object put13 = hashtable14.put("anchor", cls15);
        Hashtable hashtable15 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLTimerElementImpl == null) {
            Class class$16 = class$("org.apache.wml.dom.WMLTimerElementImpl");
            cls16 = class$16;
            class$org$apache$wml$dom$WMLTimerElementImpl = class$16;
        } else {
            cls16 = class$org$apache$wml$dom$WMLTimerElementImpl;
        }
        Object put14 = hashtable15.put("timer", cls16);
        Hashtable hashtable16 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLSmallElementImpl == null) {
            Class class$17 = class$("org.apache.wml.dom.WMLSmallElementImpl");
            cls17 = class$17;
            class$org$apache$wml$dom$WMLSmallElementImpl = class$17;
        } else {
            cls17 = class$org$apache$wml$dom$WMLSmallElementImpl;
        }
        Object put15 = hashtable16.put("small", cls17);
        Hashtable hashtable17 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLOptgroupElementImpl == null) {
            Class class$18 = class$("org.apache.wml.dom.WMLOptgroupElementImpl");
            cls18 = class$18;
            class$org$apache$wml$dom$WMLOptgroupElementImpl = class$18;
        } else {
            cls18 = class$org$apache$wml$dom$WMLOptgroupElementImpl;
        }
        Object put16 = hashtable17.put("optgroup", cls18);
        Hashtable hashtable18 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLHeadElementImpl == null) {
            Class class$19 = class$("org.apache.wml.dom.WMLHeadElementImpl");
            cls19 = class$19;
            class$org$apache$wml$dom$WMLHeadElementImpl = class$19;
        } else {
            cls19 = class$org$apache$wml$dom$WMLHeadElementImpl;
        }
        Object put17 = hashtable18.put("head", cls19);
        Hashtable hashtable19 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLTdElementImpl == null) {
            Class class$20 = class$("org.apache.wml.dom.WMLTdElementImpl");
            cls20 = class$20;
            class$org$apache$wml$dom$WMLTdElementImpl = class$20;
        } else {
            cls20 = class$org$apache$wml$dom$WMLTdElementImpl;
        }
        Object put18 = hashtable19.put("td", cls20);
        Hashtable hashtable20 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLFieldsetElementImpl == null) {
            Class class$21 = class$("org.apache.wml.dom.WMLFieldsetElementImpl");
            cls21 = class$21;
            class$org$apache$wml$dom$WMLFieldsetElementImpl = class$21;
        } else {
            cls21 = class$org$apache$wml$dom$WMLFieldsetElementImpl;
        }
        Object put19 = hashtable20.put("fieldset", cls21);
        Hashtable hashtable21 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLImgElementImpl == null) {
            Class class$22 = class$("org.apache.wml.dom.WMLImgElementImpl");
            cls22 = class$22;
            class$org$apache$wml$dom$WMLImgElementImpl = class$22;
        } else {
            cls22 = class$org$apache$wml$dom$WMLImgElementImpl;
        }
        Object put20 = hashtable21.put("img", cls22);
        Hashtable hashtable22 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLRefreshElementImpl == null) {
            Class class$23 = class$("org.apache.wml.dom.WMLRefreshElementImpl");
            cls23 = class$23;
            class$org$apache$wml$dom$WMLRefreshElementImpl = class$23;
        } else {
            cls23 = class$org$apache$wml$dom$WMLRefreshElementImpl;
        }
        Object put21 = hashtable22.put("refresh", cls23);
        Hashtable hashtable23 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLOneventElementImpl == null) {
            Class class$24 = class$("org.apache.wml.dom.WMLOneventElementImpl");
            cls24 = class$24;
            class$org$apache$wml$dom$WMLOneventElementImpl = class$24;
        } else {
            cls24 = class$org$apache$wml$dom$WMLOneventElementImpl;
        }
        Object put22 = hashtable23.put("onevent", cls24);
        Hashtable hashtable24 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLInputElementImpl == null) {
            Class class$25 = class$("org.apache.wml.dom.WMLInputElementImpl");
            cls25 = class$25;
            class$org$apache$wml$dom$WMLInputElementImpl = class$25;
        } else {
            cls25 = class$org$apache$wml$dom$WMLInputElementImpl;
        }
        Object put23 = hashtable24.put("input", cls25);
        Hashtable hashtable25 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLPrevElementImpl == null) {
            Class class$26 = class$("org.apache.wml.dom.WMLPrevElementImpl");
            cls26 = class$26;
            class$org$apache$wml$dom$WMLPrevElementImpl = class$26;
        } else {
            cls26 = class$org$apache$wml$dom$WMLPrevElementImpl;
        }
        Object put24 = hashtable25.put("prev", cls26);
        Hashtable hashtable26 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLTableElementImpl == null) {
            Class class$27 = class$("org.apache.wml.dom.WMLTableElementImpl");
            cls27 = class$27;
            class$org$apache$wml$dom$WMLTableElementImpl = class$27;
        } else {
            cls27 = class$org$apache$wml$dom$WMLTableElementImpl;
        }
        Object put25 = hashtable26.put("table", cls27);
        Hashtable hashtable27 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLMetaElementImpl == null) {
            Class class$28 = class$("org.apache.wml.dom.WMLMetaElementImpl");
            cls28 = class$28;
            class$org$apache$wml$dom$WMLMetaElementImpl = class$28;
        } else {
            cls28 = class$org$apache$wml$dom$WMLMetaElementImpl;
        }
        Object put26 = hashtable27.put("meta", cls28);
        Hashtable hashtable28 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLTemplateElementImpl == null) {
            Class class$29 = class$("org.apache.wml.dom.WMLTemplateElementImpl");
            cls29 = class$29;
            class$org$apache$wml$dom$WMLTemplateElementImpl = class$29;
        } else {
            cls29 = class$org$apache$wml$dom$WMLTemplateElementImpl;
        }
        Object put27 = hashtable28.put("template", cls29);
        Hashtable hashtable29 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLBrElementImpl == null) {
            Class class$30 = class$("org.apache.wml.dom.WMLBrElementImpl");
            cls30 = class$30;
            class$org$apache$wml$dom$WMLBrElementImpl = class$30;
        } else {
            cls30 = class$org$apache$wml$dom$WMLBrElementImpl;
        }
        Object put28 = hashtable29.put("br", cls30);
        Hashtable hashtable30 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLOptionElementImpl == null) {
            Class class$31 = class$("org.apache.wml.dom.WMLOptionElementImpl");
            cls31 = class$31;
            class$org$apache$wml$dom$WMLOptionElementImpl = class$31;
        } else {
            cls31 = class$org$apache$wml$dom$WMLOptionElementImpl;
        }
        Object put29 = hashtable30.put("option", cls31);
        Hashtable hashtable31 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLUElementImpl == null) {
            Class class$32 = class$("org.apache.wml.dom.WMLUElementImpl");
            cls32 = class$32;
            class$org$apache$wml$dom$WMLUElementImpl = class$32;
        } else {
            cls32 = class$org$apache$wml$dom$WMLUElementImpl;
        }
        Object put30 = hashtable31.put("u", cls32);
        Hashtable hashtable32 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLPElementImpl == null) {
            Class class$33 = class$("org.apache.wml.dom.WMLPElementImpl");
            cls33 = class$33;
            class$org$apache$wml$dom$WMLPElementImpl = class$33;
        } else {
            cls33 = class$org$apache$wml$dom$WMLPElementImpl;
        }
        Object put31 = hashtable32.put("p", cls33);
        Hashtable hashtable33 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLSelectElementImpl == null) {
            Class class$34 = class$("org.apache.wml.dom.WMLSelectElementImpl");
            cls34 = class$34;
            class$org$apache$wml$dom$WMLSelectElementImpl = class$34;
        } else {
            cls34 = class$org$apache$wml$dom$WMLSelectElementImpl;
        }
        Object put32 = hashtable33.put("select", cls34);
        Hashtable hashtable34 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLEmElementImpl == null) {
            Class class$35 = class$("org.apache.wml.dom.WMLEmElementImpl");
            cls35 = class$35;
            class$org$apache$wml$dom$WMLEmElementImpl = class$35;
        } else {
            cls35 = class$org$apache$wml$dom$WMLEmElementImpl;
        }
        Object put33 = hashtable34.put("em", cls35);
        Hashtable hashtable35 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLIElementImpl == null) {
            Class class$36 = class$("org.apache.wml.dom.WMLIElementImpl");
            cls36 = class$36;
            class$org$apache$wml$dom$WMLIElementImpl = class$36;
        } else {
            cls36 = class$org$apache$wml$dom$WMLIElementImpl;
        }
        Object put34 = hashtable35.put("i", cls36);
        Hashtable hashtable36 = _elementTypesWML;
        if (class$org$apache$wml$dom$WMLCardElementImpl == null) {
            Class class$37 = class$("org.apache.wml.dom.WMLCardElementImpl");
            cls37 = class$37;
            class$org$apache$wml$dom$WMLCardElementImpl = class$37;
        } else {
            cls37 = class$org$apache$wml$dom$WMLCardElementImpl;
        }
        Object put35 = hashtable36.put("card", cls37);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WMLDocumentImpl(DocumentType documentType) {
        super(documentType, false);
    }

    static Class class$(String str) {
        Throwable th;
        try {
            return Class.forName(str);
        } catch (ClassNotFoundException e) {
            ClassNotFoundException classNotFoundException = e;
            Throwable th2 = th;
            new NoClassDefFoundError(classNotFoundException.getMessage());
            throw th2;
        }
    }

    /* access modifiers changed from: protected */
    public boolean canRenameElements(String str, String str2, ElementImpl elementImpl) {
        String str3 = str;
        return _elementTypesWML.get(str2) == _elementTypesWML.get(elementImpl.getTagName());
    }

    public Element createElement(String str) throws DOMException {
        Element element;
        StringBuffer stringBuffer;
        Throwable th;
        StringBuffer stringBuffer2;
        String str2 = str;
        Class cls = (Class) _elementTypesWML.get(str2);
        if (cls != null) {
            Class cls2 = cls;
            try {
                Object[] objArr = new Object[2];
                objArr[0] = this;
                Object[] objArr2 = objArr;
                objArr2[1] = str2;
                return (Element) cls2.getConstructor(_elemClassSigWML).newInstance(objArr2);
            } catch (Exception e) {
                Throwable th2 = e;
                Throwable targetException = th2 instanceof InvocationTargetException ? ((InvocationTargetException) th2).getTargetException() : th2;
                PrintStream printStream = System.out;
                new StringBuffer();
                printStream.println(stringBuffer.append("Exception ").append(targetException.getClass().getName()).toString());
                System.out.println(targetException.getMessage());
                Throwable th3 = th;
                new StringBuffer();
                new IllegalStateException(stringBuffer2.append("Tag '").append(str2).append("' associated with an Element class that failed to construct.").toString());
                throw th3;
            }
        } else {
            new WMLElementImpl(this, str2);
            return element;
        }
    }
}
