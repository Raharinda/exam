package org.apache.wml;

public interface WMLSmallElement extends WMLElement {
    String getXmlLang();

    void setXmlLang(String str);
}
