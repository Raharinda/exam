package org.apache.wml;

public interface WMLBigElement extends WMLElement {
    String getXmlLang();

    void setXmlLang(String str);
}
