package org.apache.wml;

public interface WMLNoopElement extends WMLElement {
}
