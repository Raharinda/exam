package org.apache.wml;

public interface WMLUElement extends WMLElement {
    String getXmlLang();

    void setXmlLang(String str);
}
