package org.apache.wml;

public interface WMLOptgroupElement extends WMLElement {
    String getTitle();

    String getXmlLang();

    void setTitle(String str);

    void setXmlLang(String str);
}
