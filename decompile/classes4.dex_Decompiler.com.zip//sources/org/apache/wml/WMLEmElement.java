package org.apache.wml;

public interface WMLEmElement extends WMLElement {
    String getXmlLang();

    void setXmlLang(String str);
}
