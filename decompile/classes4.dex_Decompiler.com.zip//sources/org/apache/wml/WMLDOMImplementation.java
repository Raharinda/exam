package org.apache.wml;

import org.w3c.dom.DOMImplementation;

public interface WMLDOMImplementation extends DOMImplementation {
}
