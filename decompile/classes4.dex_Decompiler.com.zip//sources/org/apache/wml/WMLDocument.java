package org.apache.wml;

import org.w3c.dom.Document;

public interface WMLDocument extends Document {
}
