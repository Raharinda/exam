package org.apache.wml;

public interface WMLHeadElement extends WMLElement {
}
