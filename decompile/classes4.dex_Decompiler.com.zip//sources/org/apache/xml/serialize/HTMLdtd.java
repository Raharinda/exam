package org.apache.xml.serialize;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Hashtable;
import java.util.Locale;
import org.apache.xerces.dom.DOMMessageFormatter;

public final class HTMLdtd {
    private static final int ALLOWED_HEAD = 32;
    private static final int CLOSE_DD_DT = 128;
    private static final int CLOSE_P = 64;
    private static final int CLOSE_SELF = 256;
    private static final int CLOSE_TABLE = 512;
    private static final int CLOSE_TH_TD = 16384;
    private static final int ELEM_CONTENT = 2;
    private static final int EMPTY = 17;
    private static final String ENTITIES_RESOURCE = "HTMLEntities.res";
    public static final String HTMLPublicId = "-//W3C//DTD HTML 4.01//EN";
    public static final String HTMLSystemId = "http://www.w3.org/TR/html4/strict.dtd";
    private static final int ONLY_OPENING = 1;
    private static final int OPT_CLOSING = 8;
    private static final int PRESERVE = 4;
    public static final String XHTMLPublicId = "-//W3C//DTD XHTML 1.0 Strict//EN";
    public static final String XHTMLSystemId = "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd";
    private static Hashtable _boolAttrs;
    private static Hashtable _byChar;
    private static Hashtable _byName;
    private static Hashtable _elemDefs;
    static Class class$org$apache$xml$serialize$HTMLdtd;

    static {
        Hashtable hashtable;
        Hashtable hashtable2;
        new Hashtable();
        _elemDefs = hashtable;
        defineElement("ADDRESS", 64);
        defineElement("AREA", EMPTY);
        defineElement("BASE", 49);
        defineElement("BASEFONT", EMPTY);
        defineElement("BLOCKQUOTE", 64);
        defineElement("BODY", 8);
        defineElement("BR", EMPTY);
        defineElement("COL", EMPTY);
        defineElement("COLGROUP", 522);
        defineElement("DD", 137);
        defineElement("DIV", 64);
        defineElement("DL", 66);
        defineElement("DT", 137);
        defineElement("FIELDSET", 64);
        defineElement("FORM", 64);
        defineElement("FRAME", 25);
        defineElement("H1", 64);
        defineElement("H2", 64);
        defineElement("H3", 64);
        defineElement("H4", 64);
        defineElement("H5", 64);
        defineElement("H6", 64);
        defineElement("HEAD", 10);
        defineElement("HR", 81);
        defineElement("HTML", 10);
        defineElement("IMG", EMPTY);
        defineElement("INPUT", EMPTY);
        defineElement("ISINDEX", 49);
        defineElement("LI", 265);
        defineElement("LINK", 49);
        defineElement("MAP", 32);
        defineElement("META", 49);
        defineElement("OL", 66);
        defineElement("OPTGROUP", 2);
        defineElement("OPTION", 265);
        defineElement("P", 328);
        defineElement("PARAM", EMPTY);
        defineElement("PRE", 68);
        defineElement("SCRIPT", 36);
        defineElement("NOSCRIPT", 36);
        defineElement("SELECT", 2);
        defineElement("STYLE", 36);
        defineElement("TABLE", 66);
        defineElement("TBODY", 522);
        defineElement("TD", 16392);
        defineElement("TEXTAREA", 4);
        defineElement("TFOOT", 522);
        defineElement("TH", 16392);
        defineElement("THEAD", 522);
        defineElement("TITLE", 32);
        defineElement("TR", 522);
        defineElement("UL", 66);
        new Hashtable();
        _boolAttrs = hashtable2;
        defineBoolean("AREA", "href");
        defineBoolean("BUTTON", "disabled");
        defineBoolean("DIR", "compact");
        defineBoolean("DL", "compact");
        defineBoolean("FRAME", "noresize");
        defineBoolean("HR", "noshade");
        defineBoolean("IMAGE", "ismap");
        String[] strArr = new String[4];
        strArr[0] = "defaultchecked";
        String[] strArr2 = strArr;
        strArr2[1] = "checked";
        String[] strArr3 = strArr2;
        strArr3[2] = "readonly";
        String[] strArr4 = strArr3;
        strArr4[3] = "disabled";
        defineBoolean("INPUT", strArr4);
        defineBoolean("LINK", "link");
        defineBoolean("MENU", "compact");
        defineBoolean("OBJECT", "declare");
        defineBoolean("OL", "compact");
        defineBoolean("OPTGROUP", "disabled");
        String[] strArr5 = new String[3];
        strArr5[0] = "default-selected";
        String[] strArr6 = strArr5;
        strArr6[1] = "selected";
        String[] strArr7 = strArr6;
        strArr7[2] = "disabled";
        defineBoolean("OPTION", strArr7);
        defineBoolean("SCRIPT", "defer");
        String[] strArr8 = new String[2];
        strArr8[0] = "multiple";
        String[] strArr9 = strArr8;
        strArr9[1] = "disabled";
        defineBoolean("SELECT", strArr9);
        defineBoolean("STYLE", "disabled");
        defineBoolean("TD", "nowrap");
        defineBoolean("TH", "nowrap");
        String[] strArr10 = new String[2];
        strArr10[0] = "disabled";
        String[] strArr11 = strArr10;
        strArr11[1] = "readonly";
        defineBoolean("TEXTAREA", strArr11);
        defineBoolean("UL", "compact");
        initialize();
    }

    public HTMLdtd() {
    }

    public static int charFromName(String str) {
        initialize();
        Object obj = _byName.get(str);
        if (obj == null || !(obj instanceof Integer)) {
            return -1;
        }
        return ((Integer) obj).intValue();
    }

    static Class class$(String str) {
        Throwable th;
        try {
            return Class.forName(str);
        } catch (ClassNotFoundException e) {
            ClassNotFoundException classNotFoundException = e;
            Throwable th2 = th;
            new NoClassDefFoundError(classNotFoundException.getMessage());
            throw th2;
        }
    }

    private static void defineBoolean(String str, String str2) {
        defineBoolean(str, new String[]{str2});
    }

    private static void defineBoolean(String str, String[] strArr) {
        Object put = _boolAttrs.put(str, strArr);
    }

    private static void defineElement(String str, int i) {
        Object obj;
        new Integer(i);
        Object put = _elemDefs.put(str, obj);
    }

    private static void defineEntity(String str, char c) {
        Object obj;
        Object obj2;
        String str2 = str;
        char c2 = c;
        if (_byName.get(str2) == null) {
            new Integer(c2);
            Object put = _byName.put(str2, obj);
            new Integer(c2);
            Object put2 = _byChar.put(obj2, str2);
        }
    }

    public static String fromChar(int i) {
        Object obj;
        int i2 = i;
        if (i2 > 65535) {
            return null;
        }
        initialize();
        new Integer(i2);
        return (String) _byChar.get(obj);
    }

    private static void initialize() {
        Throwable th;
        Hashtable hashtable;
        Hashtable hashtable2;
        Class cls;
        BufferedReader bufferedReader;
        Reader reader;
        Throwable th2;
        InputStream inputStream = null;
        if (_byName == null) {
            try {
                new Hashtable();
                _byName = hashtable;
                new Hashtable();
                _byChar = hashtable2;
                if (class$org$apache$xml$serialize$HTMLdtd == null) {
                    Class class$ = class$("org.apache.xml.serialize.HTMLdtd");
                    cls = class$;
                    class$org$apache$xml$serialize$HTMLdtd = class$;
                } else {
                    cls = class$org$apache$xml$serialize$HTMLdtd;
                }
                inputStream = cls.getResourceAsStream(ENTITIES_RESOURCE);
                if (inputStream == null) {
                    Throwable th3 = th2;
                    new RuntimeException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "ResourceNotFound", new Object[]{ENTITIES_RESOURCE}));
                    throw th3;
                }
                new InputStreamReader(inputStream, "ASCII");
                new BufferedReader(reader);
                BufferedReader bufferedReader2 = bufferedReader;
                String readLine = bufferedReader2.readLine();
                while (readLine != null) {
                    if (readLine.length() == 0 || readLine.charAt(0) == '#') {
                        readLine = bufferedReader2.readLine();
                    } else {
                        int indexOf = readLine.indexOf(32);
                        if (indexOf > 1) {
                            String substring = readLine.substring(0, indexOf);
                            int i = indexOf + 1;
                            if (i < readLine.length()) {
                                String substring2 = readLine.substring(i);
                                int indexOf2 = substring2.indexOf(32);
                                if (indexOf2 > 0) {
                                    substring2 = substring2.substring(0, indexOf2);
                                }
                                defineEntity(substring, (char) Integer.parseInt(substring2));
                            }
                        }
                        readLine = bufferedReader2.readLine();
                    }
                }
                inputStream.close();
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (Exception e) {
                        Exception exc = e;
                    }
                }
            } catch (Exception e2) {
                Exception exc2 = e2;
                Throwable th4 = th;
                Object[] objArr = new Object[2];
                objArr[0] = ENTITIES_RESOURCE;
                Object[] objArr2 = objArr;
                objArr2[1] = exc2.toString();
                new RuntimeException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "ResourceNotLoaded", objArr2));
                throw th4;
            } catch (Throwable th5) {
                Throwable th6 = th5;
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (Exception e3) {
                        Exception exc3 = e3;
                    }
                }
                throw th6;
            }
        }
    }

    public static boolean isBoolean(String str, String str2) {
        String str3 = str2;
        String[] strArr = (String[]) _boolAttrs.get(str.toUpperCase(Locale.ENGLISH));
        if (strArr == null) {
            return false;
        }
        for (int i = 0; i < strArr.length; i++) {
            if (strArr[i].equalsIgnoreCase(str3)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isClosing(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        if (str4.equalsIgnoreCase("HEAD")) {
            return !isElement(str3, 32);
        } else if (str4.equalsIgnoreCase("P")) {
            return isElement(str3, 64);
        } else {
            if (str4.equalsIgnoreCase("DT") || str4.equalsIgnoreCase("DD")) {
                return isElement(str3, 128);
            }
            if (str4.equalsIgnoreCase("LI") || str4.equalsIgnoreCase("OPTION")) {
                return isElement(str3, 256);
            }
            if (str4.equalsIgnoreCase("THEAD") || str4.equalsIgnoreCase("TFOOT") || str4.equalsIgnoreCase("TBODY") || str4.equalsIgnoreCase("TR") || str4.equalsIgnoreCase("COLGROUP")) {
                return isElement(str3, CLOSE_TABLE);
            }
            if (str4.equalsIgnoreCase("TH") || str4.equalsIgnoreCase("TD")) {
                return isElement(str3, CLOSE_TH_TD);
            }
            return false;
        }
    }

    private static boolean isElement(String str, int i) {
        int i2 = i;
        Integer num = (Integer) _elemDefs.get(str.toUpperCase(Locale.ENGLISH));
        if (num == null) {
            return false;
        }
        return (num.intValue() & i2) == i2;
    }

    public static boolean isElementContent(String str) {
        return isElement(str, 2);
    }

    public static boolean isEmptyTag(String str) {
        return isElement(str, EMPTY);
    }

    public static boolean isOnlyOpening(String str) {
        return isElement(str, 1);
    }

    public static boolean isOptionalClosing(String str) {
        return isElement(str, 8);
    }

    public static boolean isPreserveSpace(String str) {
        return isElement(str, 4);
    }

    public static boolean isURI(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        return str4.equalsIgnoreCase("href") || str4.equalsIgnoreCase("src");
    }
}
