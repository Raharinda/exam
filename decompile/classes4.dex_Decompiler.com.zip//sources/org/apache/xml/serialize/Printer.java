package org.apache.xml.serialize;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

public class Printer {
    private static final int BufferSize = 4096;
    private final char[] _buffer = new char[4096];
    protected Writer _docWriter;
    protected StringWriter _dtdWriter;
    protected IOException _exception;
    protected final OutputFormat _format;
    private int _pos = 0;
    protected Writer _writer;

    public Printer(Writer writer, OutputFormat outputFormat) {
        this._writer = writer;
        this._format = outputFormat;
        this._exception = null;
        this._dtdWriter = null;
        this._docWriter = null;
        this._pos = 0;
    }

    public void breakLine() throws IOException {
        try {
            if (this._pos == 4096) {
                this._writer.write(this._buffer);
                this._pos = 0;
            }
            this._buffer[this._pos] = 10;
            this._pos++;
        } catch (IOException e) {
            IOException iOException = e;
            if (this._exception == null) {
                this._exception = iOException;
            }
            throw iOException;
        }
    }

    public void breakLine(boolean z) throws IOException {
        boolean z2 = z;
        breakLine();
    }

    public void enterDTD() throws IOException {
        StringWriter stringWriter;
        if (this._dtdWriter == null) {
            flushLine(false);
            new StringWriter();
            this._dtdWriter = stringWriter;
            this._docWriter = this._writer;
            this._writer = this._dtdWriter;
        }
    }

    public void flush() throws IOException {
        try {
            this._writer.write(this._buffer, 0, this._pos);
            this._writer.flush();
            this._pos = 0;
        } catch (IOException e) {
            IOException iOException = e;
            if (this._exception == null) {
                this._exception = iOException;
            }
            throw iOException;
        }
    }

    public void flushLine(boolean z) throws IOException {
        boolean z2 = z;
        try {
            this._writer.write(this._buffer, 0, this._pos);
        } catch (IOException e) {
            IOException iOException = e;
            if (this._exception == null) {
                this._exception = iOException;
            }
        }
        this._pos = 0;
    }

    public IOException getException() {
        return this._exception;
    }

    public int getNextIndent() {
        return 0;
    }

    public void indent() {
    }

    public String leaveDTD() throws IOException {
        if (this._writer != this._dtdWriter) {
            return null;
        }
        flushLine(false);
        this._writer = this._docWriter;
        return this._dtdWriter.toString();
    }

    public void printSpace() throws IOException {
        try {
            if (this._pos == 4096) {
                this._writer.write(this._buffer);
                this._pos = 0;
            }
            this._buffer[this._pos] = ' ';
            this._pos++;
        } catch (IOException e) {
            IOException iOException = e;
            if (this._exception == null) {
                this._exception = iOException;
            }
            throw iOException;
        }
    }

    public void printText(char c) throws IOException {
        char c2 = c;
        try {
            if (this._pos == 4096) {
                this._writer.write(this._buffer);
                this._pos = 0;
            }
            this._buffer[this._pos] = c2;
            this._pos++;
        } catch (IOException e) {
            IOException iOException = e;
            if (this._exception == null) {
                this._exception = iOException;
            }
            throw iOException;
        }
    }

    public void printText(String str) throws IOException {
        String str2 = str;
        try {
            int length = str2.length();
            for (int i = 0; i < length; i++) {
                if (this._pos == 4096) {
                    this._writer.write(this._buffer);
                    this._pos = 0;
                }
                this._buffer[this._pos] = str2.charAt(i);
                this._pos++;
            }
        } catch (IOException e) {
            IOException iOException = e;
            if (this._exception == null) {
                this._exception = iOException;
            }
            throw iOException;
        }
    }

    public void printText(StringBuffer stringBuffer) throws IOException {
        StringBuffer stringBuffer2 = stringBuffer;
        try {
            int length = stringBuffer2.length();
            for (int i = 0; i < length; i++) {
                if (this._pos == 4096) {
                    this._writer.write(this._buffer);
                    this._pos = 0;
                }
                this._buffer[this._pos] = stringBuffer2.charAt(i);
                this._pos++;
            }
        } catch (IOException e) {
            IOException iOException = e;
            if (this._exception == null) {
                this._exception = iOException;
            }
            throw iOException;
        }
    }

    public void printText(char[] cArr, int i, int i2) throws IOException {
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        while (true) {
            int i5 = i4;
            i4 = i5 - 1;
            if (i5 > 0) {
                try {
                    if (this._pos == 4096) {
                        this._writer.write(this._buffer);
                        this._pos = 0;
                    }
                    this._buffer[this._pos] = cArr2[i3];
                    i3++;
                    this._pos++;
                } catch (IOException e) {
                    IOException iOException = e;
                    if (this._exception == null) {
                        this._exception = iOException;
                    }
                    throw iOException;
                }
            } else {
                return;
            }
        }
    }

    public void setNextIndent(int i) {
    }

    public void setThisIndent(int i) {
    }

    public void unindent() {
    }
}
