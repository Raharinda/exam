package org.apache.xml.serialize;

import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import org.apache.xerces.dom.DOMMessageFormatter;

final class SerializerFactoryImpl extends SerializerFactory {
    private String _method;

    SerializerFactoryImpl(String str) {
        Throwable th;
        String str2 = str;
        this._method = str2;
        if (!this._method.equals(Method.XML) && !this._method.equals(Method.HTML) && !this._method.equals(Method.XHTML) && !this._method.equals(Method.TEXT)) {
            Throwable th2 = th;
            new IllegalArgumentException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "MethodNotSupported", new Object[]{str2}));
            throw th2;
        }
    }

    private Serializer getSerializer(OutputFormat outputFormat) {
        Throwable th;
        Serializer serializer;
        Serializer serializer2;
        Serializer serializer3;
        Serializer serializer4;
        OutputFormat outputFormat2 = outputFormat;
        if (this._method.equals(Method.XML)) {
            new XMLSerializer(outputFormat2);
            return serializer4;
        } else if (this._method.equals(Method.HTML)) {
            new HTMLSerializer(outputFormat2);
            return serializer3;
        } else if (this._method.equals(Method.XHTML)) {
            new XHTMLSerializer(outputFormat2);
            return serializer2;
        } else if (this._method.equals(Method.TEXT)) {
            new TextSerializer();
            return serializer;
        } else {
            Throwable th2 = th;
            new IllegalStateException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "MethodNotSupported", new Object[]{this._method}));
            throw th2;
        }
    }

    /* access modifiers changed from: protected */
    public String getSupportedMethod() {
        return this._method;
    }

    public Serializer makeSerializer(OutputStream outputStream, OutputFormat outputFormat) throws UnsupportedEncodingException {
        Serializer serializer = getSerializer(outputFormat);
        serializer.setOutputByteStream(outputStream);
        return serializer;
    }

    public Serializer makeSerializer(Writer writer, OutputFormat outputFormat) {
        Serializer serializer = getSerializer(outputFormat);
        serializer.setOutputCharStream(writer);
        return serializer;
    }

    public Serializer makeSerializer(OutputFormat outputFormat) {
        OutputFormat outputFormat2 = outputFormat;
        Serializer serializer = getSerializer(outputFormat2);
        serializer.setOutputFormat(outputFormat2);
        return serializer;
    }
}
