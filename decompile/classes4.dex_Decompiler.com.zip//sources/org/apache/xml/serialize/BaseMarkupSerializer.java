package org.apache.xml.serialize;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;
import java.lang.reflect.Method;
import java.util.Hashtable;
import java.util.Vector;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.Zip4jConstants;
import org.apache.xerces.dom.DOMErrorImpl;
import org.apache.xerces.dom.DOMLocatorImpl;
import org.apache.xerces.dom.DOMMessageFormatter;
import org.apache.xerces.util.XMLChar;
import org.w3c.dom.DOMError;
import org.w3c.dom.DOMErrorHandler;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.ls.LSException;
import org.w3c.dom.ls.LSSerializerFilter;
import org.xml.sax.AttributeList;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.DocumentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.ext.DeclHandler;
import org.xml.sax.ext.LexicalHandler;

public abstract class BaseMarkupSerializer implements ContentHandler, DocumentHandler, LexicalHandler, DTDHandler, DeclHandler, DOMSerializer, Serializer {
    static Class class$java$lang$String;
    protected String _docTypePublicId;
    protected String _docTypeSystemId;
    private int _elementStateCount;
    private ElementState[] _elementStates;
    protected EncodingInfo _encodingInfo;
    protected OutputFormat _format;
    protected boolean _indenting;
    private OutputStream _output;
    private Vector _preRoot;
    protected Hashtable _prefixes;
    private boolean _prepared;
    protected Printer _printer;
    protected boolean _started;
    private Writer _writer;
    protected Node fCurrentNode;
    protected final DOMErrorImpl fDOMError;
    protected DOMErrorHandler fDOMErrorHandler;
    protected LSSerializerFilter fDOMFilter;
    protected final StringBuffer fStrBuffer;
    protected short features = -1;

    protected BaseMarkupSerializer(OutputFormat outputFormat) {
        DOMErrorImpl dOMErrorImpl;
        StringBuffer stringBuffer;
        ElementState elementState;
        OutputFormat outputFormat2 = outputFormat;
        new DOMErrorImpl();
        this.fDOMError = dOMErrorImpl;
        new StringBuffer(40);
        this.fStrBuffer = stringBuffer;
        this.fCurrentNode = null;
        this._elementStates = new ElementState[10];
        for (int i = 0; i < this._elementStates.length; i++) {
            new ElementState();
            this._elementStates[i] = elementState;
        }
        this._format = outputFormat2;
    }

    static Class class$(String str) {
        Throwable th;
        try {
            return Class.forName(str);
        } catch (ClassNotFoundException e) {
            ClassNotFoundException classNotFoundException = e;
            Throwable th2 = th;
            new NoClassDefFoundError(classNotFoundException.getMessage());
            throw th2;
        }
    }

    public ContentHandler asContentHandler() throws IOException {
        prepare();
        return this;
    }

    public DOMSerializer asDOMSerializer() throws IOException {
        prepare();
        return this;
    }

    public DocumentHandler asDocumentHandler() throws IOException {
        prepare();
        return this;
    }

    public void attributeDecl(String str, String str2, String str3, String str4, String str5) throws SAXException {
        Throwable th;
        String str6 = str;
        String str7 = str2;
        String str8 = str3;
        String str9 = str4;
        String str10 = str5;
        try {
            this._printer.enterDTD();
            this._printer.printText("<!ATTLIST ");
            this._printer.printText(str6);
            this._printer.printText(' ');
            this._printer.printText(str7);
            this._printer.printText(' ');
            this._printer.printText(str8);
            if (str9 != null) {
                this._printer.printText(' ');
                this._printer.printText(str9);
            }
            if (str10 != null) {
                this._printer.printText(" \"");
                printEscaped(str10);
                this._printer.printText('\"');
            }
            this._printer.printText('>');
            if (this._indenting) {
                this._printer.breakLine();
            }
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    /* access modifiers changed from: protected */
    public void characters(String str) throws IOException {
        String str2 = str;
        ElementState content = content();
        if (content.inCData || content.doCData) {
            if (!content.inCData) {
                this._printer.printText("<![CDATA[");
                content.inCData = true;
            }
            int nextIndent = this._printer.getNextIndent();
            this._printer.setNextIndent(0);
            printCDATAText(str2);
            this._printer.setNextIndent(nextIndent);
        } else if (content.preserveSpace) {
            int nextIndent2 = this._printer.getNextIndent();
            this._printer.setNextIndent(0);
            printText(str2, true, content.unescaped);
            this._printer.setNextIndent(nextIndent2);
        } else {
            printText(str2, false, content.unescaped);
        }
    }

    public void characters(char[] cArr, int i, int i2) throws SAXException {
        Throwable th;
        StringBuffer stringBuffer;
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        try {
            ElementState content = content();
            if (content.inCData || content.doCData) {
                if (!content.inCData) {
                    this._printer.printText("<![CDATA[");
                    content.inCData = true;
                }
                int nextIndent = this._printer.getNextIndent();
                this._printer.setNextIndent(0);
                int i5 = i3 + i4;
                int i6 = i3;
                while (i6 < i5) {
                    char c = cArr2[i6];
                    if (c == ']' && i6 + 2 < i5 && cArr2[i6 + 1] == ']' && cArr2[i6 + 2] == '>') {
                        this._printer.printText("]]]]><![CDATA[>");
                        i6 += 2;
                    } else if (!XMLChar.isValid(c)) {
                        i6++;
                        if (i6 < i5) {
                            surrogates(c, cArr2[i6], true);
                        } else {
                            new StringBuffer();
                            fatalError(stringBuffer.append("The character '").append(c).append("' is an invalid XML character").toString());
                        }
                    } else if ((c >= ' ' && this._encodingInfo.isPrintable(c) && c != 127) || c == 10 || c == 13 || c == 9) {
                        this._printer.printText(c);
                    } else {
                        this._printer.printText("]]>&#x");
                        this._printer.printText(Integer.toHexString(c));
                        this._printer.printText(";<![CDATA[");
                    }
                    i6++;
                }
                this._printer.setNextIndent(nextIndent);
            } else if (content.preserveSpace) {
                int nextIndent2 = this._printer.getNextIndent();
                this._printer.setNextIndent(0);
                printText(cArr2, i3, i4, true, content.unescaped);
                this._printer.setNextIndent(nextIndent2);
            } else {
                printText(cArr2, i3, i4, false, content.unescaped);
            }
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    /* access modifiers changed from: protected */
    public void checkUnboundNamespacePrefixedNode(Node node) throws IOException {
    }

    /* access modifiers changed from: protected */
    public void cleanup() {
        this.fCurrentNode = null;
    }

    /* access modifiers changed from: package-private */
    public final void clearDocumentState() {
        this._elementStateCount = 0;
    }

    public void comment(String str) throws IOException {
        Vector vector;
        String str2 = str;
        if (!this._format.getOmitComments()) {
            ElementState content = content();
            int indexOf = str2.indexOf("-->");
            if (indexOf >= 0) {
                StringBuffer append = this.fStrBuffer.append("<!--").append(str2.substring(0, indexOf)).append("-->");
            } else {
                StringBuffer append2 = this.fStrBuffer.append("<!--").append(str2).append("-->");
            }
            if (isDocumentState()) {
                if (this._preRoot == null) {
                    new Vector();
                    this._preRoot = vector;
                }
                this._preRoot.addElement(this.fStrBuffer.toString());
            } else {
                if (this._indenting && !content.preserveSpace) {
                    this._printer.breakLine();
                }
                this._printer.indent();
                printText(this.fStrBuffer.toString(), true, true);
                this._printer.unindent();
                if (this._indenting) {
                    content.afterElement = true;
                }
            }
            this.fStrBuffer.setLength(0);
            content.afterComment = true;
            content.afterElement = false;
        }
    }

    public void comment(char[] cArr, int i, int i2) throws SAXException {
        Throwable th;
        String str;
        try {
            new String(cArr, i, i2);
            comment(str);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    /* access modifiers changed from: protected */
    public ElementState content() throws IOException {
        ElementState elementState = getElementState();
        if (!isDocumentState()) {
            if (elementState.inCData && !elementState.doCData) {
                this._printer.printText("]]>");
                elementState.inCData = false;
            }
            if (elementState.empty) {
                this._printer.printText('>');
                elementState.empty = false;
            }
            elementState.afterElement = false;
            elementState.afterComment = false;
        }
        return elementState;
    }

    public void elementDecl(String str, String str2) throws SAXException {
        Throwable th;
        String str3 = str;
        String str4 = str2;
        try {
            this._printer.enterDTD();
            this._printer.printText("<!ELEMENT ");
            this._printer.printText(str3);
            this._printer.printText(' ');
            this._printer.printText(str4);
            this._printer.printText('>');
            if (this._indenting) {
                this._printer.breakLine();
            }
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    public void endCDATA() {
        getElementState().doCData = false;
    }

    public void endDTD() {
    }

    public void endDocument() throws SAXException {
        Throwable th;
        try {
            serializePreRoot();
            this._printer.flush();
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    public abstract void endElement(String str) throws SAXException;

    public abstract void endElement(String str, String str2, String str3) throws SAXException;

    public void endEntity(String str) {
    }

    public void endNonEscaping() {
        getElementState().unescaped = false;
    }

    public void endPrefixMapping(String str) throws SAXException {
    }

    public void endPreserving() {
        getElementState().preserveSpace = false;
    }

    /* access modifiers changed from: protected */
    public ElementState enterElementState(String str, String str2, String str3, boolean z) {
        ElementState elementState;
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        boolean z2 = z;
        if (this._elementStateCount + 1 == this._elementStates.length) {
            ElementState[] elementStateArr = new ElementState[(this._elementStates.length + 10)];
            for (int i = 0; i < this._elementStates.length; i++) {
                elementStateArr[i] = this._elementStates[i];
            }
            for (int length = this._elementStates.length; length < elementStateArr.length; length++) {
                new ElementState();
                elementStateArr[length] = elementState;
            }
            this._elementStates = elementStateArr;
        }
        this._elementStateCount++;
        ElementState elementState2 = this._elementStates[this._elementStateCount];
        elementState2.namespaceURI = str4;
        elementState2.localName = str5;
        elementState2.rawName = str6;
        elementState2.preserveSpace = z2;
        elementState2.empty = true;
        elementState2.afterElement = false;
        elementState2.afterComment = false;
        elementState2.inCData = false;
        elementState2.doCData = false;
        elementState2.unescaped = false;
        elementState2.prefixes = this._prefixes;
        this._prefixes = null;
        return elementState2;
    }

    public void externalEntityDecl(String str, String str2, String str3) throws SAXException {
        Throwable th;
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        try {
            this._printer.enterDTD();
            unparsedEntityDecl(str4, str5, str6, (String) null);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    /* access modifiers changed from: protected */
    public void fatalError(String str) throws IOException {
        Throwable th;
        String str2 = str;
        if (this.fDOMErrorHandler != null) {
            DOMError modifyDOMError = modifyDOMError(str2, 3, (String) null, this.fCurrentNode);
            boolean handleError = this.fDOMErrorHandler.handleError(this.fDOMError);
            return;
        }
        Throwable th2 = th;
        new IOException(str2);
        throw th2;
    }

    /* access modifiers changed from: protected */
    public ElementState getElementState() {
        return this._elementStates[this._elementStateCount];
    }

    /* access modifiers changed from: protected */
    public abstract String getEntityRef(int i);

    /* access modifiers changed from: protected */
    public String getPrefix(String str) {
        String str2;
        String str3;
        String str4 = str;
        if (this._prefixes != null && (str3 = (String) this._prefixes.get(str4)) != null) {
            return str3;
        }
        if (this._elementStateCount == 0) {
            return null;
        }
        for (int i = this._elementStateCount; i > 0; i--) {
            if (this._elementStates[i].prefixes != null && (str2 = (String) this._elementStates[i].prefixes.get(str4)) != null) {
                return str2;
            }
        }
        return null;
    }

    public void ignorableWhitespace(char[] cArr, int i, int i2) throws SAXException {
        Throwable th;
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        try {
            ElementState content = content();
            if (this._indenting) {
                this._printer.setThisIndent(0);
                int i5 = i3;
                while (true) {
                    int i6 = i4;
                    i4 = i6 - 1;
                    if (i6 > 0) {
                        this._printer.printText(cArr2[i5]);
                        i5++;
                    } else {
                        return;
                    }
                }
            }
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    public void internalEntityDecl(String str, String str2) throws SAXException {
        Throwable th;
        String str3 = str;
        String str4 = str2;
        try {
            this._printer.enterDTD();
            this._printer.printText("<!ENTITY ");
            this._printer.printText(str3);
            this._printer.printText(" \"");
            printEscaped(str4);
            this._printer.printText("\">");
            if (this._indenting) {
                this._printer.breakLine();
            }
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    /* access modifiers changed from: protected */
    public boolean isDocumentState() {
        return this._elementStateCount == 0;
    }

    /* access modifiers changed from: protected */
    public ElementState leaveElementState() {
        Throwable th;
        if (this._elementStateCount > 0) {
            this._prefixes = null;
            this._elementStateCount--;
            return this._elementStates[this._elementStateCount];
        }
        Throwable th2 = th;
        new IllegalStateException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "Internal", (Object[]) null));
        throw th2;
    }

    /* access modifiers changed from: protected */
    public DOMError modifyDOMError(String str, short s, String str2, Node node) {
        DOMLocatorImpl dOMLocatorImpl;
        this.fDOMError.reset();
        this.fDOMError.fMessage = str;
        this.fDOMError.fType = str2;
        this.fDOMError.fSeverity = s;
        DOMErrorImpl dOMErrorImpl = this.fDOMError;
        new DOMLocatorImpl(-1, -1, -1, node, (String) null);
        dOMErrorImpl.fLocator = dOMLocatorImpl;
        return this.fDOMError;
    }

    public void notationDecl(String str, String str2, String str3) throws SAXException {
        Throwable th;
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        try {
            this._printer.enterDTD();
            if (str5 != null) {
                this._printer.printText("<!NOTATION ");
                this._printer.printText(str4);
                this._printer.printText(" PUBLIC ");
                printDoctypeURL(str5);
                if (str6 != null) {
                    this._printer.printText(' ');
                    printDoctypeURL(str6);
                }
            } else {
                this._printer.printText("<!NOTATION ");
                this._printer.printText(str4);
                this._printer.printText(" SYSTEM ");
                printDoctypeURL(str6);
            }
            this._printer.printText('>');
            if (this._indenting) {
                this._printer.breakLine();
            }
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    /* access modifiers changed from: protected */
    public void prepare() throws IOException {
        Printer printer;
        Printer printer2;
        Throwable th;
        if (!this._prepared) {
            if (this._writer == null && this._output == null) {
                Throwable th2 = th;
                new IOException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "NoWriterSupplied", (Object[]) null));
                throw th2;
            }
            this._encodingInfo = this._format.getEncodingInfo();
            if (this._output != null) {
                this._writer = this._encodingInfo.getWriter(this._output);
            }
            if (this._format.getIndenting()) {
                this._indenting = true;
                new IndentPrinter(this._writer, this._format);
                this._printer = printer2;
            } else {
                this._indenting = false;
                new Printer(this._writer, this._format);
                this._printer = printer;
            }
            this._elementStateCount = 0;
            ElementState elementState = this._elementStates[0];
            elementState.namespaceURI = null;
            elementState.localName = null;
            elementState.rawName = null;
            elementState.preserveSpace = this._format.getPreserveSpace();
            elementState.empty = true;
            elementState.afterElement = false;
            elementState.afterComment = false;
            elementState.inCData = false;
            elementState.doCData = false;
            elementState.prefixes = null;
            this._docTypePublicId = this._format.getDoctypePublic();
            this._docTypeSystemId = this._format.getDoctypeSystem();
            this._started = false;
            this._prepared = true;
        }
    }

    /* access modifiers changed from: protected */
    public void printCDATAText(String str) throws IOException {
        StringBuffer stringBuffer;
        Throwable th;
        Throwable th2;
        String str2 = str;
        int length = str2.length();
        int i = 0;
        while (i < length) {
            char charAt = str2.charAt(i);
            if (charAt == ']' && i + 2 < length && str2.charAt(i + 1) == ']' && str2.charAt(i + 2) == '>') {
                if (this.fDOMErrorHandler != null) {
                    if ((this.features & 16) == 0) {
                        String formatMessage = DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "EndingCDATA", (Object[]) null);
                        if ((this.features & 2) != 0) {
                            DOMError modifyDOMError = modifyDOMError(formatMessage, 3, "wf-invalid-character", this.fCurrentNode);
                            boolean handleError = this.fDOMErrorHandler.handleError(this.fDOMError);
                            Throwable th3 = th;
                            new LSException(82, formatMessage);
                            throw th3;
                        }
                        DOMError modifyDOMError2 = modifyDOMError(formatMessage, 2, "cdata-section-not-splitted", this.fCurrentNode);
                        if (!this.fDOMErrorHandler.handleError(this.fDOMError)) {
                            Throwable th4 = th2;
                            new LSException(82, formatMessage);
                            throw th4;
                        }
                    } else {
                        DOMError modifyDOMError3 = modifyDOMError(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "SplittingCDATA", (Object[]) null), 1, (String) null, this.fCurrentNode);
                        boolean handleError2 = this.fDOMErrorHandler.handleError(this.fDOMError);
                    }
                }
                this._printer.printText("]]]]><![CDATA[>");
                i += 2;
            } else if (!XMLChar.isValid(charAt)) {
                i++;
                if (i < length) {
                    surrogates(charAt, str2.charAt(i), true);
                } else {
                    new StringBuffer();
                    fatalError(stringBuffer.append("The character '").append(charAt).append("' is an invalid XML character").toString());
                }
            } else if ((charAt >= ' ' && this._encodingInfo.isPrintable(charAt) && charAt != 127) || charAt == 10 || charAt == 13 || charAt == 9) {
                this._printer.printText(charAt);
            } else {
                this._printer.printText("]]>&#x");
                this._printer.printText(Integer.toHexString(charAt));
                this._printer.printText(";<![CDATA[");
            }
            i++;
        }
    }

    /* access modifiers changed from: protected */
    public void printDoctypeURL(String str) throws IOException {
        String str2 = str;
        this._printer.printText('\"');
        for (int i = 0; i < str2.length(); i++) {
            if (str2.charAt(i) == '\"' || str2.charAt(i) < ' ' || str2.charAt(i) > 127) {
                this._printer.printText('%');
                this._printer.printText(Integer.toHexString(str2.charAt(i)));
            } else {
                this._printer.printText(str2.charAt(i));
            }
        }
        this._printer.printText('\"');
    }

    /* access modifiers changed from: protected */
    public void printEscaped(int i) throws IOException {
        int i2 = i;
        String entityRef = getEntityRef(i2);
        if (entityRef != null) {
            this._printer.printText('&');
            this._printer.printText(entityRef);
            this._printer.printText(';');
        } else if ((i2 < 32 || !this._encodingInfo.isPrintable((char) i2) || i2 == 127) && i2 != 10 && i2 != 13 && i2 != 9) {
            printHex(i2);
        } else if (i2 < 65536) {
            this._printer.printText((char) i2);
        } else {
            this._printer.printText((char) (((i2 - InternalZipConstants.MIN_SPLIT_LENGTH) >> 10) + 55296));
            this._printer.printText((char) (((i2 - InternalZipConstants.MIN_SPLIT_LENGTH) & 1023) + 56320));
        }
    }

    /* access modifiers changed from: protected */
    public void printEscaped(String str) throws IOException {
        String str2 = str;
        int i = 0;
        while (i < str2.length()) {
            char charAt = str2.charAt(i);
            if ((charAt & 64512) == 55296 && i + 1 < str2.length()) {
                char charAt2 = str2.charAt(i + 1);
                if ((charAt2 & 64512) == 56320) {
                    charAt = ((InternalZipConstants.MIN_SPLIT_LENGTH + ((charAt - 55296) << 10)) + charAt2) - 56320;
                    i++;
                }
            }
            printEscaped((int) charAt);
            i++;
        }
    }

    /* access modifiers changed from: package-private */
    public final void printHex(int i) throws IOException {
        this._printer.printText("&#x");
        this._printer.printText(Integer.toHexString(i));
        this._printer.printText(';');
    }

    /* access modifiers changed from: protected */
    public void printText(String str, boolean z, boolean z2) throws IOException {
        String str2 = str;
        boolean z3 = z2;
        if (z) {
            for (int i = 0; i < str2.length(); i++) {
                char charAt = str2.charAt(i);
                if (charAt == 10 || charAt == 13 || z3) {
                    this._printer.printText(charAt);
                } else {
                    printEscaped((int) charAt);
                }
            }
            return;
        }
        for (int i2 = 0; i2 < str2.length(); i2++) {
            char charAt2 = str2.charAt(i2);
            if (charAt2 == ' ' || charAt2 == 12 || charAt2 == 9 || charAt2 == 10 || charAt2 == 13) {
                this._printer.printSpace();
            } else if (z3) {
                this._printer.printText(charAt2);
            } else {
                printEscaped((int) charAt2);
            }
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: CFG modification limit reached, blocks count: 138 */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0069, code lost:
        if (r5 == false) goto L_0x0073;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x006b, code lost:
        r0._printer.printText(r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0073, code lost:
        printEscaped((int) r6);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void printText(char[] r12, int r13, int r14, boolean r15, boolean r16) throws java.io.IOException {
        /*
            r11 = this;
            r0 = r11
            r1 = r12
            r2 = r13
            r3 = r14
            r4 = r15
            r5 = r16
            r7 = r4
            if (r7 == 0) goto L_0x005d
        L_0x000a:
            r7 = r3
            r10 = r7
            r7 = r10
            r8 = r10
            r9 = 1
            int r8 = r8 + -1
            r3 = r8
            if (r7 > 0) goto L_0x0015
        L_0x0014:
            return
        L_0x0015:
            r7 = r1
            r8 = r2
            char r7 = r7[r8]
            r6 = r7
            int r2 = r2 + 1
            r7 = r6
            r8 = 10
            if (r7 == r8) goto L_0x0029
            r7 = r6
            r8 = 13
            if (r7 == r8) goto L_0x0029
            r7 = r5
            if (r7 == 0) goto L_0x0031
        L_0x0029:
            r7 = r0
            org.apache.xml.serialize.Printer r7 = r7._printer
            r8 = r6
            r7.printText((char) r8)
            goto L_0x000a
        L_0x0031:
            r7 = r0
            r8 = r6
            r7.printEscaped((int) r8)
            goto L_0x000a
        L_0x0037:
            r7 = r1
            r8 = r2
            char r7 = r7[r8]
            r6 = r7
            int r2 = r2 + 1
            r7 = r6
            r8 = 32
            if (r7 == r8) goto L_0x0057
            r7 = r6
            r8 = 12
            if (r7 == r8) goto L_0x0057
            r7 = r6
            r8 = 9
            if (r7 == r8) goto L_0x0057
            r7 = r6
            r8 = 10
            if (r7 == r8) goto L_0x0057
            r7 = r6
            r8 = 13
            if (r7 != r8) goto L_0x0068
        L_0x0057:
            r7 = r0
            org.apache.xml.serialize.Printer r7 = r7._printer
            r7.printSpace()
        L_0x005d:
            r7 = r3
            r10 = r7
            r7 = r10
            r8 = r10
            r9 = 1
            int r8 = r8 + -1
            r3 = r8
            if (r7 > 0) goto L_0x0037
            goto L_0x0014
        L_0x0068:
            r7 = r5
            if (r7 == 0) goto L_0x0073
            r7 = r0
            org.apache.xml.serialize.Printer r7 = r7._printer
            r8 = r6
            r7.printText((char) r8)
            goto L_0x005d
        L_0x0073:
            r7 = r0
            r8 = r6
            r7.printEscaped((int) r8)
            goto L_0x005d
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.BaseMarkupSerializer.printText(char[], int, int, boolean, boolean):void");
    }

    public final void processingInstruction(String str, String str2) throws SAXException {
        Throwable th;
        try {
            processingInstructionIO(str, str2);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    public void processingInstructionIO(String str, String str2) throws IOException {
        Vector vector;
        String str3 = str;
        String str4 = str2;
        ElementState content = content();
        int indexOf = str3.indexOf("?>");
        if (indexOf >= 0) {
            StringBuffer append = this.fStrBuffer.append("<?").append(str3.substring(0, indexOf));
        } else {
            StringBuffer append2 = this.fStrBuffer.append("<?").append(str3);
        }
        if (str4 != null) {
            StringBuffer append3 = this.fStrBuffer.append(' ');
            int indexOf2 = str4.indexOf("?>");
            if (indexOf2 >= 0) {
                StringBuffer append4 = this.fStrBuffer.append(str4.substring(0, indexOf2));
            } else {
                StringBuffer append5 = this.fStrBuffer.append(str4);
            }
        }
        StringBuffer append6 = this.fStrBuffer.append("?>");
        if (isDocumentState()) {
            if (this._preRoot == null) {
                new Vector();
                this._preRoot = vector;
            }
            this._preRoot.addElement(this.fStrBuffer.toString());
        } else {
            this._printer.indent();
            printText(this.fStrBuffer.toString(), true, true);
            this._printer.unindent();
            if (this._indenting) {
                content.afterElement = true;
            }
        }
        this.fStrBuffer.setLength(0);
    }

    public boolean reset() {
        Throwable th;
        if (this._elementStateCount > 1) {
            Throwable th2 = th;
            new IllegalStateException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "ResetInMiddle", (Object[]) null));
            throw th2;
        }
        this._prepared = false;
        this.fCurrentNode = null;
        this.fStrBuffer.setLength(0);
        return true;
    }

    public void serialize(Document document) throws IOException {
        boolean reset = reset();
        prepare();
        serializeNode(document);
        serializePreRoot();
        cleanup();
        this._printer.flush();
        if (this._printer.getException() != null) {
            throw this._printer.getException();
        }
    }

    public void serialize(DocumentFragment documentFragment) throws IOException {
        boolean reset = reset();
        prepare();
        serializeNode(documentFragment);
        cleanup();
        this._printer.flush();
        if (this._printer.getException() != null) {
            throw this._printer.getException();
        }
    }

    public void serialize(Element element) throws IOException {
        boolean reset = reset();
        prepare();
        serializeNode(element);
        cleanup();
        this._printer.flush();
        if (this._printer.getException() != null) {
            throw this._printer.getException();
        }
    }

    /* access modifiers changed from: protected */
    public abstract void serializeElement(Element element) throws IOException;

    /* access modifiers changed from: protected */
    public void serializeNode(Node node) throws IOException {
        Class cls;
        Class cls2;
        String nodeValue;
        Node node2 = node;
        this.fCurrentNode = node2;
        switch (node2.getNodeType()) {
            case 1:
                if (!(this.fDOMFilter == null || (this.fDOMFilter.getWhatToShow() & 1) == 0)) {
                    switch (this.fDOMFilter.acceptNode(node2)) {
                        case 2:
                            return;
                        case 3:
                            Node firstChild = node2.getFirstChild();
                            while (true) {
                                Node node3 = firstChild;
                                if (node3 != null) {
                                    serializeNode(node3);
                                    firstChild = node3.getNextSibling();
                                } else {
                                    return;
                                }
                            }
                    }
                }
                serializeElement((Element) node2);
                return;
            case 3:
                String nodeValue2 = node2.getNodeValue();
                if (nodeValue2 == null) {
                    return;
                }
                if (this.fDOMFilter != null && (this.fDOMFilter.getWhatToShow() & 4) != 0) {
                    switch (this.fDOMFilter.acceptNode(node2)) {
                        case 2:
                        case 3:
                            return;
                        default:
                            characters(nodeValue2);
                            return;
                    }
                } else if (!this._indenting || getElementState().preserveSpace || nodeValue2.replace(10, ' ').trim().length() != 0) {
                    characters(nodeValue2);
                    return;
                } else {
                    return;
                }
            case 4:
                String nodeValue3 = node2.getNodeValue();
                if ((this.features & 8) == 0) {
                    characters(nodeValue3);
                    return;
                } else if (nodeValue3 != null) {
                    if (!(this.fDOMFilter == null || (this.fDOMFilter.getWhatToShow() & 8) == 0)) {
                        switch (this.fDOMFilter.acceptNode(node2)) {
                            case 2:
                            case 3:
                                return;
                        }
                    }
                    startCDATA();
                    characters(nodeValue3);
                    endCDATA();
                    return;
                } else {
                    return;
                }
            case 5:
                endCDATA();
                ElementState content = content();
                if ((this.features & 4) != 0 || node2.getFirstChild() == null) {
                    if (!(this.fDOMFilter == null || (this.fDOMFilter.getWhatToShow() & 16) == 0)) {
                        switch (this.fDOMFilter.acceptNode(node2)) {
                            case 2:
                                return;
                            case 3:
                                Node firstChild2 = node2.getFirstChild();
                                while (true) {
                                    Node node4 = firstChild2;
                                    if (node4 != null) {
                                        serializeNode(node4);
                                        firstChild2 = node4.getNextSibling();
                                    } else {
                                        return;
                                    }
                                }
                        }
                    }
                    checkUnboundNamespacePrefixedNode(node2);
                    this._printer.printText("&");
                    this._printer.printText(node2.getNodeName());
                    this._printer.printText(";");
                    return;
                }
                Node firstChild3 = node2.getFirstChild();
                while (true) {
                    Node node5 = firstChild3;
                    if (node5 != null) {
                        serializeNode(node5);
                        firstChild3 = node5.getNextSibling();
                    } else {
                        return;
                    }
                }
                break;
            case Zip4jConstants.DEFLATE_LEVEL_MAXIMUM:
                if (!(this.fDOMFilter == null || (this.fDOMFilter.getWhatToShow() & 64) == 0)) {
                    switch (this.fDOMFilter.acceptNode(node2)) {
                        case 2:
                        case 3:
                            return;
                    }
                }
                processingInstructionIO(node2.getNodeName(), node2.getNodeValue());
                return;
            case 8:
                if (!this._format.getOmitComments() && (nodeValue = node2.getNodeValue()) != null) {
                    if (!(this.fDOMFilter == null || (this.fDOMFilter.getWhatToShow() & 128) == 0)) {
                        switch (this.fDOMFilter.acceptNode(node2)) {
                            case 2:
                            case 3:
                                return;
                        }
                    }
                    comment(nodeValue);
                    return;
                }
                return;
            case Zip4jConstants.DEFLATE_LEVEL_ULTRA:
                DocumentType doctype = ((Document) node2).getDoctype();
                if (doctype != null) {
                    try {
                        this._printer.enterDTD();
                        this._docTypePublicId = doctype.getPublicId();
                        this._docTypeSystemId = doctype.getSystemId();
                        String internalSubset = doctype.getInternalSubset();
                        if (internalSubset != null && internalSubset.length() > 0) {
                            this._printer.printText(internalSubset);
                        }
                        endDTD();
                        break;
                    } catch (NoSuchMethodError e) {
                        NoSuchMethodError noSuchMethodError = e;
                        Class<?> cls3 = doctype.getClass();
                        String str = null;
                        String str2 = null;
                        try {
                            Method method = cls3.getMethod("getPublicId", (Class[]) null);
                            Class<?> returnType = method.getReturnType();
                            if (class$java$lang$String == null) {
                                Class class$ = class$("java.lang.String");
                                cls2 = class$;
                                class$java$lang$String = class$;
                            } else {
                                cls2 = class$java$lang$String;
                            }
                            if (returnType.equals(cls2)) {
                                str = (String) method.invoke(doctype, (Object[]) null);
                            }
                        } catch (Exception e2) {
                            Exception exc = e2;
                        }
                        try {
                            Method method2 = cls3.getMethod("getSystemId", (Class[]) null);
                            Class<?> returnType2 = method2.getReturnType();
                            if (class$java$lang$String == null) {
                                Class class$2 = class$("java.lang.String");
                                cls = class$2;
                                class$java$lang$String = class$2;
                            } else {
                                cls = class$java$lang$String;
                            }
                            if (returnType2.equals(cls)) {
                                str2 = (String) method2.invoke(doctype, (Object[]) null);
                            }
                        } catch (Exception e3) {
                            Exception exc2 = e3;
                        }
                        this._printer.enterDTD();
                        this._docTypePublicId = str;
                        this._docTypeSystemId = str2;
                        endDTD();
                        break;
                    }
                }
                break;
            case 11:
                break;
            default:
                return;
        }
        Node firstChild4 = node2.getFirstChild();
        while (true) {
            Node node6 = firstChild4;
            if (node6 != null) {
                serializeNode(node6);
                firstChild4 = node6.getNextSibling();
            } else {
                return;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void serializePreRoot() throws IOException {
        if (this._preRoot != null) {
            for (int i = 0; i < this._preRoot.size(); i++) {
                printText((String) this._preRoot.elementAt(i), true, true);
                if (this._indenting) {
                    this._printer.breakLine();
                }
            }
            this._preRoot.removeAllElements();
        }
    }

    public void setDocumentLocator(Locator locator) {
    }

    public void setOutputByteStream(OutputStream outputStream) {
        Throwable th;
        OutputStream outputStream2 = outputStream;
        if (outputStream2 == null) {
            Throwable th2 = th;
            new NullPointerException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "ArgumentIsNull", new Object[]{"output"}));
            throw th2;
        }
        this._output = outputStream2;
        this._writer = null;
        boolean reset = reset();
    }

    public void setOutputCharStream(Writer writer) {
        Throwable th;
        Writer writer2 = writer;
        if (writer2 == null) {
            Throwable th2 = th;
            new NullPointerException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "ArgumentIsNull", new Object[]{"writer"}));
            throw th2;
        }
        this._writer = writer2;
        this._output = null;
        boolean reset = reset();
    }

    public void setOutputFormat(OutputFormat outputFormat) {
        Throwable th;
        OutputFormat outputFormat2 = outputFormat;
        if (outputFormat2 == null) {
            Throwable th2 = th;
            new NullPointerException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "ArgumentIsNull", new Object[]{"format"}));
            throw th2;
        }
        this._format = outputFormat2;
        boolean reset = reset();
    }

    public void skippedEntity(String str) throws SAXException {
        Throwable th;
        String str2 = str;
        try {
            endCDATA();
            ElementState content = content();
            this._printer.printText('&');
            this._printer.printText(str2);
            this._printer.printText(';');
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    public void startCDATA() {
        getElementState().doCData = true;
    }

    public final void startDTD(String str, String str2, String str3) throws SAXException {
        Throwable th;
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        try {
            this._printer.enterDTD();
            this._docTypePublicId = str5;
            this._docTypeSystemId = str6;
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    public void startDocument() throws SAXException {
        Throwable th;
        try {
            prepare();
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException.toString());
            throw th2;
        }
    }

    public abstract void startElement(String str, String str2, String str3, Attributes attributes) throws SAXException;

    public abstract void startElement(String str, AttributeList attributeList) throws SAXException;

    public void startEntity(String str) {
    }

    public void startNonEscaping() {
        getElementState().unescaped = true;
    }

    public void startPrefixMapping(String str, String str2) throws SAXException {
        Hashtable hashtable;
        String str3 = str;
        String str4 = str2;
        if (this._prefixes == null) {
            new Hashtable();
            this._prefixes = hashtable;
        }
        Object put = this._prefixes.put(str4, str3 == null ? "" : str3);
    }

    public void startPreserving() {
        getElementState().preserveSpace = true;
    }

    /* access modifiers changed from: protected */
    public void surrogates(int i, int i2, boolean z) throws IOException {
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        StringBuffer stringBuffer3;
        int i3 = i;
        int i4 = i2;
        boolean z2 = z;
        if (!XMLChar.isHighSurrogate(i3)) {
            new StringBuffer();
            fatalError(stringBuffer.append("The character '").append((char) i3).append("' is an invalid XML character").toString());
        } else if (!XMLChar.isLowSurrogate(i4)) {
            new StringBuffer();
            fatalError(stringBuffer3.append("The character '").append((char) i4).append("' is an invalid XML character").toString());
        } else {
            int supplemental = XMLChar.supplemental((char) i3, (char) i4);
            if (!XMLChar.isValid(supplemental)) {
                new StringBuffer();
                fatalError(stringBuffer2.append("The character '").append((char) supplemental).append("' is an invalid XML character").toString());
            } else if (!z2 || !content().inCData) {
                printHex(supplemental);
            } else {
                this._printer.printText("]]>&#x");
                this._printer.printText(Integer.toHexString(supplemental));
                this._printer.printText(";<![CDATA[");
            }
        }
    }

    public void unparsedEntityDecl(String str, String str2, String str3, String str4) throws SAXException {
        Throwable th;
        String str5 = str;
        String str6 = str2;
        String str7 = str3;
        String str8 = str4;
        try {
            this._printer.enterDTD();
            if (str6 == null) {
                this._printer.printText("<!ENTITY ");
                this._printer.printText(str5);
                this._printer.printText(" SYSTEM ");
                printDoctypeURL(str7);
            } else {
                this._printer.printText("<!ENTITY ");
                this._printer.printText(str5);
                this._printer.printText(" PUBLIC ");
                printDoctypeURL(str6);
                this._printer.printText(' ');
                printDoctypeURL(str7);
            }
            if (str8 != null) {
                this._printer.printText(" NDATA ");
                this._printer.printText(str8);
            }
            this._printer.printText('>');
            if (this._indenting) {
                this._printer.breakLine();
            }
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }
}
