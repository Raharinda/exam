package org.apache.xml.serialize;

public class XHTMLSerializer extends HTMLSerializer {
    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XHTMLSerializer() {
        /*
            r9 = this;
            r0 = r9
            r1 = r0
            r2 = 1
            org.apache.xml.serialize.OutputFormat r3 = new org.apache.xml.serialize.OutputFormat
            r8 = r3
            r3 = r8
            r4 = r8
            java.lang.String r5 = "xhtml"
            r6 = 0
            r7 = 0
            r4.<init>((java.lang.String) r5, (java.lang.String) r6, (boolean) r7)
            r1.<init>((boolean) r2, (org.apache.xml.serialize.OutputFormat) r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.XHTMLSerializer.<init>():void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XHTMLSerializer(java.io.OutputStream r12, org.apache.xml.serialize.OutputFormat r13) {
        /*
            r11 = this;
            r0 = r11
            r1 = r12
            r2 = r13
            r3 = r0
            r4 = 1
            r5 = r2
            if (r5 == 0) goto L_0x0012
            r5 = r2
        L_0x0009:
            r3.<init>((boolean) r4, (org.apache.xml.serialize.OutputFormat) r5)
            r3 = r0
            r4 = r1
            r3.setOutputByteStream(r4)
            return
        L_0x0012:
            org.apache.xml.serialize.OutputFormat r5 = new org.apache.xml.serialize.OutputFormat
            r10 = r5
            r5 = r10
            r6 = r10
            java.lang.String r7 = "xhtml"
            r8 = 0
            r9 = 0
            r6.<init>((java.lang.String) r7, (java.lang.String) r8, (boolean) r9)
            goto L_0x0009
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.XHTMLSerializer.<init>(java.io.OutputStream, org.apache.xml.serialize.OutputFormat):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XHTMLSerializer(java.io.Writer r12, org.apache.xml.serialize.OutputFormat r13) {
        /*
            r11 = this;
            r0 = r11
            r1 = r12
            r2 = r13
            r3 = r0
            r4 = 1
            r5 = r2
            if (r5 == 0) goto L_0x0012
            r5 = r2
        L_0x0009:
            r3.<init>((boolean) r4, (org.apache.xml.serialize.OutputFormat) r5)
            r3 = r0
            r4 = r1
            r3.setOutputCharStream(r4)
            return
        L_0x0012:
            org.apache.xml.serialize.OutputFormat r5 = new org.apache.xml.serialize.OutputFormat
            r10 = r5
            r5 = r10
            r6 = r10
            java.lang.String r7 = "xhtml"
            r8 = 0
            r9 = 0
            r6.<init>((java.lang.String) r7, (java.lang.String) r8, (boolean) r9)
            goto L_0x0009
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.XHTMLSerializer.<init>(java.io.Writer, org.apache.xml.serialize.OutputFormat):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XHTMLSerializer(org.apache.xml.serialize.OutputFormat r11) {
        /*
            r10 = this;
            r0 = r10
            r1 = r11
            r2 = r0
            r3 = 1
            r4 = r1
            if (r4 == 0) goto L_0x000c
            r4 = r1
        L_0x0008:
            r2.<init>((boolean) r3, (org.apache.xml.serialize.OutputFormat) r4)
            return
        L_0x000c:
            org.apache.xml.serialize.OutputFormat r4 = new org.apache.xml.serialize.OutputFormat
            r9 = r4
            r4 = r9
            r5 = r9
            java.lang.String r6 = "xhtml"
            r7 = 0
            r8 = 0
            r5.<init>((java.lang.String) r6, (java.lang.String) r7, (boolean) r8)
            goto L_0x0008
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.XHTMLSerializer.<init>(org.apache.xml.serialize.OutputFormat):void");
    }

    public void setOutputFormat(OutputFormat outputFormat) {
        OutputFormat outputFormat2;
        OutputFormat outputFormat3;
        OutputFormat outputFormat4 = outputFormat;
        if (outputFormat4 != null) {
            outputFormat3 = outputFormat4;
        } else {
            outputFormat3 = outputFormat2;
            new OutputFormat(Method.XHTML, (String) null, false);
        }
        super.setOutputFormat(outputFormat3);
    }
}
