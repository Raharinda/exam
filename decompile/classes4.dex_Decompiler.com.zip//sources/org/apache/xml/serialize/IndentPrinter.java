package org.apache.xml.serialize;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

public class IndentPrinter extends Printer {
    private StringBuffer _line;
    private int _nextIndent;
    private int _spaces = 0;
    private StringBuffer _text;
    private int _thisIndent;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public IndentPrinter(Writer writer, OutputFormat outputFormat) {
        super(writer, outputFormat);
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        new StringBuffer(80);
        this._line = stringBuffer;
        new StringBuffer(20);
        this._text = stringBuffer2;
        this._nextIndent = 0;
        this._thisIndent = 0;
    }

    public void breakLine() {
        breakLine(false);
    }

    public void breakLine(boolean z) {
        StringBuffer stringBuffer;
        boolean z2 = z;
        if (this._text.length() > 0) {
            while (this._spaces > 0) {
                StringBuffer append = this._line.append(' ');
                this._spaces--;
            }
            StringBuffer append2 = this._line.append(this._text);
            new StringBuffer(20);
            this._text = stringBuffer;
        }
        flushLine(z2);
        try {
            this._writer.write(this._format.getLineSeparator());
        } catch (IOException e) {
            IOException iOException = e;
            if (this._exception == null) {
                this._exception = iOException;
            }
        }
    }

    public void enterDTD() {
        StringBuffer stringBuffer;
        StringWriter stringWriter;
        if (this._dtdWriter == null) {
            StringBuffer append = this._line.append(this._text);
            new StringBuffer(20);
            this._text = stringBuffer;
            flushLine(false);
            new StringWriter();
            this._dtdWriter = stringWriter;
            this._docWriter = this._writer;
            this._writer = this._dtdWriter;
        }
    }

    public void flush() {
        if (this._line.length() > 0 || this._text.length() > 0) {
            breakLine();
        }
        try {
            this._writer.flush();
        } catch (IOException e) {
            IOException iOException = e;
            if (this._exception == null) {
                this._exception = iOException;
            }
        }
    }

    public void flushLine(boolean z) {
        StringBuffer stringBuffer;
        boolean z2 = z;
        if (this._line.length() > 0) {
            try {
                if (this._format.getIndenting() && !z2) {
                    int i = this._thisIndent;
                    if (2 * i > this._format.getLineWidth() && this._format.getLineWidth() > 0) {
                        i = this._format.getLineWidth() / 2;
                    }
                    while (i > 0) {
                        this._writer.write(32);
                        i--;
                    }
                }
                this._thisIndent = this._nextIndent;
                this._spaces = 0;
                this._writer.write(this._line.toString());
                new StringBuffer(40);
                this._line = stringBuffer;
            } catch (IOException e) {
                IOException iOException = e;
                if (this._exception == null) {
                    this._exception = iOException;
                }
            }
        }
    }

    public int getNextIndent() {
        return this._nextIndent;
    }

    public void indent() {
        this._nextIndent += this._format.getIndent();
    }

    public String leaveDTD() {
        StringBuffer stringBuffer;
        if (this._writer != this._dtdWriter) {
            return null;
        }
        StringBuffer append = this._line.append(this._text);
        new StringBuffer(20);
        this._text = stringBuffer;
        flushLine(false);
        this._writer = this._docWriter;
        return this._dtdWriter.toString();
    }

    public void printSpace() {
        StringBuffer stringBuffer;
        if (this._text.length() > 0) {
            if (this._format.getLineWidth() > 0 && this._thisIndent + this._line.length() + this._spaces + this._text.length() > this._format.getLineWidth()) {
                flushLine(false);
                try {
                    this._writer.write(this._format.getLineSeparator());
                } catch (IOException e) {
                    IOException iOException = e;
                    if (this._exception == null) {
                        this._exception = iOException;
                    }
                }
            }
            while (this._spaces > 0) {
                StringBuffer append = this._line.append(' ');
                this._spaces--;
            }
            StringBuffer append2 = this._line.append(this._text);
            new StringBuffer(20);
            this._text = stringBuffer;
        }
        this._spaces++;
    }

    public void printText(char c) {
        StringBuffer append = this._text.append(c);
    }

    public void printText(String str) {
        StringBuffer append = this._text.append(str);
    }

    public void printText(StringBuffer stringBuffer) {
        StringBuffer append = this._text.append(stringBuffer.toString());
    }

    public void printText(char[] cArr, int i, int i2) {
        StringBuffer append = this._text.append(cArr, i, i2);
    }

    public void setNextIndent(int i) {
        int i2 = i;
        this._nextIndent = i2;
    }

    public void setThisIndent(int i) {
        int i2 = i;
        this._thisIndent = i2;
    }

    public void unindent() {
        this._nextIndent -= this._format.getIndent();
        if (this._nextIndent < 0) {
            this._nextIndent = 0;
        }
        if (this._line.length() + this._spaces + this._text.length() == 0) {
            this._thisIndent = this._nextIndent;
        }
    }
}
