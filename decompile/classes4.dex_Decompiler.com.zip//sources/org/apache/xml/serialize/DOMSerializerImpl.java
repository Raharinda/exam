package org.apache.xml.serialize;

import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.lang.reflect.Method;
import java.util.ArrayList;
import net.lingala.zip4j.util.Zip4jConstants;
import org.apache.xerces.dom.CoreDocumentImpl;
import org.apache.xerces.dom.DOMErrorImpl;
import org.apache.xerces.dom.DOMLocatorImpl;
import org.apache.xerces.dom.DOMMessageFormatter;
import org.apache.xerces.dom.DOMNormalizer;
import org.apache.xerces.dom.DOMStringListImpl;
import org.apache.xerces.impl.XMLEntityManager;
import org.apache.xerces.util.DOMUtil;
import org.apache.xerces.util.NamespaceSupport;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.util.XML11Char;
import org.apache.xerces.util.XMLChar;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.DOMConfiguration;
import org.w3c.dom.DOMErrorHandler;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMStringList;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.ls.LSException;
import org.w3c.dom.ls.LSOutput;
import org.w3c.dom.ls.LSSerializer;
import org.w3c.dom.ls.LSSerializerFilter;

public class DOMSerializerImpl implements LSSerializer, DOMConfiguration {
    protected static final short CDATA = 8;
    protected static final short COMMENTS = 32;
    protected static final short DISCARDDEFAULT = 64;
    protected static final short DOM_ELEMENT_CONTENT_WHITESPACE = 1024;
    protected static final short ENTITIES = 4;
    protected static final short INFOSET = 128;
    protected static final short NAMESPACES = 1;
    protected static final short NSDECL = 512;
    protected static final short PRETTY_PRINT = 2048;
    protected static final short SPLITCDATA = 16;
    protected static final short WELLFORMED = 2;
    protected static final short XMLDECL = 256;
    private final DOMErrorImpl fError;
    private DOMErrorHandler fErrorHandler = null;
    private final DOMLocatorImpl fLocator;
    private DOMStringList fRecognizedParameters;
    protected short features = 0;
    private XMLSerializer serializer;
    private XML11Serializer xml11Serializer;

    static class DocumentMethods {
        static Class class$org$w3c$dom$Document;
        private static Method fgDocumentGetInputEncodingMethod;
        private static Method fgDocumentGetXmlEncodingMethod;
        private static Method fgDocumentGetXmlVersionMethod;
        private static boolean fgDocumentMethodsAvailable;

        static {
            Class cls;
            Class cls2;
            Class cls3;
            fgDocumentGetXmlVersionMethod = null;
            fgDocumentGetInputEncodingMethod = null;
            fgDocumentGetXmlEncodingMethod = null;
            fgDocumentMethodsAvailable = false;
            try {
                if (class$org$w3c$dom$Document == null) {
                    Class class$ = class$("org.w3c.dom.Document");
                    cls = class$;
                    class$org$w3c$dom$Document = class$;
                } else {
                    cls = class$org$w3c$dom$Document;
                }
                fgDocumentGetXmlVersionMethod = cls.getMethod("getXmlVersion", new Class[0]);
                if (class$org$w3c$dom$Document == null) {
                    Class class$2 = class$("org.w3c.dom.Document");
                    cls2 = class$2;
                    class$org$w3c$dom$Document = class$2;
                } else {
                    cls2 = class$org$w3c$dom$Document;
                }
                fgDocumentGetInputEncodingMethod = cls2.getMethod("getInputEncoding", new Class[0]);
                if (class$org$w3c$dom$Document == null) {
                    Class class$3 = class$("org.w3c.dom.Document");
                    cls3 = class$3;
                    class$org$w3c$dom$Document = class$3;
                } else {
                    cls3 = class$org$w3c$dom$Document;
                }
                fgDocumentGetXmlEncodingMethod = cls3.getMethod("getXmlEncoding", new Class[0]);
                fgDocumentMethodsAvailable = true;
            } catch (Exception e) {
                Exception exc = e;
                fgDocumentGetXmlVersionMethod = null;
                fgDocumentGetInputEncodingMethod = null;
                fgDocumentGetXmlEncodingMethod = null;
                fgDocumentMethodsAvailable = false;
            }
        }

        private DocumentMethods() {
        }

        static boolean access$000() {
            return fgDocumentMethodsAvailable;
        }

        static Method access$100() {
            return fgDocumentGetXmlVersionMethod;
        }

        static Method access$200() {
            return fgDocumentGetInputEncodingMethod;
        }

        static Method access$300() {
            return fgDocumentGetXmlEncodingMethod;
        }

        static Class class$(String str) {
            Throwable th;
            try {
                return Class.forName(str);
            } catch (ClassNotFoundException e) {
                ClassNotFoundException classNotFoundException = e;
                Throwable th2 = th;
                new NoClassDefFoundError(classNotFoundException.getMessage());
                throw th2;
            }
        }
    }

    public DOMSerializerImpl() {
        DOMErrorImpl dOMErrorImpl;
        DOMLocatorImpl dOMLocatorImpl;
        XMLSerializer xMLSerializer;
        new DOMErrorImpl();
        this.fError = dOMErrorImpl;
        new DOMLocatorImpl();
        this.fLocator = dOMLocatorImpl;
        this.features = (short) (this.features | 1);
        this.features = (short) (this.features | 4);
        this.features = (short) (this.features | 32);
        this.features = (short) (this.features | 8);
        this.features = (short) (this.features | 16);
        this.features = (short) (this.features | 2);
        this.features = (short) (this.features | 512);
        this.features = (short) (this.features | 1024);
        this.features = (short) (this.features | 64);
        this.features = (short) (this.features | 256);
        new XMLSerializer();
        this.serializer = xMLSerializer;
        initSerializer(this.serializer);
    }

    private String _getInputEncoding(Node node) {
        Node node2 = node;
        Document ownerDocument = node2.getNodeType() == 9 ? (Document) node2 : node2.getOwnerDocument();
        if (ownerDocument != null && DocumentMethods.access$000()) {
            try {
                return (String) DocumentMethods.access$200().invoke(ownerDocument, (Object[]) null);
            } catch (VirtualMachineError e) {
                throw e;
            } catch (ThreadDeath e2) {
                throw e2;
            } catch (Throwable th) {
                Throwable th2 = th;
            }
        }
        return null;
    }

    private String _getXmlEncoding(Node node) {
        Node node2 = node;
        Document ownerDocument = node2.getNodeType() == 9 ? (Document) node2 : node2.getOwnerDocument();
        if (ownerDocument != null && DocumentMethods.access$000()) {
            try {
                return (String) DocumentMethods.access$300().invoke(ownerDocument, (Object[]) null);
            } catch (VirtualMachineError e) {
                throw e;
            } catch (ThreadDeath e2) {
                throw e2;
            } catch (Throwable th) {
                Throwable th2 = th;
            }
        }
        return null;
    }

    private String _getXmlVersion(Node node) {
        Node node2 = node;
        Document ownerDocument = node2.getNodeType() == 9 ? (Document) node2 : node2.getOwnerDocument();
        if (ownerDocument != null && DocumentMethods.access$000()) {
            try {
                return (String) DocumentMethods.access$100().invoke(ownerDocument, (Object[]) null);
            } catch (VirtualMachineError e) {
                throw e;
            } catch (ThreadDeath e2) {
                throw e2;
            } catch (Throwable th) {
                Throwable th2 = th;
            }
        }
        return null;
    }

    private void copySettings(XMLSerializer xMLSerializer, XMLSerializer xMLSerializer2) {
        XMLSerializer xMLSerializer3 = xMLSerializer;
        XMLSerializer xMLSerializer4 = xMLSerializer2;
        xMLSerializer4.fDOMErrorHandler = this.fErrorHandler;
        xMLSerializer4._format.setEncoding(xMLSerializer3._format.getEncoding());
        xMLSerializer4._format.setLineSeparator(xMLSerializer3._format.getLineSeparator());
        xMLSerializer4.fDOMFilter = xMLSerializer3.fDOMFilter;
    }

    private void initSerializer(XMLSerializer xMLSerializer) {
        NamespaceSupport namespaceSupport;
        NamespaceSupport namespaceSupport2;
        SymbolTable symbolTable;
        XMLSerializer xMLSerializer2 = xMLSerializer;
        new NamespaceSupport();
        xMLSerializer2.fNSBinder = namespaceSupport;
        new NamespaceSupport();
        xMLSerializer2.fLocalNSBinder = namespaceSupport2;
        new SymbolTable();
        xMLSerializer2.fSymbolTable = symbolTable;
    }

    private void prepareForSerialization(XMLSerializer xMLSerializer, Node node) {
        XMLSerializer xMLSerializer2 = xMLSerializer;
        Node node2 = node;
        boolean reset = xMLSerializer2.reset();
        xMLSerializer2.features = this.features;
        xMLSerializer2.fDOMErrorHandler = this.fErrorHandler;
        xMLSerializer2.fNamespaces = (this.features & 1) != 0;
        xMLSerializer2.fNamespacePrefixes = (this.features & 512) != 0;
        xMLSerializer2._format.setIndenting((this.features & 2048) != 0);
        xMLSerializer2._format.setOmitComments((this.features & 32) == 0);
        xMLSerializer2._format.setOmitXMLDeclaration((this.features & 256) == 0);
        if ((this.features & 2) != 0) {
            Node node3 = node2;
            boolean z = true;
            Document ownerDocument = node2.getNodeType() == 9 ? (Document) node2 : node2.getOwnerDocument();
            try {
                Method method = ownerDocument.getClass().getMethod("isXMLVersionChanged()", new Class[0]);
                if (method != null) {
                    z = ((Boolean) method.invoke(ownerDocument, (Object[]) null)).booleanValue();
                }
            } catch (Exception e) {
                Exception exc = e;
            }
            if (node2.getFirstChild() != null) {
                while (node2 != null) {
                    verify(node2, z, false);
                    Node firstChild = node2.getFirstChild();
                    while (true) {
                        if (firstChild != null) {
                            break;
                        }
                        firstChild = node2.getNextSibling();
                        if (firstChild == null) {
                            node2 = node2.getParentNode();
                            if (node3 == node2) {
                                firstChild = null;
                                break;
                            }
                            firstChild = node2.getNextSibling();
                        }
                    }
                    node2 = firstChild;
                }
                return;
            }
            verify(node2, z, false);
        }
    }

    private void verify(Node node, boolean z, boolean z2) {
        Node node2 = node;
        boolean z3 = z;
        boolean z4 = z2;
        short nodeType = node2.getNodeType();
        this.fLocator.fRelatedNode = node2;
        switch (nodeType) {
            case 1:
                if (z3) {
                    if (!((this.features & 1) != 0 ? CoreDocumentImpl.isValidQName(node2.getPrefix(), node2.getLocalName(), z4) : CoreDocumentImpl.isXMLName(node2.getNodeName(), z4)) && this.fErrorHandler != null) {
                        Object[] objArr = new Object[2];
                        objArr[0] = "Element";
                        Object[] objArr2 = objArr;
                        objArr2[1] = node2.getNodeName();
                        DOMNormalizer.reportDOMError(this.fErrorHandler, this.fError, this.fLocator, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "wf-invalid-character-in-node-name", objArr2), 3, "wf-invalid-character-in-node-name");
                    }
                }
                NamedNodeMap attributes = node2.hasAttributes() ? node2.getAttributes() : null;
                if (attributes != null) {
                    for (int i = 0; i < attributes.getLength(); i++) {
                        Attr attr = (Attr) attributes.item(i);
                        this.fLocator.fRelatedNode = attr;
                        DOMNormalizer.isAttrValueWF(this.fErrorHandler, this.fError, this.fLocator, attributes, attr, attr.getValue(), z4);
                        if (z3 && !CoreDocumentImpl.isXMLName(attr.getNodeName(), z4)) {
                            Object[] objArr3 = new Object[2];
                            objArr3[0] = "Attr";
                            Object[] objArr4 = objArr3;
                            objArr4[1] = node2.getNodeName();
                            DOMNormalizer.reportDOMError(this.fErrorHandler, this.fError, this.fLocator, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "wf-invalid-character-in-node-name", objArr4), 3, "wf-invalid-character-in-node-name");
                        }
                    }
                    break;
                }
                break;
            case 3:
                DOMNormalizer.isXMLCharWF(this.fErrorHandler, this.fError, this.fLocator, node2.getNodeValue(), z4);
                break;
            case 4:
                DOMNormalizer.isXMLCharWF(this.fErrorHandler, this.fError, this.fLocator, node2.getNodeValue(), z4);
                break;
            case 5:
                if (z3 && (this.features & 4) != 0) {
                    boolean isXMLName = CoreDocumentImpl.isXMLName(node2.getNodeName(), z4);
                    break;
                }
            case Zip4jConstants.DEFLATE_LEVEL_MAXIMUM:
                ProcessingInstruction processingInstruction = (ProcessingInstruction) node2;
                String target = processingInstruction.getTarget();
                if (z3) {
                    if (!(z4 ? XML11Char.isXML11ValidName(target) : XMLChar.isValidName(target))) {
                        Object[] objArr5 = new Object[2];
                        objArr5[0] = "Element";
                        Object[] objArr6 = objArr5;
                        objArr6[1] = node2.getNodeName();
                        DOMNormalizer.reportDOMError(this.fErrorHandler, this.fError, this.fLocator, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "wf-invalid-character-in-node-name", objArr6), 3, "wf-invalid-character-in-node-name");
                    }
                }
                DOMNormalizer.isXMLCharWF(this.fErrorHandler, this.fError, this.fLocator, processingInstruction.getData(), z4);
                break;
            case 8:
                if ((this.features & 32) != 0) {
                    DOMNormalizer.isCommentWF(this.fErrorHandler, this.fError, this.fLocator, ((Comment) node2).getData(), z4);
                    break;
                }
                break;
        }
        this.fLocator.fRelatedNode = null;
    }

    public boolean canSetParameter(String str, Object obj) {
        String str2 = str;
        Object obj2 = obj;
        if (obj2 == null) {
            return true;
        }
        if (obj2 instanceof Boolean) {
            boolean booleanValue = ((Boolean) obj2).booleanValue();
            if (str2.equalsIgnoreCase("namespaces") || str2.equalsIgnoreCase("split-cdata-sections") || str2.equalsIgnoreCase("discard-default-content") || str2.equalsIgnoreCase("xml-declaration") || str2.equalsIgnoreCase("well-formed") || str2.equalsIgnoreCase("infoset") || str2.equalsIgnoreCase("entities") || str2.equalsIgnoreCase("cdata-sections") || str2.equalsIgnoreCase("comments") || str2.equalsIgnoreCase("format-pretty-print") || str2.equalsIgnoreCase("namespace-declarations")) {
                return true;
            }
            if (str2.equalsIgnoreCase("canonical-form") || str2.equalsIgnoreCase("validate-if-schema") || str2.equalsIgnoreCase("validate") || str2.equalsIgnoreCase("check-character-normalization") || str2.equalsIgnoreCase("datatype-normalization") || str2.equalsIgnoreCase("normalize-characters")) {
                return !booleanValue;
            } else if (str2.equalsIgnoreCase("element-content-whitespace") || str2.equalsIgnoreCase("ignore-unknown-character-denormalizations")) {
                return booleanValue;
            }
        } else if ((str2.equalsIgnoreCase("error-handler") && obj2 == null) || (obj2 instanceof DOMErrorHandler)) {
            return true;
        }
        return false;
    }

    public DOMConfiguration getDomConfig() {
        return this;
    }

    public LSSerializerFilter getFilter() {
        return this.serializer.fDOMFilter;
    }

    public String getNewLine() {
        return this.serializer._format.getLineSeparator();
    }

    public Object getParameter(String str) throws DOMException {
        Throwable th;
        Throwable th2;
        String str2 = str;
        if (str2.equalsIgnoreCase("comments")) {
            return (this.features & 32) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("namespaces")) {
            return (this.features & 1) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("xml-declaration")) {
            return (this.features & 256) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("cdata-sections")) {
            return (this.features & 8) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("entities")) {
            return (this.features & 4) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("split-cdata-sections")) {
            return (this.features & 16) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("well-formed")) {
            return (this.features & 2) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("namespace-declarations")) {
            return (this.features & 512) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("element-content-whitespace") || str2.equalsIgnoreCase("ignore-unknown-character-denormalizations")) {
            return Boolean.TRUE;
        } else {
            if (str2.equalsIgnoreCase("discard-default-content")) {
                return (this.features & 64) != 0 ? Boolean.TRUE : Boolean.FALSE;
            } else if (str2.equalsIgnoreCase("format-pretty-print")) {
                return (this.features & 2048) != 0 ? Boolean.TRUE : Boolean.FALSE;
            } else if (str2.equalsIgnoreCase("infoset")) {
                return ((this.features & 4) != 0 || (this.features & 8) != 0 || (this.features & 1) == 0 || (this.features & 512) == 0 || (this.features & 2) == 0 || (this.features & 32) == 0) ? Boolean.FALSE : Boolean.TRUE;
            } else {
                if (str2.equalsIgnoreCase("normalize-characters") || str2.equalsIgnoreCase("canonical-form") || str2.equalsIgnoreCase("validate-if-schema") || str2.equalsIgnoreCase("check-character-normalization") || str2.equalsIgnoreCase("validate") || str2.equalsIgnoreCase("validate-if-schema") || str2.equalsIgnoreCase("datatype-normalization")) {
                    return Boolean.FALSE;
                }
                if (str2.equalsIgnoreCase("error-handler")) {
                    return this.fErrorHandler;
                }
                if (str2.equalsIgnoreCase("resource-resolver") || str2.equalsIgnoreCase("schema-location") || str2.equalsIgnoreCase("schema-type")) {
                    Throwable th3 = th;
                    new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "FEATURE_NOT_SUPPORTED", new Object[]{str2}));
                    throw th3;
                }
                Throwable th4 = th2;
                new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "FEATURE_NOT_FOUND", new Object[]{str2}));
                throw th4;
            }
        }
    }

    public DOMStringList getParameterNames() {
        ArrayList arrayList;
        DOMStringList dOMStringList;
        if (this.fRecognizedParameters == null) {
            new ArrayList();
            ArrayList arrayList2 = arrayList;
            boolean add = arrayList2.add("namespaces");
            boolean add2 = arrayList2.add("split-cdata-sections");
            boolean add3 = arrayList2.add("discard-default-content");
            boolean add4 = arrayList2.add("xml-declaration");
            boolean add5 = arrayList2.add("canonical-form");
            boolean add6 = arrayList2.add("validate-if-schema");
            boolean add7 = arrayList2.add("validate");
            boolean add8 = arrayList2.add("check-character-normalization");
            boolean add9 = arrayList2.add("datatype-normalization");
            boolean add10 = arrayList2.add("format-pretty-print");
            boolean add11 = arrayList2.add("normalize-characters");
            boolean add12 = arrayList2.add("well-formed");
            boolean add13 = arrayList2.add("infoset");
            boolean add14 = arrayList2.add("namespace-declarations");
            boolean add15 = arrayList2.add("element-content-whitespace");
            boolean add16 = arrayList2.add("entities");
            boolean add17 = arrayList2.add("cdata-sections");
            boolean add18 = arrayList2.add("comments");
            boolean add19 = arrayList2.add("ignore-unknown-character-denormalizations");
            boolean add20 = arrayList2.add("error-handler");
            new DOMStringListImpl(arrayList2);
            this.fRecognizedParameters = dOMStringList;
        }
        return this.fRecognizedParameters;
    }

    public void setFilter(LSSerializerFilter lSSerializerFilter) {
        LSSerializerFilter lSSerializerFilter2 = lSSerializerFilter;
        this.serializer.fDOMFilter = lSSerializerFilter2;
    }

    public void setNewLine(String str) {
        this.serializer._format.setLineSeparator(str);
    }

    public void setParameter(String str, Object obj) throws DOMException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        Throwable th6;
        String str2 = str;
        Object obj2 = obj;
        if (obj2 instanceof Boolean) {
            boolean booleanValue = ((Boolean) obj2).booleanValue();
            if (str2.equalsIgnoreCase("infoset")) {
                if (booleanValue) {
                    this.features = (short) (this.features & -5);
                    this.features = (short) (this.features & -9);
                    this.features = (short) (this.features | 1);
                    this.features = (short) (this.features | 512);
                    this.features = (short) (this.features | 2);
                    this.features = (short) (this.features | 32);
                }
            } else if (str2.equalsIgnoreCase("xml-declaration")) {
                this.features = booleanValue ? (short) (this.features | 256) : (short) (this.features & -257);
            } else if (str2.equalsIgnoreCase("namespaces")) {
                this.features = booleanValue ? (short) (this.features | 1) : (short) (this.features & -2);
                this.serializer.fNamespaces = booleanValue;
            } else if (str2.equalsIgnoreCase("split-cdata-sections")) {
                this.features = booleanValue ? (short) (this.features | 16) : (short) (this.features & -17);
            } else if (str2.equalsIgnoreCase("discard-default-content")) {
                this.features = booleanValue ? (short) (this.features | 64) : (short) (this.features & -65);
            } else if (str2.equalsIgnoreCase("well-formed")) {
                this.features = booleanValue ? (short) (this.features | 2) : (short) (this.features & -3);
            } else if (str2.equalsIgnoreCase("entities")) {
                this.features = booleanValue ? (short) (this.features | 4) : (short) (this.features & -5);
            } else if (str2.equalsIgnoreCase("cdata-sections")) {
                this.features = booleanValue ? (short) (this.features | 8) : (short) (this.features & -9);
            } else if (str2.equalsIgnoreCase("comments")) {
                this.features = booleanValue ? (short) (this.features | 32) : (short) (this.features & -33);
            } else if (str2.equalsIgnoreCase("format-pretty-print")) {
                this.features = booleanValue ? (short) (this.features | 2048) : (short) (this.features & -2049);
            } else if (str2.equalsIgnoreCase("canonical-form") || str2.equalsIgnoreCase("validate-if-schema") || str2.equalsIgnoreCase("validate") || str2.equalsIgnoreCase("check-character-normalization") || str2.equalsIgnoreCase("datatype-normalization") || str2.equalsIgnoreCase("normalize-characters")) {
                if (booleanValue) {
                    Throwable th7 = th4;
                    new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "FEATURE_NOT_SUPPORTED", new Object[]{str2}));
                    throw th7;
                }
            } else if (str2.equalsIgnoreCase("namespace-declarations")) {
                this.features = booleanValue ? (short) (this.features | 512) : (short) (this.features & -513);
                this.serializer.fNamespacePrefixes = booleanValue;
            } else if (!str2.equalsIgnoreCase("element-content-whitespace") && !str2.equalsIgnoreCase("ignore-unknown-character-denormalizations")) {
                Throwable th8 = th6;
                new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "FEATURE_NOT_FOUND", new Object[]{str2}));
                throw th8;
            } else if (!booleanValue) {
                Throwable th9 = th5;
                new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "FEATURE_NOT_SUPPORTED", new Object[]{str2}));
                throw th9;
            }
        } else if (str2.equalsIgnoreCase("error-handler")) {
            if (obj2 == null || (obj2 instanceof DOMErrorHandler)) {
                this.fErrorHandler = (DOMErrorHandler) obj2;
                return;
            }
            Throwable th10 = th3;
            new DOMException(17, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "TYPE_MISMATCH_ERR", new Object[]{str2}));
            throw th10;
        } else if (str2.equalsIgnoreCase("resource-resolver") || str2.equalsIgnoreCase("schema-location") || (str2.equalsIgnoreCase("schema-type") && obj2 != null)) {
            Throwable th11 = th;
            new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "FEATURE_NOT_SUPPORTED", new Object[]{str2}));
            throw th11;
        } else {
            Throwable th12 = th2;
            new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "FEATURE_NOT_FOUND", new Object[]{str2}));
            throw th12;
        }
    }

    public boolean write(Node node, LSOutput lSOutput) throws LSException {
        XML11Serializer xML11Serializer;
        DOMErrorImpl dOMErrorImpl;
        Throwable th;
        DOMErrorImpl dOMErrorImpl2;
        Throwable th2;
        DOMErrorImpl dOMErrorImpl3;
        XML11Serializer xML11Serializer2;
        Node node2 = node;
        LSOutput lSOutput2 = lSOutput;
        if (node2 == null) {
            return false;
        }
        String _getXmlVersion = _getXmlVersion(node2);
        if (_getXmlVersion == null || !_getXmlVersion.equals("1.1")) {
            xML11Serializer = this.serializer;
        } else {
            if (this.xml11Serializer == null) {
                new XML11Serializer();
                this.xml11Serializer = xML11Serializer2;
                initSerializer(this.xml11Serializer);
            }
            copySettings(this.serializer, this.xml11Serializer);
            xML11Serializer = this.xml11Serializer;
        }
        String encoding = lSOutput2.getEncoding();
        String str = encoding;
        if (encoding == null) {
            str = _getInputEncoding(node2);
            if (str == null) {
                str = _getXmlEncoding(node2);
                if (str == null) {
                    str = "UTF-8";
                }
            }
        }
        try {
            prepareForSerialization(xML11Serializer, node2);
            xML11Serializer._format.setEncoding(str);
            OutputStream byteStream = lSOutput2.getByteStream();
            Writer characterStream = lSOutput2.getCharacterStream();
            String systemId = lSOutput2.getSystemId();
            if (characterStream != null) {
                xML11Serializer.setOutputCharStream(characterStream);
            } else if (byteStream != null) {
                xML11Serializer.setOutputByteStream(byteStream);
            } else if (systemId == null) {
                String formatMessage = DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "no-output-specified", (Object[]) null);
                if (xML11Serializer.fDOMErrorHandler != null) {
                    new DOMErrorImpl();
                    DOMErrorImpl dOMErrorImpl4 = dOMErrorImpl3;
                    dOMErrorImpl4.fType = "no-output-specified";
                    dOMErrorImpl4.fMessage = formatMessage;
                    dOMErrorImpl4.fSeverity = 3;
                    boolean handleError = xML11Serializer.fDOMErrorHandler.handleError(dOMErrorImpl4);
                }
                Throwable th3 = th2;
                new LSException(82, formatMessage);
                throw th3;
            } else {
                xML11Serializer.setOutputByteStream(XMLEntityManager.createOutputStream(systemId));
            }
            if (node2.getNodeType() == 9) {
                xML11Serializer.serialize((Document) node2);
            } else if (node2.getNodeType() == 11) {
                xML11Serializer.serialize((DocumentFragment) node2);
            } else if (node2.getNodeType() == 1) {
                xML11Serializer.serialize((Element) node2);
            } else {
                xML11Serializer.clearDocumentState();
                return false;
            }
            xML11Serializer.clearDocumentState();
            return true;
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException unsupportedEncodingException = e;
            if (xML11Serializer.fDOMErrorHandler != null) {
                new DOMErrorImpl();
                DOMErrorImpl dOMErrorImpl5 = dOMErrorImpl2;
                dOMErrorImpl5.fException = unsupportedEncodingException;
                dOMErrorImpl5.fType = "unsupported-encoding";
                dOMErrorImpl5.fMessage = unsupportedEncodingException.getMessage();
                dOMErrorImpl5.fSeverity = 3;
                boolean handleError2 = xML11Serializer.fDOMErrorHandler.handleError(dOMErrorImpl5);
            }
            Throwable th4 = th;
            new LSException(82, DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "unsupported-encoding", (Object[]) null));
            throw th4;
        } catch (LSException e2) {
            throw e2;
        } catch (RuntimeException e3) {
            RuntimeException runtimeException = e3;
            if (runtimeException == DOMNormalizer.abort) {
                xML11Serializer.clearDocumentState();
                return false;
            }
            throw ((LSException) DOMUtil.createLSException(82, runtimeException).fillInStackTrace());
        } catch (Exception e4) {
            Exception exc = e4;
            if (xML11Serializer.fDOMErrorHandler != null) {
                new DOMErrorImpl();
                DOMErrorImpl dOMErrorImpl6 = dOMErrorImpl;
                dOMErrorImpl6.fException = exc;
                dOMErrorImpl6.fMessage = exc.getMessage();
                dOMErrorImpl6.fSeverity = 2;
                boolean handleError3 = xML11Serializer.fDOMErrorHandler.handleError(dOMErrorImpl6);
            }
            throw ((LSException) DOMUtil.createLSException(82, exc).fillInStackTrace());
        } catch (Throwable th5) {
            Throwable th6 = th5;
            xML11Serializer.clearDocumentState();
            throw th6;
        }
    }

    public String writeToString(Node node) throws DOMException, LSException {
        XML11Serializer xML11Serializer;
        StringWriter stringWriter;
        Throwable th;
        Throwable th2;
        DOMErrorImpl dOMErrorImpl;
        XML11Serializer xML11Serializer2;
        Node node2 = node;
        String _getXmlVersion = _getXmlVersion(node2);
        if (_getXmlVersion == null || !_getXmlVersion.equals("1.1")) {
            xML11Serializer = this.serializer;
        } else {
            if (this.xml11Serializer == null) {
                new XML11Serializer();
                this.xml11Serializer = xML11Serializer2;
                initSerializer(this.xml11Serializer);
            }
            copySettings(this.serializer, this.xml11Serializer);
            xML11Serializer = this.xml11Serializer;
        }
        new StringWriter();
        StringWriter stringWriter2 = stringWriter;
        try {
            prepareForSerialization(xML11Serializer, node2);
            xML11Serializer._format.setEncoding("UTF-16");
            xML11Serializer.setOutputCharStream(stringWriter2);
            if (node2.getNodeType() == 9) {
                xML11Serializer.serialize((Document) node2);
            } else if (node2.getNodeType() == 11) {
                xML11Serializer.serialize((DocumentFragment) node2);
            } else if (node2.getNodeType() == 1) {
                xML11Serializer.serialize((Element) node2);
            } else {
                String formatMessage = DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "unable-to-serialize-node", (Object[]) null);
                if (xML11Serializer.fDOMErrorHandler != null) {
                    new DOMErrorImpl();
                    DOMErrorImpl dOMErrorImpl2 = dOMErrorImpl;
                    dOMErrorImpl2.fType = "unable-to-serialize-node";
                    dOMErrorImpl2.fMessage = formatMessage;
                    dOMErrorImpl2.fSeverity = 3;
                    boolean handleError = xML11Serializer.fDOMErrorHandler.handleError(dOMErrorImpl2);
                }
                Throwable th3 = th2;
                new LSException(82, formatMessage);
                throw th3;
            }
            xML11Serializer.clearDocumentState();
            return stringWriter2.toString();
        } catch (LSException e) {
            throw e;
        } catch (RuntimeException e2) {
            RuntimeException runtimeException = e2;
            if (runtimeException == DOMNormalizer.abort) {
                xML11Serializer.clearDocumentState();
                return null;
            }
            throw ((LSException) DOMUtil.createLSException(82, runtimeException).fillInStackTrace());
        } catch (IOException e3) {
            Throwable th4 = th;
            new DOMException(2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "STRING_TOO_LONG", new Object[]{e3.getMessage()}));
            throw th4;
        } catch (Throwable th5) {
            Throwable th6 = th5;
            xML11Serializer.clearDocumentState();
            throw th6;
        }
    }

    public boolean writeToURI(Node node, String str) throws LSException {
        XML11Serializer xML11Serializer;
        DOMErrorImpl dOMErrorImpl;
        XML11Serializer xML11Serializer2;
        Node node2 = node;
        String str2 = str;
        if (node2 == null) {
            return false;
        }
        String _getXmlVersion = _getXmlVersion(node2);
        if (_getXmlVersion == null || !_getXmlVersion.equals("1.1")) {
            xML11Serializer = this.serializer;
        } else {
            if (this.xml11Serializer == null) {
                new XML11Serializer();
                this.xml11Serializer = xML11Serializer2;
                initSerializer(this.xml11Serializer);
            }
            copySettings(this.serializer, this.xml11Serializer);
            xML11Serializer = this.xml11Serializer;
        }
        String _getInputEncoding = _getInputEncoding(node2);
        if (_getInputEncoding == null) {
            _getInputEncoding = _getXmlEncoding(node2);
            if (_getInputEncoding == null) {
                _getInputEncoding = "UTF-8";
            }
        }
        try {
            prepareForSerialization(xML11Serializer, node2);
            xML11Serializer._format.setEncoding(_getInputEncoding);
            xML11Serializer.setOutputByteStream(XMLEntityManager.createOutputStream(str2));
            if (node2.getNodeType() == 9) {
                xML11Serializer.serialize((Document) node2);
            } else if (node2.getNodeType() == 11) {
                xML11Serializer.serialize((DocumentFragment) node2);
            } else if (node2.getNodeType() == 1) {
                xML11Serializer.serialize((Element) node2);
            } else {
                xML11Serializer.clearDocumentState();
                return false;
            }
            xML11Serializer.clearDocumentState();
            return true;
        } catch (LSException e) {
            throw e;
        } catch (RuntimeException e2) {
            RuntimeException runtimeException = e2;
            if (runtimeException == DOMNormalizer.abort) {
                xML11Serializer.clearDocumentState();
                return false;
            }
            throw ((LSException) DOMUtil.createLSException(82, runtimeException).fillInStackTrace());
        } catch (Exception e3) {
            Exception exc = e3;
            if (xML11Serializer.fDOMErrorHandler != null) {
                new DOMErrorImpl();
                DOMErrorImpl dOMErrorImpl2 = dOMErrorImpl;
                dOMErrorImpl2.fException = exc;
                dOMErrorImpl2.fMessage = exc.getMessage();
                dOMErrorImpl2.fSeverity = 2;
                boolean handleError = xML11Serializer.fDOMErrorHandler.handleError(dOMErrorImpl2);
            }
            throw ((LSException) DOMUtil.createLSException(82, exc).fillInStackTrace());
        } catch (Throwable th) {
            Throwable th2 = th;
            xML11Serializer.clearDocumentState();
            throw th2;
        }
    }
}
