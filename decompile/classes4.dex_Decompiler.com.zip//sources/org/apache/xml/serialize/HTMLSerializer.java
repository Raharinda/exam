package org.apache.xml.serialize;

import java.io.IOException;
import java.util.Locale;
import org.apache.xerces.dom.DOMMessageFormatter;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.AttributeList;
import org.xml.sax.SAXException;

public class HTMLSerializer extends BaseMarkupSerializer {
    public static final String XHTMLNamespace = "http://www.w3.org/1999/xhtml";
    private boolean _xhtml;
    private String fUserXHTMLNamespace;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public HTMLSerializer() {
        /*
            r9 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            org.apache.xml.serialize.OutputFormat r3 = new org.apache.xml.serialize.OutputFormat
            r8 = r3
            r3 = r8
            r4 = r8
            java.lang.String r5 = "html"
            java.lang.String r6 = "ISO-8859-1"
            r7 = 0
            r4.<init>((java.lang.String) r5, (java.lang.String) r6, (boolean) r7)
            r1.<init>((boolean) r2, (org.apache.xml.serialize.OutputFormat) r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.HTMLSerializer.<init>():void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public HTMLSerializer(java.io.OutputStream r12, org.apache.xml.serialize.OutputFormat r13) {
        /*
            r11 = this;
            r0 = r11
            r1 = r12
            r2 = r13
            r3 = r0
            r4 = 0
            r5 = r2
            if (r5 == 0) goto L_0x0012
            r5 = r2
        L_0x0009:
            r3.<init>((boolean) r4, (org.apache.xml.serialize.OutputFormat) r5)
            r3 = r0
            r4 = r1
            r3.setOutputByteStream(r4)
            return
        L_0x0012:
            org.apache.xml.serialize.OutputFormat r5 = new org.apache.xml.serialize.OutputFormat
            r10 = r5
            r5 = r10
            r6 = r10
            java.lang.String r7 = "html"
            java.lang.String r8 = "ISO-8859-1"
            r9 = 0
            r6.<init>((java.lang.String) r7, (java.lang.String) r8, (boolean) r9)
            goto L_0x0009
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.HTMLSerializer.<init>(java.io.OutputStream, org.apache.xml.serialize.OutputFormat):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public HTMLSerializer(java.io.Writer r12, org.apache.xml.serialize.OutputFormat r13) {
        /*
            r11 = this;
            r0 = r11
            r1 = r12
            r2 = r13
            r3 = r0
            r4 = 0
            r5 = r2
            if (r5 == 0) goto L_0x0012
            r5 = r2
        L_0x0009:
            r3.<init>((boolean) r4, (org.apache.xml.serialize.OutputFormat) r5)
            r3 = r0
            r4 = r1
            r3.setOutputCharStream(r4)
            return
        L_0x0012:
            org.apache.xml.serialize.OutputFormat r5 = new org.apache.xml.serialize.OutputFormat
            r10 = r5
            r5 = r10
            r6 = r10
            java.lang.String r7 = "html"
            java.lang.String r8 = "ISO-8859-1"
            r9 = 0
            r6.<init>((java.lang.String) r7, (java.lang.String) r8, (boolean) r9)
            goto L_0x0009
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.HTMLSerializer.<init>(java.io.Writer, org.apache.xml.serialize.OutputFormat):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public HTMLSerializer(org.apache.xml.serialize.OutputFormat r11) {
        /*
            r10 = this;
            r0 = r10
            r1 = r11
            r2 = r0
            r3 = 0
            r4 = r1
            if (r4 == 0) goto L_0x000c
            r4 = r1
        L_0x0008:
            r2.<init>((boolean) r3, (org.apache.xml.serialize.OutputFormat) r4)
            return
        L_0x000c:
            org.apache.xml.serialize.OutputFormat r4 = new org.apache.xml.serialize.OutputFormat
            r9 = r4
            r4 = r9
            r5 = r9
            java.lang.String r6 = "html"
            java.lang.String r7 = "ISO-8859-1"
            r8 = 0
            r5.<init>((java.lang.String) r6, (java.lang.String) r7, (boolean) r8)
            goto L_0x0008
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.HTMLSerializer.<init>(org.apache.xml.serialize.OutputFormat):void");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected HTMLSerializer(boolean z, OutputFormat outputFormat) {
        super(outputFormat);
        this.fUserXHTMLNamespace = null;
        this._xhtml = z;
    }

    /* access modifiers changed from: protected */
    public void characters(String str) throws IOException {
        ElementState content = content();
        super.characters(str);
    }

    public void characters(char[] cArr, int i, int i2) throws SAXException {
        Throwable th;
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        try {
            content().doCData = false;
            super.characters(cArr2, i3, i4);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    public void endElement(String str) throws SAXException {
        endElement((String) null, (String) null, str);
    }

    public void endElement(String str, String str2, String str3) throws SAXException {
        Throwable th;
        try {
            endElementIO(str, str2, str3);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    public void endElementIO(String str, String str2, String str3) throws IOException {
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        this._printer.unindent();
        ElementState elementState = getElementState();
        String str7 = (elementState.namespaceURI == null || elementState.namespaceURI.length() == 0) ? elementState.rawName : (elementState.namespaceURI.equals(XHTMLNamespace) || (this.fUserXHTMLNamespace != null && this.fUserXHTMLNamespace.equals(elementState.namespaceURI))) ? elementState.localName : null;
        if (!this._xhtml) {
            if (elementState.empty) {
                this._printer.printText('>');
            }
            if (str7 == null || !HTMLdtd.isOnlyOpening(str7)) {
                if (this._indenting && !elementState.preserveSpace && elementState.afterElement) {
                    this._printer.breakLine();
                }
                if (elementState.inCData) {
                    this._printer.printText("]]>");
                }
                this._printer.printText("</");
                this._printer.printText(elementState.rawName);
                this._printer.printText('>');
            }
        } else if (elementState.empty) {
            this._printer.printText(" />");
        } else {
            if (elementState.inCData) {
                this._printer.printText("]]>");
            }
            this._printer.printText("</");
            this._printer.printText(elementState.rawName.toLowerCase(Locale.ENGLISH));
            this._printer.printText('>');
        }
        ElementState leaveElementState = leaveElementState();
        if (str7 == null || (!str7.equalsIgnoreCase("A") && !str7.equalsIgnoreCase("TD"))) {
            leaveElementState.afterElement = true;
        }
        leaveElementState.empty = false;
        if (isDocumentState()) {
            this._printer.flush();
        }
    }

    /* access modifiers changed from: protected */
    public String escapeURI(String str) {
        String str2 = str;
        int indexOf = str2.indexOf("\"");
        return indexOf >= 0 ? str2.substring(0, indexOf) : str2;
    }

    /* access modifiers changed from: protected */
    public String getEntityRef(int i) {
        return HTMLdtd.fromChar(i);
    }

    /* access modifiers changed from: protected */
    public void serializeElement(Element element) throws IOException {
        Element element2 = element;
        String tagName = element2.getTagName();
        ElementState elementState = getElementState();
        if (!isDocumentState()) {
            if (elementState.empty) {
                this._printer.printText('>');
            }
            if (this._indenting && !elementState.preserveSpace && (elementState.empty || elementState.afterElement)) {
                this._printer.breakLine();
            }
        } else if (!this._started) {
            startDocument(tagName);
        }
        boolean z = elementState.preserveSpace;
        this._printer.printText('<');
        if (this._xhtml) {
            this._printer.printText(tagName.toLowerCase(Locale.ENGLISH));
        } else {
            this._printer.printText(tagName);
        }
        this._printer.indent();
        NamedNodeMap attributes = element2.getAttributes();
        if (attributes != null) {
            for (int i = 0; i < attributes.getLength(); i++) {
                Attr attr = (Attr) attributes.item(i);
                String lowerCase = attr.getName().toLowerCase(Locale.ENGLISH);
                String value = attr.getValue();
                if (attr.getSpecified()) {
                    this._printer.printSpace();
                    if (!this._xhtml) {
                        if (value == null) {
                            value = "";
                        }
                        if (!this._format.getPreserveEmptyAttributes() && value.length() == 0) {
                            this._printer.printText(lowerCase);
                        } else if (HTMLdtd.isURI(tagName, lowerCase)) {
                            this._printer.printText(lowerCase);
                            this._printer.printText("=\"");
                            this._printer.printText(escapeURI(value));
                            this._printer.printText('\"');
                        } else if (HTMLdtd.isBoolean(tagName, lowerCase)) {
                            this._printer.printText(lowerCase);
                        } else {
                            this._printer.printText(lowerCase);
                            this._printer.printText("=\"");
                            printEscaped(value);
                            this._printer.printText('\"');
                        }
                    } else if (value == null) {
                        this._printer.printText(lowerCase);
                        this._printer.printText("=\"\"");
                    } else {
                        this._printer.printText(lowerCase);
                        this._printer.printText("=\"");
                        printEscaped(value);
                        this._printer.printText('\"');
                    }
                }
            }
        }
        if (HTMLdtd.isPreserveSpace(tagName)) {
            z = true;
        }
        if (element2.hasChildNodes() || !HTMLdtd.isEmptyTag(tagName)) {
            ElementState enterElementState = enterElementState((String) null, (String) null, tagName, z);
            if (tagName.equalsIgnoreCase("A") || tagName.equalsIgnoreCase("TD")) {
                enterElementState.empty = false;
                this._printer.printText('>');
            }
            if (tagName.equalsIgnoreCase("SCRIPT") || tagName.equalsIgnoreCase("STYLE")) {
                if (this._xhtml) {
                    enterElementState.doCData = true;
                } else {
                    enterElementState.unescaped = true;
                }
            }
            Node firstChild = element2.getFirstChild();
            while (true) {
                Node node = firstChild;
                if (node == null) {
                    endElementIO((String) null, (String) null, tagName);
                    return;
                } else {
                    serializeNode(node);
                    firstChild = node.getNextSibling();
                }
            }
        } else {
            this._printer.unindent();
            if (this._xhtml) {
                this._printer.printText(" />");
            } else {
                this._printer.printText('>');
            }
            elementState.afterElement = true;
            elementState.empty = false;
            if (isDocumentState()) {
                this._printer.flush();
            }
        }
    }

    public void setOutputFormat(OutputFormat outputFormat) {
        OutputFormat outputFormat2;
        OutputFormat outputFormat3;
        OutputFormat outputFormat4 = outputFormat;
        if (outputFormat4 != null) {
            outputFormat3 = outputFormat4;
        } else {
            outputFormat3 = outputFormat2;
            new OutputFormat(Method.HTML, "ISO-8859-1", false);
        }
        super.setOutputFormat(outputFormat3);
    }

    public void setXHTMLNamespace(String str) {
        String str2 = str;
        this.fUserXHTMLNamespace = str2;
    }

    /* access modifiers changed from: protected */
    public void startDocument(String str) throws IOException {
        String str2 = str;
        String leaveDTD = this._printer.leaveDTD();
        if (!this._started) {
            if (this._docTypePublicId == null && this._docTypeSystemId == null) {
                if (this._xhtml) {
                    this._docTypePublicId = "-//W3C//DTD XHTML 1.0 Strict//EN";
                    this._docTypeSystemId = "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd";
                } else {
                    this._docTypePublicId = "-//W3C//DTD HTML 4.01//EN";
                    this._docTypeSystemId = "http://www.w3.org/TR/html4/strict.dtd";
                }
            }
            if (!this._format.getOmitDocumentType()) {
                if (this._docTypePublicId != null && (!this._xhtml || this._docTypeSystemId != null)) {
                    if (this._xhtml) {
                        this._printer.printText("<!DOCTYPE html PUBLIC ");
                    } else {
                        this._printer.printText("<!DOCTYPE HTML PUBLIC ");
                    }
                    printDoctypeURL(this._docTypePublicId);
                    if (this._docTypeSystemId != null) {
                        if (this._indenting) {
                            this._printer.breakLine();
                            this._printer.printText("                      ");
                        } else {
                            this._printer.printText(' ');
                        }
                        printDoctypeURL(this._docTypeSystemId);
                    }
                    this._printer.printText('>');
                    this._printer.breakLine();
                } else if (this._docTypeSystemId != null) {
                    if (this._xhtml) {
                        this._printer.printText("<!DOCTYPE html SYSTEM ");
                    } else {
                        this._printer.printText("<!DOCTYPE HTML SYSTEM ");
                    }
                    printDoctypeURL(this._docTypeSystemId);
                    this._printer.printText('>');
                    this._printer.breakLine();
                }
            }
        }
        this._started = true;
        serializePreRoot();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:94:0x0242, code lost:
        if (r2.fUserXHTMLNamespace.equals(r3) != false) goto L_0x0244;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void startElement(java.lang.String r24, java.lang.String r25, java.lang.String r26, org.xml.sax.Attributes r27) throws org.xml.sax.SAXException {
        /*
            r23 = this;
            r2 = r23
            r3 = r24
            r4 = r25
            r5 = r26
            r6 = r27
            r17 = 0
            r13 = r17
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            if (r17 != 0) goto L_0x0041
            java.lang.IllegalStateException r17 = new java.lang.IllegalStateException     // Catch:{ IOException -> 0x0030 }
            r22 = r17
            r17 = r22
            r18 = r22
            java.lang.String r19 = "http://apache.org/xml/serializer"
            java.lang.String r20 = "NoWriterSupplied"
            r21 = 0
            java.lang.String r19 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r19, r20, r21)     // Catch:{ IOException -> 0x0030 }
            r18.<init>(r19)     // Catch:{ IOException -> 0x0030 }
            throw r17     // Catch:{ IOException -> 0x0030 }
        L_0x0030:
            r17 = move-exception
            r14 = r17
            org.xml.sax.SAXException r17 = new org.xml.sax.SAXException
            r22 = r17
            r17 = r22
            r18 = r22
            r19 = r14
            r18.<init>(r19)
            throw r17
        L_0x0041:
            r17 = r2
            org.apache.xml.serialize.ElementState r17 = r17.getElementState()     // Catch:{ IOException -> 0x0030 }
            r9 = r17
            r17 = r2
            boolean r17 = r17.isDocumentState()     // Catch:{ IOException -> 0x0030 }
            if (r17 == 0) goto L_0x01cf
            r17 = r2
            r0 = r17
            boolean r0 = r0._started     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            if (r17 != 0) goto L_0x006e
            r17 = r2
            r18 = r4
            if (r18 == 0) goto L_0x0069
            r18 = r4
            int r18 = r18.length()     // Catch:{ IOException -> 0x0030 }
            if (r18 != 0) goto L_0x01cb
        L_0x0069:
            r18 = r5
        L_0x006b:
            r17.startDocument(r18)     // Catch:{ IOException -> 0x0030 }
        L_0x006e:
            r17 = r9
            r0 = r17
            boolean r0 = r0.preserveSpace     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r8 = r17
            r17 = r3
            if (r17 == 0) goto L_0x021b
            r17 = r3
            int r17 = r17.length()     // Catch:{ IOException -> 0x0030 }
            if (r17 == 0) goto L_0x021b
            r17 = 1
        L_0x0086:
            r14 = r17
            r17 = r5
            if (r17 == 0) goto L_0x0094
            r17 = r5
            int r17 = r17.length()     // Catch:{ IOException -> 0x0030 }
            if (r17 != 0) goto L_0x00da
        L_0x0094:
            r17 = r4
            r5 = r17
            r17 = r14
            if (r17 == 0) goto L_0x00d6
            r17 = r2
            r18 = r3
            java.lang.String r17 = r17.getPrefix(r18)     // Catch:{ IOException -> 0x0030 }
            r15 = r17
            r17 = r15
            if (r17 == 0) goto L_0x00d6
            r17 = r15
            int r17 = r17.length()     // Catch:{ IOException -> 0x0030 }
            if (r17 == 0) goto L_0x00d6
            java.lang.StringBuffer r17 = new java.lang.StringBuffer     // Catch:{ IOException -> 0x0030 }
            r22 = r17
            r17 = r22
            r18 = r22
            r18.<init>()     // Catch:{ IOException -> 0x0030 }
            r18 = r15
            java.lang.StringBuffer r17 = r17.append(r18)     // Catch:{ IOException -> 0x0030 }
            java.lang.String r18 = ":"
            java.lang.StringBuffer r17 = r17.append(r18)     // Catch:{ IOException -> 0x0030 }
            r18 = r4
            java.lang.StringBuffer r17 = r17.append(r18)     // Catch:{ IOException -> 0x0030 }
            java.lang.String r17 = r17.toString()     // Catch:{ IOException -> 0x0030 }
            r5 = r17
        L_0x00d6:
            r17 = 1
            r13 = r17
        L_0x00da:
            r17 = r14
            if (r17 != 0) goto L_0x021f
            r17 = r5
            r12 = r17
        L_0x00e2:
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = 60
            r17.printText((char) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r0 = r17
            boolean r0 = r0._xhtml     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            if (r17 == 0) goto L_0x0250
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = r5
            java.util.Locale r19 = java.util.Locale.ENGLISH     // Catch:{ IOException -> 0x0030 }
            java.lang.String r18 = r18.toLowerCase(r19)     // Catch:{ IOException -> 0x0030 }
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
        L_0x010c:
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r17.indent()     // Catch:{ IOException -> 0x0030 }
            r17 = r6
            if (r17 == 0) goto L_0x012d
            r17 = 0
            r7 = r17
        L_0x011f:
            r17 = r7
            r18 = r6
            int r18 = r18.getLength()     // Catch:{ IOException -> 0x0030 }
            r0 = r17
            r1 = r18
            if (r0 < r1) goto L_0x025f
        L_0x012d:
            r17 = r12
            if (r17 == 0) goto L_0x013d
            r17 = r12
            boolean r17 = org.apache.xml.serialize.HTMLdtd.isPreserveSpace(r17)     // Catch:{ IOException -> 0x0030 }
            if (r17 == 0) goto L_0x013d
            r17 = 1
            r8 = r17
        L_0x013d:
            r17 = r13
            if (r17 == 0) goto L_0x015b
            r17 = r2
            r0 = r17
            java.util.Hashtable r0 = r0._prefixes     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            java.util.Set r17 = r17.entrySet()     // Catch:{ IOException -> 0x0030 }
            java.util.Iterator r17 = r17.iterator()     // Catch:{ IOException -> 0x0030 }
            r15 = r17
        L_0x0153:
            r17 = r15
            boolean r17 = r17.hasNext()     // Catch:{ IOException -> 0x0030 }
            if (r17 != 0) goto L_0x03a3
        L_0x015b:
            r17 = r2
            r18 = r3
            r19 = r4
            r20 = r5
            r21 = r8
            org.apache.xml.serialize.ElementState r17 = r17.enterElementState(r18, r19, r20, r21)     // Catch:{ IOException -> 0x0030 }
            r9 = r17
            r17 = r12
            if (r17 == 0) goto L_0x019c
            r17 = r12
            java.lang.String r18 = "A"
            boolean r17 = r17.equalsIgnoreCase(r18)     // Catch:{ IOException -> 0x0030 }
            if (r17 != 0) goto L_0x0185
            r17 = r12
            java.lang.String r18 = "TD"
            boolean r17 = r17.equalsIgnoreCase(r18)     // Catch:{ IOException -> 0x0030 }
            if (r17 == 0) goto L_0x019c
        L_0x0185:
            r17 = r9
            r18 = 0
            r0 = r18
            r1 = r17
            r1.empty = r0     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = 62
            r17.printText((char) r18)     // Catch:{ IOException -> 0x0030 }
        L_0x019c:
            r17 = r12
            if (r17 == 0) goto L_0x01ca
            r17 = r5
            java.lang.String r18 = "SCRIPT"
            boolean r17 = r17.equalsIgnoreCase(r18)     // Catch:{ IOException -> 0x0030 }
            if (r17 != 0) goto L_0x01b6
            r17 = r5
            java.lang.String r18 = "STYLE"
            boolean r17 = r17.equalsIgnoreCase(r18)     // Catch:{ IOException -> 0x0030 }
            if (r17 == 0) goto L_0x01ca
        L_0x01b6:
            r17 = r2
            r0 = r17
            boolean r0 = r0._xhtml     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            if (r17 == 0) goto L_0x0437
            r17 = r9
            r18 = 1
            r0 = r18
            r1 = r17
            r1.doCData = r0     // Catch:{ IOException -> 0x0030 }
        L_0x01ca:
            return
        L_0x01cb:
            r18 = r4
            goto L_0x006b
        L_0x01cf:
            r17 = r9
            r0 = r17
            boolean r0 = r0.empty     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            if (r17 == 0) goto L_0x01e6
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = 62
            r17.printText((char) r18)     // Catch:{ IOException -> 0x0030 }
        L_0x01e6:
            r17 = r2
            r0 = r17
            boolean r0 = r0._indenting     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            if (r17 == 0) goto L_0x006e
            r17 = r9
            r0 = r17
            boolean r0 = r0.preserveSpace     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            if (r17 != 0) goto L_0x006e
            r17 = r9
            r0 = r17
            boolean r0 = r0.empty     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            if (r17 != 0) goto L_0x020e
            r17 = r9
            r0 = r17
            boolean r0 = r0.afterElement     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            if (r17 == 0) goto L_0x006e
        L_0x020e:
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r17.breakLine()     // Catch:{ IOException -> 0x0030 }
            goto L_0x006e
        L_0x021b:
            r17 = 0
            goto L_0x0086
        L_0x021f:
            r17 = r3
            java.lang.String r18 = "http://www.w3.org/1999/xhtml"
            boolean r17 = r17.equals(r18)     // Catch:{ IOException -> 0x0030 }
            if (r17 != 0) goto L_0x0244
            r17 = r2
            r0 = r17
            java.lang.String r0 = r0.fUserXHTMLNamespace     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            if (r17 == 0) goto L_0x024a
            r17 = r2
            r0 = r17
            java.lang.String r0 = r0.fUserXHTMLNamespace     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = r3
            boolean r17 = r17.equals(r18)     // Catch:{ IOException -> 0x0030 }
            if (r17 == 0) goto L_0x024a
        L_0x0244:
            r17 = r4
            r12 = r17
            goto L_0x00e2
        L_0x024a:
            r17 = 0
            r12 = r17
            goto L_0x00e2
        L_0x0250:
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = r5
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            goto L_0x010c
        L_0x025f:
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r17.printSpace()     // Catch:{ IOException -> 0x0030 }
            r17 = r6
            r18 = r7
            java.lang.String r17 = r17.getQName(r18)     // Catch:{ IOException -> 0x0030 }
            java.util.Locale r18 = java.util.Locale.ENGLISH     // Catch:{ IOException -> 0x0030 }
            java.lang.String r17 = r17.toLowerCase(r18)     // Catch:{ IOException -> 0x0030 }
            r10 = r17
            r17 = r6
            r18 = r7
            java.lang.String r17 = r17.getValue(r18)     // Catch:{ IOException -> 0x0030 }
            r11 = r17
            r17 = r2
            r0 = r17
            boolean r0 = r0._xhtml     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            if (r17 != 0) goto L_0x0292
            r17 = r14
            if (r17 == 0) goto L_0x02e5
        L_0x0292:
            r17 = r11
            if (r17 != 0) goto L_0x02b5
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = r10
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            java.lang.String r18 = "=\"\""
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
        L_0x02b1:
            int r7 = r7 + 1
            goto L_0x011f
        L_0x02b5:
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = r10
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            java.lang.String r18 = "=\""
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r18 = r11
            r17.printEscaped((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = 34
            r17.printText((char) r18)     // Catch:{ IOException -> 0x0030 }
            goto L_0x02b1
        L_0x02e5:
            r17 = r11
            if (r17 != 0) goto L_0x02ee
            java.lang.String r17 = ""
            r11 = r17
        L_0x02ee:
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.OutputFormat r0 = r0._format     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            boolean r17 = r17.getPreserveEmptyAttributes()     // Catch:{ IOException -> 0x0030 }
            if (r17 != 0) goto L_0x0312
            r17 = r11
            int r17 = r17.length()     // Catch:{ IOException -> 0x0030 }
            if (r17 != 0) goto L_0x0312
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = r10
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            goto L_0x02b1
        L_0x0312:
            r17 = r5
            r18 = r10
            boolean r17 = org.apache.xml.serialize.HTMLdtd.isURI(r17, r18)     // Catch:{ IOException -> 0x0030 }
            if (r17 == 0) goto L_0x0359
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = r10
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            java.lang.String r18 = "=\""
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = r2
            r19 = r11
            java.lang.String r18 = r18.escapeURI(r19)     // Catch:{ IOException -> 0x0030 }
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = 34
            r17.printText((char) r18)     // Catch:{ IOException -> 0x0030 }
            goto L_0x02b1
        L_0x0359:
            r17 = r5
            r18 = r10
            boolean r17 = org.apache.xml.serialize.HTMLdtd.isBoolean(r17, r18)     // Catch:{ IOException -> 0x0030 }
            if (r17 == 0) goto L_0x0372
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = r10
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            goto L_0x02b1
        L_0x0372:
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = r10
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            java.lang.String r18 = "=\""
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r18 = r11
            r17.printEscaped((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = 34
            r17.printText((char) r18)     // Catch:{ IOException -> 0x0030 }
            goto L_0x02b1
        L_0x03a3:
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r17.printSpace()     // Catch:{ IOException -> 0x0030 }
            r17 = r15
            java.lang.Object r17 = r17.next()     // Catch:{ IOException -> 0x0030 }
            java.util.Map$Entry r17 = (java.util.Map.Entry) r17     // Catch:{ IOException -> 0x0030 }
            r16 = r17
            r17 = r16
            java.lang.Object r17 = r17.getKey()     // Catch:{ IOException -> 0x0030 }
            java.lang.String r17 = (java.lang.String) r17     // Catch:{ IOException -> 0x0030 }
            r11 = r17
            r17 = r16
            java.lang.Object r17 = r17.getValue()     // Catch:{ IOException -> 0x0030 }
            java.lang.String r17 = (java.lang.String) r17     // Catch:{ IOException -> 0x0030 }
            r10 = r17
            r17 = r10
            int r17 = r17.length()     // Catch:{ IOException -> 0x0030 }
            if (r17 != 0) goto L_0x03f8
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            java.lang.String r18 = "xmlns=\""
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r18 = r11
            r17.printEscaped((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = 34
            r17.printText((char) r18)     // Catch:{ IOException -> 0x0030 }
            goto L_0x0153
        L_0x03f8:
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            java.lang.String r18 = "xmlns:"
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = r10
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            java.lang.String r18 = "=\""
            r17.printText((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r18 = r11
            r17.printEscaped((java.lang.String) r18)     // Catch:{ IOException -> 0x0030 }
            r17 = r2
            r0 = r17
            org.apache.xml.serialize.Printer r0 = r0._printer     // Catch:{ IOException -> 0x0030 }
            r17 = r0
            r18 = 34
            r17.printText((char) r18)     // Catch:{ IOException -> 0x0030 }
            goto L_0x0153
        L_0x0437:
            r17 = r9
            r18 = 1
            r0 = r18
            r1 = r17
            r1.unescaped = r0     // Catch:{ IOException -> 0x0030 }
            goto L_0x01ca
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.HTMLSerializer.startElement(java.lang.String, java.lang.String, java.lang.String, org.xml.sax.Attributes):void");
    }

    public void startElement(String str, AttributeList attributeList) throws SAXException {
        Throwable th;
        Throwable th2;
        String str2 = str;
        AttributeList attributeList2 = attributeList;
        try {
            if (this._printer == null) {
                Throwable th3 = th2;
                new IllegalStateException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "NoWriterSupplied", (Object[]) null));
                throw th3;
            }
            ElementState elementState = getElementState();
            if (!isDocumentState()) {
                if (elementState.empty) {
                    this._printer.printText('>');
                }
                if (this._indenting && !elementState.preserveSpace && (elementState.empty || elementState.afterElement)) {
                    this._printer.breakLine();
                }
            } else if (!this._started) {
                startDocument(str2);
            }
            boolean z = elementState.preserveSpace;
            this._printer.printText('<');
            if (this._xhtml) {
                this._printer.printText(str2.toLowerCase(Locale.ENGLISH));
            } else {
                this._printer.printText(str2);
            }
            this._printer.indent();
            if (attributeList2 != null) {
                for (int i = 0; i < attributeList2.getLength(); i++) {
                    this._printer.printSpace();
                    String lowerCase = attributeList2.getName(i).toLowerCase(Locale.ENGLISH);
                    String value = attributeList2.getValue(i);
                    if (!this._xhtml) {
                        if (value == null) {
                            value = "";
                        }
                        if (!this._format.getPreserveEmptyAttributes() && value.length() == 0) {
                            this._printer.printText(lowerCase);
                        } else if (HTMLdtd.isURI(str2, lowerCase)) {
                            this._printer.printText(lowerCase);
                            this._printer.printText("=\"");
                            this._printer.printText(escapeURI(value));
                            this._printer.printText('\"');
                        } else if (HTMLdtd.isBoolean(str2, lowerCase)) {
                            this._printer.printText(lowerCase);
                        } else {
                            this._printer.printText(lowerCase);
                            this._printer.printText("=\"");
                            printEscaped(value);
                            this._printer.printText('\"');
                        }
                    } else if (value == null) {
                        this._printer.printText(lowerCase);
                        this._printer.printText("=\"\"");
                    } else {
                        this._printer.printText(lowerCase);
                        this._printer.printText("=\"");
                        printEscaped(value);
                        this._printer.printText('\"');
                    }
                }
            }
            if (HTMLdtd.isPreserveSpace(str2)) {
                z = true;
            }
            ElementState enterElementState = enterElementState((String) null, (String) null, str2, z);
            if (str2.equalsIgnoreCase("A") || str2.equalsIgnoreCase("TD")) {
                enterElementState.empty = false;
                this._printer.printText('>');
            }
            if (!str2.equalsIgnoreCase("SCRIPT") && !str2.equalsIgnoreCase("STYLE")) {
                return;
            }
            if (this._xhtml) {
                enterElementState.doCData = true;
            } else {
                enterElementState.unescaped = true;
            }
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th4 = th;
            new SAXException(iOException);
            throw th4;
        }
    }
}
