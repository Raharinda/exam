package org.apache.xml.serialize;

import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.Hashtable;
import java.util.StringTokenizer;

public abstract class SerializerFactory {
    public static final String FactoriesProperty = "org.apache.xml.serialize.factories";
    private static Hashtable _factories;
    static Class class$org$apache$xml$serialize$SerializerFactory;

    static {
        Hashtable hashtable;
        SerializerFactory serializerFactory;
        SerializerFactory serializerFactory2;
        SerializerFactory serializerFactory3;
        SerializerFactory serializerFactory4;
        StringTokenizer stringTokenizer;
        Class cls;
        new Hashtable();
        _factories = hashtable;
        new SerializerFactoryImpl(Method.XML);
        registerSerializerFactory(serializerFactory);
        new SerializerFactoryImpl(Method.HTML);
        registerSerializerFactory(serializerFactory2);
        new SerializerFactoryImpl(Method.XHTML);
        registerSerializerFactory(serializerFactory3);
        new SerializerFactoryImpl(Method.TEXT);
        registerSerializerFactory(serializerFactory4);
        String systemProperty = SecuritySupport.getSystemProperty(FactoriesProperty);
        if (systemProperty != null) {
            new StringTokenizer(systemProperty, " ;,:");
            StringTokenizer stringTokenizer2 = stringTokenizer;
            while (stringTokenizer2.hasMoreTokens()) {
                String nextToken = stringTokenizer2.nextToken();
                try {
                    if (class$org$apache$xml$serialize$SerializerFactory == null) {
                        Class class$ = class$("org.apache.xml.serialize.SerializerFactory");
                        cls = class$;
                        class$org$apache$xml$serialize$SerializerFactory = class$;
                    } else {
                        cls = class$org$apache$xml$serialize$SerializerFactory;
                    }
                    SerializerFactory serializerFactory5 = (SerializerFactory) ObjectFactory.newInstance(nextToken, cls.getClassLoader(), true);
                    if (_factories.containsKey(serializerFactory5.getSupportedMethod())) {
                        Object put = _factories.put(serializerFactory5.getSupportedMethod(), serializerFactory5);
                    }
                } catch (Exception e) {
                    Exception exc = e;
                }
            }
        }
    }

    public SerializerFactory() {
    }

    static Class class$(String str) {
        Throwable th;
        try {
            return Class.forName(str);
        } catch (ClassNotFoundException e) {
            ClassNotFoundException classNotFoundException = e;
            Throwable th2 = th;
            new NoClassDefFoundError(classNotFoundException.getMessage());
            throw th2;
        }
    }

    public static SerializerFactory getSerializerFactory(String str) {
        return (SerializerFactory) _factories.get(str);
    }

    /* JADX INFO: finally extract failed */
    public static void registerSerializerFactory(SerializerFactory serializerFactory) {
        SerializerFactory serializerFactory2 = serializerFactory;
        Hashtable hashtable = _factories;
        synchronized (hashtable) {
            try {
                Object put = _factories.put(serializerFactory2.getSupportedMethod(), serializerFactory2);
            } catch (Throwable th) {
                Throwable th2 = th;
                Hashtable hashtable2 = hashtable;
                throw th2;
            }
        }
    }

    /* access modifiers changed from: protected */
    public abstract String getSupportedMethod();

    public abstract Serializer makeSerializer(OutputStream outputStream, OutputFormat outputFormat) throws UnsupportedEncodingException;

    public abstract Serializer makeSerializer(Writer writer, OutputFormat outputFormat);

    public abstract Serializer makeSerializer(OutputFormat outputFormat);
}
