package org.apache.xml.serialize;

import java.io.IOException;
import java.io.Writer;
import org.apache.xerces.dom.DOMMessageFormatter;
import org.apache.xerces.util.NamespaceSupport;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.util.XML11Char;
import org.apache.xerces.util.XMLChar;
import org.w3c.dom.DOMError;
import org.xml.sax.SAXException;

public class XML11Serializer extends XMLSerializer {
    protected static final boolean DEBUG = false;
    protected static final String PREFIX = "NS";
    protected boolean fDOML1;
    protected NamespaceSupport fLocalNSBinder;
    protected NamespaceSupport fNSBinder;
    protected int fNamespaceCounter;
    protected boolean fNamespaces;
    protected SymbolTable fSymbolTable;

    public XML11Serializer() {
        this.fDOML1 = false;
        this.fNamespaceCounter = 1;
        this.fNamespaces = false;
        this._format.setVersion("1.1");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XML11Serializer(java.io.OutputStream r12, org.apache.xml.serialize.OutputFormat r13) {
        /*
            r11 = this;
            r0 = r11
            r1 = r12
            r2 = r13
            r3 = r0
            r4 = r1
            r5 = r2
            if (r5 == 0) goto L_0x0022
            r5 = r2
        L_0x0009:
            r3.<init>((java.io.OutputStream) r4, (org.apache.xml.serialize.OutputFormat) r5)
            r3 = r0
            r4 = 0
            r3.fDOML1 = r4
            r3 = r0
            r4 = 1
            r3.fNamespaceCounter = r4
            r3 = r0
            r4 = 0
            r3.fNamespaces = r4
            r3 = r0
            org.apache.xml.serialize.OutputFormat r3 = r3._format
            java.lang.String r4 = "1.1"
            r3.setVersion(r4)
            return
        L_0x0022:
            org.apache.xml.serialize.OutputFormat r5 = new org.apache.xml.serialize.OutputFormat
            r10 = r5
            r5 = r10
            r6 = r10
            java.lang.String r7 = "xml"
            r8 = 0
            r9 = 0
            r6.<init>((java.lang.String) r7, (java.lang.String) r8, (boolean) r9)
            goto L_0x0009
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.XML11Serializer.<init>(java.io.OutputStream, org.apache.xml.serialize.OutputFormat):void");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public XML11Serializer(Writer writer, OutputFormat outputFormat) {
        super(writer, outputFormat);
        this.fDOML1 = false;
        this.fNamespaceCounter = 1;
        this.fNamespaces = false;
        this._format.setVersion("1.1");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public XML11Serializer(OutputFormat outputFormat) {
        super(outputFormat);
        this.fDOML1 = false;
        this.fNamespaceCounter = 1;
        this.fNamespaces = false;
        this._format.setVersion("1.1");
    }

    public void characters(char[] cArr, int i, int i2) throws SAXException {
        Throwable th;
        StringBuffer stringBuffer;
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        try {
            ElementState content = content();
            if (content.inCData || content.doCData) {
                if (!content.inCData) {
                    this._printer.printText("<![CDATA[");
                    content.inCData = true;
                }
                int nextIndent = this._printer.getNextIndent();
                this._printer.setNextIndent(0);
                int i5 = i3 + i4;
                int i6 = i3;
                while (i6 < i5) {
                    char c = cArr2[i6];
                    if (c == ']' && i6 + 2 < i5 && cArr2[i6 + 1] == ']' && cArr2[i6 + 2] == '>') {
                        this._printer.printText("]]]]><![CDATA[>");
                        i6 += 2;
                    } else if (!XML11Char.isXML11Valid(c)) {
                        i6++;
                        if (i6 < i5) {
                            surrogates(c, cArr2[i6], true);
                        } else {
                            new StringBuffer();
                            fatalError(stringBuffer.append("The character '").append(c).append("' is an invalid XML character").toString());
                        }
                    } else if (!this._encodingInfo.isPrintable(c) || !XML11Char.isXML11ValidLiteral(c)) {
                        this._printer.printText("]]>&#x");
                        this._printer.printText(Integer.toHexString(c));
                        this._printer.printText(";<![CDATA[");
                    } else {
                        this._printer.printText(c);
                    }
                    i6++;
                }
                this._printer.setNextIndent(nextIndent);
            } else if (content.preserveSpace) {
                int nextIndent2 = this._printer.getNextIndent();
                this._printer.setNextIndent(0);
                printText(cArr2, i3, i4, true, content.unescaped);
                this._printer.setNextIndent(nextIndent2);
            } else {
                printText(cArr2, i3, i4, false, content.unescaped);
            }
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    /* access modifiers changed from: protected */
    public final void printCDATAText(String str) throws IOException {
        StringBuffer stringBuffer;
        Throwable th;
        String str2 = str;
        int length = str2.length();
        int i = 0;
        while (i < length) {
            char charAt = str2.charAt(i);
            if (charAt == ']' && i + 2 < length && str2.charAt(i + 1) == ']' && str2.charAt(i + 2) == '>') {
                if (this.fDOMErrorHandler != null) {
                    if ((this.features & 16) == 0 && (this.features & 2) == 0) {
                        DOMError modifyDOMError = modifyDOMError(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "EndingCDATA", (Object[]) null), 3, (String) null, this.fCurrentNode);
                        if (!this.fDOMErrorHandler.handleError(this.fDOMError)) {
                            Throwable th2 = th;
                            new IOException();
                            throw th2;
                        }
                    } else {
                        DOMError modifyDOMError2 = modifyDOMError(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "SplittingCDATA", (Object[]) null), 1, (String) null, this.fCurrentNode);
                        boolean handleError = this.fDOMErrorHandler.handleError(this.fDOMError);
                    }
                }
                this._printer.printText("]]]]><![CDATA[>");
                i += 2;
            } else if (!XML11Char.isXML11Valid(charAt)) {
                i++;
                if (i < length) {
                    surrogates(charAt, str2.charAt(i), true);
                } else {
                    new StringBuffer();
                    fatalError(stringBuffer.append("The character '").append(charAt).append("' is an invalid XML character").toString());
                }
            } else if (!this._encodingInfo.isPrintable(charAt) || !XML11Char.isXML11ValidLiteral(charAt)) {
                this._printer.printText("]]>&#x");
                this._printer.printText(Integer.toHexString(charAt));
                this._printer.printText(";<![CDATA[");
            } else {
                this._printer.printText(charAt);
            }
            i++;
        }
    }

    /* access modifiers changed from: protected */
    public void printEscaped(String str) throws IOException {
        StringBuffer stringBuffer;
        String str2 = str;
        int length = str2.length();
        int i = 0;
        while (i < length) {
            char charAt = str2.charAt(i);
            if (!XML11Char.isXML11Valid(charAt)) {
                i++;
                if (i < length) {
                    surrogates(charAt, str2.charAt(i), false);
                } else {
                    new StringBuffer();
                    fatalError(stringBuffer.append("The character '").append((char) charAt).append("' is an invalid XML character").toString());
                }
            } else if (charAt == 10 || charAt == 13 || charAt == 9 || charAt == 133 || charAt == 8232) {
                printHex(charAt);
            } else if (charAt == '<') {
                this._printer.printText("&lt;");
            } else if (charAt == '&') {
                this._printer.printText("&amp;");
            } else if (charAt == '\"') {
                this._printer.printText("&quot;");
            } else if (charAt < ' ' || !this._encodingInfo.isPrintable((char) charAt)) {
                printHex(charAt);
            } else {
                this._printer.printText((char) charAt);
            }
            i++;
        }
    }

    /* access modifiers changed from: protected */
    public void printText(String str, boolean z, boolean z2) throws IOException {
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        String str2 = str;
        boolean z3 = z2;
        int length = str2.length();
        if (z) {
            int i = 0;
            while (i < length) {
                char charAt = str2.charAt(i);
                if (!XML11Char.isXML11Valid(charAt)) {
                    i++;
                    if (i < length) {
                        surrogates(charAt, str2.charAt(i), true);
                    } else {
                        new StringBuffer();
                        fatalError(stringBuffer2.append("The character '").append(charAt).append("' is an invalid XML character").toString());
                    }
                } else if (!z3 || !XML11Char.isXML11ValidLiteral(charAt)) {
                    printXMLChar(charAt);
                } else {
                    this._printer.printText(charAt);
                }
                i++;
            }
            return;
        }
        int i2 = 0;
        while (i2 < length) {
            char charAt2 = str2.charAt(i2);
            if (!XML11Char.isXML11Valid(charAt2)) {
                i2++;
                if (i2 < length) {
                    surrogates(charAt2, str2.charAt(i2), true);
                } else {
                    new StringBuffer();
                    fatalError(stringBuffer.append("The character '").append(charAt2).append("' is an invalid XML character").toString());
                }
            } else if (!z3 || !XML11Char.isXML11ValidLiteral(charAt2)) {
                printXMLChar(charAt2);
            } else {
                this._printer.printText(charAt2);
            }
            i2++;
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: CFG modification limit reached, blocks count: 138 */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x00a7, code lost:
        new java.lang.StringBuffer();
        fatalError(r11.append("The character '").append(r6).append("' is an invalid XML character").toString());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x00cc, code lost:
        if (r5 == false) goto L_0x00dd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x00d3, code lost:
        if (org.apache.xerces.util.XML11Char.isXML11ValidLiteral(r6) == false) goto L_0x00dd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x00d5, code lost:
        r0._printer.printText(r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x00dd, code lost:
        printXMLChar(r6);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void printText(char[] r13, int r14, int r15, boolean r16, boolean r17) throws java.io.IOException {
        /*
            r12 = this;
            r0 = r12
            r1 = r13
            r2 = r14
            r3 = r15
            r4 = r16
            r5 = r17
            r7 = r4
            if (r7 == 0) goto L_0x009b
        L_0x000b:
            r7 = r3
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 1
            int r8 = r8 + -1
            r3 = r8
            if (r7 > 0) goto L_0x0016
        L_0x0015:
            return
        L_0x0016:
            r7 = r1
            r8 = r2
            int r2 = r2 + 1
            char r7 = r7[r8]
            r6 = r7
            r7 = r6
            boolean r7 = org.apache.xerces.util.XML11Char.isXML11Valid(r7)
            if (r7 != 0) goto L_0x005f
            r7 = r3
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 1
            int r8 = r8 + -1
            r3 = r8
            if (r7 <= 0) goto L_0x003b
            r7 = r0
            r8 = r6
            r9 = r1
            r10 = r2
            int r2 = r2 + 1
            char r9 = r9[r10]
            r10 = 1
            r7.surrogates(r8, r9, r10)
            goto L_0x000b
        L_0x003b:
            r7 = r0
            java.lang.StringBuffer r8 = new java.lang.StringBuffer
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            java.lang.String r9 = "The character '"
            java.lang.StringBuffer r8 = r8.append(r9)
            r9 = r6
            java.lang.StringBuffer r8 = r8.append(r9)
            java.lang.String r9 = "' is an invalid XML character"
            java.lang.StringBuffer r8 = r8.append(r9)
            java.lang.String r8 = r8.toString()
            r7.fatalError(r8)
            goto L_0x000b
        L_0x005f:
            r7 = r5
            if (r7 == 0) goto L_0x0071
            r7 = r6
            boolean r7 = org.apache.xerces.util.XML11Char.isXML11ValidLiteral(r7)
            if (r7 == 0) goto L_0x0071
            r7 = r0
            org.apache.xml.serialize.Printer r7 = r7._printer
            r8 = r6
            r7.printText((char) r8)
            goto L_0x000b
        L_0x0071:
            r7 = r0
            r8 = r6
            r7.printXMLChar(r8)
            goto L_0x000b
        L_0x0077:
            r7 = r1
            r8 = r2
            int r2 = r2 + 1
            char r7 = r7[r8]
            r6 = r7
            r7 = r6
            boolean r7 = org.apache.xerces.util.XML11Char.isXML11Valid(r7)
            if (r7 != 0) goto L_0x00cb
            r7 = r3
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 1
            int r8 = r8 + -1
            r3 = r8
            if (r7 <= 0) goto L_0x00a7
            r7 = r0
            r8 = r6
            r9 = r1
            r10 = r2
            int r2 = r2 + 1
            char r9 = r9[r10]
            r10 = 1
            r7.surrogates(r8, r9, r10)
        L_0x009b:
            r7 = r3
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 1
            int r8 = r8 + -1
            r3 = r8
            if (r7 > 0) goto L_0x0077
            goto L_0x0015
        L_0x00a7:
            r7 = r0
            java.lang.StringBuffer r8 = new java.lang.StringBuffer
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            java.lang.String r9 = "The character '"
            java.lang.StringBuffer r8 = r8.append(r9)
            r9 = r6
            java.lang.StringBuffer r8 = r8.append(r9)
            java.lang.String r9 = "' is an invalid XML character"
            java.lang.StringBuffer r8 = r8.append(r9)
            java.lang.String r8 = r8.toString()
            r7.fatalError(r8)
            goto L_0x009b
        L_0x00cb:
            r7 = r5
            if (r7 == 0) goto L_0x00dd
            r7 = r6
            boolean r7 = org.apache.xerces.util.XML11Char.isXML11ValidLiteral(r7)
            if (r7 == 0) goto L_0x00dd
            r7 = r0
            org.apache.xml.serialize.Printer r7 = r7._printer
            r8 = r6
            r7.printText((char) r8)
            goto L_0x009b
        L_0x00dd:
            r7 = r0
            r8 = r6
            r7.printXMLChar(r8)
            goto L_0x009b
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.XML11Serializer.printText(char[], int, int, boolean, boolean):void");
    }

    /* access modifiers changed from: protected */
    public final void printXMLChar(int i) throws IOException {
        int i2 = i;
        if (i2 == 13 || i2 == 133 || i2 == 8232) {
            printHex(i2);
        } else if (i2 == 60) {
            this._printer.printText("&lt;");
        } else if (i2 == 38) {
            this._printer.printText("&amp;");
        } else if (i2 == 62) {
            this._printer.printText("&gt;");
        } else if (!this._encodingInfo.isPrintable((char) i2) || !XML11Char.isXML11ValidLiteral(i2)) {
            printHex(i2);
        } else {
            this._printer.printText((char) i2);
        }
    }

    public boolean reset() {
        boolean reset = super.reset();
        return true;
    }

    /* access modifiers changed from: protected */
    public final void surrogates(int i, int i2, boolean z) throws IOException {
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        StringBuffer stringBuffer3;
        int i3 = i;
        int i4 = i2;
        boolean z2 = z;
        if (!XMLChar.isHighSurrogate(i3)) {
            new StringBuffer();
            fatalError(stringBuffer.append("The character '").append((char) i3).append("' is an invalid XML character").toString());
        } else if (!XMLChar.isLowSurrogate(i4)) {
            new StringBuffer();
            fatalError(stringBuffer3.append("The character '").append((char) i4).append("' is an invalid XML character").toString());
        } else {
            int supplemental = XMLChar.supplemental((char) i3, (char) i4);
            if (!XML11Char.isXML11Valid(supplemental)) {
                new StringBuffer();
                fatalError(stringBuffer2.append("The character '").append((char) supplemental).append("' is an invalid XML character").toString());
            } else if (!z2 || !content().inCData) {
                printHex(supplemental);
            } else {
                this._printer.printText("]]>&#x");
                this._printer.printText(Integer.toHexString(supplemental));
                this._printer.printText(";<![CDATA[");
            }
        }
    }
}
