package org.apache.xml.serialize;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.lang.reflect.Method;
import net.lingala.zip4j.util.InternalZipConstants;
import org.apache.xerces.util.EncodingMap;

public class EncodingInfo {
    private Object[] fArgsForMethod = null;
    Object fCharToByteConverter = null;
    Object fCharsetEncoder = null;
    boolean fHaveTriedCToB = false;
    boolean fHaveTriedCharsetEncoder = false;
    String ianaName;
    String javaName;
    int lastPrintable;

    static class CharToByteConverterMethods {
        static Class class$java$lang$String;
        private static Method fgCanConvertMethod;
        private static boolean fgConvertersAvailable;
        private static Method fgGetConverterMethod;

        static {
            Class cls;
            fgGetConverterMethod = null;
            fgCanConvertMethod = null;
            fgConvertersAvailable = false;
            try {
                Class<?> cls2 = Class.forName("sun.io.CharToByteConverter");
                Class<?> cls3 = cls2;
                Class[] clsArr = new Class[1];
                Class[] clsArr2 = clsArr;
                Class[] clsArr3 = clsArr;
                if (class$java$lang$String == null) {
                    Class class$ = class$("java.lang.String");
                    cls = class$;
                    class$java$lang$String = class$;
                } else {
                    cls = class$java$lang$String;
                }
                clsArr3[0] = cls;
                fgGetConverterMethod = cls3.getMethod("getConverter", clsArr2);
                fgCanConvertMethod = cls2.getMethod("canConvert", new Class[]{Character.TYPE});
                fgConvertersAvailable = true;
            } catch (Exception e) {
                Exception exc = e;
                fgGetConverterMethod = null;
                fgCanConvertMethod = null;
                fgConvertersAvailable = false;
            }
        }

        private CharToByteConverterMethods() {
        }

        static boolean access$500() {
            return fgConvertersAvailable;
        }

        static Method access$600() {
            return fgGetConverterMethod;
        }

        static Method access$700() {
            return fgCanConvertMethod;
        }

        static Class class$(String str) {
            Throwable th;
            try {
                return Class.forName(str);
            } catch (ClassNotFoundException e) {
                ClassNotFoundException classNotFoundException = e;
                Throwable th2 = th;
                new NoClassDefFoundError(classNotFoundException.getMessage());
                throw th2;
            }
        }
    }

    static class CharsetMethods {
        static Class class$java$lang$String;
        private static Method fgCharsetCanEncodeMethod;
        private static Method fgCharsetEncoderCanEncodeMethod;
        private static Method fgCharsetForNameMethod;
        private static Method fgCharsetNewEncoderMethod;
        private static boolean fgNIOCharsetAvailable;

        static {
            Class cls;
            fgCharsetForNameMethod = null;
            fgCharsetCanEncodeMethod = null;
            fgCharsetNewEncoderMethod = null;
            fgCharsetEncoderCanEncodeMethod = null;
            fgNIOCharsetAvailable = false;
            try {
                Class<?> cls2 = Class.forName("java.nio.charset.Charset");
                Class<?> cls3 = Class.forName("java.nio.charset.CharsetEncoder");
                Class<?> cls4 = cls2;
                Class[] clsArr = new Class[1];
                Class[] clsArr2 = clsArr;
                Class[] clsArr3 = clsArr;
                if (class$java$lang$String == null) {
                    Class class$ = class$("java.lang.String");
                    cls = class$;
                    class$java$lang$String = class$;
                } else {
                    cls = class$java$lang$String;
                }
                clsArr3[0] = cls;
                fgCharsetForNameMethod = cls4.getMethod("forName", clsArr2);
                fgCharsetCanEncodeMethod = cls2.getMethod("canEncode", new Class[0]);
                fgCharsetNewEncoderMethod = cls2.getMethod("newEncoder", new Class[0]);
                fgCharsetEncoderCanEncodeMethod = cls3.getMethod("canEncode", new Class[]{Character.TYPE});
                fgNIOCharsetAvailable = true;
            } catch (Exception e) {
                Exception exc = e;
                fgCharsetForNameMethod = null;
                fgCharsetCanEncodeMethod = null;
                fgCharsetEncoderCanEncodeMethod = null;
                fgCharsetNewEncoderMethod = null;
                fgNIOCharsetAvailable = false;
            }
        }

        private CharsetMethods() {
        }

        static boolean access$000() {
            return fgNIOCharsetAvailable;
        }

        static Method access$100() {
            return fgCharsetForNameMethod;
        }

        static Method access$200() {
            return fgCharsetCanEncodeMethod;
        }

        static Method access$300() {
            return fgCharsetNewEncoderMethod;
        }

        static Method access$400() {
            return fgCharsetEncoderCanEncodeMethod;
        }

        static Class class$(String str) {
            Throwable th;
            try {
                return Class.forName(str);
            } catch (ClassNotFoundException e) {
                ClassNotFoundException classNotFoundException = e;
                Throwable th2 = th;
                new NoClassDefFoundError(classNotFoundException.getMessage());
                throw th2;
            }
        }
    }

    public EncodingInfo(String str, String str2, int i) {
        String str3 = str;
        String str4 = str2;
        this.ianaName = str3;
        this.javaName = EncodingMap.getIANA2JavaMapping(str3);
        this.lastPrintable = i;
    }

    private boolean isPrintable0(char c) {
        Object obj;
        Object obj2;
        char c2 = c;
        if (this.fCharsetEncoder == null && CharsetMethods.access$000() && !this.fHaveTriedCharsetEncoder) {
            if (this.fArgsForMethod == null) {
                this.fArgsForMethod = new Object[1];
            }
            try {
                this.fArgsForMethod[0] = this.javaName;
                Object invoke = CharsetMethods.access$100().invoke((Object) null, this.fArgsForMethod);
                if (((Boolean) CharsetMethods.access$200().invoke(invoke, (Object[]) null)).booleanValue()) {
                    this.fCharsetEncoder = CharsetMethods.access$300().invoke(invoke, (Object[]) null);
                } else {
                    this.fHaveTriedCharsetEncoder = true;
                }
            } catch (Exception e) {
                Exception exc = e;
                this.fHaveTriedCharsetEncoder = true;
            }
        }
        if (this.fCharsetEncoder != null) {
            try {
                new Character(c2);
                this.fArgsForMethod[0] = obj2;
                return ((Boolean) CharsetMethods.access$400().invoke(this.fCharsetEncoder, this.fArgsForMethod)).booleanValue();
            } catch (Exception e2) {
                Exception exc2 = e2;
                this.fCharsetEncoder = null;
                this.fHaveTriedCharsetEncoder = false;
            }
        }
        if (this.fCharToByteConverter == null) {
            if (this.fHaveTriedCToB || !CharToByteConverterMethods.access$500()) {
                return false;
            }
            if (this.fArgsForMethod == null) {
                this.fArgsForMethod = new Object[1];
            }
            try {
                this.fArgsForMethod[0] = this.javaName;
                this.fCharToByteConverter = CharToByteConverterMethods.access$600().invoke((Object) null, this.fArgsForMethod);
            } catch (Exception e3) {
                Exception exc3 = e3;
                this.fHaveTriedCToB = true;
                return false;
            }
        }
        try {
            new Character(c2);
            this.fArgsForMethod[0] = obj;
            return ((Boolean) CharToByteConverterMethods.access$700().invoke(this.fCharToByteConverter, this.fArgsForMethod)).booleanValue();
        } catch (Exception e4) {
            Exception exc4 = e4;
            this.fCharToByteConverter = null;
            this.fHaveTriedCToB = false;
            return false;
        }
    }

    public static void testJavaEncodingName(String str) throws UnsupportedEncodingException {
        Object obj;
        new String("valid".getBytes(), str);
        Object obj2 = obj;
    }

    public String getIANAName() {
        return this.ianaName;
    }

    public Writer getWriter(OutputStream outputStream) throws UnsupportedEncodingException {
        Writer writer;
        Writer writer2;
        Writer writer3;
        OutputStream outputStream2 = outputStream;
        if (this.javaName != null) {
            new OutputStreamWriter(outputStream2, this.javaName);
            return writer3;
        }
        this.javaName = EncodingMap.getIANA2JavaMapping(this.ianaName);
        if (this.javaName == null) {
            new OutputStreamWriter(outputStream2, InternalZipConstants.CHARSET_UTF8);
            return writer2;
        }
        new OutputStreamWriter(outputStream2, this.javaName);
        return writer;
    }

    public boolean isPrintable(char c) {
        char c2 = c;
        if (c2 <= this.lastPrintable) {
            return true;
        }
        return isPrintable0(c2);
    }
}
