package org.apache.xml.serialize;

import com.microsoft.appcenter.crashes.ingestion.models.ErrorAttachmentLog;
import java.io.UnsupportedEncodingException;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Node;
import org.w3c.dom.html.HTMLDocument;

public class OutputFormat {
    private boolean _allowJavaNames;
    private String[] _cdataElements;
    private String _doctypePublic;
    private String _doctypeSystem;
    private String _encoding;
    private EncodingInfo _encodingInfo;
    private int _indent;
    private String _lineSeparator;
    private int _lineWidth;
    private String _mediaType;
    private String _method;
    private String[] _nonEscapingElements;
    private boolean _omitComments;
    private boolean _omitDoctype;
    private boolean _omitXmlDeclaration;
    private boolean _preserve;
    private boolean _preserveEmptyAttributes;
    private boolean _standalone;
    private String _version;

    public static class DTD {
        public static final String HTMLPublicId = "-//W3C//DTD HTML 4.01//EN";
        public static final String HTMLSystemId = "http://www.w3.org/TR/html4/strict.dtd";
        public static final String XHTMLPublicId = "-//W3C//DTD XHTML 1.0 Strict//EN";
        public static final String XHTMLSystemId = "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd";

        public DTD() {
        }
    }

    public static class Defaults {
        public static final String Encoding = "UTF-8";
        public static final int Indent = 4;
        public static final int LineWidth = 72;

        public Defaults() {
        }
    }

    public OutputFormat() {
        this._indent = 0;
        this._encoding = "UTF-8";
        this._encodingInfo = null;
        this._allowJavaNames = false;
        this._omitXmlDeclaration = false;
        this._omitDoctype = false;
        this._omitComments = false;
        this._standalone = false;
        this._lineSeparator = "\n";
        this._lineWidth = 72;
        this._preserve = false;
        this._preserveEmptyAttributes = false;
    }

    public OutputFormat(String str, String str2, boolean z) {
        this._indent = 0;
        this._encoding = "UTF-8";
        this._encodingInfo = null;
        this._allowJavaNames = false;
        this._omitXmlDeclaration = false;
        this._omitDoctype = false;
        this._omitComments = false;
        this._standalone = false;
        this._lineSeparator = "\n";
        this._lineWidth = 72;
        this._preserve = false;
        this._preserveEmptyAttributes = false;
        setMethod(str);
        setEncoding(str2);
        setIndenting(z);
    }

    public OutputFormat(Document document) {
        Document document2 = document;
        this._indent = 0;
        this._encoding = "UTF-8";
        this._encodingInfo = null;
        this._allowJavaNames = false;
        this._omitXmlDeclaration = false;
        this._omitDoctype = false;
        this._omitComments = false;
        this._standalone = false;
        this._lineSeparator = "\n";
        this._lineWidth = 72;
        this._preserve = false;
        this._preserveEmptyAttributes = false;
        setMethod(whichMethod(document2));
        setDoctype(whichDoctypePublic(document2), whichDoctypeSystem(document2));
        setMediaType(whichMediaType(getMethod()));
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public OutputFormat(Document document, String str, boolean z) {
        this(document);
        setEncoding(str);
        setIndenting(z);
    }

    public static String whichDoctypePublic(Document document) {
        Document document2 = document;
        DocumentType doctype = document2.getDoctype();
        if (doctype != null) {
            try {
                return doctype.getPublicId();
            } catch (Error e) {
                Error error = e;
            }
        }
        if (document2 instanceof HTMLDocument) {
            return "-//W3C//DTD XHTML 1.0 Strict//EN";
        }
        return null;
    }

    public static String whichDoctypeSystem(Document document) {
        Document document2 = document;
        DocumentType doctype = document2.getDoctype();
        if (doctype != null) {
            try {
                return doctype.getSystemId();
            } catch (Error e) {
                Error error = e;
            }
        }
        if (document2 instanceof HTMLDocument) {
            return "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd";
        }
        return null;
    }

    public static String whichMediaType(String str) {
        String str2 = str;
        if (str2.equalsIgnoreCase(Method.XML)) {
            return "text/xml";
        }
        if (str2.equalsIgnoreCase(Method.HTML)) {
            return "text/html";
        }
        if (str2.equalsIgnoreCase(Method.XHTML)) {
            return "text/html";
        }
        if (str2.equalsIgnoreCase(Method.TEXT)) {
            return ErrorAttachmentLog.CONTENT_TYPE_TEXT_PLAIN;
        }
        if (str2.equalsIgnoreCase(Method.FOP)) {
            return "application/pdf";
        }
        return null;
    }

    public static String whichMethod(Document document) {
        Document document2 = document;
        if (document2 instanceof HTMLDocument) {
            return Method.HTML;
        }
        Node firstChild = document2.getFirstChild();
        while (true) {
            Node node = firstChild;
            if (node == null) {
                return Method.XML;
            }
            if (node.getNodeType() == 1) {
                return node.getNodeName().equalsIgnoreCase(Method.HTML) ? Method.HTML : node.getNodeName().equalsIgnoreCase("root") ? Method.FOP : Method.XML;
            }
            if (node.getNodeType() == 3) {
                String nodeValue = node.getNodeValue();
                for (int i = 0; i < nodeValue.length(); i++) {
                    if (nodeValue.charAt(i) != ' ' && nodeValue.charAt(i) != 10 && nodeValue.charAt(i) != 9 && nodeValue.charAt(i) != 13) {
                        return Method.XML;
                    }
                }
                continue;
            }
            firstChild = node.getNextSibling();
        }
    }

    public String[] getCDataElements() {
        return this._cdataElements;
    }

    public String getDoctypePublic() {
        return this._doctypePublic;
    }

    public String getDoctypeSystem() {
        return this._doctypeSystem;
    }

    public String getEncoding() {
        return this._encoding;
    }

    public EncodingInfo getEncodingInfo() throws UnsupportedEncodingException {
        if (this._encodingInfo == null) {
            this._encodingInfo = Encodings.getEncodingInfo(this._encoding, this._allowJavaNames);
        }
        return this._encodingInfo;
    }

    public int getIndent() {
        return this._indent;
    }

    public boolean getIndenting() {
        return this._indent > 0;
    }

    public char getLastPrintable() {
        return (getEncoding() == null || !getEncoding().equalsIgnoreCase("ASCII")) ? (char) 65535 : 255;
    }

    public String getLineSeparator() {
        return this._lineSeparator;
    }

    public int getLineWidth() {
        return this._lineWidth;
    }

    public String getMediaType() {
        return this._mediaType;
    }

    public String getMethod() {
        return this._method;
    }

    public String[] getNonEscapingElements() {
        return this._nonEscapingElements;
    }

    public boolean getOmitComments() {
        return this._omitComments;
    }

    public boolean getOmitDocumentType() {
        return this._omitDoctype;
    }

    public boolean getOmitXMLDeclaration() {
        return this._omitXmlDeclaration;
    }

    public boolean getPreserveEmptyAttributes() {
        return this._preserveEmptyAttributes;
    }

    public boolean getPreserveSpace() {
        return this._preserve;
    }

    public boolean getStandalone() {
        return this._standalone;
    }

    public String getVersion() {
        return this._version;
    }

    public boolean isCDataElement(String str) {
        String str2 = str;
        if (this._cdataElements == null) {
            return false;
        }
        for (int i = 0; i < this._cdataElements.length; i++) {
            if (this._cdataElements[i].equals(str2)) {
                return true;
            }
        }
        return false;
    }

    public boolean isNonEscapingElement(String str) {
        String str2 = str;
        if (this._nonEscapingElements == null) {
            return false;
        }
        for (int i = 0; i < this._nonEscapingElements.length; i++) {
            if (this._nonEscapingElements[i].equals(str2)) {
                return true;
            }
        }
        return false;
    }

    public void setAllowJavaNames(boolean z) {
        boolean z2 = z;
        this._allowJavaNames = z2;
    }

    public boolean setAllowJavaNames() {
        return this._allowJavaNames;
    }

    public void setCDataElements(String[] strArr) {
        String[] strArr2 = strArr;
        this._cdataElements = strArr2;
    }

    public void setDoctype(String str, String str2) {
        this._doctypePublic = str;
        this._doctypeSystem = str2;
    }

    public void setEncoding(String str) {
        this._encoding = str;
        this._encodingInfo = null;
    }

    public void setEncoding(EncodingInfo encodingInfo) {
        EncodingInfo encodingInfo2 = encodingInfo;
        this._encoding = encodingInfo2.getIANAName();
        this._encodingInfo = encodingInfo2;
    }

    public void setIndent(int i) {
        int i2 = i;
        if (i2 < 0) {
            this._indent = 0;
            return;
        }
        this._indent = i2;
    }

    public void setIndenting(boolean z) {
        if (z) {
            this._indent = 4;
            this._lineWidth = 72;
            return;
        }
        this._indent = 0;
        this._lineWidth = 0;
    }

    public void setLineSeparator(String str) {
        String str2 = str;
        if (str2 == null) {
            this._lineSeparator = "\n";
            return;
        }
        this._lineSeparator = str2;
    }

    public void setLineWidth(int i) {
        int i2 = i;
        if (i2 <= 0) {
            this._lineWidth = 0;
            return;
        }
        this._lineWidth = i2;
    }

    public void setMediaType(String str) {
        String str2 = str;
        this._mediaType = str2;
    }

    public void setMethod(String str) {
        String str2 = str;
        this._method = str2;
    }

    public void setNonEscapingElements(String[] strArr) {
        String[] strArr2 = strArr;
        this._nonEscapingElements = strArr2;
    }

    public void setOmitComments(boolean z) {
        boolean z2 = z;
        this._omitComments = z2;
    }

    public void setOmitDocumentType(boolean z) {
        boolean z2 = z;
        this._omitDoctype = z2;
    }

    public void setOmitXMLDeclaration(boolean z) {
        boolean z2 = z;
        this._omitXmlDeclaration = z2;
    }

    public void setPreserveEmptyAttributes(boolean z) {
        boolean z2 = z;
        this._preserveEmptyAttributes = z2;
    }

    public void setPreserveSpace(boolean z) {
        boolean z2 = z;
        this._preserve = z2;
    }

    public void setStandalone(boolean z) {
        boolean z2 = z;
        this._standalone = z2;
    }

    public void setVersion(String str) {
        String str2 = str;
        this._version = str2;
    }
}
