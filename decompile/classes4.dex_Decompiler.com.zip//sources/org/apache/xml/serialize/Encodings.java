package org.apache.xml.serialize;

import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.Locale;
import org.apache.xerces.util.EncodingMap;

public class Encodings {
    static final String DEFAULT_ENCODING = "UTF8";
    static final int DEFAULT_LAST_PRINTABLE = 127;
    static final String JIS_DANGER_CHARS = "\\~¢£¥¬—―‖…‾‾∥∯〜＼～￠￡￢￣";
    static final int LAST_PRINTABLE_UNICODE = 65535;
    static final String[] UNICODE_ENCODINGS;
    static Hashtable _encodings;

    static {
        Hashtable hashtable;
        String[] strArr = new String[6];
        strArr[0] = "Unicode";
        String[] strArr2 = strArr;
        strArr2[1] = "UnicodeBig";
        String[] strArr3 = strArr2;
        strArr3[2] = "UnicodeLittle";
        String[] strArr4 = strArr3;
        strArr4[3] = "GB2312";
        String[] strArr5 = strArr4;
        strArr5[4] = "UTF8";
        String[] strArr6 = strArr5;
        strArr6[5] = "UTF-16";
        UNICODE_ENCODINGS = strArr6;
        new Hashtable();
        _encodings = hashtable;
    }

    public Encodings() {
    }

    static EncodingInfo getEncodingInfo(String str, boolean z) throws UnsupportedEncodingException {
        EncodingInfo encodingInfo;
        EncodingInfo encodingInfo2;
        Throwable th;
        EncodingInfo encodingInfo3;
        EncodingInfo encodingInfo4;
        EncodingInfo encodingInfo5;
        String str2 = str;
        boolean z2 = z;
        if (str2 == null) {
            EncodingInfo encodingInfo6 = (EncodingInfo) _encodings.get("UTF8");
            EncodingInfo encodingInfo7 = encodingInfo6;
            if (encodingInfo6 != null) {
                return encodingInfo7;
            }
            new EncodingInfo(EncodingMap.getJava2IANAMapping("UTF8"), "UTF8", 65535);
            EncodingInfo encodingInfo8 = encodingInfo5;
            Object put = _encodings.put("UTF8", encodingInfo8);
            return encodingInfo8;
        }
        String upperCase = str2.toUpperCase(Locale.ENGLISH);
        String iANA2JavaMapping = EncodingMap.getIANA2JavaMapping(upperCase);
        if (iANA2JavaMapping != null) {
            EncodingInfo encodingInfo9 = (EncodingInfo) _encodings.get(iANA2JavaMapping);
            EncodingInfo encodingInfo10 = encodingInfo9;
            if (encodingInfo9 != null) {
                return encodingInfo10;
            }
            int i = 0;
            while (true) {
                if (i >= UNICODE_ENCODINGS.length) {
                    break;
                } else if (UNICODE_ENCODINGS[i].equalsIgnoreCase(iANA2JavaMapping)) {
                    new EncodingInfo(upperCase, iANA2JavaMapping, 65535);
                    encodingInfo10 = encodingInfo;
                    break;
                } else {
                    i++;
                }
            }
            if (i == UNICODE_ENCODINGS.length) {
                new EncodingInfo(upperCase, iANA2JavaMapping, DEFAULT_LAST_PRINTABLE);
                encodingInfo10 = encodingInfo2;
            }
            Object put2 = _encodings.put(iANA2JavaMapping, encodingInfo10);
            return encodingInfo10;
        } else if (z2) {
            EncodingInfo.testJavaEncodingName(upperCase);
            EncodingInfo encodingInfo11 = (EncodingInfo) _encodings.get(upperCase);
            EncodingInfo encodingInfo12 = encodingInfo11;
            if (encodingInfo11 != null) {
                return encodingInfo12;
            }
            int i2 = 0;
            while (true) {
                if (i2 >= UNICODE_ENCODINGS.length) {
                    break;
                } else if (UNICODE_ENCODINGS[i2].equalsIgnoreCase(upperCase)) {
                    new EncodingInfo(EncodingMap.getJava2IANAMapping(upperCase), upperCase, 65535);
                    encodingInfo12 = encodingInfo3;
                    break;
                } else {
                    i2++;
                }
            }
            if (i2 == UNICODE_ENCODINGS.length) {
                new EncodingInfo(EncodingMap.getJava2IANAMapping(upperCase), upperCase, DEFAULT_LAST_PRINTABLE);
                encodingInfo12 = encodingInfo4;
            }
            Object put3 = _encodings.put(upperCase, encodingInfo12);
            return encodingInfo12;
        } else {
            Throwable th2 = th;
            new UnsupportedEncodingException(upperCase);
            throw th2;
        }
    }
}
