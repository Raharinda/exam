package org.apache.xml.serialize;

import com.kodular.fabextension.BuildConfig;
import com.microsoft.appcenter.Constants;
import java.io.IOException;
import java.util.Map;
import org.apache.xerces.dom.DOMMessageFormatter;
import org.apache.xerces.util.NamespaceSupport;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.util.XMLChar;
import org.apache.xerces.util.XMLSymbols;
import org.w3c.dom.Attr;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.AttributeList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

public class XMLSerializer extends BaseMarkupSerializer {
    protected static final boolean DEBUG = false;
    protected static final String PREFIX = "NS";
    protected NamespaceSupport fLocalNSBinder;
    protected NamespaceSupport fNSBinder;
    protected boolean fNamespacePrefixes;
    protected boolean fNamespaces;
    private boolean fPreserveSpace;
    protected SymbolTable fSymbolTable;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XMLSerializer() {
        /*
            r8 = this;
            r0 = r8
            r1 = r0
            org.apache.xml.serialize.OutputFormat r2 = new org.apache.xml.serialize.OutputFormat
            r7 = r2
            r2 = r7
            r3 = r7
            java.lang.String r4 = "xml"
            r5 = 0
            r6 = 0
            r3.<init>((java.lang.String) r4, (java.lang.String) r5, (boolean) r6)
            r1.<init>(r2)
            r1 = r0
            r2 = 0
            r1.fNamespaces = r2
            r1 = r0
            r2 = 1
            r1.fNamespacePrefixes = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.XMLSerializer.<init>():void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XMLSerializer(java.io.OutputStream r11, org.apache.xml.serialize.OutputFormat r12) {
        /*
            r10 = this;
            r0 = r10
            r1 = r11
            r2 = r12
            r3 = r0
            r4 = r2
            if (r4 == 0) goto L_0x0022
            r4 = r2
        L_0x0008:
            r3.<init>(r4)
            r3 = r0
            r4 = 0
            r3.fNamespaces = r4
            r3 = r0
            r4 = 1
            r3.fNamespacePrefixes = r4
            r3 = r0
            org.apache.xml.serialize.OutputFormat r3 = r3._format
            java.lang.String r4 = "xml"
            r3.setMethod(r4)
            r3 = r0
            r4 = r1
            r3.setOutputByteStream(r4)
            return
        L_0x0022:
            org.apache.xml.serialize.OutputFormat r4 = new org.apache.xml.serialize.OutputFormat
            r9 = r4
            r4 = r9
            r5 = r9
            java.lang.String r6 = "xml"
            r7 = 0
            r8 = 0
            r5.<init>((java.lang.String) r6, (java.lang.String) r7, (boolean) r8)
            goto L_0x0008
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.XMLSerializer.<init>(java.io.OutputStream, org.apache.xml.serialize.OutputFormat):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XMLSerializer(java.io.Writer r11, org.apache.xml.serialize.OutputFormat r12) {
        /*
            r10 = this;
            r0 = r10
            r1 = r11
            r2 = r12
            r3 = r0
            r4 = r2
            if (r4 == 0) goto L_0x0022
            r4 = r2
        L_0x0008:
            r3.<init>(r4)
            r3 = r0
            r4 = 0
            r3.fNamespaces = r4
            r3 = r0
            r4 = 1
            r3.fNamespacePrefixes = r4
            r3 = r0
            org.apache.xml.serialize.OutputFormat r3 = r3._format
            java.lang.String r4 = "xml"
            r3.setMethod(r4)
            r3 = r0
            r4 = r1
            r3.setOutputCharStream(r4)
            return
        L_0x0022:
            org.apache.xml.serialize.OutputFormat r4 = new org.apache.xml.serialize.OutputFormat
            r9 = r4
            r4 = r9
            r5 = r9
            java.lang.String r6 = "xml"
            r7 = 0
            r8 = 0
            r5.<init>((java.lang.String) r6, (java.lang.String) r7, (boolean) r8)
            goto L_0x0008
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.XMLSerializer.<init>(java.io.Writer, org.apache.xml.serialize.OutputFormat):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XMLSerializer(org.apache.xml.serialize.OutputFormat r10) {
        /*
            r9 = this;
            r0 = r9
            r1 = r10
            r2 = r0
            r3 = r1
            if (r3 == 0) goto L_0x001c
            r3 = r1
        L_0x0007:
            r2.<init>(r3)
            r2 = r0
            r3 = 0
            r2.fNamespaces = r3
            r2 = r0
            r3 = 1
            r2.fNamespacePrefixes = r3
            r2 = r0
            org.apache.xml.serialize.OutputFormat r2 = r2._format
            java.lang.String r3 = "xml"
            r2.setMethod(r3)
            return
        L_0x001c:
            org.apache.xml.serialize.OutputFormat r3 = new org.apache.xml.serialize.OutputFormat
            r8 = r3
            r3 = r8
            r4 = r8
            java.lang.String r5 = "xml"
            r6 = 0
            r7 = 0
            r4.<init>((java.lang.String) r5, (java.lang.String) r6, (boolean) r7)
            goto L_0x0007
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.XMLSerializer.<init>(org.apache.xml.serialize.OutputFormat):void");
    }

    private Attributes extractNamespaces(Attributes attributes) throws SAXException {
        AttributesImpl attributesImpl;
        Attributes attributes2 = attributes;
        if (attributes2 == null) {
            return null;
        }
        int length = attributes2.getLength();
        new AttributesImpl(attributes2);
        AttributesImpl attributesImpl2 = attributesImpl;
        for (int i = length - 1; i >= 0; i--) {
            String qName = attributesImpl2.getQName(i);
            if (qName.startsWith("xmlns")) {
                if (qName.length() == 5) {
                    startPrefixMapping("", attributes2.getValue(i));
                    attributesImpl2.removeAttribute(i);
                } else if (qName.charAt(5) == ':') {
                    startPrefixMapping(qName.substring(6), attributes2.getValue(i));
                    attributesImpl2.removeAttribute(i);
                }
            }
        }
        return attributesImpl2;
    }

    private void printAttribute(String str, String str2, boolean z, Attr attr) throws IOException {
        String str3 = str;
        String str4 = str2;
        Attr attr2 = attr;
        if (z || (this.features & 64) == 0) {
            if (!(this.fDOMFilter == null || (this.fDOMFilter.getWhatToShow() & 2) == 0)) {
                switch (this.fDOMFilter.acceptNode(attr2)) {
                    case 2:
                    case 3:
                        return;
                }
            }
            this._printer.printSpace();
            this._printer.printText(str3);
            this._printer.printText("=\"");
            printEscaped(str4);
            this._printer.printText('\"');
        }
        if (!str3.equals("xml:space")) {
            return;
        }
        if (str4.equals("preserve")) {
            this.fPreserveSpace = true;
            return;
        }
        this.fPreserveSpace = this._format.getPreserveSpace();
    }

    private void printNamespaceAttr(String str, String str2) throws IOException {
        StringBuffer stringBuffer;
        String str3 = str;
        String str4 = str2;
        this._printer.printSpace();
        if (str3 == XMLSymbols.EMPTY_STRING) {
            this._printer.printText(XMLSymbols.PREFIX_XMLNS);
        } else {
            Printer printer = this._printer;
            new StringBuffer();
            printer.printText(stringBuffer.append("xmlns:").append(str3).toString());
        }
        this._printer.printText("=\"");
        printEscaped(str4);
        this._printer.printText('\"');
    }

    /* access modifiers changed from: protected */
    public void checkUnboundNamespacePrefixedNode(Node node) throws IOException {
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        Node node2 = node;
        if (this.fNamespaces) {
            Node firstChild = node2.getFirstChild();
            while (true) {
                Node node3 = firstChild;
                if (node3 != null) {
                    Node nextSibling = node3.getNextSibling();
                    String prefix = node3.getPrefix();
                    String addSymbol = (prefix == null || prefix.length() == 0) ? XMLSymbols.EMPTY_STRING : this.fSymbolTable.addSymbol(prefix);
                    if (this.fNSBinder.getURI(addSymbol) == null && addSymbol != null) {
                        new StringBuffer();
                        fatalError(stringBuffer2.append("The replacement text of the entity node '").append(node2.getNodeName()).append("' contains an element node '").append(node3.getNodeName()).append("' with an undeclared prefix '").append(addSymbol).append("'.").toString());
                    }
                    if (node3.getNodeType() == 1) {
                        NamedNodeMap attributes = node3.getAttributes();
                        for (int i = 0; i < attributes.getLength(); i++) {
                            String prefix2 = attributes.item(i).getPrefix();
                            String addSymbol2 = (prefix2 == null || prefix2.length() == 0) ? XMLSymbols.EMPTY_STRING : this.fSymbolTable.addSymbol(prefix2);
                            if (this.fNSBinder.getURI(addSymbol2) == null && addSymbol2 != null) {
                                new StringBuffer();
                                fatalError(stringBuffer.append("The replacement text of the entity node '").append(node2.getNodeName()).append("' contains an element node '").append(node3.getNodeName()).append("' with an attribute '").append(attributes.item(i).getNodeName()).append("' an undeclared prefix '").append(addSymbol2).append("'.").toString());
                            }
                        }
                    }
                    if (node3.hasChildNodes()) {
                        checkUnboundNamespacePrefixedNode(node3);
                    }
                    firstChild = nextSibling;
                } else {
                    return;
                }
            }
        }
    }

    public void endElement(String str) throws SAXException {
        endElement((String) null, (String) null, str);
    }

    public void endElement(String str, String str2, String str3) throws SAXException {
        Throwable th;
        try {
            endElementIO(str, str2, str3);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    public void endElementIO(String str, String str2, String str3) throws IOException {
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        this._printer.unindent();
        ElementState elementState = getElementState();
        if (elementState.empty) {
            this._printer.printText("/>");
        } else {
            if (elementState.inCData) {
                this._printer.printText("]]>");
            }
            if (this._indenting && !elementState.preserveSpace && (elementState.afterElement || elementState.afterComment)) {
                this._printer.breakLine();
            }
            this._printer.printText("</");
            this._printer.printText(elementState.rawName);
            this._printer.printText('>');
        }
        ElementState leaveElementState = leaveElementState();
        leaveElementState.afterElement = true;
        leaveElementState.afterComment = false;
        leaveElementState.empty = false;
        if (isDocumentState()) {
            this._printer.flush();
        }
    }

    /* access modifiers changed from: protected */
    public String getEntityRef(int i) {
        switch (i) {
            case 34:
                return "quot";
            case 38:
                return "amp";
            case 39:
                return "apos";
            case 60:
                return "lt";
            case 62:
                return "gt";
            default:
                return null;
        }
    }

    /* access modifiers changed from: protected */
    public void printEscaped(String str) throws IOException {
        StringBuffer stringBuffer;
        String str2 = str;
        int length = str2.length();
        int i = 0;
        while (i < length) {
            char charAt = str2.charAt(i);
            if (!XMLChar.isValid(charAt)) {
                i++;
                if (i < length) {
                    surrogates(charAt, str2.charAt(i), false);
                } else {
                    new StringBuffer();
                    fatalError(stringBuffer.append("The character '").append((char) charAt).append("' is an invalid XML character").toString());
                }
            } else if (charAt == 10 || charAt == 13 || charAt == 9) {
                printHex(charAt);
            } else if (charAt == '<') {
                this._printer.printText("&lt;");
            } else if (charAt == '&') {
                this._printer.printText("&amp;");
            } else if (charAt == '\"') {
                this._printer.printText("&quot;");
            } else if (charAt < ' ' || !this._encodingInfo.isPrintable((char) charAt)) {
                printHex(charAt);
            } else {
                this._printer.printText((char) charAt);
            }
            i++;
        }
    }

    /* access modifiers changed from: protected */
    public void printText(String str, boolean z, boolean z2) throws IOException {
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        String str2 = str;
        boolean z3 = z2;
        int length = str2.length();
        if (z) {
            int i = 0;
            while (i < length) {
                char charAt = str2.charAt(i);
                if (!XMLChar.isValid(charAt)) {
                    i++;
                    if (i < length) {
                        surrogates(charAt, str2.charAt(i), true);
                    } else {
                        new StringBuffer();
                        fatalError(stringBuffer2.append("The character '").append(charAt).append("' is an invalid XML character").toString());
                    }
                } else if (z3) {
                    this._printer.printText(charAt);
                } else {
                    printXMLChar(charAt);
                }
                i++;
            }
            return;
        }
        int i2 = 0;
        while (i2 < length) {
            char charAt2 = str2.charAt(i2);
            if (!XMLChar.isValid(charAt2)) {
                i2++;
                if (i2 < length) {
                    surrogates(charAt2, str2.charAt(i2), true);
                } else {
                    new StringBuffer();
                    fatalError(stringBuffer.append("The character '").append(charAt2).append("' is an invalid XML character").toString());
                }
            } else if (z3) {
                this._printer.printText(charAt2);
            } else {
                printXMLChar(charAt2);
            }
            i2++;
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: CFG modification limit reached, blocks count: 134 */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x00a0, code lost:
        new java.lang.StringBuffer();
        fatalError(r11.append("The character '").append(r6).append("' is an invalid XML character").toString());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x00c5, code lost:
        if (r5 == false) goto L_0x00cf;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x00c7, code lost:
        r0._printer.printText(r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x00cf, code lost:
        printXMLChar(r6);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void printText(char[] r13, int r14, int r15, boolean r16, boolean r17) throws java.io.IOException {
        /*
            r12 = this;
            r0 = r12
            r1 = r13
            r2 = r14
            r3 = r15
            r4 = r16
            r5 = r17
            r7 = r4
            if (r7 == 0) goto L_0x0094
        L_0x000b:
            r7 = r3
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 1
            int r8 = r8 + -1
            r3 = r8
            if (r7 > 0) goto L_0x0016
        L_0x0015:
            return
        L_0x0016:
            r7 = r1
            r8 = r2
            int r2 = r2 + 1
            char r7 = r7[r8]
            r6 = r7
            r7 = r6
            boolean r7 = org.apache.xerces.util.XMLChar.isValid(r7)
            if (r7 != 0) goto L_0x005f
            r7 = r3
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 1
            int r8 = r8 + -1
            r3 = r8
            if (r7 <= 0) goto L_0x003b
            r7 = r0
            r8 = r6
            r9 = r1
            r10 = r2
            int r2 = r2 + 1
            char r9 = r9[r10]
            r10 = 1
            r7.surrogates(r8, r9, r10)
            goto L_0x000b
        L_0x003b:
            r7 = r0
            java.lang.StringBuffer r8 = new java.lang.StringBuffer
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            java.lang.String r9 = "The character '"
            java.lang.StringBuffer r8 = r8.append(r9)
            r9 = r6
            java.lang.StringBuffer r8 = r8.append(r9)
            java.lang.String r9 = "' is an invalid XML character"
            java.lang.StringBuffer r8 = r8.append(r9)
            java.lang.String r8 = r8.toString()
            r7.fatalError(r8)
            goto L_0x000b
        L_0x005f:
            r7 = r5
            if (r7 == 0) goto L_0x006a
            r7 = r0
            org.apache.xml.serialize.Printer r7 = r7._printer
            r8 = r6
            r7.printText((char) r8)
            goto L_0x000b
        L_0x006a:
            r7 = r0
            r8 = r6
            r7.printXMLChar(r8)
            goto L_0x000b
        L_0x0070:
            r7 = r1
            r8 = r2
            int r2 = r2 + 1
            char r7 = r7[r8]
            r6 = r7
            r7 = r6
            boolean r7 = org.apache.xerces.util.XMLChar.isValid(r7)
            if (r7 != 0) goto L_0x00c4
            r7 = r3
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 1
            int r8 = r8 + -1
            r3 = r8
            if (r7 <= 0) goto L_0x00a0
            r7 = r0
            r8 = r6
            r9 = r1
            r10 = r2
            int r2 = r2 + 1
            char r9 = r9[r10]
            r10 = 1
            r7.surrogates(r8, r9, r10)
        L_0x0094:
            r7 = r3
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 1
            int r8 = r8 + -1
            r3 = r8
            if (r7 > 0) goto L_0x0070
            goto L_0x0015
        L_0x00a0:
            r7 = r0
            java.lang.StringBuffer r8 = new java.lang.StringBuffer
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            java.lang.String r9 = "The character '"
            java.lang.StringBuffer r8 = r8.append(r9)
            r9 = r6
            java.lang.StringBuffer r8 = r8.append(r9)
            java.lang.String r9 = "' is an invalid XML character"
            java.lang.StringBuffer r8 = r8.append(r9)
            java.lang.String r8 = r8.toString()
            r7.fatalError(r8)
            goto L_0x0094
        L_0x00c4:
            r7 = r5
            if (r7 == 0) goto L_0x00cf
            r7 = r0
            org.apache.xml.serialize.Printer r7 = r7._printer
            r8 = r6
            r7.printText((char) r8)
            goto L_0x0094
        L_0x00cf:
            r7 = r0
            r8 = r6
            r7.printXMLChar(r8)
            goto L_0x0094
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.XMLSerializer.printText(char[], int, int, boolean, boolean):void");
    }

    /* access modifiers changed from: protected */
    public void printXMLChar(int i) throws IOException {
        int i2 = i;
        if (i2 == 13) {
            printHex(i2);
        } else if (i2 == 60) {
            this._printer.printText("&lt;");
        } else if (i2 == 38) {
            this._printer.printText("&amp;");
        } else if (i2 == 62) {
            this._printer.printText("&gt;");
        } else if (i2 == 10 || i2 == 9 || (i2 >= 32 && this._encodingInfo.isPrintable((char) i2))) {
            this._printer.printText((char) i2);
        } else {
            printHex(i2);
        }
    }

    public boolean reset() {
        boolean reset = super.reset();
        if (this.fNSBinder != null) {
            this.fNSBinder.reset();
            boolean declarePrefix = this.fNSBinder.declarePrefix(XMLSymbols.EMPTY_STRING, XMLSymbols.EMPTY_STRING);
        }
        return true;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:176:0x0704, code lost:
        if (r2.fLocalNSBinder.getURI(r12) == null) goto L_0x0706;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void serializeElement(org.w3c.dom.Element r28) throws java.io.IOException {
        /*
            r27 = this;
            r2 = r27
            r3 = r28
            r20 = r2
            r0 = r20
            boolean r0 = r0.fNamespaces
            r20 = r0
            if (r20 == 0) goto L_0x0024
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fLocalNSBinder
            r20 = r0
            r20.reset()
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fNSBinder
            r20 = r0
            r20.pushContext()
        L_0x0024:
            r20 = r3
            java.lang.String r20 = r20.getTagName()
            r11 = r20
            r20 = r2
            org.apache.xml.serialize.ElementState r20 = r20.getElementState()
            r8 = r20
            r20 = r2
            boolean r20 = r20.isDocumentState()
            if (r20 == 0) goto L_0x0131
            r20 = r2
            r0 = r20
            boolean r0 = r0._started
            r20 = r0
            if (r20 != 0) goto L_0x004d
            r20 = r2
            r21 = r11
            r20.startDocument(r21)
        L_0x004d:
            r20 = r2
            r21 = r8
            r0 = r21
            boolean r0 = r0.preserveSpace
            r21 = r0
            r0 = r21
            r1 = r20
            r1.fPreserveSpace = r0
            r20 = 0
            r15 = r20
            r20 = 0
            r5 = r20
            r20 = r3
            boolean r20 = r20.hasAttributes()
            if (r20 == 0) goto L_0x007d
            r20 = r3
            org.w3c.dom.NamedNodeMap r20 = r20.getAttributes()
            r5 = r20
            r20 = r5
            int r20 = r20.getLength()
            r15 = r20
        L_0x007d:
            r20 = r2
            r0 = r20
            boolean r0 = r0.fNamespaces
            r20 = r0
            if (r20 != 0) goto L_0x01e3
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            r21 = 60
            r20.printText((char) r21)
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            r21 = r11
            r20.printText((java.lang.String) r21)
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            r20.indent()
            r20 = 0
            r6 = r20
        L_0x00b0:
            r20 = r6
            r21 = r15
            r0 = r20
            r1 = r21
            if (r0 < r1) goto L_0x01a9
        L_0x00ba:
            r20 = r3
            boolean r20 = r20.hasChildNodes()
            if (r20 == 0) goto L_0x088e
            r20 = r2
            r21 = 0
            r22 = 0
            r23 = r11
            r24 = r2
            r0 = r24
            boolean r0 = r0.fPreserveSpace
            r24 = r0
            org.apache.xml.serialize.ElementState r20 = r20.enterElementState(r21, r22, r23, r24)
            r8 = r20
            r20 = r8
            r21 = r2
            r0 = r21
            org.apache.xml.serialize.OutputFormat r0 = r0._format
            r21 = r0
            r22 = r11
            boolean r21 = r21.isCDataElement(r22)
            r0 = r21
            r1 = r20
            r1.doCData = r0
            r20 = r8
            r21 = r2
            r0 = r21
            org.apache.xml.serialize.OutputFormat r0 = r0._format
            r21 = r0
            r22 = r11
            boolean r21 = r21.isNonEscapingElement(r22)
            r0 = r21
            r1 = r20
            r1.unescaped = r0
            r20 = r3
            org.w3c.dom.Node r20 = r20.getFirstChild()
            r7 = r20
        L_0x010c:
            r20 = r7
            if (r20 != 0) goto L_0x087d
            r20 = r2
            r0 = r20
            boolean r0 = r0.fNamespaces
            r20 = r0
            if (r20 == 0) goto L_0x0125
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fNSBinder
            r20 = r0
            r20.popContext()
        L_0x0125:
            r20 = r2
            r21 = 0
            r22 = 0
            r23 = r11
            r20.endElementIO(r21, r22, r23)
        L_0x0130:
            return
        L_0x0131:
            r20 = r8
            r0 = r20
            boolean r0 = r0.empty
            r20 = r0
            if (r20 == 0) goto L_0x0148
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            r21 = 62
            r20.printText((char) r21)
        L_0x0148:
            r20 = r8
            r0 = r20
            boolean r0 = r0.inCData
            r20 = r0
            if (r20 == 0) goto L_0x016a
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            java.lang.String r21 = "]]>"
            r20.printText((java.lang.String) r21)
            r20 = r8
            r21 = 0
            r0 = r21
            r1 = r20
            r1.inCData = r0
        L_0x016a:
            r20 = r2
            r0 = r20
            boolean r0 = r0._indenting
            r20 = r0
            if (r20 == 0) goto L_0x004d
            r20 = r8
            r0 = r20
            boolean r0 = r0.preserveSpace
            r20 = r0
            if (r20 != 0) goto L_0x004d
            r20 = r8
            r0 = r20
            boolean r0 = r0.empty
            r20 = r0
            if (r20 != 0) goto L_0x019c
            r20 = r8
            r0 = r20
            boolean r0 = r0.afterElement
            r20 = r0
            if (r20 != 0) goto L_0x019c
            r20 = r8
            r0 = r20
            boolean r0 = r0.afterComment
            r20 = r0
            if (r20 == 0) goto L_0x004d
        L_0x019c:
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            r20.breakLine()
            goto L_0x004d
        L_0x01a9:
            r20 = r5
            r21 = r6
            org.w3c.dom.Node r20 = r20.item(r21)
            org.w3c.dom.Attr r20 = (org.w3c.dom.Attr) r20
            r4 = r20
            r20 = r4
            java.lang.String r20 = r20.getName()
            r9 = r20
            r20 = r4
            java.lang.String r20 = r20.getValue()
            r10 = r20
            r20 = r10
            if (r20 != 0) goto L_0x01ce
            java.lang.String r20 = ""
            r10 = r20
        L_0x01ce:
            r20 = r2
            r21 = r9
            r22 = r10
            r23 = r4
            boolean r23 = r23.getSpecified()
            r24 = r4
            r20.printAttribute(r21, r22, r23, r24)
            int r6 = r6 + 1
            goto L_0x00b0
        L_0x01e3:
            r20 = 0
            r6 = r20
        L_0x01e7:
            r20 = r6
            r21 = r15
            r0 = r20
            r1 = r21
            if (r0 < r1) goto L_0x0391
            r20 = r3
            java.lang.String r20 = r20.getNamespaceURI()
            r14 = r20
            r20 = r3
            java.lang.String r20 = r20.getPrefix()
            r12 = r20
            r20 = r14
            if (r20 == 0) goto L_0x04b7
            r20 = r12
            if (r20 == 0) goto L_0x04b7
            r20 = r14
            int r20 = r20.length()
            if (r20 != 0) goto L_0x04b7
            r20 = r12
            int r20 = r20.length()
            if (r20 == 0) goto L_0x04b7
            r20 = 0
            r12 = r20
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            r21 = 60
            r20.printText((char) r21)
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            r21 = r3
            java.lang.String r21 = r21.getLocalName()
            r20.printText((java.lang.String) r21)
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            r20.indent()
        L_0x0246:
            r20 = r14
            if (r20 == 0) goto L_0x0523
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r14
            java.lang.String r20 = r20.addSymbol(r21)
            r14 = r20
            r20 = r12
            if (r20 == 0) goto L_0x0266
            r20 = r12
            int r20 = r20.length()
            if (r20 != 0) goto L_0x04de
        L_0x0266:
            java.lang.String r20 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
        L_0x0268:
            r12 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fNSBinder
            r20 = r0
            r21 = r12
            java.lang.String r20 = r20.getURI(r21)
            r21 = r14
            r0 = r20
            r1 = r21
            if (r0 != r1) goto L_0x04ee
        L_0x0280:
            r20 = 0
            r6 = r20
        L_0x0284:
            r20 = r6
            r21 = r15
            r0 = r20
            r1 = r21
            if (r0 >= r1) goto L_0x00ba
            r20 = r5
            r21 = r6
            org.w3c.dom.Node r20 = r20.item(r21)
            org.w3c.dom.Attr r20 = (org.w3c.dom.Attr) r20
            r4 = r20
            r20 = r4
            java.lang.String r20 = r20.getValue()
            r10 = r20
            r20 = r4
            java.lang.String r20 = r20.getNodeName()
            r9 = r20
            r20 = r4
            java.lang.String r20 = r20.getNamespaceURI()
            r14 = r20
            r20 = r14
            if (r20 == 0) goto L_0x02ca
            r20 = r14
            int r20 = r20.length()
            if (r20 != 0) goto L_0x02ca
            r20 = 0
            r14 = r20
            r20 = r4
            java.lang.String r20 = r20.getLocalName()
            r9 = r20
        L_0x02ca:
            r20 = r10
            if (r20 != 0) goto L_0x02d2
            java.lang.String r20 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            r10 = r20
        L_0x02d2:
            r20 = r14
            if (r20 == 0) goto L_0x07e1
            r20 = r4
            java.lang.String r20 = r20.getPrefix()
            r12 = r20
            r20 = r12
            if (r20 != 0) goto L_0x05ea
            java.lang.String r20 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
        L_0x02e4:
            r12 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r4
            java.lang.String r21 = r21.getLocalName()
            java.lang.String r20 = r20.addSymbol(r21)
            r16 = r20
            r20 = r14
            if (r20 == 0) goto L_0x0653
            r20 = r14
            java.lang.String r21 = org.apache.xerces.xni.NamespaceContext.XMLNS_URI
            boolean r20 = r20.equals(r21)
            if (r20 == 0) goto L_0x0653
            r20 = r4
            java.lang.String r20 = r20.getPrefix()
            r12 = r20
            r20 = r12
            if (r20 == 0) goto L_0x031c
            r20 = r12
            int r20 = r20.length()
            if (r20 != 0) goto L_0x05fa
        L_0x031c:
            java.lang.String r20 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
        L_0x031e:
            r12 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r4
            java.lang.String r21 = r21.getLocalName()
            java.lang.String r20 = r20.addSymbol(r21)
            r16 = r20
            r20 = r12
            java.lang.String r21 = org.apache.xerces.util.XMLSymbols.PREFIX_XMLNS
            r0 = r20
            r1 = r21
            if (r0 != r1) goto L_0x060a
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fLocalNSBinder
            r20 = r0
            r21 = r16
            java.lang.String r20 = r20.getURI(r21)
            r13 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r10
            java.lang.String r20 = r20.addSymbol(r21)
            r10 = r20
            r20 = r10
            int r20 = r20.length()
            if (r20 == 0) goto L_0x038d
            r20 = r13
            if (r20 != 0) goto L_0x038d
            r20 = r2
            r0 = r20
            boolean r0 = r0.fNamespacePrefixes
            r20 = r0
            if (r20 == 0) goto L_0x037d
            r20 = r2
            r21 = r16
            r22 = r10
            r20.printNamespaceAttr(r21, r22)
        L_0x037d:
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fLocalNSBinder
            r20 = r0
            r21 = r16
            r22 = r10
            boolean r20 = r20.declarePrefix(r21, r22)
        L_0x038d:
            int r6 = r6 + 1
            goto L_0x0284
        L_0x0391:
            r20 = r5
            r21 = r6
            org.w3c.dom.Node r20 = r20.item(r21)
            org.w3c.dom.Attr r20 = (org.w3c.dom.Attr) r20
            r4 = r20
            r20 = r4
            java.lang.String r20 = r20.getNamespaceURI()
            r14 = r20
            r20 = r14
            if (r20 == 0) goto L_0x0483
            r20 = r14
            java.lang.String r21 = org.apache.xerces.xni.NamespaceContext.XMLNS_URI
            boolean r20 = r20.equals(r21)
            if (r20 == 0) goto L_0x0483
            r20 = r4
            java.lang.String r20 = r20.getNodeValue()
            r10 = r20
            r20 = r10
            if (r20 != 0) goto L_0x03c3
            java.lang.String r20 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            r10 = r20
        L_0x03c3:
            r20 = r10
            java.lang.String r21 = org.apache.xerces.xni.NamespaceContext.XMLNS_URI
            boolean r20 = r20.equals(r21)
            if (r20 == 0) goto L_0x0425
            r20 = r2
            r0 = r20
            org.w3c.dom.DOMErrorHandler r0 = r0.fDOMErrorHandler
            r20 = r0
            if (r20 == 0) goto L_0x0483
            java.lang.String r20 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            java.lang.String r21 = "CantBindXMLNS"
            r22 = 0
            java.lang.String r20 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r20, r21, r22)
            r16 = r20
            r20 = r2
            r21 = r16
            r22 = 2
            r23 = 0
            r24 = r4
            org.w3c.dom.DOMError r20 = r20.modifyDOMError(r21, r22, r23, r24)
            r20 = r2
            r0 = r20
            org.w3c.dom.DOMErrorHandler r0 = r0.fDOMErrorHandler
            r20 = r0
            r21 = r2
            r0 = r21
            org.apache.xerces.dom.DOMErrorImpl r0 = r0.fDOMError
            r21 = r0
            boolean r20 = r20.handleError(r21)
            r17 = r20
            r20 = r17
            if (r20 != 0) goto L_0x0483
            java.lang.RuntimeException r20 = new java.lang.RuntimeException
            r26 = r20
            r20 = r26
            r21 = r26
            java.lang.String r22 = "http://apache.org/xml/serializer"
            java.lang.String r23 = "SerializationStopped"
            r24 = 0
            java.lang.String r22 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r22, r23, r24)
            r21.<init>(r22)
            throw r20
        L_0x0425:
            r20 = r4
            java.lang.String r20 = r20.getPrefix()
            r12 = r20
            r20 = r12
            if (r20 == 0) goto L_0x0439
            r20 = r12
            int r20 = r20.length()
            if (r20 != 0) goto L_0x0487
        L_0x0439:
            java.lang.String r20 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
        L_0x043b:
            r12 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r4
            java.lang.String r21 = r21.getLocalName()
            java.lang.String r20 = r20.addSymbol(r21)
            r16 = r20
            r20 = r12
            java.lang.String r21 = org.apache.xerces.util.XMLSymbols.PREFIX_XMLNS
            r0 = r20
            r1 = r21
            if (r0 != r1) goto L_0x0496
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r10
            java.lang.String r20 = r20.addSymbol(r21)
            r10 = r20
            r20 = r10
            int r20 = r20.length()
            if (r20 == 0) goto L_0x0483
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fNSBinder
            r20 = r0
            r21 = r16
            r22 = r10
            boolean r20 = r20.declarePrefix(r21, r22)
        L_0x0483:
            int r6 = r6 + 1
            goto L_0x01e7
        L_0x0487:
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r12
            java.lang.String r20 = r20.addSymbol(r21)
            goto L_0x043b
        L_0x0496:
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r10
            java.lang.String r20 = r20.addSymbol(r21)
            r10 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fNSBinder
            r20 = r0
            java.lang.String r21 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            r22 = r10
            boolean r20 = r20.declarePrefix(r21, r22)
            goto L_0x0483
        L_0x04b7:
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            r21 = 60
            r20.printText((char) r21)
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            r21 = r11
            r20.printText((java.lang.String) r21)
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            r20.indent()
            goto L_0x0246
        L_0x04de:
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r12
            java.lang.String r20 = r20.addSymbol(r21)
            goto L_0x0268
        L_0x04ee:
            r20 = r2
            r0 = r20
            boolean r0 = r0.fNamespacePrefixes
            r20 = r0
            if (r20 == 0) goto L_0x0501
            r20 = r2
            r21 = r12
            r22 = r14
            r20.printNamespaceAttr(r21, r22)
        L_0x0501:
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fLocalNSBinder
            r20 = r0
            r21 = r12
            r22 = r14
            boolean r20 = r20.declarePrefix(r21, r22)
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fNSBinder
            r20 = r0
            r21 = r12
            r22 = r14
            boolean r20 = r20.declarePrefix(r21, r22)
            goto L_0x0280
        L_0x0523:
            r20 = r3
            java.lang.String r20 = r20.getLocalName()
            if (r20 != 0) goto L_0x0599
            r20 = r2
            r0 = r20
            org.w3c.dom.DOMErrorHandler r0 = r0.fDOMErrorHandler
            r20 = r0
            if (r20 == 0) goto L_0x0280
            java.lang.String r20 = "http://www.w3.org/dom/DOMTR"
            java.lang.String r21 = "NullLocalElementName"
            r22 = 1
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r22 = r0
            r26 = r22
            r22 = r26
            r23 = r26
            r24 = 0
            r25 = r3
            java.lang.String r25 = r25.getNodeName()
            r23[r24] = r25
            java.lang.String r20 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r20, r21, r22)
            r16 = r20
            r20 = r2
            r21 = r16
            r22 = 2
            r23 = 0
            r24 = r3
            org.w3c.dom.DOMError r20 = r20.modifyDOMError(r21, r22, r23, r24)
            r20 = r2
            r0 = r20
            org.w3c.dom.DOMErrorHandler r0 = r0.fDOMErrorHandler
            r20 = r0
            r21 = r2
            r0 = r21
            org.apache.xerces.dom.DOMErrorImpl r0 = r0.fDOMError
            r21 = r0
            boolean r20 = r20.handleError(r21)
            r17 = r20
            r20 = r17
            if (r20 != 0) goto L_0x0280
            java.lang.RuntimeException r20 = new java.lang.RuntimeException
            r26 = r20
            r20 = r26
            r21 = r26
            java.lang.String r22 = "http://apache.org/xml/serializer"
            java.lang.String r23 = "SerializationStopped"
            r24 = 0
            java.lang.String r22 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r22, r23, r24)
            r21.<init>(r22)
            throw r20
        L_0x0599:
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fNSBinder
            r20 = r0
            java.lang.String r21 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            java.lang.String r20 = r20.getURI(r21)
            r14 = r20
            r20 = r14
            if (r20 == 0) goto L_0x0280
            r20 = r14
            int r20 = r20.length()
            if (r20 <= 0) goto L_0x0280
            r20 = r2
            r0 = r20
            boolean r0 = r0.fNamespacePrefixes
            r20 = r0
            if (r20 == 0) goto L_0x05c8
            r20 = r2
            java.lang.String r21 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            java.lang.String r22 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            r20.printNamespaceAttr(r21, r22)
        L_0x05c8:
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fLocalNSBinder
            r20 = r0
            java.lang.String r21 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            java.lang.String r22 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            boolean r20 = r20.declarePrefix(r21, r22)
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fNSBinder
            r20 = r0
            java.lang.String r21 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            java.lang.String r22 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            boolean r20 = r20.declarePrefix(r21, r22)
            goto L_0x0280
        L_0x05ea:
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r12
            java.lang.String r20 = r20.addSymbol(r21)
            goto L_0x02e4
        L_0x05fa:
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r12
            java.lang.String r20 = r20.addSymbol(r21)
            goto L_0x031e
        L_0x060a:
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fNSBinder
            r20 = r0
            java.lang.String r21 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            java.lang.String r20 = r20.getURI(r21)
            r14 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fLocalNSBinder
            r20 = r0
            java.lang.String r21 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            java.lang.String r20 = r20.getURI(r21)
            r13 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r10
            java.lang.String r20 = r20.addSymbol(r21)
            r10 = r20
            r20 = r13
            if (r20 != 0) goto L_0x038d
            r20 = r2
            r0 = r20
            boolean r0 = r0.fNamespacePrefixes
            r20 = r0
            if (r20 == 0) goto L_0x038d
            r20 = r2
            java.lang.String r21 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            r22 = r10
            r20.printNamespaceAttr(r21, r22)
            goto L_0x038d
        L_0x0653:
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r14
            java.lang.String r20 = r20.addSymbol(r21)
            r14 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fNSBinder
            r20 = r0
            r21 = r12
            java.lang.String r20 = r20.getURI(r21)
            r17 = r20
            r20 = r12
            java.lang.String r21 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            r0 = r20
            r1 = r21
            if (r0 == r1) goto L_0x0687
            r20 = r17
            r21 = r14
            r0 = r20
            r1 = r21
            if (r0 == r1) goto L_0x06d5
        L_0x0687:
            r20 = r4
            java.lang.String r20 = r20.getNodeName()
            r9 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fNSBinder
            r20 = r0
            r21 = r14
            java.lang.String r20 = r20.getPrefix(r21)
            r18 = r20
            r20 = r18
            if (r20 == 0) goto L_0x06ec
            r20 = r18
            java.lang.String r21 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            r0 = r20
            r1 = r21
            if (r0 == r1) goto L_0x06ec
            r20 = r18
            r12 = r20
            java.lang.StringBuffer r20 = new java.lang.StringBuffer
            r26 = r20
            r20 = r26
            r21 = r26
            r21.<init>()
            r21 = r12
            java.lang.StringBuffer r20 = r20.append(r21)
            java.lang.String r21 = ":"
            java.lang.StringBuffer r20 = r20.append(r21)
            r21 = r16
            java.lang.StringBuffer r20 = r20.append(r21)
            java.lang.String r20 = r20.toString()
            r9 = r20
        L_0x06d5:
            r20 = r2
            r21 = r9
            r22 = r10
            if (r22 != 0) goto L_0x07dd
            java.lang.String r22 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
        L_0x06df:
            r23 = r4
            boolean r23 = r23.getSpecified()
            r24 = r4
            r20.printAttribute(r21, r22, r23, r24)
            goto L_0x038d
        L_0x06ec:
            r20 = r12
            java.lang.String r21 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            r0 = r20
            r1 = r21
            if (r0 == r1) goto L_0x074a
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fLocalNSBinder
            r20 = r0
            r21 = r12
            java.lang.String r20 = r20.getURI(r21)
            if (r20 != 0) goto L_0x074a
        L_0x0706:
            r20 = r2
            r0 = r20
            boolean r0 = r0.fNamespacePrefixes
            r20 = r0
            if (r20 == 0) goto L_0x0719
            r20 = r2
            r21 = r12
            r22 = r14
            r20.printNamespaceAttr(r21, r22)
        L_0x0719:
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r10
            java.lang.String r20 = r20.addSymbol(r21)
            r10 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fLocalNSBinder
            r20 = r0
            r21 = r12
            r22 = r10
            boolean r20 = r20.declarePrefix(r21, r22)
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fNSBinder
            r20 = r0
            r21 = r12
            r22 = r14
            boolean r20 = r20.declarePrefix(r21, r22)
            goto L_0x06d5
        L_0x074a:
            r20 = 1
            r19 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            java.lang.StringBuffer r21 = new java.lang.StringBuffer
            r26 = r21
            r21 = r26
            r22 = r26
            r22.<init>()
            java.lang.String r22 = "NS"
            java.lang.StringBuffer r21 = r21.append(r22)
            r22 = r19
            int r19 = r19 + 1
            java.lang.StringBuffer r21 = r21.append(r22)
            java.lang.String r21 = r21.toString()
            java.lang.String r20 = r20.addSymbol(r21)
            r12 = r20
        L_0x077a:
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fLocalNSBinder
            r20 = r0
            r21 = r12
            java.lang.String r20 = r20.getURI(r21)
            if (r20 != 0) goto L_0x07b0
            java.lang.StringBuffer r20 = new java.lang.StringBuffer
            r26 = r20
            r20 = r26
            r21 = r26
            r21.<init>()
            r21 = r12
            java.lang.StringBuffer r20 = r20.append(r21)
            java.lang.String r21 = ":"
            java.lang.StringBuffer r20 = r20.append(r21)
            r21 = r16
            java.lang.StringBuffer r20 = r20.append(r21)
            java.lang.String r20 = r20.toString()
            r9 = r20
            goto L_0x0706
        L_0x07b0:
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            java.lang.StringBuffer r21 = new java.lang.StringBuffer
            r26 = r21
            r21 = r26
            r22 = r26
            r22.<init>()
            java.lang.String r22 = "NS"
            java.lang.StringBuffer r21 = r21.append(r22)
            r22 = r19
            int r19 = r19 + 1
            java.lang.StringBuffer r21 = r21.append(r22)
            java.lang.String r21 = r21.toString()
            java.lang.String r20 = r20.addSymbol(r21)
            r12 = r20
            goto L_0x077a
        L_0x07dd:
            r22 = r10
            goto L_0x06df
        L_0x07e1:
            r20 = r4
            java.lang.String r20 = r20.getLocalName()
            if (r20 != 0) goto L_0x086a
            r20 = r2
            r0 = r20
            org.w3c.dom.DOMErrorHandler r0 = r0.fDOMErrorHandler
            r20 = r0
            if (r20 == 0) goto L_0x0857
            java.lang.String r20 = "http://www.w3.org/dom/DOMTR"
            java.lang.String r21 = "NullLocalAttrName"
            r22 = 1
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r22 = r0
            r26 = r22
            r22 = r26
            r23 = r26
            r24 = 0
            r25 = r4
            java.lang.String r25 = r25.getNodeName()
            r23[r24] = r25
            java.lang.String r20 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r20, r21, r22)
            r16 = r20
            r20 = r2
            r21 = r16
            r22 = 2
            r23 = 0
            r24 = r4
            org.w3c.dom.DOMError r20 = r20.modifyDOMError(r21, r22, r23, r24)
            r20 = r2
            r0 = r20
            org.w3c.dom.DOMErrorHandler r0 = r0.fDOMErrorHandler
            r20 = r0
            r21 = r2
            r0 = r21
            org.apache.xerces.dom.DOMErrorImpl r0 = r0.fDOMError
            r21 = r0
            boolean r20 = r20.handleError(r21)
            r17 = r20
            r20 = r17
            if (r20 != 0) goto L_0x0857
            java.lang.RuntimeException r20 = new java.lang.RuntimeException
            r26 = r20
            r20 = r26
            r21 = r26
            java.lang.String r22 = "http://apache.org/xml/serializer"
            java.lang.String r23 = "SerializationStopped"
            r24 = 0
            java.lang.String r22 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r22, r23, r24)
            r21.<init>(r22)
            throw r20
        L_0x0857:
            r20 = r2
            r21 = r9
            r22 = r10
            r23 = r4
            boolean r23 = r23.getSpecified()
            r24 = r4
            r20.printAttribute(r21, r22, r23, r24)
            goto L_0x038d
        L_0x086a:
            r20 = r2
            r21 = r9
            r22 = r10
            r23 = r4
            boolean r23 = r23.getSpecified()
            r24 = r4
            r20.printAttribute(r21, r22, r23, r24)
            goto L_0x038d
        L_0x087d:
            r20 = r2
            r21 = r7
            r20.serializeNode(r21)
            r20 = r7
            org.w3c.dom.Node r20 = r20.getNextSibling()
            r7 = r20
            goto L_0x010c
        L_0x088e:
            r20 = r2
            r0 = r20
            boolean r0 = r0.fNamespaces
            r20 = r0
            if (r20 == 0) goto L_0x08a3
            r20 = r2
            r0 = r20
            org.apache.xerces.util.NamespaceSupport r0 = r0.fNSBinder
            r20 = r0
            r20.popContext()
        L_0x08a3:
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            r20.unindent()
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            java.lang.String r21 = "/>"
            r20.printText((java.lang.String) r21)
            r20 = r8
            r21 = 1
            r0 = r21
            r1 = r20
            r1.afterElement = r0
            r20 = r8
            r21 = 0
            r0 = r21
            r1 = r20
            r1.afterComment = r0
            r20 = r8
            r21 = 0
            r0 = r21
            r1 = r20
            r1.empty = r0
            r20 = r2
            boolean r20 = r20.isDocumentState()
            if (r20 == 0) goto L_0x0130
            r20 = r2
            r0 = r20
            org.apache.xml.serialize.Printer r0 = r0._printer
            r20 = r0
            r20.flush()
            goto L_0x0130
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.XMLSerializer.serializeElement(org.w3c.dom.Element):void");
    }

    public void setNamespaces(boolean z) {
        NamespaceSupport namespaceSupport;
        NamespaceSupport namespaceSupport2;
        SymbolTable symbolTable;
        this.fNamespaces = z;
        if (this.fNSBinder == null) {
            new NamespaceSupport();
            this.fNSBinder = namespaceSupport;
            new NamespaceSupport();
            this.fLocalNSBinder = namespaceSupport2;
            new SymbolTable();
            this.fSymbolTable = symbolTable;
        }
    }

    public void setOutputFormat(OutputFormat outputFormat) {
        OutputFormat outputFormat2;
        OutputFormat outputFormat3;
        OutputFormat outputFormat4 = outputFormat;
        if (outputFormat4 != null) {
            outputFormat3 = outputFormat4;
        } else {
            outputFormat3 = outputFormat2;
            new OutputFormat(Method.XML, (String) null, false);
        }
        super.setOutputFormat(outputFormat3);
    }

    /* access modifiers changed from: protected */
    public void startDocument(String str) throws IOException {
        StringBuffer stringBuffer;
        String str2 = str;
        String leaveDTD = this._printer.leaveDTD();
        if (!this._started) {
            if (!this._format.getOmitXMLDeclaration()) {
                new StringBuffer("<?xml version=\"");
                StringBuffer stringBuffer2 = stringBuffer;
                if (this._format.getVersion() != null) {
                    StringBuffer append = stringBuffer2.append(this._format.getVersion());
                } else {
                    StringBuffer append2 = stringBuffer2.append(BuildConfig.VERSION_NAME);
                }
                StringBuffer append3 = stringBuffer2.append('\"');
                String encoding = this._format.getEncoding();
                if (encoding != null) {
                    StringBuffer append4 = stringBuffer2.append(" encoding=\"");
                    StringBuffer append5 = stringBuffer2.append(encoding);
                    StringBuffer append6 = stringBuffer2.append('\"');
                }
                if (this._format.getStandalone() && this._docTypeSystemId == null && this._docTypePublicId == null) {
                    StringBuffer append7 = stringBuffer2.append(" standalone=\"yes\"");
                }
                StringBuffer append8 = stringBuffer2.append("?>");
                this._printer.printText(stringBuffer2);
                this._printer.breakLine();
            }
            if (!this._format.getOmitDocumentType()) {
                if (this._docTypeSystemId != null) {
                    this._printer.printText("<!DOCTYPE ");
                    this._printer.printText(str2);
                    if (this._docTypePublicId != null) {
                        this._printer.printText(" PUBLIC ");
                        printDoctypeURL(this._docTypePublicId);
                        if (this._indenting) {
                            this._printer.breakLine();
                            for (int i = 0; i < 18 + str2.length(); i++) {
                                this._printer.printText(" ");
                            }
                        } else {
                            this._printer.printText(" ");
                        }
                        printDoctypeURL(this._docTypeSystemId);
                    } else {
                        this._printer.printText(" SYSTEM ");
                        printDoctypeURL(this._docTypeSystemId);
                    }
                    if (leaveDTD != null && leaveDTD.length() > 0) {
                        this._printer.printText(" [");
                        printText(leaveDTD, true, true);
                        this._printer.printText(']');
                    }
                    this._printer.printText(">");
                    this._printer.breakLine();
                } else if (leaveDTD != null && leaveDTD.length() > 0) {
                    this._printer.printText("<!DOCTYPE ");
                    this._printer.printText(str2);
                    this._printer.printText(" [");
                    printText(leaveDTD, true, true);
                    this._printer.printText("]>");
                    this._printer.breakLine();
                }
            }
        }
        this._started = true;
        serializePreRoot();
    }

    public void startElement(String str, String str2, String str3, Attributes attributes) throws SAXException {
        Throwable th;
        String str4;
        StringBuffer stringBuffer;
        String prefix;
        StringBuffer stringBuffer2;
        StringBuffer stringBuffer3;
        Throwable th2;
        Throwable th3;
        String str5 = str;
        String str6 = str2;
        String str7 = str3;
        Attributes attributes2 = attributes;
        try {
            if (this._printer == null) {
                Throwable th4 = th3;
                new IllegalStateException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "NoWriterSupplied", (Object[]) null));
                throw th4;
            }
            ElementState elementState = getElementState();
            if (!isDocumentState()) {
                if (elementState.empty) {
                    this._printer.printText('>');
                }
                if (elementState.inCData) {
                    this._printer.printText("]]>");
                    elementState.inCData = false;
                }
                if (this._indenting && !elementState.preserveSpace && (elementState.empty || elementState.afterElement || elementState.afterComment)) {
                    this._printer.breakLine();
                }
            } else if (!this._started) {
                startDocument((str6 == null || str6.length() == 0) ? str7 : str6);
            }
            boolean z = elementState.preserveSpace;
            Attributes extractNamespaces = extractNamespaces(attributes2);
            if (str7 == null || str7.length() == 0) {
                if (str6 == null) {
                    Throwable th5 = th2;
                    new SAXException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "NoName", (Object[]) null));
                    throw th5;
                } else if (str5 == null || str5.equals("")) {
                    str7 = str6;
                } else {
                    String prefix2 = getPrefix(str5);
                    if (prefix2 == null || prefix2.length() <= 0) {
                        str7 = str6;
                    } else {
                        new StringBuffer();
                        str7 = stringBuffer3.append(prefix2).append(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR).append(str6).toString();
                    }
                }
            }
            this._printer.printText('<');
            this._printer.printText(str7);
            this._printer.indent();
            if (extractNamespaces != null) {
                for (int i = 0; i < extractNamespaces.getLength(); i++) {
                    this._printer.printSpace();
                    String qName = extractNamespaces.getQName(i);
                    if (qName != null && qName.length() == 0) {
                        qName = extractNamespaces.getLocalName(i);
                        String uri = extractNamespaces.getURI(i);
                        if (!(uri == null || uri.length() == 0 || ((str5 != null && str5.length() != 0 && uri.equals(str5)) || (prefix = getPrefix(uri)) == null || prefix.length() <= 0))) {
                            new StringBuffer();
                            qName = stringBuffer2.append(prefix).append(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR).append(qName).toString();
                        }
                    }
                    String value = extractNamespaces.getValue(i);
                    if (value == null) {
                        value = "";
                    }
                    this._printer.printText(qName);
                    this._printer.printText("=\"");
                    printEscaped(value);
                    this._printer.printText('\"');
                    if (qName.equals("xml:space")) {
                        z = value.equals("preserve") ? true : this._format.getPreserveSpace();
                    }
                }
            }
            if (this._prefixes != null) {
                for (Map.Entry entry : this._prefixes.entrySet()) {
                    this._printer.printSpace();
                    String str8 = (String) entry.getKey();
                    String str9 = (String) entry.getValue();
                    if (str9.length() == 0) {
                        this._printer.printText("xmlns=\"");
                        printEscaped(str8);
                        this._printer.printText('\"');
                    } else {
                        this._printer.printText("xmlns:");
                        this._printer.printText(str9);
                        this._printer.printText("=\"");
                        printEscaped(str8);
                        this._printer.printText('\"');
                    }
                }
            }
            ElementState enterElementState = enterElementState(str5, str6, str7, z);
            if (str6 == null || str6.length() == 0) {
                str4 = str7;
            } else {
                new StringBuffer();
                str4 = stringBuffer.append(str5).append("^").append(str6).toString();
            }
            String str10 = str4;
            enterElementState.doCData = this._format.isCDataElement(str10);
            enterElementState.unescaped = this._format.isNonEscapingElement(str10);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th6 = th;
            new SAXException(iOException);
            throw th6;
        }
    }

    public void startElement(String str, AttributeList attributeList) throws SAXException {
        Throwable th;
        Throwable th2;
        String str2 = str;
        AttributeList attributeList2 = attributeList;
        try {
            if (this._printer == null) {
                Throwable th3 = th2;
                new IllegalStateException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.SERIALIZER_DOMAIN, "NoWriterSupplied", (Object[]) null));
                throw th3;
            }
            ElementState elementState = getElementState();
            if (!isDocumentState()) {
                if (elementState.empty) {
                    this._printer.printText('>');
                }
                if (elementState.inCData) {
                    this._printer.printText("]]>");
                    elementState.inCData = false;
                }
                if (this._indenting && !elementState.preserveSpace && (elementState.empty || elementState.afterElement || elementState.afterComment)) {
                    this._printer.breakLine();
                }
            } else if (!this._started) {
                startDocument(str2);
            }
            boolean z = elementState.preserveSpace;
            this._printer.printText('<');
            this._printer.printText(str2);
            this._printer.indent();
            if (attributeList2 != null) {
                for (int i = 0; i < attributeList2.getLength(); i++) {
                    this._printer.printSpace();
                    String name = attributeList2.getName(i);
                    String value = attributeList2.getValue(i);
                    if (value != null) {
                        this._printer.printText(name);
                        this._printer.printText("=\"");
                        printEscaped(value);
                        this._printer.printText('\"');
                    }
                    if (name.equals("xml:space")) {
                        z = value.equals("preserve") ? true : this._format.getPreserveSpace();
                    }
                }
            }
            ElementState enterElementState = enterElementState((String) null, (String) null, str2, z);
            enterElementState.doCData = this._format.isCDataElement(str2);
            enterElementState.unescaped = this._format.isNonEscapingElement(str2);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th4 = th;
            new SAXException(iOException);
            throw th4;
        }
    }
}
