package org.apache.xml.serialize;

import java.io.IOException;
import net.lingala.zip4j.util.Zip4jConstants;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.AttributeList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class TextSerializer extends BaseMarkupSerializer {
    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public TextSerializer() {
        /*
            r8 = this;
            r0 = r8
            r1 = r0
            org.apache.xml.serialize.OutputFormat r2 = new org.apache.xml.serialize.OutputFormat
            r7 = r2
            r2 = r7
            r3 = r7
            java.lang.String r4 = "text"
            r5 = 0
            r6 = 0
            r3.<init>((java.lang.String) r4, (java.lang.String) r5, (boolean) r6)
            r1.<init>(r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xml.serialize.TextSerializer.<init>():void");
    }

    /* access modifiers changed from: protected */
    public void characters(String str, boolean z) throws IOException {
        boolean z2 = z;
        ElementState content = content();
        content.inCData = false;
        content.doCData = false;
        printText(str, true, true);
    }

    public void characters(char[] cArr, int i, int i2) throws SAXException {
        Throwable th;
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        try {
            ElementState content = content();
            content.inCData = false;
            content.doCData = false;
            printText(cArr2, i3, i4, true, true);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    public void comment(String str) {
    }

    public void comment(char[] cArr, int i, int i2) {
    }

    /* access modifiers changed from: protected */
    public ElementState content() {
        ElementState elementState = getElementState();
        if (!isDocumentState()) {
            if (elementState.empty) {
                elementState.empty = false;
            }
            elementState.afterElement = false;
        }
        return elementState;
    }

    public void endElement(String str) throws SAXException {
        Throwable th;
        try {
            endElementIO(str);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }

    public void endElement(String str, String str2, String str3) throws SAXException {
        String str4 = str;
        String str5 = str3;
        endElement(str5 == null ? str2 : str5);
    }

    public void endElementIO(String str) throws IOException {
        String str2 = str;
        ElementState elementState = getElementState();
        ElementState leaveElementState = leaveElementState();
        leaveElementState.afterElement = true;
        leaveElementState.empty = false;
        if (isDocumentState()) {
            this._printer.flush();
        }
    }

    /* access modifiers changed from: protected */
    public String getEntityRef(int i) {
        int i2 = i;
        return null;
    }

    public void processingInstructionIO(String str, String str2) throws IOException {
    }

    /* access modifiers changed from: protected */
    public void serializeElement(Element element) throws IOException {
        Element element2 = element;
        String tagName = element2.getTagName();
        ElementState elementState = getElementState();
        if (isDocumentState() && !this._started) {
            startDocument(tagName);
        }
        boolean z = elementState.preserveSpace;
        if (element2.hasChildNodes()) {
            ElementState enterElementState = enterElementState((String) null, (String) null, tagName, z);
            Node firstChild = element2.getFirstChild();
            while (true) {
                Node node = firstChild;
                if (node == null) {
                    endElementIO(tagName);
                    return;
                } else {
                    serializeNode(node);
                    firstChild = node.getNextSibling();
                }
            }
        } else if (!isDocumentState()) {
            elementState.afterElement = true;
            elementState.empty = false;
        }
    }

    /* access modifiers changed from: protected */
    public void serializeNode(Node node) throws IOException {
        Node node2 = node;
        switch (node2.getNodeType()) {
            case 1:
                serializeElement((Element) node2);
                return;
            case 3:
                if (node2.getNodeValue() != null) {
                    characters(node2.getNodeValue(), true);
                    return;
                }
                return;
            case 4:
                if (node2.getNodeValue() != null) {
                    characters(node2.getNodeValue(), true);
                    return;
                }
                return;
            case Zip4jConstants.DEFLATE_LEVEL_ULTRA:
            case 11:
                Node firstChild = node2.getFirstChild();
                while (true) {
                    Node node3 = firstChild;
                    if (node3 != null) {
                        serializeNode(node3);
                        firstChild = node3.getNextSibling();
                    } else {
                        return;
                    }
                }
            default:
                return;
        }
    }

    public void setOutputFormat(OutputFormat outputFormat) {
        OutputFormat outputFormat2;
        OutputFormat outputFormat3;
        OutputFormat outputFormat4 = outputFormat;
        if (outputFormat4 != null) {
            outputFormat3 = outputFormat4;
        } else {
            outputFormat3 = outputFormat2;
            new OutputFormat(Method.TEXT, (String) null, false);
        }
        super.setOutputFormat(outputFormat3);
    }

    /* access modifiers changed from: protected */
    public void startDocument(String str) throws IOException {
        String str2 = str;
        String leaveDTD = this._printer.leaveDTD();
        this._started = true;
        serializePreRoot();
    }

    public void startElement(String str, String str2, String str3, Attributes attributes) throws SAXException {
        String str4 = str;
        String str5 = str3;
        Attributes attributes2 = attributes;
        startElement(str5 == null ? str2 : str5, (AttributeList) null);
    }

    public void startElement(String str, AttributeList attributeList) throws SAXException {
        Throwable th;
        String str2 = str;
        AttributeList attributeList2 = attributeList;
        try {
            ElementState elementState = getElementState();
            if (isDocumentState() && !this._started) {
                startDocument(str2);
            }
            ElementState enterElementState = enterElementState((String) null, (String) null, str2, elementState.preserveSpace);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new SAXException(iOException);
            throw th2;
        }
    }
}
