package org.apache.xerces.jaxp.validation;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.xerces.impl.XMLEntityManager;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.impl.validation.ValidationManager;
import org.apache.xerces.impl.xs.XMLSchemaValidator;
import org.apache.xerces.impl.xs.XSMessageFormatter;
import org.apache.xerces.util.DOMEntityResolverWrapper;
import org.apache.xerces.util.ErrorHandlerWrapper;
import org.apache.xerces.util.MessageFormatter;
import org.apache.xerces.util.NamespaceSupport;
import org.apache.xerces.util.ParserConfigurationSettings;
import org.apache.xerces.util.SecurityManager;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLComponent;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.w3c.dom.ls.LSResourceResolver;
import org.xml.sax.ErrorHandler;

final class XMLSchemaValidatorComponentManager extends ParserConfigurationSettings implements XMLComponentManager {
    private static final String DISALLOW_DOCTYPE_DECL_FEATURE = "http://apache.org/xml/features/disallow-doctype-decl";
    private static final String ENTITY_MANAGER = "http://apache.org/xml/properties/internal/entity-manager";
    private static final String ENTITY_RESOLVER = "http://apache.org/xml/properties/internal/entity-resolver";
    private static final String ERROR_HANDLER = "http://apache.org/xml/properties/internal/error-handler";
    private static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
    private static final String IDENTITY_CONSTRAINT_CHECKING = "http://apache.org/xml/features/validation/identity-constraint-checking";
    private static final String ID_IDREF_CHECKING = "http://apache.org/xml/features/validation/id-idref-checking";
    private static final String IGNORE_XSI_TYPE = "http://apache.org/xml/features/validation/schema/ignore-xsi-type-until-elemdecl";
    private static final String LOCALE = "http://apache.org/xml/properties/locale";
    private static final String NAMESPACE_CONTEXT = "http://apache.org/xml/properties/internal/namespace-context";
    private static final String NORMALIZE_DATA = "http://apache.org/xml/features/validation/schema/normalized-value";
    private static final String SCHEMA_AUGMENT_PSVI = "http://apache.org/xml/features/validation/schema/augment-psvi";
    private static final String SCHEMA_ELEMENT_DEFAULT = "http://apache.org/xml/features/validation/schema/element-default";
    private static final String SCHEMA_VALIDATION = "http://apache.org/xml/features/validation/schema";
    private static final String SCHEMA_VALIDATOR = "http://apache.org/xml/properties/internal/validator/schema";
    private static final String SECURITY_MANAGER = "http://apache.org/xml/properties/security-manager";
    private static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    private static final String UNPARSED_ENTITY_CHECKING = "http://apache.org/xml/features/validation/unparsed-entity-checking";
    private static final String USE_GRAMMAR_POOL_ONLY = "http://apache.org/xml/features/internal/validation/schema/use-grammar-pool-only";
    private static final String VALIDATION = "http://xml.org/sax/features/validation";
    private static final String VALIDATION_MANAGER = "http://apache.org/xml/properties/internal/validation-manager";
    private static final String XMLGRAMMAR_POOL = "http://apache.org/xml/properties/internal/grammar-pool";
    private final HashMap fComponents;
    private boolean fConfigUpdated = true;
    private final XMLEntityManager fEntityManager;
    private ErrorHandler fErrorHandler;
    private final XMLErrorReporter fErrorReporter;
    private final HashMap fInitFeatures;
    private final HashMap fInitProperties;
    private final SecurityManager fInitSecurityManager;
    private Locale fLocale;
    private final NamespaceContext fNamespaceContext;
    private LSResourceResolver fResourceResolver;
    private final XMLSchemaValidator fSchemaValidator;
    private boolean fUseGrammarPoolOnly;
    private final ValidationManager fValidationManager;

    public XMLSchemaValidatorComponentManager(XSGrammarPoolContainer xSGrammarPoolContainer) {
        HashMap hashMap;
        HashMap hashMap2;
        HashMap hashMap3;
        XMLEntityManager xMLEntityManager;
        XMLErrorReporter xMLErrorReporter;
        NamespaceContext namespaceContext;
        XMLSchemaValidator xMLSchemaValidator;
        ValidationManager validationManager;
        Object obj;
        MessageFormatter messageFormatter;
        SecurityManager securityManager;
        XSGrammarPoolContainer xSGrammarPoolContainer2 = xSGrammarPoolContainer;
        new HashMap();
        this.fComponents = hashMap;
        new HashMap();
        this.fInitFeatures = hashMap2;
        new HashMap();
        this.fInitProperties = hashMap3;
        this.fErrorHandler = null;
        this.fResourceResolver = null;
        this.fLocale = null;
        new XMLEntityManager();
        this.fEntityManager = xMLEntityManager;
        Object put = this.fComponents.put(ENTITY_MANAGER, this.fEntityManager);
        new XMLErrorReporter();
        this.fErrorReporter = xMLErrorReporter;
        Object put2 = this.fComponents.put(ERROR_REPORTER, this.fErrorReporter);
        new NamespaceSupport();
        this.fNamespaceContext = namespaceContext;
        Object put3 = this.fComponents.put(NAMESPACE_CONTEXT, this.fNamespaceContext);
        new XMLSchemaValidator();
        this.fSchemaValidator = xMLSchemaValidator;
        Object put4 = this.fComponents.put(SCHEMA_VALIDATOR, this.fSchemaValidator);
        new ValidationManager();
        this.fValidationManager = validationManager;
        Object put5 = this.fComponents.put(VALIDATION_MANAGER, this.fValidationManager);
        Object put6 = this.fComponents.put(ENTITY_RESOLVER, (Object) null);
        Object put7 = this.fComponents.put(ERROR_HANDLER, (Object) null);
        Object put8 = this.fComponents.put(SECURITY_MANAGER, (Object) null);
        new SymbolTable();
        Object put9 = this.fComponents.put(SYMBOL_TABLE, obj);
        Object put10 = this.fComponents.put(XMLGRAMMAR_POOL, xSGrammarPoolContainer2.getGrammarPool());
        this.fUseGrammarPoolOnly = xSGrammarPoolContainer2.isFullyComposed();
        new XSMessageFormatter();
        this.fErrorReporter.putMessageFormatter("http://www.w3.org/TR/xml-schema-1", messageFormatter);
        String[] strArr = new String[4];
        strArr[0] = DISALLOW_DOCTYPE_DECL_FEATURE;
        String[] strArr2 = strArr;
        strArr2[1] = NORMALIZE_DATA;
        String[] strArr3 = strArr2;
        strArr3[2] = SCHEMA_ELEMENT_DEFAULT;
        String[] strArr4 = strArr3;
        strArr4[3] = SCHEMA_AUGMENT_PSVI;
        addRecognizedFeatures(strArr4);
        Object put11 = this.fFeatures.put(DISALLOW_DOCTYPE_DECL_FEATURE, Boolean.FALSE);
        Object put12 = this.fFeatures.put(NORMALIZE_DATA, Boolean.FALSE);
        Object put13 = this.fFeatures.put(SCHEMA_ELEMENT_DEFAULT, Boolean.FALSE);
        Object put14 = this.fFeatures.put(SCHEMA_AUGMENT_PSVI, Boolean.TRUE);
        addRecognizedParamsAndSetDefaults(this.fEntityManager, xSGrammarPoolContainer2);
        addRecognizedParamsAndSetDefaults(this.fErrorReporter, xSGrammarPoolContainer2);
        addRecognizedParamsAndSetDefaults(this.fSchemaValidator, xSGrammarPoolContainer2);
        if (Boolean.TRUE.equals(xSGrammarPoolContainer2.getFeature("http://javax.xml.XMLConstants/feature/secure-processing"))) {
            new SecurityManager();
            this.fInitSecurityManager = securityManager;
        } else {
            this.fInitSecurityManager = null;
        }
        Object put15 = this.fComponents.put(SECURITY_MANAGER, this.fInitSecurityManager);
        Object put16 = this.fFeatures.put(IGNORE_XSI_TYPE, Boolean.FALSE);
        Object put17 = this.fFeatures.put(ID_IDREF_CHECKING, Boolean.TRUE);
        Object put18 = this.fFeatures.put(IDENTITY_CONSTRAINT_CHECKING, Boolean.TRUE);
        Object put19 = this.fFeatures.put(UNPARSED_ENTITY_CHECKING, Boolean.TRUE);
    }

    private void setFeatureDefaults(XMLComponent xMLComponent, String[] strArr, XSGrammarPoolContainer xSGrammarPoolContainer) {
        XMLComponent xMLComponent2 = xMLComponent;
        String[] strArr2 = strArr;
        XSGrammarPoolContainer xSGrammarPoolContainer2 = xSGrammarPoolContainer;
        if (strArr2 != null) {
            for (int i = 0; i < strArr2.length; i++) {
                String str = strArr2[i];
                Boolean feature = xSGrammarPoolContainer2.getFeature(str);
                if (feature == null) {
                    feature = xMLComponent2.getFeatureDefault(str);
                }
                if (feature != null && !this.fFeatures.containsKey(str)) {
                    Object put = this.fFeatures.put(str, feature);
                    this.fConfigUpdated = true;
                }
            }
        }
    }

    private void setPropertyDefaults(XMLComponent xMLComponent, String[] strArr) {
        XMLComponent xMLComponent2 = xMLComponent;
        String[] strArr2 = strArr;
        if (strArr2 != null) {
            for (int i = 0; i < strArr2.length; i++) {
                String str = strArr2[i];
                Object propertyDefault = xMLComponent2.getPropertyDefault(str);
                if (propertyDefault != null && !this.fProperties.containsKey(str)) {
                    Object put = this.fProperties.put(str, propertyDefault);
                    this.fConfigUpdated = true;
                }
            }
        }
    }

    public void addRecognizedParamsAndSetDefaults(XMLComponent xMLComponent, XSGrammarPoolContainer xSGrammarPoolContainer) {
        XMLComponent xMLComponent2 = xMLComponent;
        String[] recognizedFeatures = xMLComponent2.getRecognizedFeatures();
        addRecognizedFeatures(recognizedFeatures);
        String[] recognizedProperties = xMLComponent2.getRecognizedProperties();
        addRecognizedProperties(recognizedProperties);
        setFeatureDefaults(xMLComponent2, recognizedFeatures, xSGrammarPoolContainer);
        setPropertyDefaults(xMLComponent2, recognizedProperties);
    }

    /* access modifiers changed from: package-private */
    public ErrorHandler getErrorHandler() {
        return this.fErrorHandler;
    }

    public boolean getFeature(String str) throws XMLConfigurationException {
        String str2 = str;
        if ("http://apache.org/xml/features/internal/parser-settings".equals(str2)) {
            return this.fConfigUpdated;
        }
        if (VALIDATION.equals(str2) || SCHEMA_VALIDATION.equals(str2)) {
            return true;
        }
        if (USE_GRAMMAR_POOL_ONLY.equals(str2)) {
            return this.fUseGrammarPoolOnly;
        }
        if (!"http://javax.xml.XMLConstants/feature/secure-processing".equals(str2)) {
            return super.getFeature(str2);
        }
        return getProperty(SECURITY_MANAGER) != null;
    }

    /* access modifiers changed from: package-private */
    public Locale getLocale() {
        return this.fLocale;
    }

    public Object getProperty(String str) throws XMLConfigurationException {
        String str2 = str;
        if (LOCALE.equals(str2)) {
            return getLocale();
        }
        Object obj = this.fComponents.get(str2);
        if (obj != null) {
            return obj;
        }
        if (this.fComponents.containsKey(str2)) {
            return null;
        }
        return super.getProperty(str2);
    }

    /* access modifiers changed from: package-private */
    public LSResourceResolver getResourceResolver() {
        return this.fResourceResolver;
    }

    public void reset() throws XNIException {
        this.fNamespaceContext.reset();
        this.fValidationManager.reset();
        this.fEntityManager.reset(this);
        this.fErrorReporter.reset(this);
        this.fSchemaValidator.reset(this);
        this.fConfigUpdated = false;
    }

    /* access modifiers changed from: package-private */
    public void restoreInitialState() {
        this.fConfigUpdated = true;
        Object put = this.fComponents.put(ENTITY_RESOLVER, (Object) null);
        Object put2 = this.fComponents.put(ERROR_HANDLER, (Object) null);
        Object put3 = this.fComponents.put(SECURITY_MANAGER, this.fInitSecurityManager);
        setLocale((Locale) null);
        Object put4 = this.fComponents.put(LOCALE, (Object) null);
        if (!this.fInitFeatures.isEmpty()) {
            for (Map.Entry entry : this.fInitFeatures.entrySet()) {
                super.setFeature((String) entry.getKey(), ((Boolean) entry.getValue()).booleanValue());
            }
            this.fInitFeatures.clear();
        }
        if (!this.fInitProperties.isEmpty()) {
            for (Map.Entry entry2 : this.fInitProperties.entrySet()) {
                super.setProperty((String) entry2.getKey(), entry2.getValue());
            }
            this.fInitProperties.clear();
        }
    }

    /* access modifiers changed from: package-private */
    public void setErrorHandler(ErrorHandler errorHandler) {
        Object obj;
        Object obj2;
        Object obj3;
        ErrorHandler errorHandler2 = errorHandler;
        this.fErrorHandler = errorHandler2;
        if (errorHandler2 != null) {
            obj2 = obj3;
            new ErrorHandlerWrapper(errorHandler2);
        } else {
            obj2 = obj;
            new ErrorHandlerWrapper(DraconianErrorHandler.getInstance());
        }
        setProperty(ERROR_HANDLER, obj2);
    }

    public void setFeature(String str, boolean z) throws XMLConfigurationException {
        Object obj;
        Object obj2;
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        boolean z2 = z;
        if ("http://apache.org/xml/features/internal/parser-settings".equals(str2)) {
            Throwable th4 = th3;
            new XMLConfigurationException(1, str2);
            throw th4;
        } else if (!z2 && (VALIDATION.equals(str2) || SCHEMA_VALIDATION.equals(str2))) {
            Throwable th5 = th2;
            new XMLConfigurationException(1, str2);
            throw th5;
        } else if (USE_GRAMMAR_POOL_ONLY.equals(str2) && z2 != this.fUseGrammarPoolOnly) {
            Throwable th6 = th;
            new XMLConfigurationException(1, str2);
            throw th6;
        } else if ("http://javax.xml.XMLConstants/feature/secure-processing".equals(str2)) {
            if (z2) {
                obj = obj2;
                new SecurityManager();
            } else {
                obj = null;
            }
            setProperty(SECURITY_MANAGER, obj);
        } else {
            this.fConfigUpdated = true;
            this.fEntityManager.setFeature(str2, z2);
            this.fErrorReporter.setFeature(str2, z2);
            this.fSchemaValidator.setFeature(str2, z2);
            if (!this.fInitFeatures.containsKey(str2)) {
                Object put = this.fInitFeatures.put(str2, super.getFeature(str2) ? Boolean.TRUE : Boolean.FALSE);
            }
            super.setFeature(str2, z2);
        }
    }

    /* access modifiers changed from: package-private */
    public void setLocale(Locale locale) {
        Locale locale2 = locale;
        this.fLocale = locale2;
        this.fErrorReporter.setLocale(locale2);
    }

    public void setProperty(String str, Object obj) throws XMLConfigurationException {
        Throwable th;
        String str2 = str;
        Object obj2 = obj;
        if (ENTITY_MANAGER.equals(str2) || ERROR_REPORTER.equals(str2) || NAMESPACE_CONTEXT.equals(str2) || SCHEMA_VALIDATOR.equals(str2) || SYMBOL_TABLE.equals(str2) || VALIDATION_MANAGER.equals(str2) || XMLGRAMMAR_POOL.equals(str2)) {
            Throwable th2 = th;
            new XMLConfigurationException(1, str2);
            throw th2;
        }
        this.fConfigUpdated = true;
        this.fEntityManager.setProperty(str2, obj2);
        this.fErrorReporter.setProperty(str2, obj2);
        this.fSchemaValidator.setProperty(str2, obj2);
        if (ENTITY_RESOLVER.equals(str2) || ERROR_HANDLER.equals(str2) || SECURITY_MANAGER.equals(str2)) {
            Object put = this.fComponents.put(str2, obj2);
        } else if (LOCALE.equals(str2)) {
            setLocale((Locale) obj2);
            Object put2 = this.fComponents.put(str2, obj2);
        } else {
            if (!this.fInitProperties.containsKey(str2)) {
                Object put3 = this.fInitProperties.put(str2, super.getProperty(str2));
            }
            super.setProperty(str2, obj2);
        }
    }

    /* access modifiers changed from: package-private */
    public void setResourceResolver(LSResourceResolver lSResourceResolver) {
        Object obj;
        LSResourceResolver lSResourceResolver2 = lSResourceResolver;
        this.fResourceResolver = lSResourceResolver2;
        new DOMEntityResolverWrapper(lSResourceResolver2);
        setProperty(ENTITY_RESOLVER, obj);
    }
}
