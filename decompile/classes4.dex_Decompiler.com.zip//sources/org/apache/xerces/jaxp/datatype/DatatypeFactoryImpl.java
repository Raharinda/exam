package org.apache.xerces.jaxp.datatype;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.GregorianCalendar;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;

public class DatatypeFactoryImpl extends DatatypeFactory {
    public DatatypeFactoryImpl() {
    }

    public Duration newDuration(long j) {
        Duration duration;
        new DurationImpl(j);
        return duration;
    }

    public Duration newDuration(String str) {
        Duration duration;
        new DurationImpl(str);
        return duration;
    }

    public Duration newDuration(boolean z, BigInteger bigInteger, BigInteger bigInteger2, BigInteger bigInteger3, BigInteger bigInteger4, BigInteger bigInteger5, BigDecimal bigDecimal) {
        Duration duration;
        new DurationImpl(z, bigInteger, bigInteger2, bigInteger3, bigInteger4, bigInteger5, bigDecimal);
        return duration;
    }

    public XMLGregorianCalendar newXMLGregorianCalendar() {
        XMLGregorianCalendar xMLGregorianCalendar;
        new XMLGregorianCalendarImpl();
        return xMLGregorianCalendar;
    }

    public XMLGregorianCalendar newXMLGregorianCalendar(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        return XMLGregorianCalendarImpl.createDateTime(i, i2, i3, i4, i5, i6, i7, i8);
    }

    public XMLGregorianCalendar newXMLGregorianCalendar(String str) {
        XMLGregorianCalendar xMLGregorianCalendar;
        new XMLGregorianCalendarImpl(str);
        return xMLGregorianCalendar;
    }

    public XMLGregorianCalendar newXMLGregorianCalendar(BigInteger bigInteger, int i, int i2, int i3, int i4, int i5, BigDecimal bigDecimal, int i6) {
        XMLGregorianCalendar xMLGregorianCalendar;
        new XMLGregorianCalendarImpl(bigInteger, i, i2, i3, i4, i5, bigDecimal, i6);
        return xMLGregorianCalendar;
    }

    public XMLGregorianCalendar newXMLGregorianCalendar(GregorianCalendar gregorianCalendar) {
        XMLGregorianCalendar xMLGregorianCalendar;
        new XMLGregorianCalendarImpl(gregorianCalendar);
        return xMLGregorianCalendar;
    }
}
