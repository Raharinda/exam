package org.apache.xerces.jaxp.validation;

import org.apache.xerces.xni.grammars.XMLGrammarPool;

final class XMLSchema extends AbstractXMLSchema {
    private final boolean fFullyComposed;
    private final XMLGrammarPool fGrammarPool;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XMLSchema(XMLGrammarPool xMLGrammarPool) {
        this(xMLGrammarPool, true);
    }

    public XMLSchema(XMLGrammarPool xMLGrammarPool, boolean z) {
        this.fGrammarPool = xMLGrammarPool;
        this.fFullyComposed = z;
    }

    public XMLGrammarPool getGrammarPool() {
        return this.fGrammarPool;
    }

    public boolean isFullyComposed() {
        return this.fFullyComposed;
    }
}
