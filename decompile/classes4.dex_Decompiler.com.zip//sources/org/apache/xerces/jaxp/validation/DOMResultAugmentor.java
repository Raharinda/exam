package org.apache.xerces.jaxp.validation;

import javax.xml.transform.dom.DOMResult;
import org.apache.xerces.dom.AttrImpl;
import org.apache.xerces.dom.CoreDocumentImpl;
import org.apache.xerces.dom.ElementImpl;
import org.apache.xerces.dom.ElementNSImpl;
import org.apache.xerces.dom.PSVIAttrNSImpl;
import org.apache.xerces.dom.PSVIDocumentImpl;
import org.apache.xerces.dom.PSVIElementNSImpl;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLDocumentSource;
import org.apache.xerces.xs.AttributePSVI;
import org.apache.xerces.xs.ElementPSVI;
import org.apache.xerces.xs.XSSimpleTypeDefinition;
import org.apache.xerces.xs.XSTypeDefinition;
import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;

final class DOMResultAugmentor implements DOMDocumentHandler {
    private final QName fAttributeQName;
    private final DOMValidatorHelper fDOMValidatorHelper;
    private Document fDocument;
    private CoreDocumentImpl fDocumentImpl;
    private boolean fIgnoreChars;
    private boolean fStorePSVI;

    public DOMResultAugmentor(DOMValidatorHelper dOMValidatorHelper) {
        QName qName;
        new QName();
        this.fAttributeQName = qName;
        this.fDOMValidatorHelper = dOMValidatorHelper;
    }

    private boolean processAttributePSVI(AttrImpl attrImpl, AttributePSVI attributePSVI) {
        AttrImpl attrImpl2 = attrImpl;
        AttributePSVI attributePSVI2 = attributePSVI;
        if (this.fStorePSVI) {
            ((PSVIAttrNSImpl) attrImpl2).setPSVI(attributePSVI2);
        }
        XSSimpleTypeDefinition memberTypeDefinition = attributePSVI2.getMemberTypeDefinition();
        if (memberTypeDefinition == null) {
            XSTypeDefinition typeDefinition = attributePSVI2.getTypeDefinition();
            if (typeDefinition == null) {
                return false;
            }
            attrImpl2.setType(typeDefinition);
            return typeDefinition.isIDType();
        }
        attrImpl2.setType(memberTypeDefinition);
        return memberTypeDefinition.isIDType();
    }

    public void cdata(CDATASection cDATASection) throws XNIException {
    }

    public void characters(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (!this.fIgnoreChars) {
            Node appendChild = ((Element) this.fDOMValidatorHelper.getCurrentElement()).appendChild(this.fDocument.createTextNode(xMLString2.toString()));
        }
    }

    public void characters(Text text) throws XNIException {
    }

    public void comment(XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void comment(Comment comment) throws XNIException {
    }

    public void doctypeDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
    }

    public void doctypeDecl(DocumentType documentType) throws XNIException {
    }

    public void emptyElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        startElement(qName2, xMLAttributes, augmentations2);
        endElement(qName2, augmentations2);
    }

    public void endCDATA(Augmentations augmentations) throws XNIException {
    }

    public void endDocument(Augmentations augmentations) throws XNIException {
    }

    public void endElement(QName qName, Augmentations augmentations) throws XNIException {
        ElementPSVI elementPSVI;
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        Node currentElement = this.fDOMValidatorHelper.getCurrentElement();
        if (augmentations2 != null && this.fDocumentImpl != null && (elementPSVI = (ElementPSVI) augmentations2.getItem("ELEMENT_PSVI")) != null) {
            if (this.fStorePSVI) {
                ((PSVIElementNSImpl) currentElement).setPSVI(elementPSVI);
            }
            XSTypeDefinition memberTypeDefinition = elementPSVI.getMemberTypeDefinition();
            if (memberTypeDefinition == null) {
                memberTypeDefinition = elementPSVI.getTypeDefinition();
            }
            ((ElementNSImpl) currentElement).setType(memberTypeDefinition);
        }
    }

    public void endGeneralEntity(String str, Augmentations augmentations) throws XNIException {
    }

    public XMLDocumentSource getDocumentSource() {
        return null;
    }

    public void ignorableWhitespace(XMLString xMLString, Augmentations augmentations) throws XNIException {
        characters(xMLString, augmentations);
    }

    public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void processingInstruction(ProcessingInstruction processingInstruction) throws XNIException {
    }

    public void setDOMResult(DOMResult dOMResult) {
        DOMResult dOMResult2 = dOMResult;
        this.fIgnoreChars = false;
        if (dOMResult2 != null) {
            Node node = dOMResult2.getNode();
            this.fDocument = node.getNodeType() == 9 ? (Document) node : node.getOwnerDocument();
            this.fDocumentImpl = this.fDocument instanceof CoreDocumentImpl ? (CoreDocumentImpl) this.fDocument : null;
            this.fStorePSVI = this.fDocument instanceof PSVIDocumentImpl;
            return;
        }
        this.fDocument = null;
        this.fDocumentImpl = null;
        this.fStorePSVI = false;
    }

    public void setDocumentSource(XMLDocumentSource xMLDocumentSource) {
    }

    public void setIgnoringCharacters(boolean z) {
        boolean z2 = z;
        this.fIgnoreChars = z2;
    }

    public void startCDATA(Augmentations augmentations) throws XNIException {
    }

    public void startDocument(XMLLocator xMLLocator, String str, NamespaceContext namespaceContext, Augmentations augmentations) throws XNIException {
    }

    public void startElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        Element element = (Element) this.fDOMValidatorHelper.getCurrentElement();
        NamedNodeMap attributes = element.getAttributes();
        int length = attributes.getLength();
        if (this.fDocumentImpl != null) {
            for (int i = 0; i < length; i++) {
                AttrImpl attrImpl = (AttrImpl) attributes.item(i);
                AttributePSVI attributePSVI = (AttributePSVI) xMLAttributes2.getAugmentations(i).getItem("ATTRIBUTE_PSVI");
                if (attributePSVI != null && processAttributePSVI(attrImpl, attributePSVI)) {
                    ((ElementImpl) element).setIdAttributeNode(attrImpl, true);
                }
            }
        }
        int length2 = xMLAttributes2.getLength();
        if (length2 <= length) {
            return;
        }
        if (this.fDocumentImpl == null) {
            for (int i2 = length; i2 < length2; i2++) {
                xMLAttributes2.getName(i2, this.fAttributeQName);
                element.setAttributeNS(this.fAttributeQName.uri, this.fAttributeQName.rawname, xMLAttributes2.getValue(i2));
            }
            return;
        }
        for (int i3 = length; i3 < length2; i3++) {
            xMLAttributes2.getName(i3, this.fAttributeQName);
            AttrImpl attrImpl2 = (AttrImpl) this.fDocumentImpl.createAttributeNS(this.fAttributeQName.uri, this.fAttributeQName.rawname, this.fAttributeQName.localpart);
            attrImpl2.setValue(xMLAttributes2.getValue(i3));
            Attr attributeNodeNS = element.setAttributeNodeNS(attrImpl2);
            AttributePSVI attributePSVI2 = (AttributePSVI) xMLAttributes2.getAugmentations(i3).getItem("ATTRIBUTE_PSVI");
            if (attributePSVI2 != null && processAttributePSVI(attrImpl2, attributePSVI2)) {
                ((ElementImpl) element).setIdAttributeNode(attrImpl2, true);
            }
            attrImpl2.setSpecified(false);
        }
    }

    public void startGeneralEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
    }

    public void textDecl(String str, String str2, Augmentations augmentations) throws XNIException {
    }

    public void xmlDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
    }
}
