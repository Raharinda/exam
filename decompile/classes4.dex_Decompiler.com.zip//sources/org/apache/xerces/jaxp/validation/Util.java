package org.apache.xerces.jaxp.validation;

import javax.xml.transform.stream.StreamSource;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLParseException;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

final class Util {
    Util() {
    }

    public static SAXException toSAXException(XNIException xNIException) {
        SAXException sAXException;
        XNIException xNIException2 = xNIException;
        if (xNIException2 instanceof XMLParseException) {
            return toSAXParseException((XMLParseException) xNIException2);
        }
        if (xNIException2.getException() instanceof SAXException) {
            return (SAXException) xNIException2.getException();
        }
        new SAXException(xNIException2.getMessage(), xNIException2.getException());
        return sAXException;
    }

    public static SAXParseException toSAXParseException(XMLParseException xMLParseException) {
        SAXParseException sAXParseException;
        XMLParseException xMLParseException2 = xMLParseException;
        if (xMLParseException2.getException() instanceof SAXParseException) {
            return (SAXParseException) xMLParseException2.getException();
        }
        new SAXParseException(xMLParseException2.getMessage(), xMLParseException2.getPublicId(), xMLParseException2.getExpandedSystemId(), xMLParseException2.getLineNumber(), xMLParseException2.getColumnNumber(), xMLParseException2.getException());
        return sAXParseException;
    }

    public static final XMLInputSource toXMLInputSource(StreamSource streamSource) {
        XMLInputSource xMLInputSource;
        XMLInputSource xMLInputSource2;
        XMLInputSource xMLInputSource3;
        StreamSource streamSource2 = streamSource;
        if (streamSource2.getReader() != null) {
            new XMLInputSource(streamSource2.getPublicId(), streamSource2.getSystemId(), streamSource2.getSystemId(), streamSource2.getReader(), (String) null);
            return xMLInputSource3;
        } else if (streamSource2.getInputStream() != null) {
            new XMLInputSource(streamSource2.getPublicId(), streamSource2.getSystemId(), streamSource2.getSystemId(), streamSource2.getInputStream(), (String) null);
            return xMLInputSource2;
        } else {
            new XMLInputSource(streamSource2.getPublicId(), streamSource2.getSystemId(), streamSource2.getSystemId());
            return xMLInputSource;
        }
    }
}
