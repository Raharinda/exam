package org.apache.xerces.jaxp.validation;

import org.apache.xerces.xni.grammars.Grammar;
import org.apache.xerces.xni.grammars.XMLGrammarDescription;
import org.apache.xerces.xni.grammars.XMLGrammarPool;

final class SimpleXMLSchema extends AbstractXMLSchema implements XMLGrammarPool {
    private static final Grammar[] ZERO_LENGTH_GRAMMAR_ARRAY = new Grammar[0];
    private final Grammar fGrammar;
    private final XMLGrammarDescription fGrammarDescription;
    private final Grammar[] fGrammars;

    public SimpleXMLSchema(Grammar grammar) {
        Grammar grammar2 = grammar;
        this.fGrammar = grammar2;
        Grammar[] grammarArr = new Grammar[1];
        grammarArr[0] = grammar2;
        this.fGrammars = grammarArr;
        this.fGrammarDescription = grammar2.getGrammarDescription();
    }

    public void cacheGrammars(String str, Grammar[] grammarArr) {
    }

    public void clear() {
    }

    public XMLGrammarPool getGrammarPool() {
        return this;
    }

    public boolean isFullyComposed() {
        return true;
    }

    public void lockPool() {
    }

    public Grammar retrieveGrammar(XMLGrammarDescription xMLGrammarDescription) {
        return this.fGrammarDescription.equals(xMLGrammarDescription) ? this.fGrammar : null;
    }

    public Grammar[] retrieveInitialGrammarSet(String str) {
        return "http://www.w3.org/2001/XMLSchema".equals(str) ? (Grammar[]) this.fGrammars.clone() : ZERO_LENGTH_GRAMMAR_ARRAY;
    }

    public void unlockPool() {
    }
}
