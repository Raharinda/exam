package org.apache.xerces.jaxp;

import java.util.Hashtable;
import java.util.Locale;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.validation.Schema;
import org.apache.xerces.parsers.DOMParser;
import org.apache.xerces.util.SAXMessageFormatter;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;

public class DocumentBuilderFactoryImpl extends DocumentBuilderFactory {
    private static final String CREATE_CDATA_NODES_FEATURE = "http://apache.org/xml/features/create-cdata-nodes";
    private static final String CREATE_ENTITY_REF_NODES_FEATURE = "http://apache.org/xml/features/dom/create-entity-ref-nodes";
    private static final String INCLUDE_COMMENTS_FEATURE = "http://apache.org/xml/features/include-comments";
    private static final String INCLUDE_IGNORABLE_WHITESPACE = "http://apache.org/xml/features/dom/include-ignorable-whitespace";
    private static final String NAMESPACES_FEATURE = "http://xml.org/sax/features/namespaces";
    private static final String VALIDATION_FEATURE = "http://xml.org/sax/features/validation";
    private static final String XINCLUDE_FEATURE = "http://apache.org/xml/features/xinclude";
    private Hashtable attributes;
    private boolean fSecureProcess = false;
    private Hashtable features;
    private Schema grammar;
    private boolean isXIncludeAware;

    public DocumentBuilderFactoryImpl() {
    }

    public Object getAttribute(String str) throws IllegalArgumentException {
        Throwable th;
        DocumentBuilderImpl documentBuilderImpl;
        Object obj;
        String str2 = str;
        if (this.attributes != null && (obj = this.attributes.get(str2)) != null) {
            return obj;
        }
        DOMParser dOMParser = null;
        try {
            new DocumentBuilderImpl(this, this.attributes, this.features);
            dOMParser = documentBuilderImpl.getDOMParser();
            return dOMParser.getProperty(str2);
        } catch (SAXException e) {
            SAXException sAXException = e;
            try {
                return dOMParser.getFeature(str2) ? Boolean.TRUE : Boolean.FALSE;
            } catch (SAXException e2) {
                SAXException sAXException2 = e2;
                Throwable th2 = th;
                new IllegalArgumentException(sAXException.getMessage());
                throw th2;
            }
        }
    }

    public boolean getFeature(String str) throws ParserConfigurationException {
        Throwable th;
        DocumentBuilderImpl documentBuilderImpl;
        Object obj;
        String str2 = str;
        if (str2.equals("http://javax.xml.XMLConstants/feature/secure-processing")) {
            return this.fSecureProcess;
        }
        if (str2.equals(NAMESPACES_FEATURE)) {
            return isNamespaceAware();
        }
        if (str2.equals(VALIDATION_FEATURE)) {
            return isValidating();
        }
        if (str2.equals(XINCLUDE_FEATURE)) {
            return isXIncludeAware();
        }
        if (str2.equals(INCLUDE_IGNORABLE_WHITESPACE)) {
            return !isIgnoringElementContentWhitespace();
        } else if (str2.equals(CREATE_ENTITY_REF_NODES_FEATURE)) {
            return !isExpandEntityReferences();
        } else if (str2.equals(INCLUDE_COMMENTS_FEATURE)) {
            return !isIgnoringComments();
        } else if (str2.equals(CREATE_CDATA_NODES_FEATURE)) {
            return !isCoalescing();
        } else if (this.features != null && (obj = this.features.get(str2)) != null) {
            return ((Boolean) obj).booleanValue();
        } else {
            try {
                new DocumentBuilderImpl(this, this.attributes, this.features);
                return documentBuilderImpl.getDOMParser().getFeature(str2);
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new ParserConfigurationException(sAXException.getMessage());
                throw th2;
            }
        }
    }

    public Schema getSchema() {
        return this.grammar;
    }

    public boolean isXIncludeAware() {
        return this.isXIncludeAware;
    }

    public DocumentBuilder newDocumentBuilder() throws ParserConfigurationException {
        Throwable th;
        DocumentBuilder documentBuilder;
        Throwable th2;
        Throwable th3;
        if (!(this.grammar == null || this.attributes == null)) {
            if (this.attributes.containsKey(JAXPConstants.JAXP_SCHEMA_LANGUAGE)) {
                Throwable th4 = th3;
                new ParserConfigurationException(SAXMessageFormatter.formatMessage((Locale) null, "schema-already-specified", new Object[]{JAXPConstants.JAXP_SCHEMA_LANGUAGE}));
                throw th4;
            } else if (this.attributes.containsKey(JAXPConstants.JAXP_SCHEMA_SOURCE)) {
                Throwable th5 = th2;
                new ParserConfigurationException(SAXMessageFormatter.formatMessage((Locale) null, "schema-already-specified", new Object[]{JAXPConstants.JAXP_SCHEMA_SOURCE}));
                throw th5;
            }
        }
        try {
            DocumentBuilder documentBuilder2 = documentBuilder;
            new DocumentBuilderImpl(this, this.attributes, this.features, this.fSecureProcess);
            return documentBuilder2;
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th6 = th;
            new ParserConfigurationException(sAXException.getMessage());
            throw th6;
        }
    }

    public void setAttribute(String str, Object obj) throws IllegalArgumentException {
        Throwable th;
        Object obj2;
        Hashtable hashtable;
        String str2 = str;
        Object obj3 = obj;
        if (obj3 != null) {
            if (this.attributes == null) {
                new Hashtable();
                this.attributes = hashtable;
            }
            Object put = this.attributes.put(str2, obj3);
            try {
                Object obj4 = obj2;
                new DocumentBuilderImpl(this, this.attributes, this.features);
            } catch (Exception e) {
                Exception exc = e;
                Object remove = this.attributes.remove(str2);
                Throwable th2 = th;
                new IllegalArgumentException(exc.getMessage());
                throw th2;
            }
        } else if (this.attributes != null) {
            Object remove2 = this.attributes.remove(str2);
        }
    }

    public void setFeature(String str, boolean z) throws ParserConfigurationException {
        Throwable th;
        Throwable th2;
        Object obj;
        Hashtable hashtable;
        String str2 = str;
        boolean z2 = z;
        if (str2.equals("http://javax.xml.XMLConstants/feature/secure-processing")) {
            this.fSecureProcess = z2;
        } else if (str2.equals(NAMESPACES_FEATURE)) {
            setNamespaceAware(z2);
        } else if (str2.equals(VALIDATION_FEATURE)) {
            setValidating(z2);
        } else if (str2.equals(XINCLUDE_FEATURE)) {
            setXIncludeAware(z2);
        } else if (str2.equals(INCLUDE_IGNORABLE_WHITESPACE)) {
            setIgnoringElementContentWhitespace(!z2);
        } else if (str2.equals(CREATE_ENTITY_REF_NODES_FEATURE)) {
            setExpandEntityReferences(!z2);
        } else if (str2.equals(INCLUDE_COMMENTS_FEATURE)) {
            setIgnoringComments(!z2);
        } else if (str2.equals(CREATE_CDATA_NODES_FEATURE)) {
            setCoalescing(!z2);
        } else {
            if (this.features == null) {
                new Hashtable();
                this.features = hashtable;
            }
            Object put = this.features.put(str2, z2 ? Boolean.TRUE : Boolean.FALSE);
            try {
                Object obj2 = obj;
                new DocumentBuilderImpl(this, this.attributes, this.features);
            } catch (SAXNotSupportedException e) {
                SAXNotSupportedException sAXNotSupportedException = e;
                Object remove = this.features.remove(str2);
                Throwable th3 = th2;
                new ParserConfigurationException(sAXNotSupportedException.getMessage());
                throw th3;
            } catch (SAXNotRecognizedException e2) {
                SAXNotRecognizedException sAXNotRecognizedException = e2;
                Object remove2 = this.features.remove(str2);
                Throwable th4 = th;
                new ParserConfigurationException(sAXNotRecognizedException.getMessage());
                throw th4;
            }
        }
    }

    public void setSchema(Schema schema) {
        Schema schema2 = schema;
        this.grammar = schema2;
    }

    public void setXIncludeAware(boolean z) {
        boolean z2 = z;
        this.isXIncludeAware = z2;
    }
}
