package org.apache.xerces.jaxp;

import java.util.Hashtable;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.validation.Schema;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;

public class SAXParserFactoryImpl extends SAXParserFactory {
    private static final String NAMESPACES_FEATURE = "http://xml.org/sax/features/namespaces";
    private static final String VALIDATION_FEATURE = "http://xml.org/sax/features/validation";
    private static final String XINCLUDE_FEATURE = "http://apache.org/xml/features/xinclude";
    private boolean fSecureProcess = false;
    private Hashtable features;
    private Schema grammar;
    private boolean isXIncludeAware;

    public SAXParserFactoryImpl() {
    }

    private SAXParserImpl newSAXParserImpl() throws ParserConfigurationException, SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        SAXParserImpl sAXParserImpl;
        try {
            SAXParserImpl sAXParserImpl2 = sAXParserImpl;
            new SAXParserImpl(this, this.features);
            return sAXParserImpl2;
        } catch (SAXNotSupportedException e) {
            throw e;
        } catch (SAXNotRecognizedException e2) {
            throw e2;
        } catch (SAXException e3) {
            SAXException sAXException = e3;
            Throwable th2 = th;
            new ParserConfigurationException(sAXException.getMessage());
            throw th2;
        }
    }

    public boolean getFeature(String str) throws ParserConfigurationException, SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        String str2 = str;
        if (str2 != null) {
            return str2.equals("http://javax.xml.XMLConstants/feature/secure-processing") ? this.fSecureProcess : str2.equals(NAMESPACES_FEATURE) ? isNamespaceAware() : str2.equals(VALIDATION_FEATURE) ? isValidating() : str2.equals(XINCLUDE_FEATURE) ? isXIncludeAware() : newSAXParserImpl().getXMLReader().getFeature(str2);
        }
        Throwable th2 = th;
        new NullPointerException();
        throw th2;
    }

    public Schema getSchema() {
        return this.grammar;
    }

    public boolean isXIncludeAware() {
        return this.isXIncludeAware;
    }

    public SAXParser newSAXParser() throws ParserConfigurationException {
        Throwable th;
        SAXParser sAXParser;
        try {
            SAXParser sAXParser2 = sAXParser;
            new SAXParserImpl(this, this.features, this.fSecureProcess);
            return sAXParser2;
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new ParserConfigurationException(sAXException.getMessage());
            throw th2;
        }
    }

    public void setFeature(String str, boolean z) throws ParserConfigurationException, SAXNotRecognizedException, SAXNotSupportedException {
        Hashtable hashtable;
        Throwable th;
        String str2 = str;
        boolean z2 = z;
        if (str2 == null) {
            Throwable th2 = th;
            new NullPointerException();
            throw th2;
        } else if (str2.equals("http://javax.xml.XMLConstants/feature/secure-processing")) {
            this.fSecureProcess = z2;
        } else if (str2.equals(NAMESPACES_FEATURE)) {
            setNamespaceAware(z2);
        } else if (str2.equals(VALIDATION_FEATURE)) {
            setValidating(z2);
        } else if (str2.equals(XINCLUDE_FEATURE)) {
            setXIncludeAware(z2);
        } else {
            if (this.features == null) {
                new Hashtable();
                this.features = hashtable;
            }
            Object put = this.features.put(str2, z2 ? Boolean.TRUE : Boolean.FALSE);
            try {
                SAXParserImpl newSAXParserImpl = newSAXParserImpl();
            } catch (SAXNotSupportedException e) {
                SAXNotSupportedException sAXNotSupportedException = e;
                Object remove = this.features.remove(str2);
                throw sAXNotSupportedException;
            } catch (SAXNotRecognizedException e2) {
                SAXNotRecognizedException sAXNotRecognizedException = e2;
                Object remove2 = this.features.remove(str2);
                throw sAXNotRecognizedException;
            }
        }
    }

    public void setSchema(Schema schema) {
        Schema schema2 = schema;
        this.grammar = schema2;
    }

    public void setXIncludeAware(boolean z) {
        boolean z2 = z;
        this.isXIncludeAware = z2;
    }
}
