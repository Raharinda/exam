package org.apache.xerces.jaxp;

import java.util.HashMap;
import org.apache.xerces.impl.validation.EntityState;
import org.apache.xerces.impl.validation.ValidationManager;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.XMLDTDHandler;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLDTDFilter;
import org.apache.xerces.xni.parser.XMLDTDSource;

final class UnparsedEntityHandler implements XMLDTDFilter, EntityState {
    private XMLDTDHandler fDTDHandler;
    private XMLDTDSource fDTDSource;
    private HashMap fUnparsedEntities = null;
    private final ValidationManager fValidationManager;

    UnparsedEntityHandler(ValidationManager validationManager) {
        this.fValidationManager = validationManager;
    }

    public void attributeDecl(String str, String str2, String str3, String[] strArr, String str4, XMLString xMLString, XMLString xMLString2, Augmentations augmentations) throws XNIException {
        String str5 = str;
        String str6 = str2;
        String str7 = str3;
        String[] strArr2 = strArr;
        String str8 = str4;
        XMLString xMLString3 = xMLString;
        XMLString xMLString4 = xMLString2;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.attributeDecl(str5, str6, str7, strArr2, str8, xMLString3, xMLString4, augmentations2);
        }
    }

    public void comment(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.comment(xMLString2, augmentations2);
        }
    }

    public void elementDecl(String str, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.elementDecl(str3, str4, augmentations2);
        }
    }

    public void endAttlist(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.endAttlist(augmentations2);
        }
    }

    public void endConditional(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.endConditional(augmentations2);
        }
    }

    public void endDTD(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.endDTD(augmentations2);
        }
    }

    public void endExternalSubset(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.endExternalSubset(augmentations2);
        }
    }

    public void endParameterEntity(String str, Augmentations augmentations) throws XNIException {
        String str2 = str;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.endParameterEntity(str2, augmentations2);
        }
    }

    public void externalEntityDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
        String str2 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.externalEntityDecl(str2, xMLResourceIdentifier2, augmentations2);
        }
    }

    public XMLDTDHandler getDTDHandler() {
        return this.fDTDHandler;
    }

    public XMLDTDSource getDTDSource() {
        return this.fDTDSource;
    }

    public void ignoredCharacters(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.ignoredCharacters(xMLString2, augmentations2);
        }
    }

    public void internalEntityDecl(String str, XMLString xMLString, XMLString xMLString2, Augmentations augmentations) throws XNIException {
        String str2 = str;
        XMLString xMLString3 = xMLString;
        XMLString xMLString4 = xMLString2;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.internalEntityDecl(str2, xMLString3, xMLString4, augmentations2);
        }
    }

    public boolean isEntityDeclared(String str) {
        String str2 = str;
        return false;
    }

    public boolean isEntityUnparsed(String str) {
        String str2 = str;
        if (this.fUnparsedEntities != null) {
            return this.fUnparsedEntities.containsKey(str2);
        }
        return false;
    }

    public void notationDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
        String str2 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.notationDecl(str2, xMLResourceIdentifier2, augmentations2);
        }
    }

    public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
        String str2 = str;
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.processingInstruction(str2, xMLString2, augmentations2);
        }
    }

    public void reset() {
        if (this.fUnparsedEntities != null && !this.fUnparsedEntities.isEmpty()) {
            this.fUnparsedEntities.clear();
        }
    }

    public void setDTDHandler(XMLDTDHandler xMLDTDHandler) {
        XMLDTDHandler xMLDTDHandler2 = xMLDTDHandler;
        this.fDTDHandler = xMLDTDHandler2;
    }

    public void setDTDSource(XMLDTDSource xMLDTDSource) {
        XMLDTDSource xMLDTDSource2 = xMLDTDSource;
        this.fDTDSource = xMLDTDSource2;
    }

    public void startAttlist(String str, Augmentations augmentations) throws XNIException {
        String str2 = str;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.startAttlist(str2, augmentations2);
        }
    }

    public void startConditional(short s, Augmentations augmentations) throws XNIException {
        short s2 = s;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.startConditional(s2, augmentations2);
        }
    }

    public void startDTD(XMLLocator xMLLocator, Augmentations augmentations) throws XNIException {
        XMLLocator xMLLocator2 = xMLLocator;
        Augmentations augmentations2 = augmentations;
        this.fValidationManager.setEntityState(this);
        if (this.fDTDHandler != null) {
            this.fDTDHandler.startDTD(xMLLocator2, augmentations2);
        }
    }

    public void startExternalSubset(XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.startExternalSubset(xMLResourceIdentifier2, augmentations2);
        }
    }

    public void startParameterEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.startParameterEntity(str3, xMLResourceIdentifier2, str4, augmentations2);
        }
    }

    public void textDecl(String str, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.textDecl(str3, str4, augmentations2);
        }
    }

    public void unparsedEntityDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
        HashMap hashMap;
        String str3 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        if (this.fUnparsedEntities == null) {
            new HashMap();
            this.fUnparsedEntities = hashMap;
        }
        Object put = this.fUnparsedEntities.put(str3, str3);
        if (this.fDTDHandler != null) {
            this.fDTDHandler.unparsedEntityDecl(str3, xMLResourceIdentifier2, str4, augmentations2);
        }
    }
}
