package org.apache.xerces.jaxp.validation;

import java.util.HashMap;
import javax.xml.validation.Schema;
import javax.xml.validation.Validator;
import javax.xml.validation.ValidatorHandler;
import org.apache.xerces.xni.grammars.XMLGrammarPool;

abstract class AbstractXMLSchema extends Schema implements XSGrammarPoolContainer {
    private final HashMap fFeatures;

    public AbstractXMLSchema() {
        HashMap hashMap;
        new HashMap();
        this.fFeatures = hashMap;
    }

    public final Boolean getFeature(String str) {
        return (Boolean) this.fFeatures.get(str);
    }

    public abstract XMLGrammarPool getGrammarPool();

    public abstract boolean isFullyComposed();

    public final Validator newValidator() {
        Validator validator;
        new ValidatorImpl(this);
        return validator;
    }

    public final ValidatorHandler newValidatorHandler() {
        ValidatorHandler validatorHandler;
        new ValidatorHandlerImpl((XSGrammarPoolContainer) this);
        return validatorHandler;
    }

    /* access modifiers changed from: package-private */
    public final void setFeature(String str, boolean z) {
        Object put = this.fFeatures.put(str, z ? Boolean.TRUE : Boolean.FALSE);
    }
}
