package org.apache.xerces.jaxp;

import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.impl.validation.ValidationManager;
import org.apache.xerces.impl.xs.XSMessageFormatter;
import org.apache.xerces.jaxp.validation.XSGrammarPoolContainer;
import org.apache.xerces.util.MessageFormatter;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;

final class SchemaValidatorConfiguration implements XMLComponentManager {
    private static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
    private static final String PARSER_SETTINGS = "http://apache.org/xml/features/internal/parser-settings";
    private static final String SCHEMA_VALIDATION = "http://apache.org/xml/features/validation/schema";
    private static final String USE_GRAMMAR_POOL_ONLY = "http://apache.org/xml/features/internal/validation/schema/use-grammar-pool-only";
    private static final String VALIDATION = "http://xml.org/sax/features/validation";
    private static final String VALIDATION_MANAGER = "http://apache.org/xml/properties/internal/validation-manager";
    private static final String XMLGRAMMAR_POOL = "http://apache.org/xml/properties/internal/grammar-pool";
    private final XMLGrammarPool fGrammarPool;
    private final XMLComponentManager fParentComponentManager;
    private final boolean fUseGrammarPoolOnly;
    private final ValidationManager fValidationManager;

    public SchemaValidatorConfiguration(XMLComponentManager xMLComponentManager, XSGrammarPoolContainer xSGrammarPoolContainer, ValidationManager validationManager) {
        MessageFormatter messageFormatter;
        XSGrammarPoolContainer xSGrammarPoolContainer2 = xSGrammarPoolContainer;
        this.fParentComponentManager = xMLComponentManager;
        this.fGrammarPool = xSGrammarPoolContainer2.getGrammarPool();
        this.fUseGrammarPoolOnly = xSGrammarPoolContainer2.isFullyComposed();
        this.fValidationManager = validationManager;
        try {
            XMLErrorReporter xMLErrorReporter = (XMLErrorReporter) this.fParentComponentManager.getProperty(ERROR_REPORTER);
            if (xMLErrorReporter != null) {
                new XSMessageFormatter();
                xMLErrorReporter.putMessageFormatter("http://www.w3.org/TR/xml-schema-1", messageFormatter);
            }
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
        }
    }

    public boolean getFeature(String str) throws XMLConfigurationException {
        String str2 = str;
        if (PARSER_SETTINGS.equals(str2)) {
            return this.fParentComponentManager.getFeature(str2);
        }
        if (VALIDATION.equals(str2) || SCHEMA_VALIDATION.equals(str2)) {
            return true;
        }
        return USE_GRAMMAR_POOL_ONLY.equals(str2) ? this.fUseGrammarPoolOnly : this.fParentComponentManager.getFeature(str2);
    }

    public Object getProperty(String str) throws XMLConfigurationException {
        String str2 = str;
        return XMLGRAMMAR_POOL.equals(str2) ? this.fGrammarPool : VALIDATION_MANAGER.equals(str2) ? this.fValidationManager : this.fParentComponentManager.getProperty(str2);
    }
}
