package org.apache.xerces.jaxp.validation;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.ref.SoftReference;
import java.util.Locale;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.apache.xerces.impl.XMLEntityManager;
import org.apache.xerces.impl.xs.XMLSchemaValidator;
import org.apache.xerces.parsers.SAXParser;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLParseException;
import org.apache.xerces.xni.parser.XMLParserConfiguration;
import org.apache.xml.serialize.Method;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.Serializer;
import org.apache.xml.serialize.SerializerFactory;
import org.xml.sax.SAXException;

final class StreamValidatorHelper implements ValidatorHelper {
    private static final String ENTITY_RESOLVER = "http://apache.org/xml/properties/internal/entity-resolver";
    private static final String ERROR_HANDLER = "http://apache.org/xml/properties/internal/error-handler";
    private static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
    private static final String PARSER_SETTINGS = "http://apache.org/xml/features/internal/parser-settings";
    private static final String SCHEMA_VALIDATOR = "http://apache.org/xml/properties/internal/validator/schema";
    private static final String SECURITY_MANAGER = "http://apache.org/xml/properties/security-manager";
    private static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    private static final String VALIDATION_MANAGER = "http://apache.org/xml/properties/internal/validation-manager";
    private final XMLSchemaValidatorComponentManager fComponentManager;
    private SoftReference fConfiguration;
    private SoftReference fParser;
    private final XMLSchemaValidator fSchemaValidator = ((XMLSchemaValidator) this.fComponentManager.getProperty(SCHEMA_VALIDATOR));
    private SerializerFactory fSerializerFactory;

    public StreamValidatorHelper(XMLSchemaValidatorComponentManager xMLSchemaValidatorComponentManager) {
        SoftReference softReference;
        SoftReference softReference2;
        new SoftReference((Object) null);
        this.fConfiguration = softReference;
        new SoftReference((Object) null);
        this.fParser = softReference2;
        this.fComponentManager = xMLSchemaValidatorComponentManager;
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private org.apache.xerces.xni.parser.XMLParserConfiguration initialize() {
        /*
            r9 = this;
            r0 = r9
            org.apache.xerces.parsers.XML11Configuration r4 = new org.apache.xerces.parsers.XML11Configuration
            r8 = r4
            r4 = r8
            r5 = r8
            r5.<init>()
            r1 = r4
            r4 = r1
            java.lang.String r5 = "http://apache.org/xml/properties/internal/entity-resolver"
            r6 = r0
            org.apache.xerces.jaxp.validation.XMLSchemaValidatorComponentManager r6 = r6.fComponentManager
            java.lang.String r7 = "http://apache.org/xml/properties/internal/entity-resolver"
            java.lang.Object r6 = r6.getProperty(r7)
            r4.setProperty(r5, r6)
            r4 = r1
            java.lang.String r5 = "http://apache.org/xml/properties/internal/error-handler"
            r6 = r0
            org.apache.xerces.jaxp.validation.XMLSchemaValidatorComponentManager r6 = r6.fComponentManager
            java.lang.String r7 = "http://apache.org/xml/properties/internal/error-handler"
            java.lang.Object r6 = r6.getProperty(r7)
            r4.setProperty(r5, r6)
            r4 = r0
            org.apache.xerces.jaxp.validation.XMLSchemaValidatorComponentManager r4 = r4.fComponentManager
            java.lang.String r5 = "http://apache.org/xml/properties/internal/error-reporter"
            java.lang.Object r4 = r4.getProperty(r5)
            org.apache.xerces.impl.XMLErrorReporter r4 = (org.apache.xerces.impl.XMLErrorReporter) r4
            r2 = r4
            r4 = r1
            java.lang.String r5 = "http://apache.org/xml/properties/internal/error-reporter"
            r6 = r2
            r4.setProperty(r5, r6)
            r4 = r2
            java.lang.String r5 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            org.apache.xerces.util.MessageFormatter r4 = r4.getMessageFormatter(r5)
            if (r4 != 0) goto L_0x0064
            org.apache.xerces.impl.msg.XMLMessageFormatter r4 = new org.apache.xerces.impl.msg.XMLMessageFormatter
            r8 = r4
            r4 = r8
            r5 = r8
            r5.<init>()
            r3 = r4
            r4 = r2
            java.lang.String r5 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            r6 = r3
            r4.putMessageFormatter(r5, r6)
            r4 = r2
            java.lang.String r5 = "http://www.w3.org/TR/1999/REC-xml-names-19990114"
            r6 = r3
            r4.putMessageFormatter(r5, r6)
        L_0x0064:
            r4 = r1
            java.lang.String r5 = "http://apache.org/xml/properties/internal/symbol-table"
            r6 = r0
            org.apache.xerces.jaxp.validation.XMLSchemaValidatorComponentManager r6 = r6.fComponentManager
            java.lang.String r7 = "http://apache.org/xml/properties/internal/symbol-table"
            java.lang.Object r6 = r6.getProperty(r7)
            r4.setProperty(r5, r6)
            r4 = r1
            java.lang.String r5 = "http://apache.org/xml/properties/internal/validation-manager"
            r6 = r0
            org.apache.xerces.jaxp.validation.XMLSchemaValidatorComponentManager r6 = r6.fComponentManager
            java.lang.String r7 = "http://apache.org/xml/properties/internal/validation-manager"
            java.lang.Object r6 = r6.getProperty(r7)
            r4.setProperty(r5, r6)
            r4 = r1
            java.lang.String r5 = "http://apache.org/xml/properties/security-manager"
            r6 = r0
            org.apache.xerces.jaxp.validation.XMLSchemaValidatorComponentManager r6 = r6.fComponentManager
            java.lang.String r7 = "http://apache.org/xml/properties/security-manager"
            java.lang.Object r6 = r6.getProperty(r7)
            r4.setProperty(r5, r6)
            r4 = r1
            r5 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r5 = r5.fSchemaValidator
            r4.setDocumentHandler(r5)
            r4 = r1
            r5 = 0
            r4.setDTDHandler(r5)
            r4 = r1
            r5 = 0
            r4.setDTDContentModelHandler(r5)
            r4 = r0
            java.lang.ref.SoftReference r5 = new java.lang.ref.SoftReference
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r1
            r6.<init>(r7)
            r4.fConfiguration = r5
            r4 = r1
            r0 = r4
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.jaxp.validation.StreamValidatorHelper.initialize():org.apache.xerces.xni.parser.XMLParserConfiguration");
    }

    public void validate(Source source, Result result) throws SAXException, IOException {
        XMLInputSource xMLInputSource;
        Throwable th;
        OutputFormat outputFormat;
        Serializer makeSerializer;
        OutputFormat outputFormat2;
        SAXParser sAXParser;
        SoftReference softReference;
        OutputFormat outputFormat3;
        Throwable th2;
        Source source2 = source;
        Result result2 = result;
        if ((result2 instanceof StreamResult) || result2 == null) {
            StreamSource streamSource = (StreamSource) source2;
            StreamResult streamResult = (StreamResult) result2;
            new XMLInputSource(streamSource.getPublicId(), streamSource.getSystemId(), (String) null);
            XMLInputSource xMLInputSource2 = xMLInputSource;
            xMLInputSource2.setByteStream(streamSource.getInputStream());
            xMLInputSource2.setCharacterStream(streamSource.getReader());
            boolean z = false;
            XMLParserConfiguration xMLParserConfiguration = (XMLParserConfiguration) this.fConfiguration.get();
            if (xMLParserConfiguration == null) {
                xMLParserConfiguration = initialize();
                z = true;
            } else if (this.fComponentManager.getFeature(PARSER_SETTINGS)) {
                xMLParserConfiguration.setProperty(ENTITY_RESOLVER, this.fComponentManager.getProperty(ENTITY_RESOLVER));
                xMLParserConfiguration.setProperty(ERROR_HANDLER, this.fComponentManager.getProperty(ERROR_HANDLER));
                xMLParserConfiguration.setProperty(SECURITY_MANAGER, this.fComponentManager.getProperty(SECURITY_MANAGER));
            }
            this.fComponentManager.reset();
            if (streamResult != null) {
                if (this.fSerializerFactory == null) {
                    this.fSerializerFactory = SerializerFactory.getSerializerFactory(Method.XML);
                }
                if (streamResult.getWriter() != null) {
                    new OutputFormat();
                    makeSerializer = this.fSerializerFactory.makeSerializer(streamResult.getWriter(), outputFormat3);
                } else if (streamResult.getOutputStream() != null) {
                    new OutputFormat();
                    makeSerializer = this.fSerializerFactory.makeSerializer(streamResult.getOutputStream(), outputFormat2);
                } else if (streamResult.getSystemId() != null) {
                    OutputStream createOutputStream = XMLEntityManager.createOutputStream(streamResult.getSystemId());
                    new OutputFormat();
                    makeSerializer = this.fSerializerFactory.makeSerializer(createOutputStream, outputFormat);
                } else {
                    Throwable th3 = th;
                    new IllegalArgumentException(JAXPValidationMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "StreamResultNotInitialized", (Object[]) null));
                    throw th3;
                }
                SAXParser sAXParser2 = (SAXParser) this.fParser.get();
                if (z || sAXParser2 == null) {
                    new SAXParser(xMLParserConfiguration);
                    sAXParser2 = sAXParser;
                    new SoftReference(sAXParser2);
                    this.fParser = softReference;
                } else {
                    sAXParser2.reset();
                }
                xMLParserConfiguration.setDocumentHandler(this.fSchemaValidator);
                this.fSchemaValidator.setDocumentHandler(sAXParser2);
                sAXParser2.setContentHandler(makeSerializer.asContentHandler());
            } else {
                this.fSchemaValidator.setDocumentHandler((XMLDocumentHandler) null);
            }
            try {
                xMLParserConfiguration.parse(xMLInputSource2);
                this.fSchemaValidator.setDocumentHandler((XMLDocumentHandler) null);
            } catch (XMLParseException e) {
                throw Util.toSAXParseException(e);
            } catch (XNIException e2) {
                throw Util.toSAXException(e2);
            } catch (Throwable th4) {
                Throwable th5 = th4;
                this.fSchemaValidator.setDocumentHandler((XMLDocumentHandler) null);
                throw th5;
            }
        } else {
            Throwable th6 = th2;
            Locale locale = this.fComponentManager.getLocale();
            Object[] objArr = new Object[2];
            objArr[0] = source2.getClass().getName();
            Object[] objArr2 = objArr;
            objArr2[1] = result2.getClass().getName();
            new IllegalArgumentException(JAXPValidationMessageFormatter.formatMessage(locale, "SourceResultMismatch", objArr2));
            throw th6;
        }
    }
}
