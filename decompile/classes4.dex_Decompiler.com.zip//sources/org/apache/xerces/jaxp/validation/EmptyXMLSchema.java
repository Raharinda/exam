package org.apache.xerces.jaxp.validation;

import org.apache.xerces.xni.grammars.Grammar;
import org.apache.xerces.xni.grammars.XMLGrammarDescription;
import org.apache.xerces.xni.grammars.XMLGrammarPool;

final class EmptyXMLSchema extends AbstractXMLSchema implements XMLGrammarPool {
    private static final Grammar[] ZERO_LENGTH_GRAMMAR_ARRAY = new Grammar[0];

    public EmptyXMLSchema() {
    }

    public void cacheGrammars(String str, Grammar[] grammarArr) {
    }

    public void clear() {
    }

    public XMLGrammarPool getGrammarPool() {
        return this;
    }

    public boolean isFullyComposed() {
        return true;
    }

    public void lockPool() {
    }

    public Grammar retrieveGrammar(XMLGrammarDescription xMLGrammarDescription) {
        XMLGrammarDescription xMLGrammarDescription2 = xMLGrammarDescription;
        return null;
    }

    public Grammar[] retrieveInitialGrammarSet(String str) {
        String str2 = str;
        return ZERO_LENGTH_GRAMMAR_ARRAY;
    }

    public void unlockPool() {
    }
}
