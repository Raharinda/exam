package org.apache.xerces.jaxp;

import java.io.PrintStream;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

class DefaultValidationErrorHandler extends DefaultHandler {
    private static int ERROR_COUNT_LIMIT = 10;
    private int errorCount = 0;

    DefaultValidationErrorHandler() {
    }

    public void error(SAXParseException sAXParseException) throws SAXException {
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        SAXParseException sAXParseException2 = sAXParseException;
        if (this.errorCount < ERROR_COUNT_LIMIT) {
            if (this.errorCount == 0) {
                System.err.println("Warning: validation was turned on but an org.xml.sax.ErrorHandler was not");
                System.err.println("set, which is probably not what is desired.  Parser will use a default");
                PrintStream printStream = System.err;
                new StringBuffer();
                printStream.println(stringBuffer2.append("ErrorHandler to print the first ").append(ERROR_COUNT_LIMIT).append(" errors.  Please call").toString());
                System.err.println("the 'setErrorHandler' method to fix this.");
            }
            String systemId = sAXParseException2.getSystemId();
            if (systemId == null) {
                systemId = "null";
            }
            new StringBuffer();
            System.err.println(stringBuffer.append("Error: URI=").append(systemId).append(" Line=").append(sAXParseException2.getLineNumber()).append(": ").append(sAXParseException2.getMessage()).toString());
            this.errorCount++;
        }
    }
}
