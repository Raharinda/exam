package org.apache.xerces.jaxp.validation;

import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.SoftReference;
import org.apache.xerces.dom3.as.ASContentModel;
import org.apache.xerces.xni.grammars.Grammar;
import org.apache.xerces.xni.grammars.XMLGrammarDescription;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.grammars.XMLSchemaDescription;

final class SoftReferenceGrammarPool implements XMLGrammarPool {
    protected static final int TABLE_SIZE = 11;
    protected static final Grammar[] ZERO_LENGTH_GRAMMAR_ARRAY = new Grammar[0];
    protected int fGrammarCount = 0;
    protected Entry[] fGrammars = null;
    protected boolean fPoolIsLocked;
    protected final ReferenceQueue fReferenceQueue;

    static final class Entry {
        public int bucket;
        public XMLGrammarDescription desc;
        public SoftGrammarReference grammar;
        public int hash;
        public Entry next;
        public Entry prev = null;

        protected Entry(int i, int i2, XMLGrammarDescription xMLGrammarDescription, Grammar grammar2, Entry entry, ReferenceQueue referenceQueue) {
            SoftGrammarReference softGrammarReference;
            XMLGrammarDescription xMLGrammarDescription2 = xMLGrammarDescription;
            Grammar grammar3 = grammar2;
            Entry entry2 = entry;
            ReferenceQueue referenceQueue2 = referenceQueue;
            this.hash = i;
            this.bucket = i2;
            this.next = entry2;
            if (entry2 != null) {
                entry2.prev = this;
            }
            this.desc = xMLGrammarDescription2;
            new SoftGrammarReference(this, grammar3, referenceQueue2);
            this.grammar = softGrammarReference;
        }

        /* access modifiers changed from: protected */
        public void clear() {
            this.desc = null;
            this.grammar = null;
            if (this.next != null) {
                this.next.clear();
                this.next = null;
            }
        }
    }

    static final class SoftGrammarReference extends SoftReference {
        public Entry entry;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        protected SoftGrammarReference(Entry entry2, Grammar grammar, ReferenceQueue referenceQueue) {
            super(grammar, referenceQueue);
            this.entry = entry2;
        }
    }

    public SoftReferenceGrammarPool() {
        ReferenceQueue referenceQueue;
        new ReferenceQueue();
        this.fReferenceQueue = referenceQueue;
        this.fGrammars = new Entry[TABLE_SIZE];
        this.fPoolIsLocked = false;
    }

    public SoftReferenceGrammarPool(int i) {
        ReferenceQueue referenceQueue;
        new ReferenceQueue();
        this.fReferenceQueue = referenceQueue;
        this.fGrammars = new Entry[i];
        this.fPoolIsLocked = false;
    }

    private void clean() {
        Reference poll = this.fReferenceQueue.poll();
        while (true) {
            Reference reference = poll;
            if (reference != null) {
                Entry entry = ((SoftGrammarReference) reference).entry;
                if (entry != null) {
                    Grammar removeEntry = removeEntry(entry);
                }
                poll = this.fReferenceQueue.poll();
            } else {
                return;
            }
        }
    }

    private Grammar removeEntry(Entry entry) {
        Entry entry2 = entry;
        if (entry2.prev != null) {
            entry2.prev.next = entry2.next;
        } else {
            this.fGrammars[entry2.bucket] = entry2.next;
        }
        if (entry2.next != null) {
            entry2.next.prev = entry2.prev;
        }
        this.fGrammarCount--;
        entry2.grammar.entry = null;
        return (Grammar) entry2.grammar.get();
    }

    public void cacheGrammars(String str, Grammar[] grammarArr) {
        String str2 = str;
        Grammar[] grammarArr2 = grammarArr;
        if (!this.fPoolIsLocked) {
            for (int i = 0; i < grammarArr2.length; i++) {
                putGrammar(grammarArr2[i]);
            }
        }
    }

    public void clear() {
        for (int i = 0; i < this.fGrammars.length; i++) {
            if (this.fGrammars[i] != null) {
                this.fGrammars[i].clear();
                this.fGrammars[i] = null;
            }
        }
        this.fGrammarCount = 0;
    }

    /* JADX INFO: finally extract failed */
    public boolean containsGrammar(XMLGrammarDescription xMLGrammarDescription) {
        XMLGrammarDescription xMLGrammarDescription2 = xMLGrammarDescription;
        Entry[] entryArr = this.fGrammars;
        synchronized (entryArr) {
            try {
                clean();
                int hashCode = hashCode(xMLGrammarDescription2);
                for (Entry entry = this.fGrammars[(hashCode & ASContentModel.AS_UNBOUNDED) % this.fGrammars.length]; entry != null; entry = entry.next) {
                    if (((Grammar) entry.grammar.get()) == null) {
                        Grammar removeEntry = removeEntry(entry);
                    } else if (entry.hash == hashCode && equals(entry.desc, xMLGrammarDescription2)) {
                        return true;
                    }
                }
                return false;
            } catch (Throwable th) {
                Throwable th2 = th;
                Entry[] entryArr2 = entryArr;
                throw th2;
            }
        }
    }

    public boolean equals(XMLGrammarDescription xMLGrammarDescription, XMLGrammarDescription xMLGrammarDescription2) {
        XMLGrammarDescription xMLGrammarDescription3 = xMLGrammarDescription;
        XMLGrammarDescription xMLGrammarDescription4 = xMLGrammarDescription2;
        if (!(xMLGrammarDescription3 instanceof XMLSchemaDescription)) {
            return xMLGrammarDescription3.equals(xMLGrammarDescription4);
        }
        if (!(xMLGrammarDescription4 instanceof XMLSchemaDescription)) {
            return false;
        }
        XMLSchemaDescription xMLSchemaDescription = (XMLSchemaDescription) xMLGrammarDescription3;
        XMLSchemaDescription xMLSchemaDescription2 = (XMLSchemaDescription) xMLGrammarDescription4;
        String targetNamespace = xMLSchemaDescription.getTargetNamespace();
        if (targetNamespace != null) {
            if (!targetNamespace.equals(xMLSchemaDescription2.getTargetNamespace())) {
                return false;
            }
        } else if (xMLSchemaDescription2.getTargetNamespace() != null) {
            return false;
        }
        String expandedSystemId = xMLSchemaDescription.getExpandedSystemId();
        if (expandedSystemId != null) {
            if (!expandedSystemId.equals(xMLSchemaDescription2.getExpandedSystemId())) {
                return false;
            }
        } else if (xMLSchemaDescription2.getExpandedSystemId() != null) {
            return false;
        }
        return true;
    }

    /* JADX INFO: finally extract failed */
    public Grammar getGrammar(XMLGrammarDescription xMLGrammarDescription) {
        XMLGrammarDescription xMLGrammarDescription2 = xMLGrammarDescription;
        Entry[] entryArr = this.fGrammars;
        synchronized (entryArr) {
            try {
                clean();
                int hashCode = hashCode(xMLGrammarDescription2);
                for (Entry entry = this.fGrammars[(hashCode & ASContentModel.AS_UNBOUNDED) % this.fGrammars.length]; entry != null; entry = entry.next) {
                    Grammar grammar = (Grammar) entry.grammar.get();
                    if (grammar == null) {
                        Grammar removeEntry = removeEntry(entry);
                    } else if (entry.hash == hashCode && equals(entry.desc, xMLGrammarDescription2)) {
                        Grammar grammar2 = grammar;
                        return grammar2;
                    }
                }
                return null;
            } catch (Throwable th) {
                Throwable th2 = th;
                Entry[] entryArr2 = entryArr;
                throw th2;
            }
        }
    }

    public int hashCode(XMLGrammarDescription xMLGrammarDescription) {
        XMLGrammarDescription xMLGrammarDescription2 = xMLGrammarDescription;
        if (!(xMLGrammarDescription2 instanceof XMLSchemaDescription)) {
            return xMLGrammarDescription2.hashCode();
        }
        XMLSchemaDescription xMLSchemaDescription = (XMLSchemaDescription) xMLGrammarDescription2;
        String targetNamespace = xMLSchemaDescription.getTargetNamespace();
        String expandedSystemId = xMLSchemaDescription.getExpandedSystemId();
        return (targetNamespace != null ? targetNamespace.hashCode() : 0) ^ (expandedSystemId != null ? expandedSystemId.hashCode() : 0);
    }

    public void lockPool() {
        this.fPoolIsLocked = true;
    }

    /* JADX INFO: finally extract failed */
    public void putGrammar(Grammar grammar) {
        Entry entry;
        SoftGrammarReference softGrammarReference;
        Grammar grammar2 = grammar;
        if (!this.fPoolIsLocked) {
            Entry[] entryArr = this.fGrammars;
            synchronized (entryArr) {
                try {
                    clean();
                    XMLGrammarDescription grammarDescription = grammar2.getGrammarDescription();
                    int hashCode = hashCode(grammarDescription);
                    int length = (hashCode & ASContentModel.AS_UNBOUNDED) % this.fGrammars.length;
                    Entry entry2 = this.fGrammars[length];
                    while (true) {
                        Entry entry3 = entry2;
                        if (entry3 == null) {
                            new Entry(hashCode, length, grammarDescription, grammar2, this.fGrammars[length], this.fReferenceQueue);
                            this.fGrammars[length] = entry;
                            this.fGrammarCount++;
                            return;
                        } else if (entry3.hash != hashCode || !equals(entry3.desc, grammarDescription)) {
                            entry2 = entry3.next;
                        } else {
                            if (entry3.grammar.get() != grammar2) {
                                new SoftGrammarReference(entry3, grammar2, this.fReferenceQueue);
                                entry3.grammar = softGrammarReference;
                            }
                            return;
                        }
                    }
                } catch (Throwable th) {
                    Throwable th2 = th;
                    Entry[] entryArr2 = entryArr;
                    throw th2;
                }
            }
        }
    }

    /* JADX INFO: finally extract failed */
    public Grammar removeGrammar(XMLGrammarDescription xMLGrammarDescription) {
        XMLGrammarDescription xMLGrammarDescription2 = xMLGrammarDescription;
        Entry[] entryArr = this.fGrammars;
        synchronized (entryArr) {
            try {
                clean();
                int hashCode = hashCode(xMLGrammarDescription2);
                Entry entry = this.fGrammars[(hashCode & ASContentModel.AS_UNBOUNDED) % this.fGrammars.length];
                while (true) {
                    Entry entry2 = entry;
                    if (entry2 == null) {
                        return null;
                    }
                    if (entry2.hash != hashCode || !equals(entry2.desc, xMLGrammarDescription2)) {
                        entry = entry2.next;
                    } else {
                        Grammar removeEntry = removeEntry(entry2);
                        return removeEntry;
                    }
                }
            } catch (Throwable th) {
                Throwable th2 = th;
                Entry[] entryArr2 = entryArr;
                throw th2;
            }
        }
    }

    public Grammar retrieveGrammar(XMLGrammarDescription xMLGrammarDescription) {
        return getGrammar(xMLGrammarDescription);
    }

    public Grammar[] retrieveInitialGrammarSet(String str) {
        Grammar[] grammarArr;
        String str2 = str;
        Entry[] entryArr = this.fGrammars;
        synchronized (entryArr) {
            try {
                clean();
                grammarArr = ZERO_LENGTH_GRAMMAR_ARRAY;
            } catch (Throwable th) {
                Throwable th2 = th;
                Entry[] entryArr2 = entryArr;
                throw th2;
            }
        }
        return grammarArr;
    }

    public void unlockPool() {
        this.fPoolIsLocked = false;
    }
}
