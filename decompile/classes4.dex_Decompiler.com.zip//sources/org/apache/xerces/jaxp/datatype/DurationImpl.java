package org.apache.xerces.jaxp.datatype;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;
import org.apache.xerces.util.DatatypeMessageFormatter;

class DurationImpl extends Duration implements Serializable {
    private static final BigDecimal[] FACTORS;
    private static final DatatypeConstants.Field[] FIELDS;
    private static final XMLGregorianCalendar[] TEST_POINTS;
    private static final BigDecimal ZERO = BigDecimal.valueOf(0);
    private static final long serialVersionUID = -2650025807136350131L;
    private final BigInteger days;
    private final BigInteger hours;
    private final BigInteger minutes;
    private final BigInteger months;
    private final BigDecimal seconds;
    private final int signum;
    private final BigInteger years;

    static {
        DatatypeConstants.Field[] fieldArr = new DatatypeConstants.Field[6];
        fieldArr[0] = DatatypeConstants.YEARS;
        DatatypeConstants.Field[] fieldArr2 = fieldArr;
        fieldArr2[1] = DatatypeConstants.MONTHS;
        DatatypeConstants.Field[] fieldArr3 = fieldArr2;
        fieldArr3[2] = DatatypeConstants.DAYS;
        DatatypeConstants.Field[] fieldArr4 = fieldArr3;
        fieldArr4[3] = DatatypeConstants.HOURS;
        DatatypeConstants.Field[] fieldArr5 = fieldArr4;
        fieldArr5[4] = DatatypeConstants.MINUTES;
        DatatypeConstants.Field[] fieldArr6 = fieldArr5;
        fieldArr6[5] = DatatypeConstants.SECONDS;
        FIELDS = fieldArr6;
        XMLGregorianCalendar[] xMLGregorianCalendarArr = new XMLGregorianCalendar[4];
        xMLGregorianCalendarArr[0] = XMLGregorianCalendarImpl.parse("1696-09-01T00:00:00Z");
        XMLGregorianCalendar[] xMLGregorianCalendarArr2 = xMLGregorianCalendarArr;
        xMLGregorianCalendarArr2[1] = XMLGregorianCalendarImpl.parse("1697-02-01T00:00:00Z");
        XMLGregorianCalendar[] xMLGregorianCalendarArr3 = xMLGregorianCalendarArr2;
        xMLGregorianCalendarArr3[2] = XMLGregorianCalendarImpl.parse("1903-03-01T00:00:00Z");
        XMLGregorianCalendar[] xMLGregorianCalendarArr4 = xMLGregorianCalendarArr3;
        xMLGregorianCalendarArr4[3] = XMLGregorianCalendarImpl.parse("1903-07-01T00:00:00Z");
        TEST_POINTS = xMLGregorianCalendarArr4;
        BigDecimal[] bigDecimalArr = new BigDecimal[5];
        bigDecimalArr[0] = BigDecimal.valueOf(12);
        BigDecimal[] bigDecimalArr2 = bigDecimalArr;
        bigDecimalArr2[1] = null;
        BigDecimal[] bigDecimalArr3 = bigDecimalArr2;
        bigDecimalArr3[2] = BigDecimal.valueOf(24);
        BigDecimal[] bigDecimalArr4 = bigDecimalArr3;
        bigDecimalArr4[3] = BigDecimal.valueOf(60);
        BigDecimal[] bigDecimalArr5 = bigDecimalArr4;
        bigDecimalArr5[4] = BigDecimal.valueOf(60);
        FACTORS = bigDecimalArr5;
    }

    protected DurationImpl(long j) {
        boolean z = false;
        long j2 = j;
        if (j2 > 0) {
            this.signum = 1;
        } else if (j2 < 0) {
            this.signum = -1;
            if (j2 == Long.MIN_VALUE) {
                j2++;
                z = true;
            }
            j2 *= -1;
        } else {
            this.signum = 0;
        }
        this.years = null;
        this.months = null;
        this.seconds = BigDecimal.valueOf((j2 % 60000) + (z ? 1 : 0), 3);
        long j3 = j2 / 60000;
        this.minutes = j3 == 0 ? null : BigInteger.valueOf(j3 % 60);
        long j4 = j3 / 60;
        this.hours = j4 == 0 ? null : BigInteger.valueOf(j4 % 24);
        long j5 = j4 / 24;
        this.days = j5 == 0 ? null : BigInteger.valueOf(j5);
    }

    protected DurationImpl(String str) throws IllegalArgumentException {
        boolean z;
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        Throwable th6;
        String str2 = str;
        String str3 = str2;
        int[] iArr = new int[1];
        int length = str3.length();
        boolean z2 = false;
        if (str2 == null) {
            Throwable th7 = th6;
            new NullPointerException();
            throw th7;
        }
        iArr[0] = 0;
        if (length == iArr[0] || str3.charAt(iArr[0]) != '-') {
            z = true;
        } else {
            int[] iArr2 = iArr;
            iArr2[0] = iArr2[0] + 1;
            z = false;
        }
        if (length != iArr[0]) {
            int[] iArr3 = iArr;
            int i = iArr3[0];
            iArr3[0] = i + 1;
            if (str3.charAt(i) != 'P') {
                Throwable th8 = th5;
                new IllegalArgumentException(str3);
                throw th8;
            }
        }
        int i2 = 0;
        String[] strArr = new String[3];
        int[] iArr4 = new int[3];
        while (length != iArr[0] && isDigit(str3.charAt(iArr[0])) && i2 < 3) {
            iArr4[i2] = iArr[0];
            int i3 = i2;
            i2++;
            strArr[i3] = parsePiece(str3, iArr);
        }
        if (length != iArr[0]) {
            int[] iArr5 = iArr;
            int i4 = iArr5[0];
            iArr5[0] = i4 + 1;
            if (str3.charAt(i4) == 'T') {
                z2 = true;
            } else {
                Throwable th9 = th4;
                new IllegalArgumentException(str3);
                throw th9;
            }
        }
        int i5 = 0;
        String[] strArr2 = new String[3];
        int[] iArr6 = new int[3];
        while (length != iArr[0] && isDigitOrPeriod(str3.charAt(iArr[0])) && i5 < 3) {
            iArr6[i5] = iArr[0];
            int i6 = i5;
            i5++;
            strArr2[i6] = parsePiece(str3, iArr);
        }
        if (z2 && i5 == 0) {
            Throwable th10 = th3;
            new IllegalArgumentException(str3);
            throw th10;
        } else if (length != iArr[0]) {
            Throwable th11 = th2;
            new IllegalArgumentException(str3);
            throw th11;
        } else if (i2 == 0 && i5 == 0) {
            Throwable th12 = th;
            new IllegalArgumentException(str3);
            throw th12;
        } else {
            organizeParts(str3, strArr, iArr4, i2, "YMD");
            organizeParts(str3, strArr2, iArr6, i5, "HMS");
            this.years = parseBigInteger(str3, strArr[0], iArr4[0]);
            this.months = parseBigInteger(str3, strArr[1], iArr4[1]);
            this.days = parseBigInteger(str3, strArr[2], iArr4[2]);
            this.hours = parseBigInteger(str3, strArr2[0], iArr6[0]);
            this.minutes = parseBigInteger(str3, strArr2[1], iArr6[1]);
            this.seconds = parseBigDecimal(str3, strArr2[2], iArr6[2]);
            this.signum = calcSignum(z);
        }
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected DurationImpl(boolean r21, int r22, int r23, int r24, int r25, int r26, int r27) {
        /*
            r20 = this;
            r3 = r20
            r4 = r21
            r5 = r22
            r6 = r23
            r7 = r24
            r8 = r25
            r9 = r26
            r10 = r27
            r11 = r3
            r12 = r4
            r13 = r5
            java.math.BigInteger r13 = wrap(r13)
            r14 = r6
            java.math.BigInteger r14 = wrap(r14)
            r15 = r7
            java.math.BigInteger r15 = wrap(r15)
            r16 = r8
            java.math.BigInteger r16 = wrap(r16)
            r17 = r9
            java.math.BigInteger r17 = wrap(r17)
            r18 = r10
            if (r18 == 0) goto L_0x0040
            r18 = r10
            r0 = r18
            long r0 = (long) r0
            r18 = r0
            java.math.BigDecimal r18 = java.math.BigDecimal.valueOf(r18)
        L_0x003c:
            r11.<init>((boolean) r12, (java.math.BigInteger) r13, (java.math.BigInteger) r14, (java.math.BigInteger) r15, (java.math.BigInteger) r16, (java.math.BigInteger) r17, (java.math.BigDecimal) r18)
            return
        L_0x0040:
            r18 = 0
            goto L_0x003c
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.jaxp.datatype.DurationImpl.<init>(boolean, int, int, int, int, int, int):void");
    }

    protected DurationImpl(boolean z, BigInteger bigInteger, BigInteger bigInteger2, BigInteger bigInteger3, BigInteger bigInteger4, BigInteger bigInteger5, BigDecimal bigDecimal) {
        Throwable th;
        BigInteger bigInteger6 = bigInteger;
        BigInteger bigInteger7 = bigInteger2;
        BigInteger bigInteger8 = bigInteger3;
        BigInteger bigInteger9 = bigInteger4;
        BigInteger bigInteger10 = bigInteger5;
        BigDecimal bigDecimal2 = bigDecimal;
        this.years = bigInteger6;
        this.months = bigInteger7;
        this.days = bigInteger8;
        this.hours = bigInteger9;
        this.minutes = bigInteger10;
        this.seconds = bigDecimal2;
        this.signum = calcSignum(z);
        if (bigInteger6 == null && bigInteger7 == null && bigInteger8 == null && bigInteger9 == null && bigInteger10 == null && bigDecimal2 == null) {
            Throwable th2 = th;
            new IllegalArgumentException(DatatypeMessageFormatter.formatMessage((Locale) null, "AllFieldsNull", (Object[]) null));
            throw th2;
        }
        testNonNegative(bigInteger6, DatatypeConstants.YEARS);
        testNonNegative(bigInteger7, DatatypeConstants.MONTHS);
        testNonNegative(bigInteger8, DatatypeConstants.DAYS);
        testNonNegative(bigInteger9, DatatypeConstants.HOURS);
        testNonNegative(bigInteger10, DatatypeConstants.MINUTES);
        testNonNegative(bigDecimal2, DatatypeConstants.SECONDS);
    }

    private static void alignSigns(BigDecimal[] bigDecimalArr, int i, int i2) {
        boolean z;
        BigDecimal[] bigDecimalArr2 = bigDecimalArr;
        int i3 = i;
        int i4 = i2;
        do {
            z = false;
            int i5 = 0;
            for (int i6 = i3; i6 < i4; i6++) {
                if (i5 * bigDecimalArr2[i6].signum() < 0) {
                    z = true;
                    BigDecimal divide = bigDecimalArr2[i6].abs().divide(FACTORS[i6 - 1], 0);
                    if (bigDecimalArr2[i6].signum() > 0) {
                        divide = divide.negate();
                    }
                    bigDecimalArr2[i6 - 1] = bigDecimalArr2[i6 - 1].subtract(divide);
                    bigDecimalArr2[i6] = bigDecimalArr2[i6].add(divide.multiply(FACTORS[i6 - 1]));
                }
                if (bigDecimalArr2[i6].signum() != 0) {
                    i5 = bigDecimalArr2[i6].signum();
                }
            }
        } while (z);
    }

    private int calcSignum(boolean z) {
        boolean z2 = z;
        if ((this.years == null || this.years.signum() == 0) && ((this.months == null || this.months.signum() == 0) && ((this.days == null || this.days.signum() == 0) && ((this.hours == null || this.hours.signum() == 0) && ((this.minutes == null || this.minutes.signum() == 0) && (this.seconds == null || this.seconds.signum() == 0)))))) {
            return 0;
        }
        return z2 ? 1 : -1;
    }

    private int compareDates(Duration duration, Duration duration2) {
        Duration duration3 = duration;
        Duration duration4 = duration2;
        XMLGregorianCalendar xMLGregorianCalendar = (XMLGregorianCalendar) TEST_POINTS[0].clone();
        XMLGregorianCalendar xMLGregorianCalendar2 = (XMLGregorianCalendar) TEST_POINTS[0].clone();
        xMLGregorianCalendar.add(duration3);
        xMLGregorianCalendar2.add(duration4);
        int compare = xMLGregorianCalendar.compare(xMLGregorianCalendar2);
        if (compare == 2) {
            return 2;
        }
        XMLGregorianCalendar xMLGregorianCalendar3 = (XMLGregorianCalendar) TEST_POINTS[1].clone();
        XMLGregorianCalendar xMLGregorianCalendar4 = (XMLGregorianCalendar) TEST_POINTS[1].clone();
        xMLGregorianCalendar3.add(duration3);
        xMLGregorianCalendar4.add(duration4);
        int compareResults = compareResults(compare, xMLGregorianCalendar3.compare(xMLGregorianCalendar4));
        if (compareResults == 2) {
            return 2;
        }
        XMLGregorianCalendar xMLGregorianCalendar5 = (XMLGregorianCalendar) TEST_POINTS[2].clone();
        XMLGregorianCalendar xMLGregorianCalendar6 = (XMLGregorianCalendar) TEST_POINTS[2].clone();
        xMLGregorianCalendar5.add(duration3);
        xMLGregorianCalendar6.add(duration4);
        int compareResults2 = compareResults(compareResults, xMLGregorianCalendar5.compare(xMLGregorianCalendar6));
        if (compareResults2 == 2) {
            return 2;
        }
        XMLGregorianCalendar xMLGregorianCalendar7 = (XMLGregorianCalendar) TEST_POINTS[3].clone();
        XMLGregorianCalendar xMLGregorianCalendar8 = (XMLGregorianCalendar) TEST_POINTS[3].clone();
        xMLGregorianCalendar7.add(duration3);
        xMLGregorianCalendar8.add(duration4);
        return compareResults(compareResults2, xMLGregorianCalendar7.compare(xMLGregorianCalendar8));
    }

    private int compareResults(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        if (i4 == 2) {
            return 2;
        }
        if (i3 != i4) {
            return 2;
        }
        return i3;
    }

    private static long getCalendarTimeInMillis(Calendar calendar) {
        return calendar.getTime().getTime();
    }

    private BigDecimal getFieldAsBigDecimal(DatatypeConstants.Field field) {
        BigDecimal bigDecimal;
        DatatypeConstants.Field field2 = field;
        if (field2 == DatatypeConstants.SECONDS) {
            return this.seconds != null ? this.seconds : ZERO;
        }
        BigInteger bigInteger = (BigInteger) getField(field2);
        if (bigInteger == null) {
            return ZERO;
        }
        new BigDecimal(bigInteger);
        return bigDecimal;
    }

    private int getInt(DatatypeConstants.Field field) {
        Number field2 = getField(field);
        if (field2 == null) {
            return 0;
        }
        return field2.intValue();
    }

    private static boolean isDigit(char c) {
        char c2 = c;
        return '0' <= c2 && c2 <= '9';
    }

    private static boolean isDigitOrPeriod(char c) {
        char c2 = c;
        return isDigit(c2) || c2 == '.';
    }

    private static void organizeParts(String str, String[] strArr, int[] iArr, int i, String str2) throws IllegalArgumentException {
        Throwable th;
        Throwable th2;
        String str3 = str;
        String[] strArr2 = strArr;
        int[] iArr2 = iArr;
        String str4 = str2;
        int length = str4.length();
        for (int i2 = i - 1; i2 >= 0; i2--) {
            if (strArr2[i2] == null) {
                Throwable th3 = th;
                new IllegalArgumentException(str3);
                throw th3;
            }
            int lastIndexOf = str4.lastIndexOf(strArr2[i2].charAt(strArr2[i2].length() - 1), length - 1);
            if (lastIndexOf == -1) {
                Throwable th4 = th2;
                new IllegalArgumentException(str3);
                throw th4;
            }
            for (int i3 = lastIndexOf + 1; i3 < length; i3++) {
                strArr2[i3] = null;
            }
            length = lastIndexOf;
            strArr2[length] = strArr2[i2];
            iArr2[length] = iArr2[i2];
        }
        while (true) {
            length--;
            if (length >= 0) {
                strArr2[length] = null;
            } else {
                return;
            }
        }
    }

    private static BigDecimal parseBigDecimal(String str, String str2, int i) throws IllegalArgumentException {
        BigDecimal bigDecimal;
        String str3 = str;
        String str4 = str2;
        int i2 = i;
        if (str4 == null) {
            return null;
        }
        new BigDecimal(str4.substring(0, str4.length() - 1));
        return bigDecimal;
    }

    private static BigInteger parseBigInteger(String str, String str2, int i) throws IllegalArgumentException {
        BigInteger bigInteger;
        String str3 = str;
        String str4 = str2;
        int i2 = i;
        if (str4 == null) {
            return null;
        }
        new BigInteger(str4.substring(0, str4.length() - 1));
        return bigInteger;
    }

    private static String parsePiece(String str, int[] iArr) throws IllegalArgumentException {
        Throwable th;
        String str2 = str;
        int[] iArr2 = iArr;
        int i = iArr2[0];
        while (iArr2[0] < str2.length() && isDigitOrPeriod(str2.charAt(iArr2[0]))) {
            int[] iArr3 = iArr2;
            iArr3[0] = iArr3[0] + 1;
        }
        if (iArr2[0] == str2.length()) {
            Throwable th2 = th;
            new IllegalArgumentException(str2);
            throw th2;
        }
        int[] iArr4 = iArr2;
        iArr4[0] = iArr4[0] + 1;
        return str2.substring(i, iArr2[0]);
    }

    static BigDecimal sanitize(BigDecimal bigDecimal, int i) {
        BigDecimal bigDecimal2 = bigDecimal;
        int i2 = i;
        return (i2 == 0 || bigDecimal2 == null) ? ZERO : i2 > 0 ? bigDecimal2 : bigDecimal2.negate();
    }

    private static BigDecimal sanitize(BigInteger bigInteger, int i) {
        BigDecimal bigDecimal;
        BigDecimal bigDecimal2;
        BigInteger bigInteger2 = bigInteger;
        int i2 = i;
        if (i2 == 0 || bigInteger2 == null) {
            return ZERO;
        }
        if (i2 > 0) {
            new BigDecimal(bigInteger2);
            return bigDecimal2;
        }
        new BigDecimal(bigInteger2.negate());
        return bigDecimal;
    }

    private static void testNonNegative(BigDecimal bigDecimal, DatatypeConstants.Field field) {
        Throwable th;
        BigDecimal bigDecimal2 = bigDecimal;
        DatatypeConstants.Field field2 = field;
        if (bigDecimal2 != null && bigDecimal2.signum() < 0) {
            Throwable th2 = th;
            new IllegalArgumentException(DatatypeMessageFormatter.formatMessage((Locale) null, "NegativeField", new Object[]{field2.toString()}));
            throw th2;
        }
    }

    private static void testNonNegative(BigInteger bigInteger, DatatypeConstants.Field field) {
        Throwable th;
        BigInteger bigInteger2 = bigInteger;
        DatatypeConstants.Field field2 = field;
        if (bigInteger2 != null && bigInteger2.signum() < 0) {
            Throwable th2 = th;
            new IllegalArgumentException(DatatypeMessageFormatter.formatMessage((Locale) null, "NegativeField", new Object[]{field2.toString()}));
            throw th2;
        }
    }

    private static BigInteger toBigInteger(BigDecimal bigDecimal, boolean z) {
        BigDecimal bigDecimal2 = bigDecimal;
        if (!z || bigDecimal2.signum() != 0) {
            return bigDecimal2.unscaledValue();
        }
        return null;
    }

    private String toString(BigDecimal bigDecimal) {
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        StringBuffer stringBuffer3;
        StringBuffer stringBuffer4;
        BigDecimal bigDecimal2 = bigDecimal;
        String bigInteger = bigDecimal2.unscaledValue().toString();
        int scale = bigDecimal2.scale();
        if (scale == 0) {
            return bigInteger;
        }
        int length = bigInteger.length() - scale;
        if (length == 0) {
            new StringBuffer();
            return stringBuffer4.append("0.").append(bigInteger).toString();
        }
        if (length > 0) {
            new StringBuffer(bigInteger);
            stringBuffer2 = stringBuffer3;
            StringBuffer insert = stringBuffer2.insert(length, '.');
        } else {
            new StringBuffer((3 - length) + bigInteger.length());
            stringBuffer2 = stringBuffer;
            StringBuffer append = stringBuffer2.append("0.");
            for (int i = 0; i < (-length); i++) {
                StringBuffer append2 = stringBuffer2.append('0');
            }
            StringBuffer append3 = stringBuffer2.append(bigInteger);
        }
        return stringBuffer2.toString();
    }

    private static BigInteger wrap(int i) {
        int i2 = i;
        if (i2 == Integer.MIN_VALUE) {
            return null;
        }
        return BigInteger.valueOf((long) i2);
    }

    private Object writeReplace() throws IOException {
        Object obj;
        new SerializedDuration(toString());
        return obj;
    }

    public Duration add(Duration duration) {
        Throwable th;
        Duration duration2 = duration;
        BigDecimal[] bigDecimalArr = {sanitize((BigInteger) getField(DatatypeConstants.YEARS), getSign()).add(sanitize((BigInteger) duration2.getField(DatatypeConstants.YEARS), duration2.getSign())), sanitize((BigInteger) getField(DatatypeConstants.MONTHS), getSign()).add(sanitize((BigInteger) duration2.getField(DatatypeConstants.MONTHS), duration2.getSign())), sanitize((BigInteger) getField(DatatypeConstants.DAYS), getSign()).add(sanitize((BigInteger) duration2.getField(DatatypeConstants.DAYS), duration2.getSign())), sanitize((BigInteger) getField(DatatypeConstants.HOURS), getSign()).add(sanitize((BigInteger) duration2.getField(DatatypeConstants.HOURS), duration2.getSign())), sanitize((BigInteger) getField(DatatypeConstants.MINUTES), getSign()).add(sanitize((BigInteger) duration2.getField(DatatypeConstants.MINUTES), duration2.getSign())), sanitize((BigDecimal) getField(DatatypeConstants.SECONDS), getSign()).add(sanitize((BigDecimal) duration2.getField(DatatypeConstants.SECONDS), duration2.getSign()))};
        alignSigns(bigDecimalArr, 0, 2);
        alignSigns(bigDecimalArr, 2, 6);
        int i = 0;
        for (int i2 = 0; i2 < 6; i2++) {
            if (i * bigDecimalArr[i2].signum() < 0) {
                Throwable th2 = th;
                new IllegalStateException();
                throw th2;
            }
            if (i == 0) {
                i = bigDecimalArr[i2].signum();
            }
        }
        DurationImpl durationImpl = r16;
        DurationImpl durationImpl2 = new DurationImpl(i >= 0, toBigInteger(sanitize(bigDecimalArr[0], i), getField(DatatypeConstants.YEARS) == null && duration2.getField(DatatypeConstants.YEARS) == null), toBigInteger(sanitize(bigDecimalArr[1], i), getField(DatatypeConstants.MONTHS) == null && duration2.getField(DatatypeConstants.MONTHS) == null), toBigInteger(sanitize(bigDecimalArr[2], i), getField(DatatypeConstants.DAYS) == null && duration2.getField(DatatypeConstants.DAYS) == null), toBigInteger(sanitize(bigDecimalArr[3], i), getField(DatatypeConstants.HOURS) == null && duration2.getField(DatatypeConstants.HOURS) == null), toBigInteger(sanitize(bigDecimalArr[4], i), getField(DatatypeConstants.MINUTES) == null && duration2.getField(DatatypeConstants.MINUTES) == null), (bigDecimalArr[5].signum() == 0 && getField(DatatypeConstants.SECONDS) == null && duration2.getField(DatatypeConstants.SECONDS) == null) ? null : sanitize(bigDecimalArr[5], i));
        return durationImpl;
    }

    public void addTo(Calendar calendar) {
        Calendar calendar2 = calendar;
        calendar2.add(1, getYears() * this.signum);
        calendar2.add(2, getMonths() * this.signum);
        calendar2.add(5, getDays() * this.signum);
        calendar2.add(10, getHours() * this.signum);
        calendar2.add(12, getMinutes() * this.signum);
        calendar2.add(13, getSeconds() * this.signum);
        if (this.seconds != null) {
            calendar2.add(14, this.seconds.subtract(this.seconds.setScale(0, 1)).movePointRight(3).intValue() * this.signum);
        }
    }

    public void addTo(Date date) {
        Calendar calendar;
        Date date2 = date;
        new GregorianCalendar();
        Calendar calendar2 = calendar;
        calendar2.setTime(date2);
        addTo(calendar2);
        date2.setTime(getCalendarTimeInMillis(calendar2));
    }

    public int compare(Duration duration) {
        GregorianCalendar gregorianCalendar;
        GregorianCalendar gregorianCalendar2;
        Throwable th;
        StringBuffer stringBuffer;
        Throwable th2;
        StringBuffer stringBuffer2;
        Throwable th3;
        StringBuffer stringBuffer3;
        Throwable th4;
        StringBuffer stringBuffer4;
        Throwable th5;
        StringBuffer stringBuffer5;
        Throwable th6;
        StringBuffer stringBuffer6;
        Throwable th7;
        StringBuffer stringBuffer7;
        Throwable th8;
        StringBuffer stringBuffer8;
        Throwable th9;
        StringBuffer stringBuffer9;
        Throwable th10;
        StringBuffer stringBuffer10;
        Throwable th11;
        StringBuffer stringBuffer11;
        Throwable th12;
        StringBuffer stringBuffer12;
        Duration duration2 = duration;
        BigInteger valueOf = BigInteger.valueOf(2147483647L);
        if (this.years != null && this.years.compareTo(valueOf) == 1) {
            Throwable th13 = th12;
            Object[] objArr = new Object[2];
            new StringBuffer();
            objArr[0] = stringBuffer12.append(getClass().getName()).append("#compare(Duration duration)").append(DatatypeConstants.YEARS.toString()).toString();
            Object[] objArr2 = objArr;
            objArr2[1] = this.years.toString();
            new UnsupportedOperationException(DatatypeMessageFormatter.formatMessage((Locale) null, "TooLarge", objArr2));
            throw th13;
        } else if (this.months != null && this.months.compareTo(valueOf) == 1) {
            Throwable th14 = th11;
            Object[] objArr3 = new Object[2];
            new StringBuffer();
            objArr3[0] = stringBuffer11.append(getClass().getName()).append("#compare(Duration duration)").append(DatatypeConstants.MONTHS.toString()).toString();
            Object[] objArr4 = objArr3;
            objArr4[1] = this.months.toString();
            new UnsupportedOperationException(DatatypeMessageFormatter.formatMessage((Locale) null, "TooLarge", objArr4));
            throw th14;
        } else if (this.days != null && this.days.compareTo(valueOf) == 1) {
            Throwable th15 = th10;
            Object[] objArr5 = new Object[2];
            new StringBuffer();
            objArr5[0] = stringBuffer10.append(getClass().getName()).append("#compare(Duration duration)").append(DatatypeConstants.DAYS.toString()).toString();
            Object[] objArr6 = objArr5;
            objArr6[1] = this.days.toString();
            new UnsupportedOperationException(DatatypeMessageFormatter.formatMessage((Locale) null, "TooLarge", objArr6));
            throw th15;
        } else if (this.hours != null && this.hours.compareTo(valueOf) == 1) {
            Throwable th16 = th9;
            Object[] objArr7 = new Object[2];
            new StringBuffer();
            objArr7[0] = stringBuffer9.append(getClass().getName()).append("#compare(Duration duration)").append(DatatypeConstants.HOURS.toString()).toString();
            Object[] objArr8 = objArr7;
            objArr8[1] = this.hours.toString();
            new UnsupportedOperationException(DatatypeMessageFormatter.formatMessage((Locale) null, "TooLarge", objArr8));
            throw th16;
        } else if (this.minutes != null && this.minutes.compareTo(valueOf) == 1) {
            Throwable th17 = th8;
            Object[] objArr9 = new Object[2];
            new StringBuffer();
            objArr9[0] = stringBuffer8.append(getClass().getName()).append("#compare(Duration duration)").append(DatatypeConstants.MINUTES.toString()).toString();
            Object[] objArr10 = objArr9;
            objArr10[1] = this.minutes.toString();
            new UnsupportedOperationException(DatatypeMessageFormatter.formatMessage((Locale) null, "TooLarge", objArr10));
            throw th17;
        } else if (this.seconds == null || this.seconds.toBigInteger().compareTo(valueOf) != 1) {
            BigInteger bigInteger = (BigInteger) duration2.getField(DatatypeConstants.YEARS);
            if (bigInteger == null || bigInteger.compareTo(valueOf) != 1) {
                BigInteger bigInteger2 = (BigInteger) duration2.getField(DatatypeConstants.MONTHS);
                if (bigInteger2 == null || bigInteger2.compareTo(valueOf) != 1) {
                    BigInteger bigInteger3 = (BigInteger) duration2.getField(DatatypeConstants.DAYS);
                    if (bigInteger3 == null || bigInteger3.compareTo(valueOf) != 1) {
                        BigInteger bigInteger4 = (BigInteger) duration2.getField(DatatypeConstants.HOURS);
                        if (bigInteger4 == null || bigInteger4.compareTo(valueOf) != 1) {
                            BigInteger bigInteger5 = (BigInteger) duration2.getField(DatatypeConstants.MINUTES);
                            if (bigInteger5 == null || bigInteger5.compareTo(valueOf) != 1) {
                                BigDecimal bigDecimal = (BigDecimal) duration2.getField(DatatypeConstants.SECONDS);
                                BigInteger bigInteger6 = null;
                                if (bigDecimal != null) {
                                    bigInteger6 = bigDecimal.toBigInteger();
                                }
                                if (bigInteger6 == null || bigInteger6.compareTo(valueOf) != 1) {
                                    new GregorianCalendar(1970, 1, 1, 0, 0, 0);
                                    GregorianCalendar gregorianCalendar3 = gregorianCalendar;
                                    gregorianCalendar3.add(1, getYears() * getSign());
                                    gregorianCalendar3.add(2, getMonths() * getSign());
                                    gregorianCalendar3.add(6, getDays() * getSign());
                                    gregorianCalendar3.add(11, getHours() * getSign());
                                    gregorianCalendar3.add(12, getMinutes() * getSign());
                                    gregorianCalendar3.add(13, getSeconds() * getSign());
                                    new GregorianCalendar(1970, 1, 1, 0, 0, 0);
                                    GregorianCalendar gregorianCalendar4 = gregorianCalendar2;
                                    gregorianCalendar4.add(1, duration2.getYears() * duration2.getSign());
                                    gregorianCalendar4.add(2, duration2.getMonths() * duration2.getSign());
                                    gregorianCalendar4.add(6, duration2.getDays() * duration2.getSign());
                                    gregorianCalendar4.add(11, duration2.getHours() * duration2.getSign());
                                    gregorianCalendar4.add(12, duration2.getMinutes() * duration2.getSign());
                                    gregorianCalendar4.add(13, duration2.getSeconds() * duration2.getSign());
                                    if (gregorianCalendar3.equals(gregorianCalendar4)) {
                                        return 0;
                                    }
                                    return compareDates(this, duration2);
                                }
                                Throwable th18 = th;
                                Object[] objArr11 = new Object[2];
                                new StringBuffer();
                                objArr11[0] = stringBuffer.append(getClass().getName()).append("#compare(Duration duration)").append(DatatypeConstants.SECONDS.toString()).toString();
                                Object[] objArr12 = objArr11;
                                objArr12[1] = bigInteger6.toString();
                                new UnsupportedOperationException(DatatypeMessageFormatter.formatMessage((Locale) null, "TooLarge", objArr12));
                                throw th18;
                            }
                            Throwable th19 = th2;
                            Object[] objArr13 = new Object[2];
                            new StringBuffer();
                            objArr13[0] = stringBuffer2.append(getClass().getName()).append("#compare(Duration duration)").append(DatatypeConstants.MINUTES.toString()).toString();
                            Object[] objArr14 = objArr13;
                            objArr14[1] = bigInteger5.toString();
                            new UnsupportedOperationException(DatatypeMessageFormatter.formatMessage((Locale) null, "TooLarge", objArr14));
                            throw th19;
                        }
                        Throwable th20 = th3;
                        Object[] objArr15 = new Object[2];
                        new StringBuffer();
                        objArr15[0] = stringBuffer3.append(getClass().getName()).append("#compare(Duration duration)").append(DatatypeConstants.HOURS.toString()).toString();
                        Object[] objArr16 = objArr15;
                        objArr16[1] = bigInteger4.toString();
                        new UnsupportedOperationException(DatatypeMessageFormatter.formatMessage((Locale) null, "TooLarge", objArr16));
                        throw th20;
                    }
                    Throwable th21 = th4;
                    Object[] objArr17 = new Object[2];
                    new StringBuffer();
                    objArr17[0] = stringBuffer4.append(getClass().getName()).append("#compare(Duration duration)").append(DatatypeConstants.DAYS.toString()).toString();
                    Object[] objArr18 = objArr17;
                    objArr18[1] = bigInteger3.toString();
                    new UnsupportedOperationException(DatatypeMessageFormatter.formatMessage((Locale) null, "TooLarge", objArr18));
                    throw th21;
                }
                Throwable th22 = th5;
                Object[] objArr19 = new Object[2];
                new StringBuffer();
                objArr19[0] = stringBuffer5.append(getClass().getName()).append("#compare(Duration duration)").append(DatatypeConstants.MONTHS.toString()).toString();
                Object[] objArr20 = objArr19;
                objArr20[1] = bigInteger2.toString();
                new UnsupportedOperationException(DatatypeMessageFormatter.formatMessage((Locale) null, "TooLarge", objArr20));
                throw th22;
            }
            Throwable th23 = th6;
            Object[] objArr21 = new Object[2];
            new StringBuffer();
            objArr21[0] = stringBuffer6.append(getClass().getName()).append("#compare(Duration duration)").append(DatatypeConstants.YEARS.toString()).toString();
            Object[] objArr22 = objArr21;
            objArr22[1] = bigInteger.toString();
            new UnsupportedOperationException(DatatypeMessageFormatter.formatMessage((Locale) null, "TooLarge", objArr22));
            throw th23;
        } else {
            Throwable th24 = th7;
            Object[] objArr23 = new Object[2];
            new StringBuffer();
            objArr23[0] = stringBuffer7.append(getClass().getName()).append("#compare(Duration duration)").append(DatatypeConstants.SECONDS.toString()).toString();
            Object[] objArr24 = objArr23;
            objArr24[1] = toString(this.seconds);
            new UnsupportedOperationException(DatatypeMessageFormatter.formatMessage((Locale) null, "TooLarge", objArr24));
            throw th24;
        }
    }

    public int getDays() {
        return getInt(DatatypeConstants.DAYS);
    }

    public Number getField(DatatypeConstants.Field field) {
        Throwable th;
        Throwable th2;
        DatatypeConstants.Field field2 = field;
        if (field2 == null) {
            Throwable th3 = th2;
            new NullPointerException(DatatypeMessageFormatter.formatMessage((Locale) null, "FieldCannotBeNull", new Object[]{"javax.xml.datatype.Duration#isSet(DatatypeConstants.Field field) "}));
            throw th3;
        } else if (field2 == DatatypeConstants.YEARS) {
            return this.years;
        } else {
            if (field2 == DatatypeConstants.MONTHS) {
                return this.months;
            }
            if (field2 == DatatypeConstants.DAYS) {
                return this.days;
            }
            if (field2 == DatatypeConstants.HOURS) {
                return this.hours;
            }
            if (field2 == DatatypeConstants.MINUTES) {
                return this.minutes;
            }
            if (field2 == DatatypeConstants.SECONDS) {
                return this.seconds;
            }
            Throwable th4 = th;
            Object[] objArr = new Object[2];
            objArr[0] = "javax.xml.datatype.Duration#(getSet(DatatypeConstants.Field field)";
            Object[] objArr2 = objArr;
            objArr2[1] = field2.toString();
            new IllegalArgumentException(DatatypeMessageFormatter.formatMessage((Locale) null, "UnknownField", objArr2));
            throw th4;
        }
    }

    public int getHours() {
        return getInt(DatatypeConstants.HOURS);
    }

    public int getMinutes() {
        return getInt(DatatypeConstants.MINUTES);
    }

    public int getMonths() {
        return getInt(DatatypeConstants.MONTHS);
    }

    public int getSeconds() {
        return getInt(DatatypeConstants.SECONDS);
    }

    public int getSign() {
        return this.signum;
    }

    public long getTimeInMillis(Calendar calendar) {
        Calendar calendar2 = calendar;
        Calendar calendar3 = (Calendar) calendar2.clone();
        addTo(calendar3);
        return getCalendarTimeInMillis(calendar3) - getCalendarTimeInMillis(calendar2);
    }

    public long getTimeInMillis(Date date) {
        Calendar calendar;
        Date date2 = date;
        new GregorianCalendar();
        Calendar calendar2 = calendar;
        calendar2.setTime(date2);
        addTo(calendar2);
        return getCalendarTimeInMillis(calendar2) - date2.getTime();
    }

    public int getYears() {
        return getInt(DatatypeConstants.YEARS);
    }

    public int hashCode() {
        GregorianCalendar gregorianCalendar = TEST_POINTS[0].toGregorianCalendar();
        addTo((Calendar) gregorianCalendar);
        return (int) getCalendarTimeInMillis(gregorianCalendar);
    }

    public boolean isSet(DatatypeConstants.Field field) {
        Throwable th;
        Throwable th2;
        DatatypeConstants.Field field2 = field;
        if (field2 == null) {
            Throwable th3 = th2;
            new NullPointerException(DatatypeMessageFormatter.formatMessage((Locale) null, "FieldCannotBeNull", new Object[]{"javax.xml.datatype.Duration#isSet(DatatypeConstants.Field field)"}));
            throw th3;
        } else if (field2 == DatatypeConstants.YEARS) {
            return this.years != null;
        } else if (field2 == DatatypeConstants.MONTHS) {
            return this.months != null;
        } else if (field2 == DatatypeConstants.DAYS) {
            return this.days != null;
        } else if (field2 == DatatypeConstants.HOURS) {
            return this.hours != null;
        } else if (field2 == DatatypeConstants.MINUTES) {
            return this.minutes != null;
        } else if (field2 == DatatypeConstants.SECONDS) {
            return this.seconds != null;
        } else {
            Throwable th4 = th;
            Object[] objArr = new Object[2];
            objArr[0] = "javax.xml.datatype.Duration#isSet(DatatypeConstants.Field field)";
            Object[] objArr2 = objArr;
            objArr2[1] = field2.toString();
            new IllegalArgumentException(DatatypeMessageFormatter.formatMessage((Locale) null, "UnknownField", objArr2));
            throw th4;
        }
    }

    public Duration multiply(int i) {
        return multiply(BigDecimal.valueOf((long) i));
    }

    public Duration multiply(BigDecimal bigDecimal) {
        BigDecimal bigDecimal2;
        BigDecimal multiply;
        Throwable th;
        BigDecimal bigDecimal3 = bigDecimal;
        BigDecimal bigDecimal4 = ZERO;
        int signum2 = bigDecimal3.signum();
        BigDecimal abs = bigDecimal3.abs();
        BigDecimal[] bigDecimalArr = new BigDecimal[6];
        for (int i = 0; i < 5; i++) {
            BigDecimal add = getFieldAsBigDecimal(FIELDS[i]).multiply(abs).add(bigDecimal4);
            bigDecimalArr[i] = add.setScale(0, 1);
            BigDecimal subtract = add.subtract(bigDecimalArr[i]);
            if (i != 1) {
                multiply = subtract.multiply(FACTORS[i]);
            } else if (subtract.signum() != 0) {
                Throwable th2 = th;
                new IllegalStateException();
                throw th2;
            } else {
                multiply = ZERO;
            }
            bigDecimal4 = multiply;
        }
        if (this.seconds != null) {
            bigDecimalArr[5] = this.seconds.multiply(abs).add(bigDecimal4);
        } else {
            bigDecimalArr[5] = bigDecimal4;
        }
        DurationImpl durationImpl = r19;
        boolean z = this.signum * signum2 >= 0;
        BigInteger bigInteger = toBigInteger(bigDecimalArr[0], null == this.years);
        BigInteger bigInteger2 = toBigInteger(bigDecimalArr[1], null == this.months);
        BigInteger bigInteger3 = toBigInteger(bigDecimalArr[2], null == this.days);
        BigInteger bigInteger4 = toBigInteger(bigDecimalArr[3], null == this.hours);
        BigInteger bigInteger5 = toBigInteger(bigDecimalArr[4], null == this.minutes);
        if (bigDecimalArr[5].signum() == 0) {
            if (this.seconds == null) {
                bigDecimal2 = null;
                DurationImpl durationImpl2 = new DurationImpl(z, bigInteger, bigInteger2, bigInteger3, bigInteger4, bigInteger5, bigDecimal2);
                return durationImpl;
            }
        }
        bigDecimal2 = bigDecimalArr[5];
        DurationImpl durationImpl22 = new DurationImpl(z, bigInteger, bigInteger2, bigInteger3, bigInteger4, bigInteger5, bigDecimal2);
        return durationImpl;
    }

    public Duration negate() {
        DurationImpl durationImpl = r10;
        DurationImpl durationImpl2 = new DurationImpl(this.signum <= 0, this.years, this.months, this.days, this.hours, this.minutes, this.seconds);
        return durationImpl;
    }

    public Duration normalizeWith(Calendar calendar) {
        Calendar calendar2 = calendar;
        Calendar calendar3 = (Calendar) calendar2.clone();
        calendar3.add(1, getYears() * this.signum);
        calendar3.add(2, getMonths() * this.signum);
        calendar3.add(5, getDays() * this.signum);
        int calendarTimeInMillis = (int) ((getCalendarTimeInMillis(calendar3) - getCalendarTimeInMillis(calendar2)) / 86400000);
        DurationImpl durationImpl = r16;
        DurationImpl durationImpl2 = new DurationImpl(calendarTimeInMillis >= 0, (BigInteger) null, (BigInteger) null, wrap(Math.abs(calendarTimeInMillis)), (BigInteger) getField(DatatypeConstants.HOURS), (BigInteger) getField(DatatypeConstants.MINUTES), (BigDecimal) getField(DatatypeConstants.SECONDS));
        return durationImpl;
    }

    public int signum() {
        return this.signum;
    }

    public Duration subtract(Duration duration) {
        return add(duration.negate());
    }

    public String toString() {
        StringBuffer stringBuffer;
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        if (this.signum < 0) {
            StringBuffer append = stringBuffer2.append('-');
        }
        StringBuffer append2 = stringBuffer2.append('P');
        if (this.years != null) {
            StringBuffer append3 = stringBuffer2.append(this.years).append('Y');
        }
        if (this.months != null) {
            StringBuffer append4 = stringBuffer2.append(this.months).append('M');
        }
        if (this.days != null) {
            StringBuffer append5 = stringBuffer2.append(this.days).append('D');
        }
        if (!(this.hours == null && this.minutes == null && this.seconds == null)) {
            StringBuffer append6 = stringBuffer2.append('T');
            if (this.hours != null) {
                StringBuffer append7 = stringBuffer2.append(this.hours).append('H');
            }
            if (this.minutes != null) {
                StringBuffer append8 = stringBuffer2.append(this.minutes).append('M');
            }
            if (this.seconds != null) {
                StringBuffer append9 = stringBuffer2.append(toString(this.seconds)).append('S');
            }
        }
        return stringBuffer2.toString();
    }
}
