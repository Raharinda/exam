package org.apache.xerces.jaxp.validation;

import java.io.IOException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Validator;
import org.apache.xerces.util.SAXMessageFormatter;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xs.AttributePSVI;
import org.apache.xerces.xs.ElementPSVI;
import org.apache.xerces.xs.PSVIProvider;
import org.w3c.dom.ls.LSResourceResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;

final class ValidatorImpl extends Validator implements PSVIProvider {
    private static final String CURRENT_ELEMENT_NODE = "http://apache.org/xml/properties/dom/current-element-node";
    private static final String JAXP_SOURCE_RESULT_FEATURE_PREFIX = "http://javax.xml.transform";
    private final XMLSchemaValidatorComponentManager fComponentManager;
    private boolean fConfigurationChanged = false;
    private DOMValidatorHelper fDOMValidatorHelper;
    private boolean fErrorHandlerChanged = false;
    private boolean fResourceResolverChanged = false;
    private ValidatorHandlerImpl fSAXValidatorHelper;
    private StAXValidatorHelper fStAXValidatorHelper;
    private StreamValidatorHelper fStreamValidatorHelper;

    public ValidatorImpl(XSGrammarPoolContainer xSGrammarPoolContainer) {
        XMLSchemaValidatorComponentManager xMLSchemaValidatorComponentManager;
        new XMLSchemaValidatorComponentManager(xSGrammarPoolContainer);
        this.fComponentManager = xMLSchemaValidatorComponentManager;
        setErrorHandler((ErrorHandler) null);
        setResourceResolver((LSResourceResolver) null);
    }

    public AttributePSVI getAttributePSVI(int i) {
        return this.fSAXValidatorHelper != null ? this.fSAXValidatorHelper.getAttributePSVI(i) : null;
    }

    public AttributePSVI getAttributePSVIByName(String str, String str2) {
        return this.fSAXValidatorHelper != null ? this.fSAXValidatorHelper.getAttributePSVIByName(str, str2) : null;
    }

    public ElementPSVI getElementPSVI() {
        return this.fSAXValidatorHelper != null ? this.fSAXValidatorHelper.getElementPSVI() : null;
    }

    public ErrorHandler getErrorHandler() {
        return this.fComponentManager.getErrorHandler();
    }

    public boolean getFeature(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        if (str2 == null) {
            Throwable th4 = th3;
            new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "FeatureNameNull", (Object[]) null));
            throw th4;
        } else if (str2.startsWith(JAXP_SOURCE_RESULT_FEATURE_PREFIX) && (str2.equals("http://javax.xml.transform.stream.StreamSource/feature") || str2.equals("http://javax.xml.transform.sax.SAXSource/feature") || str2.equals("http://javax.xml.transform.dom.DOMSource/feature") || str2.equals("http://javax.xml.transform.stax.StAXSource/feature") || str2.equals("http://javax.xml.transform.stream.StreamResult/feature") || str2.equals("http://javax.xml.transform.sax.SAXResult/feature") || str2.equals("http://javax.xml.transform.dom.DOMResult/feature") || str2.equals("http://javax.xml.transform.stax.StAXResult/feature"))) {
            return true;
        } else {
            try {
                return this.fComponentManager.getFeature(str2);
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
                String identifier = xMLConfigurationException.getIdentifier();
                if (xMLConfigurationException.getType() == 0) {
                    Throwable th5 = th2;
                    new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "feature-not-recognized", new Object[]{identifier}));
                    throw th5;
                }
                Throwable th6 = th;
                new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "feature-not-supported", new Object[]{identifier}));
                throw th6;
            }
        }
    }

    public Object getProperty(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        if (str2 == null) {
            Throwable th4 = th3;
            new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "ProperyNameNull", (Object[]) null));
            throw th4;
        } else if (CURRENT_ELEMENT_NODE.equals(str2)) {
            return this.fDOMValidatorHelper != null ? this.fDOMValidatorHelper.getCurrentElement() : null;
        } else {
            try {
                return this.fComponentManager.getProperty(str2);
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
                String identifier = xMLConfigurationException.getIdentifier();
                if (xMLConfigurationException.getType() == 0) {
                    Throwable th5 = th2;
                    new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "property-not-recognized", new Object[]{identifier}));
                    throw th5;
                }
                Throwable th6 = th;
                new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "property-not-supported", new Object[]{identifier}));
                throw th6;
            }
        }
    }

    public LSResourceResolver getResourceResolver() {
        return this.fComponentManager.getResourceResolver();
    }

    public void reset() {
        if (this.fConfigurationChanged) {
            this.fComponentManager.restoreInitialState();
            setErrorHandler((ErrorHandler) null);
            setResourceResolver((LSResourceResolver) null);
            this.fConfigurationChanged = false;
            this.fErrorHandlerChanged = false;
            this.fResourceResolverChanged = false;
            return;
        }
        if (this.fErrorHandlerChanged) {
            setErrorHandler((ErrorHandler) null);
            this.fErrorHandlerChanged = false;
        }
        if (this.fResourceResolverChanged) {
            setResourceResolver((LSResourceResolver) null);
            this.fResourceResolverChanged = false;
        }
    }

    public void setErrorHandler(ErrorHandler errorHandler) {
        ErrorHandler errorHandler2 = errorHandler;
        this.fErrorHandlerChanged = errorHandler2 != null;
        this.fComponentManager.setErrorHandler(errorHandler2);
    }

    public void setFeature(String str, boolean z) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        String str2 = str;
        boolean z2 = z;
        if (str2 == null) {
            Throwable th5 = th4;
            new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "FeatureNameNull", (Object[]) null));
            throw th5;
        } else if (!str2.startsWith(JAXP_SOURCE_RESULT_FEATURE_PREFIX) || (!str2.equals("http://javax.xml.transform.stream.StreamSource/feature") && !str2.equals("http://javax.xml.transform.sax.SAXSource/feature") && !str2.equals("http://javax.xml.transform.dom.DOMSource/feature") && !str2.equals("http://javax.xml.transform.stax.StAXSource/feature") && !str2.equals("http://javax.xml.transform.stream.StreamResult/feature") && !str2.equals("http://javax.xml.transform.sax.SAXResult/feature") && !str2.equals("http://javax.xml.transform.dom.DOMResult/feature") && !str2.equals("http://javax.xml.transform.stax.StAXResult/feature"))) {
            try {
                this.fComponentManager.setFeature(str2, z2);
                this.fConfigurationChanged = true;
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
                String identifier = xMLConfigurationException.getIdentifier();
                if (xMLConfigurationException.getType() == 0) {
                    Throwable th6 = th2;
                    new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "feature-not-recognized", new Object[]{identifier}));
                    throw th6;
                }
                Throwable th7 = th;
                new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "feature-not-supported", new Object[]{identifier}));
                throw th7;
            }
        } else {
            Throwable th8 = th3;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "feature-read-only", new Object[]{str2}));
            throw th8;
        }
    }

    public void setProperty(String str, Object obj) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        String str2 = str;
        Object obj2 = obj;
        if (str2 == null) {
            Throwable th5 = th4;
            new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "ProperyNameNull", (Object[]) null));
            throw th5;
        } else if (CURRENT_ELEMENT_NODE.equals(str2)) {
            Throwable th6 = th3;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "property-read-only", new Object[]{str2}));
            throw th6;
        } else {
            try {
                this.fComponentManager.setProperty(str2, obj2);
                this.fConfigurationChanged = true;
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
                String identifier = xMLConfigurationException.getIdentifier();
                if (xMLConfigurationException.getType() == 0) {
                    Throwable th7 = th2;
                    new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "property-not-recognized", new Object[]{identifier}));
                    throw th7;
                }
                Throwable th8 = th;
                new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "property-not-supported", new Object[]{identifier}));
                throw th8;
            }
        }
    }

    public void setResourceResolver(LSResourceResolver lSResourceResolver) {
        LSResourceResolver lSResourceResolver2 = lSResourceResolver;
        this.fResourceResolverChanged = lSResourceResolver2 != null;
        this.fComponentManager.setResourceResolver(lSResourceResolver2);
    }

    public void validate(Source source, Result result) throws SAXException, IOException {
        Throwable th;
        Throwable th2;
        StreamValidatorHelper streamValidatorHelper;
        StAXValidatorHelper stAXValidatorHelper;
        DOMValidatorHelper dOMValidatorHelper;
        ValidatorHandlerImpl validatorHandlerImpl;
        Source source2 = source;
        Result result2 = result;
        if (source2 instanceof SAXSource) {
            if (this.fSAXValidatorHelper == null) {
                new ValidatorHandlerImpl(this.fComponentManager);
                this.fSAXValidatorHelper = validatorHandlerImpl;
            }
            this.fSAXValidatorHelper.validate(source2, result2);
        } else if (source2 instanceof DOMSource) {
            if (this.fDOMValidatorHelper == null) {
                new DOMValidatorHelper(this.fComponentManager);
                this.fDOMValidatorHelper = dOMValidatorHelper;
            }
            this.fDOMValidatorHelper.validate(source2, result2);
        } else if (source2 instanceof StAXSource) {
            if (this.fStAXValidatorHelper == null) {
                new StAXValidatorHelper(this.fComponentManager);
                this.fStAXValidatorHelper = stAXValidatorHelper;
            }
            this.fStAXValidatorHelper.validate(source2, result2);
        } else if (source2 instanceof StreamSource) {
            if (this.fStreamValidatorHelper == null) {
                new StreamValidatorHelper(this.fComponentManager);
                this.fStreamValidatorHelper = streamValidatorHelper;
            }
            this.fStreamValidatorHelper.validate(source2, result2);
        } else if (source2 == null) {
            Throwable th3 = th2;
            new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "SourceParameterNull", (Object[]) null));
            throw th3;
        } else {
            Throwable th4 = th;
            new IllegalArgumentException(JAXPValidationMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "SourceNotAccepted", new Object[]{source2.getClass().getName()}));
            throw th4;
        }
    }
}
