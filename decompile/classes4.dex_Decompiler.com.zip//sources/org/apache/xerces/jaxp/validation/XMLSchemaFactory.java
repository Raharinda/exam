package org.apache.xerces.jaxp.validation;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import javax.xml.stream.XMLEventReader;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.apache.xerces.impl.Constants;
import org.apache.xerces.impl.xs.XMLSchemaLoader;
import org.apache.xerces.util.DOMEntityResolverWrapper;
import org.apache.xerces.util.DOMInputSource;
import org.apache.xerces.util.ErrorHandlerWrapper;
import org.apache.xerces.util.SAXInputSource;
import org.apache.xerces.util.SAXMessageFormatter;
import org.apache.xerces.util.SecurityManager;
import org.apache.xerces.util.StAXInputSource;
import org.apache.xerces.util.XMLGrammarPoolImpl;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.Grammar;
import org.apache.xerces.xni.grammars.XMLGrammarDescription;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.w3c.dom.ls.LSResourceResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.SAXParseException;

public final class XMLSchemaFactory extends SchemaFactory {
    private static final String JAXP_SOURCE_FEATURE_PREFIX = "http://javax.xml.transform";
    private static final String SCHEMA_FULL_CHECKING = "http://apache.org/xml/features/validation/schema-full-checking";
    private static final String SECURITY_MANAGER = "http://apache.org/xml/properties/security-manager";
    private static final String USE_GRAMMAR_POOL_ONLY = "http://apache.org/xml/features/internal/validation/schema/use-grammar-pool-only";
    private static final String XMLGRAMMAR_POOL = "http://apache.org/xml/properties/internal/grammar-pool";
    private final DOMEntityResolverWrapper fDOMEntityResolverWrapper;
    private ErrorHandler fErrorHandler;
    private final ErrorHandlerWrapper fErrorHandlerWrapper;
    private LSResourceResolver fLSResourceResolver;
    private SecurityManager fSecurityManager;
    private boolean fUseGrammarPoolOnly = true;
    private final XMLGrammarPoolWrapper fXMLGrammarPoolWrapper;
    private final XMLSchemaLoader fXMLSchemaLoader;

    static class XMLGrammarPoolImplExtension extends XMLGrammarPoolImpl {
        public XMLGrammarPoolImplExtension() {
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public XMLGrammarPoolImplExtension(int i) {
            super(i);
        }

        /* access modifiers changed from: package-private */
        public int getGrammarCount() {
            return this.fGrammarCount;
        }
    }

    static class XMLGrammarPoolWrapper implements XMLGrammarPool {
        private XMLGrammarPool fGrammarPool;

        XMLGrammarPoolWrapper() {
        }

        public void cacheGrammars(String str, Grammar[] grammarArr) {
            this.fGrammarPool.cacheGrammars(str, grammarArr);
        }

        public void clear() {
            this.fGrammarPool.clear();
        }

        /* access modifiers changed from: package-private */
        public XMLGrammarPool getGrammarPool() {
            return this.fGrammarPool;
        }

        public void lockPool() {
            this.fGrammarPool.lockPool();
        }

        public Grammar retrieveGrammar(XMLGrammarDescription xMLGrammarDescription) {
            return this.fGrammarPool.retrieveGrammar(xMLGrammarDescription);
        }

        public Grammar[] retrieveInitialGrammarSet(String str) {
            return this.fGrammarPool.retrieveInitialGrammarSet(str);
        }

        /* access modifiers changed from: package-private */
        public void setGrammarPool(XMLGrammarPool xMLGrammarPool) {
            XMLGrammarPool xMLGrammarPool2 = xMLGrammarPool;
            this.fGrammarPool = xMLGrammarPool2;
        }

        public void unlockPool() {
            this.fGrammarPool.unlockPool();
        }
    }

    public XMLSchemaFactory() {
        XMLSchemaLoader xMLSchemaLoader;
        ErrorHandlerWrapper errorHandlerWrapper;
        DOMEntityResolverWrapper dOMEntityResolverWrapper;
        XMLGrammarPoolWrapper xMLGrammarPoolWrapper;
        new XMLSchemaLoader();
        this.fXMLSchemaLoader = xMLSchemaLoader;
        new ErrorHandlerWrapper(DraconianErrorHandler.getInstance());
        this.fErrorHandlerWrapper = errorHandlerWrapper;
        new DOMEntityResolverWrapper();
        this.fDOMEntityResolverWrapper = dOMEntityResolverWrapper;
        new XMLGrammarPoolWrapper();
        this.fXMLGrammarPoolWrapper = xMLGrammarPoolWrapper;
        this.fXMLSchemaLoader.setFeature(SCHEMA_FULL_CHECKING, true);
        this.fXMLSchemaLoader.setProperty(XMLGRAMMAR_POOL, this.fXMLGrammarPoolWrapper);
        this.fXMLSchemaLoader.setEntityResolver(this.fDOMEntityResolverWrapper);
        this.fXMLSchemaLoader.setErrorHandler(this.fErrorHandlerWrapper);
    }

    private void propagateFeatures(AbstractXMLSchema abstractXMLSchema) {
        AbstractXMLSchema abstractXMLSchema2 = abstractXMLSchema;
        abstractXMLSchema2.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", this.fSecurityManager != null);
        String[] recognizedFeatures = this.fXMLSchemaLoader.getRecognizedFeatures();
        for (int i = 0; i < recognizedFeatures.length; i++) {
            abstractXMLSchema2.setFeature(recognizedFeatures[i], this.fXMLSchemaLoader.getFeature(recognizedFeatures[i]));
        }
    }

    public ErrorHandler getErrorHandler() {
        return this.fErrorHandler;
    }

    public boolean getFeature(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        if (str2 == null) {
            Throwable th4 = th3;
            new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "FeatureNameNull", (Object[]) null));
            throw th4;
        } else if (str2.startsWith(JAXP_SOURCE_FEATURE_PREFIX) && (str2.equals("http://javax.xml.transform.stream.StreamSource/feature") || str2.equals("http://javax.xml.transform.sax.SAXSource/feature") || str2.equals("http://javax.xml.transform.dom.DOMSource/feature") || str2.equals("http://javax.xml.transform.stax.StAXSource/feature"))) {
            return true;
        } else {
            if (str2.equals("http://javax.xml.XMLConstants/feature/secure-processing")) {
                return this.fSecurityManager != null;
            } else if (str2.equals(USE_GRAMMAR_POOL_ONLY)) {
                return this.fUseGrammarPoolOnly;
            } else {
                try {
                    return this.fXMLSchemaLoader.getFeature(str2);
                } catch (XMLConfigurationException e) {
                    XMLConfigurationException xMLConfigurationException = e;
                    String identifier = xMLConfigurationException.getIdentifier();
                    if (xMLConfigurationException.getType() == 0) {
                        Throwable th5 = th2;
                        new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "feature-not-recognized", new Object[]{identifier}));
                        throw th5;
                    }
                    Throwable th6 = th;
                    new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "feature-not-supported", new Object[]{identifier}));
                    throw th6;
                }
            }
        }
    }

    public Object getProperty(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        String str2 = str;
        if (str2 == null) {
            Throwable th5 = th4;
            new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "ProperyNameNull", (Object[]) null));
            throw th5;
        } else if (str2.equals(SECURITY_MANAGER)) {
            return this.fSecurityManager;
        } else {
            if (str2.equals(XMLGRAMMAR_POOL)) {
                Throwable th6 = th3;
                new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "property-not-supported", new Object[]{str2}));
                throw th6;
            }
            try {
                return this.fXMLSchemaLoader.getProperty(str2);
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
                String identifier = xMLConfigurationException.getIdentifier();
                if (xMLConfigurationException.getType() == 0) {
                    Throwable th7 = th2;
                    new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "property-not-recognized", new Object[]{identifier}));
                    throw th7;
                }
                Throwable th8 = th;
                new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "property-not-supported", new Object[]{identifier}));
                throw th8;
            }
        }
    }

    public LSResourceResolver getResourceResolver() {
        return this.fLSResourceResolver;
    }

    public boolean isSchemaLanguageSupported(String str) {
        Throwable th;
        Throwable th2;
        String str2 = str;
        if (str2 == null) {
            Throwable th3 = th2;
            new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "SchemaLanguageNull", (Object[]) null));
            throw th3;
        } else if (str2.length() == 0) {
            Throwable th4 = th;
            new IllegalArgumentException(JAXPValidationMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "SchemaLanguageLengthZero", (Object[]) null));
            throw th4;
        } else {
            return str2.equals("http://www.w3.org/2001/XMLSchema") || str2.equals(Constants.W3C_XML_SCHEMA10_NS_URI);
        }
    }

    public Schema newSchema() throws SAXException {
        AbstractXMLSchema abstractXMLSchema;
        new WeakReferenceXMLSchema();
        AbstractXMLSchema abstractXMLSchema2 = abstractXMLSchema;
        propagateFeatures(abstractXMLSchema2);
        return abstractXMLSchema2;
    }

    public Schema newSchema(XMLGrammarPool xMLGrammarPool) throws SAXException {
        AbstractXMLSchema abstractXMLSchema;
        AbstractXMLSchema abstractXMLSchema2;
        AbstractXMLSchema abstractXMLSchema3;
        XMLGrammarPool xMLGrammarPool2;
        XMLGrammarPool xMLGrammarPool3 = xMLGrammarPool;
        if (this.fUseGrammarPoolOnly) {
            abstractXMLSchema2 = abstractXMLSchema3;
            new ReadOnlyGrammarPool(xMLGrammarPool3);
            new XMLSchema(xMLGrammarPool2);
        } else {
            abstractXMLSchema2 = abstractXMLSchema;
            new XMLSchema(xMLGrammarPool3, false);
        }
        AbstractXMLSchema abstractXMLSchema4 = abstractXMLSchema2;
        propagateFeatures(abstractXMLSchema4);
        return abstractXMLSchema4;
    }

    public Schema newSchema(Source[] sourceArr) throws SAXException {
        XMLGrammarPoolImplExtension xMLGrammarPoolImplExtension;
        SAXParseException sAXParseException;
        AbstractXMLSchema abstractXMLSchema;
        XMLGrammarPool xMLGrammarPool;
        AbstractXMLSchema abstractXMLSchema2;
        AbstractXMLSchema abstractXMLSchema3;
        AbstractXMLSchema abstractXMLSchema4;
        AbstractXMLSchema abstractXMLSchema5;
        XMLGrammarPool xMLGrammarPool2;
        Throwable th;
        Throwable th2;
        XMLInputSource xMLInputSource;
        XMLInputSource xMLInputSource2;
        XMLInputSource xMLInputSource3;
        Throwable th3;
        XMLInputSource xMLInputSource4;
        XMLInputSource xMLInputSource5;
        Source[] sourceArr2 = sourceArr;
        new XMLGrammarPoolImplExtension();
        XMLGrammarPoolImplExtension xMLGrammarPoolImplExtension2 = xMLGrammarPoolImplExtension;
        this.fXMLGrammarPoolWrapper.setGrammarPool(xMLGrammarPoolImplExtension2);
        XMLInputSource[] xMLInputSourceArr = new XMLInputSource[sourceArr2.length];
        for (int i = 0; i < sourceArr2.length; i++) {
            Source source = sourceArr2[i];
            if (source instanceof StreamSource) {
                StreamSource streamSource = (StreamSource) source;
                String publicId = streamSource.getPublicId();
                String systemId = streamSource.getSystemId();
                InputStream inputStream = streamSource.getInputStream();
                Reader reader = streamSource.getReader();
                new XMLInputSource(publicId, systemId, (String) null);
                XMLInputSource xMLInputSource6 = xMLInputSource5;
                xMLInputSource6.setByteStream(inputStream);
                xMLInputSource6.setCharacterStream(reader);
                xMLInputSourceArr[i] = xMLInputSource6;
            } else if (source instanceof SAXSource) {
                SAXSource sAXSource = (SAXSource) source;
                InputSource inputSource = sAXSource.getInputSource();
                if (inputSource == null) {
                    Throwable th4 = th3;
                    new SAXException(JAXPValidationMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "SAXSourceNullInputSource", (Object[]) null));
                    throw th4;
                }
                new SAXInputSource(sAXSource.getXMLReader(), inputSource);
                xMLInputSourceArr[i] = xMLInputSource4;
            } else if (source instanceof DOMSource) {
                DOMSource dOMSource = (DOMSource) source;
                new DOMInputSource(dOMSource.getNode(), dOMSource.getSystemId());
                xMLInputSourceArr[i] = xMLInputSource3;
            } else if (source instanceof StAXSource) {
                StAXSource stAXSource = (StAXSource) source;
                XMLEventReader xMLEventReader = stAXSource.getXMLEventReader();
                if (xMLEventReader != null) {
                    new StAXInputSource(xMLEventReader);
                    xMLInputSourceArr[i] = xMLInputSource2;
                } else {
                    new StAXInputSource(stAXSource.getXMLStreamReader());
                    xMLInputSourceArr[i] = xMLInputSource;
                }
            } else if (source == null) {
                Throwable th5 = th2;
                new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "SchemaSourceArrayMemberNull", (Object[]) null));
                throw th5;
            } else {
                Throwable th6 = th;
                new IllegalArgumentException(JAXPValidationMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "SchemaFactorySourceUnrecognized", new Object[]{source.getClass().getName()}));
                throw th6;
            }
        }
        try {
            this.fXMLSchemaLoader.loadGrammar(xMLInputSourceArr);
            this.fXMLGrammarPoolWrapper.setGrammarPool((XMLGrammarPool) null);
            int grammarCount = xMLGrammarPoolImplExtension2.getGrammarCount();
            if (!this.fUseGrammarPoolOnly) {
                new ReadOnlyGrammarPool(xMLGrammarPoolImplExtension2);
                new XMLSchema(xMLGrammarPool, false);
                abstractXMLSchema2 = abstractXMLSchema;
            } else if (grammarCount > 1) {
                new ReadOnlyGrammarPool(xMLGrammarPoolImplExtension2);
                new XMLSchema(xMLGrammarPool2);
                abstractXMLSchema2 = abstractXMLSchema5;
            } else if (grammarCount == 1) {
                new SimpleXMLSchema(xMLGrammarPoolImplExtension2.retrieveInitialGrammarSet("http://www.w3.org/2001/XMLSchema")[0]);
                abstractXMLSchema2 = abstractXMLSchema4;
            } else {
                new EmptyXMLSchema();
                abstractXMLSchema2 = abstractXMLSchema3;
            }
            propagateFeatures(abstractXMLSchema2);
            return abstractXMLSchema2;
        } catch (XNIException e) {
            throw Util.toSAXException(e);
        } catch (IOException e2) {
            IOException iOException = e2;
            new SAXParseException(iOException.getMessage(), (Locator) null, iOException);
            SAXParseException sAXParseException2 = sAXParseException;
            if (this.fErrorHandler != null) {
                this.fErrorHandler.error(sAXParseException2);
            }
            throw sAXParseException2;
        }
    }

    public void setErrorHandler(ErrorHandler errorHandler) {
        ErrorHandler errorHandler2 = errorHandler;
        this.fErrorHandler = errorHandler2;
        this.fErrorHandlerWrapper.setErrorHandler(errorHandler2 != null ? errorHandler2 : DraconianErrorHandler.getInstance());
        this.fXMLSchemaLoader.setErrorHandler(this.fErrorHandlerWrapper);
    }

    public void setFeature(String str, boolean z) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        SecurityManager securityManager;
        SecurityManager securityManager2;
        Throwable th3;
        Throwable th4;
        String str2 = str;
        boolean z2 = z;
        if (str2 == null) {
            Throwable th5 = th4;
            new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "FeatureNameNull", (Object[]) null));
            throw th5;
        } else if (str2.startsWith(JAXP_SOURCE_FEATURE_PREFIX) && (str2.equals("http://javax.xml.transform.stream.StreamSource/feature") || str2.equals("http://javax.xml.transform.sax.SAXSource/feature") || str2.equals("http://javax.xml.transform.dom.DOMSource/feature") || str2.equals("http://javax.xml.transform.stax.StAXSource/feature"))) {
            Throwable th6 = th3;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "feature-read-only", new Object[]{str2}));
            throw th6;
        } else if (str2.equals("http://javax.xml.XMLConstants/feature/secure-processing")) {
            if (z2) {
                securityManager = securityManager2;
                new SecurityManager();
            } else {
                securityManager = null;
            }
            this.fSecurityManager = securityManager;
            this.fXMLSchemaLoader.setProperty(SECURITY_MANAGER, this.fSecurityManager);
        } else if (str2.equals(USE_GRAMMAR_POOL_ONLY)) {
            this.fUseGrammarPoolOnly = z2;
        } else {
            try {
                this.fXMLSchemaLoader.setFeature(str2, z2);
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
                String identifier = xMLConfigurationException.getIdentifier();
                if (xMLConfigurationException.getType() == 0) {
                    Throwable th7 = th2;
                    new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "feature-not-recognized", new Object[]{identifier}));
                    throw th7;
                }
                Throwable th8 = th;
                new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "feature-not-supported", new Object[]{identifier}));
                throw th8;
            }
        }
    }

    public void setProperty(String str, Object obj) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        String str2 = str;
        Object obj2 = obj;
        if (str2 == null) {
            Throwable th5 = th4;
            new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "ProperyNameNull", (Object[]) null));
            throw th5;
        } else if (str2.equals(SECURITY_MANAGER)) {
            this.fSecurityManager = (SecurityManager) obj2;
            this.fXMLSchemaLoader.setProperty(SECURITY_MANAGER, this.fSecurityManager);
        } else if (str2.equals(XMLGRAMMAR_POOL)) {
            Throwable th6 = th3;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "property-not-supported", new Object[]{str2}));
            throw th6;
        } else {
            try {
                this.fXMLSchemaLoader.setProperty(str2, obj2);
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
                String identifier = xMLConfigurationException.getIdentifier();
                if (xMLConfigurationException.getType() == 0) {
                    Throwable th7 = th2;
                    new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "property-not-recognized", new Object[]{identifier}));
                    throw th7;
                }
                Throwable th8 = th;
                new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fXMLSchemaLoader.getLocale(), "property-not-supported", new Object[]{identifier}));
                throw th8;
            }
        }
    }

    public void setResourceResolver(LSResourceResolver lSResourceResolver) {
        LSResourceResolver lSResourceResolver2 = lSResourceResolver;
        this.fLSResourceResolver = lSResourceResolver2;
        this.fDOMEntityResolverWrapper.setEntityResolver(lSResourceResolver2);
        this.fXMLSchemaLoader.setEntityResolver(this.fDOMEntityResolverWrapper);
    }
}
