package org.apache.xerces.jaxp;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.validation.Schema;
import org.apache.xerces.dom.DOMImplementationImpl;
import org.apache.xerces.dom.DOMMessageFormatter;
import org.apache.xerces.dom.DocumentImpl;
import org.apache.xerces.impl.validation.ValidationManager;
import org.apache.xerces.impl.xs.XMLSchemaValidator;
import org.apache.xerces.jaxp.validation.XSGrammarPoolContainer;
import org.apache.xerces.parsers.DOMParser;
import org.apache.xerces.util.SecurityManager;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.parser.XMLComponent;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLDocumentSource;
import org.apache.xerces.xni.parser.XMLParserConfiguration;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;

public class DocumentBuilderImpl extends DocumentBuilder implements JAXPConstants {
    private static final String CREATE_CDATA_NODES_FEATURE = "http://apache.org/xml/features/create-cdata-nodes";
    private static final String CREATE_ENTITY_REF_NODES_FEATURE = "http://apache.org/xml/features/dom/create-entity-ref-nodes";
    private static final String INCLUDE_COMMENTS_FEATURE = "http://apache.org/xml/features/include-comments";
    private static final String INCLUDE_IGNORABLE_WHITESPACE = "http://apache.org/xml/features/dom/include-ignorable-whitespace";
    private static final String NAMESPACES_FEATURE = "http://xml.org/sax/features/namespaces";
    private static final String SECURITY_MANAGER = "http://apache.org/xml/properties/security-manager";
    private static final String VALIDATION_FEATURE = "http://xml.org/sax/features/validation";
    private static final String XINCLUDE_FEATURE = "http://apache.org/xml/features/xinclude";
    private static final String XMLSCHEMA_VALIDATION_FEATURE = "http://apache.org/xml/features/validation/schema";
    private final DOMParser domParser;
    private final EntityResolver fInitEntityResolver;
    private final ErrorHandler fInitErrorHandler;
    private final ValidationManager fSchemaValidationManager;
    private final XMLComponent fSchemaValidator;
    private final XMLComponentManager fSchemaValidatorComponentManager;
    private final UnparsedEntityHandler fUnparsedEntityHandler;
    private final Schema grammar;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    DocumentBuilderImpl(DocumentBuilderFactoryImpl documentBuilderFactoryImpl, Hashtable hashtable, Hashtable hashtable2) throws SAXNotRecognizedException, SAXNotSupportedException {
        this(documentBuilderFactoryImpl, hashtable, hashtable2, false);
    }

    DocumentBuilderImpl(DocumentBuilderFactoryImpl documentBuilderFactoryImpl, Hashtable hashtable, Hashtable hashtable2, boolean z) throws SAXNotRecognizedException, SAXNotSupportedException {
        DOMParser dOMParser;
        XMLDocumentSource xMLDocumentSource;
        XMLComponent xMLComponent;
        XMLComponent xMLComponent2;
        ValidationManager validationManager;
        UnparsedEntityHandler unparsedEntityHandler;
        XMLComponentManager xMLComponentManager;
        Object obj;
        ErrorHandler errorHandler;
        DocumentBuilderFactoryImpl documentBuilderFactoryImpl2 = documentBuilderFactoryImpl;
        Hashtable hashtable3 = hashtable;
        Hashtable hashtable4 = hashtable2;
        boolean z2 = z;
        new DOMParser();
        this.domParser = dOMParser;
        if (documentBuilderFactoryImpl2.isValidating()) {
            new DefaultValidationErrorHandler();
            this.fInitErrorHandler = errorHandler;
            setErrorHandler(this.fInitErrorHandler);
        } else {
            this.fInitErrorHandler = this.domParser.getErrorHandler();
        }
        this.domParser.setFeature(VALIDATION_FEATURE, documentBuilderFactoryImpl2.isValidating());
        this.domParser.setFeature(NAMESPACES_FEATURE, documentBuilderFactoryImpl2.isNamespaceAware());
        this.domParser.setFeature(INCLUDE_IGNORABLE_WHITESPACE, !documentBuilderFactoryImpl2.isIgnoringElementContentWhitespace());
        this.domParser.setFeature(CREATE_ENTITY_REF_NODES_FEATURE, !documentBuilderFactoryImpl2.isExpandEntityReferences());
        this.domParser.setFeature(INCLUDE_COMMENTS_FEATURE, !documentBuilderFactoryImpl2.isIgnoringComments());
        this.domParser.setFeature(CREATE_CDATA_NODES_FEATURE, !documentBuilderFactoryImpl2.isCoalescing());
        if (documentBuilderFactoryImpl2.isXIncludeAware()) {
            this.domParser.setFeature(XINCLUDE_FEATURE, true);
        }
        if (z2) {
            new SecurityManager();
            this.domParser.setProperty(SECURITY_MANAGER, obj);
        }
        this.grammar = documentBuilderFactoryImpl2.getSchema();
        if (this.grammar != null) {
            XMLParserConfiguration xMLParserConfiguration = this.domParser.getXMLParserConfiguration();
            if (this.grammar instanceof XSGrammarPoolContainer) {
                new XMLSchemaValidator();
                xMLComponent = xMLComponent2;
                new ValidationManager();
                this.fSchemaValidationManager = validationManager;
                new UnparsedEntityHandler(this.fSchemaValidationManager);
                this.fUnparsedEntityHandler = unparsedEntityHandler;
                xMLParserConfiguration.setDTDHandler(this.fUnparsedEntityHandler);
                this.fUnparsedEntityHandler.setDTDHandler(this.domParser);
                this.domParser.setDTDSource(this.fUnparsedEntityHandler);
                new SchemaValidatorConfiguration(xMLParserConfiguration, (XSGrammarPoolContainer) this.grammar, this.fSchemaValidationManager);
                this.fSchemaValidatorComponentManager = xMLComponentManager;
            } else {
                new JAXPValidatorComponent(this.grammar.newValidatorHandler());
                xMLComponent = xMLDocumentSource;
                this.fSchemaValidationManager = null;
                this.fUnparsedEntityHandler = null;
                this.fSchemaValidatorComponentManager = xMLParserConfiguration;
            }
            xMLParserConfiguration.addRecognizedFeatures(xMLComponent.getRecognizedFeatures());
            xMLParserConfiguration.addRecognizedProperties(xMLComponent.getRecognizedProperties());
            xMLParserConfiguration.setDocumentHandler((XMLDocumentHandler) xMLComponent);
            ((XMLDocumentSource) xMLComponent).setDocumentHandler(this.domParser);
            this.domParser.setDocumentSource((XMLDocumentSource) xMLComponent);
            this.fSchemaValidator = xMLComponent;
        } else {
            this.fSchemaValidationManager = null;
            this.fUnparsedEntityHandler = null;
            this.fSchemaValidatorComponentManager = null;
            this.fSchemaValidator = null;
        }
        setFeatures(hashtable4);
        setDocumentBuilderFactoryAttributes(hashtable3);
        this.fInitEntityResolver = this.domParser.getEntityResolver();
    }

    private void resetSchemaValidator() throws SAXException {
        Throwable th;
        try {
            this.fSchemaValidator.reset(this.fSchemaValidatorComponentManager);
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
            Throwable th2 = th;
            new SAXException(xMLConfigurationException);
            throw th2;
        }
    }

    private void setDocumentBuilderFactoryAttributes(Hashtable hashtable) throws SAXNotSupportedException, SAXNotRecognizedException {
        Throwable th;
        Hashtable hashtable2 = hashtable;
        if (hashtable2 != null) {
            for (Map.Entry entry : hashtable2.entrySet()) {
                String str = (String) entry.getKey();
                Object value = entry.getValue();
                if (value instanceof Boolean) {
                    this.domParser.setFeature(str, ((Boolean) value).booleanValue());
                } else if (JAXPConstants.JAXP_SCHEMA_LANGUAGE.equals(str)) {
                    if ("http://www.w3.org/2001/XMLSchema".equals(value) && isValidating()) {
                        this.domParser.setFeature(XMLSCHEMA_VALIDATION_FEATURE, true);
                        this.domParser.setProperty(JAXPConstants.JAXP_SCHEMA_LANGUAGE, "http://www.w3.org/2001/XMLSchema");
                    }
                } else if (!JAXPConstants.JAXP_SCHEMA_SOURCE.equals(str)) {
                    this.domParser.setProperty(str, value);
                } else if (!isValidating()) {
                    continue;
                } else {
                    String str2 = (String) hashtable2.get(JAXPConstants.JAXP_SCHEMA_LANGUAGE);
                    if (str2 == null || !"http://www.w3.org/2001/XMLSchema".equals(str2)) {
                        Throwable th2 = th;
                        Object[] objArr = new Object[2];
                        objArr[0] = JAXPConstants.JAXP_SCHEMA_LANGUAGE;
                        Object[] objArr2 = objArr;
                        objArr2[1] = JAXPConstants.JAXP_SCHEMA_SOURCE;
                        new IllegalArgumentException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "jaxp-order-not-supported", objArr2));
                        throw th2;
                    }
                    this.domParser.setProperty(str, value);
                }
            }
        }
    }

    private void setFeatures(Hashtable hashtable) throws SAXNotSupportedException, SAXNotRecognizedException {
        Hashtable hashtable2 = hashtable;
        if (hashtable2 != null) {
            for (Map.Entry entry : hashtable2.entrySet()) {
                this.domParser.setFeature((String) entry.getKey(), ((Boolean) entry.getValue()).booleanValue());
            }
        }
    }

    public DOMImplementation getDOMImplementation() {
        return DOMImplementationImpl.getDOMImplementation();
    }

    /* access modifiers changed from: package-private */
    public DOMParser getDOMParser() {
        return this.domParser;
    }

    public Schema getSchema() {
        return this.grammar;
    }

    public boolean isNamespaceAware() {
        Throwable th;
        try {
            return this.domParser.getFeature(NAMESPACES_FEATURE);
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new IllegalStateException(sAXException.getMessage());
            throw th2;
        }
    }

    public boolean isValidating() {
        Throwable th;
        try {
            return this.domParser.getFeature(VALIDATION_FEATURE);
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new IllegalStateException(sAXException.getMessage());
            throw th2;
        }
    }

    public boolean isXIncludeAware() {
        try {
            return this.domParser.getFeature(XINCLUDE_FEATURE);
        } catch (SAXException e) {
            SAXException sAXException = e;
            return false;
        }
    }

    public Document newDocument() {
        Document document;
        new DocumentImpl();
        return document;
    }

    public Document parse(InputSource inputSource) throws SAXException, IOException {
        Throwable th;
        InputSource inputSource2 = inputSource;
        if (inputSource2 == null) {
            Throwable th2 = th;
            new IllegalArgumentException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "jaxp-null-input-source", (Object[]) null));
            throw th2;
        }
        if (this.fSchemaValidator != null) {
            if (this.fSchemaValidationManager != null) {
                this.fSchemaValidationManager.reset();
                this.fUnparsedEntityHandler.reset();
            }
            resetSchemaValidator();
        }
        this.domParser.parse(inputSource2);
        Document document = this.domParser.getDocument();
        this.domParser.dropDocumentReferences();
        return document;
    }

    public void reset() {
        if (this.domParser.getErrorHandler() != this.fInitErrorHandler) {
            this.domParser.setErrorHandler(this.fInitErrorHandler);
        }
        if (this.domParser.getEntityResolver() != this.fInitEntityResolver) {
            this.domParser.setEntityResolver(this.fInitEntityResolver);
        }
    }

    public void setEntityResolver(EntityResolver entityResolver) {
        this.domParser.setEntityResolver(entityResolver);
    }

    public void setErrorHandler(ErrorHandler errorHandler) {
        this.domParser.setErrorHandler(errorHandler);
    }
}
