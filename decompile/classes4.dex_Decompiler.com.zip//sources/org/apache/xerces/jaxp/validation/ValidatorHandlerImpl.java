package org.apache.xerces.jaxp.validation;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Locale;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.validation.TypeInfoProvider;
import javax.xml.validation.ValidatorHandler;
import org.apache.xerces.impl.XMLEntityManager;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.impl.dv.XSSimpleType;
import org.apache.xerces.impl.validation.EntityState;
import org.apache.xerces.impl.validation.ValidationManager;
import org.apache.xerces.impl.xs.XMLSchemaValidator;
import org.apache.xerces.parsers.SAXParser;
import org.apache.xerces.util.AttributesProxy;
import org.apache.xerces.util.SAXLocatorWrapper;
import org.apache.xerces.util.SAXMessageFormatter;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.util.URI;
import org.apache.xerces.util.XMLAttributesImpl;
import org.apache.xerces.util.XMLSymbols;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLDocumentSource;
import org.apache.xerces.xni.parser.XMLParseException;
import org.apache.xerces.xs.AttributePSVI;
import org.apache.xerces.xs.ElementPSVI;
import org.apache.xerces.xs.ItemPSVI;
import org.apache.xerces.xs.PSVIProvider;
import org.apache.xerces.xs.XSSimpleTypeDefinition;
import org.apache.xerces.xs.XSTypeDefinition;
import org.w3c.dom.TypeInfo;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSResourceResolver;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;
import org.xml.sax.ext.Attributes2;
import org.xml.sax.ext.EntityResolver2;
import org.xml.sax.ext.LexicalHandler;

final class ValidatorHandlerImpl extends ValidatorHandler implements DTDHandler, EntityState, PSVIProvider, ValidatorHelper, XMLDocumentHandler {
    private static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
    private static final String LEXICAL_HANDLER = "http://xml.org/sax/properties/lexical-handler";
    private static final String NAMESPACE_CONTEXT = "http://apache.org/xml/properties/internal/namespace-context";
    private static final String NAMESPACE_PREFIXES = "http://xml.org/sax/features/namespace-prefixes";
    private static final String SCHEMA_VALIDATOR = "http://apache.org/xml/properties/internal/validator/schema";
    private static final String SECURITY_MANAGER = "http://apache.org/xml/properties/security-manager";
    private static final String STRINGS_INTERNED = "http://apache.org/xml/features/internal/strings-interned";
    private static final String STRING_INTERNING = "http://xml.org/sax/features/string-interning";
    private static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    private static final String VALIDATION_MANAGER = "http://apache.org/xml/properties/internal/validation-manager";
    private final AttributesProxy fAttrAdapter;
    private final QName fAttributeQName;
    private final XMLAttributesImpl fAttributes;
    private final XMLSchemaValidatorComponentManager fComponentManager;
    private ContentHandler fContentHandler;
    private final QName fElementQName;
    private final XMLErrorReporter fErrorReporter;
    private final NamespaceContext fNamespaceContext;
    private boolean fNeedPushNSContext;
    private final ResolutionForwarder fResolutionForwarder;
    private final SAXLocatorWrapper fSAXLocatorWrapper;
    private final XMLSchemaValidator fSchemaValidator;
    private boolean fStringsInternalized;
    private final SymbolTable fSymbolTable;
    private final XMLString fTempString;
    private final XMLSchemaTypeInfoProvider fTypeInfoProvider;
    private HashMap fUnparsedEntities;
    private final ValidationManager fValidationManager;

    /* renamed from: org.apache.xerces.jaxp.validation.ValidatorHandlerImpl$1  reason: invalid class name */
    class AnonymousClass1 {
    }

    static final class ResolutionForwarder implements EntityResolver2 {
        private static final String XML_TYPE = "http://www.w3.org/TR/REC-xml";
        protected LSResourceResolver fEntityResolver;

        public ResolutionForwarder() {
        }

        public ResolutionForwarder(LSResourceResolver lSResourceResolver) {
            setEntityResolver(lSResourceResolver);
        }

        private String resolveSystemId(String str, String str2) {
            String str3 = str;
            try {
                return XMLEntityManager.expandSystemId(str3, str2, false);
            } catch (URI.MalformedURIException e) {
                URI.MalformedURIException malformedURIException = e;
                return str3;
            }
        }

        public LSResourceResolver getEntityResolver() {
            return this.fEntityResolver;
        }

        public InputSource getExternalSubset(String str, String str2) throws SAXException, IOException {
            String str3 = str;
            String str4 = str2;
            return null;
        }

        public InputSource resolveEntity(String str, String str2) throws SAXException, IOException {
            return resolveEntity((String) null, str, (String) null, str2);
        }

        public InputSource resolveEntity(String str, String str2, String str3, String str4) throws SAXException, IOException {
            LSInput resolveResource;
            InputSource inputSource;
            Reader reader;
            String str5 = str;
            String str6 = str2;
            String str7 = str3;
            String str8 = str4;
            if (this.fEntityResolver == null || (resolveResource = this.fEntityResolver.resolveResource("http://www.w3.org/TR/REC-xml", (String) null, str6, str8, str7)) == null) {
                return null;
            }
            String publicId = resolveResource.getPublicId();
            String systemId = resolveResource.getSystemId();
            String baseURI = resolveResource.getBaseURI();
            Reader characterStream = resolveResource.getCharacterStream();
            InputStream byteStream = resolveResource.getByteStream();
            String stringData = resolveResource.getStringData();
            String encoding = resolveResource.getEncoding();
            new InputSource();
            InputSource inputSource2 = inputSource;
            inputSource2.setPublicId(publicId);
            inputSource2.setSystemId(baseURI != null ? resolveSystemId(systemId, baseURI) : systemId);
            if (characterStream != null) {
                inputSource2.setCharacterStream(characterStream);
            } else if (byteStream != null) {
                inputSource2.setByteStream(byteStream);
            } else if (!(stringData == null || stringData.length() == 0)) {
                new StringReader(stringData);
                inputSource2.setCharacterStream(reader);
            }
            inputSource2.setEncoding(encoding);
            return inputSource2;
        }

        public void setEntityResolver(LSResourceResolver lSResourceResolver) {
            LSResourceResolver lSResourceResolver2 = lSResourceResolver;
            this.fEntityResolver = lSResourceResolver2;
        }
    }

    private class XMLSchemaTypeInfoProvider extends TypeInfoProvider {
        private XMLAttributes fAttributes;
        private Augmentations fElementAugs;
        private boolean fInEndElement;
        private boolean fInStartElement;
        private final ValidatorHandlerImpl this$0;

        private XMLSchemaTypeInfoProvider(ValidatorHandlerImpl validatorHandlerImpl) {
            this.this$0 = validatorHandlerImpl;
            this.fInStartElement = false;
            this.fInEndElement = false;
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        XMLSchemaTypeInfoProvider(ValidatorHandlerImpl validatorHandlerImpl, AnonymousClass1 r7) {
            this(validatorHandlerImpl);
            AnonymousClass1 r2 = r7;
        }

        private void checkStateAttribute() {
            Throwable th;
            if (!this.fInStartElement) {
                Throwable th2 = th;
                new IllegalStateException(JAXPValidationMessageFormatter.formatMessage(ValidatorHandlerImpl.access$100(this.this$0).getLocale(), "TypeInfoProviderIllegalStateAttribute", (Object[]) null));
                throw th2;
            }
        }

        private void checkStateElement() {
            Throwable th;
            if (!this.fInStartElement && !this.fInEndElement) {
                Throwable th2 = th;
                new IllegalStateException(JAXPValidationMessageFormatter.formatMessage(ValidatorHandlerImpl.access$100(this.this$0).getLocale(), "TypeInfoProviderIllegalStateElement", (Object[]) null));
                throw th2;
            }
        }

        private TypeInfo getAttributeType(int i) {
            Throwable th;
            int i2 = i;
            checkStateAttribute();
            if (i2 < 0 || this.fAttributes.getLength() <= i2) {
                Throwable th2 = th;
                new IndexOutOfBoundsException(Integer.toString(i2));
                throw th2;
            }
            Augmentations augmentations = this.fAttributes.getAugmentations(i2);
            if (augmentations == null) {
                return null;
            }
            return getTypeInfoFromPSVI((AttributePSVI) augmentations.getItem("ATTRIBUTE_PSVI"));
        }

        private TypeInfo getTypeInfoFromPSVI(ItemPSVI itemPSVI) {
            XSSimpleTypeDefinition memberTypeDefinition;
            ItemPSVI itemPSVI2 = itemPSVI;
            if (itemPSVI2 == null) {
                return null;
            }
            if (itemPSVI2.getValidity() != 2 || (memberTypeDefinition = itemPSVI2.getMemberTypeDefinition()) == null) {
                XSTypeDefinition typeDefinition = itemPSVI2.getTypeDefinition();
                if (typeDefinition == null) {
                    return null;
                }
                return typeDefinition instanceof TypeInfo ? (TypeInfo) typeDefinition : null;
            }
            return memberTypeDefinition instanceof TypeInfo ? (TypeInfo) memberTypeDefinition : null;
        }

        /* access modifiers changed from: package-private */
        public void beginEndElement(Augmentations augmentations) {
            this.fInEndElement = true;
            this.fElementAugs = augmentations;
        }

        /* access modifiers changed from: package-private */
        public void beginStartElement(Augmentations augmentations, XMLAttributes xMLAttributes) {
            this.fInStartElement = true;
            this.fElementAugs = augmentations;
            this.fAttributes = xMLAttributes;
        }

        /* access modifiers changed from: package-private */
        public void finishEndElement() {
            this.fInEndElement = false;
            this.fElementAugs = null;
        }

        /* access modifiers changed from: package-private */
        public void finishStartElement() {
            this.fInStartElement = false;
            this.fElementAugs = null;
            this.fAttributes = null;
        }

        /* access modifiers changed from: package-private */
        public AttributePSVI getAttributePSVI(int i) {
            Augmentations augmentations;
            int i2 = i;
            if (this.fAttributes == null || (augmentations = this.fAttributes.getAugmentations(i2)) == null) {
                return null;
            }
            return (AttributePSVI) augmentations.getItem("ATTRIBUTE_PSVI");
        }

        /* access modifiers changed from: package-private */
        public AttributePSVI getAttributePSVIByName(String str, String str2) {
            Augmentations augmentations;
            String str3 = str;
            String str4 = str2;
            if (this.fAttributes == null || (augmentations = this.fAttributes.getAugmentations(str3, str4)) == null) {
                return null;
            }
            return (AttributePSVI) augmentations.getItem("ATTRIBUTE_PSVI");
        }

        public TypeInfo getAttributeTypeInfo(int i) {
            checkStateAttribute();
            return getAttributeType(i);
        }

        public TypeInfo getAttributeTypeInfo(String str) {
            checkStateAttribute();
            return getAttributeTypeInfo(this.fAttributes.getIndex(str));
        }

        public TypeInfo getAttributeTypeInfo(String str, String str2) {
            checkStateAttribute();
            return getAttributeTypeInfo(this.fAttributes.getIndex(str, str2));
        }

        /* access modifiers changed from: package-private */
        public ElementPSVI getElementPSVI() {
            return this.fElementAugs != null ? (ElementPSVI) this.fElementAugs.getItem("ELEMENT_PSVI") : null;
        }

        public TypeInfo getElementTypeInfo() {
            checkStateElement();
            if (this.fElementAugs == null) {
                return null;
            }
            return getTypeInfoFromPSVI((ElementPSVI) this.fElementAugs.getItem("ELEMENT_PSVI"));
        }

        public boolean isIdAttribute(int i) {
            checkStateAttribute();
            XSSimpleType attributeType = getAttributeType(i);
            if (attributeType == null) {
                return false;
            }
            return attributeType.isIDType();
        }

        public boolean isSpecified(int i) {
            checkStateAttribute();
            return this.fAttributes.isSpecified(i);
        }
    }

    public ValidatorHandlerImpl(XMLSchemaValidatorComponentManager xMLSchemaValidatorComponentManager) {
        SAXLocatorWrapper sAXLocatorWrapper;
        QName qName;
        QName qName2;
        XMLAttributesImpl xMLAttributesImpl;
        AttributesProxy attributesProxy;
        XMLString xMLString;
        XMLSchemaTypeInfoProvider xMLSchemaTypeInfoProvider;
        ResolutionForwarder resolutionForwarder;
        new SAXLocatorWrapper();
        this.fSAXLocatorWrapper = sAXLocatorWrapper;
        this.fNeedPushNSContext = true;
        this.fUnparsedEntities = null;
        this.fStringsInternalized = false;
        new QName();
        this.fElementQName = qName;
        new QName();
        this.fAttributeQName = qName2;
        new XMLAttributesImpl();
        this.fAttributes = xMLAttributesImpl;
        new AttributesProxy(this.fAttributes);
        this.fAttrAdapter = attributesProxy;
        new XMLString();
        this.fTempString = xMLString;
        this.fContentHandler = null;
        new XMLSchemaTypeInfoProvider(this, (AnonymousClass1) null);
        this.fTypeInfoProvider = xMLSchemaTypeInfoProvider;
        new ResolutionForwarder((LSResourceResolver) null);
        this.fResolutionForwarder = resolutionForwarder;
        this.fComponentManager = xMLSchemaValidatorComponentManager;
        this.fErrorReporter = (XMLErrorReporter) this.fComponentManager.getProperty(ERROR_REPORTER);
        this.fNamespaceContext = (NamespaceContext) this.fComponentManager.getProperty(NAMESPACE_CONTEXT);
        this.fSchemaValidator = (XMLSchemaValidator) this.fComponentManager.getProperty(SCHEMA_VALIDATOR);
        this.fSymbolTable = (SymbolTable) this.fComponentManager.getProperty(SYMBOL_TABLE);
        this.fValidationManager = (ValidationManager) this.fComponentManager.getProperty(VALIDATION_MANAGER);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ValidatorHandlerImpl(org.apache.xerces.jaxp.validation.XSGrammarPoolContainer r9) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            r2 = r0
            org.apache.xerces.jaxp.validation.XMLSchemaValidatorComponentManager r3 = new org.apache.xerces.jaxp.validation.XMLSchemaValidatorComponentManager
            r7 = r3
            r3 = r7
            r4 = r7
            r5 = r1
            r4.<init>(r5)
            r2.<init>((org.apache.xerces.jaxp.validation.XMLSchemaValidatorComponentManager) r3)
            r2 = r0
            org.apache.xerces.jaxp.validation.XMLSchemaValidatorComponentManager r2 = r2.fComponentManager
            r3 = 1
            java.lang.String[] r3 = new java.lang.String[r3]
            r7 = r3
            r3 = r7
            r4 = r7
            r5 = 0
            java.lang.String r6 = "http://xml.org/sax/features/namespace-prefixes"
            r4[r5] = r6
            r2.addRecognizedFeatures(r3)
            r2 = r0
            org.apache.xerces.jaxp.validation.XMLSchemaValidatorComponentManager r2 = r2.fComponentManager
            java.lang.String r3 = "http://xml.org/sax/features/namespace-prefixes"
            r4 = 0
            r2.setFeature(r3, r4)
            r2 = r0
            r3 = 0
            r2.setErrorHandler(r3)
            r2 = r0
            r3 = 0
            r2.setResourceResolver(r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.jaxp.validation.ValidatorHandlerImpl.<init>(org.apache.xerces.jaxp.validation.XSGrammarPoolContainer):void");
    }

    static XMLSchemaValidatorComponentManager access$100(ValidatorHandlerImpl validatorHandlerImpl) {
        return validatorHandlerImpl.fComponentManager;
    }

    private void fillQName(QName qName, String str, String str2, String str3) {
        QName qName2 = qName;
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        if (!this.fStringsInternalized) {
            str4 = (str4 == null || str4.length() <= 0) ? null : this.fSymbolTable.addSymbol(str4);
            str5 = str5 != null ? this.fSymbolTable.addSymbol(str5) : XMLSymbols.EMPTY_STRING;
            str6 = str6 != null ? this.fSymbolTable.addSymbol(str6) : XMLSymbols.EMPTY_STRING;
        } else {
            if (str4 != null && str4.length() == 0) {
                str4 = null;
            }
            if (str5 == null) {
                str5 = XMLSymbols.EMPTY_STRING;
            }
            if (str6 == null) {
                str6 = XMLSymbols.EMPTY_STRING;
            }
        }
        String str7 = XMLSymbols.EMPTY_STRING;
        int indexOf = str6.indexOf(58);
        if (indexOf != -1) {
            str7 = this.fSymbolTable.addSymbol(str6.substring(0, indexOf));
        }
        qName2.setValues(str7, str5, str6, str4);
    }

    private void fillXMLAttribute(Attributes attributes, int i) {
        Attributes attributes2 = attributes;
        int i2 = i;
        fillQName(this.fAttributeQName, attributes2.getURI(i2), attributes2.getLocalName(i2), attributes2.getQName(i2));
        String type = attributes2.getType(i2);
        this.fAttributes.addAttributeNS(this.fAttributeQName, type != null ? type : XMLSymbols.fCDATASymbol, attributes2.getValue(i2));
    }

    private void fillXMLAttributes(Attributes attributes) {
        Attributes attributes2 = attributes;
        this.fAttributes.removeAllAttributes();
        int length = attributes2.getLength();
        for (int i = 0; i < length; i++) {
            fillXMLAttribute(attributes2, i);
            this.fAttributes.setSpecified(i, true);
        }
    }

    private void fillXMLAttributes2(Attributes2 attributes2) {
        Attributes2 attributes22 = attributes2;
        this.fAttributes.removeAllAttributes();
        int length = attributes22.getLength();
        for (int i = 0; i < length; i++) {
            fillXMLAttribute(attributes22, i);
            this.fAttributes.setSpecified(i, attributes22.isSpecified(i));
            if (attributes22.isDeclared(i)) {
                Object putItem = this.fAttributes.getAugmentations(i).putItem("ATTRIBUTE_DECLARED", Boolean.TRUE);
            }
        }
    }

    public void characters(XMLString xMLString, Augmentations augmentations) throws XNIException {
        Throwable th;
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (this.fContentHandler != null && xMLString2.length != 0) {
            try {
                this.fContentHandler.characters(xMLString2.ch, xMLString2.offset, xMLString2.length);
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }
    }

    public void characters(char[] cArr, int i, int i2) throws SAXException {
        try {
            this.fTempString.setValues(cArr, i, i2);
            this.fSchemaValidator.characters(this.fTempString, (Augmentations) null);
        } catch (XMLParseException e) {
            throw Util.toSAXParseException(e);
        } catch (XNIException e2) {
            throw Util.toSAXException(e2);
        }
    }

    public void comment(XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void doctypeDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
    }

    public void emptyElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        startElement(qName2, xMLAttributes, augmentations2);
        endElement(qName2, augmentations2);
    }

    public void endCDATA(Augmentations augmentations) throws XNIException {
    }

    public void endDocument() throws SAXException {
        this.fSAXLocatorWrapper.setLocator((Locator) null);
        try {
            this.fSchemaValidator.endDocument((Augmentations) null);
        } catch (XMLParseException e) {
            throw Util.toSAXParseException(e);
        } catch (XNIException e2) {
            throw Util.toSAXException(e2);
        }
    }

    public void endDocument(Augmentations augmentations) throws XNIException {
        Throwable th;
        Augmentations augmentations2 = augmentations;
        if (this.fContentHandler != null) {
            try {
                this.fContentHandler.endDocument();
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }
    }

    public void endElement(String str, String str2, String str3) throws SAXException {
        fillQName(this.fElementQName, str, str2, str3);
        try {
            this.fSchemaValidator.endElement(this.fElementQName, (Augmentations) null);
            this.fNamespaceContext.popContext();
        } catch (XMLParseException e) {
            throw Util.toSAXParseException(e);
        } catch (XNIException e2) {
            throw Util.toSAXException(e2);
        } catch (Throwable th) {
            Throwable th2 = th;
            this.fNamespaceContext.popContext();
            throw th2;
        }
    }

    public void endElement(QName qName, Augmentations augmentations) throws XNIException {
        Throwable th;
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        if (this.fContentHandler != null) {
            try {
                this.fTypeInfoProvider.beginEndElement(augmentations2);
                this.fContentHandler.endElement(qName2.uri != null ? qName2.uri : XMLSymbols.EMPTY_STRING, qName2.localpart, qName2.rawname);
                this.fTypeInfoProvider.finishEndElement();
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            } catch (Throwable th3) {
                Throwable th4 = th3;
                this.fTypeInfoProvider.finishEndElement();
                throw th4;
            }
        }
    }

    public void endGeneralEntity(String str, Augmentations augmentations) throws XNIException {
    }

    public void endPrefixMapping(String str) throws SAXException {
        String str2 = str;
        if (this.fContentHandler != null) {
            this.fContentHandler.endPrefixMapping(str2);
        }
    }

    public AttributePSVI getAttributePSVI(int i) {
        return this.fTypeInfoProvider.getAttributePSVI(i);
    }

    public AttributePSVI getAttributePSVIByName(String str, String str2) {
        return this.fTypeInfoProvider.getAttributePSVIByName(str, str2);
    }

    public ContentHandler getContentHandler() {
        return this.fContentHandler;
    }

    public XMLDocumentSource getDocumentSource() {
        return this.fSchemaValidator;
    }

    public ElementPSVI getElementPSVI() {
        return this.fTypeInfoProvider.getElementPSVI();
    }

    public ErrorHandler getErrorHandler() {
        return this.fComponentManager.getErrorHandler();
    }

    public boolean getFeature(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        if (str2 == null) {
            Throwable th4 = th3;
            new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "FeatureNameNull", (Object[]) null));
            throw th4;
        } else if (STRINGS_INTERNED.equals(str2)) {
            return this.fStringsInternalized;
        } else {
            try {
                return this.fComponentManager.getFeature(str2);
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
                String identifier = xMLConfigurationException.getIdentifier();
                if (xMLConfigurationException.getType() == 0) {
                    Throwable th5 = th2;
                    new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "feature-not-recognized", new Object[]{identifier}));
                    throw th5;
                }
                Throwable th6 = th;
                new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "feature-not-supported", new Object[]{identifier}));
                throw th6;
            }
        }
    }

    public Object getProperty(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        if (str2 == null) {
            Throwable th4 = th3;
            new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "ProperyNameNull", (Object[]) null));
            throw th4;
        }
        try {
            return this.fComponentManager.getProperty(str2);
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
            String identifier = xMLConfigurationException.getIdentifier();
            if (xMLConfigurationException.getType() == 0) {
                Throwable th5 = th2;
                new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "property-not-recognized", new Object[]{identifier}));
                throw th5;
            }
            Throwable th6 = th;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "property-not-supported", new Object[]{identifier}));
            throw th6;
        }
    }

    public LSResourceResolver getResourceResolver() {
        return this.fComponentManager.getResourceResolver();
    }

    public TypeInfoProvider getTypeInfoProvider() {
        return this.fTypeInfoProvider;
    }

    public void ignorableWhitespace(XMLString xMLString, Augmentations augmentations) throws XNIException {
        Throwable th;
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (this.fContentHandler != null) {
            try {
                this.fContentHandler.ignorableWhitespace(xMLString2.ch, xMLString2.offset, xMLString2.length);
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }
    }

    public void ignorableWhitespace(char[] cArr, int i, int i2) throws SAXException {
        try {
            this.fTempString.setValues(cArr, i, i2);
            this.fSchemaValidator.ignorableWhitespace(this.fTempString, (Augmentations) null);
        } catch (XMLParseException e) {
            throw Util.toSAXParseException(e);
        } catch (XNIException e2) {
            throw Util.toSAXException(e2);
        }
    }

    public boolean isEntityDeclared(String str) {
        String str2 = str;
        return false;
    }

    public boolean isEntityUnparsed(String str) {
        String str2 = str;
        if (this.fUnparsedEntities != null) {
            return this.fUnparsedEntities.containsKey(str2);
        }
        return false;
    }

    public void notationDecl(String str, String str2, String str3) throws SAXException {
    }

    public void processingInstruction(String str, String str2) throws SAXException {
        String str3 = str;
        String str4 = str2;
        if (this.fContentHandler != null) {
            this.fContentHandler.processingInstruction(str3, str4);
        }
    }

    public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
        Throwable th;
        String str2 = str;
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (this.fContentHandler != null) {
            try {
                this.fContentHandler.processingInstruction(str2, xMLString2.toString());
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }
    }

    public void setContentHandler(ContentHandler contentHandler) {
        ContentHandler contentHandler2 = contentHandler;
        this.fContentHandler = contentHandler2;
    }

    public void setDocumentLocator(Locator locator) {
        Locator locator2 = locator;
        this.fSAXLocatorWrapper.setLocator(locator2);
        if (this.fContentHandler != null) {
            this.fContentHandler.setDocumentLocator(locator2);
        }
    }

    public void setDocumentSource(XMLDocumentSource xMLDocumentSource) {
    }

    public void setErrorHandler(ErrorHandler errorHandler) {
        this.fComponentManager.setErrorHandler(errorHandler);
    }

    public void setFeature(String str, boolean z) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        boolean z2 = z;
        if (str2 == null) {
            Throwable th4 = th3;
            new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "FeatureNameNull", (Object[]) null));
            throw th4;
        } else if (STRINGS_INTERNED.equals(str2)) {
            this.fStringsInternalized = z2;
        } else {
            try {
                this.fComponentManager.setFeature(str2, z2);
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
                String identifier = xMLConfigurationException.getIdentifier();
                if (xMLConfigurationException.getType() == 0) {
                    Throwable th5 = th2;
                    new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "feature-not-recognized", new Object[]{identifier}));
                    throw th5;
                }
                Throwable th6 = th;
                new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "feature-not-supported", new Object[]{identifier}));
                throw th6;
            }
        }
    }

    public void setProperty(String str, Object obj) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        Object obj2 = obj;
        if (str2 == null) {
            Throwable th4 = th3;
            new NullPointerException(JAXPValidationMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "ProperyNameNull", (Object[]) null));
            throw th4;
        }
        try {
            this.fComponentManager.setProperty(str2, obj2);
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
            String identifier = xMLConfigurationException.getIdentifier();
            if (xMLConfigurationException.getType() == 0) {
                Throwable th5 = th2;
                new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "property-not-recognized", new Object[]{identifier}));
                throw th5;
            }
            Throwable th6 = th;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fComponentManager.getLocale(), "property-not-supported", new Object[]{identifier}));
            throw th6;
        }
    }

    public void setResourceResolver(LSResourceResolver lSResourceResolver) {
        this.fComponentManager.setResourceResolver(lSResourceResolver);
    }

    public void skippedEntity(String str) throws SAXException {
        String str2 = str;
        if (this.fContentHandler != null) {
            this.fContentHandler.skippedEntity(str2);
        }
    }

    public void startCDATA(Augmentations augmentations) throws XNIException {
    }

    public void startDocument() throws SAXException {
        this.fComponentManager.reset();
        this.fSchemaValidator.setDocumentHandler(this);
        this.fValidationManager.setEntityState(this);
        this.fTypeInfoProvider.finishStartElement();
        this.fNeedPushNSContext = true;
        if (this.fUnparsedEntities != null && !this.fUnparsedEntities.isEmpty()) {
            this.fUnparsedEntities.clear();
        }
        this.fErrorReporter.setDocumentLocator(this.fSAXLocatorWrapper);
        try {
            this.fSchemaValidator.startDocument(this.fSAXLocatorWrapper, this.fSAXLocatorWrapper.getEncoding(), this.fNamespaceContext, (Augmentations) null);
        } catch (XMLParseException e) {
            throw Util.toSAXParseException(e);
        } catch (XNIException e2) {
            throw Util.toSAXException(e2);
        }
    }

    public void startDocument(XMLLocator xMLLocator, String str, NamespaceContext namespaceContext, Augmentations augmentations) throws XNIException {
        Throwable th;
        XMLLocator xMLLocator2 = xMLLocator;
        String str2 = str;
        NamespaceContext namespaceContext2 = namespaceContext;
        Augmentations augmentations2 = augmentations;
        if (this.fContentHandler != null) {
            try {
                this.fContentHandler.startDocument();
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }
    }

    public void startElement(String str, String str2, String str3, Attributes attributes) throws SAXException {
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        Attributes attributes2 = attributes;
        if (this.fNeedPushNSContext) {
            this.fNamespaceContext.pushContext();
        }
        this.fNeedPushNSContext = true;
        fillQName(this.fElementQName, str4, str5, str6);
        if (attributes2 instanceof Attributes2) {
            fillXMLAttributes2((Attributes2) attributes2);
        } else {
            fillXMLAttributes(attributes2);
        }
        try {
            this.fSchemaValidator.startElement(this.fElementQName, this.fAttributes, (Augmentations) null);
        } catch (XMLParseException e) {
            throw Util.toSAXParseException(e);
        } catch (XNIException e2) {
            throw Util.toSAXException(e2);
        }
    }

    public void startElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        Throwable th;
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        if (this.fContentHandler != null) {
            try {
                this.fTypeInfoProvider.beginStartElement(augmentations2, xMLAttributes2);
                this.fContentHandler.startElement(qName2.uri != null ? qName2.uri : XMLSymbols.EMPTY_STRING, qName2.localpart, qName2.rawname, this.fAttrAdapter);
                this.fTypeInfoProvider.finishStartElement();
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            } catch (Throwable th3) {
                Throwable th4 = th3;
                this.fTypeInfoProvider.finishStartElement();
                throw th4;
            }
        }
    }

    public void startGeneralEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
    }

    public void startPrefixMapping(String str, String str2) throws SAXException {
        String str3;
        String str4;
        String str5 = str;
        String str6 = str2;
        if (!this.fStringsInternalized) {
            str3 = str5 != null ? this.fSymbolTable.addSymbol(str5) : XMLSymbols.EMPTY_STRING;
            str4 = (str6 == null || str6.length() <= 0) ? null : this.fSymbolTable.addSymbol(str6);
        } else {
            str3 = str5 != null ? str5 : XMLSymbols.EMPTY_STRING;
            str4 = (str6 == null || str6.length() <= 0) ? null : str6;
        }
        if (this.fNeedPushNSContext) {
            this.fNeedPushNSContext = false;
            this.fNamespaceContext.pushContext();
        }
        boolean declarePrefix = this.fNamespaceContext.declarePrefix(str3, str4);
        if (this.fContentHandler != null) {
            this.fContentHandler.startPrefixMapping(str5, str6);
        }
    }

    public void textDecl(String str, String str2, Augmentations augmentations) throws XNIException {
    }

    public void unparsedEntityDecl(String str, String str2, String str3, String str4) throws SAXException {
        HashMap hashMap;
        String str5 = str;
        String str6 = str2;
        String str7 = str3;
        String str8 = str4;
        if (this.fUnparsedEntities == null) {
            new HashMap();
            this.fUnparsedEntities = hashMap;
        }
        Object put = this.fUnparsedEntities.put(str5, str5);
    }

    public void validate(Source source, Result result) throws SAXException, IOException {
        Throwable th;
        Object property;
        Throwable th2;
        Source source2 = source;
        Result result2 = result;
        if ((result2 instanceof SAXResult) || result2 == null) {
            SAXSource sAXSource = (SAXSource) source2;
            SAXResult sAXResult = (SAXResult) result2;
            LexicalHandler lexicalHandler = null;
            if (result2 != null) {
                ContentHandler handler = sAXResult.getHandler();
                lexicalHandler = sAXResult.getLexicalHandler();
                if (lexicalHandler == null && (handler instanceof LexicalHandler)) {
                    lexicalHandler = (LexicalHandler) handler;
                }
                setContentHandler(handler);
            }
            XMLReader xMLReader = null;
            try {
                xMLReader = sAXSource.getXMLReader();
                if (xMLReader == null) {
                    SAXParserFactory newInstance = SAXParserFactory.newInstance();
                    newInstance.setNamespaceAware(true);
                    xMLReader = newInstance.newSAXParser().getXMLReader();
                    if ((xMLReader instanceof SAXParser) && (property = this.fComponentManager.getProperty(SECURITY_MANAGER)) != null) {
                        try {
                            xMLReader.setProperty(SECURITY_MANAGER, property);
                        } catch (SAXException e) {
                            SAXException sAXException = e;
                        }
                    }
                }
                try {
                    this.fStringsInternalized = xMLReader.getFeature(STRING_INTERNING);
                } catch (SAXException e2) {
                    SAXException sAXException2 = e2;
                    this.fStringsInternalized = false;
                }
                ErrorHandler errorHandler = this.fComponentManager.getErrorHandler();
                xMLReader.setErrorHandler(errorHandler != null ? errorHandler : DraconianErrorHandler.getInstance());
                xMLReader.setEntityResolver(this.fResolutionForwarder);
                this.fResolutionForwarder.setEntityResolver(this.fComponentManager.getResourceResolver());
                xMLReader.setContentHandler(this);
                xMLReader.setDTDHandler(this);
                try {
                    xMLReader.setProperty(LEXICAL_HANDLER, lexicalHandler);
                } catch (SAXException e3) {
                    SAXException sAXException3 = e3;
                }
                xMLReader.parse(sAXSource.getInputSource());
                setContentHandler((ContentHandler) null);
                if (xMLReader != null) {
                    try {
                        xMLReader.setContentHandler((ContentHandler) null);
                        xMLReader.setDTDHandler((DTDHandler) null);
                        xMLReader.setErrorHandler((ErrorHandler) null);
                        xMLReader.setEntityResolver((EntityResolver) null);
                        this.fResolutionForwarder.setEntityResolver((LSResourceResolver) null);
                        xMLReader.setProperty(LEXICAL_HANDLER, (Object) null);
                    } catch (Exception e4) {
                        Exception exc = e4;
                    }
                }
            } catch (Exception e5) {
                Exception exc2 = e5;
                Throwable th3 = th;
                new FactoryConfigurationError(exc2);
                throw th3;
            } catch (Throwable th4) {
                Throwable th5 = th4;
                setContentHandler((ContentHandler) null);
                if (xMLReader != null) {
                    try {
                        xMLReader.setContentHandler((ContentHandler) null);
                        xMLReader.setDTDHandler((DTDHandler) null);
                        xMLReader.setErrorHandler((ErrorHandler) null);
                        xMLReader.setEntityResolver((EntityResolver) null);
                        this.fResolutionForwarder.setEntityResolver((LSResourceResolver) null);
                        xMLReader.setProperty(LEXICAL_HANDLER, (Object) null);
                    } catch (Exception e6) {
                        Exception exc3 = e6;
                    }
                }
                throw th5;
            }
        } else {
            Throwable th6 = th2;
            Locale locale = this.fComponentManager.getLocale();
            Object[] objArr = new Object[2];
            objArr[0] = source2.getClass().getName();
            Object[] objArr2 = objArr;
            objArr2[1] = result2.getClass().getName();
            new IllegalArgumentException(JAXPValidationMessageFormatter.formatMessage(locale, "SourceResultMismatch", objArr2));
            throw th6;
        }
    }

    public void xmlDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
    }
}
