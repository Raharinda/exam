package org.apache.xerces.jaxp.datatype;

import com.bumptech.glide.request.target.Target;
import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import org.apache.xerces.dom3.as.ASContentModel;
import org.apache.xerces.util.DatatypeMessageFormatter;

class XMLGregorianCalendarImpl extends XMLGregorianCalendar implements Serializable, Cloneable {
    private static final BigInteger BILLION_B = BigInteger.valueOf(1000000000);
    private static final int BILLION_I = 1000000000;
    private static final int DAY = 2;
    private static final BigDecimal DECIMAL_ONE = BigDecimal.valueOf(1);
    private static final BigDecimal DECIMAL_SIXTY = BigDecimal.valueOf(60);
    private static final BigDecimal DECIMAL_ZERO = BigDecimal.valueOf(0);
    private static final String[] FIELD_NAME;
    private static final BigInteger FOUR = BigInteger.valueOf(4);
    private static final BigInteger FOUR_HUNDRED = BigInteger.valueOf(400);
    private static final int HOUR = 3;
    private static final BigInteger HUNDRED = BigInteger.valueOf(100);
    public static final XMLGregorianCalendar LEAP_YEAR_DEFAULT = createDateTime(400, 1, 1, 0, 0, 0, (int) Target.SIZE_ORIGINAL, (int) Target.SIZE_ORIGINAL);
    private static final int[] MAX_FIELD_VALUE = {ASContentModel.AS_UNBOUNDED, 12, 31, 24, 59, 60, 999, 840};
    private static final int MILLISECOND = 6;
    private static final int MINUTE = 4;
    private static final int[] MIN_FIELD_VALUE = {Target.SIZE_ORIGINAL, 1, 1, 0, 0, 0, 0, -840};
    private static final int MONTH = 1;
    private static final Date PURE_GREGORIAN_CHANGE;
    private static final int SECOND = 5;
    private static final BigInteger SIXTY = BigInteger.valueOf(60);
    private static final int TIMEZONE = 7;
    private static final BigInteger TWELVE = BigInteger.valueOf(12);
    private static final BigInteger TWENTY_FOUR = BigInteger.valueOf(24);
    private static final int YEAR = 0;
    private static final long serialVersionUID = 3905403108073447394L;
    private int day = Target.SIZE_ORIGINAL;
    private BigInteger eon = null;
    private BigDecimal fractionalSecond = null;
    private int hour = Target.SIZE_ORIGINAL;
    private int minute = Target.SIZE_ORIGINAL;
    private int month = Target.SIZE_ORIGINAL;
    private int orig_day = Target.SIZE_ORIGINAL;
    private BigInteger orig_eon;
    private BigDecimal orig_fracSeconds;
    private int orig_hour = Target.SIZE_ORIGINAL;
    private int orig_minute = Target.SIZE_ORIGINAL;
    private int orig_month = Target.SIZE_ORIGINAL;
    private int orig_second = Target.SIZE_ORIGINAL;
    private int orig_timezone = Target.SIZE_ORIGINAL;
    private int orig_year = Target.SIZE_ORIGINAL;
    private int second = Target.SIZE_ORIGINAL;
    private int timezone = Target.SIZE_ORIGINAL;
    private int year = Target.SIZE_ORIGINAL;

    /* renamed from: org.apache.xerces.jaxp.datatype.XMLGregorianCalendarImpl$1  reason: invalid class name */
    class AnonymousClass1 {
    }

    private static class DaysInMonth {
        private static final int[] table = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

        private DaysInMonth() {
        }

        static int[] access$100() {
            return table;
        }
    }

    private final class Parser {
        private int fidx;
        private final int flen;
        private final String format;
        private final XMLGregorianCalendarImpl this$0;
        private final String value;
        private int vidx;
        private final int vlen;

        private Parser(XMLGregorianCalendarImpl xMLGregorianCalendarImpl, String str, String str2) {
            String str3 = str;
            String str4 = str2;
            this.this$0 = xMLGregorianCalendarImpl;
            this.format = str3;
            this.value = str4;
            this.flen = str3.length();
            this.vlen = str4.length();
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        Parser(XMLGregorianCalendarImpl xMLGregorianCalendarImpl, String str, String str2, AnonymousClass1 r13) {
            this(xMLGregorianCalendarImpl, str, str2);
            AnonymousClass1 r4 = r13;
        }

        private BigDecimal parseBigDecimal() throws IllegalArgumentException {
            Throwable th;
            BigDecimal bigDecimal;
            int i = this.vidx;
            if (peek() == '.') {
                this.vidx++;
                while (XMLGregorianCalendarImpl.access$200(peek())) {
                    this.vidx++;
                }
                new BigDecimal(this.value.substring(i, this.vidx));
                return bigDecimal;
            }
            Throwable th2 = th;
            new IllegalArgumentException(this.value);
            throw th2;
        }

        private int parseInt(int i, int i2) throws IllegalArgumentException {
            Throwable th;
            int i3 = i;
            int i4 = i2;
            int i5 = this.vidx;
            while (XMLGregorianCalendarImpl.access$200(peek()) && this.vidx - i5 < i4) {
                this.vidx++;
            }
            if (this.vidx - i5 >= i3) {
                return Integer.parseInt(this.value.substring(i5, this.vidx));
            }
            Throwable th2 = th;
            new IllegalArgumentException(this.value);
            throw th2;
        }

        private void parseYear() throws IllegalArgumentException {
            BigInteger bigInteger;
            Throwable th;
            int i = this.vidx;
            int i2 = 0;
            if (peek() == '-') {
                this.vidx++;
                i2 = 1;
            }
            while (XMLGregorianCalendarImpl.access$200(peek())) {
                this.vidx++;
            }
            int i3 = (this.vidx - i) - i2;
            if (i3 < 4) {
                Throwable th2 = th;
                new IllegalArgumentException(this.value);
                throw th2;
            }
            String substring = this.value.substring(i, this.vidx);
            if (i3 < 10) {
                this.this$0.setYear(Integer.parseInt(substring));
                return;
            }
            new BigInteger(substring);
            this.this$0.setYear(bigInteger);
        }

        private char peek() throws IllegalArgumentException {
            if (this.vidx == this.vlen) {
                return 65535;
            }
            return this.value.charAt(this.vidx);
        }

        private char read() throws IllegalArgumentException {
            Throwable th;
            if (this.vidx == this.vlen) {
                Throwable th2 = th;
                new IllegalArgumentException(this.value);
                throw th2;
            }
            String str = this.value;
            int i = this.vidx;
            int i2 = i + 1;
            this.vidx = i2;
            return str.charAt(i);
        }

        private void skip(char c) throws IllegalArgumentException {
            Throwable th;
            if (read() != c) {
                Throwable th2 = th;
                new IllegalArgumentException(this.value);
                throw th2;
            }
        }

        public void parse() throws IllegalArgumentException {
            Throwable th;
            Throwable th2;
            while (this.fidx < this.flen) {
                String str = this.format;
                int i = this.fidx;
                this.fidx = i + 1;
                char charAt = str.charAt(i);
                if (charAt != '%') {
                    skip(charAt);
                } else {
                    String str2 = this.format;
                    int i2 = this.fidx;
                    this.fidx = i2 + 1;
                    switch (str2.charAt(i2)) {
                        case 'D':
                            this.this$0.setDay(parseInt(2, 2));
                            break;
                        case 'M':
                            this.this$0.setMonth(parseInt(2, 2));
                            break;
                        case 'Y':
                            parseYear();
                            break;
                        case 'h':
                            this.this$0.setHour(parseInt(2, 2));
                            break;
                        case 'm':
                            this.this$0.setMinute(parseInt(2, 2));
                            break;
                        case 's':
                            this.this$0.setSecond(parseInt(2, 2));
                            if (peek() != '.') {
                                break;
                            } else {
                                this.this$0.setFractionalSecond(parseBigDecimal());
                                break;
                            }
                        case 'z':
                            char peek = peek();
                            if (peek != 'Z') {
                                if (peek != '+' && peek != '-') {
                                    break;
                                } else {
                                    this.vidx++;
                                    int parseInt = parseInt(2, 2);
                                    skip(':');
                                    this.this$0.setTimezone(((parseInt * 60) + parseInt(2, 2)) * (peek == '+' ? 1 : -1));
                                    break;
                                }
                            } else {
                                this.vidx++;
                                this.this$0.setTimezone(0);
                                break;
                            }
                        default:
                            Throwable th3 = th2;
                            new InternalError();
                            throw th3;
                    }
                }
            }
            if (this.vidx != this.vlen) {
                Throwable th4 = th;
                new IllegalArgumentException(this.value);
                throw th4;
            }
        }
    }

    static {
        Date date;
        new Date(Long.MIN_VALUE);
        PURE_GREGORIAN_CHANGE = date;
        String[] strArr = new String[8];
        strArr[0] = "Year";
        String[] strArr2 = strArr;
        strArr2[1] = "Month";
        String[] strArr3 = strArr2;
        strArr3[2] = "Day";
        String[] strArr4 = strArr3;
        strArr4[3] = "Hour";
        String[] strArr5 = strArr4;
        strArr5[4] = "Minute";
        String[] strArr6 = strArr5;
        strArr6[5] = "Second";
        String[] strArr7 = strArr6;
        strArr7[6] = "Millisecond";
        String[] strArr8 = strArr7;
        strArr8[7] = "Timezone";
        FIELD_NAME = strArr8;
    }

    public XMLGregorianCalendarImpl() {
    }

    private XMLGregorianCalendarImpl(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        Throwable th;
        Object obj;
        Object obj2;
        Object obj3;
        Object obj4;
        Object obj5;
        Object obj6;
        Object obj7;
        Object obj8;
        int i9 = i;
        int i10 = i2;
        int i11 = i3;
        int i12 = i4;
        int i13 = i5;
        int i14 = i6;
        int i15 = i7;
        int i16 = i8;
        setYear(i9);
        setMonth(i10);
        setDay(i11);
        setTime(i12, i13, i14);
        setTimezone(i16);
        setFractionalSecond(i15 != Integer.MIN_VALUE ? BigDecimal.valueOf((long) i15, 3) : null);
        if (!isValid()) {
            Throwable th2 = th;
            Object[] objArr = new Object[8];
            new Integer(i9);
            objArr[0] = obj;
            Object[] objArr2 = objArr;
            new Integer(i10);
            objArr2[1] = obj2;
            Object[] objArr3 = objArr2;
            new Integer(i11);
            objArr3[2] = obj3;
            Object[] objArr4 = objArr3;
            new Integer(i12);
            objArr4[3] = obj4;
            Object[] objArr5 = objArr4;
            new Integer(i13);
            objArr5[4] = obj5;
            Object[] objArr6 = objArr5;
            new Integer(i14);
            objArr6[5] = obj6;
            Object[] objArr7 = objArr6;
            new Integer(i15);
            objArr7[6] = obj7;
            Object[] objArr8 = objArr7;
            new Integer(i16);
            objArr8[7] = obj8;
            new IllegalArgumentException(DatatypeMessageFormatter.formatMessage((Locale) null, "InvalidXGCValue-milli", objArr8));
            throw th2;
        }
        save();
    }

    protected XMLGregorianCalendarImpl(String str) throws IllegalArgumentException {
        String str2;
        Parser parser;
        Throwable th;
        Parser parser2;
        Throwable th2;
        String str3 = str;
        String str4 = str3;
        int length = str4.length();
        if (str4.indexOf(84) != -1) {
            str2 = "%Y-%M-%DT%h:%m:%s%z";
        } else if (length >= 3 && str4.charAt(2) == ':') {
            str2 = "%h:%m:%s%z";
        } else if (!str4.startsWith("--")) {
            int i = 0;
            length = str4.indexOf(58) != -1 ? length - 6 : length;
            for (int i2 = 1; i2 < length; i2++) {
                if (str4.charAt(i2) == '-') {
                    i++;
                }
            }
            str2 = i == 0 ? "%Y%z" : i == 1 ? "%Y-%M%z" : "%Y-%M-%D%z";
        } else if (length >= 3 && str4.charAt(2) == '-') {
            str2 = "---%D%z";
        } else if (length == 4 || (length >= 6 && (str4.charAt(4) == '+' || (str4.charAt(4) == '-' && (str4.charAt(5) == '-' || length == 10))))) {
            new Parser(this, "--%M--%z", str4, (AnonymousClass1) null);
            try {
                parser.parse();
                if (!isValid()) {
                    Throwable th3 = th;
                    new IllegalArgumentException(DatatypeMessageFormatter.formatMessage((Locale) null, "InvalidXGCRepresentation", new Object[]{str3}));
                    throw th3;
                }
                save();
                return;
            } catch (IllegalArgumentException e) {
                IllegalArgumentException illegalArgumentException = e;
                str2 = "--%M%z";
            }
        } else {
            str2 = "--%M-%D%z";
        }
        new Parser(this, str2, str4, (AnonymousClass1) null);
        parser2.parse();
        if (!isValid()) {
            Throwable th4 = th2;
            new IllegalArgumentException(DatatypeMessageFormatter.formatMessage((Locale) null, "InvalidXGCRepresentation", new Object[]{str3}));
            throw th4;
        }
        save();
    }

    protected XMLGregorianCalendarImpl(BigInteger bigInteger, int i, int i2, int i3, int i4, int i5, BigDecimal bigDecimal, int i6) {
        Throwable th;
        Object obj;
        Object obj2;
        Object obj3;
        Object obj4;
        Object obj5;
        Object obj6;
        BigInteger bigInteger2 = bigInteger;
        int i7 = i;
        int i8 = i2;
        int i9 = i3;
        int i10 = i4;
        int i11 = i5;
        BigDecimal bigDecimal2 = bigDecimal;
        int i12 = i6;
        setYear(bigInteger2);
        setMonth(i7);
        setDay(i8);
        setTime(i9, i10, i11, bigDecimal2);
        setTimezone(i12);
        if (!isValid()) {
            Throwable th2 = th;
            Object[] objArr = new Object[8];
            objArr[0] = bigInteger2;
            Object[] objArr2 = objArr;
            new Integer(i7);
            objArr2[1] = obj;
            Object[] objArr3 = objArr2;
            new Integer(i8);
            objArr3[2] = obj2;
            Object[] objArr4 = objArr3;
            new Integer(i9);
            objArr4[3] = obj3;
            Object[] objArr5 = objArr4;
            new Integer(i10);
            objArr5[4] = obj4;
            Object[] objArr6 = objArr5;
            new Integer(i11);
            objArr6[5] = obj5;
            Object[] objArr7 = objArr6;
            objArr7[6] = bigDecimal2;
            Object[] objArr8 = objArr7;
            new Integer(i12);
            objArr8[7] = obj6;
            new IllegalArgumentException(DatatypeMessageFormatter.formatMessage((Locale) null, "InvalidXGCValue-fractional", objArr8));
            throw th2;
        }
        save();
    }

    public XMLGregorianCalendarImpl(GregorianCalendar gregorianCalendar) {
        GregorianCalendar gregorianCalendar2 = gregorianCalendar;
        int i = gregorianCalendar2.get(1);
        setYear(gregorianCalendar2.get(0) == 0 ? -i : i);
        setMonth(gregorianCalendar2.get(2) + 1);
        setDay(gregorianCalendar2.get(5));
        setTime(gregorianCalendar2.get(11), gregorianCalendar2.get(12), gregorianCalendar2.get(13), gregorianCalendar2.get(14));
        setTimezone((gregorianCalendar2.get(15) + gregorianCalendar2.get(16)) / 60000);
        save();
    }

    static boolean access$200(char c) {
        return isDigit(c);
    }

    private void checkFieldValueConstraint(int i, int i2) throws IllegalArgumentException {
        Throwable th;
        Object obj;
        int i3 = i;
        int i4 = i2;
        if ((i4 < MIN_FIELD_VALUE[i3] && i4 != Integer.MIN_VALUE) || i4 > MAX_FIELD_VALUE[i3]) {
            Throwable th2 = th;
            Object[] objArr = new Object[2];
            new Integer(i4);
            objArr[0] = obj;
            Object[] objArr2 = objArr;
            objArr2[1] = FIELD_NAME[i3];
            new IllegalArgumentException(DatatypeMessageFormatter.formatMessage((Locale) null, "InvalidFieldValue", objArr2));
            throw th2;
        }
    }

    private static int compareField(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        if (i3 == i4) {
            return 0;
        }
        if (i3 == Integer.MIN_VALUE || i4 == Integer.MIN_VALUE) {
            return 2;
        }
        return i3 < i4 ? -1 : 1;
    }

    private static int compareField(BigDecimal bigDecimal, BigDecimal bigDecimal2) {
        BigDecimal bigDecimal3 = bigDecimal;
        BigDecimal bigDecimal4 = bigDecimal2;
        if (bigDecimal3 == bigDecimal4) {
            return 0;
        }
        if (bigDecimal3 == null) {
            bigDecimal3 = DECIMAL_ZERO;
        }
        if (bigDecimal4 == null) {
            bigDecimal4 = DECIMAL_ZERO;
        }
        return bigDecimal3.compareTo(bigDecimal4);
    }

    private static int compareField(BigInteger bigInteger, BigInteger bigInteger2) {
        BigInteger bigInteger3 = bigInteger;
        BigInteger bigInteger4 = bigInteger2;
        if (bigInteger3 == null) {
            return bigInteger4 == null ? 0 : 2;
        } else if (bigInteger4 == null) {
            return 2;
        } else {
            return bigInteger3.compareTo(bigInteger4);
        }
    }

    public static XMLGregorianCalendar createDate(int i, int i2, int i3, int i4) {
        XMLGregorianCalendar xMLGregorianCalendar;
        new XMLGregorianCalendarImpl(i, i2, i3, (int) Target.SIZE_ORIGINAL, (int) Target.SIZE_ORIGINAL, (int) Target.SIZE_ORIGINAL, (int) Target.SIZE_ORIGINAL, i4);
        return xMLGregorianCalendar;
    }

    public static XMLGregorianCalendar createDateTime(int i, int i2, int i3, int i4, int i5, int i6) {
        XMLGregorianCalendar xMLGregorianCalendar;
        new XMLGregorianCalendarImpl(i, i2, i3, i4, i5, i6, (int) Target.SIZE_ORIGINAL, (int) Target.SIZE_ORIGINAL);
        return xMLGregorianCalendar;
    }

    public static XMLGregorianCalendar createDateTime(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        XMLGregorianCalendar xMLGregorianCalendar;
        new XMLGregorianCalendarImpl(i, i2, i3, i4, i5, i6, i7, i8);
        return xMLGregorianCalendar;
    }

    public static XMLGregorianCalendar createDateTime(BigInteger bigInteger, int i, int i2, int i3, int i4, int i5, BigDecimal bigDecimal, int i6) {
        XMLGregorianCalendar xMLGregorianCalendar;
        new XMLGregorianCalendarImpl(bigInteger, i, i2, i3, i4, i5, bigDecimal, i6);
        return xMLGregorianCalendar;
    }

    public static XMLGregorianCalendar createTime(int i, int i2, int i3, int i4) {
        XMLGregorianCalendar xMLGregorianCalendar;
        new XMLGregorianCalendarImpl((int) Target.SIZE_ORIGINAL, (int) Target.SIZE_ORIGINAL, (int) Target.SIZE_ORIGINAL, i, i2, i3, (int) Target.SIZE_ORIGINAL, i4);
        return xMLGregorianCalendar;
    }

    public static XMLGregorianCalendar createTime(int i, int i2, int i3, int i4, int i5) {
        XMLGregorianCalendar xMLGregorianCalendar;
        new XMLGregorianCalendarImpl((int) Target.SIZE_ORIGINAL, (int) Target.SIZE_ORIGINAL, (int) Target.SIZE_ORIGINAL, i, i2, i3, i4, i5);
        return xMLGregorianCalendar;
    }

    public static XMLGregorianCalendar createTime(int i, int i2, int i3, BigDecimal bigDecimal, int i4) {
        XMLGregorianCalendar xMLGregorianCalendar;
        new XMLGregorianCalendarImpl((BigInteger) null, (int) Target.SIZE_ORIGINAL, (int) Target.SIZE_ORIGINAL, i, i2, i3, bigDecimal, i4);
        return xMLGregorianCalendar;
    }

    private String format(String str) {
        StringBuffer stringBuffer;
        Throwable th;
        String str2 = str;
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        int i = 0;
        int length = str2.length();
        while (i < length) {
            int i2 = i;
            i++;
            char charAt = str2.charAt(i2);
            if (charAt != '%') {
                StringBuffer append = stringBuffer2.append(charAt);
            } else {
                int i3 = i;
                i++;
                switch (str2.charAt(i3)) {
                    case 'D':
                        printNumber(stringBuffer2, getDay(), 2);
                        break;
                    case 'M':
                        printNumber(stringBuffer2, getMonth(), 2);
                        break;
                    case 'Y':
                        if (this.eon != null) {
                            printNumber(stringBuffer2, getEonAndYear(), 4);
                            break;
                        } else {
                            int i4 = this.year;
                            if (i4 < 0) {
                                StringBuffer append2 = stringBuffer2.append('-');
                                i4 = -this.year;
                            }
                            printNumber(stringBuffer2, i4, 4);
                            break;
                        }
                    case 'h':
                        printNumber(stringBuffer2, getHour(), 2);
                        break;
                    case 'm':
                        printNumber(stringBuffer2, getMinute(), 2);
                        break;
                    case 's':
                        printNumber(stringBuffer2, getSecond(), 2);
                        if (getFractionalSecond() == null) {
                            break;
                        } else {
                            String xMLGregorianCalendarImpl = toString(getFractionalSecond());
                            StringBuffer append3 = stringBuffer2.append(xMLGregorianCalendarImpl.substring(1, xMLGregorianCalendarImpl.length()));
                            break;
                        }
                    case 'z':
                        int timezone2 = getTimezone();
                        if (timezone2 != 0) {
                            if (timezone2 != Integer.MIN_VALUE) {
                                if (timezone2 < 0) {
                                    StringBuffer append4 = stringBuffer2.append('-');
                                    timezone2 *= -1;
                                } else {
                                    StringBuffer append5 = stringBuffer2.append('+');
                                }
                                printNumber(stringBuffer2, timezone2 / 60, 2);
                                StringBuffer append6 = stringBuffer2.append(':');
                                printNumber(stringBuffer2, timezone2 % 60, 2);
                                break;
                            } else {
                                break;
                            }
                        } else {
                            StringBuffer append7 = stringBuffer2.append('Z');
                            break;
                        }
                    default:
                        Throwable th2 = th;
                        new InternalError();
                        throw th2;
                }
            }
        }
        return stringBuffer2.toString();
    }

    private BigDecimal getSeconds() {
        if (this.second == Integer.MIN_VALUE) {
            return DECIMAL_ZERO;
        }
        BigDecimal valueOf = BigDecimal.valueOf((long) this.second);
        return this.fractionalSecond != null ? valueOf.add(this.fractionalSecond) : valueOf;
    }

    private static int internalCompare(XMLGregorianCalendar xMLGregorianCalendar, XMLGregorianCalendar xMLGregorianCalendar2) {
        XMLGregorianCalendar xMLGregorianCalendar3 = xMLGregorianCalendar;
        XMLGregorianCalendar xMLGregorianCalendar4 = xMLGregorianCalendar2;
        if (xMLGregorianCalendar3.getEon() == xMLGregorianCalendar4.getEon()) {
            int compareField = compareField(xMLGregorianCalendar3.getYear(), xMLGregorianCalendar4.getYear());
            if (compareField != 0) {
                return compareField;
            }
        } else {
            int compareField2 = compareField(xMLGregorianCalendar3.getEonAndYear(), xMLGregorianCalendar4.getEonAndYear());
            if (compareField2 != 0) {
                return compareField2;
            }
        }
        int compareField3 = compareField(xMLGregorianCalendar3.getMonth(), xMLGregorianCalendar4.getMonth());
        if (compareField3 != 0) {
            return compareField3;
        }
        int compareField4 = compareField(xMLGregorianCalendar3.getDay(), xMLGregorianCalendar4.getDay());
        if (compareField4 != 0) {
            return compareField4;
        }
        int compareField5 = compareField(xMLGregorianCalendar3.getHour(), xMLGregorianCalendar4.getHour());
        if (compareField5 != 0) {
            return compareField5;
        }
        int compareField6 = compareField(xMLGregorianCalendar3.getMinute(), xMLGregorianCalendar4.getMinute());
        if (compareField6 != 0) {
            return compareField6;
        }
        int compareField7 = compareField(xMLGregorianCalendar3.getSecond(), xMLGregorianCalendar4.getSecond());
        return compareField7 != 0 ? compareField7 : compareField(xMLGregorianCalendar3.getFractionalSecond(), xMLGregorianCalendar4.getFractionalSecond());
    }

    private static boolean isDigit(char c) {
        char c2 = c;
        return '0' <= c2 && c2 <= '9';
    }

    private static int maximumDayInMonthFor(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        if (i4 != 2) {
            return DaysInMonth.access$100()[i4];
        }
        if (i3 % 400 == 0 || (i3 % 100 != 0 && i3 % 4 == 0)) {
            return 29;
        }
        return DaysInMonth.access$100()[2];
    }

    private static int maximumDayInMonthFor(BigInteger bigInteger, int i) {
        BigInteger bigInteger2 = bigInteger;
        int i2 = i;
        if (i2 != 2) {
            return DaysInMonth.access$100()[i2];
        }
        if (bigInteger2.mod(FOUR_HUNDRED).equals(BigInteger.ZERO) || (!bigInteger2.mod(HUNDRED).equals(BigInteger.ZERO) && bigInteger2.mod(FOUR).equals(BigInteger.ZERO))) {
            return 29;
        }
        return DaysInMonth.access$100()[i2];
    }

    private XMLGregorianCalendar normalizeToTimezone(XMLGregorianCalendar xMLGregorianCalendar, int i) {
        XMLGregorianCalendar xMLGregorianCalendar2 = (XMLGregorianCalendar) xMLGregorianCalendar.clone();
        int i2 = -i;
        DurationImpl durationImpl = r15;
        DurationImpl durationImpl2 = new DurationImpl(i2 >= 0, 0, 0, 0, 0, i2 < 0 ? -i2 : i2, 0);
        xMLGregorianCalendar2.add(durationImpl);
        xMLGregorianCalendar2.setTimezone(0);
        return xMLGregorianCalendar2;
    }

    public static XMLGregorianCalendar parse(String str) {
        XMLGregorianCalendar xMLGregorianCalendar;
        new XMLGregorianCalendarImpl(str);
        return xMLGregorianCalendar;
    }

    private void printNumber(StringBuffer stringBuffer, int i, int i2) {
        StringBuffer stringBuffer2 = stringBuffer;
        int i3 = i2;
        String valueOf = String.valueOf(i);
        for (int length = valueOf.length(); length < i3; length++) {
            StringBuffer append = stringBuffer2.append('0');
        }
        StringBuffer append2 = stringBuffer2.append(valueOf);
    }

    private void printNumber(StringBuffer stringBuffer, BigInteger bigInteger, int i) {
        StringBuffer stringBuffer2 = stringBuffer;
        int i2 = i;
        String bigInteger2 = bigInteger.toString();
        for (int length = bigInteger2.length(); length < i2; length++) {
            StringBuffer append = stringBuffer2.append('0');
        }
        StringBuffer append2 = stringBuffer2.append(bigInteger2);
    }

    static BigInteger sanitize(Number number, int i) {
        Number number2 = number;
        int i2 = i;
        if (i2 == 0 || number2 == null) {
            return BigInteger.ZERO;
        }
        return i2 < 0 ? ((BigInteger) number2).negate() : (BigInteger) number2;
    }

    private void save() {
        this.orig_eon = this.eon;
        this.orig_year = this.year;
        this.orig_month = this.month;
        this.orig_day = this.day;
        this.orig_hour = this.hour;
        this.orig_minute = this.minute;
        this.orig_second = this.second;
        this.orig_fracSeconds = this.fractionalSecond;
        this.orig_timezone = this.timezone;
    }

    private void setEon(BigInteger bigInteger) {
        BigInteger bigInteger2 = bigInteger;
        if (bigInteger2 == null || bigInteger2.compareTo(BigInteger.ZERO) != 0) {
            this.eon = bigInteger2;
            return;
        }
        this.eon = null;
    }

    private String toString(BigDecimal bigDecimal) {
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        StringBuffer stringBuffer3;
        StringBuffer stringBuffer4;
        BigDecimal bigDecimal2 = bigDecimal;
        String bigInteger = bigDecimal2.unscaledValue().toString();
        int scale = bigDecimal2.scale();
        if (scale == 0) {
            return bigInteger;
        }
        int length = bigInteger.length() - scale;
        if (length == 0) {
            new StringBuffer();
            return stringBuffer4.append("0.").append(bigInteger).toString();
        }
        if (length > 0) {
            new StringBuffer(bigInteger);
            stringBuffer2 = stringBuffer3;
            StringBuffer insert = stringBuffer2.insert(length, '.');
        } else {
            new StringBuffer((3 - length) + bigInteger.length());
            stringBuffer2 = stringBuffer;
            StringBuffer append = stringBuffer2.append("0.");
            for (int i = 0; i < (-length); i++) {
                StringBuffer append2 = stringBuffer2.append('0');
            }
            StringBuffer append3 = stringBuffer2.append(bigInteger);
        }
        return stringBuffer2.toString();
    }

    private Object writeReplace() throws IOException {
        Object obj;
        new SerializedXMLGregorianCalendar(toXMLFormat());
        return obj;
    }

    public void add(Duration duration) {
        BigDecimal bigDecimal;
        BigDecimal bigDecimal2;
        BigDecimal seconds;
        BigDecimal bigDecimal3;
        BigDecimal bigDecimal4;
        BigDecimal bigDecimal5;
        BigDecimal bigDecimal6;
        BigDecimal bigDecimal7;
        BigDecimal bigDecimal8;
        int i;
        int i2;
        int i3;
        BigDecimal bigDecimal9;
        Duration duration2 = duration;
        boolean[] zArr = {false, false, false, false, false, false};
        int sign = duration2.getSign();
        int month2 = getMonth();
        if (month2 == Integer.MIN_VALUE) {
            month2 = MIN_FIELD_VALUE[1];
            zArr[1] = true;
        }
        BigInteger add = BigInteger.valueOf((long) month2).add(sanitize(duration2.getField(DatatypeConstants.MONTHS), sign));
        setMonth(add.subtract(BigInteger.ONE).mod(TWELVE).intValue() + 1);
        new BigDecimal(add.subtract(BigInteger.ONE));
        new BigDecimal(TWELVE);
        BigInteger bigInteger = bigDecimal.divide(bigDecimal2, 3).toBigInteger();
        BigInteger eonAndYear = getEonAndYear();
        if (eonAndYear == null) {
            zArr[0] = true;
            eonAndYear = BigInteger.ZERO;
        }
        setYear(eonAndYear.add(sanitize(duration2.getField(DatatypeConstants.YEARS), sign)).add(bigInteger));
        if (getSecond() == Integer.MIN_VALUE) {
            zArr[5] = true;
            seconds = DECIMAL_ZERO;
        } else {
            seconds = getSeconds();
        }
        BigDecimal add2 = seconds.add(DurationImpl.sanitize((BigDecimal) duration2.getField(DatatypeConstants.SECONDS), sign));
        new BigDecimal(add2.toBigInteger());
        new BigDecimal(bigDecimal4.divide(DECIMAL_SIXTY, 3).toBigInteger());
        BigDecimal bigDecimal10 = bigDecimal3;
        BigDecimal subtract = add2.subtract(bigDecimal10.multiply(DECIMAL_SIXTY));
        BigInteger bigInteger2 = bigDecimal10.toBigInteger();
        setSecond(subtract.intValue());
        new BigDecimal(BigInteger.valueOf((long) getSecond()));
        BigDecimal subtract2 = subtract.subtract(bigDecimal5);
        if (subtract2.compareTo(DECIMAL_ZERO) < 0) {
            setFractionalSecond(DECIMAL_ONE.add(subtract2));
            if (getSecond() == 0) {
                setSecond(59);
                bigInteger2 = bigInteger2.subtract(BigInteger.ONE);
            } else {
                setSecond(getSecond() - 1);
            }
        } else {
            setFractionalSecond(subtract2);
        }
        int minute2 = getMinute();
        if (minute2 == Integer.MIN_VALUE) {
            zArr[4] = true;
            minute2 = MIN_FIELD_VALUE[4];
        }
        BigInteger add3 = BigInteger.valueOf((long) minute2).add(sanitize(duration2.getField(DatatypeConstants.MINUTES), sign)).add(bigInteger2);
        setMinute(add3.mod(SIXTY).intValue());
        new BigDecimal(add3);
        BigInteger bigInteger3 = bigDecimal6.divide(DECIMAL_SIXTY, 3).toBigInteger();
        int hour2 = getHour();
        if (hour2 == Integer.MIN_VALUE) {
            zArr[3] = true;
            hour2 = MIN_FIELD_VALUE[3];
        }
        BigInteger add4 = BigInteger.valueOf((long) hour2).add(sanitize(duration2.getField(DatatypeConstants.HOURS), sign)).add(bigInteger3);
        setHour(add4.mod(TWENTY_FOUR).intValue());
        new BigDecimal(add4);
        new BigDecimal(TWENTY_FOUR);
        BigInteger bigInteger4 = bigDecimal7.divide(bigDecimal8, 3).toBigInteger();
        int day2 = getDay();
        if (day2 == Integer.MIN_VALUE) {
            zArr[2] = true;
            day2 = MIN_FIELD_VALUE[2];
        }
        BigInteger sanitize = sanitize(duration2.getField(DatatypeConstants.DAYS), sign);
        int maximumDayInMonthFor = maximumDayInMonthFor(getEonAndYear(), getMonth());
        BigInteger add5 = (day2 > maximumDayInMonthFor ? BigInteger.valueOf((long) maximumDayInMonthFor) : day2 < 1 ? BigInteger.ONE : BigInteger.valueOf((long) day2)).add(sanitize).add(bigInteger4);
        while (true) {
            if (add5.compareTo(BigInteger.ONE) >= 0) {
                if (add5.compareTo(BigInteger.valueOf((long) maximumDayInMonthFor(getEonAndYear(), getMonth()))) <= 0) {
                    break;
                }
                add5 = add5.add(BigInteger.valueOf((long) (-maximumDayInMonthFor(getEonAndYear(), getMonth()))));
                i = 1;
            } else {
                add5 = add5.add(this.month >= 2 ? BigInteger.valueOf((long) maximumDayInMonthFor(getEonAndYear(), getMonth() - 1)) : BigInteger.valueOf((long) maximumDayInMonthFor(getEonAndYear().subtract(BigInteger.valueOf(1)), 12)));
                i = -1;
            }
            int month3 = getMonth() + i;
            int i4 = (month3 - 1) % 12;
            if (i4 < 0) {
                i3 = 12 + i4 + 1;
                new BigDecimal(TWELVE);
                i2 = BigDecimal.valueOf((long) (month3 - 1)).divide(bigDecimal9, 0).intValue();
            } else {
                i2 = (month3 - 1) / 12;
                i3 = i4 + 1;
            }
            setMonth(i3);
            if (i2 != 0) {
                setYear(getEonAndYear().add(BigInteger.valueOf((long) i2)));
            }
        }
        setDay(add5.intValue());
        for (int i5 = 0; i5 <= 5; i5++) {
            if (zArr[i5]) {
                switch (i5) {
                    case 0:
                        setYear((int) Target.SIZE_ORIGINAL);
                        break;
                    case 1:
                        setMonth(Target.SIZE_ORIGINAL);
                        break;
                    case 2:
                        setDay(Target.SIZE_ORIGINAL);
                        break;
                    case 3:
                        setHour(Target.SIZE_ORIGINAL);
                        break;
                    case 4:
                        setMinute(Target.SIZE_ORIGINAL);
                        break;
                    case 5:
                        setSecond(Target.SIZE_ORIGINAL);
                        setFractionalSecond((BigDecimal) null);
                        break;
                }
            }
        }
    }

    public void clear() {
        this.eon = null;
        this.year = Target.SIZE_ORIGINAL;
        this.month = Target.SIZE_ORIGINAL;
        this.day = Target.SIZE_ORIGINAL;
        this.timezone = Target.SIZE_ORIGINAL;
        this.hour = Target.SIZE_ORIGINAL;
        this.minute = Target.SIZE_ORIGINAL;
        this.second = Target.SIZE_ORIGINAL;
        this.fractionalSecond = null;
    }

    public Object clone() {
        Object obj;
        new XMLGregorianCalendarImpl(getEonAndYear(), this.month, this.day, this.hour, this.minute, this.second, this.fractionalSecond, this.timezone);
        return obj;
    }

    public int compare(XMLGregorianCalendar xMLGregorianCalendar) {
        XMLGregorianCalendarImpl xMLGregorianCalendarImpl = this;
        XMLGregorianCalendarImpl xMLGregorianCalendarImpl2 = xMLGregorianCalendar;
        if (xMLGregorianCalendarImpl.getTimezone() == xMLGregorianCalendarImpl2.getTimezone()) {
            return internalCompare(xMLGregorianCalendarImpl, xMLGregorianCalendarImpl2);
        }
        if (xMLGregorianCalendarImpl.getTimezone() != Integer.MIN_VALUE && xMLGregorianCalendarImpl2.getTimezone() != Integer.MIN_VALUE) {
            return internalCompare((XMLGregorianCalendarImpl) xMLGregorianCalendarImpl.normalize(), (XMLGregorianCalendarImpl) xMLGregorianCalendarImpl2.normalize());
        } else if (xMLGregorianCalendarImpl.getTimezone() != Integer.MIN_VALUE) {
            if (xMLGregorianCalendarImpl.getTimezone() != 0) {
                xMLGregorianCalendarImpl = (XMLGregorianCalendarImpl) xMLGregorianCalendarImpl.normalize();
            }
            int internalCompare = internalCompare(xMLGregorianCalendarImpl, normalizeToTimezone(xMLGregorianCalendarImpl2, 840));
            if (internalCompare == -1) {
                return internalCompare;
            }
            int internalCompare2 = internalCompare(xMLGregorianCalendarImpl, normalizeToTimezone(xMLGregorianCalendarImpl2, -840));
            if (internalCompare2 == 1) {
                return internalCompare2;
            }
            return 2;
        } else {
            if (xMLGregorianCalendarImpl2.getTimezone() != 0) {
                xMLGregorianCalendarImpl2 = (XMLGregorianCalendarImpl) normalizeToTimezone(xMLGregorianCalendarImpl2, xMLGregorianCalendarImpl2.getTimezone());
            }
            int internalCompare3 = internalCompare(normalizeToTimezone(xMLGregorianCalendarImpl, -840), xMLGregorianCalendarImpl2);
            if (internalCompare3 == -1) {
                return internalCompare3;
            }
            int internalCompare4 = internalCompare(normalizeToTimezone(xMLGregorianCalendarImpl, 840), xMLGregorianCalendarImpl2);
            if (internalCompare4 == 1) {
                return internalCompare4;
            }
            return 2;
        }
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [java.lang.Object] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean equals(java.lang.Object r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r1
            r3 = r0
            if (r2 != r3) goto L_0x0009
            r2 = 1
            r0 = r2
        L_0x0008:
            return r0
        L_0x0009:
            r2 = r1
            boolean r2 = r2 instanceof javax.xml.datatype.XMLGregorianCalendar
            if (r2 == 0) goto L_0x001d
            r2 = r0
            r3 = r1
            javax.xml.datatype.XMLGregorianCalendar r3 = (javax.xml.datatype.XMLGregorianCalendar) r3
            int r2 = r2.compare(r3)
            if (r2 != 0) goto L_0x001b
            r2 = 1
        L_0x0019:
            r0 = r2
            goto L_0x0008
        L_0x001b:
            r2 = 0
            goto L_0x0019
        L_0x001d:
            r2 = 0
            r0 = r2
            goto L_0x0008
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.jaxp.datatype.XMLGregorianCalendarImpl.equals(java.lang.Object):boolean");
    }

    public int getDay() {
        return this.day;
    }

    public BigInteger getEon() {
        return this.eon;
    }

    public BigInteger getEonAndYear() {
        if (this.year != Integer.MIN_VALUE && this.eon != null) {
            return this.eon.add(BigInteger.valueOf((long) this.year));
        }
        if (this.year == Integer.MIN_VALUE || this.eon != null) {
            return null;
        }
        return BigInteger.valueOf((long) this.year);
    }

    public BigDecimal getFractionalSecond() {
        return this.fractionalSecond;
    }

    public int getHour() {
        return this.hour;
    }

    public int getMillisecond() {
        return this.fractionalSecond == null ? Target.SIZE_ORIGINAL : this.fractionalSecond.movePointRight(3).intValue();
    }

    public int getMinute() {
        return this.minute;
    }

    public int getMonth() {
        return this.month;
    }

    public int getSecond() {
        return this.second;
    }

    public TimeZone getTimeZone(int i) {
        StringBuffer stringBuffer;
        TimeZone timeZone;
        int i2 = i;
        int timezone2 = getTimezone();
        if (timezone2 == Integer.MIN_VALUE) {
            timezone2 = i2;
        }
        if (timezone2 == Integer.MIN_VALUE) {
            timeZone = TimeZone.getDefault();
        } else {
            char c = timezone2 < 0 ? '-' : '+';
            if (c == '-') {
                timezone2 = -timezone2;
            }
            int i3 = timezone2 / 60;
            int i4 = timezone2 - (i3 * 60);
            new StringBuffer(8);
            StringBuffer stringBuffer2 = stringBuffer;
            StringBuffer append = stringBuffer2.append("GMT");
            StringBuffer append2 = stringBuffer2.append(c);
            StringBuffer append3 = stringBuffer2.append(i3);
            if (i4 != 0) {
                if (i4 < 10) {
                    StringBuffer append4 = stringBuffer2.append('0');
                }
                StringBuffer append5 = stringBuffer2.append(i4);
            }
            timeZone = TimeZone.getTimeZone(stringBuffer2.toString());
        }
        return timeZone;
    }

    public int getTimezone() {
        return this.timezone;
    }

    public QName getXMLSchemaType() {
        Throwable th;
        StringBuffer stringBuffer;
        if (this.year != Integer.MIN_VALUE && this.month != Integer.MIN_VALUE && this.day != Integer.MIN_VALUE && this.hour != Integer.MIN_VALUE && this.minute != Integer.MIN_VALUE && this.second != Integer.MIN_VALUE) {
            return DatatypeConstants.DATETIME;
        }
        if (this.year != Integer.MIN_VALUE && this.month != Integer.MIN_VALUE && this.day != Integer.MIN_VALUE && this.hour == Integer.MIN_VALUE && this.minute == Integer.MIN_VALUE && this.second == Integer.MIN_VALUE) {
            return DatatypeConstants.DATE;
        }
        if (this.year == Integer.MIN_VALUE && this.month == Integer.MIN_VALUE && this.day == Integer.MIN_VALUE && this.hour != Integer.MIN_VALUE && this.minute != Integer.MIN_VALUE && this.second != Integer.MIN_VALUE) {
            return DatatypeConstants.TIME;
        }
        if (this.year != Integer.MIN_VALUE && this.month != Integer.MIN_VALUE && this.day == Integer.MIN_VALUE && this.hour == Integer.MIN_VALUE && this.minute == Integer.MIN_VALUE && this.second == Integer.MIN_VALUE) {
            return DatatypeConstants.GYEARMONTH;
        }
        if (this.year == Integer.MIN_VALUE && this.month != Integer.MIN_VALUE && this.day != Integer.MIN_VALUE && this.hour == Integer.MIN_VALUE && this.minute == Integer.MIN_VALUE && this.second == Integer.MIN_VALUE) {
            return DatatypeConstants.GMONTHDAY;
        }
        if (this.year != Integer.MIN_VALUE && this.month == Integer.MIN_VALUE && this.day == Integer.MIN_VALUE && this.hour == Integer.MIN_VALUE && this.minute == Integer.MIN_VALUE && this.second == Integer.MIN_VALUE) {
            return DatatypeConstants.GYEAR;
        }
        if (this.year == Integer.MIN_VALUE && this.month != Integer.MIN_VALUE && this.day == Integer.MIN_VALUE && this.hour == Integer.MIN_VALUE && this.minute == Integer.MIN_VALUE && this.second == Integer.MIN_VALUE) {
            return DatatypeConstants.GMONTH;
        }
        if (this.year == Integer.MIN_VALUE && this.month == Integer.MIN_VALUE && this.day != Integer.MIN_VALUE && this.hour == Integer.MIN_VALUE && this.minute == Integer.MIN_VALUE && this.second == Integer.MIN_VALUE) {
            return DatatypeConstants.GDAY;
        }
        Throwable th2 = th;
        new StringBuffer();
        new IllegalStateException(stringBuffer.append(getClass().getName()).append("#getXMLSchemaType() :").append(DatatypeMessageFormatter.formatMessage((Locale) null, "InvalidXGCFields", (Object[]) null)).toString());
        throw th2;
    }

    public int getYear() {
        return this.year;
    }

    public int hashCode() {
        int timezone2 = getTimezone();
        if (timezone2 == Integer.MIN_VALUE) {
            timezone2 = 0;
        }
        XMLGregorianCalendar xMLGregorianCalendar = this;
        if (timezone2 != 0) {
            xMLGregorianCalendar = normalizeToTimezone(this, getTimezone());
        }
        return xMLGregorianCalendar.getYear() + xMLGregorianCalendar.getMonth() + xMLGregorianCalendar.getDay() + xMLGregorianCalendar.getHour() + xMLGregorianCalendar.getMinute() + xMLGregorianCalendar.getSecond();
    }

    public boolean isValid() {
        if (!(this.month == Integer.MIN_VALUE || this.day == Integer.MIN_VALUE)) {
            if (this.year != Integer.MIN_VALUE) {
                if (this.eon == null) {
                    if (this.day > maximumDayInMonthFor(this.year, this.month)) {
                        return false;
                    }
                } else if (this.day > maximumDayInMonthFor(getEonAndYear(), this.month)) {
                    return false;
                }
            } else if (this.day > maximumDayInMonthFor(2000, this.month)) {
                return false;
            }
        }
        if (this.hour != 24 || (this.minute == 0 && this.second == 0 && (this.fractionalSecond == null || this.fractionalSecond.compareTo(DECIMAL_ZERO) == 0))) {
            return (this.eon == null && this.year == 0) ? false : true;
        }
        return false;
    }

    public XMLGregorianCalendar normalize() {
        XMLGregorianCalendar normalizeToTimezone = normalizeToTimezone(this, this.timezone);
        if (getTimezone() == Integer.MIN_VALUE) {
            normalizeToTimezone.setTimezone(Target.SIZE_ORIGINAL);
        }
        if (getMillisecond() == Integer.MIN_VALUE) {
            normalizeToTimezone.setMillisecond(Target.SIZE_ORIGINAL);
        }
        return normalizeToTimezone;
    }

    public void reset() {
        this.eon = this.orig_eon;
        this.year = this.orig_year;
        this.month = this.orig_month;
        this.day = this.orig_day;
        this.hour = this.orig_hour;
        this.minute = this.orig_minute;
        this.second = this.orig_second;
        this.fractionalSecond = this.orig_fracSeconds;
        this.timezone = this.orig_timezone;
    }

    public void setDay(int i) {
        int i2 = i;
        checkFieldValueConstraint(2, i2);
        this.day = i2;
    }

    public void setFractionalSecond(BigDecimal bigDecimal) {
        Throwable th;
        BigDecimal bigDecimal2 = bigDecimal;
        if (bigDecimal2 == null || (bigDecimal2.compareTo(DECIMAL_ZERO) >= 0 && bigDecimal2.compareTo(DECIMAL_ONE) <= 0)) {
            this.fractionalSecond = bigDecimal2;
            return;
        }
        Throwable th2 = th;
        new IllegalArgumentException(DatatypeMessageFormatter.formatMessage((Locale) null, "InvalidFractional", new Object[]{bigDecimal2}));
        throw th2;
    }

    public void setHour(int i) {
        int i2 = i;
        checkFieldValueConstraint(3, i2);
        this.hour = i2;
    }

    public void setMillisecond(int i) {
        int i2 = i;
        if (i2 == Integer.MIN_VALUE) {
            this.fractionalSecond = null;
            return;
        }
        checkFieldValueConstraint(6, i2);
        this.fractionalSecond = BigDecimal.valueOf((long) i2, 3);
    }

    public void setMinute(int i) {
        int i2 = i;
        checkFieldValueConstraint(4, i2);
        this.minute = i2;
    }

    public void setMonth(int i) {
        int i2 = i;
        checkFieldValueConstraint(1, i2);
        this.month = i2;
    }

    public void setSecond(int i) {
        int i2 = i;
        checkFieldValueConstraint(5, i2);
        this.second = i2;
    }

    public void setTime(int i, int i2, int i3) {
        setTime(i, i2, i3, (BigDecimal) null);
    }

    public void setTime(int i, int i2, int i3, int i4) {
        setHour(i);
        setMinute(i2);
        setSecond(i3);
        setMillisecond(i4);
    }

    public void setTime(int i, int i2, int i3, BigDecimal bigDecimal) {
        setHour(i);
        setMinute(i2);
        setSecond(i3);
        setFractionalSecond(bigDecimal);
    }

    public void setTimezone(int i) {
        int i2 = i;
        checkFieldValueConstraint(7, i2);
        this.timezone = i2;
    }

    public void setYear(int i) {
        int i2 = i;
        if (i2 == Integer.MIN_VALUE) {
            this.year = Target.SIZE_ORIGINAL;
            this.eon = null;
        } else if (Math.abs(i2) < 1000000000) {
            this.year = i2;
            this.eon = null;
        } else {
            BigInteger valueOf = BigInteger.valueOf((long) i2);
            BigInteger remainder = valueOf.remainder(BILLION_B);
            this.year = remainder.intValue();
            setEon(valueOf.subtract(remainder));
        }
    }

    public void setYear(BigInteger bigInteger) {
        BigInteger bigInteger2 = bigInteger;
        if (bigInteger2 == null) {
            this.eon = null;
            this.year = Target.SIZE_ORIGINAL;
            return;
        }
        BigInteger remainder = bigInteger2.remainder(BILLION_B);
        this.year = remainder.intValue();
        setEon(bigInteger2.subtract(remainder));
    }

    public GregorianCalendar toGregorianCalendar() {
        GregorianCalendar gregorianCalendar;
        new GregorianCalendar(getTimeZone(Target.SIZE_ORIGINAL), Locale.getDefault());
        GregorianCalendar gregorianCalendar2 = gregorianCalendar;
        gregorianCalendar2.clear();
        gregorianCalendar2.setGregorianChange(PURE_GREGORIAN_CHANGE);
        if (this.year != Integer.MIN_VALUE) {
            if (this.eon == null) {
                gregorianCalendar2.set(0, this.year < 0 ? 0 : 1);
                gregorianCalendar2.set(1, Math.abs(this.year));
            } else {
                BigInteger eonAndYear = getEonAndYear();
                gregorianCalendar2.set(0, eonAndYear.signum() == -1 ? 0 : 1);
                gregorianCalendar2.set(1, eonAndYear.abs().intValue());
            }
        }
        if (this.month != Integer.MIN_VALUE) {
            gregorianCalendar2.set(2, this.month - 1);
        }
        if (this.day != Integer.MIN_VALUE) {
            gregorianCalendar2.set(5, this.day);
        }
        if (this.hour != Integer.MIN_VALUE) {
            gregorianCalendar2.set(11, this.hour);
        }
        if (this.minute != Integer.MIN_VALUE) {
            gregorianCalendar2.set(12, this.minute);
        }
        if (this.second != Integer.MIN_VALUE) {
            gregorianCalendar2.set(13, this.second);
        }
        if (this.fractionalSecond != null) {
            gregorianCalendar2.set(14, getMillisecond());
        }
        return gregorianCalendar2;
    }

    public GregorianCalendar toGregorianCalendar(TimeZone timeZone, Locale locale, XMLGregorianCalendar xMLGregorianCalendar) {
        GregorianCalendar gregorianCalendar;
        int year2;
        Locale locale2 = locale;
        XMLGregorianCalendar xMLGregorianCalendar2 = xMLGregorianCalendar;
        TimeZone timeZone2 = timeZone;
        if (timeZone2 == null) {
            int i = Integer.MIN_VALUE;
            if (xMLGregorianCalendar2 != null) {
                i = xMLGregorianCalendar2.getTimezone();
            }
            timeZone2 = getTimeZone(i);
        }
        if (locale2 == null) {
            locale2 = Locale.getDefault();
        }
        new GregorianCalendar(timeZone2, locale2);
        GregorianCalendar gregorianCalendar2 = gregorianCalendar;
        gregorianCalendar2.clear();
        gregorianCalendar2.setGregorianChange(PURE_GREGORIAN_CHANGE);
        if (this.year != Integer.MIN_VALUE) {
            if (this.eon == null) {
                gregorianCalendar2.set(0, this.year < 0 ? 0 : 1);
                gregorianCalendar2.set(1, Math.abs(this.year));
            } else {
                BigInteger eonAndYear = getEonAndYear();
                gregorianCalendar2.set(0, eonAndYear.signum() == -1 ? 0 : 1);
                gregorianCalendar2.set(1, eonAndYear.abs().intValue());
            }
        } else if (!(xMLGregorianCalendar2 == null || (year2 = xMLGregorianCalendar2.getYear()) == Integer.MIN_VALUE)) {
            if (xMLGregorianCalendar2.getEon() == null) {
                gregorianCalendar2.set(0, year2 < 0 ? 0 : 1);
                gregorianCalendar2.set(1, Math.abs(year2));
            } else {
                BigInteger eonAndYear2 = xMLGregorianCalendar2.getEonAndYear();
                gregorianCalendar2.set(0, eonAndYear2.signum() == -1 ? 0 : 1);
                gregorianCalendar2.set(1, eonAndYear2.abs().intValue());
            }
        }
        if (this.month != Integer.MIN_VALUE) {
            gregorianCalendar2.set(2, this.month - 1);
        } else {
            int month2 = xMLGregorianCalendar2 != null ? xMLGregorianCalendar2.getMonth() : Target.SIZE_ORIGINAL;
            if (month2 != Integer.MIN_VALUE) {
                gregorianCalendar2.set(2, month2 - 1);
            }
        }
        if (this.day != Integer.MIN_VALUE) {
            gregorianCalendar2.set(5, this.day);
        } else {
            int day2 = xMLGregorianCalendar2 != null ? xMLGregorianCalendar2.getDay() : Target.SIZE_ORIGINAL;
            if (day2 != Integer.MIN_VALUE) {
                gregorianCalendar2.set(5, day2);
            }
        }
        if (this.hour != Integer.MIN_VALUE) {
            gregorianCalendar2.set(11, this.hour);
        } else {
            int hour2 = xMLGregorianCalendar2 != null ? xMLGregorianCalendar2.getHour() : Target.SIZE_ORIGINAL;
            if (hour2 != Integer.MIN_VALUE) {
                gregorianCalendar2.set(11, hour2);
            }
        }
        if (this.minute != Integer.MIN_VALUE) {
            gregorianCalendar2.set(12, this.minute);
        } else {
            int minute2 = xMLGregorianCalendar2 != null ? xMLGregorianCalendar2.getMinute() : Target.SIZE_ORIGINAL;
            if (minute2 != Integer.MIN_VALUE) {
                gregorianCalendar2.set(12, minute2);
            }
        }
        if (this.second != Integer.MIN_VALUE) {
            gregorianCalendar2.set(13, this.second);
        } else {
            int second2 = xMLGregorianCalendar2 != null ? xMLGregorianCalendar2.getSecond() : Target.SIZE_ORIGINAL;
            if (second2 != Integer.MIN_VALUE) {
                gregorianCalendar2.set(13, second2);
            }
        }
        if (this.fractionalSecond != null) {
            gregorianCalendar2.set(14, getMillisecond());
        } else {
            if ((xMLGregorianCalendar2 != null ? xMLGregorianCalendar2.getFractionalSecond() : null) != null) {
                gregorianCalendar2.set(14, xMLGregorianCalendar2.getMillisecond());
            }
        }
        return gregorianCalendar2;
    }

    public String toXMLFormat() {
        QName xMLSchemaType = getXMLSchemaType();
        String str = null;
        if (xMLSchemaType == DatatypeConstants.DATETIME) {
            str = "%Y-%M-%DT%h:%m:%s%z";
        } else if (xMLSchemaType == DatatypeConstants.DATE) {
            str = "%Y-%M-%D%z";
        } else if (xMLSchemaType == DatatypeConstants.TIME) {
            str = "%h:%m:%s%z";
        } else if (xMLSchemaType == DatatypeConstants.GMONTH) {
            str = "--%M--%z";
        } else if (xMLSchemaType == DatatypeConstants.GDAY) {
            str = "---%D%z";
        } else if (xMLSchemaType == DatatypeConstants.GYEAR) {
            str = "%Y%z";
        } else if (xMLSchemaType == DatatypeConstants.GYEARMONTH) {
            str = "%Y-%M%z";
        } else if (xMLSchemaType == DatatypeConstants.GMONTHDAY) {
            str = "--%M-%D%z";
        }
        return format(str);
    }
}
