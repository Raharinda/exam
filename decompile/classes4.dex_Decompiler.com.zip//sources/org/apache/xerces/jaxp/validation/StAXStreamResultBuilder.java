package org.apache.xerces.jaxp.validation;

import com.kodular.fabextension.BuildConfig;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.Comment;
import javax.xml.stream.events.DTD;
import javax.xml.stream.events.EndDocument;
import javax.xml.stream.events.EntityReference;
import javax.xml.stream.events.ProcessingInstruction;
import javax.xml.stream.events.StartDocument;
import javax.xml.transform.stax.StAXResult;
import org.apache.xerces.util.JAXPNamespaceContextWrapper;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLDocumentSource;

final class StAXStreamResultBuilder implements StAXDocumentHandler {
    private final QName fAttrName;
    private boolean fIgnoreChars;
    private boolean fInCDATA;
    private final JAXPNamespaceContextWrapper fNamespaceContext;
    private XMLStreamWriter fStreamWriter;

    public StAXStreamResultBuilder(JAXPNamespaceContextWrapper jAXPNamespaceContextWrapper) {
        QName qName;
        new QName();
        this.fAttrName = qName;
        this.fNamespaceContext = jAXPNamespaceContextWrapper;
    }

    public void cdata(Characters characters) throws XMLStreamException {
        this.fStreamWriter.writeCData(characters.getData());
    }

    public void characters(Characters characters) throws XMLStreamException {
        this.fStreamWriter.writeCharacters(characters.getData());
    }

    public void characters(XMLString xMLString, Augmentations augmentations) throws XNIException {
        Throwable th;
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (!this.fIgnoreChars) {
            try {
                if (!this.fInCDATA) {
                    this.fStreamWriter.writeCharacters(xMLString2.ch, xMLString2.offset, xMLString2.length);
                } else {
                    this.fStreamWriter.writeCData(xMLString2.toString());
                }
            } catch (XMLStreamException e) {
                Exception exc = e;
                Throwable th2 = th;
                new XNIException(exc);
                throw th2;
            }
        }
    }

    public void comment(XMLStreamReader xMLStreamReader) throws XMLStreamException {
        this.fStreamWriter.writeComment(xMLStreamReader.getText());
    }

    public void comment(Comment comment) throws XMLStreamException {
        this.fStreamWriter.writeComment(comment.getText());
    }

    public void comment(XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void doctypeDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
    }

    public void doctypeDecl(DTD dtd) throws XMLStreamException {
        this.fStreamWriter.writeDTD(dtd.getDocumentTypeDeclaration());
    }

    public void emptyElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        startElement(qName2, xMLAttributes, augmentations2);
        endElement(qName2, augmentations2);
    }

    public void endCDATA(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        this.fInCDATA = false;
    }

    public void endDocument(XMLStreamReader xMLStreamReader) throws XMLStreamException {
        XMLStreamReader xMLStreamReader2 = xMLStreamReader;
        this.fStreamWriter.writeEndDocument();
        this.fStreamWriter.flush();
    }

    public void endDocument(EndDocument endDocument) throws XMLStreamException {
        EndDocument endDocument2 = endDocument;
        this.fStreamWriter.writeEndDocument();
        this.fStreamWriter.flush();
    }

    public void endDocument(Augmentations augmentations) throws XNIException {
    }

    public void endElement(QName qName, Augmentations augmentations) throws XNIException {
        Throwable th;
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        try {
            this.fStreamWriter.writeEndElement();
        } catch (XMLStreamException e) {
            Exception exc = e;
            Throwable th2 = th;
            new XNIException(exc);
            throw th2;
        }
    }

    public void endGeneralEntity(String str, Augmentations augmentations) throws XNIException {
    }

    public void entityReference(XMLStreamReader xMLStreamReader) throws XMLStreamException {
        this.fStreamWriter.writeEntityRef(xMLStreamReader.getLocalName());
    }

    public void entityReference(EntityReference entityReference) throws XMLStreamException {
        this.fStreamWriter.writeEntityRef(entityReference.getName());
    }

    public XMLDocumentSource getDocumentSource() {
        return null;
    }

    public void ignorableWhitespace(XMLString xMLString, Augmentations augmentations) throws XNIException {
        characters(xMLString, augmentations);
    }

    public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void processingInstruction(XMLStreamReader xMLStreamReader) throws XMLStreamException {
        XMLStreamReader xMLStreamReader2 = xMLStreamReader;
        String pIData = xMLStreamReader2.getPIData();
        if (pIData == null || pIData.length() <= 0) {
            this.fStreamWriter.writeProcessingInstruction(xMLStreamReader2.getPITarget());
        } else {
            this.fStreamWriter.writeProcessingInstruction(xMLStreamReader2.getPITarget(), pIData);
        }
    }

    public void processingInstruction(ProcessingInstruction processingInstruction) throws XMLStreamException {
        ProcessingInstruction processingInstruction2 = processingInstruction;
        String data = processingInstruction2.getData();
        if (data == null || data.length() <= 0) {
            this.fStreamWriter.writeProcessingInstruction(processingInstruction2.getTarget());
        } else {
            this.fStreamWriter.writeProcessingInstruction(processingInstruction2.getTarget(), data);
        }
    }

    public void setDocumentSource(XMLDocumentSource xMLDocumentSource) {
    }

    public void setIgnoringCharacters(boolean z) {
        boolean z2 = z;
        this.fIgnoreChars = z2;
    }

    public void setStAXResult(StAXResult stAXResult) {
        StAXResult stAXResult2 = stAXResult;
        this.fIgnoreChars = false;
        this.fInCDATA = false;
        this.fAttrName.clear();
        this.fStreamWriter = stAXResult2 != null ? stAXResult2.getXMLStreamWriter() : null;
    }

    public void startCDATA(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        this.fInCDATA = true;
    }

    public void startDocument(XMLStreamReader xMLStreamReader) throws XMLStreamException {
        XMLStreamReader xMLStreamReader2 = xMLStreamReader;
        String version = xMLStreamReader2.getVersion();
        String characterEncodingScheme = xMLStreamReader2.getCharacterEncodingScheme();
        this.fStreamWriter.writeStartDocument(characterEncodingScheme != null ? characterEncodingScheme : "UTF-8", version != null ? version : BuildConfig.VERSION_NAME);
    }

    public void startDocument(StartDocument startDocument) throws XMLStreamException {
        StartDocument startDocument2 = startDocument;
        String version = startDocument2.getVersion();
        String characterEncodingScheme = startDocument2.getCharacterEncodingScheme();
        this.fStreamWriter.writeStartDocument(characterEncodingScheme != null ? characterEncodingScheme : "UTF-8", version != null ? version : BuildConfig.VERSION_NAME);
    }

    public void startDocument(XMLLocator xMLLocator, String str, NamespaceContext namespaceContext, Augmentations augmentations) throws XNIException {
    }

    public void startElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        Throwable th;
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        try {
            if (qName2.prefix.length() > 0) {
                this.fStreamWriter.writeStartElement(qName2.prefix, qName2.localpart, qName2.uri != null ? qName2.uri : "");
            } else if (qName2.uri != null) {
                this.fStreamWriter.writeStartElement(qName2.uri, qName2.localpart);
            } else {
                this.fStreamWriter.writeStartElement(qName2.localpart);
            }
            int declaredPrefixCount = this.fNamespaceContext.getDeclaredPrefixCount();
            javax.xml.namespace.NamespaceContext namespaceContext = this.fNamespaceContext.getNamespaceContext();
            for (int i = 0; i < declaredPrefixCount; i++) {
                String declaredPrefixAt = this.fNamespaceContext.getDeclaredPrefixAt(i);
                String namespaceURI = namespaceContext.getNamespaceURI(declaredPrefixAt);
                if (declaredPrefixAt.length() == 0) {
                    this.fStreamWriter.writeDefaultNamespace(namespaceURI != null ? namespaceURI : "");
                } else {
                    this.fStreamWriter.writeNamespace(declaredPrefixAt, namespaceURI != null ? namespaceURI : "");
                }
            }
            int length = xMLAttributes2.getLength();
            for (int i2 = 0; i2 < length; i2++) {
                xMLAttributes2.getName(i2, this.fAttrName);
                if (this.fAttrName.prefix.length() > 0) {
                    this.fStreamWriter.writeAttribute(this.fAttrName.prefix, this.fAttrName.uri != null ? this.fAttrName.uri : "", this.fAttrName.localpart, xMLAttributes2.getValue(i2));
                } else if (this.fAttrName.uri != null) {
                    this.fStreamWriter.writeAttribute(this.fAttrName.uri, this.fAttrName.localpart, xMLAttributes2.getValue(i2));
                } else {
                    this.fStreamWriter.writeAttribute(this.fAttrName.localpart, xMLAttributes2.getValue(i2));
                }
            }
        } catch (XMLStreamException e) {
            Exception exc = e;
            Throwable th2 = th;
            new XNIException(exc);
            throw th2;
        }
    }

    public void startGeneralEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
    }

    public void textDecl(String str, String str2, Augmentations augmentations) throws XNIException {
    }

    public void xmlDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
    }
}
