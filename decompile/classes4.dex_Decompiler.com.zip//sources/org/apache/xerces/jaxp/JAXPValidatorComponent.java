package org.apache.xerces.jaxp;

import java.io.IOException;
import javax.xml.validation.TypeInfoProvider;
import javax.xml.validation.ValidatorHandler;
import org.apache.xerces.dom.DOMInputImpl;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.impl.xs.opti.DefaultXMLDocumentHandler;
import org.apache.xerces.util.AttributesProxy;
import org.apache.xerces.util.AugmentationsImpl;
import org.apache.xerces.util.ErrorHandlerProxy;
import org.apache.xerces.util.ErrorHandlerWrapper;
import org.apache.xerces.util.LocatorProxy;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.util.XMLResourceIdentifierImpl;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLComponent;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.w3c.dom.TypeInfo;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSResourceResolver;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.ErrorHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

final class JAXPValidatorComponent extends TeeXMLDocumentFilterImpl implements XMLComponent {
    private static final String ENTITY_MANAGER = "http://apache.org/xml/properties/internal/entity-manager";
    private static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
    private static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    private static final TypeInfoProvider noInfoProvider;
    private XMLAttributes fCurrentAttributes;
    private Augmentations fCurrentAug;
    private XMLEntityResolver fEntityResolver;
    private XMLErrorReporter fErrorReporter;
    private SymbolTable fSymbolTable;
    private final SAX2XNI sax2xni;
    private final TypeInfoProvider typeInfoProvider;
    private final ValidatorHandler validator;
    private final XNI2SAX xni2sax;

    private static final class DraconianErrorHandler implements ErrorHandler {
        private static final DraconianErrorHandler ERROR_HANDLER_INSTANCE;

        static {
            DraconianErrorHandler draconianErrorHandler;
            new DraconianErrorHandler();
            ERROR_HANDLER_INSTANCE = draconianErrorHandler;
        }

        private DraconianErrorHandler() {
        }

        public static DraconianErrorHandler getInstance() {
            return ERROR_HANDLER_INSTANCE;
        }

        public void error(SAXParseException sAXParseException) throws SAXException {
            throw sAXParseException;
        }

        public void fatalError(SAXParseException sAXParseException) throws SAXException {
            throw sAXParseException;
        }

        public void warning(SAXParseException sAXParseException) throws SAXException {
        }
    }

    private final class SAX2XNI extends DefaultHandler {
        private final Augmentations fAugmentations;
        private final QName fQName;
        private final JAXPValidatorComponent this$0;

        private SAX2XNI(JAXPValidatorComponent jAXPValidatorComponent) {
            Augmentations augmentations;
            QName qName;
            this.this$0 = jAXPValidatorComponent;
            new AugmentationsImpl();
            this.fAugmentations = augmentations;
            new QName();
            this.fQName = qName;
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        SAX2XNI(JAXPValidatorComponent jAXPValidatorComponent, AnonymousClass1 r7) {
            this(jAXPValidatorComponent);
            AnonymousClass1 r2 = r7;
        }

        private Augmentations aug() {
            if (JAXPValidatorComponent.access$600(this.this$0) != null) {
                Augmentations access$600 = JAXPValidatorComponent.access$600(this.this$0);
                Augmentations access$602 = JAXPValidatorComponent.access$602(this.this$0, (Augmentations) null);
                return access$600;
            }
            this.fAugmentations.removeAllItems();
            return this.fAugmentations;
        }

        private Augmentations elementAug() {
            return aug();
        }

        private XMLDocumentHandler handler() {
            return this.this$0.getDocumentHandler();
        }

        private QName toQName(String str, String str2, String str3) {
            String str4 = str;
            String str5 = str2;
            String str6 = str3;
            String str7 = null;
            int indexOf = str6.indexOf(58);
            if (indexOf > 0) {
                str7 = JAXPValidatorComponent.access$700(this.this$0, str6.substring(0, indexOf));
            }
            this.fQName.setValues(str7, JAXPValidatorComponent.access$700(this.this$0, str5), JAXPValidatorComponent.access$700(this.this$0, str6), JAXPValidatorComponent.access$700(this.this$0, str4));
            return this.fQName;
        }

        private SAXException toSAXException(XNIException xNIException) {
            SAXException sAXException;
            Exception exc = xNIException;
            Exception exception = exc.getException();
            if (exception == null) {
                exception = exc;
            }
            if (exception instanceof SAXException) {
                return (SAXException) exception;
            }
            new SAXException(exception);
            return sAXException;
        }

        public void characters(char[] cArr, int i, int i2) throws SAXException {
            XMLString xMLString;
            try {
                new XMLString(cArr, i, i2);
                handler().characters(xMLString, aug());
            } catch (XNIException e) {
                throw toSAXException(e);
            }
        }

        public void endElement(String str, String str2, String str3) throws SAXException {
            try {
                handler().endElement(toQName(str, str2, str3), aug());
            } catch (XNIException e) {
                throw toSAXException(e);
            }
        }

        public void ignorableWhitespace(char[] cArr, int i, int i2) throws SAXException {
            XMLString xMLString;
            try {
                new XMLString(cArr, i, i2);
                handler().ignorableWhitespace(xMLString, aug());
            } catch (XNIException e) {
                throw toSAXException(e);
            }
        }

        public void startElement(String str, String str2, String str3, Attributes attributes) throws SAXException {
            String str4 = str;
            String str5 = str2;
            String str6 = str3;
            try {
                JAXPValidatorComponent.access$400(this.this$0, attributes);
                handler().startElement(toQName(str4, str5, str6), JAXPValidatorComponent.access$500(this.this$0), elementAug());
            } catch (XNIException e) {
                throw toSAXException(e);
            }
        }
    }

    private static final class XNI2SAX extends DefaultXMLDocumentHandler {
        private final AttributesProxy fAttributesProxy;
        private ContentHandler fContentHandler;
        protected NamespaceContext fNamespaceContext;
        private String fVersion;

        private XNI2SAX() {
            AttributesProxy attributesProxy;
            new AttributesProxy((XMLAttributes) null);
            this.fAttributesProxy = attributesProxy;
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        XNI2SAX(AnonymousClass1 r4) {
            this();
            AnonymousClass1 r1 = r4;
        }

        public void characters(XMLString xMLString, Augmentations augmentations) throws XNIException {
            Throwable th;
            XMLString xMLString2 = xMLString;
            Augmentations augmentations2 = augmentations;
            try {
                this.fContentHandler.characters(xMLString2.ch, xMLString2.offset, xMLString2.length);
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }

        public void emptyElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
            QName qName2 = qName;
            Augmentations augmentations2 = augmentations;
            startElement(qName2, xMLAttributes, augmentations2);
            endElement(qName2, augmentations2);
        }

        public void endDocument(Augmentations augmentations) throws XNIException {
            Throwable th;
            Augmentations augmentations2 = augmentations;
            try {
                this.fContentHandler.endDocument();
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }

        public void endElement(QName qName, Augmentations augmentations) throws XNIException {
            Throwable th;
            QName qName2 = qName;
            Augmentations augmentations2 = augmentations;
            try {
                this.fContentHandler.endElement(qName2.uri != null ? qName2.uri : "", qName2.localpart, qName2.rawname);
                int declaredPrefixCount = this.fNamespaceContext.getDeclaredPrefixCount();
                if (declaredPrefixCount > 0) {
                    for (int i = 0; i < declaredPrefixCount; i++) {
                        this.fContentHandler.endPrefixMapping(this.fNamespaceContext.getDeclaredPrefixAt(i));
                    }
                }
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }

        public ContentHandler getContentHandler() {
            return this.fContentHandler;
        }

        public void ignorableWhitespace(XMLString xMLString, Augmentations augmentations) throws XNIException {
            Throwable th;
            XMLString xMLString2 = xMLString;
            Augmentations augmentations2 = augmentations;
            try {
                this.fContentHandler.ignorableWhitespace(xMLString2.ch, xMLString2.offset, xMLString2.length);
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }

        public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
            Throwable th;
            Augmentations augmentations2 = augmentations;
            try {
                this.fContentHandler.processingInstruction(str, xMLString.toString());
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }

        public void setContentHandler(ContentHandler contentHandler) {
            ContentHandler contentHandler2 = contentHandler;
            this.fContentHandler = contentHandler2;
        }

        public void startDocument(XMLLocator xMLLocator, String str, NamespaceContext namespaceContext, Augmentations augmentations) throws XNIException {
            Locator locator;
            Throwable th;
            String str2 = str;
            Augmentations augmentations2 = augmentations;
            this.fNamespaceContext = namespaceContext;
            new LocatorProxy(xMLLocator);
            this.fContentHandler.setDocumentLocator(locator);
            try {
                this.fContentHandler.startDocument();
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }

        public void startElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
            Throwable th;
            QName qName2 = qName;
            XMLAttributes xMLAttributes2 = xMLAttributes;
            Augmentations augmentations2 = augmentations;
            try {
                int declaredPrefixCount = this.fNamespaceContext.getDeclaredPrefixCount();
                if (declaredPrefixCount > 0) {
                    for (int i = 0; i < declaredPrefixCount; i++) {
                        String declaredPrefixAt = this.fNamespaceContext.getDeclaredPrefixAt(i);
                        String uri = this.fNamespaceContext.getURI(declaredPrefixAt);
                        this.fContentHandler.startPrefixMapping(declaredPrefixAt, uri == null ? "" : uri);
                    }
                }
                String str = qName2.uri != null ? qName2.uri : "";
                String str2 = qName2.localpart;
                this.fAttributesProxy.setAttributes(xMLAttributes2);
                this.fContentHandler.startElement(str, str2, qName2.rawname, this.fAttributesProxy);
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }

        public void xmlDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
            String str4 = str2;
            String str5 = str3;
            Augmentations augmentations2 = augmentations;
            String str6 = str;
            this.fVersion = str6;
        }
    }

    static {
        TypeInfoProvider typeInfoProvider2;
        new TypeInfoProvider() {
            public TypeInfo getAttributeTypeInfo(int i) {
                int i2 = i;
                return null;
            }

            public TypeInfo getAttributeTypeInfo(String str) {
                String str2 = str;
                return null;
            }

            public TypeInfo getAttributeTypeInfo(String str, String str2) {
                String str3 = str;
                String str4 = str2;
                return null;
            }

            public TypeInfo getElementTypeInfo() {
                return null;
            }

            public boolean isIdAttribute(int i) {
                int i2 = i;
                return false;
            }

            public boolean isSpecified(int i) {
                int i2 = i;
                return false;
            }
        };
        noInfoProvider = typeInfoProvider2;
    }

    /* JADX WARNING: type inference failed for: r4v11, types: [org.apache.xerces.xni.XMLDocumentHandler, org.apache.xerces.jaxp.JAXPValidatorComponent$XNI2SAX] */
    public JAXPValidatorComponent(ValidatorHandler validatorHandler) {
        XNI2SAX xni2sax2;
        SAX2XNI sax2xni2;
        ErrorHandler errorHandler;
        LSResourceResolver lSResourceResolver;
        ValidatorHandler validatorHandler2 = validatorHandler;
        new XNI2SAX((AnonymousClass1) null);
        this.xni2sax = xni2sax2;
        new SAX2XNI(this, (AnonymousClass1) null);
        this.sax2xni = sax2xni2;
        this.validator = validatorHandler2;
        TypeInfoProvider typeInfoProvider2 = validatorHandler2.getTypeInfoProvider();
        this.typeInfoProvider = typeInfoProvider2 == null ? noInfoProvider : typeInfoProvider2;
        this.xni2sax.setContentHandler(this.validator);
        this.validator.setContentHandler(this.sax2xni);
        setSide(this.xni2sax);
        new ErrorHandlerProxy(this) {
            private final JAXPValidatorComponent this$0;

            {
                this.this$0 = r5;
            }

            /* access modifiers changed from: protected */
            public XMLErrorHandler getErrorHandler() {
                XMLErrorHandler xMLErrorHandler;
                XMLErrorHandler errorHandler = JAXPValidatorComponent.access$200(this.this$0).getErrorHandler();
                if (errorHandler != null) {
                    return errorHandler;
                }
                new ErrorHandlerWrapper(DraconianErrorHandler.getInstance());
                return xMLErrorHandler;
            }
        };
        this.validator.setErrorHandler(errorHandler);
        new LSResourceResolver(this) {
            private final JAXPValidatorComponent this$0;

            {
                this.this$0 = r5;
            }

            public LSInput resolveResource(String str, String str2, String str3, String str4, String str5) {
                Throwable th;
                XMLResourceIdentifier xMLResourceIdentifier;
                LSInput lSInput;
                String str6 = str;
                String str7 = str2;
                String str8 = str3;
                String str9 = str4;
                String str10 = str5;
                if (JAXPValidatorComponent.access$300(this.this$0) == null) {
                    return null;
                }
                try {
                    new XMLResourceIdentifierImpl(str8, str9, str10, (String) null);
                    XMLInputSource resolveEntity = JAXPValidatorComponent.access$300(this.this$0).resolveEntity(xMLResourceIdentifier);
                    if (resolveEntity == null) {
                        return null;
                    }
                    new DOMInputImpl();
                    LSInput lSInput2 = lSInput;
                    lSInput2.setBaseURI(resolveEntity.getBaseSystemId());
                    lSInput2.setByteStream(resolveEntity.getByteStream());
                    lSInput2.setCharacterStream(resolveEntity.getCharacterStream());
                    lSInput2.setEncoding(resolveEntity.getEncoding());
                    lSInput2.setPublicId(resolveEntity.getPublicId());
                    lSInput2.setSystemId(resolveEntity.getSystemId());
                    return lSInput2;
                } catch (IOException e) {
                    IOException iOException = e;
                    Throwable th2 = th;
                    new XNIException((Exception) iOException);
                    throw th2;
                }
            }
        };
        this.validator.setResourceResolver(lSResourceResolver);
    }

    static XMLErrorReporter access$200(JAXPValidatorComponent jAXPValidatorComponent) {
        return jAXPValidatorComponent.fErrorReporter;
    }

    static XMLEntityResolver access$300(JAXPValidatorComponent jAXPValidatorComponent) {
        return jAXPValidatorComponent.fEntityResolver;
    }

    static void access$400(JAXPValidatorComponent jAXPValidatorComponent, Attributes attributes) {
        jAXPValidatorComponent.updateAttributes(attributes);
    }

    static XMLAttributes access$500(JAXPValidatorComponent jAXPValidatorComponent) {
        return jAXPValidatorComponent.fCurrentAttributes;
    }

    static Augmentations access$600(JAXPValidatorComponent jAXPValidatorComponent) {
        return jAXPValidatorComponent.fCurrentAug;
    }

    static Augmentations access$602(JAXPValidatorComponent jAXPValidatorComponent, Augmentations augmentations) {
        Augmentations augmentations2 = augmentations;
        Augmentations augmentations3 = augmentations2;
        jAXPValidatorComponent.fCurrentAug = augmentations3;
        return augmentations2;
    }

    static String access$700(JAXPValidatorComponent jAXPValidatorComponent, String str) {
        return jAXPValidatorComponent.symbolize(str);
    }

    private String symbolize(String str) {
        return this.fSymbolTable.addSymbol(str);
    }

    private void updateAttributes(Attributes attributes) {
        QName qName;
        Attributes attributes2 = attributes;
        int length = attributes2.getLength();
        for (int i = 0; i < length; i++) {
            String qName2 = attributes2.getQName(i);
            int index = this.fCurrentAttributes.getIndex(qName2);
            String value = attributes2.getValue(i);
            if (index == -1) {
                int indexOf = qName2.indexOf(58);
                new QName(indexOf < 0 ? null : symbolize(qName2.substring(0, indexOf)), symbolize(attributes2.getLocalName(i)), symbolize(qName2), symbolize(attributes2.getURI(i)));
                int addAttribute = this.fCurrentAttributes.addAttribute(qName, attributes2.getType(i), value);
            } else if (!value.equals(this.fCurrentAttributes.getValue(index))) {
                this.fCurrentAttributes.setValue(index, value);
            }
        }
    }

    public void characters(XMLString xMLString, Augmentations augmentations) throws XNIException {
        this.fCurrentAug = augmentations;
        this.xni2sax.characters(xMLString, (Augmentations) null);
    }

    public void emptyElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        startElement(qName2, xMLAttributes, augmentations2);
        endElement(qName2, augmentations2);
    }

    public void endElement(QName qName, Augmentations augmentations) throws XNIException {
        this.fCurrentAug = augmentations;
        this.xni2sax.endElement(qName, (Augmentations) null);
    }

    public Boolean getFeatureDefault(String str) {
        String str2 = str;
        return null;
    }

    public Object getPropertyDefault(String str) {
        String str2 = str;
        return null;
    }

    public String[] getRecognizedFeatures() {
        return null;
    }

    public String[] getRecognizedProperties() {
        String[] strArr = new String[3];
        strArr[0] = ENTITY_MANAGER;
        String[] strArr2 = strArr;
        strArr2[1] = ERROR_REPORTER;
        String[] strArr3 = strArr2;
        strArr3[2] = SYMBOL_TABLE;
        return strArr3;
    }

    public void ignorableWhitespace(XMLString xMLString, Augmentations augmentations) throws XNIException {
        this.fCurrentAug = augmentations;
        this.xni2sax.ignorableWhitespace(xMLString, (Augmentations) null);
    }

    public void reset(XMLComponentManager xMLComponentManager) throws XMLConfigurationException {
        XMLComponentManager xMLComponentManager2 = xMLComponentManager;
        this.fSymbolTable = (SymbolTable) xMLComponentManager2.getProperty(SYMBOL_TABLE);
        this.fErrorReporter = (XMLErrorReporter) xMLComponentManager2.getProperty(ERROR_REPORTER);
        try {
            this.fEntityResolver = (XMLEntityResolver) xMLComponentManager2.getProperty(ENTITY_MANAGER);
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
            this.fEntityResolver = null;
        }
    }

    public void setFeature(String str, boolean z) throws XMLConfigurationException {
    }

    public void setProperty(String str, Object obj) throws XMLConfigurationException {
    }

    public void startElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        XMLAttributes xMLAttributes2 = xMLAttributes;
        this.fCurrentAttributes = xMLAttributes2;
        this.fCurrentAug = augmentations;
        this.xni2sax.startElement(qName, xMLAttributes2, (Augmentations) null);
        this.fCurrentAttributes = null;
    }
}
