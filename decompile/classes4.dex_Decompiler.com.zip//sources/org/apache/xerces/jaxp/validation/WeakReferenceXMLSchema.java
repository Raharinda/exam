package org.apache.xerces.jaxp.validation;

import java.lang.ref.WeakReference;
import org.apache.xerces.xni.grammars.XMLGrammarPool;

final class WeakReferenceXMLSchema extends AbstractXMLSchema {
    private WeakReference fGrammarPool;

    public WeakReferenceXMLSchema() {
        WeakReference weakReference;
        new WeakReference((Object) null);
        this.fGrammarPool = weakReference;
    }

    public synchronized XMLGrammarPool getGrammarPool() {
        XMLGrammarPool xMLGrammarPool;
        XMLGrammarPool xMLGrammarPool2;
        WeakReference weakReference;
        synchronized (this) {
            XMLGrammarPool xMLGrammarPool3 = (XMLGrammarPool) this.fGrammarPool.get();
            if (xMLGrammarPool3 == null) {
                new SoftReferenceGrammarPool();
                xMLGrammarPool3 = xMLGrammarPool2;
                new WeakReference(xMLGrammarPool3);
                this.fGrammarPool = weakReference;
            }
            xMLGrammarPool = xMLGrammarPool3;
        }
        return xMLGrammarPool;
    }

    public boolean isFullyComposed() {
        return false;
    }
}
