package org.apache.xerces.jaxp.validation;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Locale;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import net.lingala.zip4j.util.Zip4jConstants;
import org.apache.xerces.dom.NodeImpl;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.impl.validation.EntityState;
import org.apache.xerces.impl.validation.ValidationManager;
import org.apache.xerces.impl.xs.XMLSchemaValidator;
import org.apache.xerces.impl.xs.util.SimpleLocator;
import org.apache.xerces.util.NamespaceSupport;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.util.XMLAttributesImpl;
import org.apache.xerces.util.XMLSymbols;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLParseException;
import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Entity;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

final class DOMValidatorHelper implements ValidatorHelper, EntityState {
    private static final int CHUNK_MASK = 1023;
    private static final int CHUNK_SIZE = 1024;
    private static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
    private static final String NAMESPACE_CONTEXT = "http://apache.org/xml/properties/internal/namespace-context";
    private static final String SCHEMA_VALIDATOR = "http://apache.org/xml/properties/internal/validator/schema";
    private static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    private static final String VALIDATION_MANAGER = "http://apache.org/xml/properties/internal/validation-manager";
    final QName fAttributeQName;
    final XMLAttributesImpl fAttributes;
    private final char[] fCharBuffer = new char[1024];
    private final XMLSchemaValidatorComponentManager fComponentManager;
    private Node fCurrentElement;
    private final DOMNamespaceContext fDOMNamespaceContext;
    private final DOMResultAugmentor fDOMResultAugmentor;
    private final DOMResultBuilder fDOMResultBuilder;
    private DOMDocumentHandler fDOMValidatorHandler;
    final QName fElementQName;
    private NamedNodeMap fEntities = null;
    private final XMLErrorReporter fErrorReporter;
    private final NamespaceSupport fNamespaceContext;
    private Node fRoot;
    private final XMLSchemaValidator fSchemaValidator;
    private final SymbolTable fSymbolTable;
    final XMLString fTempString;
    private final ValidationManager fValidationManager;
    private final SimpleLocator fXMLLocator;

    final class DOMNamespaceContext implements NamespaceContext {
        protected boolean fDOMContextBuilt = false;
        protected String[] fNamespace = new String[32];
        protected int fNamespaceSize = 0;
        private final DOMValidatorHelper this$0;

        DOMNamespaceContext(DOMValidatorHelper dOMValidatorHelper) {
            this.this$0 = dOMValidatorHelper;
        }

        private void declarePrefix0(String str, String str2) {
            String str3 = str;
            String str4 = str2;
            if (this.fNamespaceSize == this.fNamespace.length) {
                String[] strArr = new String[(this.fNamespaceSize * 2)];
                System.arraycopy(this.fNamespace, 0, strArr, 0, this.fNamespaceSize);
                this.fNamespace = strArr;
            }
            String[] strArr2 = this.fNamespace;
            int i = this.fNamespaceSize;
            int i2 = i + 1;
            this.fNamespaceSize = i2;
            strArr2[i] = str3;
            String[] strArr3 = this.fNamespace;
            int i3 = this.fNamespaceSize;
            int i4 = i3 + 1;
            this.fNamespaceSize = i4;
            strArr3[i3] = str4;
        }

        private void fillNamespaceContext() {
            if (DOMValidatorHelper.access$100(this.this$0) != null) {
                Node parentNode = DOMValidatorHelper.access$100(this.this$0).getParentNode();
                while (true) {
                    Node node = parentNode;
                    if (node != null) {
                        if (1 == node.getNodeType()) {
                            NamedNodeMap attributes = node.getAttributes();
                            int length = attributes.getLength();
                            for (int i = 0; i < length; i++) {
                                Attr attr = (Attr) attributes.item(i);
                                String value = attr.getValue();
                                if (value == null) {
                                    value = XMLSymbols.EMPTY_STRING;
                                }
                                DOMValidatorHelper.access$200(this.this$0, this.this$0.fAttributeQName, attr);
                                if (this.this$0.fAttributeQName.uri == NamespaceContext.XMLNS_URI) {
                                    if (this.this$0.fAttributeQName.prefix == XMLSymbols.PREFIX_XMLNS) {
                                        declarePrefix0(this.this$0.fAttributeQName.localpart, value.length() != 0 ? DOMValidatorHelper.access$300(this.this$0).addSymbol(value) : null);
                                    } else {
                                        declarePrefix0(XMLSymbols.EMPTY_STRING, value.length() != 0 ? DOMValidatorHelper.access$300(this.this$0).addSymbol(value) : null);
                                    }
                                }
                            }
                        }
                        parentNode = node.getParentNode();
                    } else {
                        return;
                    }
                }
            }
        }

        private String getURI0(String str) {
            String str2 = str;
            for (int i = 0; i < this.fNamespaceSize; i += 2) {
                if (this.fNamespace[i] == str2) {
                    return this.fNamespace[i + 1];
                }
            }
            return null;
        }

        public boolean declarePrefix(String str, String str2) {
            return DOMValidatorHelper.access$000(this.this$0).declarePrefix(str, str2);
        }

        public Enumeration getAllPrefixes() {
            return DOMValidatorHelper.access$000(this.this$0).getAllPrefixes();
        }

        public String getDeclaredPrefixAt(int i) {
            return DOMValidatorHelper.access$000(this.this$0).getDeclaredPrefixAt(i);
        }

        public int getDeclaredPrefixCount() {
            return DOMValidatorHelper.access$000(this.this$0).getDeclaredPrefixCount();
        }

        public String getPrefix(String str) {
            return DOMValidatorHelper.access$000(this.this$0).getPrefix(str);
        }

        public String getURI(String str) {
            String str2 = str;
            String uri = DOMValidatorHelper.access$000(this.this$0).getURI(str2);
            if (uri == null) {
                if (!this.fDOMContextBuilt) {
                    fillNamespaceContext();
                    this.fDOMContextBuilt = true;
                }
                if (this.fNamespaceSize > 0 && !DOMValidatorHelper.access$000(this.this$0).containsPrefix(str2)) {
                    uri = getURI0(str2);
                }
            }
            return uri;
        }

        public void popContext() {
            DOMValidatorHelper.access$000(this.this$0).popContext();
        }

        public void pushContext() {
            DOMValidatorHelper.access$000(this.this$0).pushContext();
        }

        public void reset() {
            this.fDOMContextBuilt = false;
            this.fNamespaceSize = 0;
        }
    }

    public DOMValidatorHelper(XMLSchemaValidatorComponentManager xMLSchemaValidatorComponentManager) {
        DOMNamespaceContext dOMNamespaceContext;
        SimpleLocator simpleLocator;
        DOMResultAugmentor dOMResultAugmentor;
        DOMResultBuilder dOMResultBuilder;
        QName qName;
        QName qName2;
        XMLAttributesImpl xMLAttributesImpl;
        XMLString xMLString;
        new DOMNamespaceContext(this);
        this.fDOMNamespaceContext = dOMNamespaceContext;
        new SimpleLocator((String) null, (String) null, -1, -1, -1);
        this.fXMLLocator = simpleLocator;
        new DOMResultAugmentor(this);
        this.fDOMResultAugmentor = dOMResultAugmentor;
        new DOMResultBuilder();
        this.fDOMResultBuilder = dOMResultBuilder;
        new QName();
        this.fElementQName = qName;
        new QName();
        this.fAttributeQName = qName2;
        new XMLAttributesImpl();
        this.fAttributes = xMLAttributesImpl;
        new XMLString();
        this.fTempString = xMLString;
        this.fComponentManager = xMLSchemaValidatorComponentManager;
        this.fErrorReporter = (XMLErrorReporter) this.fComponentManager.getProperty(ERROR_REPORTER);
        this.fNamespaceContext = (NamespaceSupport) this.fComponentManager.getProperty(NAMESPACE_CONTEXT);
        this.fSchemaValidator = (XMLSchemaValidator) this.fComponentManager.getProperty(SCHEMA_VALIDATOR);
        this.fSymbolTable = (SymbolTable) this.fComponentManager.getProperty(SYMBOL_TABLE);
        this.fValidationManager = (ValidationManager) this.fComponentManager.getProperty(VALIDATION_MANAGER);
    }

    static NamespaceSupport access$000(DOMValidatorHelper dOMValidatorHelper) {
        return dOMValidatorHelper.fNamespaceContext;
    }

    static Node access$100(DOMValidatorHelper dOMValidatorHelper) {
        return dOMValidatorHelper.fRoot;
    }

    static void access$200(DOMValidatorHelper dOMValidatorHelper, QName qName, Node node) {
        dOMValidatorHelper.fillQName(qName, node);
    }

    static SymbolTable access$300(DOMValidatorHelper dOMValidatorHelper) {
        return dOMValidatorHelper.fSymbolTable;
    }

    private void beginNode(Node node) {
        Node node2 = node;
        switch (node2.getNodeType()) {
            case 1:
                this.fCurrentElement = node2;
                this.fNamespaceContext.pushContext();
                fillQName(this.fElementQName, node2);
                processAttributes(node2.getAttributes());
                this.fSchemaValidator.startElement(this.fElementQName, this.fAttributes, (Augmentations) null);
                return;
            case 3:
                if (this.fDOMValidatorHandler != null) {
                    this.fDOMValidatorHandler.setIgnoringCharacters(true);
                    sendCharactersToValidator(node2.getNodeValue());
                    this.fDOMValidatorHandler.setIgnoringCharacters(false);
                    this.fDOMValidatorHandler.characters((Text) node2);
                    return;
                }
                sendCharactersToValidator(node2.getNodeValue());
                return;
            case 4:
                if (this.fDOMValidatorHandler != null) {
                    this.fDOMValidatorHandler.setIgnoringCharacters(true);
                    this.fSchemaValidator.startCDATA((Augmentations) null);
                    sendCharactersToValidator(node2.getNodeValue());
                    this.fSchemaValidator.endCDATA((Augmentations) null);
                    this.fDOMValidatorHandler.setIgnoringCharacters(false);
                    this.fDOMValidatorHandler.cdata((CDATASection) node2);
                    return;
                }
                this.fSchemaValidator.startCDATA((Augmentations) null);
                sendCharactersToValidator(node2.getNodeValue());
                this.fSchemaValidator.endCDATA((Augmentations) null);
                return;
            case Zip4jConstants.DEFLATE_LEVEL_MAXIMUM:
                if (this.fDOMValidatorHandler != null) {
                    this.fDOMValidatorHandler.processingInstruction((ProcessingInstruction) node2);
                    return;
                }
                return;
            case 8:
                if (this.fDOMValidatorHandler != null) {
                    this.fDOMValidatorHandler.comment((Comment) node2);
                    return;
                }
                return;
            case 10:
                if (this.fDOMValidatorHandler != null) {
                    this.fDOMValidatorHandler.doctypeDecl((DocumentType) node2);
                    return;
                }
                return;
            default:
                return;
        }
    }

    private void fillQName(QName qName, Node node) {
        QName qName2 = qName;
        Node node2 = node;
        String prefix = node2.getPrefix();
        String localName = node2.getLocalName();
        String nodeName = node2.getNodeName();
        String namespaceURI = node2.getNamespaceURI();
        qName2.prefix = prefix != null ? this.fSymbolTable.addSymbol(prefix) : XMLSymbols.EMPTY_STRING;
        qName2.localpart = localName != null ? this.fSymbolTable.addSymbol(localName) : XMLSymbols.EMPTY_STRING;
        qName2.rawname = nodeName != null ? this.fSymbolTable.addSymbol(nodeName) : XMLSymbols.EMPTY_STRING;
        qName2.uri = (namespaceURI == null || namespaceURI.length() <= 0) ? null : this.fSymbolTable.addSymbol(namespaceURI);
    }

    private void finishNode(Node node) {
        Node node2 = node;
        if (node2.getNodeType() == 1) {
            this.fCurrentElement = node2;
            fillQName(this.fElementQName, node2);
            this.fSchemaValidator.endElement(this.fElementQName, (Augmentations) null);
            this.fNamespaceContext.popContext();
        }
    }

    private void processAttributes(NamedNodeMap namedNodeMap) {
        NamedNodeMap namedNodeMap2 = namedNodeMap;
        int length = namedNodeMap2.getLength();
        this.fAttributes.removeAllAttributes();
        for (int i = 0; i < length; i++) {
            Attr attr = (Attr) namedNodeMap2.item(i);
            String value = attr.getValue();
            if (value == null) {
                value = XMLSymbols.EMPTY_STRING;
            }
            fillQName(this.fAttributeQName, attr);
            this.fAttributes.addAttributeNS(this.fAttributeQName, XMLSymbols.fCDATASymbol, value);
            this.fAttributes.setSpecified(i, attr.getSpecified());
            if (this.fAttributeQName.uri == NamespaceContext.XMLNS_URI) {
                if (this.fAttributeQName.prefix == XMLSymbols.PREFIX_XMLNS) {
                    boolean declarePrefix = this.fNamespaceContext.declarePrefix(this.fAttributeQName.localpart, value.length() != 0 ? this.fSymbolTable.addSymbol(value) : null);
                } else {
                    boolean declarePrefix2 = this.fNamespaceContext.declarePrefix(XMLSymbols.EMPTY_STRING, value.length() != 0 ? this.fSymbolTable.addSymbol(value) : null);
                }
            }
        }
    }

    private void sendCharactersToValidator(String str) {
        String str2 = str;
        if (str2 != null) {
            int length = str2.length();
            int i = length & CHUNK_MASK;
            if (i > 0) {
                str2.getChars(0, i, this.fCharBuffer, 0);
                this.fTempString.setValues(this.fCharBuffer, 0, i);
                this.fSchemaValidator.characters(this.fTempString, (Augmentations) null);
            }
            int i2 = i;
            while (i2 < length) {
                int i3 = i2 + 1024;
                i2 = i3;
                str2.getChars(i2, i3, this.fCharBuffer, 0);
                this.fTempString.setValues(this.fCharBuffer, 0, 1024);
                this.fSchemaValidator.characters(this.fTempString, (Augmentations) null);
            }
        }
    }

    private void setupDOMResultHandler(DOMSource dOMSource, DOMResult dOMResult) throws SAXException {
        Throwable th;
        DOMSource dOMSource2 = dOMSource;
        DOMResult dOMResult2 = dOMResult;
        if (dOMResult2 == null) {
            this.fDOMValidatorHandler = null;
            this.fSchemaValidator.setDocumentHandler((XMLDocumentHandler) null);
            return;
        }
        if (dOMSource2.getNode() == dOMResult2.getNode()) {
            this.fDOMValidatorHandler = this.fDOMResultAugmentor;
            this.fDOMResultAugmentor.setDOMResult(dOMResult2);
            this.fSchemaValidator.setDocumentHandler(this.fDOMResultAugmentor);
            return;
        }
        if (dOMResult2.getNode() == null) {
            try {
                DocumentBuilderFactory newInstance = DocumentBuilderFactory.newInstance();
                newInstance.setNamespaceAware(true);
                dOMResult2.setNode(newInstance.newDocumentBuilder().newDocument());
            } catch (ParserConfigurationException e) {
                ParserConfigurationException parserConfigurationException = e;
                Throwable th2 = th;
                new SAXException(parserConfigurationException);
                throw th2;
            }
        }
        this.fDOMValidatorHandler = this.fDOMResultBuilder;
        this.fDOMResultBuilder.setDOMResult(dOMResult2);
        this.fSchemaValidator.setDocumentHandler(this.fDOMResultBuilder);
    }

    private void setupEntityMap(Document document) {
        DocumentType doctype;
        Document document2 = document;
        if (document2 == null || (doctype = document2.getDoctype()) == null) {
            this.fEntities = null;
            return;
        }
        this.fEntities = doctype.getEntities();
    }

    private boolean useIsSameNode(Node node) {
        Node node2 = node;
        if (node2 instanceof NodeImpl) {
            return false;
        }
        Document ownerDocument = node2.getNodeType() == 9 ? (Document) node2 : node2.getOwnerDocument();
        return ownerDocument != null && ownerDocument.getImplementation().hasFeature("Core", "3.0");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0048, code lost:
        if (r1 == null) goto L_0x004f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x004a, code lost:
        finishNode(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x004f, code lost:
        r4 = null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void validate(org.w3c.dom.Node r8) {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r5 = r1
            r2 = r5
            r5 = r0
            r6 = r2
            boolean r5 = r5.useIsSameNode(r6)
            r3 = r5
        L_0x000b:
            r5 = r1
            if (r5 != 0) goto L_0x000f
            return
        L_0x000f:
            r5 = r0
            r6 = r1
            r5.beginNode(r6)
            r5 = r1
            org.w3c.dom.Node r5 = r5.getFirstChild()
            r4 = r5
        L_0x001a:
            r5 = r4
            if (r5 == 0) goto L_0x0020
        L_0x001d:
            r5 = r4
            r1 = r5
            goto L_0x000b
        L_0x0020:
            r5 = r0
            r6 = r1
            r5.finishNode(r6)
            r5 = r2
            r6 = r1
            if (r5 != r6) goto L_0x002a
            goto L_0x001d
        L_0x002a:
            r5 = r1
            org.w3c.dom.Node r5 = r5.getNextSibling()
            r4 = r5
            r5 = r4
            if (r5 != 0) goto L_0x001a
            r5 = r1
            org.w3c.dom.Node r5 = r5.getParentNode()
            r1 = r5
            r5 = r1
            if (r5 == 0) goto L_0x0047
            r5 = r3
            if (r5 == 0) goto L_0x0052
            r5 = r2
            r6 = r1
            boolean r5 = r5.isSameNode(r6)
        L_0x0045:
            if (r5 == 0) goto L_0x001a
        L_0x0047:
            r5 = r1
            if (r5 == 0) goto L_0x004f
            r5 = r0
            r6 = r1
            r5.finishNode(r6)
        L_0x004f:
            r5 = 0
            r4 = r5
            goto L_0x001d
        L_0x0052:
            r5 = r2
            r6 = r1
            if (r5 != r6) goto L_0x0058
            r5 = 1
            goto L_0x0045
        L_0x0058:
            r5 = 0
            goto L_0x0045
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.jaxp.validation.DOMValidatorHelper.validate(org.w3c.dom.Node):void");
    }

    /* access modifiers changed from: package-private */
    public Node getCurrentElement() {
        return this.fCurrentElement;
    }

    public boolean isEntityDeclared(String str) {
        String str2 = str;
        return false;
    }

    public boolean isEntityUnparsed(String str) {
        Entity entity;
        String str2 = str;
        if (this.fEntities == null || (entity = (Entity) this.fEntities.getNamedItem(str2)) == null) {
            return false;
        }
        return entity.getNotationName() != null;
    }

    public void validate(Source source, Result result) throws SAXException, IOException {
        Throwable th;
        Source source2 = source;
        Result result2 = result;
        if ((result2 instanceof DOMResult) || result2 == null) {
            DOMSource dOMSource = (DOMSource) source2;
            DOMResult dOMResult = (DOMResult) result2;
            Node node = dOMSource.getNode();
            this.fRoot = node;
            if (node != null) {
                this.fComponentManager.reset();
                this.fValidationManager.setEntityState(this);
                this.fDOMNamespaceContext.reset();
                String systemId = dOMSource.getSystemId();
                this.fXMLLocator.setLiteralSystemId(systemId);
                this.fXMLLocator.setExpandedSystemId(systemId);
                this.fErrorReporter.setDocumentLocator(this.fXMLLocator);
                try {
                    setupEntityMap(node.getNodeType() == 9 ? (Document) node : node.getOwnerDocument());
                    setupDOMResultHandler(dOMSource, dOMResult);
                    this.fSchemaValidator.startDocument(this.fXMLLocator, (String) null, this.fDOMNamespaceContext, (Augmentations) null);
                    validate(node);
                    this.fSchemaValidator.endDocument((Augmentations) null);
                    this.fRoot = null;
                    this.fCurrentElement = null;
                    this.fEntities = null;
                    if (this.fDOMValidatorHandler != null) {
                        this.fDOMValidatorHandler.setDOMResult((DOMResult) null);
                    }
                } catch (XMLParseException e) {
                    throw Util.toSAXParseException(e);
                } catch (XNIException e2) {
                    throw Util.toSAXException(e2);
                } catch (Throwable th2) {
                    Throwable th3 = th2;
                    this.fRoot = null;
                    this.fCurrentElement = null;
                    this.fEntities = null;
                    if (this.fDOMValidatorHandler != null) {
                        this.fDOMValidatorHandler.setDOMResult((DOMResult) null);
                    }
                    throw th3;
                }
            }
        } else {
            Throwable th4 = th;
            Locale locale = this.fComponentManager.getLocale();
            Object[] objArr = new Object[2];
            objArr[0] = source2.getClass().getName();
            Object[] objArr2 = objArr;
            objArr2[1] = result2.getClass().getName();
            new IllegalArgumentException(JAXPValidationMessageFormatter.formatMessage(locale, "SourceResultMismatch", objArr2));
            throw th4;
        }
    }
}
