package org.apache.xerces.jaxp;

import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLDocumentFilter;
import org.apache.xerces.xni.parser.XMLDocumentSource;

class TeeXMLDocumentFilterImpl implements XMLDocumentFilter {
    private XMLDocumentHandler next;
    private XMLDocumentHandler side;
    private XMLDocumentSource source;

    TeeXMLDocumentFilterImpl() {
    }

    public void characters(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        this.side.characters(xMLString2, augmentations2);
        this.next.characters(xMLString2, augmentations2);
    }

    public void comment(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        this.side.comment(xMLString2, augmentations2);
        this.next.comment(xMLString2, augmentations2);
    }

    public void doctypeDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        Augmentations augmentations2 = augmentations;
        this.side.doctypeDecl(str4, str5, str6, augmentations2);
        this.next.doctypeDecl(str4, str5, str6, augmentations2);
    }

    public void emptyElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        this.side.emptyElement(qName2, xMLAttributes2, augmentations2);
        this.next.emptyElement(qName2, xMLAttributes2, augmentations2);
    }

    public void endCDATA(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        this.side.endCDATA(augmentations2);
        this.next.endCDATA(augmentations2);
    }

    public void endDocument(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        this.side.endDocument(augmentations2);
        this.next.endDocument(augmentations2);
    }

    public void endElement(QName qName, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        this.side.endElement(qName2, augmentations2);
        this.next.endElement(qName2, augmentations2);
    }

    public void endGeneralEntity(String str, Augmentations augmentations) throws XNIException {
        String str2 = str;
        Augmentations augmentations2 = augmentations;
        this.side.endGeneralEntity(str2, augmentations2);
        this.next.endGeneralEntity(str2, augmentations2);
    }

    public XMLDocumentHandler getDocumentHandler() {
        return this.next;
    }

    public XMLDocumentSource getDocumentSource() {
        return this.source;
    }

    public XMLDocumentHandler getSide() {
        return this.side;
    }

    public void ignorableWhitespace(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        this.side.ignorableWhitespace(xMLString2, augmentations2);
        this.next.ignorableWhitespace(xMLString2, augmentations2);
    }

    public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
        String str2 = str;
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        this.side.processingInstruction(str2, xMLString2, augmentations2);
        this.next.processingInstruction(str2, xMLString2, augmentations2);
    }

    public void setDocumentHandler(XMLDocumentHandler xMLDocumentHandler) {
        XMLDocumentHandler xMLDocumentHandler2 = xMLDocumentHandler;
        this.next = xMLDocumentHandler2;
    }

    public void setDocumentSource(XMLDocumentSource xMLDocumentSource) {
        XMLDocumentSource xMLDocumentSource2 = xMLDocumentSource;
        this.source = xMLDocumentSource2;
    }

    public void setSide(XMLDocumentHandler xMLDocumentHandler) {
        XMLDocumentHandler xMLDocumentHandler2 = xMLDocumentHandler;
        this.side = xMLDocumentHandler2;
    }

    public void startCDATA(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        this.side.startCDATA(augmentations2);
        this.next.startCDATA(augmentations2);
    }

    public void startDocument(XMLLocator xMLLocator, String str, NamespaceContext namespaceContext, Augmentations augmentations) throws XNIException {
        XMLLocator xMLLocator2 = xMLLocator;
        String str2 = str;
        NamespaceContext namespaceContext2 = namespaceContext;
        Augmentations augmentations2 = augmentations;
        this.side.startDocument(xMLLocator2, str2, namespaceContext2, augmentations2);
        this.next.startDocument(xMLLocator2, str2, namespaceContext2, augmentations2);
    }

    public void startElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        this.side.startElement(qName2, xMLAttributes2, augmentations2);
        this.next.startElement(qName2, xMLAttributes2, augmentations2);
    }

    public void startGeneralEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        this.side.startGeneralEntity(str3, xMLResourceIdentifier2, str4, augmentations2);
        this.next.startGeneralEntity(str3, xMLResourceIdentifier2, str4, augmentations2);
    }

    public void textDecl(String str, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        this.side.textDecl(str3, str4, augmentations2);
        this.next.textDecl(str3, str4, augmentations2);
    }

    public void xmlDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        Augmentations augmentations2 = augmentations;
        this.side.xmlDecl(str4, str5, str6, augmentations2);
        this.next.xmlDecl(str4, str5, str6, augmentations2);
    }
}
