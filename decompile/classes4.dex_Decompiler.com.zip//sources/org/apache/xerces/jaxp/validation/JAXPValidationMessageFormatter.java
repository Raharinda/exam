package org.apache.xerces.jaxp.validation;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

final class JAXPValidationMessageFormatter {
    JAXPValidationMessageFormatter() {
    }

    public static String formatMessage(Locale locale, String str, Object[] objArr) throws MissingResourceException {
        Throwable th;
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        Locale locale2 = locale;
        String str2 = str;
        Object[] objArr2 = objArr;
        if (locale2 == null) {
            locale2 = Locale.getDefault();
        }
        ResourceBundle bundle = ResourceBundle.getBundle("org.apache.xerces.impl.msg.JAXPValidationMessages", locale2);
        try {
            String string = bundle.getString(str2);
            if (objArr2 != null) {
                try {
                    string = MessageFormat.format(string, objArr2);
                } catch (Exception e) {
                    Exception exc = e;
                    String string2 = bundle.getString("FormatFailed");
                    new StringBuffer();
                    string = stringBuffer2.append(string2).append(" ").append(bundle.getString(str2)).toString();
                }
            }
            if (string == null) {
                string = str2;
                if (objArr2.length > 0) {
                    new StringBuffer(string);
                    StringBuffer stringBuffer3 = stringBuffer;
                    StringBuffer append = stringBuffer3.append('?');
                    for (int i = 0; i < objArr2.length; i++) {
                        if (i > 0) {
                            StringBuffer append2 = stringBuffer3.append('&');
                        }
                        StringBuffer append3 = stringBuffer3.append(String.valueOf(objArr2[i]));
                    }
                }
            }
            return string;
        } catch (MissingResourceException e2) {
            MissingResourceException missingResourceException = e2;
            Throwable th2 = th;
            new MissingResourceException(str2, bundle.getString("BadMessageKey"), str2);
            throw th2;
        }
    }
}
