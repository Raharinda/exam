package org.apache.xerces.jaxp.validation;

import com.kodular.fabextension.BuildConfig;
import java.util.Iterator;
import java.util.NoSuchElementException;
import javax.xml.namespace.NamespaceContext;
import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.Comment;
import javax.xml.stream.events.DTD;
import javax.xml.stream.events.EndDocument;
import javax.xml.stream.events.EntityReference;
import javax.xml.stream.events.ProcessingInstruction;
import javax.xml.stream.events.StartDocument;
import javax.xml.stream.events.XMLEvent;
import javax.xml.transform.stax.StAXResult;
import org.apache.xerces.util.JAXPNamespaceContextWrapper;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLDocumentSource;

final class StAXEventResultBuilder implements StAXDocumentHandler {
    private static final Iterator EMPTY_COLLECTION_ITERATOR;
    private final QName fAttrName;
    private final XMLEventFactory fEventFactory = XMLEventFactory.newInstance();
    private XMLEventWriter fEventWriter;
    private boolean fIgnoreChars;
    private boolean fInCDATA;
    private final JAXPNamespaceContextWrapper fNamespaceContext;
    private final StAXValidatorHelper fStAXValidatorHelper;

    final class AttributeIterator implements Iterator {
        XMLAttributes fAttributes;
        int fEnd;
        int fIndex = 0;
        private final StAXEventResultBuilder this$0;

        AttributeIterator(StAXEventResultBuilder stAXEventResultBuilder, XMLAttributes xMLAttributes, int i) {
            this.this$0 = stAXEventResultBuilder;
            this.fAttributes = xMLAttributes;
            this.fEnd = i;
        }

        public boolean hasNext() {
            if (this.fIndex < this.fEnd) {
                return true;
            }
            this.fAttributes = null;
            return false;
        }

        public Object next() {
            Throwable th;
            if (!hasNext()) {
                Throwable th2 = th;
                new NoSuchElementException();
                throw th2;
            }
            this.fAttributes.getName(this.fIndex, StAXEventResultBuilder.access$000(this.this$0));
            XMLEventFactory access$100 = StAXEventResultBuilder.access$100(this.this$0);
            String str = StAXEventResultBuilder.access$000(this.this$0).prefix;
            String str2 = StAXEventResultBuilder.access$000(this.this$0).uri != null ? StAXEventResultBuilder.access$000(this.this$0).uri : "";
            String str3 = StAXEventResultBuilder.access$000(this.this$0).localpart;
            XMLAttributes xMLAttributes = this.fAttributes;
            int i = this.fIndex;
            int i2 = i + 1;
            this.fIndex = i2;
            return access$100.createAttribute(str, str2, str3, xMLAttributes.getValue(i));
        }

        public void remove() {
            Throwable th;
            Throwable th2 = th;
            new UnsupportedOperationException();
            throw th2;
        }
    }

    final class NamespaceIterator implements Iterator {
        int fEnd;
        int fIndex = 0;
        NamespaceContext fNC;
        private final StAXEventResultBuilder this$0;

        NamespaceIterator(StAXEventResultBuilder stAXEventResultBuilder, int i) {
            StAXEventResultBuilder stAXEventResultBuilder2 = stAXEventResultBuilder;
            this.this$0 = stAXEventResultBuilder2;
            this.fNC = StAXEventResultBuilder.access$200(stAXEventResultBuilder2).getNamespaceContext();
            this.fEnd = i;
        }

        public boolean hasNext() {
            if (this.fIndex < this.fEnd) {
                return true;
            }
            this.fNC = null;
            return false;
        }

        public Object next() {
            Throwable th;
            if (!hasNext()) {
                Throwable th2 = th;
                new NoSuchElementException();
                throw th2;
            }
            JAXPNamespaceContextWrapper access$200 = StAXEventResultBuilder.access$200(this.this$0);
            int i = this.fIndex;
            this.fIndex = i + 1;
            String declaredPrefixAt = access$200.getDeclaredPrefixAt(i);
            String namespaceURI = this.fNC.getNamespaceURI(declaredPrefixAt);
            if (declaredPrefixAt.length() == 0) {
                return StAXEventResultBuilder.access$100(this.this$0).createNamespace(namespaceURI != null ? namespaceURI : "");
            }
            return StAXEventResultBuilder.access$100(this.this$0).createNamespace(declaredPrefixAt, namespaceURI != null ? namespaceURI : "");
        }

        public void remove() {
            Throwable th;
            Throwable th2 = th;
            new UnsupportedOperationException();
            throw th2;
        }
    }

    static {
        Iterator it;
        new Iterator() {
            public boolean hasNext() {
                return false;
            }

            public Object next() {
                Throwable th;
                Throwable th2 = th;
                new NoSuchElementException();
                throw th2;
            }

            public void remove() {
                Throwable th;
                Throwable th2 = th;
                new UnsupportedOperationException();
                throw th2;
            }
        };
        EMPTY_COLLECTION_ITERATOR = it;
    }

    public StAXEventResultBuilder(StAXValidatorHelper stAXValidatorHelper, JAXPNamespaceContextWrapper jAXPNamespaceContextWrapper) {
        QName qName;
        new QName();
        this.fAttrName = qName;
        this.fStAXValidatorHelper = stAXValidatorHelper;
        this.fNamespaceContext = jAXPNamespaceContextWrapper;
    }

    static QName access$000(StAXEventResultBuilder stAXEventResultBuilder) {
        return stAXEventResultBuilder.fAttrName;
    }

    static XMLEventFactory access$100(StAXEventResultBuilder stAXEventResultBuilder) {
        return stAXEventResultBuilder.fEventFactory;
    }

    static JAXPNamespaceContextWrapper access$200(StAXEventResultBuilder stAXEventResultBuilder) {
        return stAXEventResultBuilder.fNamespaceContext;
    }

    private Iterator getAttributeIterator(XMLAttributes xMLAttributes, int i) {
        Iterator it;
        Iterator it2;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        int i2 = i;
        if (i2 > 0) {
            it = it2;
            new AttributeIterator(this, xMLAttributes2, i2);
        } else {
            it = EMPTY_COLLECTION_ITERATOR;
        }
        return it;
    }

    private Iterator getNamespaceIterator() {
        Iterator it;
        Iterator it2;
        int declaredPrefixCount = this.fNamespaceContext.getDeclaredPrefixCount();
        if (declaredPrefixCount > 0) {
            it = it2;
            new NamespaceIterator(this, declaredPrefixCount);
        } else {
            it = EMPTY_COLLECTION_ITERATOR;
        }
        return it;
    }

    public void cdata(Characters characters) throws XMLStreamException {
        this.fEventWriter.add(characters);
    }

    public void characters(Characters characters) throws XMLStreamException {
        this.fEventWriter.add(characters);
    }

    public void characters(XMLString xMLString, Augmentations augmentations) throws XNIException {
        Throwable th;
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (!this.fIgnoreChars) {
            try {
                if (!this.fInCDATA) {
                    this.fEventWriter.add(this.fEventFactory.createCharacters(xMLString2.toString()));
                } else {
                    this.fEventWriter.add(this.fEventFactory.createCData(xMLString2.toString()));
                }
            } catch (XMLStreamException e) {
                Exception exc = e;
                Throwable th2 = th;
                new XNIException(exc);
                throw th2;
            }
        }
    }

    public void comment(XMLStreamReader xMLStreamReader) throws XMLStreamException {
        this.fEventWriter.add(this.fEventFactory.createComment(xMLStreamReader.getText()));
    }

    public void comment(Comment comment) throws XMLStreamException {
        this.fEventWriter.add(comment);
    }

    public void comment(XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void doctypeDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
    }

    public void doctypeDecl(DTD dtd) throws XMLStreamException {
        this.fEventWriter.add(dtd);
    }

    public void emptyElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        startElement(qName2, xMLAttributes, augmentations2);
        endElement(qName2, augmentations2);
    }

    public void endCDATA(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        this.fInCDATA = false;
    }

    public void endDocument(XMLStreamReader xMLStreamReader) throws XMLStreamException {
        XMLStreamReader xMLStreamReader2 = xMLStreamReader;
        this.fEventWriter.add(this.fEventFactory.createEndDocument());
        this.fEventWriter.flush();
    }

    public void endDocument(EndDocument endDocument) throws XMLStreamException {
        this.fEventWriter.add(endDocument);
        this.fEventWriter.flush();
    }

    public void endDocument(Augmentations augmentations) throws XNIException {
    }

    public void endElement(QName qName, Augmentations augmentations) throws XNIException {
        Throwable th;
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        try {
            XMLEvent currentEvent = this.fStAXValidatorHelper.getCurrentEvent();
            if (currentEvent != null) {
                this.fEventWriter.add(currentEvent);
            } else {
                this.fEventWriter.add(this.fEventFactory.createEndElement(qName2.prefix, qName2.uri, qName2.localpart, getNamespaceIterator()));
            }
        } catch (XMLStreamException e) {
            Exception exc = e;
            Throwable th2 = th;
            new XNIException(exc);
            throw th2;
        }
    }

    public void endGeneralEntity(String str, Augmentations augmentations) throws XNIException {
    }

    public void entityReference(XMLStreamReader xMLStreamReader) throws XMLStreamException {
        String localName = xMLStreamReader.getLocalName();
        this.fEventWriter.add(this.fEventFactory.createEntityReference(localName, this.fStAXValidatorHelper.getEntityDeclaration(localName)));
    }

    public void entityReference(EntityReference entityReference) throws XMLStreamException {
        this.fEventWriter.add(entityReference);
    }

    public XMLDocumentSource getDocumentSource() {
        return null;
    }

    public void ignorableWhitespace(XMLString xMLString, Augmentations augmentations) throws XNIException {
        characters(xMLString, augmentations);
    }

    public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void processingInstruction(XMLStreamReader xMLStreamReader) throws XMLStreamException {
        XMLStreamReader xMLStreamReader2 = xMLStreamReader;
        String pIData = xMLStreamReader2.getPIData();
        this.fEventWriter.add(this.fEventFactory.createProcessingInstruction(xMLStreamReader2.getPITarget(), pIData != null ? pIData : ""));
    }

    public void processingInstruction(ProcessingInstruction processingInstruction) throws XMLStreamException {
        this.fEventWriter.add(processingInstruction);
    }

    public void setDocumentSource(XMLDocumentSource xMLDocumentSource) {
    }

    public void setIgnoringCharacters(boolean z) {
        boolean z2 = z;
        this.fIgnoreChars = z2;
    }

    public void setStAXResult(StAXResult stAXResult) {
        StAXResult stAXResult2 = stAXResult;
        this.fIgnoreChars = false;
        this.fInCDATA = false;
        this.fEventWriter = stAXResult2 != null ? stAXResult2.getXMLEventWriter() : null;
    }

    public void startCDATA(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        this.fInCDATA = true;
    }

    public void startDocument(XMLStreamReader xMLStreamReader) throws XMLStreamException {
        XMLStreamReader xMLStreamReader2 = xMLStreamReader;
        String version = xMLStreamReader2.getVersion();
        String characterEncodingScheme = xMLStreamReader2.getCharacterEncodingScheme();
        this.fEventWriter.add(this.fEventFactory.createStartDocument(characterEncodingScheme != null ? characterEncodingScheme : "UTF-8", version != null ? version : BuildConfig.VERSION_NAME, xMLStreamReader2.standaloneSet()));
    }

    public void startDocument(StartDocument startDocument) throws XMLStreamException {
        this.fEventWriter.add(startDocument);
    }

    public void startDocument(XMLLocator xMLLocator, String str, org.apache.xerces.xni.NamespaceContext namespaceContext, Augmentations augmentations) throws XNIException {
    }

    public void startElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        Throwable th;
        XMLEvent currentEvent;
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        try {
            int length = xMLAttributes2.getLength();
            if (length != 0 || (currentEvent = this.fStAXValidatorHelper.getCurrentEvent()) == null) {
                this.fEventWriter.add(this.fEventFactory.createStartElement(qName2.prefix, qName2.uri != null ? qName2.uri : "", qName2.localpart, getAttributeIterator(xMLAttributes2, length), getNamespaceIterator(), this.fNamespaceContext.getNamespaceContext()));
            } else {
                this.fEventWriter.add(currentEvent);
            }
        } catch (XMLStreamException e) {
            Exception exc = e;
            Throwable th2 = th;
            new XNIException(exc);
            throw th2;
        }
    }

    public void startGeneralEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
    }

    public void textDecl(String str, String str2, Augmentations augmentations) throws XNIException {
    }

    public void xmlDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
    }
}
