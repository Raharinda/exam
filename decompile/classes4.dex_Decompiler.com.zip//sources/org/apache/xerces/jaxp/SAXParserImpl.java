package org.apache.xerces.jaxp;

import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Map;
import javax.xml.parsers.SAXParser;
import javax.xml.validation.Schema;
import org.apache.xerces.impl.validation.ValidationManager;
import org.apache.xerces.impl.xs.XMLSchemaValidator;
import org.apache.xerces.jaxp.validation.XSGrammarPoolContainer;
import org.apache.xerces.util.SAXMessageFormatter;
import org.apache.xerces.util.SecurityManager;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.parser.XMLComponent;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLDocumentSource;
import org.apache.xerces.xni.parser.XMLParserConfiguration;
import org.apache.xerces.xs.AttributePSVI;
import org.apache.xerces.xs.ElementPSVI;
import org.apache.xerces.xs.PSVIProvider;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.DocumentHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.HandlerBase;
import org.xml.sax.InputSource;
import org.xml.sax.Parser;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

public class SAXParserImpl extends SAXParser implements JAXPConstants, PSVIProvider {
    private static final String NAMESPACES_FEATURE = "http://xml.org/sax/features/namespaces";
    private static final String NAMESPACE_PREFIXES_FEATURE = "http://xml.org/sax/features/namespace-prefixes";
    private static final String SECURITY_MANAGER = "http://apache.org/xml/properties/security-manager";
    private static final String VALIDATION_FEATURE = "http://xml.org/sax/features/validation";
    private static final String XINCLUDE_FEATURE = "http://apache.org/xml/features/xinclude";
    private static final String XMLSCHEMA_VALIDATION_FEATURE = "http://apache.org/xml/features/validation/schema";
    private final EntityResolver fInitEntityResolver;
    private final ErrorHandler fInitErrorHandler;
    private final ValidationManager fSchemaValidationManager;
    private final XMLComponent fSchemaValidator;
    private final XMLComponentManager fSchemaValidatorComponentManager;
    private final UnparsedEntityHandler fUnparsedEntityHandler;
    private final Schema grammar;
    private String schemaLanguage;
    private final JAXPSAXParser xmlReader;

    public static class JAXPSAXParser extends org.apache.xerces.parsers.SAXParser {
        private final HashMap fInitFeatures;
        private final HashMap fInitProperties;
        private final SAXParserImpl fSAXParser;

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        public JAXPSAXParser() {
            this((SAXParserImpl) null);
        }

        JAXPSAXParser(SAXParserImpl sAXParserImpl) {
            HashMap hashMap;
            HashMap hashMap2;
            new HashMap();
            this.fInitFeatures = hashMap;
            new HashMap();
            this.fInitProperties = hashMap2;
            this.fSAXParser = sAXParserImpl;
        }

        private void resetSchemaValidator() throws SAXException {
            Throwable th;
            try {
                SAXParserImpl.access$000(this.fSAXParser).reset(SAXParserImpl.access$500(this.fSAXParser));
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
                Throwable th2 = th;
                new SAXException(xMLConfigurationException);
                throw th2;
            }
        }

        private void setSchemaValidatorFeature(String str, boolean z) throws SAXNotRecognizedException, SAXNotSupportedException {
            Throwable th;
            Throwable th2;
            try {
                SAXParserImpl.access$000(this.fSAXParser).setFeature(str, z);
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
                String identifier = xMLConfigurationException.getIdentifier();
                if (xMLConfigurationException.getType() == 0) {
                    Throwable th3 = th2;
                    new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-not-recognized", new Object[]{identifier}));
                    throw th3;
                }
                Throwable th4 = th;
                new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-not-supported", new Object[]{identifier}));
                throw th4;
            }
        }

        private void setSchemaValidatorProperty(String str, Object obj) throws SAXNotRecognizedException, SAXNotSupportedException {
            Throwable th;
            Throwable th2;
            try {
                SAXParserImpl.access$000(this.fSAXParser).setProperty(str, obj);
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
                String identifier = xMLConfigurationException.getIdentifier();
                if (xMLConfigurationException.getType() == 0) {
                    Throwable th3 = th2;
                    new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-recognized", new Object[]{identifier}));
                    throw th3;
                }
                Throwable th4 = th;
                new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-supported", new Object[]{identifier}));
                throw th4;
            }
        }

        public synchronized boolean getFeature(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
            boolean feature;
            Throwable th;
            String str2 = str;
            synchronized (this) {
                if (str2 == null) {
                    Throwable th2 = th;
                    new NullPointerException();
                    throw th2;
                } else if (str2.equals("http://javax.xml.XMLConstants/feature/secure-processing")) {
                    try {
                        feature = super.getProperty(SAXParserImpl.SECURITY_MANAGER) != null;
                    } catch (SAXException e) {
                        SAXException sAXException = e;
                        feature = false;
                    }
                } else {
                    feature = super.getFeature(str2);
                }
            }
            return feature;
        }

        /* access modifiers changed from: package-private */
        public boolean getFeature0(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
            return super.getFeature(str);
        }

        public synchronized Object getProperty(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
            String property;
            Throwable th;
            String str2 = str;
            synchronized (this) {
                if (str2 == null) {
                    Throwable th2 = th;
                    new NullPointerException();
                    throw th2;
                }
                property = (this.fSAXParser == null || !JAXPConstants.JAXP_SCHEMA_LANGUAGE.equals(str2)) ? super.getProperty(str2) : SAXParserImpl.access$200(this.fSAXParser);
            }
            return property;
        }

        /* access modifiers changed from: package-private */
        public Object getProperty0(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
            return super.getProperty(str);
        }

        /* access modifiers changed from: package-private */
        public XMLParserConfiguration getXMLParserConfiguration() {
            return this.fConfiguration;
        }

        public void parse(String str) throws SAXException, IOException {
            String str2 = str;
            if (!(this.fSAXParser == null || SAXParserImpl.access$000(this.fSAXParser) == null)) {
                if (SAXParserImpl.access$300(this.fSAXParser) != null) {
                    SAXParserImpl.access$300(this.fSAXParser).reset();
                    SAXParserImpl.access$400(this.fSAXParser).reset();
                }
                resetSchemaValidator();
            }
            super.parse(str2);
        }

        public void parse(InputSource inputSource) throws SAXException, IOException {
            InputSource inputSource2 = inputSource;
            if (!(this.fSAXParser == null || SAXParserImpl.access$000(this.fSAXParser) == null)) {
                if (SAXParserImpl.access$300(this.fSAXParser) != null) {
                    SAXParserImpl.access$300(this.fSAXParser).reset();
                    SAXParserImpl.access$400(this.fSAXParser).reset();
                }
                resetSchemaValidator();
            }
            super.parse(inputSource2);
        }

        /* access modifiers changed from: package-private */
        public synchronized void restoreInitState() throws SAXNotRecognizedException, SAXNotSupportedException {
            synchronized (this) {
                if (!this.fInitFeatures.isEmpty()) {
                    for (Map.Entry entry : this.fInitFeatures.entrySet()) {
                        super.setFeature((String) entry.getKey(), ((Boolean) entry.getValue()).booleanValue());
                    }
                    this.fInitFeatures.clear();
                }
                if (!this.fInitProperties.isEmpty()) {
                    for (Map.Entry entry2 : this.fInitProperties.entrySet()) {
                        super.setProperty((String) entry2.getKey(), entry2.getValue());
                    }
                    this.fInitProperties.clear();
                }
            }
        }

        public synchronized void setFeature(String str, boolean z) throws SAXNotRecognizedException, SAXNotSupportedException {
            Object obj;
            Object obj2;
            Throwable th;
            String str2 = str;
            boolean z2 = z;
            synchronized (this) {
                if (str2 == null) {
                    Throwable th2 = th;
                    new NullPointerException();
                    throw th2;
                } else if (str2.equals("http://javax.xml.XMLConstants/feature/secure-processing")) {
                    if (z2) {
                        try {
                            obj = obj2;
                            new SecurityManager();
                        } catch (SAXNotRecognizedException e) {
                            SAXNotRecognizedException sAXNotRecognizedException = e;
                            if (z2) {
                                throw sAXNotRecognizedException;
                            }
                        } catch (SAXNotSupportedException e2) {
                            SAXNotSupportedException sAXNotSupportedException = e2;
                            if (z2) {
                                throw sAXNotSupportedException;
                            }
                        }
                    } else {
                        obj = null;
                    }
                    setProperty(SAXParserImpl.SECURITY_MANAGER, obj);
                } else {
                    if (!this.fInitFeatures.containsKey(str2)) {
                        Object put = this.fInitFeatures.put(str2, super.getFeature(str2) ? Boolean.TRUE : Boolean.FALSE);
                    }
                    if (!(this.fSAXParser == null || SAXParserImpl.access$000(this.fSAXParser) == null)) {
                        setSchemaValidatorFeature(str2, z2);
                    }
                    super.setFeature(str2, z2);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public void setFeature0(String str, boolean z) throws SAXNotRecognizedException, SAXNotSupportedException {
            super.setFeature(str, z);
        }

        public synchronized void setProperty(String str, Object obj) throws SAXNotRecognizedException, SAXNotSupportedException {
            Throwable th;
            Throwable th2;
            Throwable th3;
            Throwable th4;
            Throwable th5;
            String str2 = str;
            Object obj2 = obj;
            synchronized (this) {
                if (str2 == null) {
                    Throwable th6 = th5;
                    new NullPointerException();
                    throw th6;
                }
                if (this.fSAXParser != null) {
                    if (JAXPConstants.JAXP_SCHEMA_LANGUAGE.equals(str2)) {
                        if (SAXParserImpl.access$100(this.fSAXParser) != null) {
                            Throwable th7 = th4;
                            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "schema-already-specified", new Object[]{str2}));
                            throw th7;
                        } else if ("http://www.w3.org/2001/XMLSchema".equals(obj2)) {
                            if (this.fSAXParser.isValidating()) {
                                String access$202 = SAXParserImpl.access$202(this.fSAXParser, "http://www.w3.org/2001/XMLSchema");
                                setFeature(SAXParserImpl.XMLSCHEMA_VALIDATION_FEATURE, true);
                                if (!this.fInitProperties.containsKey(JAXPConstants.JAXP_SCHEMA_LANGUAGE)) {
                                    Object put = this.fInitProperties.put(JAXPConstants.JAXP_SCHEMA_LANGUAGE, super.getProperty(JAXPConstants.JAXP_SCHEMA_LANGUAGE));
                                }
                                super.setProperty(JAXPConstants.JAXP_SCHEMA_LANGUAGE, "http://www.w3.org/2001/XMLSchema");
                            }
                        } else if (obj2 == null) {
                            String access$2022 = SAXParserImpl.access$202(this.fSAXParser, (String) null);
                            setFeature(SAXParserImpl.XMLSCHEMA_VALIDATION_FEATURE, false);
                        } else {
                            Throwable th8 = th3;
                            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "schema-not-supported", (Object[]) null));
                            throw th8;
                        }
                    } else if (JAXPConstants.JAXP_SCHEMA_SOURCE.equals(str2)) {
                        if (SAXParserImpl.access$100(this.fSAXParser) != null) {
                            Throwable th9 = th2;
                            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "schema-already-specified", new Object[]{str2}));
                            throw th9;
                        }
                        String str3 = (String) getProperty(JAXPConstants.JAXP_SCHEMA_LANGUAGE);
                        if (str3 == null || !"http://www.w3.org/2001/XMLSchema".equals(str3)) {
                            Throwable th10 = th;
                            Locale locale = this.fConfiguration.getLocale();
                            Object[] objArr = new Object[2];
                            objArr[0] = JAXPConstants.JAXP_SCHEMA_LANGUAGE;
                            Object[] objArr2 = objArr;
                            objArr2[1] = JAXPConstants.JAXP_SCHEMA_SOURCE;
                            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(locale, "jaxp-order-not-supported", objArr2));
                            throw th10;
                        }
                        if (!this.fInitProperties.containsKey(JAXPConstants.JAXP_SCHEMA_SOURCE)) {
                            Object put2 = this.fInitProperties.put(JAXPConstants.JAXP_SCHEMA_SOURCE, super.getProperty(JAXPConstants.JAXP_SCHEMA_SOURCE));
                        }
                        super.setProperty(str2, obj2);
                    }
                }
                if (!this.fInitProperties.containsKey(str2)) {
                    Object put3 = this.fInitProperties.put(str2, super.getProperty(str2));
                }
                if (!(this.fSAXParser == null || SAXParserImpl.access$000(this.fSAXParser) == null)) {
                    setSchemaValidatorProperty(str2, obj2);
                }
                super.setProperty(str2, obj2);
            }
        }

        /* access modifiers changed from: package-private */
        public void setProperty0(String str, Object obj) throws SAXNotRecognizedException, SAXNotSupportedException {
            super.setProperty(str, obj);
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    SAXParserImpl(SAXParserFactoryImpl sAXParserFactoryImpl, Hashtable hashtable) throws SAXException {
        this(sAXParserFactoryImpl, hashtable, false);
    }

    SAXParserImpl(SAXParserFactoryImpl sAXParserFactoryImpl, Hashtable hashtable, boolean z) throws SAXException {
        JAXPSAXParser jAXPSAXParser;
        XMLDocumentSource xMLDocumentSource;
        XMLComponent xMLComponent;
        XMLComponent xMLComponent2;
        ValidationManager validationManager;
        UnparsedEntityHandler unparsedEntityHandler;
        XMLComponentManager xMLComponentManager;
        ErrorHandler errorHandler;
        Object obj;
        SAXParserFactoryImpl sAXParserFactoryImpl2 = sAXParserFactoryImpl;
        Hashtable hashtable2 = hashtable;
        boolean z2 = z;
        this.schemaLanguage = null;
        new JAXPSAXParser(this);
        this.xmlReader = jAXPSAXParser;
        this.xmlReader.setFeature0(NAMESPACES_FEATURE, sAXParserFactoryImpl2.isNamespaceAware());
        this.xmlReader.setFeature0(NAMESPACE_PREFIXES_FEATURE, !sAXParserFactoryImpl2.isNamespaceAware());
        if (sAXParserFactoryImpl2.isXIncludeAware()) {
            this.xmlReader.setFeature0(XINCLUDE_FEATURE, true);
        }
        if (z2) {
            new SecurityManager();
            this.xmlReader.setProperty0(SECURITY_MANAGER, obj);
        }
        setFeatures(hashtable2);
        if (sAXParserFactoryImpl2.isValidating()) {
            new DefaultValidationErrorHandler();
            this.fInitErrorHandler = errorHandler;
            this.xmlReader.setErrorHandler(this.fInitErrorHandler);
        } else {
            this.fInitErrorHandler = this.xmlReader.getErrorHandler();
        }
        this.xmlReader.setFeature0(VALIDATION_FEATURE, sAXParserFactoryImpl2.isValidating());
        this.grammar = sAXParserFactoryImpl2.getSchema();
        if (this.grammar != null) {
            XMLParserConfiguration xMLParserConfiguration = this.xmlReader.getXMLParserConfiguration();
            if (this.grammar instanceof XSGrammarPoolContainer) {
                new XMLSchemaValidator();
                xMLComponent = xMLComponent2;
                new ValidationManager();
                this.fSchemaValidationManager = validationManager;
                new UnparsedEntityHandler(this.fSchemaValidationManager);
                this.fUnparsedEntityHandler = unparsedEntityHandler;
                xMLParserConfiguration.setDTDHandler(this.fUnparsedEntityHandler);
                this.fUnparsedEntityHandler.setDTDHandler(this.xmlReader);
                this.xmlReader.setDTDSource(this.fUnparsedEntityHandler);
                new SchemaValidatorConfiguration(xMLParserConfiguration, (XSGrammarPoolContainer) this.grammar, this.fSchemaValidationManager);
                this.fSchemaValidatorComponentManager = xMLComponentManager;
            } else {
                new JAXPValidatorComponent(this.grammar.newValidatorHandler());
                xMLComponent = xMLDocumentSource;
                this.fSchemaValidationManager = null;
                this.fUnparsedEntityHandler = null;
                this.fSchemaValidatorComponentManager = xMLParserConfiguration;
            }
            xMLParserConfiguration.addRecognizedFeatures(xMLComponent.getRecognizedFeatures());
            xMLParserConfiguration.addRecognizedProperties(xMLComponent.getRecognizedProperties());
            xMLParserConfiguration.setDocumentHandler((XMLDocumentHandler) xMLComponent);
            ((XMLDocumentSource) xMLComponent).setDocumentHandler(this.xmlReader);
            this.xmlReader.setDocumentSource((XMLDocumentSource) xMLComponent);
            this.fSchemaValidator = xMLComponent;
        } else {
            this.fSchemaValidationManager = null;
            this.fUnparsedEntityHandler = null;
            this.fSchemaValidatorComponentManager = null;
            this.fSchemaValidator = null;
        }
        this.fInitEntityResolver = this.xmlReader.getEntityResolver();
    }

    static XMLComponent access$000(SAXParserImpl sAXParserImpl) {
        return sAXParserImpl.fSchemaValidator;
    }

    static Schema access$100(SAXParserImpl sAXParserImpl) {
        return sAXParserImpl.grammar;
    }

    static String access$200(SAXParserImpl sAXParserImpl) {
        return sAXParserImpl.schemaLanguage;
    }

    static String access$202(SAXParserImpl sAXParserImpl, String str) {
        String str2 = str;
        String str3 = str2;
        sAXParserImpl.schemaLanguage = str3;
        return str2;
    }

    static ValidationManager access$300(SAXParserImpl sAXParserImpl) {
        return sAXParserImpl.fSchemaValidationManager;
    }

    static UnparsedEntityHandler access$400(SAXParserImpl sAXParserImpl) {
        return sAXParserImpl.fUnparsedEntityHandler;
    }

    static XMLComponentManager access$500(SAXParserImpl sAXParserImpl) {
        return sAXParserImpl.fSchemaValidatorComponentManager;
    }

    private void setFeatures(Hashtable hashtable) throws SAXNotSupportedException, SAXNotRecognizedException {
        Hashtable hashtable2 = hashtable;
        if (hashtable2 != null) {
            for (Map.Entry entry : hashtable2.entrySet()) {
                this.xmlReader.setFeature0((String) entry.getKey(), ((Boolean) entry.getValue()).booleanValue());
            }
        }
    }

    public AttributePSVI getAttributePSVI(int i) {
        return this.xmlReader.getAttributePSVI(i);
    }

    public AttributePSVI getAttributePSVIByName(String str, String str2) {
        return this.xmlReader.getAttributePSVIByName(str, str2);
    }

    public ElementPSVI getElementPSVI() {
        return this.xmlReader.getElementPSVI();
    }

    public Parser getParser() throws SAXException {
        return this.xmlReader;
    }

    public Object getProperty(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
        return this.xmlReader.getProperty(str);
    }

    public Schema getSchema() {
        return this.grammar;
    }

    public XMLReader getXMLReader() {
        return this.xmlReader;
    }

    public boolean isNamespaceAware() {
        Throwable th;
        try {
            return this.xmlReader.getFeature(NAMESPACES_FEATURE);
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new IllegalStateException(sAXException.getMessage());
            throw th2;
        }
    }

    public boolean isValidating() {
        Throwable th;
        try {
            return this.xmlReader.getFeature(VALIDATION_FEATURE);
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new IllegalStateException(sAXException.getMessage());
            throw th2;
        }
    }

    public boolean isXIncludeAware() {
        try {
            return this.xmlReader.getFeature(XINCLUDE_FEATURE);
        } catch (SAXException e) {
            SAXException sAXException = e;
            return false;
        }
    }

    public void parse(InputSource inputSource, HandlerBase handlerBase) throws SAXException, IOException {
        Throwable th;
        InputSource inputSource2 = inputSource;
        HandlerBase handlerBase2 = handlerBase;
        if (inputSource2 == null) {
            Throwable th2 = th;
            new IllegalArgumentException();
            throw th2;
        }
        if (handlerBase2 != null) {
            this.xmlReader.setDocumentHandler(handlerBase2);
            this.xmlReader.setEntityResolver(handlerBase2);
            this.xmlReader.setErrorHandler(handlerBase2);
            this.xmlReader.setDTDHandler(handlerBase2);
            this.xmlReader.setContentHandler((ContentHandler) null);
        }
        this.xmlReader.parse(inputSource2);
    }

    public void parse(InputSource inputSource, DefaultHandler defaultHandler) throws SAXException, IOException {
        Throwable th;
        InputSource inputSource2 = inputSource;
        DefaultHandler defaultHandler2 = defaultHandler;
        if (inputSource2 == null) {
            Throwable th2 = th;
            new IllegalArgumentException();
            throw th2;
        }
        if (defaultHandler2 != null) {
            this.xmlReader.setContentHandler(defaultHandler2);
            this.xmlReader.setEntityResolver(defaultHandler2);
            this.xmlReader.setErrorHandler(defaultHandler2);
            this.xmlReader.setDTDHandler(defaultHandler2);
            this.xmlReader.setDocumentHandler((DocumentHandler) null);
        }
        this.xmlReader.parse(inputSource2);
    }

    public void reset() {
        try {
            this.xmlReader.restoreInitState();
        } catch (SAXException e) {
            SAXException sAXException = e;
        }
        this.xmlReader.setContentHandler((ContentHandler) null);
        this.xmlReader.setDTDHandler((DTDHandler) null);
        if (this.xmlReader.getErrorHandler() != this.fInitErrorHandler) {
            this.xmlReader.setErrorHandler(this.fInitErrorHandler);
        }
        if (this.xmlReader.getEntityResolver() != this.fInitEntityResolver) {
            this.xmlReader.setEntityResolver(this.fInitEntityResolver);
        }
    }

    public void setProperty(String str, Object obj) throws SAXNotRecognizedException, SAXNotSupportedException {
        this.xmlReader.setProperty(str, obj);
    }
}
