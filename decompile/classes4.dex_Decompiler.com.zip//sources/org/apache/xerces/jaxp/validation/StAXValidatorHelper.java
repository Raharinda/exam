package org.apache.xerces.jaxp.validation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.xml.stream.Location;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.DTD;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.EntityDeclaration;
import javax.xml.stream.events.Namespace;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.stax.StAXResult;
import javax.xml.transform.stax.StAXSource;
import net.lingala.zip4j.util.Zip4jConstants;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.impl.validation.EntityState;
import org.apache.xerces.impl.validation.ValidationManager;
import org.apache.xerces.impl.xs.XMLSchemaValidator;
import org.apache.xerces.util.JAXPNamespaceContextWrapper;
import org.apache.xerces.util.StAXLocationWrapper;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.util.XMLAttributesImpl;
import org.apache.xerces.util.XMLStringBuffer;
import org.apache.xerces.util.XMLSymbols;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLParseException;
import org.xml.sax.SAXException;

final class StAXValidatorHelper implements ValidatorHelper, EntityState {
    private static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
    private static final String SCHEMA_VALIDATOR = "http://apache.org/xml/properties/internal/validator/schema";
    private static final String STRING_INTERNING = "javax.xml.stream.isInterning";
    private static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    private static final String VALIDATION_MANAGER = "http://apache.org/xml/properties/internal/validation-manager";
    final QName fAttributeQName;
    final XMLAttributesImpl fAttributes;
    private final XMLSchemaValidatorComponentManager fComponentManager;
    private XMLEvent fCurrentEvent = null;
    final ArrayList fDeclaredPrefixes;
    private int fDepth = 0;
    final QName fElementQName;
    private HashMap fEntities = null;
    private final XMLErrorReporter fErrorReporter;
    private EventHelper fEventHelper;
    private final JAXPNamespaceContextWrapper fNamespaceContext;
    private final XMLSchemaValidator fSchemaValidator;
    private StAXEventResultBuilder fStAXEventResultBuilder;
    private final StAXLocationWrapper fStAXLocationWrapper;
    private StAXStreamResultBuilder fStAXStreamResultBuilder;
    private StAXDocumentHandler fStAXValidatorHandler;
    private StreamHelper fStreamHelper;
    final XMLStringBuffer fStringBuffer;
    private boolean fStringsInternalized = false;
    private final SymbolTable fSymbolTable;
    final XMLString fTempString;
    private final ValidationManager fValidationManager;
    private final XMLStreamReaderLocation fXMLStreamReaderLocation;

    final class EventHelper {
        private static final int CHUNK_MASK = 1023;
        private static final int CHUNK_SIZE = 1024;
        private final char[] fCharBuffer = new char[1024];
        private final StAXValidatorHelper this$0;

        EventHelper(StAXValidatorHelper stAXValidatorHelper) {
            this.this$0 = stAXValidatorHelper;
        }

        private void fillDeclaredPrefixes(Iterator it) {
            Iterator it2 = it;
            this.this$0.fDeclaredPrefixes.clear();
            while (it2.hasNext()) {
                String prefix = ((Namespace) it2.next()).getPrefix();
                boolean add = this.this$0.fDeclaredPrefixes.add(prefix != null ? prefix : "");
            }
        }

        private void fillDeclaredPrefixes(EndElement endElement) {
            fillDeclaredPrefixes(endElement.getNamespaces());
        }

        private void fillDeclaredPrefixes(StartElement startElement) {
            fillDeclaredPrefixes(startElement.getNamespaces());
        }

        private void fillQName(QName qName, javax.xml.namespace.QName qName2) {
            javax.xml.namespace.QName qName3 = qName2;
            this.this$0.fillQName(qName, qName3.getNamespaceURI(), qName3.getLocalPart(), qName3.getPrefix());
        }

        private void fillXMLAttributes(StartElement startElement) {
            this.this$0.fAttributes.removeAllAttributes();
            Iterator attributes = startElement.getAttributes();
            while (attributes.hasNext()) {
                Attribute attribute = (Attribute) attributes.next();
                fillQName(this.this$0.fAttributeQName, attribute.getName());
                String dTDType = attribute.getDTDType();
                int length = this.this$0.fAttributes.getLength();
                this.this$0.fAttributes.addAttributeNS(this.this$0.fAttributeQName, dTDType != null ? dTDType : XMLSymbols.fCDATASymbol, attribute.getValue());
                this.this$0.fAttributes.setSpecified(length, attribute.isSpecified());
            }
        }

        private void sendCharactersToValidator(String str) {
            String str2 = str;
            if (str2 != null) {
                int length = str2.length();
                int i = length & CHUNK_MASK;
                if (i > 0) {
                    str2.getChars(0, i, this.fCharBuffer, 0);
                    this.this$0.fTempString.setValues(this.fCharBuffer, 0, i);
                    StAXValidatorHelper.access$400(this.this$0).characters(this.this$0.fTempString, (Augmentations) null);
                }
                int i2 = i;
                while (i2 < length) {
                    int i3 = i2 + 1024;
                    i2 = i3;
                    str2.getChars(i2, i3, this.fCharBuffer, 0);
                    this.this$0.fTempString.setValues(this.fCharBuffer, 0, 1024);
                    StAXValidatorHelper.access$400(this.this$0).characters(this.this$0.fTempString, (Augmentations) null);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public final void validate(XMLEventReader xMLEventReader, StAXResult stAXResult) throws SAXException, XMLStreamException {
            Throwable th;
            XMLEventReader xMLEventReader2 = xMLEventReader;
            StAXResult stAXResult2 = stAXResult;
            XMLEvent access$702 = StAXValidatorHelper.access$702(this.this$0, xMLEventReader2.peek());
            if (StAXValidatorHelper.access$700(this.this$0) != null) {
                int eventType = StAXValidatorHelper.access$700(this.this$0).getEventType();
                if (eventType == 7 || eventType == 1) {
                    this.this$0.setup((Location) null, stAXResult2, false);
                    StAXValidatorHelper.access$400(this.this$0).startDocument(StAXValidatorHelper.access$200(this.this$0), (String) null, StAXValidatorHelper.access$300(this.this$0), (Augmentations) null);
                    while (xMLEventReader2.hasNext()) {
                        XMLEvent access$7022 = StAXValidatorHelper.access$702(this.this$0, xMLEventReader2.nextEvent());
                        switch (StAXValidatorHelper.access$700(this.this$0).getEventType()) {
                            case 1:
                                int access$504 = StAXValidatorHelper.access$504(this.this$0);
                                StartElement asStartElement = StAXValidatorHelper.access$700(this.this$0).asStartElement();
                                fillQName(this.this$0.fElementQName, asStartElement.getName());
                                fillXMLAttributes(asStartElement);
                                fillDeclaredPrefixes(asStartElement);
                                StAXValidatorHelper.access$300(this.this$0).setNamespaceContext(asStartElement.getNamespaceContext());
                                StAXValidatorHelper.access$200(this.this$0).setLocation(asStartElement.getLocation());
                                StAXValidatorHelper.access$400(this.this$0).startElement(this.this$0.fElementQName, this.this$0.fAttributes, (Augmentations) null);
                                continue;
                            case 2:
                                EndElement asEndElement = StAXValidatorHelper.access$700(this.this$0).asEndElement();
                                fillQName(this.this$0.fElementQName, asEndElement.getName());
                                fillDeclaredPrefixes(asEndElement);
                                StAXValidatorHelper.access$200(this.this$0).setLocation(asEndElement.getLocation());
                                StAXValidatorHelper.access$400(this.this$0).endElement(this.this$0.fElementQName, (Augmentations) null);
                                if (StAXValidatorHelper.access$506(this.this$0) <= 0) {
                                    break;
                                } else {
                                    continue;
                                }
                            case 3:
                                if (StAXValidatorHelper.access$600(this.this$0) != null) {
                                    StAXValidatorHelper.access$600(this.this$0).processingInstruction(StAXValidatorHelper.access$700(this.this$0));
                                    break;
                                } else {
                                    continue;
                                }
                            case 4:
                            case 6:
                                if (StAXValidatorHelper.access$600(this.this$0) == null) {
                                    sendCharactersToValidator(StAXValidatorHelper.access$700(this.this$0).asCharacters().getData());
                                    break;
                                } else {
                                    Characters asCharacters = StAXValidatorHelper.access$700(this.this$0).asCharacters();
                                    StAXValidatorHelper.access$600(this.this$0).setIgnoringCharacters(true);
                                    sendCharactersToValidator(asCharacters.getData());
                                    StAXValidatorHelper.access$600(this.this$0).setIgnoringCharacters(false);
                                    StAXValidatorHelper.access$600(this.this$0).characters(asCharacters);
                                    continue;
                                }
                            case 5:
                                if (StAXValidatorHelper.access$600(this.this$0) != null) {
                                    StAXValidatorHelper.access$600(this.this$0).comment(StAXValidatorHelper.access$700(this.this$0));
                                    break;
                                } else {
                                    continue;
                                }
                            case Zip4jConstants.DEFLATE_LEVEL_MAXIMUM:
                                int access$5042 = StAXValidatorHelper.access$504(this.this$0);
                                if (StAXValidatorHelper.access$600(this.this$0) != null) {
                                    StAXValidatorHelper.access$600(this.this$0).startDocument(StAXValidatorHelper.access$700(this.this$0));
                                    break;
                                } else {
                                    continue;
                                }
                            case 8:
                                if (StAXValidatorHelper.access$600(this.this$0) != null) {
                                    StAXValidatorHelper.access$600(this.this$0).endDocument(StAXValidatorHelper.access$700(this.this$0));
                                    break;
                                } else {
                                    continue;
                                }
                            case Zip4jConstants.DEFLATE_LEVEL_ULTRA:
                                if (StAXValidatorHelper.access$600(this.this$0) != null) {
                                    StAXValidatorHelper.access$600(this.this$0).entityReference(StAXValidatorHelper.access$700(this.this$0));
                                    break;
                                } else {
                                    continue;
                                }
                            case 11:
                                DTD access$700 = StAXValidatorHelper.access$700(this.this$0);
                                this.this$0.processEntityDeclarations(access$700.getEntities());
                                if (StAXValidatorHelper.access$600(this.this$0) != null) {
                                    StAXValidatorHelper.access$600(this.this$0).doctypeDecl(access$700);
                                    break;
                                } else {
                                    continue;
                                }
                            case 12:
                                if (StAXValidatorHelper.access$600(this.this$0) == null) {
                                    StAXValidatorHelper.access$400(this.this$0).startCDATA((Augmentations) null);
                                    sendCharactersToValidator(StAXValidatorHelper.access$700(this.this$0).asCharacters().getData());
                                    StAXValidatorHelper.access$400(this.this$0).endCDATA((Augmentations) null);
                                    break;
                                } else {
                                    Characters asCharacters2 = StAXValidatorHelper.access$700(this.this$0).asCharacters();
                                    StAXValidatorHelper.access$600(this.this$0).setIgnoringCharacters(true);
                                    StAXValidatorHelper.access$400(this.this$0).startCDATA((Augmentations) null);
                                    sendCharactersToValidator(StAXValidatorHelper.access$700(this.this$0).asCharacters().getData());
                                    StAXValidatorHelper.access$400(this.this$0).endCDATA((Augmentations) null);
                                    StAXValidatorHelper.access$600(this.this$0).setIgnoringCharacters(false);
                                    StAXValidatorHelper.access$600(this.this$0).cdata(asCharacters2);
                                    continue;
                                }
                        }
                        StAXValidatorHelper.access$400(this.this$0).endDocument((Augmentations) null);
                        return;
                    }
                    StAXValidatorHelper.access$400(this.this$0).endDocument((Augmentations) null);
                    return;
                }
                Throwable th2 = th;
                new SAXException(JAXPValidationMessageFormatter.formatMessage(StAXValidatorHelper.access$000(this.this$0).getLocale(), "StAXIllegalInitialState", (Object[]) null));
                throw th2;
            }
        }
    }

    final class StreamHelper {
        private final StAXValidatorHelper this$0;

        StreamHelper(StAXValidatorHelper stAXValidatorHelper) {
            this.this$0 = stAXValidatorHelper;
        }

        private void fillDeclaredPrefixes(XMLStreamReader xMLStreamReader) {
            XMLStreamReader xMLStreamReader2 = xMLStreamReader;
            this.this$0.fDeclaredPrefixes.clear();
            int namespaceCount = xMLStreamReader2.getNamespaceCount();
            for (int i = 0; i < namespaceCount; i++) {
                String namespacePrefix = xMLStreamReader2.getNamespacePrefix(i);
                boolean add = this.this$0.fDeclaredPrefixes.add(namespacePrefix != null ? namespacePrefix : "");
            }
        }

        private void fillXMLAttributes(XMLStreamReader xMLStreamReader) {
            XMLStreamReader xMLStreamReader2 = xMLStreamReader;
            this.this$0.fAttributes.removeAllAttributes();
            int attributeCount = xMLStreamReader2.getAttributeCount();
            for (int i = 0; i < attributeCount; i++) {
                this.this$0.fillQName(this.this$0.fAttributeQName, xMLStreamReader2.getAttributeNamespace(i), xMLStreamReader2.getAttributeLocalName(i), xMLStreamReader2.getAttributePrefix(i));
                String attributeType = xMLStreamReader2.getAttributeType(i);
                this.this$0.fAttributes.addAttributeNS(this.this$0.fAttributeQName, attributeType != null ? attributeType : XMLSymbols.fCDATASymbol, xMLStreamReader2.getAttributeValue(i));
                this.this$0.fAttributes.setSpecified(i, xMLStreamReader2.isAttributeSpecified(i));
            }
        }

        /* access modifiers changed from: package-private */
        /* JADX WARNING: Removed duplicated region for block: B:23:0x00ad  */
        /* JADX WARNING: Removed duplicated region for block: B:26:0x00bc  */
        /* JADX WARNING: Removed duplicated region for block: B:27:0x010d  */
        /* JADX WARNING: Removed duplicated region for block: B:28:0x0154  */
        /* JADX WARNING: Removed duplicated region for block: B:29:0x017d  */
        /* JADX WARNING: Removed duplicated region for block: B:30:0x01bc  */
        /* JADX WARNING: Removed duplicated region for block: B:33:0x01d9  */
        /* JADX WARNING: Removed duplicated region for block: B:36:0x01ef  */
        /* JADX WARNING: Removed duplicated region for block: B:39:0x0205  */
        /* JADX WARNING: Removed duplicated region for block: B:42:0x021b  */
        /* JADX WARNING: Removed duplicated region for block: B:48:? A[RETURN, SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final void validate(javax.xml.stream.XMLStreamReader r13, javax.xml.transform.stax.StAXResult r14) throws org.xml.sax.SAXException, javax.xml.stream.XMLStreamException {
            /*
                r12 = this;
                r0 = r12
                r1 = r13
                r2 = r14
                r6 = r1
                boolean r6 = r6.hasNext()
                if (r6 == 0) goto L_0x00b8
                r6 = r1
                int r6 = r6.getEventType()
                r3 = r6
                r6 = r3
                r7 = 7
                if (r6 == r7) goto L_0x0034
                r6 = r3
                r7 = 1
                if (r6 == r7) goto L_0x0034
                org.xml.sax.SAXException r6 = new org.xml.sax.SAXException
                r11 = r6
                r6 = r11
                r7 = r11
                r8 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r8 = r8.this$0
                org.apache.xerces.jaxp.validation.XMLSchemaValidatorComponentManager r8 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$000(r8)
                java.util.Locale r8 = r8.getLocale()
                java.lang.String r9 = "StAXIllegalInitialState"
                r10 = 0
                java.lang.String r8 = org.apache.xerces.jaxp.validation.JAXPValidationMessageFormatter.formatMessage(r8, r9, r10)
                r7.<init>(r8)
                throw r6
            L_0x0034:
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper$XMLStreamReaderLocation r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$100(r6)
                r7 = r1
                r6.setXMLStreamReader(r7)
                java.lang.Boolean r6 = java.lang.Boolean.FALSE
                r4 = r6
                r6 = r1
                java.lang.String r7 = "javax.xml.stream.isInterning"
                java.lang.Object r6 = r6.getProperty(r7)     // Catch:{ Exception -> 0x00b9 }
                r4 = r6
            L_0x004b:
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                r7 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r7 = r7.this$0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper$XMLStreamReaderLocation r7 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$100(r7)
                r8 = r2
                java.lang.Boolean r9 = java.lang.Boolean.TRUE
                r10 = r4
                boolean r9 = r9.equals(r10)
                r6.setup(r7, r8, r9)
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.impl.xs.XMLSchemaValidator r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$400(r6)
                r7 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r7 = r7.this$0
                org.apache.xerces.util.StAXLocationWrapper r7 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$200(r7)
                r8 = 0
                r9 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r9 = r9.this$0
                org.apache.xerces.util.JAXPNamespaceContextWrapper r9 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$300(r9)
                r10 = 0
                r6.startDocument(r7, r8, r9, r10)
            L_0x007a:
                r6 = r3
                switch(r6) {
                    case 1: goto L_0x00bc;
                    case 2: goto L_0x010d;
                    case 3: goto L_0x01d9;
                    case 4: goto L_0x0154;
                    case 5: goto L_0x01ef;
                    case 6: goto L_0x0154;
                    case 7: goto L_0x01bc;
                    case 8: goto L_0x007e;
                    case 9: goto L_0x0205;
                    case 10: goto L_0x007e;
                    case 11: goto L_0x021b;
                    case 12: goto L_0x017d;
                    default: goto L_0x007e;
                }
            L_0x007e:
                r6 = r1
                int r6 = r6.next()
                r3 = r6
                r6 = r1
                boolean r6 = r6.hasNext()
                if (r6 == 0) goto L_0x0094
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                int r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$500(r6)
                if (r6 > 0) goto L_0x007a
            L_0x0094:
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.impl.xs.XMLSchemaValidator r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$400(r6)
                r7 = 0
                r6.endDocument(r7)
                r6 = r3
                r7 = 8
                if (r6 != r7) goto L_0x00b8
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.jaxp.validation.StAXDocumentHandler r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$600(r6)
                if (r6 == 0) goto L_0x00b8
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.jaxp.validation.StAXDocumentHandler r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$600(r6)
                r7 = r1
                r6.endDocument((javax.xml.stream.XMLStreamReader) r7)
            L_0x00b8:
                return
            L_0x00b9:
                r6 = move-exception
                r5 = r6
                goto L_0x004b
            L_0x00bc:
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                int r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$504(r6)
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                r7 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r7 = r7.this$0
                org.apache.xerces.xni.QName r7 = r7.fElementQName
                r8 = r1
                java.lang.String r8 = r8.getNamespaceURI()
                r9 = r1
                java.lang.String r9 = r9.getLocalName()
                r10 = r1
                java.lang.String r10 = r10.getPrefix()
                r6.fillQName(r7, r8, r9, r10)
                r6 = r0
                r7 = r1
                r6.fillXMLAttributes(r7)
                r6 = r0
                r7 = r1
                r6.fillDeclaredPrefixes(r7)
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.util.JAXPNamespaceContextWrapper r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$300(r6)
                r7 = r1
                javax.xml.namespace.NamespaceContext r7 = r7.getNamespaceContext()
                r6.setNamespaceContext(r7)
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.impl.xs.XMLSchemaValidator r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$400(r6)
                r7 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r7 = r7.this$0
                org.apache.xerces.xni.QName r7 = r7.fElementQName
                r8 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r8 = r8.this$0
                org.apache.xerces.util.XMLAttributesImpl r8 = r8.fAttributes
                r9 = 0
                r6.startElement(r7, r8, r9)
                goto L_0x007e
            L_0x010d:
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                r7 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r7 = r7.this$0
                org.apache.xerces.xni.QName r7 = r7.fElementQName
                r8 = r1
                java.lang.String r8 = r8.getNamespaceURI()
                r9 = r1
                java.lang.String r9 = r9.getLocalName()
                r10 = r1
                java.lang.String r10 = r10.getPrefix()
                r6.fillQName(r7, r8, r9, r10)
                r6 = r0
                r7 = r1
                r6.fillDeclaredPrefixes(r7)
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.util.JAXPNamespaceContextWrapper r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$300(r6)
                r7 = r1
                javax.xml.namespace.NamespaceContext r7 = r7.getNamespaceContext()
                r6.setNamespaceContext(r7)
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.impl.xs.XMLSchemaValidator r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$400(r6)
                r7 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r7 = r7.this$0
                org.apache.xerces.xni.QName r7 = r7.fElementQName
                r8 = 0
                r6.endElement(r7, r8)
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                int r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$506(r6)
                goto L_0x007e
            L_0x0154:
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.xni.XMLString r6 = r6.fTempString
                r7 = r1
                char[] r7 = r7.getTextCharacters()
                r8 = r1
                int r8 = r8.getTextStart()
                r9 = r1
                int r9 = r9.getTextLength()
                r6.setValues(r7, r8, r9)
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.impl.xs.XMLSchemaValidator r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$400(r6)
                r7 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r7 = r7.this$0
                org.apache.xerces.xni.XMLString r7 = r7.fTempString
                r8 = 0
                r6.characters(r7, r8)
                goto L_0x007e
            L_0x017d:
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.impl.xs.XMLSchemaValidator r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$400(r6)
                r7 = 0
                r6.startCDATA(r7)
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.xni.XMLString r6 = r6.fTempString
                r7 = r1
                char[] r7 = r7.getTextCharacters()
                r8 = r1
                int r8 = r8.getTextStart()
                r9 = r1
                int r9 = r9.getTextLength()
                r6.setValues(r7, r8, r9)
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.impl.xs.XMLSchemaValidator r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$400(r6)
                r7 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r7 = r7.this$0
                org.apache.xerces.xni.XMLString r7 = r7.fTempString
                r8 = 0
                r6.characters(r7, r8)
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.impl.xs.XMLSchemaValidator r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$400(r6)
                r7 = 0
                r6.endCDATA(r7)
                goto L_0x007e
            L_0x01bc:
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                int r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$504(r6)
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.jaxp.validation.StAXDocumentHandler r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$600(r6)
                if (r6 == 0) goto L_0x007e
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.jaxp.validation.StAXDocumentHandler r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$600(r6)
                r7 = r1
                r6.startDocument((javax.xml.stream.XMLStreamReader) r7)
                goto L_0x007e
            L_0x01d9:
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.jaxp.validation.StAXDocumentHandler r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$600(r6)
                if (r6 == 0) goto L_0x007e
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.jaxp.validation.StAXDocumentHandler r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$600(r6)
                r7 = r1
                r6.processingInstruction((javax.xml.stream.XMLStreamReader) r7)
                goto L_0x007e
            L_0x01ef:
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.jaxp.validation.StAXDocumentHandler r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$600(r6)
                if (r6 == 0) goto L_0x007e
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.jaxp.validation.StAXDocumentHandler r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$600(r6)
                r7 = r1
                r6.comment((javax.xml.stream.XMLStreamReader) r7)
                goto L_0x007e
            L_0x0205:
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.jaxp.validation.StAXDocumentHandler r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$600(r6)
                if (r6 == 0) goto L_0x007e
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                org.apache.xerces.jaxp.validation.StAXDocumentHandler r6 = org.apache.xerces.jaxp.validation.StAXValidatorHelper.access$600(r6)
                r7 = r1
                r6.entityReference((javax.xml.stream.XMLStreamReader) r7)
                goto L_0x007e
            L_0x021b:
                r6 = r0
                org.apache.xerces.jaxp.validation.StAXValidatorHelper r6 = r6.this$0
                r7 = r1
                java.lang.String r8 = "javax.xml.stream.entities"
                java.lang.Object r7 = r7.getProperty(r8)
                java.util.List r7 = (java.util.List) r7
                r6.processEntityDeclarations(r7)
                goto L_0x007e
            */
            throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.jaxp.validation.StAXValidatorHelper.StreamHelper.validate(javax.xml.stream.XMLStreamReader, javax.xml.transform.stax.StAXResult):void");
        }
    }

    static final class XMLStreamReaderLocation implements Location {
        private XMLStreamReader reader;

        public XMLStreamReaderLocation() {
        }

        private Location getLocation() {
            return this.reader != null ? this.reader.getLocation() : null;
        }

        public int getCharacterOffset() {
            Location location = getLocation();
            if (location != null) {
                return location.getCharacterOffset();
            }
            return -1;
        }

        public int getColumnNumber() {
            Location location = getLocation();
            if (location != null) {
                return location.getColumnNumber();
            }
            return -1;
        }

        public int getLineNumber() {
            Location location = getLocation();
            if (location != null) {
                return location.getLineNumber();
            }
            return -1;
        }

        public String getPublicId() {
            Location location = getLocation();
            if (location != null) {
                return location.getPublicId();
            }
            return null;
        }

        public String getSystemId() {
            Location location = getLocation();
            if (location != null) {
                return location.getSystemId();
            }
            return null;
        }

        public void setXMLStreamReader(XMLStreamReader xMLStreamReader) {
            XMLStreamReader xMLStreamReader2 = xMLStreamReader;
            this.reader = xMLStreamReader2;
        }
    }

    public StAXValidatorHelper(XMLSchemaValidatorComponentManager xMLSchemaValidatorComponentManager) {
        StAXLocationWrapper stAXLocationWrapper;
        XMLStreamReaderLocation xMLStreamReaderLocation;
        QName qName;
        QName qName2;
        XMLAttributesImpl xMLAttributesImpl;
        ArrayList arrayList;
        XMLString xMLString;
        XMLStringBuffer xMLStringBuffer;
        JAXPNamespaceContextWrapper jAXPNamespaceContextWrapper;
        new StAXLocationWrapper();
        this.fStAXLocationWrapper = stAXLocationWrapper;
        new XMLStreamReaderLocation();
        this.fXMLStreamReaderLocation = xMLStreamReaderLocation;
        new QName();
        this.fElementQName = qName;
        new QName();
        this.fAttributeQName = qName2;
        new XMLAttributesImpl();
        this.fAttributes = xMLAttributesImpl;
        new ArrayList();
        this.fDeclaredPrefixes = arrayList;
        new XMLString();
        this.fTempString = xMLString;
        new XMLStringBuffer();
        this.fStringBuffer = xMLStringBuffer;
        this.fComponentManager = xMLSchemaValidatorComponentManager;
        this.fErrorReporter = (XMLErrorReporter) this.fComponentManager.getProperty(ERROR_REPORTER);
        this.fSchemaValidator = (XMLSchemaValidator) this.fComponentManager.getProperty(SCHEMA_VALIDATOR);
        this.fSymbolTable = (SymbolTable) this.fComponentManager.getProperty(SYMBOL_TABLE);
        this.fValidationManager = (ValidationManager) this.fComponentManager.getProperty(VALIDATION_MANAGER);
        new JAXPNamespaceContextWrapper(this.fSymbolTable);
        this.fNamespaceContext = jAXPNamespaceContextWrapper;
        this.fNamespaceContext.setDeclaredPrefixes(this.fDeclaredPrefixes);
    }

    static XMLSchemaValidatorComponentManager access$000(StAXValidatorHelper stAXValidatorHelper) {
        return stAXValidatorHelper.fComponentManager;
    }

    static XMLStreamReaderLocation access$100(StAXValidatorHelper stAXValidatorHelper) {
        return stAXValidatorHelper.fXMLStreamReaderLocation;
    }

    static StAXLocationWrapper access$200(StAXValidatorHelper stAXValidatorHelper) {
        return stAXValidatorHelper.fStAXLocationWrapper;
    }

    static JAXPNamespaceContextWrapper access$300(StAXValidatorHelper stAXValidatorHelper) {
        return stAXValidatorHelper.fNamespaceContext;
    }

    static XMLSchemaValidator access$400(StAXValidatorHelper stAXValidatorHelper) {
        return stAXValidatorHelper.fSchemaValidator;
    }

    static int access$500(StAXValidatorHelper stAXValidatorHelper) {
        return stAXValidatorHelper.fDepth;
    }

    static int access$504(StAXValidatorHelper stAXValidatorHelper) {
        StAXValidatorHelper stAXValidatorHelper2 = stAXValidatorHelper;
        int i = stAXValidatorHelper2.fDepth + 1;
        int i2 = i;
        stAXValidatorHelper2.fDepth = i2;
        return i;
    }

    static int access$506(StAXValidatorHelper stAXValidatorHelper) {
        StAXValidatorHelper stAXValidatorHelper2 = stAXValidatorHelper;
        int i = stAXValidatorHelper2.fDepth - 1;
        stAXValidatorHelper2.fDepth = i;
        return i;
    }

    static StAXDocumentHandler access$600(StAXValidatorHelper stAXValidatorHelper) {
        return stAXValidatorHelper.fStAXValidatorHandler;
    }

    static XMLEvent access$700(StAXValidatorHelper stAXValidatorHelper) {
        return stAXValidatorHelper.fCurrentEvent;
    }

    static XMLEvent access$702(StAXValidatorHelper stAXValidatorHelper, XMLEvent xMLEvent) {
        XMLEvent xMLEvent2 = xMLEvent;
        XMLEvent xMLEvent3 = xMLEvent2;
        stAXValidatorHelper.fCurrentEvent = xMLEvent3;
        return xMLEvent2;
    }

    private void setupStAXResultHandler(StAXResult stAXResult) {
        StAXEventResultBuilder stAXEventResultBuilder;
        StAXStreamResultBuilder stAXStreamResultBuilder;
        StAXResult stAXResult2 = stAXResult;
        if (stAXResult2 == null) {
            this.fStAXValidatorHandler = null;
            this.fSchemaValidator.setDocumentHandler((XMLDocumentHandler) null);
            return;
        }
        if (stAXResult2.getXMLStreamWriter() != null) {
            if (this.fStAXStreamResultBuilder == null) {
                new StAXStreamResultBuilder(this.fNamespaceContext);
                this.fStAXStreamResultBuilder = stAXStreamResultBuilder;
            }
            this.fStAXValidatorHandler = this.fStAXStreamResultBuilder;
            this.fStAXStreamResultBuilder.setStAXResult(stAXResult2);
        } else {
            if (this.fStAXEventResultBuilder == null) {
                new StAXEventResultBuilder(this, this.fNamespaceContext);
                this.fStAXEventResultBuilder = stAXEventResultBuilder;
            }
            this.fStAXValidatorHandler = this.fStAXEventResultBuilder;
            this.fStAXEventResultBuilder.setStAXResult(stAXResult2);
        }
        this.fSchemaValidator.setDocumentHandler(this.fStAXValidatorHandler);
    }

    /* access modifiers changed from: package-private */
    public final void fillQName(QName qName, String str, String str2, String str3) {
        QName qName2 = qName;
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        if (!this.fStringsInternalized) {
            str4 = (str4 == null || str4.length() <= 0) ? null : this.fSymbolTable.addSymbol(str4);
            str5 = str5 != null ? this.fSymbolTable.addSymbol(str5) : XMLSymbols.EMPTY_STRING;
            str6 = (str6 == null || str6.length() <= 0) ? XMLSymbols.EMPTY_STRING : this.fSymbolTable.addSymbol(str6);
        } else {
            if (str4 != null && str4.length() == 0) {
                str4 = null;
            }
            if (str5 == null) {
                str5 = XMLSymbols.EMPTY_STRING;
            }
            if (str6 == null) {
                str6 = XMLSymbols.EMPTY_STRING;
            }
        }
        String str7 = str5;
        if (str6 != XMLSymbols.EMPTY_STRING) {
            this.fStringBuffer.clear();
            this.fStringBuffer.append(str6);
            this.fStringBuffer.append(':');
            this.fStringBuffer.append(str5);
            str7 = this.fSymbolTable.addSymbol(this.fStringBuffer.ch, this.fStringBuffer.offset, this.fStringBuffer.length);
        }
        qName2.setValues(str6, str5, str7, str4);
    }

    /* access modifiers changed from: package-private */
    public final XMLEvent getCurrentEvent() {
        return this.fCurrentEvent;
    }

    /* access modifiers changed from: package-private */
    public final EntityDeclaration getEntityDeclaration(String str) {
        return this.fEntities != null ? (EntityDeclaration) this.fEntities.get(str) : null;
    }

    public boolean isEntityDeclared(String str) {
        String str2 = str;
        if (this.fEntities != null) {
            return this.fEntities.containsKey(str2);
        }
        return false;
    }

    public boolean isEntityUnparsed(String str) {
        EntityDeclaration entityDeclaration;
        String str2 = str;
        if (this.fEntities == null || (entityDeclaration = (EntityDeclaration) this.fEntities.get(str2)) == null) {
            return false;
        }
        return entityDeclaration.getNotationName() != null;
    }

    /* access modifiers changed from: package-private */
    public final void processEntityDeclarations(List list) {
        HashMap hashMap;
        List list2 = list;
        int size = list2 != null ? list2.size() : 0;
        if (size > 0) {
            if (this.fEntities == null) {
                new HashMap();
                this.fEntities = hashMap;
            }
            for (int i = 0; i < size; i++) {
                EntityDeclaration entityDeclaration = (EntityDeclaration) list2.get(i);
                Object put = this.fEntities.put(entityDeclaration.getName(), entityDeclaration);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public final void setup(Location location, StAXResult stAXResult, boolean z) {
        Location location2 = location;
        boolean z2 = z;
        this.fDepth = 0;
        this.fComponentManager.reset();
        setupStAXResultHandler(stAXResult);
        this.fValidationManager.setEntityState(this);
        if (this.fEntities != null && !this.fEntities.isEmpty()) {
            this.fEntities.clear();
        }
        this.fStAXLocationWrapper.setLocation(location2);
        this.fErrorReporter.setDocumentLocator(this.fStAXLocationWrapper);
        this.fStringsInternalized = z2;
    }

    public void validate(Source source, Result result) throws SAXException, IOException {
        Throwable th;
        EventHelper eventHelper;
        StreamHelper streamHelper;
        Throwable th2;
        Source source2 = source;
        Result result2 = result;
        if ((result2 instanceof StAXResult) || result2 == null) {
            StAXSource stAXSource = (StAXSource) source2;
            StAXResult stAXResult = (StAXResult) result2;
            try {
                XMLStreamReader xMLStreamReader = stAXSource.getXMLStreamReader();
                if (xMLStreamReader != null) {
                    if (this.fStreamHelper == null) {
                        new StreamHelper(this);
                        this.fStreamHelper = streamHelper;
                    }
                    this.fStreamHelper.validate(xMLStreamReader, stAXResult);
                } else {
                    if (this.fEventHelper == null) {
                        new EventHelper(this);
                        this.fEventHelper = eventHelper;
                    }
                    this.fEventHelper.validate(stAXSource.getXMLEventReader(), stAXResult);
                }
                this.fCurrentEvent = null;
                this.fStAXLocationWrapper.setLocation((Location) null);
                this.fXMLStreamReaderLocation.setXMLStreamReader((XMLStreamReader) null);
                if (this.fStAXValidatorHandler != null) {
                    this.fStAXValidatorHandler.setStAXResult((StAXResult) null);
                }
            } catch (XMLStreamException e) {
                Exception exc = e;
                Throwable th3 = th;
                new SAXException(exc);
                throw th3;
            } catch (XMLParseException e2) {
                throw Util.toSAXParseException(e2);
            } catch (XNIException e3) {
                throw Util.toSAXException(e3);
            } catch (Throwable th4) {
                Throwable th5 = th4;
                this.fCurrentEvent = null;
                this.fStAXLocationWrapper.setLocation((Location) null);
                this.fXMLStreamReaderLocation.setXMLStreamReader((XMLStreamReader) null);
                if (this.fStAXValidatorHandler != null) {
                    this.fStAXValidatorHandler.setStAXResult((StAXResult) null);
                }
                throw th5;
            }
        } else {
            Throwable th6 = th2;
            Locale locale = this.fComponentManager.getLocale();
            Object[] objArr = new Object[2];
            objArr[0] = source2.getClass().getName();
            Object[] objArr2 = objArr;
            objArr2[1] = result2.getClass().getName();
            new IllegalArgumentException(JAXPValidationMessageFormatter.formatMessage(locale, "SourceResultMismatch", objArr2));
            throw th6;
        }
    }
}
