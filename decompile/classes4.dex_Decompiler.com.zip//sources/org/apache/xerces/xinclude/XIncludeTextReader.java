package org.apache.xerces.xinclude;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import org.apache.xerces.dom.DOMMessageFormatter;
import org.apache.xerces.impl.XMLEntityManager;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.util.EncodingMap;
import org.apache.xerces.util.HTTPInputSource;
import org.apache.xerces.util.XMLChar;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.parser.XMLInputSource;

public class XIncludeTextReader {
    private XMLErrorReporter fErrorReporter;
    private final XIncludeHandler fHandler;
    private Reader fReader;
    private XMLInputSource fSource;
    private XMLString fTempString;

    public XIncludeTextReader(XMLInputSource xMLInputSource, XIncludeHandler xIncludeHandler, int i) throws IOException {
        XMLString xMLString;
        XMLString xMLString2;
        new XMLString();
        this.fTempString = xMLString;
        this.fHandler = xIncludeHandler;
        this.fSource = xMLInputSource;
        new XMLString(new char[(i + 1)], 0, 0);
        this.fTempString = xMLString2;
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.io.Reader createASCIIReader(java.io.InputStream r10) {
        /*
            r9 = this;
            r0 = r9
            r1 = r10
            org.apache.xerces.impl.io.ASCIIReader r2 = new org.apache.xerces.impl.io.ASCIIReader
            r8 = r2
            r2 = r8
            r3 = r8
            r4 = r1
            r5 = r0
            org.apache.xerces.xni.XMLString r5 = r5.fTempString
            char[] r5 = r5.ch
            int r5 = r5.length
            r6 = r0
            org.apache.xerces.impl.XMLErrorReporter r6 = r6.fErrorReporter
            java.lang.String r7 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            org.apache.xerces.util.MessageFormatter r6 = r6.getMessageFormatter(r7)
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r7 = r7.fErrorReporter
            java.util.Locale r7 = r7.getLocale()
            r3.<init>(r4, r5, r6, r7)
            r0 = r2
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.xinclude.XIncludeTextReader.createASCIIReader(java.io.InputStream):java.io.Reader");
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.io.Reader createLatin1Reader(java.io.InputStream r8) {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            org.apache.xerces.impl.io.Latin1Reader r2 = new org.apache.xerces.impl.io.Latin1Reader
            r6 = r2
            r2 = r6
            r3 = r6
            r4 = r1
            r5 = r0
            org.apache.xerces.xni.XMLString r5 = r5.fTempString
            char[] r5 = r5.ch
            int r5 = r5.length
            r3.<init>(r4, r5)
            r0 = r2
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.xinclude.XIncludeTextReader.createLatin1Reader(java.io.InputStream):java.io.Reader");
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.io.Reader createUTF16Reader(java.io.InputStream r12, boolean r13) {
        /*
            r11 = this;
            r0 = r11
            r1 = r12
            r2 = r13
            org.apache.xerces.impl.io.UTF16Reader r3 = new org.apache.xerces.impl.io.UTF16Reader
            r10 = r3
            r3 = r10
            r4 = r10
            r5 = r1
            r6 = r0
            org.apache.xerces.xni.XMLString r6 = r6.fTempString
            char[] r6 = r6.ch
            int r6 = r6.length
            r7 = 1
            int r6 = r6 << 1
            r7 = r2
            r8 = r0
            org.apache.xerces.impl.XMLErrorReporter r8 = r8.fErrorReporter
            java.lang.String r9 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            org.apache.xerces.util.MessageFormatter r8 = r8.getMessageFormatter(r9)
            r9 = r0
            org.apache.xerces.impl.XMLErrorReporter r9 = r9.fErrorReporter
            java.util.Locale r9 = r9.getLocale()
            r4.<init>(r5, r6, r7, r8, r9)
            r0 = r3
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.xinclude.XIncludeTextReader.createUTF16Reader(java.io.InputStream, boolean):java.io.Reader");
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.io.Reader createUTF8Reader(java.io.InputStream r10) {
        /*
            r9 = this;
            r0 = r9
            r1 = r10
            org.apache.xerces.impl.io.UTF8Reader r2 = new org.apache.xerces.impl.io.UTF8Reader
            r8 = r2
            r2 = r8
            r3 = r8
            r4 = r1
            r5 = r0
            org.apache.xerces.xni.XMLString r5 = r5.fTempString
            char[] r5 = r5.ch
            int r5 = r5.length
            r6 = r0
            org.apache.xerces.impl.XMLErrorReporter r6 = r6.fErrorReporter
            java.lang.String r7 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            org.apache.xerces.util.MessageFormatter r6 = r6.getMessageFormatter(r7)
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r7 = r7.fErrorReporter
            java.util.Locale r7 = r7.getLocale()
            r3.<init>(r4, r5, r6, r7)
            r0 = r2
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.xinclude.XIncludeTextReader.createUTF8Reader(java.io.InputStream):java.io.Reader");
    }

    public void close() throws IOException {
        if (this.fReader != null) {
            this.fReader.close();
            this.fReader = null;
        }
    }

    /* access modifiers changed from: protected */
    public String consumeBOM(InputStream inputStream, String str) throws IOException {
        InputStream inputStream2 = inputStream;
        String str2 = str;
        byte[] bArr = new byte[3];
        inputStream2.mark(3);
        if (str2.equals("UTF-8")) {
            if (inputStream2.read(bArr, 0, 3) == 3) {
                byte b = bArr[0] & 255;
                byte b2 = bArr[1] & 255;
                byte b3 = bArr[2] & 255;
                if (!(b == 239 && b2 == 187 && b3 == 191)) {
                    inputStream2.reset();
                }
            } else {
                inputStream2.reset();
            }
        } else if (str2.startsWith("UTF-16")) {
            if (inputStream2.read(bArr, 0, 2) == 2) {
                byte b4 = bArr[0] & 255;
                byte b5 = bArr[1] & 255;
                if (b4 == 254 && b5 == 255) {
                    return "UTF-16BE";
                }
                if (b4 == 255 && b5 == 254) {
                    return "UTF-16LE";
                }
            }
            inputStream2.reset();
        }
        return str2;
    }

    /* access modifiers changed from: protected */
    public String getEncodingName(InputStream inputStream) throws IOException {
        InputStream inputStream2 = inputStream;
        byte[] bArr = new byte[4];
        String str = null;
        inputStream2.mark(4);
        int read = inputStream2.read(bArr, 0, 4);
        inputStream2.reset();
        if (read == 4) {
            str = getEncodingName(bArr);
        }
        return str;
    }

    /* access modifiers changed from: protected */
    public String getEncodingName(byte[] bArr) {
        byte[] bArr2 = bArr;
        byte b = bArr2[0] & 255;
        byte b2 = bArr2[1] & 255;
        if (b == 254 && b2 == 255) {
            return "UTF-16BE";
        }
        if (b == 255 && b2 == 254) {
            return "UTF-16LE";
        }
        byte b3 = bArr2[2] & 255;
        if (b == 239 && b2 == 187 && b3 == 191) {
            return "UTF-8";
        }
        byte b4 = bArr2[3] & 255;
        if (b == 0 && b2 == 0 && b3 == 0 && b4 == 60) {
            return "ISO-10646-UCS-4";
        }
        if (b == 60 && b2 == 0 && b3 == 0 && b4 == 0) {
            return "ISO-10646-UCS-4";
        }
        if (b == 0 && b2 == 0 && b3 == 60 && b4 == 0) {
            return "ISO-10646-UCS-4";
        }
        if (b == 0 && b2 == 60 && b3 == 0 && b4 == 0) {
            return "ISO-10646-UCS-4";
        }
        if (b == 0 && b2 == 60 && b3 == 0 && b4 == 63) {
            return "UTF-16BE";
        }
        if (b == 60 && b2 == 0 && b3 == 63 && b4 == 0) {
            return "UTF-16LE";
        }
        if (b == 76 && b2 == 111 && b3 == 167 && b4 == 148) {
            return "CP037";
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public Reader getReader(XMLInputSource xMLInputSource) throws IOException {
        URL url;
        InputStream inputStream;
        InputStream inputStream2;
        String trim;
        Reader reader;
        Throwable th;
        InputStream inputStream3;
        XMLInputSource xMLInputSource2 = xMLInputSource;
        if (xMLInputSource2.getCharacterStream() != null) {
            return xMLInputSource2.getCharacterStream();
        }
        String encoding = xMLInputSource2.getEncoding();
        if (encoding == null) {
            encoding = "UTF-8";
        }
        if (xMLInputSource2.getByteStream() != null) {
            inputStream2 = xMLInputSource2.getByteStream();
            if (!(inputStream2 instanceof BufferedInputStream)) {
                new BufferedInputStream(inputStream2, this.fTempString.ch.length);
                inputStream2 = inputStream3;
            }
        } else {
            new URL(XMLEntityManager.expandSystemId(xMLInputSource2.getSystemId(), xMLInputSource2.getBaseSystemId(), false));
            URLConnection openConnection = url.openConnection();
            if ((openConnection instanceof HttpURLConnection) && (xMLInputSource2 instanceof HTTPInputSource)) {
                HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
                HTTPInputSource hTTPInputSource = (HTTPInputSource) xMLInputSource2;
                Iterator hTTPRequestProperties = hTTPInputSource.getHTTPRequestProperties();
                while (hTTPRequestProperties.hasNext()) {
                    Map.Entry entry = (Map.Entry) hTTPRequestProperties.next();
                    httpURLConnection.setRequestProperty((String) entry.getKey(), (String) entry.getValue());
                }
                boolean followHTTPRedirects = hTTPInputSource.getFollowHTTPRedirects();
                if (!followHTTPRedirects) {
                    httpURLConnection.setInstanceFollowRedirects(followHTTPRedirects);
                }
            }
            new BufferedInputStream(openConnection.getInputStream());
            inputStream2 = inputStream;
            String contentType = openConnection.getContentType();
            int indexOf = contentType != null ? contentType.indexOf(59) : -1;
            String str = null;
            if (indexOf != -1) {
                trim = contentType.substring(0, indexOf).trim();
                String trim2 = contentType.substring(indexOf + 1).trim();
                if (trim2.startsWith("charset=")) {
                    str = trim2.substring(8).trim();
                    if ((str.charAt(0) == '\"' && str.charAt(str.length() - 1) == '\"') || (str.charAt(0) == '\'' && str.charAt(str.length() - 1) == '\'')) {
                        str = str.substring(1, str.length() - 1);
                    }
                } else {
                    str = null;
                }
            } else {
                trim = contentType != null ? contentType.trim() : "";
            }
            String str2 = null;
            if (trim.equals("text/xml")) {
                str2 = str != null ? str : "US-ASCII";
            } else if (trim.equals("application/xml")) {
                str2 = str != null ? str : getEncodingName(inputStream2);
            } else if (trim.endsWith("+xml")) {
                str2 = getEncodingName(inputStream2);
            }
            if (str2 != null) {
                encoding = str2;
            }
        }
        String consumeBOM = consumeBOM(inputStream2, encoding.toUpperCase(Locale.ENGLISH));
        if (consumeBOM.equals("UTF-8")) {
            return createUTF8Reader(inputStream2);
        }
        if (consumeBOM.equals("UTF-16BE")) {
            return createUTF16Reader(inputStream2, true);
        }
        if (consumeBOM.equals("UTF-16LE")) {
            return createUTF16Reader(inputStream2, false);
        }
        String iANA2JavaMapping = EncodingMap.getIANA2JavaMapping(consumeBOM);
        if (iANA2JavaMapping == null) {
            Throwable th2 = th;
            new IOException(this.fErrorReporter.getMessageFormatter(DOMMessageFormatter.XML_DOMAIN).formatMessage(this.fErrorReporter.getLocale(), "EncodingDeclInvalid", new Object[]{consumeBOM}));
            throw th2;
        } else if (iANA2JavaMapping.equals("ASCII")) {
            return createASCIIReader(inputStream2);
        } else {
            if (iANA2JavaMapping.equals("ISO8859_1")) {
                return createLatin1Reader(inputStream2);
            }
            new InputStreamReader(inputStream2, iANA2JavaMapping);
            return reader;
        }
    }

    /* access modifiers changed from: protected */
    public boolean isValid(int i) {
        return XMLChar.isValid(i);
    }

    /* JADX WARNING: type inference failed for: r6v36, types: [int] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void parse() throws java.io.IOException {
        /*
            r15 = this;
            r0 = r15
            r6 = r0
            r7 = r0
            r8 = r0
            org.apache.xerces.xni.parser.XMLInputSource r8 = r8.fSource
            java.io.Reader r7 = r7.getReader(r8)
            r6.fReader = r7
            r6 = r0
            r7 = 0
            r6.fSource = r7
            r6 = r0
            java.io.Reader r6 = r6.fReader
            r7 = r0
            org.apache.xerces.xni.XMLString r7 = r7.fTempString
            char[] r7 = r7.ch
            r8 = 0
            r9 = r0
            org.apache.xerces.xni.XMLString r9 = r9.fTempString
            char[] r9 = r9.ch
            int r9 = r9.length
            r10 = 1
            int r9 = r9 + -1
            int r6 = r6.read(r7, r8, r9)
            r1 = r6
            r6 = r0
            org.apache.xerces.xinclude.XIncludeHandler r6 = r6.fHandler
            r7 = 1
            r6.fHasIncludeReportedContent = r7
        L_0x002d:
            r6 = r1
            r7 = -1
            if (r6 != r7) goto L_0x0032
            return
        L_0x0032:
            r6 = 0
            r2 = r6
        L_0x0034:
            r6 = r2
            r7 = r1
            if (r6 < r7) goto L_0x0076
            r6 = r0
            org.apache.xerces.xinclude.XIncludeHandler r6 = r6.fHandler
            if (r6 == 0) goto L_0x005e
            r6 = r1
            if (r6 <= 0) goto L_0x005e
            r6 = r0
            org.apache.xerces.xni.XMLString r6 = r6.fTempString
            r7 = 0
            r6.offset = r7
            r6 = r0
            org.apache.xerces.xni.XMLString r6 = r6.fTempString
            r7 = r1
            r6.length = r7
            r6 = r0
            org.apache.xerces.xinclude.XIncludeHandler r6 = r6.fHandler
            r7 = r0
            org.apache.xerces.xni.XMLString r7 = r7.fTempString
            r8 = r0
            org.apache.xerces.xinclude.XIncludeHandler r8 = r8.fHandler
            r9 = 0
            r10 = 1
            org.apache.xerces.xni.Augmentations r8 = r8.modifyAugmentations(r9, r10)
            r6.characters(r7, r8)
        L_0x005e:
            r6 = r0
            java.io.Reader r6 = r6.fReader
            r7 = r0
            org.apache.xerces.xni.XMLString r7 = r7.fTempString
            char[] r7 = r7.ch
            r8 = 0
            r9 = r0
            org.apache.xerces.xni.XMLString r9 = r9.fTempString
            char[] r9 = r9.ch
            int r9 = r9.length
            r10 = 1
            int r9 = r9 + -1
            int r6 = r6.read(r7, r8, r9)
            r1 = r6
            goto L_0x002d
        L_0x0076:
            r6 = r0
            org.apache.xerces.xni.XMLString r6 = r6.fTempString
            char[] r6 = r6.ch
            r7 = r2
            char r6 = r6[r7]
            r3 = r6
            r6 = r0
            r7 = r3
            boolean r6 = r6.isValid(r7)
            if (r6 != 0) goto L_0x00d2
            r6 = r3
            boolean r6 = org.apache.xerces.util.XMLChar.isHighSurrogate(r6)
            if (r6 == 0) goto L_0x010e
            int r2 = r2 + 1
            r6 = r2
            r7 = r1
            if (r6 >= r7) goto L_0x00d6
            r6 = r0
            org.apache.xerces.xni.XMLString r6 = r6.fTempString
            char[] r6 = r6.ch
            r7 = r2
            char r6 = r6[r7]
            r4 = r6
        L_0x009d:
            r6 = r4
            boolean r6 = org.apache.xerces.util.XMLChar.isLowSurrogate(r6)
            if (r6 == 0) goto L_0x00ef
            r6 = r3
            r7 = r4
            char r7 = (char) r7
            int r6 = org.apache.xerces.util.XMLChar.supplemental(r6, r7)
            r5 = r6
            r6 = r0
            r7 = r5
            boolean r6 = r6.isValid(r7)
            if (r6 != 0) goto L_0x00d2
            r6 = r0
            org.apache.xerces.impl.XMLErrorReporter r6 = r6.fErrorReporter
            java.lang.String r7 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            java.lang.String r8 = "InvalidCharInContent"
            r9 = 1
            java.lang.Object[] r9 = new java.lang.Object[r9]
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = 0
            r12 = r5
            r13 = 16
            java.lang.String r12 = java.lang.Integer.toString(r12, r13)
            r10[r11] = r12
            r10 = 2
            java.lang.String r6 = r6.reportError(r7, r8, r9, r10)
        L_0x00d2:
            int r2 = r2 + 1
            goto L_0x0034
        L_0x00d6:
            r6 = r0
            java.io.Reader r6 = r6.fReader
            int r6 = r6.read()
            r4 = r6
            r6 = r4
            r7 = -1
            if (r6 == r7) goto L_0x009d
            r6 = r0
            org.apache.xerces.xni.XMLString r6 = r6.fTempString
            char[] r6 = r6.ch
            r7 = r1
            int r1 = r1 + 1
            r8 = r4
            char r8 = (char) r8
            r6[r7] = r8
            goto L_0x009d
        L_0x00ef:
            r6 = r0
            org.apache.xerces.impl.XMLErrorReporter r6 = r6.fErrorReporter
            java.lang.String r7 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            java.lang.String r8 = "InvalidCharInContent"
            r9 = 1
            java.lang.Object[] r9 = new java.lang.Object[r9]
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = 0
            r12 = r4
            r13 = 16
            java.lang.String r12 = java.lang.Integer.toString(r12, r13)
            r10[r11] = r12
            r10 = 2
            java.lang.String r6 = r6.reportError(r7, r8, r9, r10)
            goto L_0x00d2
        L_0x010e:
            r6 = r0
            org.apache.xerces.impl.XMLErrorReporter r6 = r6.fErrorReporter
            java.lang.String r7 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            java.lang.String r8 = "InvalidCharInContent"
            r9 = 1
            java.lang.Object[] r9 = new java.lang.Object[r9]
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = 0
            r12 = r3
            r13 = 16
            java.lang.String r12 = java.lang.Integer.toString(r12, r13)
            r10[r11] = r12
            r10 = 2
            java.lang.String r6 = r6.reportError(r7, r8, r9, r10)
            goto L_0x00d2
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.xinclude.XIncludeTextReader.parse():void");
    }

    /* access modifiers changed from: protected */
    public void setBufferSize(int i) {
        int i2 = i + 1;
        if (this.fTempString.ch.length != i2) {
            this.fTempString.ch = new char[i2];
        }
    }

    public void setErrorReporter(XMLErrorReporter xMLErrorReporter) {
        XMLErrorReporter xMLErrorReporter2 = xMLErrorReporter;
        this.fErrorReporter = xMLErrorReporter2;
    }

    public void setInputSource(XMLInputSource xMLInputSource) {
        XMLInputSource xMLInputSource2 = xMLInputSource;
        this.fSource = xMLInputSource2;
    }
}
