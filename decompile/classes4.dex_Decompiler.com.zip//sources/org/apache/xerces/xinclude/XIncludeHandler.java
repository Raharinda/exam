package org.apache.xerces.xinclude;

import com.microsoft.appcenter.Constants;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Stack;
import java.util.StringTokenizer;
import net.lingala.zip4j.util.InternalZipConstants;
import org.apache.xerces.impl.XMLEntityManager;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.util.AugmentationsImpl;
import org.apache.xerces.util.HTTPInputSource;
import org.apache.xerces.util.IntStack;
import org.apache.xerces.util.ParserConfigurationSettings;
import org.apache.xerces.util.SecurityManager;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.util.URI;
import org.apache.xerces.util.XMLAttributesImpl;
import org.apache.xerces.util.XMLChar;
import org.apache.xerces.util.XMLLocatorWrapper;
import org.apache.xerces.util.XMLResourceIdentifierImpl;
import org.apache.xerces.util.XMLSymbols;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLDTDHandler;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLComponent;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLDTDFilter;
import org.apache.xerces.xni.parser.XMLDTDSource;
import org.apache.xerces.xni.parser.XMLDocumentFilter;
import org.apache.xerces.xni.parser.XMLDocumentSource;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLParserConfiguration;
import org.apache.xerces.xpointer.XPointerProcessor;
import org.apache.xml.serialize.Method;

public class XIncludeHandler implements XMLComponent, XMLDocumentFilter, XMLDTDFilter {
    protected static final String ALLOW_UE_AND_NOTATION_EVENTS = "http://xml.org/sax/features/allow-dtd-events-after-endDTD";
    protected static final String BUFFER_SIZE = "http://apache.org/xml/properties/input-buffer-size";
    public static final String CURRENT_BASE_URI = "currentBaseURI";
    protected static final String DYNAMIC_VALIDATION = "http://apache.org/xml/features/validation/dynamic";
    protected static final String ENTITY_RESOLVER = "http://apache.org/xml/properties/internal/entity-resolver";
    protected static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
    private static final Boolean[] FEATURE_DEFAULTS;
    public static final String HTTP_ACCEPT = "Accept";
    public static final String HTTP_ACCEPT_LANGUAGE = "Accept-Language";
    private static final int INITIAL_SIZE = 8;
    protected static final String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
    private static final QName NEW_NS_ATTR_QNAME;
    protected static final String PARSER_SETTINGS = "http://apache.org/xml/features/internal/parser-settings";
    private static final Object[] PROPERTY_DEFAULTS;
    private static final String[] RECOGNIZED_FEATURES;
    private static final String[] RECOGNIZED_PROPERTIES;
    protected static final String SCHEMA_VALIDATION = "http://apache.org/xml/features/validation/schema";
    protected static final String SECURITY_MANAGER = "http://apache.org/xml/properties/security-manager";
    private static final int STATE_EXPECT_FALLBACK = 3;
    private static final int STATE_IGNORE = 2;
    private static final int STATE_NORMAL_PROCESSING = 1;
    protected static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    protected static final String VALIDATION = "http://xml.org/sax/features/validation";
    public static final String XINCLUDE_ATTR_ACCEPT = "accept".intern();
    public static final String XINCLUDE_ATTR_ACCEPT_LANGUAGE = "accept-language".intern();
    public static final String XINCLUDE_ATTR_ENCODING = "encoding".intern();
    public static final String XINCLUDE_ATTR_HREF = "href".intern();
    public static final String XINCLUDE_ATTR_PARSE = "parse".intern();
    private static final String XINCLUDE_BASE = "base".intern();
    public static final String XINCLUDE_DEFAULT_CONFIGURATION = "org.apache.xerces.parsers.XIncludeParserConfiguration";
    public static final String XINCLUDE_FALLBACK = "fallback".intern();
    protected static final String XINCLUDE_FIXUP_BASE_URIS = "http://apache.org/xml/features/xinclude/fixup-base-uris";
    protected static final String XINCLUDE_FIXUP_LANGUAGE = "http://apache.org/xml/features/xinclude/fixup-language";
    public static final String XINCLUDE_INCLUDE = "include".intern();
    public static final String XINCLUDE_INCLUDED = "[included]".intern();
    private static final String XINCLUDE_LANG = "lang".intern();
    public static final String XINCLUDE_NS_URI = "http://www.w3.org/2001/XInclude".intern();
    public static final String XINCLUDE_PARSE_TEXT = Method.TEXT.intern();
    public static final String XINCLUDE_PARSE_XML = Method.XML.intern();
    private static final QName XML_BASE_QNAME;
    private static final QName XML_LANG_QNAME;
    public static final String XPOINTER = "xpointer";
    private static final char[] gAfterEscaping1 = new char[128];
    private static final char[] gAfterEscaping2 = new char[128];
    private static final char[] gHexChs = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
    private static final boolean[] gNeedEscaping = new boolean[128];
    protected final Stack fBaseURI;
    protected final IntStack fBaseURIScope;
    protected int fBufferSize = InternalZipConstants.UFT8_NAMES_FLAG;
    protected XMLParserConfiguration fChildConfig;
    protected final XMLResourceIdentifier fCurrentBaseURI;
    protected String fCurrentLanguage;
    protected XMLDTDHandler fDTDHandler;
    protected XMLDTDSource fDTDSource;
    private int fDepth;
    protected XMLLocator fDocLocation;
    protected XMLDocumentHandler fDocumentHandler;
    protected XMLDocumentSource fDocumentSource;
    protected XMLEntityResolver fEntityResolver;
    protected XMLErrorReporter fErrorReporter;
    protected final Stack fExpandedSystemID;
    private boolean fFixupBaseURIs;
    private boolean fFixupLanguage;
    boolean fHasIncludeReportedContent;
    protected String fHrefFromParent;
    private boolean fInDTD;
    private boolean fIsXML11;
    protected final IntStack fLanguageScope;
    protected final Stack fLanguageStack;
    protected final Stack fLiteralSystemID;
    protected XIncludeNamespaceSupport fNamespaceContext;
    private boolean fNeedCopyFeatures;
    private final ArrayList fNotations;
    protected String fParentRelativeURI;
    protected XIncludeHandler fParentXIncludeHandler;
    private int fResultDepth;
    private boolean[] fSawFallback;
    private boolean[] fSawInclude;
    protected SecurityManager fSecurityManager;
    private boolean fSeenRootElement;
    private boolean fSendUEAndNotationEvents;
    protected ParserConfigurationSettings fSettings;
    private int[] fState;
    protected SymbolTable fSymbolTable;
    private final ArrayList fUnparsedEntities;
    protected XIncludeTextReader fXInclude10TextReader;
    protected XIncludeTextReader fXInclude11TextReader;
    protected XMLParserConfiguration fXIncludeChildConfig;
    protected XMLLocatorWrapper fXIncludeLocator;
    protected XIncludeMessageFormatter fXIncludeMessageFormatter;
    protected XMLParserConfiguration fXPointerChildConfig;
    protected XPointerProcessor fXPtrProcessor = null;

    protected static class Notation {
        public Augmentations augmentations;
        public String baseURI;
        public String expandedSystemId;
        public String name;
        public String publicId;
        public String systemId;

        protected Notation() {
        }

        private boolean isEqual(String str, String str2) {
            String str3 = str;
            String str4 = str2;
            return str3 == str4 || (str3 != null && str3.equals(str4));
        }

        public boolean equals(Object obj) {
            Object obj2 = obj;
            if (obj2 == null) {
                return false;
            }
            if (!(obj2 instanceof Notation)) {
                return false;
            }
            return this.name.equals(((Notation) obj2).name);
        }

        public boolean isDuplicate(Object obj) {
            Object obj2 = obj;
            if (obj2 == null || !(obj2 instanceof Notation)) {
                return false;
            }
            Notation notation = (Notation) obj2;
            return this.name.equals(notation.name) && isEqual(this.publicId, notation.publicId) && isEqual(this.expandedSystemId, notation.expandedSystemId);
        }
    }

    protected static class UnparsedEntity {
        public Augmentations augmentations;
        public String baseURI;
        public String expandedSystemId;
        public String name;
        public String notation;
        public String publicId;
        public String systemId;

        protected UnparsedEntity() {
        }

        private boolean isEqual(String str, String str2) {
            String str3 = str;
            String str4 = str2;
            return str3 == str4 || (str3 != null && str3.equals(str4));
        }

        public boolean equals(Object obj) {
            Object obj2 = obj;
            if (obj2 == null) {
                return false;
            }
            if (!(obj2 instanceof UnparsedEntity)) {
                return false;
            }
            return this.name.equals(((UnparsedEntity) obj2).name);
        }

        public boolean isDuplicate(Object obj) {
            Object obj2 = obj;
            if (obj2 == null || !(obj2 instanceof UnparsedEntity)) {
                return false;
            }
            UnparsedEntity unparsedEntity = (UnparsedEntity) obj2;
            return this.name.equals(unparsedEntity.name) && isEqual(this.publicId, unparsedEntity.publicId) && isEqual(this.expandedSystemId, unparsedEntity.expandedSystemId) && isEqual(this.notation, unparsedEntity.notation);
        }
    }

    static {
        QName qName;
        StringBuffer stringBuffer;
        QName qName2;
        StringBuffer stringBuffer2;
        QName qName3;
        StringBuffer stringBuffer3;
        Object obj;
        String str = XMLSymbols.PREFIX_XML;
        String str2 = XINCLUDE_BASE;
        new StringBuffer();
        new QName(str, str2, stringBuffer.append(XMLSymbols.PREFIX_XML).append(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR).append(XINCLUDE_BASE).toString().intern(), NamespaceContext.XML_URI);
        XML_BASE_QNAME = qName;
        String str3 = XMLSymbols.PREFIX_XML;
        String str4 = XINCLUDE_LANG;
        new StringBuffer();
        new QName(str3, str4, stringBuffer2.append(XMLSymbols.PREFIX_XML).append(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR).append(XINCLUDE_LANG).toString().intern(), NamespaceContext.XML_URI);
        XML_LANG_QNAME = qName2;
        String str5 = XMLSymbols.PREFIX_XMLNS;
        new StringBuffer();
        new QName(str5, "", stringBuffer3.append(XMLSymbols.PREFIX_XMLNS).append(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR).toString(), NamespaceContext.XMLNS_URI);
        NEW_NS_ATTR_QNAME = qName3;
        String[] strArr = new String[3];
        strArr[0] = ALLOW_UE_AND_NOTATION_EVENTS;
        String[] strArr2 = strArr;
        strArr2[1] = XINCLUDE_FIXUP_BASE_URIS;
        String[] strArr3 = strArr2;
        strArr3[2] = XINCLUDE_FIXUP_LANGUAGE;
        RECOGNIZED_FEATURES = strArr3;
        Boolean[] boolArr = new Boolean[3];
        boolArr[0] = Boolean.TRUE;
        Boolean[] boolArr2 = boolArr;
        boolArr2[1] = Boolean.TRUE;
        Boolean[] boolArr3 = boolArr2;
        boolArr3[2] = Boolean.TRUE;
        FEATURE_DEFAULTS = boolArr3;
        String[] strArr4 = new String[4];
        strArr4[0] = ERROR_REPORTER;
        String[] strArr5 = strArr4;
        strArr5[1] = ENTITY_RESOLVER;
        String[] strArr6 = strArr5;
        strArr6[2] = SECURITY_MANAGER;
        String[] strArr7 = strArr6;
        strArr7[3] = BUFFER_SIZE;
        RECOGNIZED_PROPERTIES = strArr7;
        Object[] objArr = new Object[4];
        objArr[0] = null;
        Object[] objArr2 = objArr;
        objArr2[1] = null;
        Object[] objArr3 = objArr2;
        objArr3[2] = null;
        Object[] objArr4 = objArr3;
        new Integer(InternalZipConstants.UFT8_NAMES_FLAG);
        objArr4[3] = obj;
        PROPERTY_DEFAULTS = objArr4;
        char[] cArr = {' ', '<', '>', '\"', '{', '}', '|', '\\', '^', '`'};
        int length = cArr.length;
        for (int i = 0; i < length; i++) {
            char c = cArr[i];
            gNeedEscaping[c] = true;
            gAfterEscaping1[c] = gHexChs[c >> 4];
            gAfterEscaping2[c] = gHexChs[c & 15];
        }
    }

    public XIncludeHandler() {
        XMLLocatorWrapper xMLLocatorWrapper;
        XIncludeMessageFormatter xIncludeMessageFormatter;
        ArrayList arrayList;
        ArrayList arrayList2;
        IntStack intStack;
        Stack stack;
        Stack stack2;
        Stack stack3;
        XMLResourceIdentifier xMLResourceIdentifier;
        IntStack intStack2;
        Stack stack4;
        new XMLLocatorWrapper();
        this.fXIncludeLocator = xMLLocatorWrapper;
        new XIncludeMessageFormatter();
        this.fXIncludeMessageFormatter = xIncludeMessageFormatter;
        this.fSawInclude = new boolean[8];
        this.fSawFallback = new boolean[8];
        this.fState = new int[8];
        this.fFixupBaseURIs = true;
        this.fFixupLanguage = true;
        this.fNeedCopyFeatures = true;
        this.fDepth = 0;
        this.fSawFallback[this.fDepth] = false;
        this.fSawInclude[this.fDepth] = false;
        this.fState[this.fDepth] = 1;
        new ArrayList();
        this.fNotations = arrayList;
        new ArrayList();
        this.fUnparsedEntities = arrayList2;
        new IntStack();
        this.fBaseURIScope = intStack;
        new Stack();
        this.fBaseURI = stack;
        new Stack();
        this.fLiteralSystemID = stack2;
        new Stack();
        this.fExpandedSystemID = stack3;
        new XMLResourceIdentifierImpl();
        this.fCurrentBaseURI = xMLResourceIdentifier;
        new IntStack();
        this.fLanguageScope = intStack2;
        new Stack();
        this.fLanguageStack = stack4;
        this.fCurrentLanguage = null;
    }

    private void checkMultipleRootElements() {
        if (getRootElementProcessed()) {
            reportFatalError("MultipleRootElements");
        }
        setRootElementProcessed(true);
    }

    private void checkWhitespace(XMLString xMLString) {
        XMLString xMLString2 = xMLString;
        int i = xMLString2.offset + xMLString2.length;
        for (int i2 = xMLString2.offset; i2 < i; i2++) {
            if (!XMLChar.isSpace(xMLString2.ch[i2])) {
                reportFatalError("ContentIllegalAtTopLevel");
                return;
            }
        }
    }

    private void copyFeatures1(Enumeration enumeration, String str, XMLComponentManager xMLComponentManager, ParserConfigurationSettings parserConfigurationSettings) {
        StringBuffer stringBuffer;
        Enumeration enumeration2 = enumeration;
        String str2 = str;
        XMLComponentManager xMLComponentManager2 = xMLComponentManager;
        ParserConfigurationSettings parserConfigurationSettings2 = parserConfigurationSettings;
        while (enumeration2.hasMoreElements()) {
            new StringBuffer();
            String stringBuffer2 = stringBuffer.append(str2).append((String) enumeration2.nextElement()).toString();
            parserConfigurationSettings2.addRecognizedFeatures(new String[]{stringBuffer2});
            try {
                parserConfigurationSettings2.setFeature(stringBuffer2, xMLComponentManager2.getFeature(stringBuffer2));
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
            }
        }
    }

    private void copyFeatures1(Enumeration enumeration, String str, XMLComponentManager xMLComponentManager, XMLParserConfiguration xMLParserConfiguration) {
        StringBuffer stringBuffer;
        Enumeration enumeration2 = enumeration;
        String str2 = str;
        XMLComponentManager xMLComponentManager2 = xMLComponentManager;
        XMLParserConfiguration xMLParserConfiguration2 = xMLParserConfiguration;
        while (enumeration2.hasMoreElements()) {
            new StringBuffer();
            String stringBuffer2 = stringBuffer.append(str2).append((String) enumeration2.nextElement()).toString();
            try {
                xMLParserConfiguration2.setFeature(stringBuffer2, xMLComponentManager2.getFeature(stringBuffer2));
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
            }
        }
    }

    private XMLInputSource createInputSource(String str, String str2, String str3, String str4, String str5) {
        HTTPInputSource hTTPInputSource;
        String str6 = str4;
        String str7 = str5;
        new HTTPInputSource(str, str2, str3);
        HTTPInputSource hTTPInputSource2 = hTTPInputSource;
        if (str6 != null && str6.length() > 0) {
            hTTPInputSource2.setHTTPRequestProperty(HTTP_ACCEPT, str6);
        }
        if (str7 != null && str7.length() > 0) {
            hTTPInputSource2.setHTTPRequestProperty(HTTP_ACCEPT_LANGUAGE, str7);
        }
        return hTTPInputSource2;
    }

    private String escapeHref(String str) {
        StringBuffer stringBuffer;
        char charAt;
        int supplemental;
        String str2 = str;
        int length = str2.length();
        new StringBuffer(length * 3);
        StringBuffer stringBuffer2 = stringBuffer;
        int i = 0;
        while (i < length && (charAt = str2.charAt(i)) <= '~') {
            if (charAt < ' ') {
                return str2;
            }
            if (gNeedEscaping[charAt]) {
                StringBuffer append = stringBuffer2.append('%');
                StringBuffer append2 = stringBuffer2.append(gAfterEscaping1[charAt]);
                StringBuffer append3 = stringBuffer2.append(gAfterEscaping2[charAt]);
            } else {
                StringBuffer append4 = stringBuffer2.append((char) charAt);
            }
            i++;
        }
        if (i < length) {
            int i2 = i;
            while (i2 < length) {
                char charAt2 = str2.charAt(i2);
                if ((charAt2 < ' ' || charAt2 > '~') && ((charAt2 < 160 || charAt2 > 55295) && ((charAt2 < 63744 || charAt2 > 64975) && (charAt2 < 65008 || charAt2 > 65519)))) {
                    if (XMLChar.isHighSurrogate(charAt2)) {
                        i2++;
                        if (i2 < length) {
                            char charAt3 = str2.charAt(i2);
                            if (XMLChar.isLowSurrogate(charAt3) && (supplemental = XMLChar.supplemental((char) charAt2, (char) charAt3)) < 983040 && (supplemental & InternalZipConstants.MAX_ALLOWED_ZIP_COMMENT_LENGTH) <= 65533) {
                            }
                        }
                    }
                    return str2;
                }
                i2++;
            }
            try {
                byte[] bytes = str2.substring(i).getBytes("UTF-8");
                length = bytes.length;
                for (int i3 = 0; i3 < length; i3++) {
                    byte b = bytes[i3];
                    if (b < 0) {
                        int i4 = b + 256;
                        StringBuffer append5 = stringBuffer2.append('%');
                        StringBuffer append6 = stringBuffer2.append(gHexChs[i4 >> 4]);
                        StringBuffer append7 = stringBuffer2.append(gHexChs[i4 & 15]);
                    } else if (gNeedEscaping[b]) {
                        StringBuffer append8 = stringBuffer2.append('%');
                        StringBuffer append9 = stringBuffer2.append(gAfterEscaping1[b]);
                        StringBuffer append10 = stringBuffer2.append(gAfterEscaping2[b]);
                    } else {
                        StringBuffer append11 = stringBuffer2.append((char) b);
                    }
                }
            } catch (UnsupportedEncodingException e) {
                UnsupportedEncodingException unsupportedEncodingException = e;
                return str2;
            }
        }
        return stringBuffer2.length() != length ? stringBuffer2.toString() : str2;
    }

    private String getIncludeParentBaseURI() {
        int includeParentDepth = getIncludeParentDepth();
        return (isRootDocument() || includeParentDepth != 0) ? getBaseURI(includeParentDepth) : this.fParentXIncludeHandler.getIncludeParentBaseURI();
    }

    private int getIncludeParentDepth() {
        for (int i = this.fDepth - 1; i >= 0; i--) {
            if (!getSawInclude(i) && !getSawFallback(i)) {
                return i;
            }
        }
        return 0;
    }

    private String getIncludeParentLanguage() {
        int includeParentDepth = getIncludeParentDepth();
        return (isRootDocument() || includeParentDepth != 0) ? getLanguage(includeParentDepth) : this.fParentXIncludeHandler.getIncludeParentLanguage();
    }

    private int getResultDepth() {
        return this.fResultDepth;
    }

    private boolean getRootElementProcessed() {
        return isRootDocument() ? this.fSeenRootElement : this.fParentXIncludeHandler.getRootElementProcessed();
    }

    private boolean isEqual(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        return str3 == str4 || (str3 != null && str3.equals(str4));
    }

    private boolean isValidInHTTPHeader(String str) {
        String str2 = str;
        for (int length = str2.length() - 1; length >= 0; length--) {
            char charAt = str2.charAt(length);
            if (charAt < ' ' || charAt > '~') {
                return false;
            }
        }
        return true;
    }

    private void reportError(String str, Object[] objArr, short s, Exception exc) {
        String str2 = str;
        Object[] objArr2 = objArr;
        short s2 = s;
        Exception exc2 = exc;
        if (this.fErrorReporter != null) {
            String reportError = this.fErrorReporter.reportError(XIncludeMessageFormatter.XINCLUDE_DOMAIN, str2, objArr2, s2, exc2);
        }
    }

    private int scopeOfBaseURI(int i) {
        int i2 = i;
        for (int size = this.fBaseURIScope.size() - 1; size >= 0; size--) {
            if (this.fBaseURIScope.elementAt(size) <= i2) {
                return size;
            }
        }
        return -1;
    }

    private int scopeOfLanguage(int i) {
        int i2 = i;
        for (int size = this.fLanguageScope.size() - 1; size >= 0; size--) {
            if (this.fLanguageScope.elementAt(size) <= i2) {
                return size;
            }
        }
        return -1;
    }

    private void setErrorReporter(XMLErrorReporter xMLErrorReporter) {
        this.fErrorReporter = xMLErrorReporter;
        if (this.fErrorReporter != null) {
            this.fErrorReporter.putMessageFormatter(XIncludeMessageFormatter.XINCLUDE_DOMAIN, this.fXIncludeMessageFormatter);
            if (this.fDocLocation != null) {
                this.fErrorReporter.setDocumentLocator(this.fDocLocation);
            }
        }
    }

    private void setRootElementProcessed(boolean z) {
        boolean z2 = z;
        if (isRootDocument()) {
            this.fSeenRootElement = z2;
            return;
        }
        this.fParentXIncludeHandler.setRootElementProcessed(z2);
    }

    /* access modifiers changed from: protected */
    public void addNotation(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) {
        Notation notation;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        new Notation();
        Notation notation2 = notation;
        notation2.name = str;
        notation2.systemId = xMLResourceIdentifier2.getLiteralSystemId();
        notation2.publicId = xMLResourceIdentifier2.getPublicId();
        notation2.baseURI = xMLResourceIdentifier2.getBaseSystemId();
        notation2.expandedSystemId = xMLResourceIdentifier2.getExpandedSystemId();
        notation2.augmentations = augmentations;
        boolean add = this.fNotations.add(notation2);
    }

    /* access modifiers changed from: protected */
    public void addUnparsedEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) {
        UnparsedEntity unparsedEntity;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        new UnparsedEntity();
        UnparsedEntity unparsedEntity2 = unparsedEntity;
        unparsedEntity2.name = str;
        unparsedEntity2.systemId = xMLResourceIdentifier2.getLiteralSystemId();
        unparsedEntity2.publicId = xMLResourceIdentifier2.getPublicId();
        unparsedEntity2.baseURI = xMLResourceIdentifier2.getBaseSystemId();
        unparsedEntity2.expandedSystemId = xMLResourceIdentifier2.getExpandedSystemId();
        unparsedEntity2.notation = str2;
        unparsedEntity2.augmentations = augmentations;
        boolean add = this.fUnparsedEntities.add(unparsedEntity2);
    }

    public void attributeDecl(String str, String str2, String str3, String[] strArr, String str4, XMLString xMLString, XMLString xMLString2, Augmentations augmentations) throws XNIException {
        String str5 = str;
        String str6 = str2;
        String str7 = str3;
        String[] strArr2 = strArr;
        String str8 = str4;
        XMLString xMLString3 = xMLString;
        XMLString xMLString4 = xMLString2;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.attributeDecl(str5, str6, str7, strArr2, str8, xMLString3, xMLString4, augmentations2);
        }
    }

    public void characters(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (getState() != 1) {
            return;
        }
        if (this.fResultDepth == 0) {
            checkWhitespace(xMLString2);
        } else if (this.fDocumentHandler != null) {
            this.fDepth++;
            this.fDocumentHandler.characters(xMLString2, modifyAugmentations(augmentations2));
            this.fDepth--;
        }
    }

    /* access modifiers changed from: protected */
    public void checkAndSendNotation(Notation notation) {
        XMLResourceIdentifier xMLResourceIdentifier;
        Notation notation2 = notation;
        if (isRootDocument()) {
            int indexOf = this.fNotations.indexOf(notation2);
            if (indexOf == -1) {
                new XMLResourceIdentifierImpl(notation2.publicId, notation2.systemId, notation2.baseURI, notation2.expandedSystemId);
                XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
                addNotation(notation2.name, xMLResourceIdentifier2, notation2.augmentations);
                if (this.fSendUEAndNotationEvents && this.fDTDHandler != null) {
                    this.fDTDHandler.notationDecl(notation2.name, xMLResourceIdentifier2, notation2.augmentations);
                    return;
                }
                return;
            }
            if (!notation2.isDuplicate((Notation) this.fNotations.get(indexOf))) {
                reportFatalError("NonDuplicateNotation", new Object[]{notation2.name});
                return;
            }
            return;
        }
        this.fParentXIncludeHandler.checkAndSendNotation(notation2);
    }

    /* access modifiers changed from: protected */
    public void checkAndSendUnparsedEntity(UnparsedEntity unparsedEntity) {
        XMLResourceIdentifier xMLResourceIdentifier;
        UnparsedEntity unparsedEntity2 = unparsedEntity;
        if (isRootDocument()) {
            int indexOf = this.fUnparsedEntities.indexOf(unparsedEntity2);
            if (indexOf == -1) {
                new XMLResourceIdentifierImpl(unparsedEntity2.publicId, unparsedEntity2.systemId, unparsedEntity2.baseURI, unparsedEntity2.expandedSystemId);
                XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
                addUnparsedEntity(unparsedEntity2.name, xMLResourceIdentifier2, unparsedEntity2.notation, unparsedEntity2.augmentations);
                if (this.fSendUEAndNotationEvents && this.fDTDHandler != null) {
                    this.fDTDHandler.unparsedEntityDecl(unparsedEntity2.name, xMLResourceIdentifier2, unparsedEntity2.notation, unparsedEntity2.augmentations);
                    return;
                }
                return;
            }
            if (!unparsedEntity2.isDuplicate((UnparsedEntity) this.fUnparsedEntities.get(indexOf))) {
                reportFatalError("NonDuplicateUnparsedEntity", new Object[]{unparsedEntity2.name});
                return;
            }
            return;
        }
        this.fParentXIncludeHandler.checkAndSendUnparsedEntity(unparsedEntity2);
    }

    /* access modifiers changed from: protected */
    public void checkNotation(String str) {
        Notation notation;
        new Notation();
        Notation notation2 = notation;
        notation2.name = str;
        int indexOf = this.fNotations.indexOf(notation2);
        if (indexOf != -1) {
            checkAndSendNotation((Notation) this.fNotations.get(indexOf));
        }
    }

    /* access modifiers changed from: protected */
    public void checkUnparsedEntity(String str) {
        UnparsedEntity unparsedEntity;
        new UnparsedEntity();
        UnparsedEntity unparsedEntity2 = unparsedEntity;
        unparsedEntity2.name = str;
        int indexOf = this.fUnparsedEntities.indexOf(unparsedEntity2);
        if (indexOf != -1) {
            UnparsedEntity unparsedEntity3 = (UnparsedEntity) this.fUnparsedEntities.get(indexOf);
            checkNotation(unparsedEntity3.notation);
            checkAndSendUnparsedEntity(unparsedEntity3);
        }
    }

    public void comment(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (!this.fInDTD) {
            if (this.fDocumentHandler != null && getState() == 1) {
                this.fDepth++;
                this.fDocumentHandler.comment(xMLString2, modifyAugmentations(augmentations2));
                this.fDepth--;
            }
        } else if (this.fDTDHandler != null) {
            this.fDTDHandler.comment(xMLString2, augmentations2);
        }
    }

    /* access modifiers changed from: protected */
    public void copyFeatures(XMLComponentManager xMLComponentManager, ParserConfigurationSettings parserConfigurationSettings) {
        XMLComponentManager xMLComponentManager2 = xMLComponentManager;
        ParserConfigurationSettings parserConfigurationSettings2 = parserConfigurationSettings;
        copyFeatures1(org.apache.xerces.impl.Constants.getXercesFeatures(), "http://apache.org/xml/features/", xMLComponentManager2, parserConfigurationSettings2);
        copyFeatures1(org.apache.xerces.impl.Constants.getSAXFeatures(), "http://xml.org/sax/features/", xMLComponentManager2, parserConfigurationSettings2);
    }

    /* access modifiers changed from: protected */
    public void copyFeatures(XMLComponentManager xMLComponentManager, XMLParserConfiguration xMLParserConfiguration) {
        XMLComponentManager xMLComponentManager2 = xMLComponentManager;
        XMLParserConfiguration xMLParserConfiguration2 = xMLParserConfiguration;
        copyFeatures1(org.apache.xerces.impl.Constants.getXercesFeatures(), "http://apache.org/xml/features/", xMLComponentManager2, xMLParserConfiguration2);
        copyFeatures1(org.apache.xerces.impl.Constants.getSAXFeatures(), "http://xml.org/sax/features/", xMLComponentManager2, xMLParserConfiguration2);
    }

    public void doctypeDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        Augmentations augmentations2 = augmentations;
        if (isRootDocument() && this.fDocumentHandler != null) {
            this.fDocumentHandler.doctypeDecl(str4, str5, str6, augmentations2);
        }
    }

    public void elementDecl(String str, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.elementDecl(str3, str4, augmentations2);
        }
    }

    public void emptyElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        this.fDepth++;
        int state = getState(this.fDepth - 1);
        if (state == 3 && getState(this.fDepth - 2) == 3) {
            setState(2);
        } else {
            setState(state);
        }
        processXMLBaseAttributes(xMLAttributes2);
        if (this.fFixupLanguage) {
            processXMLLangAttributes(xMLAttributes2);
        }
        if (isIncludeElement(qName2)) {
            if (handleIncludeElement(xMLAttributes2)) {
                setState(2);
            } else {
                reportFatalError("NoFallback");
            }
        } else if (isFallbackElement(qName2)) {
            handleFallbackElement();
        } else if (hasXIncludeNamespace(qName2)) {
            if (getSawInclude(this.fDepth - 1)) {
                reportFatalError("IncludeChild", new Object[]{qName2.rawname});
            }
            if (getSawFallback(this.fDepth - 1)) {
                reportFatalError("FallbackChild", new Object[]{qName2.rawname});
            }
            if (getState() == 1) {
                if (this.fResultDepth == 0) {
                    checkMultipleRootElements();
                }
                if (this.fDocumentHandler != null) {
                    this.fDocumentHandler.emptyElement(qName2, processAttributes(xMLAttributes2), modifyAugmentations(augmentations2));
                }
            }
        } else if (getState() == 1) {
            if (this.fResultDepth == 0) {
                checkMultipleRootElements();
            }
            if (this.fDocumentHandler != null) {
                this.fDocumentHandler.emptyElement(qName2, processAttributes(xMLAttributes2), modifyAugmentations(augmentations2));
            }
        }
        setSawFallback(this.fDepth + 1, false);
        setSawInclude(this.fDepth, false);
        if (this.fBaseURIScope.size() > 0 && this.fDepth == this.fBaseURIScope.peek()) {
            restoreBaseURI();
        }
        this.fDepth--;
    }

    public void endAttlist(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.endAttlist(augmentations2);
        }
    }

    public void endCDATA(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        if (this.fDocumentHandler != null && getState() == 1 && this.fResultDepth != 0) {
            this.fDocumentHandler.endCDATA(augmentations2);
        }
    }

    public void endConditional(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.endConditional(augmentations2);
        }
    }

    public void endDTD(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.endDTD(augmentations2);
        }
        this.fInDTD = false;
    }

    public void endDocument(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        if (isRootDocument()) {
            if (!this.fSeenRootElement) {
                reportFatalError("RootElementRequired");
            }
            if (this.fDocumentHandler != null) {
                this.fDocumentHandler.endDocument(augmentations2);
            }
        }
    }

    public void endElement(QName qName, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        if (isIncludeElement(qName2) && getState() == 3 && !getSawFallback(this.fDepth + 1)) {
            reportFatalError("NoFallback");
        }
        if (isFallbackElement(qName2)) {
            if (getState() == 1) {
                setState(2);
            }
        } else if (getState() == 1) {
            this.fResultDepth--;
            if (this.fDocumentHandler != null) {
                this.fDocumentHandler.endElement(qName2, augmentations2);
            }
        }
        setSawFallback(this.fDepth + 1, false);
        setSawInclude(this.fDepth, false);
        if (this.fBaseURIScope.size() > 0 && this.fDepth == this.fBaseURIScope.peek()) {
            restoreBaseURI();
        }
        if (this.fLanguageScope.size() > 0 && this.fDepth == this.fLanguageScope.peek()) {
            this.fCurrentLanguage = restoreLanguage();
        }
        this.fDepth--;
    }

    public void endExternalSubset(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.endExternalSubset(augmentations2);
        }
    }

    public void endGeneralEntity(String str, Augmentations augmentations) throws XNIException {
        String str2 = str;
        Augmentations augmentations2 = augmentations;
        if (this.fDocumentHandler != null && getState() == 1 && this.fResultDepth != 0) {
            this.fDocumentHandler.endGeneralEntity(str2, augmentations2);
        }
    }

    public void endParameterEntity(String str, Augmentations augmentations) throws XNIException {
        String str2 = str;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.endParameterEntity(str2, augmentations2);
        }
    }

    public void externalEntityDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
        String str2 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.externalEntityDecl(str2, xMLResourceIdentifier2, augmentations2);
        }
    }

    public String getBaseURI(int i) {
        return (String) this.fExpandedSystemID.elementAt(scopeOfBaseURI(i));
    }

    public XMLDTDHandler getDTDHandler() {
        return this.fDTDHandler;
    }

    public XMLDTDSource getDTDSource() {
        return this.fDTDSource;
    }

    public XMLDocumentHandler getDocumentHandler() {
        return this.fDocumentHandler;
    }

    public XMLDocumentSource getDocumentSource() {
        return this.fDocumentSource;
    }

    public Boolean getFeatureDefault(String str) {
        String str2 = str;
        for (int i = 0; i < RECOGNIZED_FEATURES.length; i++) {
            if (RECOGNIZED_FEATURES[i].equals(str2)) {
                return FEATURE_DEFAULTS[i];
            }
        }
        return null;
    }

    public String getLanguage(int i) {
        return (String) this.fLanguageStack.elementAt(scopeOfLanguage(i));
    }

    public Object getPropertyDefault(String str) {
        String str2 = str;
        for (int i = 0; i < RECOGNIZED_PROPERTIES.length; i++) {
            if (RECOGNIZED_PROPERTIES[i].equals(str2)) {
                return PROPERTY_DEFAULTS[i];
            }
        }
        return null;
    }

    public String[] getRecognizedFeatures() {
        return (String[]) RECOGNIZED_FEATURES.clone();
    }

    public String[] getRecognizedProperties() {
        return (String[]) RECOGNIZED_PROPERTIES.clone();
    }

    /* access modifiers changed from: protected */
    public String getRelativeBaseURI() throws URI.MalformedURIException {
        URI uri;
        URI uri2;
        StringBuffer stringBuffer;
        int includeParentDepth = getIncludeParentDepth();
        String relativeURI = getRelativeURI(includeParentDepth);
        if (isRootDocument()) {
            return relativeURI;
        }
        if (relativeURI.length() == 0) {
            relativeURI = this.fCurrentBaseURI.getLiteralSystemId();
        }
        if (includeParentDepth != 0) {
            return relativeURI;
        }
        if (this.fParentRelativeURI == null) {
            this.fParentRelativeURI = this.fParentXIncludeHandler.getRelativeBaseURI();
        }
        if (this.fParentRelativeURI.length() == 0) {
            return relativeURI;
        }
        new URI(this.fParentRelativeURI, true);
        URI uri3 = uri;
        new URI(uri3, relativeURI);
        URI uri4 = uri2;
        if (!isEqual(uri3.getScheme(), uri4.getScheme())) {
            return relativeURI;
        }
        if (!isEqual(uri3.getAuthority(), uri4.getAuthority())) {
            return uri4.getSchemeSpecificPart();
        }
        String path = uri4.getPath();
        String queryString = uri4.getQueryString();
        String fragment = uri4.getFragment();
        if (queryString == null && fragment == null) {
            return path;
        }
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        if (path != null) {
            StringBuffer append = stringBuffer2.append(path);
        }
        if (queryString != null) {
            StringBuffer append2 = stringBuffer2.append('?');
            StringBuffer append3 = stringBuffer2.append(queryString);
        }
        if (fragment != null) {
            StringBuffer append4 = stringBuffer2.append('#');
            StringBuffer append5 = stringBuffer2.append(fragment);
        }
        return stringBuffer2.toString();
    }

    public String getRelativeURI(int i) throws URI.MalformedURIException {
        URI uri;
        URI uri2;
        int scopeOfBaseURI = scopeOfBaseURI(i) + 1;
        if (scopeOfBaseURI == this.fBaseURIScope.size()) {
            return "";
        }
        new URI("file", (String) this.fLiteralSystemID.elementAt(scopeOfBaseURI));
        URI uri3 = uri;
        for (int i2 = scopeOfBaseURI + 1; i2 < this.fBaseURIScope.size(); i2++) {
            new URI(uri3, (String) this.fLiteralSystemID.elementAt(i2));
            uri3 = uri2;
        }
        return uri3.getPath();
    }

    /* access modifiers changed from: protected */
    public boolean getSawFallback(int i) {
        int i2 = i;
        if (i2 >= this.fSawFallback.length) {
            return false;
        }
        return this.fSawFallback[i2];
    }

    /* access modifiers changed from: protected */
    public boolean getSawInclude(int i) {
        int i2 = i;
        if (i2 >= this.fSawInclude.length) {
            return false;
        }
        return this.fSawInclude[i2];
    }

    /* access modifiers changed from: protected */
    public int getState() {
        return this.fState[this.fDepth];
    }

    /* access modifiers changed from: protected */
    public int getState(int i) {
        return this.fState[i];
    }

    /* access modifiers changed from: protected */
    public void handleFallbackElement() {
        if (!getSawInclude(this.fDepth - 1)) {
            if (getState() != 2) {
                reportFatalError("FallbackParent");
            } else {
                return;
            }
        }
        setSawInclude(this.fDepth, false);
        this.fNamespaceContext.setContextInvalid();
        if (getSawFallback(this.fDepth)) {
            reportFatalError("MultipleFallbacks");
        } else {
            setSawFallback(this.fDepth, true);
        }
        if (getState() == 3) {
            setState(1);
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:133:0x0641, code lost:
        r22 = java.lang.Boolean.FALSE;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:134:0x0645, code lost:
        r22 = java.lang.Boolean.FALSE;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:135:0x0649, code lost:
        r12 = (org.apache.xerces.xinclude.XIncludeHandler) r2.fChildConfig.getProperty("http://apache.org/xml/properties/internal/xinclude-handler");
        r12.setParent(r2);
        r12.setHref(r4);
        r12.setXIncludeLocator(r2.fXIncludeLocator);
        r12.setDocumentHandler(getDocumentHandler());
        r2.fXIncludeChildConfig = r2.fChildConfig;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:0x0204, code lost:
        if (r2.fXPointerChildConfig != null) goto L_0x0206;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x0212, code lost:
        if (r2.fXIncludeChildConfig == null) goto L_0x0214;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:68:0x0214, code lost:
        r11 = XINCLUDE_DEFAULT_CONFIGURATION;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:69:0x021b, code lost:
        if (r6 == null) goto L_0x0222;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x021d, code lost:
        r11 = "org.apache.xerces.parsers.XPointerParserConfiguration";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x0222, code lost:
        r2.fChildConfig = (org.apache.xerces.xni.parser.XMLParserConfiguration) org.apache.xerces.xinclude.ObjectFactory.newInstance(r11, org.apache.xerces.xinclude.ObjectFactory.findClassLoader(), true);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x0240, code lost:
        if (r2.fSymbolTable == null) goto L_0x0258;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x0242, code lost:
        r2.fChildConfig.setProperty(SYMBOL_TABLE, r2.fSymbolTable);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:75:0x0260, code lost:
        if (r2.fErrorReporter == null) goto L_0x0278;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:76:0x0262, code lost:
        r2.fChildConfig.setProperty(ERROR_REPORTER, r2.fErrorReporter);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:78:0x0280, code lost:
        if (r2.fEntityResolver == null) goto L_0x0298;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:79:0x0282, code lost:
        r2.fChildConfig.setProperty(ENTITY_RESOLVER, r2.fEntityResolver);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:80:0x0298, code lost:
        r2.fChildConfig.setProperty(SECURITY_MANAGER, r2.fSecurityManager);
        new java.lang.Integer(r2.fBufferSize);
        r2.fChildConfig.setProperty(BUFFER_SIZE, r28);
        r2.fNeedCopyFeatures = true;
        r2.fChildConfig.setProperty("http://apache.org/xml/properties/internal/namespace-context", r2.fNamespaceContext);
        r2.fChildConfig.setFeature(XINCLUDE_FIXUP_BASE_URIS, r2.fFixupBaseURIs);
        r2.fChildConfig.setFeature(XINCLUDE_FIXUP_LANGUAGE, r2.fFixupLanguage);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:81:0x031d, code lost:
        if (r6 == null) goto L_0x0649;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:82:0x031f, code lost:
        r12 = (org.apache.xerces.xpointer.XPointerHandler) r2.fChildConfig.getProperty("http://apache.org/xml/properties/internal/xpointer-handler");
        r2.fXPtrProcessor = r12;
        ((org.apache.xerces.xpointer.XPointerHandler) r2.fXPtrProcessor).setProperty("http://apache.org/xml/properties/internal/namespace-context", r2.fNamespaceContext);
        r20 = (org.apache.xerces.xpointer.XPointerHandler) r2.fXPtrProcessor;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x0369, code lost:
        if (r2.fFixupBaseURIs == false) goto L_0x0641;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:84:0x036b, code lost:
        r22 = java.lang.Boolean.TRUE;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:85:0x036d, code lost:
        r20.setProperty(XINCLUDE_FIXUP_BASE_URIS, r22);
        r20 = (org.apache.xerces.xpointer.XPointerHandler) r2.fXPtrProcessor;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:86:0x0385, code lost:
        if (r2.fFixupLanguage == false) goto L_0x0645;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:87:0x0387, code lost:
        r22 = java.lang.Boolean.TRUE;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:88:0x0389, code lost:
        r20.setProperty(XINCLUDE_FIXUP_LANGUAGE, r22);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:89:0x0394, code lost:
        if (r2.fErrorReporter == null) goto L_0x03ae;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:90:0x0396, code lost:
        ((org.apache.xerces.xpointer.XPointerHandler) r2.fXPtrProcessor).setProperty(ERROR_REPORTER, r2.fErrorReporter);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:91:0x03ae, code lost:
        r12.setParent(r2);
        r12.setHref(r4);
        r12.setXIncludeLocator(r2.fXIncludeLocator);
        r12.setDocumentHandler(getDocumentHandler());
        r2.fXPointerChildConfig = r2.fChildConfig;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean handleIncludeElement(org.apache.xerces.xni.XMLAttributes r30) throws org.apache.xerces.xni.XNIException {
        /*
            r29 = this;
            r2 = r29
            r3 = r30
            r20 = r2
            r21 = r2
            r0 = r21
            int r0 = r0.fDepth
            r21 = r0
            r22 = 1
            int r21 = r21 + -1
            boolean r20 = r20.getSawInclude(r21)
            if (r20 == 0) goto L_0x0034
            r20 = r2
            java.lang.String r21 = "IncludeChild"
            r22 = 1
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            java.lang.String r25 = XINCLUDE_INCLUDE
            r23[r24] = r25
            r20.reportFatalError(r21, r22)
        L_0x0034:
            r20 = r2
            int r20 = r20.getState()
            r21 = 2
            r0 = r20
            r1 = r21
            if (r0 != r1) goto L_0x0047
            r20 = 1
            r2 = r20
        L_0x0046:
            return r2
        L_0x0047:
            r20 = r2
            r21 = r2
            r0 = r21
            int r0 = r0.fDepth
            r21 = r0
            r22 = 1
            r20.setSawInclude(r21, r22)
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeNamespaceSupport r0 = r0.fNamespaceContext
            r20 = r0
            r20.setContextInvalid()
            r20 = r3
            java.lang.String r21 = XINCLUDE_ATTR_HREF
            java.lang.String r20 = r20.getValue((java.lang.String) r21)
            r4 = r20
            r20 = r3
            java.lang.String r21 = XINCLUDE_ATTR_PARSE
            java.lang.String r20 = r20.getValue((java.lang.String) r21)
            r5 = r20
            r20 = r3
            java.lang.String r21 = "xpointer"
            java.lang.String r20 = r20.getValue((java.lang.String) r21)
            r6 = r20
            r20 = r3
            java.lang.String r21 = XINCLUDE_ATTR_ACCEPT
            java.lang.String r20 = r20.getValue((java.lang.String) r21)
            r7 = r20
            r20 = r3
            java.lang.String r21 = XINCLUDE_ATTR_ACCEPT_LANGUAGE
            java.lang.String r20 = r20.getValue((java.lang.String) r21)
            r8 = r20
            r20 = r5
            if (r20 != 0) goto L_0x009c
            java.lang.String r20 = XINCLUDE_PARSE_XML
            r5 = r20
        L_0x009c:
            r20 = r4
            if (r20 != 0) goto L_0x00a4
            java.lang.String r20 = org.apache.xerces.util.XMLSymbols.EMPTY_STRING
            r4 = r20
        L_0x00a4:
            r20 = r4
            int r20 = r20.length()
            if (r20 != 0) goto L_0x00c2
            java.lang.String r20 = XINCLUDE_PARSE_XML
            r21 = r5
            boolean r20 = r20.equals(r21)
            if (r20 == 0) goto L_0x00c2
            r20 = r6
            if (r20 != 0) goto L_0x04fc
            r20 = r2
            java.lang.String r21 = "XpointerMissing"
            r20.reportFatalError(r21)
        L_0x00c2:
            r20 = 0
            r9 = r20
            org.apache.xerces.util.URI r20 = new org.apache.xerces.util.URI     // Catch:{ MalformedURIException -> 0x055a }
            r28 = r20
            r20 = r28
            r21 = r28
            r22 = r4
            r23 = 1
            r21.<init>((java.lang.String) r22, (boolean) r23)     // Catch:{ MalformedURIException -> 0x055a }
            r9 = r20
            r20 = r9
            java.lang.String r20 = r20.getFragment()     // Catch:{ MalformedURIException -> 0x055a }
            if (r20 == 0) goto L_0x00fb
            r20 = r2
            java.lang.String r21 = "HrefFragmentIdentifierIllegal"
            r22 = 1
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ MalformedURIException -> 0x055a }
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25     // Catch:{ MalformedURIException -> 0x055a }
            r20.reportFatalError(r21, r22)     // Catch:{ MalformedURIException -> 0x055a }
        L_0x00fb:
            r20 = r7
            if (r20 == 0) goto L_0x0117
            r20 = r2
            r21 = r7
            boolean r20 = r20.isValidInHTTPHeader(r21)
            if (r20 != 0) goto L_0x0117
            r20 = r2
            java.lang.String r21 = "AcceptMalformed"
            r22 = 0
            r20.reportFatalError(r21, r22)
            r20 = 0
            r7 = r20
        L_0x0117:
            r20 = r8
            if (r20 == 0) goto L_0x0133
            r20 = r2
            r21 = r8
            boolean r20 = r20.isValidInHTTPHeader(r21)
            if (r20 != 0) goto L_0x0133
            r20 = r2
            java.lang.String r21 = "AcceptLanguageMalformed"
            r22 = 0
            r20.reportFatalError(r21, r22)
            r20 = 0
            r8 = r20
        L_0x0133:
            r20 = 0
            r10 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLEntityResolver r0 = r0.fEntityResolver
            r20 = r0
            if (r20 == 0) goto L_0x01c6
            org.apache.xerces.util.XMLResourceIdentifierImpl r20 = new org.apache.xerces.util.XMLResourceIdentifierImpl     // Catch:{ IOException -> 0x05eb }
            r28 = r20
            r20 = r28
            r21 = r28
            r22 = 0
            r23 = r4
            r24 = r2
            r0 = r24
            org.apache.xerces.xni.XMLResourceIdentifier r0 = r0.fCurrentBaseURI     // Catch:{ IOException -> 0x05eb }
            r24 = r0
            java.lang.String r24 = r24.getExpandedSystemId()     // Catch:{ IOException -> 0x05eb }
            r25 = r4
            r26 = r2
            r0 = r26
            org.apache.xerces.xni.XMLResourceIdentifier r0 = r0.fCurrentBaseURI     // Catch:{ IOException -> 0x05eb }
            r26 = r0
            java.lang.String r26 = r26.getExpandedSystemId()     // Catch:{ IOException -> 0x05eb }
            r27 = 0
            java.lang.String r25 = org.apache.xerces.impl.XMLEntityManager.expandSystemId(r25, r26, r27)     // Catch:{ IOException -> 0x05eb }
            r21.<init>(r22, r23, r24, r25)     // Catch:{ IOException -> 0x05eb }
            r11 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLEntityResolver r0 = r0.fEntityResolver     // Catch:{ IOException -> 0x05eb }
            r20 = r0
            r21 = r11
            org.apache.xerces.xni.parser.XMLInputSource r20 = r20.resolveEntity(r21)     // Catch:{ IOException -> 0x05eb }
            r10 = r20
            r20 = r10
            if (r20 == 0) goto L_0x01c6
            r20 = r10
            r0 = r20
            boolean r0 = r0 instanceof org.apache.xerces.util.HTTPInputSource     // Catch:{ IOException -> 0x05eb }
            r20 = r0
            if (r20 != 0) goto L_0x01c6
            r20 = r7
            if (r20 != 0) goto L_0x0198
            r20 = r8
            if (r20 == 0) goto L_0x01c6
        L_0x0198:
            r20 = r10
            java.io.Reader r20 = r20.getCharacterStream()     // Catch:{ IOException -> 0x05eb }
            if (r20 != 0) goto L_0x01c6
            r20 = r10
            java.io.InputStream r20 = r20.getByteStream()     // Catch:{ IOException -> 0x05eb }
            if (r20 != 0) goto L_0x01c6
            r20 = r2
            r21 = r10
            java.lang.String r21 = r21.getPublicId()     // Catch:{ IOException -> 0x05eb }
            r22 = r10
            java.lang.String r22 = r22.getSystemId()     // Catch:{ IOException -> 0x05eb }
            r23 = r10
            java.lang.String r23 = r23.getBaseSystemId()     // Catch:{ IOException -> 0x05eb }
            r24 = r7
            r25 = r8
            org.apache.xerces.xni.parser.XMLInputSource r20 = r20.createInputSource(r21, r22, r23, r24, r25)     // Catch:{ IOException -> 0x05eb }
            r10 = r20
        L_0x01c6:
            r20 = r10
            if (r20 != 0) goto L_0x01ee
            r20 = r7
            if (r20 != 0) goto L_0x01d2
            r20 = r8
            if (r20 == 0) goto L_0x0622
        L_0x01d2:
            r20 = r2
            r21 = 0
            r22 = r4
            r23 = r2
            r0 = r23
            org.apache.xerces.xni.XMLResourceIdentifier r0 = r0.fCurrentBaseURI
            r23 = r0
            java.lang.String r23 = r23.getExpandedSystemId()
            r24 = r7
            r25 = r8
            org.apache.xerces.xni.parser.XMLInputSource r20 = r20.createInputSource(r21, r22, r23, r24, r25)
            r10 = r20
        L_0x01ee:
            r20 = r5
            java.lang.String r21 = XINCLUDE_PARSE_XML
            boolean r20 = r20.equals(r21)
            if (r20 == 0) goto L_0x07ea
            r20 = r6
            if (r20 == 0) goto L_0x0206
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fXPointerChildConfig
            r20 = r0
            if (r20 == 0) goto L_0x0214
        L_0x0206:
            r20 = r6
            if (r20 != 0) goto L_0x03e4
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fXIncludeChildConfig
            r20 = r0
            if (r20 != 0) goto L_0x03e4
        L_0x0214:
            java.lang.String r20 = "org.apache.xerces.parsers.XIncludeParserConfiguration"
            r11 = r20
            r20 = r6
            if (r20 == 0) goto L_0x0222
            java.lang.String r20 = "org.apache.xerces.parsers.XPointerParserConfiguration"
            r11 = r20
        L_0x0222:
            r20 = r2
            r21 = r11
            java.lang.ClassLoader r22 = org.apache.xerces.xinclude.ObjectFactory.findClassLoader()
            r23 = 1
            java.lang.Object r21 = org.apache.xerces.xinclude.ObjectFactory.newInstance(r21, r22, r23)
            org.apache.xerces.xni.parser.XMLParserConfiguration r21 = (org.apache.xerces.xni.parser.XMLParserConfiguration) r21
            r0 = r21
            r1 = r20
            r1.fChildConfig = r0
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            if (r20 == 0) goto L_0x0258
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fChildConfig
            r20 = r0
            java.lang.String r21 = "http://apache.org/xml/properties/internal/symbol-table"
            r22 = r2
            r0 = r22
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r22 = r0
            r20.setProperty(r21, r22)
        L_0x0258:
            r20 = r2
            r0 = r20
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter
            r20 = r0
            if (r20 == 0) goto L_0x0278
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fChildConfig
            r20 = r0
            java.lang.String r21 = "http://apache.org/xml/properties/internal/error-reporter"
            r22 = r2
            r0 = r22
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter
            r22 = r0
            r20.setProperty(r21, r22)
        L_0x0278:
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLEntityResolver r0 = r0.fEntityResolver
            r20 = r0
            if (r20 == 0) goto L_0x0298
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fChildConfig
            r20 = r0
            java.lang.String r21 = "http://apache.org/xml/properties/internal/entity-resolver"
            r22 = r2
            r0 = r22
            org.apache.xerces.xni.parser.XMLEntityResolver r0 = r0.fEntityResolver
            r22 = r0
            r20.setProperty(r21, r22)
        L_0x0298:
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fChildConfig
            r20 = r0
            java.lang.String r21 = "http://apache.org/xml/properties/security-manager"
            r22 = r2
            r0 = r22
            org.apache.xerces.util.SecurityManager r0 = r0.fSecurityManager
            r22 = r0
            r20.setProperty(r21, r22)
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fChildConfig
            r20 = r0
            java.lang.String r21 = "http://apache.org/xml/properties/input-buffer-size"
            java.lang.Integer r22 = new java.lang.Integer
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = r2
            r0 = r24
            int r0 = r0.fBufferSize
            r24 = r0
            r23.<init>(r24)
            r20.setProperty(r21, r22)
            r20 = r2
            r21 = 1
            r0 = r21
            r1 = r20
            r1.fNeedCopyFeatures = r0
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fChildConfig
            r20 = r0
            java.lang.String r21 = "http://apache.org/xml/properties/internal/namespace-context"
            r22 = r2
            r0 = r22
            org.apache.xerces.xinclude.XIncludeNamespaceSupport r0 = r0.fNamespaceContext
            r22 = r0
            r20.setProperty(r21, r22)
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fChildConfig
            r20 = r0
            java.lang.String r21 = "http://apache.org/xml/features/xinclude/fixup-base-uris"
            r22 = r2
            r0 = r22
            boolean r0 = r0.fFixupBaseURIs
            r22 = r0
            r20.setFeature(r21, r22)
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fChildConfig
            r20 = r0
            java.lang.String r21 = "http://apache.org/xml/features/xinclude/fixup-language"
            r22 = r2
            r0 = r22
            boolean r0 = r0.fFixupLanguage
            r22 = r0
            r20.setFeature(r21, r22)
            r20 = r6
            if (r20 == 0) goto L_0x0649
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fChildConfig
            r20 = r0
            java.lang.String r21 = "http://apache.org/xml/properties/internal/xpointer-handler"
            java.lang.Object r20 = r20.getProperty(r21)
            org.apache.xerces.xpointer.XPointerHandler r20 = (org.apache.xerces.xpointer.XPointerHandler) r20
            r12 = r20
            r20 = r2
            r21 = r12
            r0 = r21
            r1 = r20
            r1.fXPtrProcessor = r0
            r20 = r2
            r0 = r20
            org.apache.xerces.xpointer.XPointerProcessor r0 = r0.fXPtrProcessor
            r20 = r0
            org.apache.xerces.xpointer.XPointerHandler r20 = (org.apache.xerces.xpointer.XPointerHandler) r20
            java.lang.String r21 = "http://apache.org/xml/properties/internal/namespace-context"
            r22 = r2
            r0 = r22
            org.apache.xerces.xinclude.XIncludeNamespaceSupport r0 = r0.fNamespaceContext
            r22 = r0
            r20.setProperty(r21, r22)
            r20 = r2
            r0 = r20
            org.apache.xerces.xpointer.XPointerProcessor r0 = r0.fXPtrProcessor
            r20 = r0
            org.apache.xerces.xpointer.XPointerHandler r20 = (org.apache.xerces.xpointer.XPointerHandler) r20
            java.lang.String r21 = "http://apache.org/xml/features/xinclude/fixup-base-uris"
            r22 = r2
            r0 = r22
            boolean r0 = r0.fFixupBaseURIs
            r22 = r0
            if (r22 == 0) goto L_0x0641
            java.lang.Boolean r22 = java.lang.Boolean.TRUE
        L_0x036d:
            r20.setProperty(r21, r22)
            r20 = r2
            r0 = r20
            org.apache.xerces.xpointer.XPointerProcessor r0 = r0.fXPtrProcessor
            r20 = r0
            org.apache.xerces.xpointer.XPointerHandler r20 = (org.apache.xerces.xpointer.XPointerHandler) r20
            java.lang.String r21 = "http://apache.org/xml/features/xinclude/fixup-language"
            r22 = r2
            r0 = r22
            boolean r0 = r0.fFixupLanguage
            r22 = r0
            if (r22 == 0) goto L_0x0645
            java.lang.Boolean r22 = java.lang.Boolean.TRUE
        L_0x0389:
            r20.setProperty(r21, r22)
            r20 = r2
            r0 = r20
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter
            r20 = r0
            if (r20 == 0) goto L_0x03ae
            r20 = r2
            r0 = r20
            org.apache.xerces.xpointer.XPointerProcessor r0 = r0.fXPtrProcessor
            r20 = r0
            org.apache.xerces.xpointer.XPointerHandler r20 = (org.apache.xerces.xpointer.XPointerHandler) r20
            java.lang.String r21 = "http://apache.org/xml/properties/internal/error-reporter"
            r22 = r2
            r0 = r22
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter
            r22 = r0
            r20.setProperty(r21, r22)
        L_0x03ae:
            r20 = r12
            r21 = r2
            r20.setParent(r21)
            r20 = r12
            r21 = r4
            r20.setHref(r21)
            r20 = r12
            r21 = r2
            r0 = r21
            org.apache.xerces.util.XMLLocatorWrapper r0 = r0.fXIncludeLocator
            r21 = r0
            r20.setXIncludeLocator(r21)
            r20 = r12
            r21 = r2
            org.apache.xerces.xni.XMLDocumentHandler r21 = r21.getDocumentHandler()
            r20.setDocumentHandler(r21)
            r20 = r2
            r21 = r2
            r0 = r21
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fChildConfig
            r21 = r0
            r0 = r21
            r1 = r20
            r1.fXPointerChildConfig = r0
        L_0x03e4:
            r20 = r6
            if (r20 == 0) goto L_0x06c9
            r20 = r2
            r21 = r2
            r0 = r21
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fXPointerChildConfig
            r21 = r0
            r0 = r21
            r1 = r20
            r1.fChildConfig = r0
            r20 = r2
            r0 = r20
            org.apache.xerces.xpointer.XPointerProcessor r0 = r0.fXPtrProcessor     // Catch:{ XNIException -> 0x0694 }
            r20 = r0
            r21 = r6
            r20.parseXPointer(r21)     // Catch:{ XNIException -> 0x0694 }
        L_0x0405:
            r20 = r2
            r0 = r20
            boolean r0 = r0.fNeedCopyFeatures
            r20 = r0
            if (r20 == 0) goto L_0x0424
            r20 = r2
            r21 = r2
            r0 = r21
            org.apache.xerces.util.ParserConfigurationSettings r0 = r0.fSettings
            r21 = r0
            r22 = r2
            r0 = r22
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fChildConfig
            r22 = r0
            r20.copyFeatures((org.apache.xerces.xni.parser.XMLComponentManager) r21, (org.apache.xerces.xni.parser.XMLParserConfiguration) r22)
        L_0x0424:
            r20 = r2
            r21 = 0
            r0 = r21
            r1 = r20
            r1.fNeedCopyFeatures = r0
            r20 = r2
            r21 = 0
            r0 = r21
            r1 = r20
            r1.fHasIncludeReportedContent = r0     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeNamespaceSupport r0 = r0.fNamespaceContext     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20 = r0
            r20.pushScope()     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fChildConfig     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20 = r0
            r21 = r10
            r20.parse(r21)     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20 = r2
            r0 = r20
            org.apache.xerces.util.XMLLocatorWrapper r0 = r0.fXIncludeLocator     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20 = r0
            r21 = r2
            r0 = r21
            org.apache.xerces.xni.XMLLocator r0 = r0.fDocLocation     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r21 = r0
            r20.setLocator(r21)     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20 = r2
            r0 = r20
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20 = r0
            if (r20 == 0) goto L_0x0480
            r20 = r2
            r0 = r20
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20 = r0
            r21 = r2
            r0 = r21
            org.apache.xerces.xni.XMLLocator r0 = r0.fDocLocation     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r21 = r0
            r20.setDocumentLocator(r21)     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
        L_0x0480:
            r20 = r6
            if (r20 == 0) goto L_0x06df
            r20 = r2
            r0 = r20
            org.apache.xerces.xpointer.XPointerProcessor r0 = r0.fXPtrProcessor     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20 = r0
            boolean r20 = r20.isXPointerResolved()     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            if (r20 != 0) goto L_0x06df
            r20 = r2
            r0 = r20
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20 = r0
            if (r20 == 0) goto L_0x06db
            r20 = r2
            r0 = r20
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20 = r0
            java.util.Locale r20 = r20.getLocale()     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
        L_0x04a8:
            r11 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeMessageFormatter r0 = r0.fXIncludeMessageFormatter     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20 = r0
            r21 = r11
            java.lang.String r22 = "XPointerResolutionUnsuccessful"
            r23 = 0
            java.lang.String r20 = r20.formatMessage(r21, r22, r23)     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r12 = r20
            r20 = r2
            java.lang.String r21 = "XMLResourceError"
            r22 = 2
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 1
            r25 = r12
            r23[r24] = r25     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20.reportResourceError(r21, r22)     // Catch:{ XNIException -> 0x06f0, IOException -> 0x074b }
            r20 = 0
            r13 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeNamespaceSupport r0 = r0.fNamespaceContext
            r20 = r0
            r20.popScope()
            r20 = r13
            r2 = r20
            goto L_0x0046
        L_0x04fc:
            r20 = r2
            r0 = r20
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter
            r20 = r0
            if (r20 == 0) goto L_0x0557
            r20 = r2
            r0 = r20
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter
            r20 = r0
            java.util.Locale r20 = r20.getLocale()
        L_0x0512:
            r9 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeMessageFormatter r0 = r0.fXIncludeMessageFormatter
            r20 = r0
            r21 = r9
            java.lang.String r22 = "XPointerStreamability"
            r23 = 0
            java.lang.String r20 = r20.formatMessage(r21, r22, r23)
            r10 = r20
            r20 = r2
            java.lang.String r21 = "XMLResourceError"
            r22 = 2
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 1
            r25 = r10
            r23[r24] = r25
            r20.reportResourceError(r21, r22)
            r20 = 0
            r2 = r20
            goto L_0x0046
        L_0x0557:
            r20 = 0
            goto L_0x0512
        L_0x055a:
            r20 = move-exception
            r10 = r20
            r20 = r2
            r21 = r4
            java.lang.String r20 = r20.escapeHref(r21)
            r11 = r20
            r20 = r4
            r21 = r11
            r0 = r20
            r1 = r21
            if (r0 == r1) goto L_0x05cd
            r20 = r11
            r4 = r20
            org.apache.xerces.util.URI r20 = new org.apache.xerces.util.URI     // Catch:{ MalformedURIException -> 0x05ac }
            r28 = r20
            r20 = r28
            r21 = r28
            r22 = r4
            r23 = 1
            r21.<init>((java.lang.String) r22, (boolean) r23)     // Catch:{ MalformedURIException -> 0x05ac }
            r9 = r20
            r20 = r9
            java.lang.String r20 = r20.getFragment()     // Catch:{ MalformedURIException -> 0x05ac }
            if (r20 == 0) goto L_0x05aa
            r20 = r2
            java.lang.String r21 = "HrefFragmentIdentifierIllegal"
            r22 = 1
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ MalformedURIException -> 0x05ac }
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25     // Catch:{ MalformedURIException -> 0x05ac }
            r20.reportFatalError(r21, r22)     // Catch:{ MalformedURIException -> 0x05ac }
        L_0x05aa:
            goto L_0x00fb
        L_0x05ac:
            r20 = move-exception
            r12 = r20
            r20 = r2
            java.lang.String r21 = "HrefSyntacticallyInvalid"
            r22 = 1
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25
            r20.reportFatalError(r21, r22)
            goto L_0x00fb
        L_0x05cd:
            r20 = r2
            java.lang.String r21 = "HrefSyntacticallyInvalid"
            r22 = 1
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25
            r20.reportFatalError(r21, r22)
            goto L_0x00fb
        L_0x05eb:
            r20 = move-exception
            r11 = r20
            r20 = r2
            java.lang.String r21 = "XMLResourceError"
            r22 = 2
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 1
            r25 = r11
            java.lang.String r25 = r25.getMessage()
            r23[r24] = r25
            r23 = r11
            r20.reportResourceError(r21, r22, r23)
            r20 = 0
            r2 = r20
            goto L_0x0046
        L_0x0622:
            org.apache.xerces.xni.parser.XMLInputSource r20 = new org.apache.xerces.xni.parser.XMLInputSource
            r28 = r20
            r20 = r28
            r21 = r28
            r22 = 0
            r23 = r4
            r24 = r2
            r0 = r24
            org.apache.xerces.xni.XMLResourceIdentifier r0 = r0.fCurrentBaseURI
            r24 = r0
            java.lang.String r24 = r24.getExpandedSystemId()
            r21.<init>(r22, r23, r24)
            r10 = r20
            goto L_0x01ee
        L_0x0641:
            java.lang.Boolean r22 = java.lang.Boolean.FALSE
            goto L_0x036d
        L_0x0645:
            java.lang.Boolean r22 = java.lang.Boolean.FALSE
            goto L_0x0389
        L_0x0649:
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fChildConfig
            r20 = r0
            java.lang.String r21 = "http://apache.org/xml/properties/internal/xinclude-handler"
            java.lang.Object r20 = r20.getProperty(r21)
            org.apache.xerces.xinclude.XIncludeHandler r20 = (org.apache.xerces.xinclude.XIncludeHandler) r20
            r12 = r20
            r20 = r12
            r21 = r2
            r20.setParent(r21)
            r20 = r12
            r21 = r4
            r20.setHref(r21)
            r20 = r12
            r21 = r2
            r0 = r21
            org.apache.xerces.util.XMLLocatorWrapper r0 = r0.fXIncludeLocator
            r21 = r0
            r20.setXIncludeLocator(r21)
            r20 = r12
            r21 = r2
            org.apache.xerces.xni.XMLDocumentHandler r21 = r21.getDocumentHandler()
            r20.setDocumentHandler(r21)
            r20 = r2
            r21 = r2
            r0 = r21
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fChildConfig
            r21 = r0
            r0 = r21
            r1 = r20
            r1.fXIncludeChildConfig = r0
            goto L_0x03e4
        L_0x0694:
            r20 = move-exception
            r11 = r20
            r20 = r2
            java.lang.String r21 = "XMLResourceError"
            r22 = 2
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 1
            r25 = r11
            java.lang.String r25 = r25.getMessage()
            r23[r24] = r25
            r20.reportResourceError(r21, r22)
            r20 = 0
            r2 = r20
            goto L_0x0046
        L_0x06c9:
            r20 = r2
            r21 = r2
            r0 = r21
            org.apache.xerces.xni.parser.XMLParserConfiguration r0 = r0.fXIncludeChildConfig
            r21 = r0
            r0 = r21
            r1 = r20
            r1.fChildConfig = r0
            goto L_0x0405
        L_0x06db:
            r20 = 0
            goto L_0x04a8
        L_0x06df:
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeNamespaceSupport r0 = r0.fNamespaceContext
            r20 = r0
            r20.popScope()
        L_0x06ea:
            r20 = 1
            r2 = r20
            goto L_0x0046
        L_0x06f0:
            r20 = move-exception
            r11 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.util.XMLLocatorWrapper r0 = r0.fXIncludeLocator     // Catch:{ all -> 0x0796 }
            r20 = r0
            r21 = r2
            r0 = r21
            org.apache.xerces.xni.XMLLocator r0 = r0.fDocLocation     // Catch:{ all -> 0x0796 }
            r21 = r0
            r20.setLocator(r21)     // Catch:{ all -> 0x0796 }
            r20 = r2
            r0 = r20
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter     // Catch:{ all -> 0x0796 }
            r20 = r0
            if (r20 == 0) goto L_0x0723
            r20 = r2
            r0 = r20
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter     // Catch:{ all -> 0x0796 }
            r20 = r0
            r21 = r2
            r0 = r21
            org.apache.xerces.xni.XMLLocator r0 = r0.fDocLocation     // Catch:{ all -> 0x0796 }
            r21 = r0
            r20.setDocumentLocator(r21)     // Catch:{ all -> 0x0796 }
        L_0x0723:
            r20 = r2
            java.lang.String r21 = "XMLParseError"
            r22 = 1
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ all -> 0x0796 }
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25     // Catch:{ all -> 0x0796 }
            r20.reportFatalError(r21, r22)     // Catch:{ all -> 0x0796 }
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeNamespaceSupport r0 = r0.fNamespaceContext
            r20 = r0
            r20.popScope()
            goto L_0x06ea
        L_0x074b:
            r20 = move-exception
            r12 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.util.XMLLocatorWrapper r0 = r0.fXIncludeLocator     // Catch:{ all -> 0x0796 }
            r20 = r0
            r21 = r2
            r0 = r21
            org.apache.xerces.xni.XMLLocator r0 = r0.fDocLocation     // Catch:{ all -> 0x0796 }
            r21 = r0
            r20.setLocator(r21)     // Catch:{ all -> 0x0796 }
            r20 = r2
            r0 = r20
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter     // Catch:{ all -> 0x0796 }
            r20 = r0
            if (r20 == 0) goto L_0x077e
            r20 = r2
            r0 = r20
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter     // Catch:{ all -> 0x0796 }
            r20 = r0
            r21 = r2
            r0 = r21
            org.apache.xerces.xni.XMLLocator r0 = r0.fDocLocation     // Catch:{ all -> 0x0796 }
            r21 = r0
            r20.setDocumentLocator(r21)     // Catch:{ all -> 0x0796 }
        L_0x077e:
            r20 = r2
            r0 = r20
            boolean r0 = r0.fHasIncludeReportedContent     // Catch:{ all -> 0x0796 }
            r20 = r0
            if (r20 == 0) goto L_0x07a7
            org.apache.xerces.xni.XNIException r20 = new org.apache.xerces.xni.XNIException     // Catch:{ all -> 0x0796 }
            r28 = r20
            r20 = r28
            r21 = r28
            r22 = r12
            r21.<init>((java.lang.Exception) r22)     // Catch:{ all -> 0x0796 }
            throw r20     // Catch:{ all -> 0x0796 }
        L_0x0796:
            r20 = move-exception
            r14 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeNamespaceSupport r0 = r0.fNamespaceContext
            r20 = r0
            r20.popScope()
            r20 = r14
            throw r20
        L_0x07a7:
            r20 = r2
            java.lang.String r21 = "XMLResourceError"
            r22 = 2
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ all -> 0x0796 }
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25     // Catch:{ all -> 0x0796 }
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 1
            r25 = r12
            java.lang.String r25 = r25.getMessage()     // Catch:{ all -> 0x0796 }
            r23[r24] = r25     // Catch:{ all -> 0x0796 }
            r23 = r12
            r20.reportResourceError(r21, r22, r23)     // Catch:{ all -> 0x0796 }
            r20 = 0
            r13 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeNamespaceSupport r0 = r0.fNamespaceContext
            r20 = r0
            r20.popScope()
            r20 = r13
            r2 = r20
            goto L_0x0046
        L_0x07ea:
            r20 = r5
            java.lang.String r21 = XINCLUDE_PARSE_TEXT
            boolean r20 = r20.equals(r21)
            if (r20 == 0) goto L_0x097f
            r20 = r3
            java.lang.String r21 = XINCLUDE_ATTR_ENCODING
            java.lang.String r20 = r20.getValue((java.lang.String) r21)
            r11 = r20
            r20 = r10
            r21 = r11
            r20.setEncoding(r21)
            r20 = 0
            r12 = r20
            r20 = r2
            r21 = 0
            r0 = r21
            r1 = r20
            r1.fHasIncludeReportedContent = r0     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r20 = r2
            r0 = r20
            boolean r0 = r0.fIsXML11     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r20 = r0
            if (r20 != 0) goto L_0x08ab
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeTextReader r0 = r0.fXInclude10TextReader     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r20 = r0
            if (r20 != 0) goto L_0x086d
            r20 = r2
            org.apache.xerces.xinclude.XIncludeTextReader r21 = new org.apache.xerces.xinclude.XIncludeTextReader     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r28 = r21
            r21 = r28
            r22 = r28
            r23 = r10
            r24 = r2
            r25 = r2
            r0 = r25
            int r0 = r0.fBufferSize     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r25 = r0
            r22.<init>(r23, r24, r25)     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r0 = r21
            r1 = r20
            r1.fXInclude10TextReader = r0     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
        L_0x0846:
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeTextReader r0 = r0.fXInclude10TextReader     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r20 = r0
            r12 = r20
        L_0x0850:
            r20 = r12
            r21 = r2
            r0 = r21
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r21 = r0
            r20.setErrorReporter(r21)     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r20 = r12
            r20.parse()     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r20 = r12
            if (r20 == 0) goto L_0x086b
            r20 = r12
            r20.close()     // Catch:{ IOException -> 0x0a79 }
        L_0x086b:
            goto L_0x06ea
        L_0x086d:
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeTextReader r0 = r0.fXInclude10TextReader     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r20 = r0
            r21 = r10
            r20.setInputSource(r21)     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            goto L_0x0846
        L_0x087b:
            r20 = move-exception
            r13 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter     // Catch:{ all -> 0x092f }
            r20 = r0
            r21 = r13
            java.lang.String r21 = r21.getDomain()     // Catch:{ all -> 0x092f }
            r22 = r13
            java.lang.String r22 = r22.getKey()     // Catch:{ all -> 0x092f }
            r23 = r13
            java.lang.Object[] r23 = r23.getArguments()     // Catch:{ all -> 0x092f }
            r24 = 2
            r25 = r13
            java.lang.String r20 = r20.reportError(r21, r22, r23, r24, r25)     // Catch:{ all -> 0x092f }
            r20 = r12
            if (r20 == 0) goto L_0x08a9
            r20 = r12
            r20.close()     // Catch:{ IOException -> 0x09d4 }
        L_0x08a9:
            goto L_0x06ea
        L_0x08ab:
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeTextReader r0 = r0.fXInclude11TextReader     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r20 = r0
            if (r20 != 0) goto L_0x08e0
            r20 = r2
            org.apache.xerces.xinclude.XInclude11TextReader r21 = new org.apache.xerces.xinclude.XInclude11TextReader     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r28 = r21
            r21 = r28
            r22 = r28
            r23 = r10
            r24 = r2
            r25 = r2
            r0 = r25
            int r0 = r0.fBufferSize     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r25 = r0
            r22.<init>(r23, r24, r25)     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r0 = r21
            r1 = r20
            r1.fXInclude11TextReader = r0     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
        L_0x08d4:
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeTextReader r0 = r0.fXInclude11TextReader     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r20 = r0
            r12 = r20
            goto L_0x0850
        L_0x08e0:
            r20 = r2
            r0 = r20
            org.apache.xerces.xinclude.XIncludeTextReader r0 = r0.fXInclude11TextReader     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            r20 = r0
            r21 = r10
            r20.setInputSource(r21)     // Catch:{ MalformedByteSequenceException -> 0x087b, CharConversionException -> 0x08ee, IOException -> 0x0914 }
            goto L_0x08d4
        L_0x08ee:
            r20 = move-exception
            r14 = r20
            r20 = r2
            r0 = r20
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter     // Catch:{ all -> 0x092f }
            r20 = r0
            java.lang.String r21 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            java.lang.String r22 = "CharConversionFailure"
            r23 = 0
            r24 = 2
            r25 = r14
            java.lang.String r20 = r20.reportError(r21, r22, r23, r24, r25)     // Catch:{ all -> 0x092f }
            r20 = r12
            if (r20 == 0) goto L_0x0912
            r20 = r12
            r20.close()     // Catch:{ IOException -> 0x0a0b }
        L_0x0912:
            goto L_0x06ea
        L_0x0914:
            r20 = move-exception
            r15 = r20
            r20 = r2
            r0 = r20
            boolean r0 = r0.fHasIncludeReportedContent     // Catch:{ all -> 0x092f }
            r20 = r0
            if (r20 == 0) goto L_0x093e
            org.apache.xerces.xni.XNIException r20 = new org.apache.xerces.xni.XNIException     // Catch:{ all -> 0x092f }
            r28 = r20
            r20 = r28
            r21 = r28
            r22 = r15
            r21.<init>((java.lang.Exception) r22)     // Catch:{ all -> 0x092f }
            throw r20     // Catch:{ all -> 0x092f }
        L_0x092f:
            r20 = move-exception
            r17 = r20
            r20 = r12
            if (r20 == 0) goto L_0x093b
            r20 = r12
            r20.close()     // Catch:{ IOException -> 0x099d }
        L_0x093b:
            r20 = r17
            throw r20
        L_0x093e:
            r20 = r2
            java.lang.String r21 = "TextResourceError"
            r22 = 2
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ all -> 0x092f }
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25     // Catch:{ all -> 0x092f }
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 1
            r25 = r15
            java.lang.String r25 = r25.getMessage()     // Catch:{ all -> 0x092f }
            r23[r24] = r25     // Catch:{ all -> 0x092f }
            r23 = r15
            r20.reportResourceError(r21, r22, r23)     // Catch:{ all -> 0x092f }
            r20 = 0
            r16 = r20
            r20 = r12
            if (r20 == 0) goto L_0x0979
            r20 = r12
            r20.close()     // Catch:{ IOException -> 0x0a42 }
        L_0x0979:
            r20 = r16
            r2 = r20
            goto L_0x0046
        L_0x097f:
            r20 = r2
            java.lang.String r21 = "InvalidParseValue"
            r22 = 1
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r5
            r23[r24] = r25
            r20.reportFatalError(r21, r22)
            goto L_0x06ea
        L_0x099d:
            r20 = move-exception
            r19 = r20
            r20 = r2
            java.lang.String r21 = "TextResourceError"
            r22 = 2
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 1
            r25 = r19
            java.lang.String r25 = r25.getMessage()
            r23[r24] = r25
            r23 = r19
            r20.reportResourceError(r21, r22, r23)
            r20 = 0
            r2 = r20
            goto L_0x0046
        L_0x09d4:
            r20 = move-exception
            r19 = r20
            r20 = r2
            java.lang.String r21 = "TextResourceError"
            r22 = 2
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 1
            r25 = r19
            java.lang.String r25 = r25.getMessage()
            r23[r24] = r25
            r23 = r19
            r20.reportResourceError(r21, r22, r23)
            r20 = 0
            r2 = r20
            goto L_0x0046
        L_0x0a0b:
            r20 = move-exception
            r19 = r20
            r20 = r2
            java.lang.String r21 = "TextResourceError"
            r22 = 2
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 1
            r25 = r19
            java.lang.String r25 = r25.getMessage()
            r23[r24] = r25
            r23 = r19
            r20.reportResourceError(r21, r22, r23)
            r20 = 0
            r2 = r20
            goto L_0x0046
        L_0x0a42:
            r20 = move-exception
            r19 = r20
            r20 = r2
            java.lang.String r21 = "TextResourceError"
            r22 = 2
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 1
            r25 = r19
            java.lang.String r25 = r25.getMessage()
            r23[r24] = r25
            r23 = r19
            r20.reportResourceError(r21, r22, r23)
            r20 = 0
            r2 = r20
            goto L_0x0046
        L_0x0a79:
            r20 = move-exception
            r19 = r20
            r20 = r2
            java.lang.String r21 = "TextResourceError"
            r22 = 2
            r0 = r22
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r22 = r0
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 0
            r25 = r4
            r23[r24] = r25
            r28 = r22
            r22 = r28
            r23 = r28
            r24 = 1
            r25 = r19
            java.lang.String r25 = r25.getMessage()
            r23[r24] = r25
            r23 = r19
            r20.reportResourceError(r21, r22, r23)
            r20 = 0
            r2 = r20
            goto L_0x0046
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.xinclude.XIncludeHandler.handleIncludeElement(org.apache.xerces.xni.XMLAttributes):boolean");
    }

    /* access modifiers changed from: protected */
    public boolean hasXIncludeNamespace(QName qName) {
        QName qName2 = qName;
        return qName2.uri == XINCLUDE_NS_URI || this.fNamespaceContext.getURI(qName2.prefix) == XINCLUDE_NS_URI;
    }

    public void ignorableWhitespace(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (this.fDocumentHandler != null && getState() == 1 && this.fResultDepth != 0) {
            this.fDocumentHandler.ignorableWhitespace(xMLString2, augmentations2);
        }
    }

    public void ignoredCharacters(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.ignoredCharacters(xMLString2, augmentations2);
        }
    }

    public void internalEntityDecl(String str, XMLString xMLString, XMLString xMLString2, Augmentations augmentations) throws XNIException {
        String str2 = str;
        XMLString xMLString3 = xMLString;
        XMLString xMLString4 = xMLString2;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.internalEntityDecl(str2, xMLString3, xMLString4, augmentations2);
        }
    }

    /* access modifiers changed from: protected */
    public boolean isFallbackElement(QName qName) {
        QName qName2 = qName;
        return qName2.localpart.equals(XINCLUDE_FALLBACK) && hasXIncludeNamespace(qName2);
    }

    /* access modifiers changed from: protected */
    public boolean isIncludeElement(QName qName) {
        QName qName2 = qName;
        return qName2.localpart.equals(XINCLUDE_INCLUDE) && hasXIncludeNamespace(qName2);
    }

    /* access modifiers changed from: protected */
    public boolean isRootDocument() {
        return this.fParentXIncludeHandler == null;
    }

    /* access modifiers changed from: protected */
    public boolean isTopLevelIncludedItem() {
        return isTopLevelIncludedItemViaInclude() || isTopLevelIncludedItemViaFallback();
    }

    /* access modifiers changed from: protected */
    public boolean isTopLevelIncludedItemViaFallback() {
        return getSawFallback(this.fDepth - 1);
    }

    /* access modifiers changed from: protected */
    public boolean isTopLevelIncludedItemViaInclude() {
        return this.fDepth == 1 && !isRootDocument();
    }

    /* access modifiers changed from: protected */
    public Augmentations modifyAugmentations(Augmentations augmentations) {
        return modifyAugmentations(augmentations, false);
    }

    /* access modifiers changed from: protected */
    public Augmentations modifyAugmentations(Augmentations augmentations, boolean z) {
        Augmentations augmentations2;
        Augmentations augmentations3 = augmentations;
        if (z || isTopLevelIncludedItem()) {
            if (augmentations3 == null) {
                new AugmentationsImpl();
                augmentations3 = augmentations2;
            }
            Object putItem = augmentations3.putItem(XINCLUDE_INCLUDED, Boolean.TRUE);
        }
        return augmentations3;
    }

    public void notationDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
        String str2 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        Augmentations augmentations2 = augmentations;
        addNotation(str2, xMLResourceIdentifier2, augmentations2);
        if (this.fDTDHandler != null) {
            this.fDTDHandler.notationDecl(str2, xMLResourceIdentifier2, augmentations2);
        }
    }

    /* access modifiers changed from: protected */
    public XMLAttributes processAttributes(XMLAttributes xMLAttributes) {
        StringTokenizer stringTokenizer;
        StringBuffer stringBuffer;
        XMLAttributes xMLAttributes2;
        XMLAttributes xMLAttributes3;
        XMLAttributes xMLAttributes4;
        String expandedSystemId;
        XMLAttributes xMLAttributes5;
        XMLAttributes xMLAttributes6 = xMLAttributes;
        if (isTopLevelIncludedItem()) {
            if (this.fFixupBaseURIs && !sameBaseURIAsIncludeParent()) {
                if (xMLAttributes6 == null) {
                    new XMLAttributesImpl();
                    xMLAttributes6 = xMLAttributes5;
                }
                try {
                    expandedSystemId = getRelativeBaseURI();
                } catch (URI.MalformedURIException e) {
                    URI.MalformedURIException malformedURIException = e;
                    expandedSystemId = this.fCurrentBaseURI.getExpandedSystemId();
                }
                xMLAttributes6.setSpecified(xMLAttributes6.addAttribute(XML_BASE_QNAME, XMLSymbols.fCDATASymbol, expandedSystemId), true);
            }
            if (this.fFixupLanguage && !sameLanguageAsIncludeParent()) {
                if (xMLAttributes6 == null) {
                    new XMLAttributesImpl();
                    xMLAttributes6 = xMLAttributes4;
                }
                xMLAttributes6.setSpecified(xMLAttributes6.addAttribute(XML_LANG_QNAME, XMLSymbols.fCDATASymbol, this.fCurrentLanguage), true);
            }
            Enumeration allPrefixes = this.fNamespaceContext.getAllPrefixes();
            while (allPrefixes.hasMoreElements()) {
                String str = (String) allPrefixes.nextElement();
                String uRIFromIncludeParent = this.fNamespaceContext.getURIFromIncludeParent(str);
                String uri = this.fNamespaceContext.getURI(str);
                if (!(uRIFromIncludeParent == uri || xMLAttributes6 == null)) {
                    if (str == XMLSymbols.EMPTY_STRING) {
                        if (xMLAttributes6.getValue(NamespaceContext.XMLNS_URI, XMLSymbols.PREFIX_XMLNS) == null) {
                            if (xMLAttributes6 == null) {
                                new XMLAttributesImpl();
                                xMLAttributes6 = xMLAttributes3;
                            }
                            QName qName = (QName) NEW_NS_ATTR_QNAME.clone();
                            qName.prefix = null;
                            qName.localpart = XMLSymbols.PREFIX_XMLNS;
                            qName.rawname = XMLSymbols.PREFIX_XMLNS;
                            xMLAttributes6.setSpecified(xMLAttributes6.addAttribute(qName, XMLSymbols.fCDATASymbol, uri != null ? uri : XMLSymbols.EMPTY_STRING), true);
                            boolean declarePrefix = this.fNamespaceContext.declarePrefix(str, uri);
                        }
                    } else if (xMLAttributes6.getValue(NamespaceContext.XMLNS_URI, str) == null) {
                        if (xMLAttributes6 == null) {
                            new XMLAttributesImpl();
                            xMLAttributes6 = xMLAttributes2;
                        }
                        QName qName2 = (QName) NEW_NS_ATTR_QNAME.clone();
                        qName2.localpart = str;
                        new StringBuffer();
                        QName qName3 = qName2;
                        qName3.rawname = stringBuffer.append(qName3.rawname).append(str).toString();
                        qName2.rawname = this.fSymbolTable != null ? this.fSymbolTable.addSymbol(qName2.rawname) : qName2.rawname.intern();
                        xMLAttributes6.setSpecified(xMLAttributes6.addAttribute(qName2, XMLSymbols.fCDATASymbol, uri != null ? uri : XMLSymbols.EMPTY_STRING), true);
                        boolean declarePrefix2 = this.fNamespaceContext.declarePrefix(str, uri);
                    }
                }
            }
        }
        if (xMLAttributes6 != null) {
            int length = xMLAttributes6.getLength();
            for (int i = 0; i < length; i++) {
                String type = xMLAttributes6.getType(i);
                String value = xMLAttributes6.getValue(i);
                if (type == XMLSymbols.fENTITYSymbol) {
                    checkUnparsedEntity(value);
                }
                if (type == XMLSymbols.fENTITIESSymbol) {
                    new StringTokenizer(value);
                    StringTokenizer stringTokenizer2 = stringTokenizer;
                    while (stringTokenizer2.hasMoreTokens()) {
                        checkUnparsedEntity(stringTokenizer2.nextToken());
                    }
                } else if (type == XMLSymbols.fNOTATIONSymbol) {
                    checkNotation(value);
                }
            }
        }
        return xMLAttributes6;
    }

    /* access modifiers changed from: protected */
    public void processXMLBaseAttributes(XMLAttributes xMLAttributes) {
        String value = xMLAttributes.getValue(NamespaceContext.XML_URI, "base");
        if (value != null) {
            try {
                String expandSystemId = XMLEntityManager.expandSystemId(value, this.fCurrentBaseURI.getExpandedSystemId(), false);
                this.fCurrentBaseURI.setLiteralSystemId(value);
                this.fCurrentBaseURI.setBaseSystemId(this.fCurrentBaseURI.getExpandedSystemId());
                this.fCurrentBaseURI.setExpandedSystemId(expandSystemId);
                saveBaseURI();
            } catch (URI.MalformedURIException e) {
                URI.MalformedURIException malformedURIException = e;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void processXMLLangAttributes(XMLAttributes xMLAttributes) {
        String value = xMLAttributes.getValue(NamespaceContext.XML_URI, "lang");
        if (value != null) {
            this.fCurrentLanguage = value;
            saveLanguage(this.fCurrentLanguage);
        }
    }

    public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
        String str2 = str;
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (!this.fInDTD) {
            if (this.fDocumentHandler != null && getState() == 1) {
                this.fDepth++;
                this.fDocumentHandler.processingInstruction(str2, xMLString2, modifyAugmentations(augmentations2));
                this.fDepth--;
            }
        } else if (this.fDTDHandler != null) {
            this.fDTDHandler.processingInstruction(str2, xMLString2, augmentations2);
        }
    }

    /* access modifiers changed from: protected */
    public void reportFatalError(String str) {
        reportFatalError(str, (Object[]) null);
    }

    /* access modifiers changed from: protected */
    public void reportFatalError(String str, Object[] objArr) {
        reportFatalError(str, objArr, (Exception) null);
    }

    /* access modifiers changed from: protected */
    public void reportFatalError(String str, Object[] objArr, Exception exc) {
        reportError(str, objArr, 2, exc);
    }

    /* access modifiers changed from: protected */
    public void reportResourceError(String str) {
        reportResourceError(str, (Object[]) null);
    }

    /* access modifiers changed from: protected */
    public void reportResourceError(String str, Object[] objArr) {
        reportResourceError(str, objArr, (Exception) null);
    }

    /* access modifiers changed from: protected */
    public void reportResourceError(String str, Object[] objArr, Exception exc) {
        reportError(str, objArr, 0, exc);
    }

    /* JADX WARNING: Removed duplicated region for block: B:118:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x01af  */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x01bd  */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x01e3 A[Catch:{ XMLConfigurationException -> 0x027e }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void reset(org.apache.xerces.xni.parser.XMLComponentManager r11) throws org.apache.xerces.xni.XNIException {
        /*
            r10 = this;
            r0 = r10
            r1 = r11
            r6 = r0
            r7 = 0
            r6.fNamespaceContext = r7
            r6 = r0
            r7 = 0
            r6.fDepth = r7
            r6 = r0
            r7 = r0
            boolean r7 = r7.isRootDocument()
            if (r7 == 0) goto L_0x007b
            r7 = 0
        L_0x0013:
            r6.fResultDepth = r7
            r6 = r0
            java.util.ArrayList r6 = r6.fNotations
            r6.clear()
            r6 = r0
            java.util.ArrayList r6 = r6.fUnparsedEntities
            r6.clear()
            r6 = r0
            r7 = 0
            r6.fParentRelativeURI = r7
            r6 = r0
            r7 = 0
            r6.fIsXML11 = r7
            r6 = r0
            r7 = 0
            r6.fInDTD = r7
            r6 = r0
            r7 = 0
            r6.fSeenRootElement = r7
            r6 = r0
            org.apache.xerces.util.IntStack r6 = r6.fBaseURIScope
            r6.clear()
            r6 = r0
            java.util.Stack r6 = r6.fBaseURI
            r6.clear()
            r6 = r0
            java.util.Stack r6 = r6.fLiteralSystemID
            r6.clear()
            r6 = r0
            java.util.Stack r6 = r6.fExpandedSystemID
            r6.clear()
            r6 = r0
            org.apache.xerces.util.IntStack r6 = r6.fLanguageScope
            r6.clear()
            r6 = r0
            java.util.Stack r6 = r6.fLanguageStack
            r6.clear()
            r6 = 0
            r2 = r6
        L_0x0057:
            r6 = r2
            r7 = r0
            int[] r7 = r7.fState
            int r7 = r7.length
            if (r6 < r7) goto L_0x0083
            r6 = 0
            r3 = r6
        L_0x0060:
            r6 = r3
            r7 = r0
            boolean[] r7 = r7.fSawFallback
            int r7 = r7.length
            if (r6 < r7) goto L_0x008d
            r6 = 0
            r4 = r6
        L_0x0069:
            r6 = r4
            r7 = r0
            boolean[] r7 = r7.fSawInclude
            int r7 = r7.length
            if (r6 < r7) goto L_0x0097
            r6 = r1
            java.lang.String r7 = "http://apache.org/xml/features/internal/parser-settings"
            boolean r6 = r6.getFeature(r7)     // Catch:{ XMLConfigurationException -> 0x0209 }
            if (r6 != 0) goto L_0x00a1
        L_0x007a:
            return
        L_0x007b:
            r7 = r0
            org.apache.xerces.xinclude.XIncludeHandler r7 = r7.fParentXIncludeHandler
            int r7 = r7.getResultDepth()
            goto L_0x0013
        L_0x0083:
            r6 = r0
            int[] r6 = r6.fState
            r7 = r2
            r8 = 1
            r6[r7] = r8
            int r2 = r2 + 1
            goto L_0x0057
        L_0x008d:
            r6 = r0
            boolean[] r6 = r6.fSawFallback
            r7 = r3
            r8 = 0
            r6[r7] = r8
            int r3 = r3 + 1
            goto L_0x0060
        L_0x0097:
            r6 = r0
            boolean[] r6 = r6.fSawInclude
            r7 = r4
            r8 = 0
            r6[r7] = r8
            int r4 = r4 + 1
            goto L_0x0069
        L_0x00a1:
            r6 = r0
            r7 = 1
            r6.fNeedCopyFeatures = r7
            r6 = r0
            r7 = r1
            java.lang.String r8 = "http://xml.org/sax/features/allow-dtd-events-after-endDTD"
            boolean r7 = r7.getFeature(r8)     // Catch:{ XMLConfigurationException -> 0x020d }
            r6.fSendUEAndNotationEvents = r7     // Catch:{ XMLConfigurationException -> 0x020d }
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x020d }
            if (r6 == 0) goto L_0x00c1
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x020d }
            java.lang.String r7 = "http://xml.org/sax/features/allow-dtd-events-after-endDTD"
            r8 = r0
            boolean r8 = r8.fSendUEAndNotationEvents     // Catch:{ XMLConfigurationException -> 0x020d }
            r6.setFeature(r7, r8)     // Catch:{ XMLConfigurationException -> 0x020d }
        L_0x00c1:
            r6 = r0
            r7 = r1
            java.lang.String r8 = "http://apache.org/xml/features/xinclude/fixup-base-uris"
            boolean r7 = r7.getFeature(r8)     // Catch:{ XMLConfigurationException -> 0x0211 }
            r6.fFixupBaseURIs = r7     // Catch:{ XMLConfigurationException -> 0x0211 }
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x0211 }
            if (r6 == 0) goto L_0x00dd
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x0211 }
            java.lang.String r7 = "http://apache.org/xml/features/xinclude/fixup-base-uris"
            r8 = r0
            boolean r8 = r8.fFixupBaseURIs     // Catch:{ XMLConfigurationException -> 0x0211 }
            r6.setFeature(r7, r8)     // Catch:{ XMLConfigurationException -> 0x0211 }
        L_0x00dd:
            r6 = r0
            r7 = r1
            java.lang.String r8 = "http://apache.org/xml/features/xinclude/fixup-language"
            boolean r7 = r7.getFeature(r8)     // Catch:{ XMLConfigurationException -> 0x0219 }
            r6.fFixupLanguage = r7     // Catch:{ XMLConfigurationException -> 0x0219 }
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x0219 }
            if (r6 == 0) goto L_0x00f9
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x0219 }
            java.lang.String r7 = "http://apache.org/xml/features/xinclude/fixup-language"
            r8 = r0
            boolean r8 = r8.fFixupLanguage     // Catch:{ XMLConfigurationException -> 0x0219 }
            r6.setFeature(r7, r8)     // Catch:{ XMLConfigurationException -> 0x0219 }
        L_0x00f9:
            r6 = r1
            java.lang.String r7 = "http://apache.org/xml/properties/internal/symbol-table"
            java.lang.Object r6 = r6.getProperty(r7)     // Catch:{ XMLConfigurationException -> 0x0221 }
            org.apache.xerces.util.SymbolTable r6 = (org.apache.xerces.util.SymbolTable) r6     // Catch:{ XMLConfigurationException -> 0x0221 }
            r5 = r6
            r6 = r5
            if (r6 == 0) goto L_0x011a
            r6 = r0
            r7 = r5
            r6.fSymbolTable = r7     // Catch:{ XMLConfigurationException -> 0x0221 }
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x0221 }
            if (r6 == 0) goto L_0x011a
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x0221 }
            java.lang.String r7 = "http://apache.org/xml/properties/internal/symbol-table"
            r8 = r5
            r6.setProperty(r7, r8)     // Catch:{ XMLConfigurationException -> 0x0221 }
        L_0x011a:
            r6 = r1
            java.lang.String r7 = "http://apache.org/xml/properties/internal/error-reporter"
            java.lang.Object r6 = r6.getProperty(r7)     // Catch:{ XMLConfigurationException -> 0x0229 }
            org.apache.xerces.impl.XMLErrorReporter r6 = (org.apache.xerces.impl.XMLErrorReporter) r6     // Catch:{ XMLConfigurationException -> 0x0229 }
            r5 = r6
            r6 = r5
            if (r6 == 0) goto L_0x013c
            r6 = r0
            r7 = r5
            r6.setErrorReporter(r7)     // Catch:{ XMLConfigurationException -> 0x0229 }
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x0229 }
            if (r6 == 0) goto L_0x013c
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x0229 }
            java.lang.String r7 = "http://apache.org/xml/properties/internal/error-reporter"
            r8 = r5
            r6.setProperty(r7, r8)     // Catch:{ XMLConfigurationException -> 0x0229 }
        L_0x013c:
            r6 = r1
            java.lang.String r7 = "http://apache.org/xml/properties/internal/entity-resolver"
            java.lang.Object r6 = r6.getProperty(r7)     // Catch:{ XMLConfigurationException -> 0x0231 }
            org.apache.xerces.xni.parser.XMLEntityResolver r6 = (org.apache.xerces.xni.parser.XMLEntityResolver) r6     // Catch:{ XMLConfigurationException -> 0x0231 }
            r5 = r6
            r6 = r5
            if (r6 == 0) goto L_0x015d
            r6 = r0
            r7 = r5
            r6.fEntityResolver = r7     // Catch:{ XMLConfigurationException -> 0x0231 }
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x0231 }
            if (r6 == 0) goto L_0x015d
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x0231 }
            java.lang.String r7 = "http://apache.org/xml/properties/internal/entity-resolver"
            r8 = r5
            r6.setProperty(r7, r8)     // Catch:{ XMLConfigurationException -> 0x0231 }
        L_0x015d:
            r6 = r1
            java.lang.String r7 = "http://apache.org/xml/properties/security-manager"
            java.lang.Object r6 = r6.getProperty(r7)     // Catch:{ XMLConfigurationException -> 0x0239 }
            org.apache.xerces.util.SecurityManager r6 = (org.apache.xerces.util.SecurityManager) r6     // Catch:{ XMLConfigurationException -> 0x0239 }
            r5 = r6
            r6 = r5
            if (r6 == 0) goto L_0x017e
            r6 = r0
            r7 = r5
            r6.fSecurityManager = r7     // Catch:{ XMLConfigurationException -> 0x0239 }
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x0239 }
            if (r6 == 0) goto L_0x017e
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x0239 }
            java.lang.String r7 = "http://apache.org/xml/properties/security-manager"
            r8 = r5
            r6.setProperty(r7, r8)     // Catch:{ XMLConfigurationException -> 0x0239 }
        L_0x017e:
            r6 = r1
            java.lang.String r7 = "http://apache.org/xml/properties/input-buffer-size"
            java.lang.Object r6 = r6.getProperty(r7)     // Catch:{ XMLConfigurationException -> 0x0254 }
            java.lang.Integer r6 = (java.lang.Integer) r6     // Catch:{ XMLConfigurationException -> 0x0254 }
            r5 = r6
            r6 = r5
            if (r6 == 0) goto L_0x0241
            r6 = r5
            int r6 = r6.intValue()     // Catch:{ XMLConfigurationException -> 0x0254 }
            if (r6 <= 0) goto L_0x0241
            r6 = r0
            r7 = r5
            int r7 = r7.intValue()     // Catch:{ XMLConfigurationException -> 0x0254 }
            r6.fBufferSize = r7     // Catch:{ XMLConfigurationException -> 0x0254 }
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x0254 }
            if (r6 == 0) goto L_0x01aa
            r6 = r0
            org.apache.xerces.xni.parser.XMLParserConfiguration r6 = r6.fChildConfig     // Catch:{ XMLConfigurationException -> 0x0254 }
            java.lang.String r7 = "http://apache.org/xml/properties/input-buffer-size"
            r8 = r5
            r6.setProperty(r7, r8)     // Catch:{ XMLConfigurationException -> 0x0254 }
        L_0x01aa:
            r6 = r0
            org.apache.xerces.xinclude.XIncludeTextReader r6 = r6.fXInclude10TextReader
            if (r6 == 0) goto L_0x01b8
            r6 = r0
            org.apache.xerces.xinclude.XIncludeTextReader r6 = r6.fXInclude10TextReader
            r7 = r0
            int r7 = r7.fBufferSize
            r6.setBufferSize(r7)
        L_0x01b8:
            r6 = r0
            org.apache.xerces.xinclude.XIncludeTextReader r6 = r6.fXInclude11TextReader
            if (r6 == 0) goto L_0x01c6
            r6 = r0
            org.apache.xerces.xinclude.XIncludeTextReader r6 = r6.fXInclude11TextReader
            r7 = r0
            int r7 = r7.fBufferSize
            r6.setBufferSize(r7)
        L_0x01c6:
            r6 = r0
            org.apache.xerces.util.ParserConfigurationSettings r7 = new org.apache.xerces.util.ParserConfigurationSettings
            r9 = r7
            r7 = r9
            r8 = r9
            r8.<init>()
            r6.fSettings = r7
            r6 = r0
            r7 = r1
            r8 = r0
            org.apache.xerces.util.ParserConfigurationSettings r8 = r8.fSettings
            r6.copyFeatures((org.apache.xerces.xni.parser.XMLComponentManager) r7, (org.apache.xerces.util.ParserConfigurationSettings) r8)
            r6 = r1
            java.lang.String r7 = "http://apache.org/xml/features/validation/schema"
            boolean r6 = r6.getFeature(r7)     // Catch:{ XMLConfigurationException -> 0x027e }
            if (r6 == 0) goto L_0x0207
            r6 = r0
            org.apache.xerces.util.ParserConfigurationSettings r6 = r6.fSettings     // Catch:{ XMLConfigurationException -> 0x027e }
            java.lang.String r7 = "http://apache.org/xml/features/validation/schema"
            r8 = 0
            r6.setFeature(r7, r8)     // Catch:{ XMLConfigurationException -> 0x027e }
            java.lang.String r6 = org.apache.xerces.impl.Constants.NS_XMLSCHEMA     // Catch:{ XMLConfigurationException -> 0x027e }
            r7 = r1
            java.lang.String r8 = "http://java.sun.com/xml/jaxp/properties/schemaLanguage"
            java.lang.Object r7 = r7.getProperty(r8)     // Catch:{ XMLConfigurationException -> 0x027e }
            boolean r6 = r6.equals(r7)     // Catch:{ XMLConfigurationException -> 0x027e }
            if (r6 == 0) goto L_0x0269
            r6 = r0
            org.apache.xerces.util.ParserConfigurationSettings r6 = r6.fSettings     // Catch:{ XMLConfigurationException -> 0x027e }
            java.lang.String r7 = "http://xml.org/sax/features/validation"
            r8 = 0
            r6.setFeature(r7, r8)     // Catch:{ XMLConfigurationException -> 0x027e }
        L_0x0207:
            goto L_0x007a
        L_0x0209:
            r6 = move-exception
            r5 = r6
            goto L_0x00a1
        L_0x020d:
            r6 = move-exception
            r5 = r6
            goto L_0x00c1
        L_0x0211:
            r6 = move-exception
            r5 = r6
            r6 = r0
            r7 = 1
            r6.fFixupBaseURIs = r7
            goto L_0x00dd
        L_0x0219:
            r6 = move-exception
            r5 = r6
            r6 = r0
            r7 = 1
            r6.fFixupLanguage = r7
            goto L_0x00f9
        L_0x0221:
            r6 = move-exception
            r5 = r6
            r6 = r0
            r7 = 0
            r6.fSymbolTable = r7
            goto L_0x011a
        L_0x0229:
            r6 = move-exception
            r5 = r6
            r6 = r0
            r7 = 0
            r6.fErrorReporter = r7
            goto L_0x013c
        L_0x0231:
            r6 = move-exception
            r5 = r6
            r6 = r0
            r7 = 0
            r6.fEntityResolver = r7
            goto L_0x015d
        L_0x0239:
            r6 = move-exception
            r5 = r6
            r6 = r0
            r7 = 0
            r6.fSecurityManager = r7
            goto L_0x017e
        L_0x0241:
            r6 = r0
            r7 = r0
            java.lang.String r8 = "http://apache.org/xml/properties/input-buffer-size"
            java.lang.Object r7 = r7.getPropertyDefault(r8)     // Catch:{ XMLConfigurationException -> 0x0254 }
            java.lang.Integer r7 = (java.lang.Integer) r7     // Catch:{ XMLConfigurationException -> 0x0254 }
            int r7 = r7.intValue()     // Catch:{ XMLConfigurationException -> 0x0254 }
            r6.fBufferSize = r7     // Catch:{ XMLConfigurationException -> 0x0254 }
            goto L_0x01aa
        L_0x0254:
            r6 = move-exception
            r5 = r6
            r6 = r0
            r7 = r0
            java.lang.String r8 = "http://apache.org/xml/properties/input-buffer-size"
            java.lang.Object r7 = r7.getPropertyDefault(r8)
            java.lang.Integer r7 = (java.lang.Integer) r7
            int r7 = r7.intValue()
            r6.fBufferSize = r7
            goto L_0x01aa
        L_0x0269:
            r6 = r1
            java.lang.String r7 = "http://xml.org/sax/features/validation"
            boolean r6 = r6.getFeature(r7)     // Catch:{ XMLConfigurationException -> 0x027e }
            if (r6 == 0) goto L_0x0207
            r6 = r0
            org.apache.xerces.util.ParserConfigurationSettings r6 = r6.fSettings     // Catch:{ XMLConfigurationException -> 0x027e }
            java.lang.String r7 = "http://apache.org/xml/features/validation/dynamic"
            r8 = 1
            r6.setFeature(r7, r8)     // Catch:{ XMLConfigurationException -> 0x027e }
            goto L_0x0207
        L_0x027e:
            r6 = move-exception
            r5 = r6
            goto L_0x0207
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.xinclude.XIncludeHandler.reset(org.apache.xerces.xni.parser.XMLComponentManager):void");
    }

    /* access modifiers changed from: protected */
    public void restoreBaseURI() {
        Object pop = this.fBaseURI.pop();
        Object pop2 = this.fLiteralSystemID.pop();
        Object pop3 = this.fExpandedSystemID.pop();
        int pop4 = this.fBaseURIScope.pop();
        this.fCurrentBaseURI.setBaseSystemId((String) this.fBaseURI.peek());
        this.fCurrentBaseURI.setLiteralSystemId((String) this.fLiteralSystemID.peek());
        this.fCurrentBaseURI.setExpandedSystemId((String) this.fExpandedSystemID.peek());
    }

    public String restoreLanguage() {
        Object pop = this.fLanguageStack.pop();
        int pop2 = this.fLanguageScope.pop();
        return (String) this.fLanguageStack.peek();
    }

    /* access modifiers changed from: protected */
    public boolean sameBaseURIAsIncludeParent() {
        String includeParentBaseURI = getIncludeParentBaseURI();
        return includeParentBaseURI != null && includeParentBaseURI.equals(this.fCurrentBaseURI.getExpandedSystemId());
    }

    /* access modifiers changed from: protected */
    public boolean sameLanguageAsIncludeParent() {
        String includeParentLanguage = getIncludeParentLanguage();
        return includeParentLanguage != null && includeParentLanguage.equalsIgnoreCase(this.fCurrentLanguage);
    }

    /* access modifiers changed from: protected */
    public void saveBaseURI() {
        this.fBaseURIScope.push(this.fDepth);
        Object push = this.fBaseURI.push(this.fCurrentBaseURI.getBaseSystemId());
        Object push2 = this.fLiteralSystemID.push(this.fCurrentBaseURI.getLiteralSystemId());
        Object push3 = this.fExpandedSystemID.push(this.fCurrentBaseURI.getExpandedSystemId());
    }

    /* access modifiers changed from: protected */
    public void saveLanguage(String str) {
        this.fLanguageScope.push(this.fDepth);
        Object push = this.fLanguageStack.push(str);
    }

    /* access modifiers changed from: protected */
    public boolean searchForRecursiveIncludes(String str) {
        String str2 = str;
        if (str2.equals(this.fCurrentBaseURI.getExpandedSystemId())) {
            return true;
        }
        if (this.fParentXIncludeHandler == null) {
            return false;
        }
        return this.fParentXIncludeHandler.searchForRecursiveIncludes(str2);
    }

    public void setDTDHandler(XMLDTDHandler xMLDTDHandler) {
        XMLDTDHandler xMLDTDHandler2 = xMLDTDHandler;
        this.fDTDHandler = xMLDTDHandler2;
    }

    public void setDTDSource(XMLDTDSource xMLDTDSource) {
        XMLDTDSource xMLDTDSource2 = xMLDTDSource;
        this.fDTDSource = xMLDTDSource2;
    }

    public void setDocumentHandler(XMLDocumentHandler xMLDocumentHandler) {
        XMLDocumentHandler xMLDocumentHandler2 = xMLDocumentHandler;
        if (this.fDocumentHandler != xMLDocumentHandler2) {
            this.fDocumentHandler = xMLDocumentHandler2;
            if (this.fXIncludeChildConfig != null) {
                this.fXIncludeChildConfig.setDocumentHandler(xMLDocumentHandler2);
            }
            if (this.fXPointerChildConfig != null) {
                this.fXPointerChildConfig.setDocumentHandler(xMLDocumentHandler2);
            }
        }
    }

    public void setDocumentSource(XMLDocumentSource xMLDocumentSource) {
        XMLDocumentSource xMLDocumentSource2 = xMLDocumentSource;
        this.fDocumentSource = xMLDocumentSource2;
    }

    public void setFeature(String str, boolean z) throws XMLConfigurationException {
        String str2 = str;
        boolean z2 = z;
        if (str2.equals(ALLOW_UE_AND_NOTATION_EVENTS)) {
            this.fSendUEAndNotationEvents = z2;
        }
        if (this.fSettings != null) {
            this.fNeedCopyFeatures = true;
            this.fSettings.setFeature(str2, z2);
        }
    }

    /* access modifiers changed from: protected */
    public void setHref(String str) {
        String str2 = str;
        this.fHrefFromParent = str2;
    }

    /* access modifiers changed from: protected */
    public void setParent(XIncludeHandler xIncludeHandler) {
        XIncludeHandler xIncludeHandler2 = xIncludeHandler;
        this.fParentXIncludeHandler = xIncludeHandler2;
    }

    public void setProperty(String str, Object obj) throws XMLConfigurationException {
        String str2 = str;
        Object obj2 = obj;
        if (str2.equals(SYMBOL_TABLE)) {
            this.fSymbolTable = (SymbolTable) obj2;
            if (this.fChildConfig != null) {
                this.fChildConfig.setProperty(str2, obj2);
            }
        } else if (str2.equals(ERROR_REPORTER)) {
            setErrorReporter((XMLErrorReporter) obj2);
            if (this.fChildConfig != null) {
                this.fChildConfig.setProperty(str2, obj2);
            }
        } else if (str2.equals(ENTITY_RESOLVER)) {
            this.fEntityResolver = (XMLEntityResolver) obj2;
            if (this.fChildConfig != null) {
                this.fChildConfig.setProperty(str2, obj2);
            }
        } else if (str2.equals(SECURITY_MANAGER)) {
            this.fSecurityManager = (SecurityManager) obj2;
            if (this.fChildConfig != null) {
                this.fChildConfig.setProperty(str2, obj2);
            }
        } else if (str2.equals(BUFFER_SIZE)) {
            Integer num = (Integer) obj2;
            if (this.fChildConfig != null) {
                this.fChildConfig.setProperty(str2, obj2);
            }
            if (num != null && num.intValue() > 0) {
                this.fBufferSize = num.intValue();
                if (this.fXInclude10TextReader != null) {
                    this.fXInclude10TextReader.setBufferSize(this.fBufferSize);
                }
                if (this.fXInclude11TextReader != null) {
                    this.fXInclude11TextReader.setBufferSize(this.fBufferSize);
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void setSawFallback(int i, boolean z) {
        int i2 = i;
        boolean z2 = z;
        if (i2 >= this.fSawFallback.length) {
            boolean[] zArr = new boolean[(i2 * 2)];
            System.arraycopy(this.fSawFallback, 0, zArr, 0, this.fSawFallback.length);
            this.fSawFallback = zArr;
        }
        this.fSawFallback[i2] = z2;
    }

    /* access modifiers changed from: protected */
    public void setSawInclude(int i, boolean z) {
        int i2 = i;
        boolean z2 = z;
        if (i2 >= this.fSawInclude.length) {
            boolean[] zArr = new boolean[(i2 * 2)];
            System.arraycopy(this.fSawInclude, 0, zArr, 0, this.fSawInclude.length);
            this.fSawInclude = zArr;
        }
        this.fSawInclude[i2] = z2;
    }

    /* access modifiers changed from: protected */
    public void setState(int i) {
        int i2 = i;
        if (this.fDepth >= this.fState.length) {
            int[] iArr = new int[(this.fDepth * 2)];
            System.arraycopy(this.fState, 0, iArr, 0, this.fState.length);
            this.fState = iArr;
        }
        this.fState[this.fDepth] = i2;
    }

    /* access modifiers changed from: protected */
    public void setXIncludeLocator(XMLLocatorWrapper xMLLocatorWrapper) {
        XMLLocatorWrapper xMLLocatorWrapper2 = xMLLocatorWrapper;
        this.fXIncludeLocator = xMLLocatorWrapper2;
    }

    /* access modifiers changed from: protected */
    public void setupCurrentBaseURI(XMLLocator xMLLocator) {
        XMLLocator xMLLocator2 = xMLLocator;
        this.fCurrentBaseURI.setBaseSystemId(xMLLocator2.getBaseSystemId());
        if (xMLLocator2.getLiteralSystemId() != null) {
            this.fCurrentBaseURI.setLiteralSystemId(xMLLocator2.getLiteralSystemId());
        } else {
            this.fCurrentBaseURI.setLiteralSystemId(this.fHrefFromParent);
        }
        String expandedSystemId = xMLLocator2.getExpandedSystemId();
        if (expandedSystemId == null) {
            try {
                expandedSystemId = XMLEntityManager.expandSystemId(this.fCurrentBaseURI.getLiteralSystemId(), this.fCurrentBaseURI.getBaseSystemId(), false);
                if (expandedSystemId == null) {
                    expandedSystemId = this.fCurrentBaseURI.getLiteralSystemId();
                }
            } catch (URI.MalformedURIException e) {
                URI.MalformedURIException malformedURIException = e;
                reportFatalError("ExpandedSystemId");
            }
        }
        this.fCurrentBaseURI.setExpandedSystemId(expandedSystemId);
    }

    public void startAttlist(String str, Augmentations augmentations) throws XNIException {
        String str2 = str;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.startAttlist(str2, augmentations2);
        }
    }

    public void startCDATA(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        if (this.fDocumentHandler != null && getState() == 1 && this.fResultDepth != 0) {
            this.fDocumentHandler.startCDATA(augmentations2);
        }
    }

    public void startConditional(short s, Augmentations augmentations) throws XNIException {
        short s2 = s;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.startConditional(s2, augmentations2);
        }
    }

    public void startDTD(XMLLocator xMLLocator, Augmentations augmentations) throws XNIException {
        XMLLocator xMLLocator2 = xMLLocator;
        Augmentations augmentations2 = augmentations;
        this.fInDTD = true;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.startDTD(xMLLocator2, augmentations2);
        }
    }

    public void startDocument(XMLLocator xMLLocator, String str, NamespaceContext namespaceContext, Augmentations augmentations) throws XNIException {
        Augmentations augmentations2;
        XMLLocator xMLLocator2 = xMLLocator;
        String str2 = str;
        NamespaceContext namespaceContext2 = namespaceContext;
        Augmentations augmentations3 = augmentations;
        this.fErrorReporter.setDocumentLocator(xMLLocator2);
        if (!(namespaceContext2 instanceof XIncludeNamespaceSupport)) {
            reportFatalError("IncompatibleNamespaceContext");
        }
        this.fNamespaceContext = (XIncludeNamespaceSupport) namespaceContext2;
        this.fDocLocation = xMLLocator2;
        this.fXIncludeLocator.setLocator(this.fDocLocation);
        setupCurrentBaseURI(xMLLocator2);
        saveBaseURI();
        if (augmentations3 == null) {
            new AugmentationsImpl();
            augmentations3 = augmentations2;
        }
        Object putItem = augmentations3.putItem(CURRENT_BASE_URI, this.fCurrentBaseURI);
        if (!isRootDocument()) {
            this.fParentXIncludeHandler.fHasIncludeReportedContent = true;
            if (this.fParentXIncludeHandler.searchForRecursiveIncludes(this.fCurrentBaseURI.getExpandedSystemId())) {
                reportFatalError("RecursiveInclude", new Object[]{this.fCurrentBaseURI.getExpandedSystemId()});
            }
        }
        this.fCurrentLanguage = XMLSymbols.EMPTY_STRING;
        saveLanguage(this.fCurrentLanguage);
        if (isRootDocument() && this.fDocumentHandler != null) {
            this.fDocumentHandler.startDocument(this.fXIncludeLocator, str2, namespaceContext2, augmentations3);
        }
    }

    public void startElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        this.fDepth++;
        int state = getState(this.fDepth - 1);
        if (state == 3 && getState(this.fDepth - 2) == 3) {
            setState(2);
        } else {
            setState(state);
        }
        processXMLBaseAttributes(xMLAttributes2);
        if (this.fFixupLanguage) {
            processXMLLangAttributes(xMLAttributes2);
        }
        if (isIncludeElement(qName2)) {
            if (handleIncludeElement(xMLAttributes2)) {
                setState(2);
            } else {
                setState(3);
            }
        } else if (isFallbackElement(qName2)) {
            handleFallbackElement();
        } else if (hasXIncludeNamespace(qName2)) {
            if (getSawInclude(this.fDepth - 1)) {
                reportFatalError("IncludeChild", new Object[]{qName2.rawname});
            }
            if (getSawFallback(this.fDepth - 1)) {
                reportFatalError("FallbackChild", new Object[]{qName2.rawname});
            }
            if (getState() == 1) {
                int i = this.fResultDepth;
                int i2 = i;
                this.fResultDepth = i + 1;
                if (i2 == 0) {
                    checkMultipleRootElements();
                }
                if (this.fDocumentHandler != null) {
                    this.fDocumentHandler.startElement(qName2, processAttributes(xMLAttributes2), modifyAugmentations(augmentations2));
                }
            }
        } else if (getState() == 1) {
            int i3 = this.fResultDepth;
            int i4 = i3;
            this.fResultDepth = i3 + 1;
            if (i4 == 0) {
                checkMultipleRootElements();
            }
            if (this.fDocumentHandler != null) {
                this.fDocumentHandler.startElement(qName2, processAttributes(xMLAttributes2), modifyAugmentations(augmentations2));
            }
        }
    }

    public void startExternalSubset(XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.startExternalSubset(xMLResourceIdentifier2, augmentations2);
        }
    }

    public void startGeneralEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        if (getState() != 1) {
            return;
        }
        if (this.fResultDepth == 0) {
            if (augmentations2 != null && Boolean.TRUE.equals(augmentations2.getItem("ENTITY_SKIPPED"))) {
                reportFatalError("UnexpandedEntityReferenceIllegal");
            }
        } else if (this.fDocumentHandler != null) {
            this.fDocumentHandler.startGeneralEntity(str3, xMLResourceIdentifier2, str4, augmentations2);
        }
    }

    public void startParameterEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        if (this.fDTDHandler != null) {
            this.fDTDHandler.startParameterEntity(str3, xMLResourceIdentifier2, str4, augmentations2);
        }
    }

    public void textDecl(String str, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        if (this.fDocumentHandler != null && getState() == 1) {
            this.fDocumentHandler.textDecl(str3, str4, augmentations2);
        }
    }

    public void unparsedEntityDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        addUnparsedEntity(str3, xMLResourceIdentifier2, str4, augmentations2);
        if (this.fDTDHandler != null) {
            this.fDTDHandler.unparsedEntityDecl(str3, xMLResourceIdentifier2, str4, augmentations2);
        }
    }

    public void xmlDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        Augmentations augmentations2 = augmentations;
        this.fIsXML11 = "1.1".equals(str4);
        if (isRootDocument() && this.fDocumentHandler != null) {
            this.fDocumentHandler.xmlDecl(str4, str5, str6, augmentations2);
        }
    }
}
