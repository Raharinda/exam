package org.apache.xerces.xinclude;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;

final class SecuritySupport {
    private SecuritySupport() {
    }

    static ClassLoader getContextClassLoader() {
        PrivilegedAction privilegedAction;
        new PrivilegedAction() {
            public Object run() {
                ClassLoader classLoader = null;
                try {
                    classLoader = Thread.currentThread().getContextClassLoader();
                } catch (SecurityException e) {
                    SecurityException securityException = e;
                }
                return classLoader;
            }
        };
        return (ClassLoader) AccessController.doPrivileged(privilegedAction);
    }

    static boolean getFileExists(File file) {
        PrivilegedAction privilegedAction;
        new PrivilegedAction(file) {
            private final File val$f;

            {
                this.val$f = r5;
            }

            public Object run() {
                return this.val$f.exists() ? Boolean.TRUE : Boolean.FALSE;
            }
        };
        return ((Boolean) AccessController.doPrivileged(privilegedAction)).booleanValue();
    }

    static FileInputStream getFileInputStream(File file) throws FileNotFoundException {
        PrivilegedExceptionAction privilegedExceptionAction;
        try {
            new PrivilegedExceptionAction(file) {
                private final File val$file;

                {
                    this.val$file = r5;
                }

                public Object run() throws FileNotFoundException {
                    Object obj;
                    new FileInputStream(this.val$file);
                    return obj;
                }
            };
            return (FileInputStream) AccessController.doPrivileged(privilegedExceptionAction);
        } catch (PrivilegedActionException e) {
            throw ((FileNotFoundException) e.getException());
        }
    }

    static long getLastModified(File file) {
        PrivilegedAction privilegedAction;
        new PrivilegedAction(file) {
            private final File val$f;

            {
                this.val$f = r5;
            }

            public Object run() {
                Object obj;
                new Long(this.val$f.lastModified());
                return obj;
            }
        };
        return ((Long) AccessController.doPrivileged(privilegedAction)).longValue();
    }

    static ClassLoader getParentClassLoader(ClassLoader classLoader) {
        PrivilegedAction privilegedAction;
        new PrivilegedAction(classLoader) {
            private final ClassLoader val$cl;

            {
                this.val$cl = r5;
            }

            public Object run() {
                ClassLoader classLoader = null;
                try {
                    classLoader = this.val$cl.getParent();
                } catch (SecurityException e) {
                    SecurityException securityException = e;
                }
                return classLoader == this.val$cl ? null : classLoader;
            }
        };
        return (ClassLoader) AccessController.doPrivileged(privilegedAction);
    }

    static InputStream getResourceAsStream(ClassLoader classLoader, String str) {
        PrivilegedAction privilegedAction;
        new PrivilegedAction(classLoader, str) {
            private final ClassLoader val$cl;
            private final String val$name;

            {
                this.val$cl = r6;
                this.val$name = r7;
            }

            public Object run() {
                return this.val$cl == null ? ClassLoader.getSystemResourceAsStream(this.val$name) : this.val$cl.getResourceAsStream(this.val$name);
            }
        };
        return (InputStream) AccessController.doPrivileged(privilegedAction);
    }

    static ClassLoader getSystemClassLoader() {
        PrivilegedAction privilegedAction;
        new PrivilegedAction() {
            public Object run() {
                ClassLoader classLoader = null;
                try {
                    classLoader = ClassLoader.getSystemClassLoader();
                } catch (SecurityException e) {
                    SecurityException securityException = e;
                }
                return classLoader;
            }
        };
        return (ClassLoader) AccessController.doPrivileged(privilegedAction);
    }

    static String getSystemProperty(String str) {
        PrivilegedAction privilegedAction;
        new PrivilegedAction(str) {
            private final String val$propName;

            {
                this.val$propName = r5;
            }

            public Object run() {
                return System.getProperty(this.val$propName);
            }
        };
        return (String) AccessController.doPrivileged(privilegedAction);
    }
}
