package org.apache.xerces.xinclude;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import org.apache.xerces.util.MessageFormatter;

public class XIncludeMessageFormatter implements MessageFormatter {
    public static final String XINCLUDE_DOMAIN = "http://www.w3.org/TR/xinclude";
    private Locale fLocale = null;
    private ResourceBundle fResourceBundle = null;

    public XIncludeMessageFormatter() {
    }

    public String formatMessage(Locale locale, String str, Object[] objArr) throws MissingResourceException {
        Throwable th;
        StringBuffer stringBuffer;
        Locale locale2 = locale;
        String str2 = str;
        Object[] objArr2 = objArr;
        if (locale2 == null) {
            locale2 = Locale.getDefault();
        }
        if (locale2 != this.fLocale) {
            this.fResourceBundle = ResourceBundle.getBundle("org.apache.xerces.impl.msg.XIncludeMessages", locale2);
            this.fLocale = locale2;
        }
        String string = this.fResourceBundle.getString(str2);
        if (objArr2 != null) {
            try {
                string = MessageFormat.format(string, objArr2);
            } catch (Exception e) {
                Exception exc = e;
                String string2 = this.fResourceBundle.getString("FormatFailed");
                new StringBuffer();
                string = stringBuffer.append(string2).append(" ").append(this.fResourceBundle.getString(str2)).toString();
            }
        }
        if (string != null) {
            return string;
        }
        Throwable th2 = th;
        new MissingResourceException(this.fResourceBundle.getString("BadMessageKey"), "org.apache.xerces.impl.msg.XIncludeMessages", str2);
        throw th2;
    }
}
