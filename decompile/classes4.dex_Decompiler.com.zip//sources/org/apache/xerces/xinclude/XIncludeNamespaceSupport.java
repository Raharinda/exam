package org.apache.xerces.xinclude;

import org.apache.xerces.xni.NamespaceContext;

public class XIncludeNamespaceSupport extends MultipleScopeNamespaceSupport {
    private boolean[] fValidContext = new boolean[8];

    public XIncludeNamespaceSupport() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public XIncludeNamespaceSupport(NamespaceContext namespaceContext) {
        super(namespaceContext);
    }

    public String getURIFromIncludeParent(String str) {
        String str2 = str;
        int i = this.fCurrentContext - 1;
        while (i > 0 && !this.fValidContext[i]) {
            i--;
        }
        return getURI(str2, i);
    }

    public void pushContext() {
        super.pushContext();
        if (this.fCurrentContext + 1 == this.fValidContext.length) {
            boolean[] zArr = new boolean[(this.fValidContext.length * 2)];
            System.arraycopy(this.fValidContext, 0, zArr, 0, this.fValidContext.length);
            this.fValidContext = zArr;
        }
        this.fValidContext[this.fCurrentContext] = true;
    }

    public void setContextInvalid() {
        this.fValidContext[this.fCurrentContext] = false;
    }
}
