package org.apache.xerces.xinclude;

import java.util.Enumeration;
import org.apache.xerces.util.NamespaceSupport;
import org.apache.xerces.util.XMLSymbols;
import org.apache.xerces.xni.NamespaceContext;

public class MultipleScopeNamespaceSupport extends NamespaceSupport {
    protected int fCurrentScope = 0;
    protected int[] fScope = new int[8];

    public MultipleScopeNamespaceSupport() {
        this.fScope[0] = 0;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public MultipleScopeNamespaceSupport(NamespaceContext namespaceContext) {
        super(namespaceContext);
        this.fScope[0] = 0;
    }

    public Enumeration getAllPrefixes() {
        Enumeration enumeration;
        int i = 0;
        if (this.fPrefixes.length < this.fNamespace.length / 2) {
            this.fPrefixes = new String[this.fNamespaceSize];
        }
        boolean z = true;
        for (int i2 = this.fContext[this.fScope[this.fCurrentScope]]; i2 <= this.fNamespaceSize - 2; i2 += 2) {
            String str = this.fNamespace[i2];
            int i3 = 0;
            while (true) {
                if (i3 >= i) {
                    break;
                } else if (this.fPrefixes[i3] == str) {
                    z = false;
                    break;
                } else {
                    i3++;
                }
            }
            if (z) {
                int i4 = i;
                i++;
                this.fPrefixes[i4] = str;
            }
            z = true;
        }
        new NamespaceSupport.Prefixes(this, this.fPrefixes, i);
        return enumeration;
    }

    public String getPrefix(String str) {
        return getPrefix(str, this.fNamespaceSize, this.fContext[this.fScope[this.fCurrentScope]]);
    }

    public String getPrefix(String str, int i) {
        int i2 = i;
        return getPrefix(str, this.fContext[i2 + 1], this.fContext[this.fScope[getScopeForContext(i2)]]);
    }

    public String getPrefix(String str, int i, int i2) {
        String str2 = str;
        int i3 = i;
        int i4 = i2;
        if (str2 == NamespaceContext.XML_URI) {
            return XMLSymbols.PREFIX_XML;
        }
        if (str2 == NamespaceContext.XMLNS_URI) {
            return XMLSymbols.PREFIX_XMLNS;
        }
        for (int i5 = i3; i5 > i4; i5 -= 2) {
            if (this.fNamespace[i5 - 1] == str2 && getURI(this.fNamespace[i5 - 2]) == str2) {
                return this.fNamespace[i5 - 2];
            }
        }
        return null;
    }

    public int getScopeForContext(int i) {
        int i2 = i;
        int i3 = this.fCurrentScope;
        while (i2 < this.fScope[i3]) {
            i3--;
        }
        return i3;
    }

    public String getURI(String str) {
        return getURI(str, this.fNamespaceSize, this.fContext[this.fScope[this.fCurrentScope]]);
    }

    public String getURI(String str, int i) {
        int i2 = i;
        return getURI(str, this.fContext[i2 + 1], this.fContext[this.fScope[getScopeForContext(i2)]]);
    }

    public String getURI(String str, int i, int i2) {
        String str2 = str;
        int i3 = i;
        int i4 = i2;
        if (str2 == XMLSymbols.PREFIX_XML) {
            return NamespaceContext.XML_URI;
        }
        if (str2 == XMLSymbols.PREFIX_XMLNS) {
            return NamespaceContext.XMLNS_URI;
        }
        for (int i5 = i3; i5 > i4; i5 -= 2) {
            if (this.fNamespace[i5 - 2] == str2) {
                return this.fNamespace[i5 - 1];
            }
        }
        return null;
    }

    public void popScope() {
        int[] iArr = this.fScope;
        int i = this.fCurrentScope;
        int i2 = i - 1;
        this.fCurrentScope = i2;
        this.fCurrentContext = iArr[i];
        popContext();
    }

    public void pushScope() {
        if (this.fCurrentScope + 1 == this.fScope.length) {
            int[] iArr = new int[(this.fScope.length * 2)];
            System.arraycopy(this.fScope, 0, iArr, 0, this.fScope.length);
            this.fScope = iArr;
        }
        pushContext();
        int[] iArr2 = this.fScope;
        int i = this.fCurrentScope + 1;
        int i2 = i;
        this.fCurrentScope = i2;
        iArr2[i] = this.fCurrentContext;
    }

    public void reset() {
        this.fCurrentContext = this.fScope[this.fCurrentScope];
        this.fNamespaceSize = this.fContext[this.fCurrentContext];
    }
}
