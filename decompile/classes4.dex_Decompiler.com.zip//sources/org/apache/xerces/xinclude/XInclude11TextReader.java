package org.apache.xerces.xinclude;

import java.io.IOException;
import org.apache.xerces.util.XML11Char;
import org.apache.xerces.xni.parser.XMLInputSource;

public class XInclude11TextReader extends XIncludeTextReader {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public XInclude11TextReader(XMLInputSource xMLInputSource, XIncludeHandler xIncludeHandler, int i) throws IOException {
        super(xMLInputSource, xIncludeHandler, i);
    }

    /* access modifiers changed from: protected */
    public boolean isValid(int i) {
        return XML11Char.isXML11Valid(i);
    }
}
