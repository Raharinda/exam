package org.apache.xerces.stax.events;

import java.io.IOException;
import java.io.Writer;
import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.NotationDeclaration;

public final class NotationDeclarationImpl extends XMLEventImpl implements NotationDeclaration {
    private final String fName;
    private final String fPublicId;
    private final String fSystemId;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NotationDeclarationImpl(String str, String str2, String str3, Location location) {
        super(14, location);
        this.fName = str;
        this.fPublicId = str2;
        this.fSystemId = str3;
    }

    public String getName() {
        return this.fName;
    }

    public String getPublicId() {
        return this.fPublicId;
    }

    public String getSystemId() {
        return this.fSystemId;
    }

    public void writeAsEncodedUnicode(Writer writer) throws XMLStreamException {
        Throwable th;
        Writer writer2 = writer;
        try {
            writer2.write("<!NOTATION ");
            if (this.fPublicId != null) {
                writer2.write("PUBLIC \"");
                writer2.write(this.fPublicId);
                writer2.write(34);
                if (this.fSystemId != null) {
                    writer2.write(" \"");
                    writer2.write(this.fSystemId);
                    writer2.write(34);
                }
            } else {
                writer2.write("SYSTEM \"");
                writer2.write(this.fSystemId);
                writer2.write(34);
            }
            writer2.write(this.fName);
            writer2.write(62);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new XMLStreamException(iOException);
            throw th2;
        }
    }
}
