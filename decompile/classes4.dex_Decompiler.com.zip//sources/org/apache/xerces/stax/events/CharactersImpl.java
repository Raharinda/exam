package org.apache.xerces.stax.events;

import java.io.IOException;
import java.io.Writer;
import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Characters;
import org.apache.xerces.util.XMLChar;

public final class CharactersImpl extends XMLEventImpl implements Characters {
    private final String fData;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CharactersImpl(String str, int i, Location location) {
        super(i, location);
        String str2 = str;
        this.fData = str2 != null ? str2 : "";
    }

    public String getData() {
        return this.fData;
    }

    public boolean isCData() {
        return 12 == getEventType();
    }

    public boolean isIgnorableWhiteSpace() {
        return 6 == getEventType();
    }

    public boolean isWhiteSpace() {
        int length = this.fData != null ? this.fData.length() : 0;
        if (length == 0) {
            return false;
        }
        for (int i = 0; i < length; i++) {
            if (!XMLChar.isSpace(this.fData.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public void writeAsEncodedUnicode(Writer writer) throws XMLStreamException {
        Throwable th;
        try {
            writer.write(this.fData);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new XMLStreamException(iOException);
            throw th2;
        }
    }
}
