package org.apache.xerces.stax.events;

import java.io.IOException;
import java.io.Writer;
import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EntityDeclaration;

public final class EntityDeclarationImpl extends XMLEventImpl implements EntityDeclaration {
    private final String fName;
    private final String fNotationName;
    private final String fPublicId;
    private final String fSystemId;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public EntityDeclarationImpl(String str, String str2, String str3, String str4, Location location) {
        super(15, location);
        this.fPublicId = str;
        this.fSystemId = str2;
        this.fName = str3;
        this.fNotationName = str4;
    }

    public String getBaseURI() {
        return null;
    }

    public String getName() {
        return this.fName;
    }

    public String getNotationName() {
        return this.fNotationName;
    }

    public String getPublicId() {
        return this.fPublicId;
    }

    public String getReplacementText() {
        return null;
    }

    public String getSystemId() {
        return this.fSystemId;
    }

    public void writeAsEncodedUnicode(Writer writer) throws XMLStreamException {
        Throwable th;
        Writer writer2 = writer;
        try {
            writer2.write("<!ENTITY ");
            writer2.write(this.fName);
            if (this.fPublicId != null) {
                writer2.write(" PUBLIC \"");
                writer2.write(this.fPublicId);
                writer2.write("\" \"");
                writer2.write(this.fSystemId);
                writer2.write(34);
            } else {
                writer2.write(" SYSTEM \"");
                writer2.write(this.fSystemId);
                writer2.write(34);
            }
            if (this.fNotationName != null) {
                writer2.write(" NDATA ");
                writer2.write(this.fNotationName);
            }
            writer2.write(62);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new XMLStreamException(iOException);
            throw th2;
        }
    }
}
