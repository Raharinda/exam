package org.apache.xerces.stax.events;

import java.io.IOException;
import java.io.Writer;
import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Comment;

public final class CommentImpl extends XMLEventImpl implements Comment {
    private final String fText;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CommentImpl(String str, Location location) {
        super(5, location);
        String str2 = str;
        this.fText = str2 != null ? str2 : "";
    }

    public String getText() {
        return this.fText;
    }

    public void writeAsEncodedUnicode(Writer writer) throws XMLStreamException {
        Throwable th;
        Writer writer2 = writer;
        try {
            writer2.write("<!--");
            writer2.write(this.fText);
            writer2.write("-->");
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new XMLStreamException(iOException);
            throw th2;
        }
    }
}
