package org.apache.xerces.stax.events;

import java.io.IOException;
import java.io.Writer;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.Namespace;
import javax.xml.stream.events.StartElement;
import org.apache.xerces.stax.DefaultNamespaceContext;

public final class StartElementImpl extends ElementImpl implements StartElement {
    private static final Comparator QNAME_COMPARATOR;
    private final Map fAttributes;
    private final NamespaceContext fNamespaceContext;

    static {
        Comparator comparator;
        new Comparator() {
            public int compare(Object obj, Object obj2) {
                Object obj3 = obj;
                Object obj4 = obj2;
                if (obj3.equals(obj4)) {
                    return 0;
                }
                return ((QName) obj3).toString().compareTo(((QName) obj4).toString());
            }
        };
        QNAME_COMPARATOR = comparator;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public StartElementImpl(QName qName, Iterator it, Iterator it2, NamespaceContext namespaceContext, Location location) {
        super(qName, true, it2, location);
        Map map;
        Iterator it3 = it;
        NamespaceContext namespaceContext2 = namespaceContext;
        if (it3 == null || !it3.hasNext()) {
            this.fAttributes = Collections.EMPTY_MAP;
        } else {
            new TreeMap(QNAME_COMPARATOR);
            this.fAttributes = map;
            do {
                Attribute attribute = (Attribute) it3.next();
                Object put = this.fAttributes.put(attribute.getName(), attribute);
            } while (it3.hasNext());
        }
        this.fNamespaceContext = namespaceContext2 != null ? namespaceContext2 : DefaultNamespaceContext.getInstance();
    }

    public Attribute getAttributeByName(QName qName) {
        return (Attribute) this.fAttributes.get(qName);
    }

    public Iterator getAttributes() {
        return ElementImpl.createImmutableIterator(this.fAttributes.values().iterator());
    }

    public NamespaceContext getNamespaceContext() {
        return this.fNamespaceContext;
    }

    public String getNamespaceURI(String str) {
        return this.fNamespaceContext.getNamespaceURI(str);
    }

    public void writeAsEncodedUnicode(Writer writer) throws XMLStreamException {
        Throwable th;
        Writer writer2 = writer;
        try {
            writer2.write(60);
            QName name = getName();
            String prefix = name.getPrefix();
            if (prefix != null && prefix.length() > 0) {
                writer2.write(prefix);
                writer2.write(58);
            }
            writer2.write(name.getLocalPart());
            Iterator namespaces = getNamespaces();
            while (namespaces.hasNext()) {
                Namespace namespace = (Namespace) namespaces.next();
                writer2.write(32);
                namespace.writeAsEncodedUnicode(writer2);
            }
            Iterator attributes = getAttributes();
            while (attributes.hasNext()) {
                Attribute attribute = (Attribute) attributes.next();
                writer2.write(32);
                attribute.writeAsEncodedUnicode(writer2);
            }
            writer2.write(62);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new XMLStreamException(iOException);
            throw th2;
        }
    }
}
