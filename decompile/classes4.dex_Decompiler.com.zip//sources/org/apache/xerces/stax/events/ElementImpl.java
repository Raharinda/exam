package org.apache.xerces.stax.events;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.xml.namespace.QName;
import javax.xml.stream.Location;
import javax.xml.stream.events.Namespace;

abstract class ElementImpl extends XMLEventImpl {
    private final QName fName;
    private final List fNamespaces;

    private static final class NoRemoveIterator implements Iterator {
        private final Iterator fWrapped;

        public NoRemoveIterator(Iterator it) {
            this.fWrapped = it;
        }

        public boolean hasNext() {
            return this.fWrapped.hasNext();
        }

        public Object next() {
            return this.fWrapped.next();
        }

        public void remove() {
            Throwable th;
            Throwable th2 = th;
            new UnsupportedOperationException("Attributes iterator is read-only.");
            throw th2;
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    ElementImpl(QName qName, boolean z, Iterator it, Location location) {
        super(z ? 1 : 2, location);
        List list;
        QName qName2 = qName;
        Iterator it2 = it;
        this.fName = qName2;
        if (it2 == null || !it2.hasNext()) {
            this.fNamespaces = Collections.EMPTY_LIST;
            return;
        }
        new ArrayList();
        this.fNamespaces = list;
        do {
            boolean add = this.fNamespaces.add((Namespace) it2.next());
        } while (it2.hasNext());
    }

    static Iterator createImmutableIterator(Iterator it) {
        Iterator it2;
        new NoRemoveIterator(it);
        return it2;
    }

    public final QName getName() {
        return this.fName;
    }

    public final Iterator getNamespaces() {
        return createImmutableIterator(this.fNamespaces.iterator());
    }
}
