package org.apache.xerces.stax;

import java.util.Iterator;
import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.stream.Location;
import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.Namespace;
import javax.xml.stream.events.StartDocument;
import javax.xml.stream.events.StartElement;
import org.apache.xerces.stax.events.StartDocumentImpl;

public final class XMLEventFactoryImpl extends XMLEventFactory {
    private Location fLocation;

    public XMLEventFactoryImpl() {
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private javax.xml.stream.events.StartElement createStartElement(javax.xml.namespace.QName r14, java.util.Iterator r15, java.util.Iterator r16, javax.xml.namespace.NamespaceContext r17) {
        /*
            r13 = this;
            r0 = r13
            r1 = r14
            r2 = r15
            r3 = r16
            r4 = r17
            org.apache.xerces.stax.events.StartElementImpl r5 = new org.apache.xerces.stax.events.StartElementImpl
            r12 = r5
            r5 = r12
            r6 = r12
            r7 = r1
            r8 = r2
            r9 = r3
            r10 = r4
            r11 = r0
            javax.xml.stream.Location r11 = r11.fLocation
            r6.<init>(r7, r8, r9, r10, r11)
            r0 = r5
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.XMLEventFactoryImpl.createStartElement(javax.xml.namespace.QName, java.util.Iterator, java.util.Iterator, javax.xml.namespace.NamespaceContext):javax.xml.stream.events.StartElement");
    }

    public Attribute createAttribute(String str, String str2) {
        QName qName;
        new QName(str);
        return createAttribute(qName, str2);
    }

    public Attribute createAttribute(String str, String str2, String str3, String str4) {
        QName qName;
        new QName(str2, str3, str);
        return createAttribute(qName, str4);
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public javax.xml.stream.events.Attribute createAttribute(javax.xml.namespace.QName r12, java.lang.String r13) {
        /*
            r11 = this;
            r0 = r11
            r1 = r12
            r2 = r13
            org.apache.xerces.stax.events.AttributeImpl r3 = new org.apache.xerces.stax.events.AttributeImpl
            r10 = r3
            r3 = r10
            r4 = r10
            r5 = r1
            r6 = r2
            java.lang.String r7 = "CDATA"
            r8 = 1
            r9 = r0
            javax.xml.stream.Location r9 = r9.fLocation
            r4.<init>(r5, r6, r7, r8, r9)
            r0 = r3
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.XMLEventFactoryImpl.createAttribute(javax.xml.namespace.QName, java.lang.String):javax.xml.stream.events.Attribute");
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public javax.xml.stream.events.Characters createCData(java.lang.String r9) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            org.apache.xerces.stax.events.CharactersImpl r2 = new org.apache.xerces.stax.events.CharactersImpl
            r7 = r2
            r2 = r7
            r3 = r7
            r4 = r1
            r5 = 12
            r6 = r0
            javax.xml.stream.Location r6 = r6.fLocation
            r3.<init>(r4, r5, r6)
            r0 = r2
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.XMLEventFactoryImpl.createCData(java.lang.String):javax.xml.stream.events.Characters");
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public javax.xml.stream.events.Characters createCharacters(java.lang.String r9) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            org.apache.xerces.stax.events.CharactersImpl r2 = new org.apache.xerces.stax.events.CharactersImpl
            r7 = r2
            r2 = r7
            r3 = r7
            r4 = r1
            r5 = 4
            r6 = r0
            javax.xml.stream.Location r6 = r6.fLocation
            r3.<init>(r4, r5, r6)
            r0 = r2
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.XMLEventFactoryImpl.createCharacters(java.lang.String):javax.xml.stream.events.Characters");
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public javax.xml.stream.events.Comment createComment(java.lang.String r8) {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            org.apache.xerces.stax.events.CommentImpl r2 = new org.apache.xerces.stax.events.CommentImpl
            r6 = r2
            r2 = r6
            r3 = r6
            r4 = r1
            r5 = r0
            javax.xml.stream.Location r5 = r5.fLocation
            r3.<init>(r4, r5)
            r0 = r2
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.XMLEventFactoryImpl.createComment(java.lang.String):javax.xml.stream.events.Comment");
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public javax.xml.stream.events.DTD createDTD(java.lang.String r8) {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            org.apache.xerces.stax.events.DTDImpl r2 = new org.apache.xerces.stax.events.DTDImpl
            r6 = r2
            r2 = r6
            r3 = r6
            r4 = r1
            r5 = r0
            javax.xml.stream.Location r5 = r5.fLocation
            r3.<init>(r4, r5)
            r0 = r2
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.XMLEventFactoryImpl.createDTD(java.lang.String):javax.xml.stream.events.DTD");
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public javax.xml.stream.events.EndDocument createEndDocument() {
        /*
            r5 = this;
            r0 = r5
            org.apache.xerces.stax.events.EndDocumentImpl r1 = new org.apache.xerces.stax.events.EndDocumentImpl
            r4 = r1
            r1 = r4
            r2 = r4
            r3 = r0
            javax.xml.stream.Location r3 = r3.fLocation
            r2.<init>(r3)
            r0 = r1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.XMLEventFactoryImpl.createEndDocument():javax.xml.stream.events.EndDocument");
    }

    public EndElement createEndElement(String str, String str2, String str3) {
        QName qName;
        new QName(str2, str3, str);
        return createEndElement(qName, (Iterator) null);
    }

    public EndElement createEndElement(String str, String str2, String str3, Iterator it) {
        QName qName;
        new QName(str2, str3, str);
        return createEndElement(qName, it);
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public javax.xml.stream.events.EndElement createEndElement(javax.xml.namespace.QName r10, java.util.Iterator r11) {
        /*
            r9 = this;
            r0 = r9
            r1 = r10
            r2 = r11
            org.apache.xerces.stax.events.EndElementImpl r3 = new org.apache.xerces.stax.events.EndElementImpl
            r8 = r3
            r3 = r8
            r4 = r8
            r5 = r1
            r6 = r2
            r7 = r0
            javax.xml.stream.Location r7 = r7.fLocation
            r4.<init>(r5, r6, r7)
            r0 = r3
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.XMLEventFactoryImpl.createEndElement(javax.xml.namespace.QName, java.util.Iterator):javax.xml.stream.events.EndElement");
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public javax.xml.stream.events.EntityReference createEntityReference(java.lang.String r10, javax.xml.stream.events.EntityDeclaration r11) {
        /*
            r9 = this;
            r0 = r9
            r1 = r10
            r2 = r11
            org.apache.xerces.stax.events.EntityReferenceImpl r3 = new org.apache.xerces.stax.events.EntityReferenceImpl
            r8 = r3
            r3 = r8
            r4 = r8
            r5 = r1
            r6 = r2
            r7 = r0
            javax.xml.stream.Location r7 = r7.fLocation
            r4.<init>(r5, r6, r7)
            r0 = r3
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.XMLEventFactoryImpl.createEntityReference(java.lang.String, javax.xml.stream.events.EntityDeclaration):javax.xml.stream.events.EntityReference");
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public javax.xml.stream.events.Characters createIgnorableSpace(java.lang.String r9) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            org.apache.xerces.stax.events.CharactersImpl r2 = new org.apache.xerces.stax.events.CharactersImpl
            r7 = r2
            r2 = r7
            r3 = r7
            r4 = r1
            r5 = 6
            r6 = r0
            javax.xml.stream.Location r6 = r6.fLocation
            r3.<init>(r4, r5, r6)
            r0 = r2
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.XMLEventFactoryImpl.createIgnorableSpace(java.lang.String):javax.xml.stream.events.Characters");
    }

    public Namespace createNamespace(String str) {
        return createNamespace("", str);
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public javax.xml.stream.events.Namespace createNamespace(java.lang.String r10, java.lang.String r11) {
        /*
            r9 = this;
            r0 = r9
            r1 = r10
            r2 = r11
            org.apache.xerces.stax.events.NamespaceImpl r3 = new org.apache.xerces.stax.events.NamespaceImpl
            r8 = r3
            r3 = r8
            r4 = r8
            r5 = r1
            r6 = r2
            r7 = r0
            javax.xml.stream.Location r7 = r7.fLocation
            r4.<init>(r5, r6, r7)
            r0 = r3
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.XMLEventFactoryImpl.createNamespace(java.lang.String, java.lang.String):javax.xml.stream.events.Namespace");
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public javax.xml.stream.events.ProcessingInstruction createProcessingInstruction(java.lang.String r10, java.lang.String r11) {
        /*
            r9 = this;
            r0 = r9
            r1 = r10
            r2 = r11
            org.apache.xerces.stax.events.ProcessingInstructionImpl r3 = new org.apache.xerces.stax.events.ProcessingInstructionImpl
            r8 = r3
            r3 = r8
            r4 = r8
            r5 = r1
            r6 = r2
            r7 = r0
            javax.xml.stream.Location r7 = r7.fLocation
            r4.<init>(r5, r6, r7)
            r0 = r3
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.XMLEventFactoryImpl.createProcessingInstruction(java.lang.String, java.lang.String):javax.xml.stream.events.ProcessingInstruction");
    }

    public Characters createSpace(String str) {
        return createCharacters(str);
    }

    public StartDocument createStartDocument() {
        return createStartDocument((String) null, (String) null);
    }

    public StartDocument createStartDocument(String str) {
        return createStartDocument(str, (String) null);
    }

    public StartDocument createStartDocument(String str, String str2) {
        String str3 = str;
        StartDocument startDocument = r11;
        StartDocument startDocumentImpl = new StartDocumentImpl(str3, str3 != null, false, false, str2, this.fLocation);
        return startDocument;
    }

    public StartDocument createStartDocument(String str, String str2, boolean z) {
        String str3 = str;
        StartDocument startDocument = r12;
        StartDocument startDocumentImpl = new StartDocumentImpl(str3, str3 != null, z, true, str2, this.fLocation);
        return startDocument;
    }

    public StartElement createStartElement(String str, String str2, String str3) {
        QName qName;
        new QName(str2, str3, str);
        return createStartElement(qName, (Iterator) null, (Iterator) null);
    }

    public StartElement createStartElement(String str, String str2, String str3, Iterator it, Iterator it2) {
        QName qName;
        new QName(str2, str3, str);
        return createStartElement(qName, it, it2);
    }

    public StartElement createStartElement(String str, String str2, String str3, Iterator it, Iterator it2, NamespaceContext namespaceContext) {
        QName qName;
        new QName(str2, str3, str);
        return createStartElement(qName, it, it2, namespaceContext);
    }

    public StartElement createStartElement(QName qName, Iterator it, Iterator it2) {
        return createStartElement(qName, it, it2, (NamespaceContext) null);
    }

    public void setLocation(Location location) {
        Location location2 = location;
        this.fLocation = location2;
    }
}
