package org.apache.xerces.stax;

import javax.xml.stream.Location;

public class ImmutableLocation implements Location {
    private final int fCharacterOffset;
    private final int fColumnNumber;
    private final int fLineNumber;
    private final String fPublicId;
    private final String fSystemId;

    public ImmutableLocation(int i, int i2, int i3, String str, String str2) {
        this.fCharacterOffset = i;
        this.fColumnNumber = i2;
        this.fLineNumber = i3;
        this.fPublicId = str;
        this.fSystemId = str2;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ImmutableLocation(javax.xml.stream.Location r9) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            r2 = r0
            r3 = r1
            int r3 = r3.getCharacterOffset()
            r4 = r1
            int r4 = r4.getColumnNumber()
            r5 = r1
            int r5 = r5.getLineNumber()
            r6 = r1
            java.lang.String r6 = r6.getPublicId()
            r7 = r1
            java.lang.String r7 = r7.getSystemId()
            r2.<init>(r3, r4, r5, r6, r7)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.ImmutableLocation.<init>(javax.xml.stream.Location):void");
    }

    public int getCharacterOffset() {
        return this.fCharacterOffset;
    }

    public int getColumnNumber() {
        return this.fColumnNumber;
    }

    public int getLineNumber() {
        return this.fLineNumber;
    }

    public String getPublicId() {
        return this.fPublicId;
    }

    public String getSystemId() {
        return this.fSystemId;
    }
}
