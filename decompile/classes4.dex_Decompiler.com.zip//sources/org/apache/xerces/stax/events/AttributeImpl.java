package org.apache.xerces.stax.events;

import java.io.IOException;
import java.io.Writer;
import javax.xml.namespace.QName;
import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;

public class AttributeImpl extends XMLEventImpl implements Attribute {
    private final String fDtdType;
    private final boolean fIsSpecified;
    private final QName fName;
    private final String fValue;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected AttributeImpl(int i, QName qName, String str, String str2, boolean z, Location location) {
        super(i, location);
        this.fName = qName;
        this.fValue = str;
        this.fDtdType = str2;
        this.fIsSpecified = z;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public AttributeImpl(QName qName, String str, String str2, boolean z, Location location) {
        this(10, qName, str, str2, z, location);
    }

    public final String getDTDType() {
        return this.fDtdType;
    }

    public final QName getName() {
        return this.fName;
    }

    public final String getValue() {
        return this.fValue;
    }

    public final boolean isSpecified() {
        return this.fIsSpecified;
    }

    public final void writeAsEncodedUnicode(Writer writer) throws XMLStreamException {
        Throwable th;
        Writer writer2 = writer;
        try {
            String prefix = this.fName.getPrefix();
            if (prefix != null && prefix.length() > 0) {
                writer2.write(prefix);
                writer2.write(58);
            }
            writer2.write(this.fName.getLocalPart());
            writer2.write("=\"");
            writer2.write(this.fValue);
            writer2.write(34);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new XMLStreamException(iOException);
            throw th2;
        }
    }
}
