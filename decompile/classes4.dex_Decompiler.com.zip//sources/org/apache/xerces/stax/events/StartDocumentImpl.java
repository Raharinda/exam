package org.apache.xerces.stax.events;

import com.kodular.fabextension.BuildConfig;
import java.io.IOException;
import java.io.Writer;
import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.StartDocument;

public final class StartDocumentImpl extends XMLEventImpl implements StartDocument {
    private final String fCharEncoding;
    private final boolean fEncodingSet;
    private final boolean fIsStandalone;
    private final boolean fStandaloneSet;
    private final String fVersion;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public StartDocumentImpl(String str, boolean z, boolean z2, boolean z3, String str2, Location location) {
        super(7, location);
        this.fCharEncoding = str;
        this.fEncodingSet = z;
        this.fIsStandalone = z2;
        this.fStandaloneSet = z3;
        this.fVersion = str2;
    }

    public boolean encodingSet() {
        return this.fEncodingSet;
    }

    public String getCharacterEncodingScheme() {
        return this.fCharEncoding;
    }

    public String getSystemId() {
        return getLocation().getSystemId();
    }

    public String getVersion() {
        return this.fVersion;
    }

    public boolean isStandalone() {
        return this.fIsStandalone;
    }

    public boolean standaloneSet() {
        return this.fStandaloneSet;
    }

    public void writeAsEncodedUnicode(Writer writer) throws XMLStreamException {
        Throwable th;
        Writer writer2 = writer;
        try {
            writer2.write("<?xml version=\"");
            writer2.write((this.fVersion == null || this.fVersion.length() <= 0) ? BuildConfig.VERSION_NAME : this.fVersion);
            writer2.write(34);
            if (encodingSet()) {
                writer2.write(" encoding=\"");
                writer2.write(this.fCharEncoding);
                writer2.write(34);
            }
            if (standaloneSet()) {
                writer2.write(" standalone=\"");
                writer2.write(this.fIsStandalone ? "yes" : "no");
                writer2.write(34);
            }
            writer2.write("?>");
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new XMLStreamException(iOException);
            throw th2;
        }
    }
}
