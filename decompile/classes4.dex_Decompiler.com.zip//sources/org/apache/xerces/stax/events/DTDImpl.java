package org.apache.xerces.stax.events;

import java.io.IOException;
import java.io.Writer;
import java.util.Collections;
import java.util.List;
import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.DTD;

public final class DTDImpl extends XMLEventImpl implements DTD {
    private final String fDTD;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DTDImpl(String str, Location location) {
        super(11, location);
        String str2 = str;
        this.fDTD = str2 != null ? str2 : null;
    }

    public String getDocumentTypeDeclaration() {
        return this.fDTD;
    }

    public List getEntities() {
        return Collections.EMPTY_LIST;
    }

    public List getNotations() {
        return Collections.EMPTY_LIST;
    }

    public Object getProcessedDTD() {
        return null;
    }

    public void writeAsEncodedUnicode(Writer writer) throws XMLStreamException {
        Throwable th;
        try {
            writer.write(this.fDTD);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new XMLStreamException(iOException);
            throw th2;
        }
    }
}
