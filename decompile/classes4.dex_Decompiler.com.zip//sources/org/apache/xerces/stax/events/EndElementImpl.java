package org.apache.xerces.stax.events;

import java.io.IOException;
import java.io.Writer;
import java.util.Iterator;
import javax.xml.namespace.QName;
import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;

public final class EndElementImpl extends ElementImpl implements EndElement {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public EndElementImpl(QName qName, Iterator it, Location location) {
        super(qName, false, it, location);
    }

    public void writeAsEncodedUnicode(Writer writer) throws XMLStreamException {
        Throwable th;
        Writer writer2 = writer;
        try {
            writer2.write("</");
            QName name = getName();
            String prefix = name.getPrefix();
            if (prefix != null && prefix.length() > 0) {
                writer2.write(prefix);
                writer2.write(58);
            }
            writer2.write(name.getLocalPart());
            writer2.write(62);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new XMLStreamException(iOException);
            throw th2;
        }
    }
}
