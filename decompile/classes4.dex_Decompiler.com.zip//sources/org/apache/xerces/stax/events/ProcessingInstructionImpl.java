package org.apache.xerces.stax.events;

import java.io.IOException;
import java.io.Writer;
import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.ProcessingInstruction;

public final class ProcessingInstructionImpl extends XMLEventImpl implements ProcessingInstruction {
    private final String fData;
    private final String fTarget;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ProcessingInstructionImpl(String str, String str2, Location location) {
        super(3, location);
        String str3 = str;
        String str4 = str2;
        this.fTarget = str3 != null ? str3 : "";
        this.fData = str4;
    }

    public String getData() {
        return this.fData;
    }

    public String getTarget() {
        return this.fTarget;
    }

    public void writeAsEncodedUnicode(Writer writer) throws XMLStreamException {
        Throwable th;
        Writer writer2 = writer;
        try {
            writer2.write("<?");
            writer2.write(this.fTarget);
            if (this.fData != null && this.fData.length() > 0) {
                writer2.write(32);
                writer2.write(this.fData);
            }
            writer2.write("?>");
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new XMLStreamException(iOException);
            throw th2;
        }
    }
}
