package org.apache.xerces.stax.events;

import java.io.Writer;
import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndDocument;

public final class EndDocumentImpl extends XMLEventImpl implements EndDocument {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public EndDocumentImpl(Location location) {
        super(8, location);
    }

    public void writeAsEncodedUnicode(Writer writer) throws XMLStreamException {
    }
}
