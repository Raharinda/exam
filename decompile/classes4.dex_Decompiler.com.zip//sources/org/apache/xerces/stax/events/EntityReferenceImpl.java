package org.apache.xerces.stax.events;

import java.io.IOException;
import java.io.Writer;
import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EntityDeclaration;
import javax.xml.stream.events.EntityReference;

public final class EntityReferenceImpl extends XMLEventImpl implements EntityReference {
    private final EntityDeclaration fDecl;
    private final String fName;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public EntityReferenceImpl(String str, EntityDeclaration entityDeclaration, Location location) {
        super(9, location);
        String str2 = str;
        EntityDeclaration entityDeclaration2 = entityDeclaration;
        this.fName = str2 != null ? str2 : "";
        this.fDecl = entityDeclaration2;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public EntityReferenceImpl(javax.xml.stream.events.EntityDeclaration r8, javax.xml.stream.Location r9) {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r2 = r9
            r3 = r0
            r4 = r1
            if (r4 == 0) goto L_0x0012
            r4 = r1
            java.lang.String r4 = r4.getName()
        L_0x000c:
            r5 = r1
            r6 = r2
            r3.<init>(r4, r5, r6)
            return
        L_0x0012:
            java.lang.String r4 = ""
            goto L_0x000c
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.events.EntityReferenceImpl.<init>(javax.xml.stream.events.EntityDeclaration, javax.xml.stream.Location):void");
    }

    public EntityDeclaration getDeclaration() {
        return this.fDecl;
    }

    public String getName() {
        return this.fName;
    }

    public void writeAsEncodedUnicode(Writer writer) throws XMLStreamException {
        Throwable th;
        Writer writer2 = writer;
        try {
            writer2.write(38);
            writer2.write(this.fName);
            writer2.write(59);
        } catch (IOException e) {
            IOException iOException = e;
            Throwable th2 = th;
            new XMLStreamException(iOException);
            throw th2;
        }
    }
}
