package org.apache.xerces.stax;

import java.util.Collections;
import java.util.Iterator;
import java.util.NoSuchElementException;
import javax.xml.namespace.NamespaceContext;
import org.apache.xml.serialize.Method;

public final class DefaultNamespaceContext implements NamespaceContext {
    private static final DefaultNamespaceContext DEFAULT_NAMESPACE_CONTEXT_INSTANCE;

    static {
        DefaultNamespaceContext defaultNamespaceContext;
        new DefaultNamespaceContext();
        DEFAULT_NAMESPACE_CONTEXT_INSTANCE = defaultNamespaceContext;
    }

    private DefaultNamespaceContext() {
    }

    public static DefaultNamespaceContext getInstance() {
        return DEFAULT_NAMESPACE_CONTEXT_INSTANCE;
    }

    public String getNamespaceURI(String str) {
        Throwable th;
        String str2 = str;
        if (str2 != null) {
            return Method.XML.equals(str2) ? "http://www.w3.org/XML/1998/namespace" : "xmlns".equals(str2) ? "http://www.w3.org/2000/xmlns/" : "";
        }
        Throwable th2 = th;
        new IllegalArgumentException("Prefix cannot be null.");
        throw th2;
    }

    public String getPrefix(String str) {
        Throwable th;
        String str2 = str;
        if (str2 == null) {
            Throwable th2 = th;
            new IllegalArgumentException("Namespace URI cannot be null.");
            throw th2;
        } else if ("http://www.w3.org/XML/1998/namespace".equals(str2)) {
            return Method.XML;
        } else {
            if ("http://www.w3.org/2000/xmlns/".equals(str2)) {
                return "xmlns";
            }
            return null;
        }
    }

    public Iterator getPrefixes(String str) {
        Iterator it;
        Iterator it2;
        Throwable th;
        String str2 = str;
        if (str2 == null) {
            Throwable th2 = th;
            new IllegalArgumentException("Namespace URI cannot be null.");
            throw th2;
        } else if ("http://www.w3.org/XML/1998/namespace".equals(str2)) {
            new Iterator(this) {
                boolean more = true;
                private final DefaultNamespaceContext this$0;

                {
                    this.this$0 = r5;
                }

                public boolean hasNext() {
                    return this.more;
                }

                public Object next() {
                    Throwable th;
                    if (!hasNext()) {
                        Throwable th2 = th;
                        new NoSuchElementException();
                        throw th2;
                    }
                    this.more = false;
                    return Method.XML;
                }

                public void remove() {
                    Throwable th;
                    Throwable th2 = th;
                    new UnsupportedOperationException();
                    throw th2;
                }
            };
            return it2;
        } else if (!"http://www.w3.org/2000/xmlns/".equals(str2)) {
            return Collections.EMPTY_LIST.iterator();
        } else {
            new Iterator(this) {
                boolean more = true;
                private final DefaultNamespaceContext this$0;

                {
                    this.this$0 = r5;
                }

                public boolean hasNext() {
                    return this.more;
                }

                public Object next() {
                    Throwable th;
                    if (!hasNext()) {
                        Throwable th2 = th;
                        new NoSuchElementException();
                        throw th2;
                    }
                    this.more = false;
                    return "xmlns";
                }

                public void remove() {
                    Throwable th;
                    Throwable th2 = th;
                    new UnsupportedOperationException();
                    throw th2;
                }
            };
            return it;
        }
    }
}
