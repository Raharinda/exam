package org.apache.xerces.stax.events;

import javax.xml.namespace.QName;
import javax.xml.stream.events.Namespace;

public final class NamespaceImpl extends AttributeImpl implements Namespace {
    private final String fNamespaceURI;
    private final String fPrefix;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public NamespaceImpl(java.lang.String r12, java.lang.String r13, javax.xml.stream.Location r14) {
        /*
            r11 = this;
            r0 = r11
            r1 = r12
            r2 = r13
            r3 = r14
            r4 = r0
            r5 = 13
            r6 = r1
            javax.xml.namespace.QName r6 = makeAttributeQName(r6)
            r7 = r2
            r8 = 0
            r9 = 1
            r10 = r3
            r4.<init>(r5, r6, r7, r8, r9, r10)
            r4 = r0
            r5 = r1
            if (r5 != 0) goto L_0x0021
            java.lang.String r5 = ""
        L_0x001a:
            r4.fPrefix = r5
            r4 = r0
            r5 = r2
            r4.fNamespaceURI = r5
            return
        L_0x0021:
            r5 = r1
            goto L_0x001a
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.stax.events.NamespaceImpl.<init>(java.lang.String, java.lang.String, javax.xml.stream.Location):void");
    }

    private static QName makeAttributeQName(String str) {
        QName qName;
        QName qName2;
        String str2 = str;
        if (str2 == null || str2.equals("")) {
            new QName("http://www.w3.org/2000/xmlns/", "xmlns", "");
            return qName;
        }
        new QName("http://www.w3.org/2000/xmlns/", str2, "xmlns");
        return qName2;
    }

    public String getNamespaceURI() {
        return this.fNamespaceURI;
    }

    public String getPrefix() {
        return this.fPrefix;
    }

    public boolean isDefaultNamespaceDeclaration() {
        return this.fPrefix.length() == 0;
    }
}
