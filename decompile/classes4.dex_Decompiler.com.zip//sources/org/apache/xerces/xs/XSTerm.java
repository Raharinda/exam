package org.apache.xerces.xs;

public interface XSTerm extends XSObject {
}
