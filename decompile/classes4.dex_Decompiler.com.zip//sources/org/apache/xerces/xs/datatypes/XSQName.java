package org.apache.xerces.xs.datatypes;

import javax.xml.namespace.QName;

public interface XSQName {
    QName getJAXPQName();

    org.apache.xerces.xni.QName getXNIQName();
}
