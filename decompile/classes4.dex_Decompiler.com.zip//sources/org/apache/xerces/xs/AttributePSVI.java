package org.apache.xerces.xs;

public interface AttributePSVI extends ItemPSVI {
    XSAttributeDeclaration getAttributeDeclaration();
}
