package org.apache.xerces.xs.datatypes;

public interface XSFloat {
    float getValue();
}
