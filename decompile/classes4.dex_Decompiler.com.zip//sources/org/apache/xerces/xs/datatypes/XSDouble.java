package org.apache.xerces.xs.datatypes;

public interface XSDouble {
    double getValue();
}
