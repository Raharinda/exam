package org.apache.xerces.dom;

import java.util.Vector;
import org.apache.xerces.dom3.as.ASAttributeDeclaration;
import org.apache.xerces.dom3.as.ASContentModel;
import org.apache.xerces.dom3.as.ASElementDeclaration;
import org.apache.xerces.dom3.as.ASEntityDeclaration;
import org.apache.xerces.dom3.as.ASModel;
import org.apache.xerces.dom3.as.ASNamedObjectMap;
import org.apache.xerces.dom3.as.ASNotationDeclaration;
import org.apache.xerces.dom3.as.ASObject;
import org.apache.xerces.dom3.as.ASObjectList;
import org.apache.xerces.dom3.as.DOMASException;
import org.apache.xerces.impl.xs.SchemaGrammar;
import org.w3c.dom.DOMException;

public class ASModelImpl implements ASModel {
    protected Vector fASModels;
    protected SchemaGrammar fGrammar = null;
    boolean fNamespaceAware = true;

    public ASModelImpl() {
        Vector vector;
        new Vector();
        this.fASModels = vector;
    }

    public ASModelImpl(boolean z) {
        Vector vector;
        new Vector();
        this.fASModels = vector;
        this.fNamespaceAware = z;
    }

    public void addASModel(ASModel aSModel) {
        this.fASModels.addElement(aSModel);
    }

    public ASObject cloneASObject(boolean z) {
        Throwable th;
        boolean z2 = z;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public ASAttributeDeclaration createASAttributeDeclaration(String str, String str2) throws DOMException {
        Throwable th;
        String str3 = str;
        String str4 = str2;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public ASContentModel createASContentModel(int i, int i2, short s) throws DOMASException {
        Throwable th;
        int i3 = i;
        int i4 = i2;
        short s2 = s;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public ASElementDeclaration createASElementDeclaration(String str, String str2) throws DOMException {
        Throwable th;
        String str3 = str;
        String str4 = str2;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public ASEntityDeclaration createASEntityDeclaration(String str) throws DOMException {
        Throwable th;
        String str2 = str;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public ASNotationDeclaration createASNotationDeclaration(String str, String str2, String str3, String str4) throws DOMException {
        Throwable th;
        String str5 = str;
        String str6 = str2;
        String str7 = str3;
        String str8 = str4;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public ASObjectList getASModels() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public String getAsHint() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public String getAsLocation() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public short getAsNodeType() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public ASNamedObjectMap getAttributeDeclarations() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public boolean getContainer() {
        return this.fGrammar != null;
    }

    public ASNamedObjectMap getContentModelDeclarations() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public ASNamedObjectMap getElementDeclarations() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public ASNamedObjectMap getEntityDeclarations() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public SchemaGrammar getGrammar() {
        return this.fGrammar;
    }

    public Vector getInternalASModels() {
        return this.fASModels;
    }

    public boolean getIsNamespaceAware() {
        return this.fNamespaceAware;
    }

    public String getLocalName() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public String getNamespaceURI() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public String getNodeName() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public ASNamedObjectMap getNotationDeclarations() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public ASModel getOwnerASModel() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public String getPrefix() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public short getUsageLocation() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public void importASObject(ASObject aSObject) {
        Throwable th;
        ASObject aSObject2 = aSObject;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public void insertASObject(ASObject aSObject) {
        Throwable th;
        ASObject aSObject2 = aSObject;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public void removeAS(ASModel aSModel) {
        boolean removeElement = this.fASModels.removeElement(aSModel);
    }

    public void setAsHint(String str) {
        Throwable th;
        String str2 = str;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public void setAsLocation(String str) {
        Throwable th;
        String str2 = str;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public void setGrammar(SchemaGrammar schemaGrammar) {
        SchemaGrammar schemaGrammar2 = schemaGrammar;
        this.fGrammar = schemaGrammar2;
    }

    public void setLocalName(String str) {
        Throwable th;
        String str2 = str;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public void setNamespaceURI(String str) {
        Throwable th;
        String str2 = str;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public void setNodeName(String str) {
        Throwable th;
        String str2 = str;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public void setOwnerASModel(ASModel aSModel) {
        Throwable th;
        ASModel aSModel2 = aSModel;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public void setPrefix(String str) {
        Throwable th;
        String str2 = str;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }

    public boolean validate() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }
}
