package org.apache.xerces.dom;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.w3c.dom.TypeInfo;

public class AttrImpl extends NodeImpl implements Attr, TypeInfo {
    static final String DTD_URI = "http://www.w3.org/TR/REC-xml";
    static final long serialVersionUID = 7277707688218972102L;
    protected String name;
    transient Object type;
    protected Object value = null;

    protected AttrImpl() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected AttrImpl(CoreDocumentImpl coreDocumentImpl, String str) {
        super(coreDocumentImpl);
        this.name = str;
        isSpecified(true);
        hasStringValue(true);
    }

    private void readObject(ObjectInputStream objectInputStream) throws ClassNotFoundException, IOException {
        objectInputStream.defaultReadObject();
        needsSyncChildren(false);
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        ObjectOutputStream objectOutputStream2 = objectOutputStream;
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        objectOutputStream2.defaultWriteObject();
    }

    /* access modifiers changed from: package-private */
    public void checkNormalizationAfterInsert(ChildNode childNode) {
        ChildNode childNode2 = childNode;
        if (childNode2.getNodeType() == 3) {
            ChildNode previousSibling = childNode2.previousSibling();
            ChildNode childNode3 = childNode2.nextSibling;
            if ((previousSibling != null && previousSibling.getNodeType() == 3) || (childNode3 != null && childNode3.getNodeType() == 3)) {
                isNormalized(false);
            }
        } else if (!childNode2.isNormalized()) {
            isNormalized(false);
        }
    }

    /* access modifiers changed from: package-private */
    public void checkNormalizationAfterRemove(ChildNode childNode) {
        ChildNode childNode2;
        ChildNode childNode3 = childNode;
        if (childNode3 != null && childNode3.getNodeType() == 3 && (childNode2 = childNode3.nextSibling) != null && childNode2.getNodeType() == 3) {
            isNormalized(false);
        }
    }

    public Node cloneNode(boolean z) {
        boolean z2 = z;
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        AttrImpl attrImpl = (AttrImpl) super.cloneNode(z2);
        if (!attrImpl.hasStringValue()) {
            attrImpl.value = null;
            Node node = (Node) this.value;
            while (true) {
                Node node2 = node;
                if (node2 == null) {
                    break;
                }
                Node appendChild = attrImpl.appendChild(node2.cloneNode(true));
                node = node2.getNextSibling();
            }
        }
        attrImpl.isSpecified(true);
        return attrImpl;
    }

    public NodeList getChildNodes() {
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        return this;
    }

    public Element getElement() {
        return (Element) (isOwned() ? this.ownerNode : null);
    }

    public Node getFirstChild() {
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        makeChildNode();
        return (Node) this.value;
    }

    public Node getLastChild() {
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        return lastChild();
    }

    public int getLength() {
        if (hasStringValue()) {
            return 1;
        }
        int i = 0;
        for (ChildNode childNode = (ChildNode) this.value; childNode != null; childNode = childNode.nextSibling) {
            i++;
        }
        return i;
    }

    public String getName() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.name;
    }

    public String getNodeName() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.name;
    }

    public short getNodeType() {
        return 2;
    }

    public String getNodeValue() {
        return getValue();
    }

    public Element getOwnerElement() {
        return (Element) (isOwned() ? this.ownerNode : null);
    }

    public TypeInfo getSchemaTypeInfo() {
        return this;
    }

    public boolean getSpecified() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return isSpecified();
    }

    public String getTypeName() {
        return (String) this.type;
    }

    public String getTypeNamespace() {
        if (this.type != null) {
            return "http://www.w3.org/TR/REC-xml";
        }
        return null;
    }

    public String getValue() {
        StringBuffer stringBuffer;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        if (this.value == null) {
            return "";
        }
        if (hasStringValue()) {
            return (String) this.value;
        }
        ChildNode childNode = (ChildNode) this.value;
        String entityRefValue = childNode.getNodeType() == 5 ? ((EntityReferenceImpl) childNode).getEntityRefValue() : childNode.getNodeValue();
        ChildNode childNode2 = childNode.nextSibling;
        if (childNode2 == null || entityRefValue == null) {
            return entityRefValue == null ? "" : entityRefValue;
        }
        new StringBuffer(entityRefValue);
        StringBuffer stringBuffer2 = stringBuffer;
        while (childNode2 != null) {
            if (childNode2.getNodeType() == 5) {
                String entityRefValue2 = ((EntityReferenceImpl) childNode2).getEntityRefValue();
                if (entityRefValue2 == null) {
                    return "";
                }
                StringBuffer append = stringBuffer2.append(entityRefValue2);
            } else {
                StringBuffer append2 = stringBuffer2.append(childNode2.getNodeValue());
            }
            childNode2 = childNode2.nextSibling;
        }
        return stringBuffer2.toString();
    }

    public boolean hasChildNodes() {
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        return this.value != null;
    }

    public Node insertBefore(Node node, Node node2) throws DOMException {
        return internalInsertBefore(node, node2, false);
    }

    /* access modifiers changed from: package-private */
    public Node internalInsertBefore(Node node, Node node2, boolean z) throws DOMException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        Throwable th6;
        Node node3 = node;
        Node node4 = node2;
        boolean z2 = z;
        CoreDocumentImpl ownerDocument = ownerDocument();
        boolean z3 = ownerDocument.errorChecking;
        if (node3.getNodeType() == 11) {
            if (z3) {
                Node firstChild = node3.getFirstChild();
                while (true) {
                    Node node5 = firstChild;
                    if (node5 == null) {
                        break;
                    } else if (!ownerDocument.isKidOK(this, node5)) {
                        Throwable th7 = th6;
                        new DOMException(3, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "HIERARCHY_REQUEST_ERR", (Object[]) null));
                        throw th7;
                    } else {
                        firstChild = node5.getNextSibling();
                    }
                }
            }
            while (node3.hasChildNodes()) {
                Node insertBefore = insertBefore(node3.getFirstChild(), node4);
            }
            return node3;
        } else if (node3 == node4) {
            Node nextSibling = node4.getNextSibling();
            Node removeChild = removeChild(node3);
            Node insertBefore2 = insertBefore(node3, nextSibling);
            return node3;
        } else {
            if (needsSyncChildren()) {
                synchronizeChildren();
            }
            if (z3) {
                if (isReadOnly()) {
                    Throwable th8 = th5;
                    new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                    throw th8;
                } else if (node3.getOwnerDocument() != ownerDocument) {
                    Throwable th9 = th4;
                    new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                    throw th9;
                } else if (!ownerDocument.isKidOK(this, node3)) {
                    Throwable th10 = th3;
                    new DOMException(3, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "HIERARCHY_REQUEST_ERR", (Object[]) null));
                    throw th10;
                } else if (node4 == null || node4.getParentNode() == this) {
                    boolean z4 = true;
                    NodeImpl nodeImpl = this;
                    while (true) {
                        NodeImpl nodeImpl2 = nodeImpl;
                        if (z4 && nodeImpl2 != null) {
                            z4 = node3 != nodeImpl2;
                            nodeImpl = nodeImpl2.parentNode();
                        }
                    }
                    if (!z4) {
                        Throwable th11 = th;
                        new DOMException(3, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "HIERARCHY_REQUEST_ERR", (Object[]) null));
                        throw th11;
                    }
                } else {
                    Throwable th12 = th2;
                    new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
                    throw th12;
                }
            }
            makeChildNode();
            ownerDocument.insertingNode(this, z2);
            ChildNode childNode = (ChildNode) node3;
            NodeImpl parentNode = childNode.parentNode();
            if (parentNode != null) {
                Node removeChild2 = parentNode.removeChild(childNode);
            }
            ChildNode childNode2 = (ChildNode) node4;
            childNode.ownerNode = this;
            childNode.isOwned(true);
            ChildNode childNode3 = (ChildNode) this.value;
            if (childNode3 == null) {
                this.value = childNode;
                childNode.isFirstChild(true);
                childNode.previousSibling = childNode;
            } else if (childNode2 == null) {
                ChildNode childNode4 = childNode3.previousSibling;
                childNode4.nextSibling = childNode;
                childNode.previousSibling = childNode4;
                childNode3.previousSibling = childNode;
            } else if (node4 == childNode3) {
                childNode3.isFirstChild(false);
                childNode.nextSibling = childNode3;
                childNode.previousSibling = childNode3.previousSibling;
                childNode3.previousSibling = childNode;
                this.value = childNode;
                childNode.isFirstChild(true);
            } else {
                ChildNode childNode5 = childNode2.previousSibling;
                childNode.nextSibling = childNode2;
                childNode5.nextSibling = childNode;
                childNode2.previousSibling = childNode;
                childNode.previousSibling = childNode5;
            }
            changed();
            ownerDocument.insertedNode(this, childNode, z2);
            checkNormalizationAfterInsert(childNode);
            return node3;
        }
    }

    /* access modifiers changed from: package-private */
    public Node internalRemoveChild(Node node, boolean z) throws DOMException {
        Throwable th;
        Throwable th2;
        Node node2 = node;
        boolean z2 = z;
        CoreDocumentImpl ownerDocument = ownerDocument();
        if (ownerDocument.errorChecking) {
            if (isReadOnly()) {
                Throwable th3 = th2;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th3;
            } else if (!(node2 == null || node2.getParentNode() == this)) {
                Throwable th4 = th;
                new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
                throw th4;
            }
        }
        ChildNode childNode = (ChildNode) node2;
        ownerDocument.removingNode(this, childNode, z2);
        if (childNode == this.value) {
            childNode.isFirstChild(false);
            this.value = childNode.nextSibling;
            ChildNode childNode2 = (ChildNode) this.value;
            if (childNode2 != null) {
                childNode2.isFirstChild(true);
                childNode2.previousSibling = childNode.previousSibling;
            }
        } else {
            ChildNode childNode3 = childNode.previousSibling;
            ChildNode childNode4 = childNode.nextSibling;
            childNode3.nextSibling = childNode4;
            if (childNode4 == null) {
                ((ChildNode) this.value).previousSibling = childNode3;
            } else {
                childNode4.previousSibling = childNode3;
            }
        }
        ChildNode previousSibling = childNode.previousSibling();
        childNode.ownerNode = ownerDocument;
        childNode.isOwned(false);
        childNode.nextSibling = null;
        childNode.previousSibling = null;
        changed();
        ownerDocument.removedNode(this, z2);
        checkNormalizationAfterRemove(previousSibling);
        return childNode;
    }

    public boolean isDerivedFrom(String str, String str2, int i) {
        String str3 = str;
        String str4 = str2;
        int i2 = i;
        return false;
    }

    public boolean isEqualNode(Node node) {
        return super.isEqualNode(node);
    }

    public boolean isId() {
        return isIdAttribute();
    }

    public Node item(int i) {
        int i2 = i;
        if (hasStringValue()) {
            if (i2 != 0 || this.value == null) {
                return null;
            }
            makeChildNode();
            return (Node) this.value;
        } else if (i2 < 0) {
            return null;
        } else {
            ChildNode childNode = (ChildNode) this.value;
            for (int i3 = 0; i3 < i2 && childNode != null; i3++) {
                childNode = childNode.nextSibling;
            }
            return childNode;
        }
    }

    /* access modifiers changed from: package-private */
    public final ChildNode lastChild() {
        makeChildNode();
        return this.value != null ? ((ChildNode) this.value).previousSibling : null;
    }

    /* access modifiers changed from: package-private */
    public final void lastChild(ChildNode childNode) {
        ChildNode childNode2 = childNode;
        if (this.value != null) {
            ((ChildNode) this.value).previousSibling = childNode2;
        }
    }

    /* access modifiers changed from: protected */
    public void makeChildNode() {
        if (hasStringValue()) {
            if (this.value != null) {
                TextImpl textImpl = (TextImpl) ownerDocument().createTextNode((String) this.value);
                this.value = textImpl;
                textImpl.isFirstChild(true);
                textImpl.previousSibling = textImpl;
                textImpl.ownerNode = this;
                textImpl.isOwned(true);
            }
            hasStringValue(false);
        }
    }

    public void normalize() {
        if (!isNormalized() && !hasStringValue()) {
            Node node = (ChildNode) this.value;
            while (true) {
                Node node2 = node;
                if (node2 == null) {
                    isNormalized(true);
                    return;
                }
                Node nextSibling = node2.getNextSibling();
                if (node2.getNodeType() == 3) {
                    if (nextSibling != null && nextSibling.getNodeType() == 3) {
                        ((Text) node2).appendData(nextSibling.getNodeValue());
                        Node removeChild = removeChild(nextSibling);
                        nextSibling = node2;
                    } else if (node2.getNodeValue() == null || node2.getNodeValue().length() == 0) {
                        Node removeChild2 = removeChild(node2);
                    }
                }
                node = nextSibling;
            }
        }
    }

    public Node removeChild(Node node) throws DOMException {
        Throwable th;
        Node node2 = node;
        if (!hasStringValue()) {
            return internalRemoveChild(node2, false);
        }
        Throwable th2 = th;
        new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
        throw th2;
    }

    /* access modifiers changed from: package-private */
    public void rename(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        this.name = str2;
    }

    public Node replaceChild(Node node, Node node2) throws DOMException {
        Node node3 = node;
        Node node4 = node2;
        makeChildNode();
        CoreDocumentImpl ownerDocument = ownerDocument();
        ownerDocument.replacingNode(this);
        Node internalInsertBefore = internalInsertBefore(node3, node4, true);
        if (node3 != node4) {
            Node internalRemoveChild = internalRemoveChild(node4, true);
        }
        ownerDocument.replacedNode(this);
        return node4;
    }

    public void setIdAttribute(boolean z) {
        boolean z2 = z;
        if (needsSyncData()) {
            synchronizeData();
        }
        isIdAttribute(z2);
    }

    public void setNodeValue(String str) throws DOMException {
        setValue(str);
    }

    /* access modifiers changed from: protected */
    public void setOwnerDocument(CoreDocumentImpl coreDocumentImpl) {
        CoreDocumentImpl coreDocumentImpl2 = coreDocumentImpl;
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        super.setOwnerDocument(coreDocumentImpl2);
        if (!hasStringValue()) {
            ChildNode childNode = (ChildNode) this.value;
            while (true) {
                ChildNode childNode2 = childNode;
                if (childNode2 != null) {
                    childNode2.setOwnerDocument(coreDocumentImpl2);
                    childNode = childNode2.nextSibling;
                } else {
                    return;
                }
            }
        }
    }

    public void setReadOnly(boolean z, boolean z2) {
        boolean z3 = z;
        boolean z4 = z2;
        super.setReadOnly(z3, z4);
        if (z4) {
            if (needsSyncChildren()) {
                synchronizeChildren();
            }
            if (!hasStringValue()) {
                ChildNode childNode = (ChildNode) this.value;
                while (true) {
                    ChildNode childNode2 = childNode;
                    if (childNode2 != null) {
                        if (childNode2.getNodeType() != 5) {
                            childNode2.setReadOnly(z3, true);
                        }
                        childNode = childNode2.nextSibling;
                    } else {
                        return;
                    }
                }
            }
        }
    }

    public void setSpecified(boolean z) {
        boolean z2 = z;
        if (needsSyncData()) {
            synchronizeData();
        }
        isSpecified(z2);
    }

    public void setType(Object obj) {
        Object obj2 = obj;
        this.type = obj2;
    }

    public void setValue(String str) {
        Throwable th;
        String str2 = str;
        CoreDocumentImpl ownerDocument = ownerDocument();
        if (!ownerDocument.errorChecking || !isReadOnly()) {
            Element ownerElement = getOwnerElement();
            String str3 = "";
            TextImpl textImpl = null;
            if (needsSyncData()) {
                synchronizeData();
            }
            if (needsSyncChildren()) {
                synchronizeChildren();
            }
            if (this.value != null) {
                if (!ownerDocument.getMutationEvents()) {
                    if (hasStringValue()) {
                        str3 = (String) this.value;
                    } else {
                        str3 = getValue();
                        ChildNode childNode = (ChildNode) this.value;
                        childNode.previousSibling = null;
                        childNode.isFirstChild(false);
                        childNode.ownerNode = ownerDocument;
                    }
                    this.value = null;
                    needsSyncChildren(false);
                } else if (hasStringValue()) {
                    str3 = (String) this.value;
                    textImpl = (TextImpl) ownerDocument.createTextNode((String) this.value);
                    this.value = textImpl;
                    textImpl.isFirstChild(true);
                    textImpl.previousSibling = textImpl;
                    textImpl.ownerNode = this;
                    textImpl.isOwned(true);
                    hasStringValue(false);
                    Node internalRemoveChild = internalRemoveChild(textImpl, true);
                } else {
                    str3 = getValue();
                    while (this.value != null) {
                        Node internalRemoveChild2 = internalRemoveChild((Node) this.value, true);
                    }
                }
                if (isIdAttribute() && ownerElement != null) {
                    ownerDocument.removeIdentifier(str3);
                }
            }
            isSpecified(true);
            if (ownerDocument.getMutationEvents()) {
                if (textImpl == null) {
                    textImpl = (TextImpl) ownerDocument.createTextNode(str2);
                } else {
                    textImpl.data = str2;
                }
                Node internalInsertBefore = internalInsertBefore(textImpl, (Node) null, true);
                hasStringValue(false);
                ownerDocument.modifiedAttrValue(this, str3);
            } else {
                this.value = str2;
                hasStringValue(true);
                changed();
            }
            if (isIdAttribute() && ownerElement != null) {
                ownerDocument.putIdentifier(str2, ownerElement);
                return;
            }
            return;
        }
        Throwable th2 = th;
        new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
        throw th2;
    }

    /* access modifiers changed from: protected */
    public void synchronizeChildren() {
        needsSyncChildren(false);
    }

    public String toString() {
        StringBuffer stringBuffer;
        new StringBuffer();
        return stringBuffer.append(getName()).append("=").append("\"").append(getValue()).append("\"").toString();
    }
}
