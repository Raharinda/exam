package org.apache.xerces.dom;

import java.io.OutputStream;
import java.io.Writer;
import org.w3c.dom.ls.LSOutput;

public class DOMOutputImpl implements LSOutput {
    protected OutputStream fByteStream = null;
    protected Writer fCharStream = null;
    protected String fEncoding = null;
    protected String fSystemId = null;

    public DOMOutputImpl() {
    }

    public OutputStream getByteStream() {
        return this.fByteStream;
    }

    public Writer getCharacterStream() {
        return this.fCharStream;
    }

    public String getEncoding() {
        return this.fEncoding;
    }

    public String getSystemId() {
        return this.fSystemId;
    }

    public void setByteStream(OutputStream outputStream) {
        OutputStream outputStream2 = outputStream;
        this.fByteStream = outputStream2;
    }

    public void setCharacterStream(Writer writer) {
        Writer writer2 = writer;
        this.fCharStream = writer2;
    }

    public void setEncoding(String str) {
        String str2 = str;
        this.fEncoding = str2;
    }

    public void setSystemId(String str) {
        String str2 = str;
        this.fSystemId = str2;
    }
}
