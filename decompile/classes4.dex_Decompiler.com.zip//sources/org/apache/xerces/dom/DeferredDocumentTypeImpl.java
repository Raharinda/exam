package org.apache.xerces.dom;

public class DeferredDocumentTypeImpl extends DocumentTypeImpl implements DeferredNode {
    static final long serialVersionUID = -2172579663227313509L;
    protected transient int fNodeIndex;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    DeferredDocumentTypeImpl(DeferredDocumentImpl deferredDocumentImpl, int i) {
        super(deferredDocumentImpl, (String) null);
        this.fNodeIndex = i;
        needsSyncData(true);
        needsSyncChildren(true);
    }

    public int getNodeIndex() {
        return this.fNodeIndex;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void synchronizeChildren() {
        /*
            r12 = this;
            r0 = r12
            r7 = r0
            org.apache.xerces.dom.CoreDocumentImpl r7 = r7.ownerDocument()
            boolean r7 = r7.getMutationEvents()
            r1 = r7
            r7 = r0
            org.apache.xerces.dom.CoreDocumentImpl r7 = r7.ownerDocument()
            r8 = 0
            r7.setMutationEvents(r8)
            r7 = r0
            r8 = 0
            r7.needsSyncChildren(r8)
            r7 = r0
            org.apache.xerces.dom.CoreDocumentImpl r7 = r7.ownerDocument
            org.apache.xerces.dom.DeferredDocumentImpl r7 = (org.apache.xerces.dom.DeferredDocumentImpl) r7
            r2 = r7
            r7 = r0
            org.apache.xerces.dom.NamedNodeMapImpl r8 = new org.apache.xerces.dom.NamedNodeMapImpl
            r11 = r8
            r8 = r11
            r9 = r11
            r10 = r0
            r9.<init>(r10)
            r7.entities = r8
            r7 = r0
            org.apache.xerces.dom.NamedNodeMapImpl r8 = new org.apache.xerces.dom.NamedNodeMapImpl
            r11 = r8
            r8 = r11
            r9 = r11
            r10 = r0
            r9.<init>(r10)
            r7.notations = r8
            r7 = r0
            org.apache.xerces.dom.NamedNodeMapImpl r8 = new org.apache.xerces.dom.NamedNodeMapImpl
            r11 = r8
            r8 = r11
            r9 = r11
            r10 = r0
            r9.<init>(r10)
            r7.elements = r8
            r7 = 0
            r3 = r7
            r7 = r2
            r8 = r0
            int r8 = r8.fNodeIndex
            int r7 = r7.getLastChild(r8)
            r4 = r7
        L_0x004e:
            r7 = r4
            r8 = -1
            if (r7 != r8) goto L_0x0062
            r7 = r0
            org.apache.xerces.dom.CoreDocumentImpl r7 = r7.ownerDocument()
            r8 = r1
            r7.setMutationEvents(r8)
            r7 = r0
            r8 = 1
            r9 = 0
            r7.setReadOnly(r8, r9)
            return
        L_0x0062:
            r7 = r2
            r8 = r4
            org.apache.xerces.dom.DeferredNode r7 = r7.getNodeObject(r8)
            r5 = r7
            r7 = r5
            short r7 = r7.getNodeType()
            r6 = r7
            r7 = r6
            switch(r7) {
                case 1: goto L_0x00cb;
                case 6: goto L_0x00b0;
                case 12: goto L_0x00b9;
                case 21: goto L_0x00c2;
                default: goto L_0x0073;
            }
        L_0x0073:
            java.io.PrintStream r7 = java.lang.System.out
            java.lang.StringBuffer r8 = new java.lang.StringBuffer
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            java.lang.String r9 = "DeferredDocumentTypeImpl#synchronizeInfo: node.getNodeType() = "
            java.lang.StringBuffer r8 = r8.append(r9)
            r9 = r5
            short r9 = r9.getNodeType()
            java.lang.StringBuffer r8 = r8.append(r9)
            java.lang.String r9 = ", class = "
            java.lang.StringBuffer r8 = r8.append(r9)
            r9 = r5
            java.lang.Class r9 = r9.getClass()
            java.lang.String r9 = r9.getName()
            java.lang.StringBuffer r8 = r8.append(r9)
            java.lang.String r8 = r8.toString()
            r7.println(r8)
        L_0x00a8:
            r7 = r2
            r8 = r4
            int r7 = r7.getPrevSibling(r8)
            r4 = r7
            goto L_0x004e
        L_0x00b0:
            r7 = r0
            org.apache.xerces.dom.NamedNodeMapImpl r7 = r7.entities
            r8 = r5
            org.w3c.dom.Node r7 = r7.setNamedItem(r8)
            goto L_0x00a8
        L_0x00b9:
            r7 = r0
            org.apache.xerces.dom.NamedNodeMapImpl r7 = r7.notations
            r8 = r5
            org.w3c.dom.Node r7 = r7.setNamedItem(r8)
            goto L_0x00a8
        L_0x00c2:
            r7 = r0
            org.apache.xerces.dom.NamedNodeMapImpl r7 = r7.elements
            r8 = r5
            org.w3c.dom.Node r7 = r7.setNamedItem(r8)
            goto L_0x00a8
        L_0x00cb:
            r7 = r0
            org.w3c.dom.Document r7 = r7.getOwnerDocument()
            org.apache.xerces.dom.DocumentImpl r7 = (org.apache.xerces.dom.DocumentImpl) r7
            boolean r7 = r7.allowGrammarAccess
            if (r7 == 0) goto L_0x0073
            r7 = r0
            r8 = r5
            r9 = r3
            org.w3c.dom.Node r7 = r7.insertBefore(r8, r9)
            r7 = r5
            r3 = r7
            goto L_0x00a8
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.DeferredDocumentTypeImpl.synchronizeChildren():void");
    }

    /* access modifiers changed from: protected */
    public void synchronizeData() {
        needsSyncData(false);
        DeferredDocumentImpl deferredDocumentImpl = (DeferredDocumentImpl) this.ownerDocument;
        this.name = deferredDocumentImpl.getNodeName(this.fNodeIndex);
        this.publicID = deferredDocumentImpl.getNodeValue(this.fNodeIndex);
        this.systemID = deferredDocumentImpl.getNodeURI(this.fNodeIndex);
        this.internalSubset = deferredDocumentImpl.getNodeValue(deferredDocumentImpl.getNodeExtra(this.fNodeIndex));
    }
}
