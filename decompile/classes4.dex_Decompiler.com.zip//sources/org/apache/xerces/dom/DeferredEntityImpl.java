package org.apache.xerces.dom;

public class DeferredEntityImpl extends EntityImpl implements DeferredNode {
    static final long serialVersionUID = 4760180431078941638L;
    protected transient int fNodeIndex;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    DeferredEntityImpl(DeferredDocumentImpl deferredDocumentImpl, int i) {
        super(deferredDocumentImpl, (String) null);
        this.fNodeIndex = i;
        needsSyncData(true);
        needsSyncChildren(true);
    }

    public int getNodeIndex() {
        return this.fNodeIndex;
    }

    /* access modifiers changed from: protected */
    public void synchronizeChildren() {
        needsSyncChildren(false);
        isReadOnly(false);
        ((DeferredDocumentImpl) ownerDocument()).synchronizeChildren((ParentNode) this, this.fNodeIndex);
        setReadOnly(true, true);
    }

    /* access modifiers changed from: protected */
    public void synchronizeData() {
        needsSyncData(false);
        DeferredDocumentImpl deferredDocumentImpl = (DeferredDocumentImpl) this.ownerDocument;
        this.name = deferredDocumentImpl.getNodeName(this.fNodeIndex);
        this.publicId = deferredDocumentImpl.getNodeValue(this.fNodeIndex);
        this.systemId = deferredDocumentImpl.getNodeURI(this.fNodeIndex);
        int nodeExtra = deferredDocumentImpl.getNodeExtra(this.fNodeIndex);
        short nodeType = deferredDocumentImpl.getNodeType(nodeExtra);
        this.notationName = deferredDocumentImpl.getNodeName(nodeExtra);
        this.version = deferredDocumentImpl.getNodeValue(nodeExtra);
        this.encoding = deferredDocumentImpl.getNodeURI(nodeExtra);
        int nodeExtra2 = deferredDocumentImpl.getNodeExtra(nodeExtra);
        this.baseURI = deferredDocumentImpl.getNodeName(nodeExtra2);
        this.inputEncoding = deferredDocumentImpl.getNodeValue(nodeExtra2);
    }
}
