package org.apache.xerces.dom;

import com.kodular.fabextension.BuildConfig;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.WeakHashMap;
import net.lingala.zip4j.util.Zip4jConstants;
import org.apache.xerces.dom.ParentNode;
import org.apache.xerces.util.URI;
import org.apache.xerces.util.XML11Char;
import org.apache.xerces.util.XMLChar;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xml.serialize.Method;
import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Comment;
import org.w3c.dom.DOMConfiguration;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.Entity;
import org.w3c.dom.EntityReference;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Notation;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;
import org.w3c.dom.UserDataHandler;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventListener;

public class CoreDocumentImpl extends ParentNode implements Document {
    static Class class$org$w3c$dom$Document;
    private static final int[] kidOK = new int[13];
    static final long serialVersionUID = 0;
    protected String actualEncoding;
    protected boolean allowGrammarAccess;
    protected int changes;
    protected ElementImpl docElement;
    protected DocumentTypeImpl docType;
    private int documentNumber;
    transient DOMNormalizer domNormalizer;
    protected String encoding;
    protected boolean errorChecking;
    transient DOMConfigurationImpl fConfiguration;
    protected String fDocumentURI;
    transient NodeListCache fFreeNLCache;
    transient Object fXPathEvaluator;
    protected Hashtable identifiers;
    private int nodeCounter;
    private Map nodeTable;
    protected boolean standalone;
    protected Map userData;
    protected String version;
    private boolean xml11Version;
    protected boolean xmlVersionChanged;

    static {
        kidOK[9] = 1410;
        int[] iArr = kidOK;
        int[] iArr2 = kidOK;
        int[] iArr3 = kidOK;
        kidOK[1] = 442;
        iArr3[5] = 442;
        iArr2[6] = 442;
        iArr[11] = 442;
        kidOK[2] = 40;
        int[] iArr4 = kidOK;
        int[] iArr5 = kidOK;
        int[] iArr6 = kidOK;
        int[] iArr7 = kidOK;
        int[] iArr8 = kidOK;
        kidOK[12] = 0;
        iArr8[4] = 0;
        iArr7[3] = 0;
        iArr6[8] = 0;
        iArr5[7] = 0;
        iArr4[10] = 0;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public CoreDocumentImpl() {
        this(false);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public CoreDocumentImpl(DocumentType documentType) {
        this(documentType, false);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public CoreDocumentImpl(DocumentType documentType, boolean z) {
        this(z);
        Throwable th;
        DocumentType documentType2 = documentType;
        if (documentType2 != null) {
            try {
                ((DocumentTypeImpl) documentType2).ownerDocument = this;
                Node appendChild = appendChild(documentType2);
            } catch (ClassCastException e) {
                ClassCastException classCastException = e;
                Throwable th2 = th;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th2;
            }
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CoreDocumentImpl(boolean z) {
        super((CoreDocumentImpl) null);
        this.domNormalizer = null;
        this.fConfiguration = null;
        this.fXPathEvaluator = null;
        this.changes = 0;
        this.errorChecking = true;
        this.xmlVersionChanged = false;
        this.documentNumber = 0;
        this.nodeCounter = 0;
        this.xml11Version = false;
        this.ownerDocument = this;
        this.allowGrammarAccess = z;
    }

    static Class class$(String str) {
        Throwable th;
        try {
            return Class.forName(str);
        } catch (ClassNotFoundException e) {
            ClassNotFoundException classNotFoundException = e;
            Throwable th2 = th;
            new NoClassDefFoundError(classNotFoundException.getMessage());
            throw th2;
        }
    }

    private Node importNode(Node node, boolean z, boolean z2, HashMap hashMap) throws DOMException {
        Element element;
        Throwable th;
        Object obj;
        Hashtable hashtable;
        Throwable th2;
        Node node2 = node;
        boolean z3 = z;
        boolean z4 = z2;
        HashMap hashMap2 = hashMap;
        Hashtable hashtable2 = null;
        if (node2 instanceof NodeImpl) {
            hashtable2 = ((NodeImpl) node2).getUserDataRecord();
        }
        switch (node2.getNodeType()) {
            case 1:
                boolean hasFeature = node2.getOwnerDocument().getImplementation().hasFeature("XML", "2.0");
                Element createElement = (!hasFeature || node2.getLocalName() == null) ? createElement(node2.getNodeName()) : createElementNS(node2.getNamespaceURI(), node2.getNodeName());
                NamedNodeMap attributes = node2.getAttributes();
                if (attributes != null) {
                    int length = attributes.getLength();
                    for (int i = 0; i < length; i++) {
                        Attr attr = (Attr) attributes.item(i);
                        if (attr.getSpecified() || z4) {
                            Attr attr2 = (Attr) importNode(attr, true, z4, hashMap2);
                            if (!hasFeature || attr.getLocalName() == null) {
                                Attr attributeNode = createElement.setAttributeNode(attr2);
                            } else {
                                Attr attributeNodeNS = createElement.setAttributeNodeNS(attr2);
                            }
                        }
                    }
                }
                if (!(hashMap2 == null || (obj = hashMap2.get(node2)) == null)) {
                    if (this.identifiers == null) {
                        new Hashtable();
                        this.identifiers = hashtable;
                    }
                    Object put = this.identifiers.put(obj, createElement);
                }
                element = createElement;
                break;
            case 2:
                element = node2.getOwnerDocument().getImplementation().hasFeature("XML", "2.0") ? node2.getLocalName() == null ? createAttribute(node2.getNodeName()) : createAttributeNS(node2.getNamespaceURI(), node2.getNodeName()) : createAttribute(node2.getNodeName());
                if (!(node2 instanceof AttrImpl)) {
                    if (node2.getFirstChild() != null) {
                        z3 = true;
                        break;
                    } else {
                        element.setNodeValue(node2.getNodeValue());
                        z3 = false;
                        break;
                    }
                } else {
                    AttrImpl attrImpl = (AttrImpl) node2;
                    if (!attrImpl.hasStringValue()) {
                        z3 = true;
                        break;
                    } else {
                        ((AttrImpl) element).setValue(attrImpl.getValue());
                        z3 = false;
                        break;
                    }
                }
            case 3:
                element = createTextNode(node2.getNodeValue());
                break;
            case 4:
                element = createCDATASection(node2.getNodeValue());
                break;
            case 5:
                element = createEntityReference(node2.getNodeName());
                z3 = false;
                break;
            case 6:
                Entity entity = (Entity) node2;
                EntityImpl entityImpl = (EntityImpl) createEntity(node2.getNodeName());
                entityImpl.setPublicId(entity.getPublicId());
                entityImpl.setSystemId(entity.getSystemId());
                entityImpl.setNotationName(entity.getNotationName());
                entityImpl.isReadOnly(false);
                element = entityImpl;
                break;
            case Zip4jConstants.DEFLATE_LEVEL_MAXIMUM:
                element = createProcessingInstruction(node2.getNodeName(), node2.getNodeValue());
                break;
            case 8:
                element = createComment(node2.getNodeValue());
                break;
            case 10:
                if (z4) {
                    DocumentType documentType = (DocumentType) node2;
                    DocumentTypeImpl documentTypeImpl = (DocumentTypeImpl) createDocumentType(documentType.getNodeName(), documentType.getPublicId(), documentType.getSystemId());
                    documentTypeImpl.setInternalSubset(documentType.getInternalSubset());
                    NamedNodeMap entities = documentType.getEntities();
                    NamedNodeMap entities2 = documentTypeImpl.getEntities();
                    if (entities != null) {
                        for (int i2 = 0; i2 < entities.getLength(); i2++) {
                            Node namedItem = entities2.setNamedItem(importNode(entities.item(i2), true, true, hashMap2));
                        }
                    }
                    NamedNodeMap notations = documentType.getNotations();
                    NamedNodeMap notations2 = documentTypeImpl.getNotations();
                    if (notations != null) {
                        for (int i3 = 0; i3 < notations.getLength(); i3++) {
                            Node namedItem2 = notations2.setNamedItem(importNode(notations.item(i3), true, true, hashMap2));
                        }
                    }
                    element = documentTypeImpl;
                    break;
                } else {
                    Throwable th3 = th;
                    new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
                    throw th3;
                }
            case 11:
                element = createDocumentFragment();
                break;
            case 12:
                Notation notation = (Notation) node2;
                Node node3 = (NotationImpl) createNotation(node2.getNodeName());
                node3.setPublicId(notation.getPublicId());
                node3.setSystemId(notation.getSystemId());
                element = node3;
                break;
            default:
                Throwable th4 = th2;
                new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
                throw th4;
        }
        if (hashtable2 != null) {
            callUserDataHandlers(node2, element, 2, hashtable2);
        }
        if (z3) {
            Node firstChild = node2.getFirstChild();
            while (true) {
                Node node4 = firstChild;
                if (node4 != null) {
                    Node appendChild = element.appendChild(importNode(node4, true, z4, hashMap2));
                    firstChild = node4.getNextSibling();
                }
            }
        }
        if (element.getNodeType() == 6) {
            ((NodeImpl) element).setReadOnly(true, true);
        }
        return element;
    }

    public static final boolean isValidQName(String str, String str2, boolean z) {
        boolean z2;
        String str3 = str;
        String str4 = str2;
        boolean z3 = z;
        if (str4 == null) {
            return false;
        }
        if (!z3) {
            z2 = (str3 == null || XMLChar.isValidNCName(str3)) && XMLChar.isValidNCName(str4);
        } else {
            z2 = (str3 == null || XML11Char.isXML11ValidNCName(str3)) && XML11Char.isXML11ValidNCName(str4);
        }
        return z2;
    }

    public static final boolean isXMLName(String str, boolean z) {
        String str2 = str;
        boolean z2 = z;
        if (str2 == null) {
            return false;
        }
        return !z2 ? XMLChar.isValidName(str2) : XML11Char.isXML11ValidName(str2);
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        Map map;
        Map map2;
        objectInputStream.defaultReadObject();
        if (this.userData != null) {
            new WeakHashMap(this.userData);
            this.userData = map2;
        }
        if (this.nodeTable != null) {
            new WeakHashMap(this.nodeTable);
            this.nodeTable = map;
        }
    }

    private ElementImpl replaceRenameElement(ElementImpl elementImpl, String str, String str2) {
        ElementImpl elementImpl2 = elementImpl;
        ElementNSImpl elementNSImpl = (ElementNSImpl) createElementNS(str, str2);
        copyEventListeners(elementImpl2, elementNSImpl);
        Hashtable removeUserDataTable = removeUserDataTable(elementImpl2);
        Node parentNode = elementImpl2.getParentNode();
        Node nextSibling = elementImpl2.getNextSibling();
        if (parentNode != null) {
            Node removeChild = parentNode.removeChild(elementImpl2);
        }
        Node firstChild = elementImpl2.getFirstChild();
        while (true) {
            Node node = firstChild;
            if (node == null) {
                break;
            }
            Node removeChild2 = elementImpl2.removeChild(node);
            Node appendChild = elementNSImpl.appendChild(node);
            firstChild = elementImpl2.getFirstChild();
        }
        elementNSImpl.moveSpecifiedAttributes(elementImpl2);
        setUserDataTable(elementNSImpl, removeUserDataTable);
        callUserDataHandlers(elementImpl2, elementNSImpl, 4);
        if (parentNode != null) {
            Node insertBefore = parentNode.insertBefore(elementNSImpl, nextSibling);
        }
        return elementNSImpl;
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        Map map;
        Map map2;
        ObjectOutputStream objectOutputStream2 = objectOutputStream;
        Map map3 = this.userData;
        Map map4 = this.nodeTable;
        if (map3 != null) {
            try {
                new Hashtable(map3);
                this.userData = map2;
            } catch (Throwable th) {
                Throwable th2 = th;
                this.userData = map3;
                this.nodeTable = map4;
                throw th2;
            }
        }
        if (map4 != null) {
            new Hashtable(map4);
            this.nodeTable = map;
        }
        objectOutputStream2.defaultWriteObject();
        this.userData = map3;
        this.nodeTable = map4;
    }

    public void abort() {
    }

    /* access modifiers changed from: protected */
    public void addEventListener(NodeImpl nodeImpl, String str, EventListener eventListener, boolean z) {
    }

    public Node adoptNode(Node node) {
        Hashtable userDataRecord;
        Node namedItem;
        Throwable th;
        Throwable th2;
        Node node2 = node;
        try {
            NodeImpl nodeImpl = (NodeImpl) node2;
            if (node2 == null) {
                return null;
            }
            if (!(node2 == null || node2.getOwnerDocument() == null)) {
                DOMImplementation implementation = getImplementation();
                DOMImplementation implementation2 = node2.getOwnerDocument().getImplementation();
                if (implementation != implementation2) {
                    if ((implementation instanceof DOMImplementationImpl) && (implementation2 instanceof DeferredDOMImplementationImpl)) {
                        undeferChildren(nodeImpl);
                    } else if (!(implementation instanceof DeferredDOMImplementationImpl) || !(implementation2 instanceof DOMImplementationImpl)) {
                        return null;
                    }
                } else if (implementation2 instanceof DeferredDOMImplementationImpl) {
                    undeferChildren(nodeImpl);
                }
            }
            switch (nodeImpl.getNodeType()) {
                case 1:
                    userDataRecord = nodeImpl.getUserDataRecord();
                    Node parentNode = nodeImpl.getParentNode();
                    if (parentNode != null) {
                        Node removeChild = parentNode.removeChild(node2);
                    }
                    nodeImpl.setOwnerDocument(this);
                    if (userDataRecord != null) {
                        setUserDataTable(nodeImpl, userDataRecord);
                    }
                    ((ElementImpl) nodeImpl).reconcileDefaultAttributes();
                    break;
                case 2:
                    AttrImpl attrImpl = (AttrImpl) nodeImpl;
                    if (attrImpl.getOwnerElement() != null) {
                        Attr removeAttributeNode = attrImpl.getOwnerElement().removeAttributeNode(attrImpl);
                    }
                    attrImpl.isSpecified(true);
                    userDataRecord = nodeImpl.getUserDataRecord();
                    attrImpl.setOwnerDocument(this);
                    if (userDataRecord != null) {
                        setUserDataTable(nodeImpl, userDataRecord);
                        break;
                    }
                    break;
                case 5:
                    userDataRecord = nodeImpl.getUserDataRecord();
                    Node parentNode2 = nodeImpl.getParentNode();
                    if (parentNode2 != null) {
                        Node removeChild2 = parentNode2.removeChild(node2);
                    }
                    while (true) {
                        Node firstChild = nodeImpl.getFirstChild();
                        Node node3 = firstChild;
                        if (firstChild == null) {
                            nodeImpl.setOwnerDocument(this);
                            if (userDataRecord != null) {
                                setUserDataTable(nodeImpl, userDataRecord);
                            }
                            if (!(this.docType == null || (namedItem = this.docType.getEntities().getNamedItem(nodeImpl.getNodeName())) == null)) {
                                Node firstChild2 = namedItem.getFirstChild();
                                while (true) {
                                    Node node4 = firstChild2;
                                    if (node4 == null) {
                                        break;
                                    } else {
                                        Node appendChild = nodeImpl.appendChild(node4.cloneNode(true));
                                        firstChild2 = node4.getNextSibling();
                                    }
                                }
                            }
                        } else {
                            Node removeChild3 = nodeImpl.removeChild(node3);
                        }
                    }
                case 6:
                case 12:
                    Throwable th3 = th2;
                    new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                    throw th3;
                case Zip4jConstants.DEFLATE_LEVEL_ULTRA:
                case 10:
                    Throwable th4 = th;
                    new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
                    throw th4;
                default:
                    userDataRecord = nodeImpl.getUserDataRecord();
                    Node parentNode3 = nodeImpl.getParentNode();
                    if (parentNode3 != null) {
                        Node removeChild4 = parentNode3.removeChild(node2);
                    }
                    nodeImpl.setOwnerDocument(this);
                    if (userDataRecord != null) {
                        setUserDataTable(nodeImpl, userDataRecord);
                        break;
                    }
                    break;
            }
            if (userDataRecord != null) {
                callUserDataHandlers(node2, (Node) null, 5, userDataRecord);
            }
            return nodeImpl;
        } catch (ClassCastException e) {
            ClassCastException classCastException = e;
            return null;
        }
    }

    /* access modifiers changed from: protected */
    public void callUserDataHandlers(Node node, Node node2, short s) {
        Hashtable userDataRecord;
        Node node3 = node;
        Node node4 = node2;
        short s2 = s;
        if (this.userData != null && (node3 instanceof NodeImpl) && (userDataRecord = ((NodeImpl) node3).getUserDataRecord()) != null && !userDataRecord.isEmpty()) {
            callUserDataHandlers(node3, node4, s2, userDataRecord);
        }
    }

    /* access modifiers changed from: package-private */
    public void callUserDataHandlers(Node node, Node node2, short s, Hashtable hashtable) {
        Node node3 = node;
        Node node4 = node2;
        short s2 = s;
        Hashtable hashtable2 = hashtable;
        if (hashtable2 != null && !hashtable2.isEmpty()) {
            for (Map.Entry entry : hashtable2.entrySet()) {
                String str = (String) entry.getKey();
                ParentNode.UserDataRecord userDataRecord = (ParentNode.UserDataRecord) entry.getValue();
                if (userDataRecord.fHandler != null) {
                    userDataRecord.fHandler.handle(s2, str, userDataRecord.fData, node3, node4);
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public boolean canRenameElements(String str, String str2, ElementImpl elementImpl) {
        String str3 = str;
        String str4 = str2;
        ElementImpl elementImpl2 = elementImpl;
        return true;
    }

    /* access modifiers changed from: protected */
    public void changed() {
        this.changes++;
    }

    /* access modifiers changed from: protected */
    public int changes() {
        return this.changes;
    }

    /* access modifiers changed from: protected */
    public final void checkDOMNSErr(String str, String str2) {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str3 = str;
        String str4 = str2;
        if (!this.errorChecking) {
            return;
        }
        if (str4 == null) {
            Throwable th4 = th3;
            new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
            throw th4;
        } else if (str3.equals(Method.XML) && !str4.equals(NamespaceContext.XML_URI)) {
            Throwable th5 = th2;
            new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
            throw th5;
        } else if ((str3.equals("xmlns") && !str4.equals(NamespaceContext.XMLNS_URI)) || (!str3.equals("xmlns") && str4.equals(NamespaceContext.XMLNS_URI))) {
            Throwable th6 = th;
            new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
            throw th6;
        }
    }

    /* access modifiers changed from: protected */
    public final void checkNamespaceWF(String str, int i, int i2) {
        Throwable th;
        String str2 = str;
        int i3 = i;
        int i4 = i2;
        if (this.errorChecking) {
            if (i3 == 0 || i3 == str2.length() - 1 || i4 != i3) {
                Throwable th2 = th;
                new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
                throw th2;
            }
        }
    }

    /* access modifiers changed from: protected */
    public final void checkQName(String str, String str2) {
        boolean z;
        Throwable th;
        String str3 = str;
        String str4 = str2;
        if (this.errorChecking) {
            if (!this.xml11Version) {
                z = (str3 == null || XMLChar.isValidNCName(str3)) && XMLChar.isValidNCName(str4);
            } else {
                z = (str3 == null || XML11Char.isXML11ValidNCName(str3)) && XML11Char.isXML11ValidNCName(str4);
            }
            if (!z) {
                Throwable th2 = th;
                new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
                throw th2;
            }
        }
    }

    /* access modifiers changed from: protected */
    public final void clearIdentifiers() {
        if (this.identifiers != null) {
            this.identifiers.clear();
        }
    }

    public Object clone() throws CloneNotSupportedException {
        CoreDocumentImpl coreDocumentImpl = (CoreDocumentImpl) super.clone();
        coreDocumentImpl.docType = null;
        coreDocumentImpl.docElement = null;
        return coreDocumentImpl;
    }

    public Node cloneNode(boolean z) {
        CoreDocumentImpl coreDocumentImpl;
        new CoreDocumentImpl();
        CoreDocumentImpl coreDocumentImpl2 = coreDocumentImpl;
        callUserDataHandlers(this, coreDocumentImpl2, 1);
        cloneNode(coreDocumentImpl2, z);
        return coreDocumentImpl2;
    }

    /* access modifiers changed from: protected */
    public void cloneNode(CoreDocumentImpl coreDocumentImpl, boolean z) {
        HashMap hashMap;
        CoreDocumentImpl coreDocumentImpl2 = coreDocumentImpl;
        boolean z2 = z;
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        if (z2) {
            HashMap hashMap2 = null;
            if (this.identifiers != null) {
                new HashMap();
                hashMap2 = hashMap;
                for (Map.Entry entry : this.identifiers.entrySet()) {
                    Object put = hashMap2.put(entry.getValue(), entry.getKey());
                }
            }
            ChildNode childNode = this.firstChild;
            while (true) {
                ChildNode childNode2 = childNode;
                if (childNode2 == null) {
                    break;
                }
                Node appendChild = coreDocumentImpl2.appendChild(coreDocumentImpl2.importNode(childNode2, true, true, hashMap2));
                childNode = childNode2.nextSibling;
            }
        }
        coreDocumentImpl2.allowGrammarAccess = this.allowGrammarAccess;
        coreDocumentImpl2.errorChecking = this.errorChecking;
    }

    /* access modifiers changed from: protected */
    public void copyEventListeners(NodeImpl nodeImpl, NodeImpl nodeImpl2) {
    }

    public Attr createAttribute(String str) throws DOMException {
        Attr attr;
        Throwable th;
        String str2 = str;
        if (!this.errorChecking || isXMLName(str2, this.xml11Version)) {
            new AttrImpl(this, str2);
            return attr;
        }
        Throwable th2 = th;
        new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
        throw th2;
    }

    public Attr createAttributeNS(String str, String str2) throws DOMException {
        Attr attr;
        new AttrNSImpl(this, str, str2);
        return attr;
    }

    public Attr createAttributeNS(String str, String str2, String str3) throws DOMException {
        Attr attr;
        new AttrNSImpl(this, str, str2, str3);
        return attr;
    }

    public CDATASection createCDATASection(String str) throws DOMException {
        CDATASection cDATASection;
        new CDATASectionImpl(this, str);
        return cDATASection;
    }

    public Comment createComment(String str) {
        Comment comment;
        new CommentImpl(this, str);
        return comment;
    }

    public DocumentFragment createDocumentFragment() {
        DocumentFragment documentFragment;
        new DocumentFragmentImpl(this);
        return documentFragment;
    }

    public DocumentType createDocumentType(String str, String str2, String str3) throws DOMException {
        DocumentType documentType;
        new DocumentTypeImpl(this, str, str2, str3);
        return documentType;
    }

    public Element createElement(String str) throws DOMException {
        Element element;
        Throwable th;
        String str2 = str;
        if (!this.errorChecking || isXMLName(str2, this.xml11Version)) {
            new ElementImpl(this, str2);
            return element;
        }
        Throwable th2 = th;
        new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
        throw th2;
    }

    public ElementDefinitionImpl createElementDefinition(String str) throws DOMException {
        ElementDefinitionImpl elementDefinitionImpl;
        Throwable th;
        String str2 = str;
        if (!this.errorChecking || isXMLName(str2, this.xml11Version)) {
            new ElementDefinitionImpl(this, str2);
            return elementDefinitionImpl;
        }
        Throwable th2 = th;
        new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
        throw th2;
    }

    public Element createElementNS(String str, String str2) throws DOMException {
        Element element;
        new ElementNSImpl(this, str, str2);
        return element;
    }

    public Element createElementNS(String str, String str2, String str3) throws DOMException {
        Element element;
        new ElementNSImpl(this, str, str2, str3);
        return element;
    }

    public Entity createEntity(String str) throws DOMException {
        Entity entity;
        Throwable th;
        String str2 = str;
        if (!this.errorChecking || isXMLName(str2, this.xml11Version)) {
            new EntityImpl(this, str2);
            return entity;
        }
        Throwable th2 = th;
        new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
        throw th2;
    }

    public EntityReference createEntityReference(String str) throws DOMException {
        EntityReference entityReference;
        Throwable th;
        String str2 = str;
        if (!this.errorChecking || isXMLName(str2, this.xml11Version)) {
            new EntityReferenceImpl(this, str2);
            return entityReference;
        }
        Throwable th2 = th;
        new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
        throw th2;
    }

    public Notation createNotation(String str) throws DOMException {
        Notation notation;
        Throwable th;
        String str2 = str;
        if (!this.errorChecking || isXMLName(str2, this.xml11Version)) {
            new NotationImpl(this, str2);
            return notation;
        }
        Throwable th2 = th;
        new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
        throw th2;
    }

    public ProcessingInstruction createProcessingInstruction(String str, String str2) throws DOMException {
        ProcessingInstruction processingInstruction;
        Throwable th;
        String str3 = str;
        String str4 = str2;
        if (!this.errorChecking || isXMLName(str3, this.xml11Version)) {
            new ProcessingInstructionImpl(this, str3, str4);
            return processingInstruction;
        }
        Throwable th2 = th;
        new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
        throw th2;
    }

    public Text createTextNode(String str) {
        Text text;
        new TextImpl(this, str);
        return text;
    }

    /* access modifiers changed from: package-private */
    public void deletedText(CharacterDataImpl characterDataImpl, int i, int i2) {
    }

    /* access modifiers changed from: protected */
    public boolean dispatchEvent(NodeImpl nodeImpl, Event event) {
        NodeImpl nodeImpl2 = nodeImpl;
        Event event2 = event;
        return false;
    }

    /* access modifiers changed from: package-private */
    public void freeNodeListCache(NodeListCache nodeListCache) {
        NodeListCache nodeListCache2 = nodeListCache;
        nodeListCache2.next = this.fFreeNLCache;
        this.fFreeNLCache = nodeListCache2;
    }

    public boolean getAsync() {
        return false;
    }

    public String getBaseURI() {
        URI uri;
        if (this.fDocumentURI == null || this.fDocumentURI.length() == 0) {
            return this.fDocumentURI;
        }
        try {
            new URI(this.fDocumentURI);
            return uri.toString();
        } catch (URI.MalformedURIException e) {
            URI.MalformedURIException malformedURIException = e;
            return null;
        }
    }

    public DocumentType getDoctype() {
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        return this.docType;
    }

    public Element getDocumentElement() {
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        return this.docElement;
    }

    public String getDocumentURI() {
        return this.fDocumentURI;
    }

    public DOMConfiguration getDomConfig() {
        DOMConfigurationImpl dOMConfigurationImpl;
        if (this.fConfiguration == null) {
            new DOMConfigurationImpl();
            this.fConfiguration = dOMConfigurationImpl;
        }
        return this.fConfiguration;
    }

    public Element getElementById(String str) {
        return getIdentifier(str);
    }

    public NodeList getElementsByTagName(String str) {
        NodeList nodeList;
        new DeepNodeListImpl(this, str);
        return nodeList;
    }

    public NodeList getElementsByTagNameNS(String str, String str2) {
        NodeList nodeList;
        new DeepNodeListImpl(this, str, str2);
        return nodeList;
    }

    public String getEncoding() {
        return getXmlEncoding();
    }

    public boolean getErrorChecking() {
        return this.errorChecking;
    }

    public Object getFeature(String str, String str2) {
        Class cls;
        String str3 = str;
        String str4 = str2;
        boolean z = str4 == null || str4.length() == 0;
        if (!str3.equalsIgnoreCase("+XPath") || (!z && !str4.equals("3.0"))) {
            return super.getFeature(str3, str4);
        }
        if (this.fXPathEvaluator != null) {
            return this.fXPathEvaluator;
        }
        try {
            Class findProviderClass = ObjectFactory.findProviderClass("org.apache.xpath.domapi.XPathEvaluatorImpl", ObjectFactory.findClassLoader(), true);
            Class cls2 = findProviderClass;
            Class[] clsArr = new Class[1];
            Class[] clsArr2 = clsArr;
            Class[] clsArr3 = clsArr;
            if (class$org$w3c$dom$Document == null) {
                Class class$ = class$("org.w3c.dom.Document");
                cls = class$;
                class$org$w3c$dom$Document = class$;
            } else {
                cls = class$org$w3c$dom$Document;
            }
            clsArr3[0] = cls;
            Constructor constructor = cls2.getConstructor(clsArr2);
            Class[] interfaces = findProviderClass.getInterfaces();
            for (int i = 0; i < interfaces.length; i++) {
                if (interfaces[i].getName().equals("org.w3c.dom.xpath.XPathEvaluator")) {
                    this.fXPathEvaluator = constructor.newInstance(new Object[]{this});
                    return this.fXPathEvaluator;
                }
            }
            return null;
        } catch (Exception e) {
            Exception exc = e;
            return null;
        }
    }

    public Element getIdentifier(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.identifiers == null) {
            return null;
        }
        Element element = (Element) this.identifiers.get(str2);
        if (element != null) {
            Node parentNode = element.getParentNode();
            while (true) {
                Node node = parentNode;
                if (node == null) {
                    break;
                } else if (node == this) {
                    return element;
                } else {
                    parentNode = node.getParentNode();
                }
            }
        }
        return null;
    }

    public Enumeration getIdentifiers() {
        Hashtable hashtable;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.identifiers == null) {
            new Hashtable();
            this.identifiers = hashtable;
        }
        return this.identifiers.keys();
    }

    public DOMImplementation getImplementation() {
        return CoreDOMImplementationImpl.getDOMImplementation();
    }

    public String getInputEncoding() {
        return this.actualEncoding;
    }

    /* access modifiers changed from: package-private */
    public boolean getMutationEvents() {
        return false;
    }

    /* access modifiers changed from: package-private */
    public NodeListCache getNodeListCache(ParentNode parentNode) {
        NodeListCache nodeListCache;
        ParentNode parentNode2 = parentNode;
        if (this.fFreeNLCache == null) {
            new NodeListCache(parentNode2);
            return nodeListCache;
        }
        NodeListCache nodeListCache2 = this.fFreeNLCache;
        this.fFreeNLCache = this.fFreeNLCache.next;
        nodeListCache2.fChild = null;
        nodeListCache2.fChildIndex = -1;
        nodeListCache2.fLength = -1;
        if (nodeListCache2.fOwner != null) {
            nodeListCache2.fOwner.fNodeListCache = null;
        }
        nodeListCache2.fOwner = parentNode2;
        return nodeListCache2;
    }

    public String getNodeName() {
        return "#document";
    }

    /* access modifiers changed from: protected */
    public int getNodeNumber() {
        if (this.documentNumber == 0) {
            this.documentNumber = ((CoreDOMImplementationImpl) CoreDOMImplementationImpl.getDOMImplementation()).assignDocumentNumber();
        }
        return this.documentNumber;
    }

    /* access modifiers changed from: protected */
    public int getNodeNumber(Node node) {
        int intValue;
        Object obj;
        Map map;
        Object obj2;
        Node node2 = node;
        if (this.nodeTable == null) {
            new WeakHashMap();
            this.nodeTable = map;
            int i = this.nodeCounter - 1;
            int i2 = i;
            this.nodeCounter = i2;
            intValue = i;
            new Integer(intValue);
            Object put = this.nodeTable.put(node2, obj2);
        } else {
            Integer num = (Integer) this.nodeTable.get(node2);
            if (num == null) {
                int i3 = this.nodeCounter - 1;
                int i4 = i3;
                this.nodeCounter = i4;
                intValue = i3;
                new Integer(intValue);
                Object put2 = this.nodeTable.put(node2, obj);
            } else {
                intValue = num.intValue();
            }
        }
        return intValue;
    }

    public short getNodeType() {
        return 9;
    }

    public final Document getOwnerDocument() {
        return null;
    }

    public boolean getStandalone() {
        return getXmlStandalone();
    }

    public boolean getStrictErrorChecking() {
        return this.errorChecking;
    }

    public String getTextContent() throws DOMException {
        return null;
    }

    /* access modifiers changed from: protected */
    public Object getUserData(NodeImpl nodeImpl) {
        return getUserData(nodeImpl, "XERCES1DOMUSERDATA");
    }

    public Object getUserData(Node node, String str) {
        Node node2 = node;
        String str2 = str;
        if (this.userData == null) {
            return null;
        }
        Hashtable hashtable = (Hashtable) this.userData.get(node2);
        if (hashtable == null) {
            return null;
        }
        Object obj = hashtable.get(str2);
        if (obj != null) {
            return ((ParentNode.UserDataRecord) obj).fData;
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public Hashtable getUserDataRecord(Node node) {
        Node node2 = node;
        if (this.userData == null) {
            return null;
        }
        Hashtable hashtable = (Hashtable) this.userData.get(node2);
        if (hashtable == null) {
            return null;
        }
        return hashtable;
    }

    public String getVersion() {
        return getXmlVersion();
    }

    public String getXmlEncoding() {
        return this.encoding;
    }

    public boolean getXmlStandalone() {
        return this.standalone;
    }

    public String getXmlVersion() {
        return this.version == null ? BuildConfig.VERSION_NAME : this.version;
    }

    public Node importNode(Node node, boolean z) throws DOMException {
        return importNode(node, z, false, (HashMap) null);
    }

    public Node insertBefore(Node node, Node node2) throws DOMException {
        Throwable th;
        Node node3 = node;
        Node node4 = node2;
        short nodeType = node3.getNodeType();
        if (this.errorChecking) {
            if (needsSyncChildren()) {
                synchronizeChildren();
            }
            if ((nodeType == 1 && this.docElement != null) || (nodeType == 10 && this.docType != null)) {
                Throwable th2 = th;
                new DOMException(3, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "HIERARCHY_REQUEST_ERR", (Object[]) null));
                throw th2;
            }
        }
        if (node3.getOwnerDocument() == null && (node3 instanceof DocumentTypeImpl)) {
            ((DocumentTypeImpl) node3).ownerDocument = this;
        }
        Node insertBefore = super.insertBefore(node3, node4);
        if (nodeType == 1) {
            this.docElement = (ElementImpl) node3;
        } else if (nodeType == 10) {
            this.docType = (DocumentTypeImpl) node3;
        }
        return node3;
    }

    /* access modifiers changed from: package-private */
    public void insertedNode(NodeImpl nodeImpl, NodeImpl nodeImpl2, boolean z) {
    }

    /* access modifiers changed from: package-private */
    public void insertedText(CharacterDataImpl characterDataImpl, int i, int i2) {
    }

    /* access modifiers changed from: package-private */
    public void insertingNode(NodeImpl nodeImpl, boolean z) {
    }

    /* access modifiers changed from: protected */
    public boolean isKidOK(Node node, Node node2) {
        Node node3 = node;
        Node node4 = node2;
        if (!this.allowGrammarAccess || node3.getNodeType() != 10) {
            return 0 != (kidOK[node3.getNodeType()] & (1 << node4.getNodeType()));
        }
        return node4.getNodeType() == 1;
    }

    /* access modifiers changed from: package-private */
    public boolean isNormalizeDocRequired() {
        return true;
    }

    /* access modifiers changed from: package-private */
    public boolean isXML11Version() {
        return this.xml11Version;
    }

    /* access modifiers changed from: package-private */
    public boolean isXMLVersionChanged() {
        return this.xmlVersionChanged;
    }

    public boolean load(String str) {
        String str2 = str;
        return false;
    }

    public boolean loadXML(String str) {
        String str2 = str;
        return false;
    }

    /* access modifiers changed from: package-private */
    public void modifiedAttrValue(AttrImpl attrImpl, String str) {
    }

    /* access modifiers changed from: package-private */
    public void modifiedCharacterData(NodeImpl nodeImpl, String str, String str2, boolean z) {
    }

    /* access modifiers changed from: package-private */
    public void modifyingCharacterData(NodeImpl nodeImpl, boolean z) {
    }

    public void normalizeDocument() {
        DOMConfigurationImpl dOMConfigurationImpl;
        DOMNormalizer dOMNormalizer;
        if (!isNormalized() || isNormalizeDocRequired()) {
            if (needsSyncChildren()) {
                synchronizeChildren();
            }
            if (this.domNormalizer == null) {
                new DOMNormalizer();
                this.domNormalizer = dOMNormalizer;
            }
            if (this.fConfiguration == null) {
                new DOMConfigurationImpl();
                this.fConfiguration = dOMConfigurationImpl;
            } else {
                this.fConfiguration.reset();
            }
            this.domNormalizer.normalizeDocument(this, this.fConfiguration);
            isNormalized(true);
            this.xmlVersionChanged = false;
        }
    }

    public void putIdentifier(String str, Element element) {
        Hashtable hashtable;
        String str2 = str;
        Element element2 = element;
        if (element2 == null) {
            removeIdentifier(str2);
            return;
        }
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.identifiers == null) {
            new Hashtable();
            this.identifiers = hashtable;
        }
        Object put = this.identifiers.put(str2, element2);
    }

    public Node removeChild(Node node) throws DOMException {
        Node node2 = node;
        Node removeChild = super.removeChild(node2);
        short nodeType = node2.getNodeType();
        if (nodeType == 1) {
            this.docElement = null;
        } else if (nodeType == 10) {
            this.docType = null;
        }
        return node2;
    }

    /* access modifiers changed from: protected */
    public void removeEventListener(NodeImpl nodeImpl, String str, EventListener eventListener, boolean z) {
    }

    public void removeIdentifier(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.identifiers != null) {
            Object remove = this.identifiers.remove(str2);
        }
    }

    /* access modifiers changed from: package-private */
    public Hashtable removeUserDataTable(Node node) {
        Node node2 = node;
        if (this.userData == null) {
            return null;
        }
        return (Hashtable) this.userData.get(node2);
    }

    /* access modifiers changed from: package-private */
    public void removedAttrNode(AttrImpl attrImpl, NodeImpl nodeImpl, String str) {
    }

    /* access modifiers changed from: package-private */
    public void removedNode(NodeImpl nodeImpl, boolean z) {
    }

    /* access modifiers changed from: package-private */
    public void removingNode(NodeImpl nodeImpl, NodeImpl nodeImpl2, boolean z) {
    }

    /* JADX WARNING: type inference failed for: r15v0, types: [org.w3c.dom.Node] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public org.w3c.dom.Node renameNode(org.w3c.dom.Node r15, java.lang.String r16, java.lang.String r17) throws org.w3c.dom.DOMException {
        /*
            r14 = this;
            r0 = r14
            r1 = r15
            r2 = r16
            r3 = r17
            r9 = r0
            boolean r9 = r9.errorChecking
            if (r9 == 0) goto L_0x002e
            r9 = r1
            org.w3c.dom.Document r9 = r9.getOwnerDocument()
            r10 = r0
            if (r9 == r10) goto L_0x002e
            r9 = r1
            r10 = r0
            if (r9 == r10) goto L_0x002e
            java.lang.String r9 = "http://www.w3.org/dom/DOMTR"
            java.lang.String r10 = "WRONG_DOCUMENT_ERR"
            r11 = 0
            java.lang.String r9 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r9, r10, r11)
            r4 = r9
            org.w3c.dom.DOMException r9 = new org.w3c.dom.DOMException
            r13 = r9
            r9 = r13
            r10 = r13
            r11 = 4
            r12 = r4
            r10.<init>(r11, r12)
            throw r9
        L_0x002e:
            r9 = r1
            short r9 = r9.getNodeType()
            switch(r9) {
                case 1: goto L_0x004e;
                case 2: goto L_0x00a9;
                default: goto L_0x0036;
            }
        L_0x0036:
            java.lang.String r9 = "http://www.w3.org/dom/DOMTR"
            java.lang.String r10 = "NOT_SUPPORTED_ERR"
            r11 = 0
            java.lang.String r9 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r9, r10, r11)
            r4 = r9
            org.w3c.dom.DOMException r9 = new org.w3c.dom.DOMException
            r13 = r9
            r9 = r13
            r10 = r13
            r11 = 9
            r12 = r4
            r10.<init>(r11, r12)
            throw r9
        L_0x004e:
            r9 = r1
            org.apache.xerces.dom.ElementImpl r9 = (org.apache.xerces.dom.ElementImpl) r9
            r4 = r9
            r9 = r4
            boolean r9 = r9 instanceof org.apache.xerces.dom.ElementNSImpl
            if (r9 == 0) goto L_0x0085
            r9 = r0
            r10 = r2
            r11 = r3
            r12 = r4
            boolean r9 = r9.canRenameElements(r10, r11, r12)
            if (r9 == 0) goto L_0x007b
            r9 = r4
            org.apache.xerces.dom.ElementNSImpl r9 = (org.apache.xerces.dom.ElementNSImpl) r9
            r10 = r2
            r11 = r3
            r9.rename(r10, r11)
            r9 = r0
            r10 = r4
            r11 = 0
            r12 = 4
            r9.callUserDataHandlers(r10, r11, r12)
        L_0x0070:
            r9 = r0
            r10 = r1
            org.w3c.dom.Element r10 = (org.w3c.dom.Element) r10
            r11 = r4
            r9.renamedElement(r10, r11)
            r9 = r4
            r0 = r9
        L_0x007a:
            return r0
        L_0x007b:
            r9 = r0
            r10 = r4
            r11 = r2
            r12 = r3
            org.apache.xerces.dom.ElementImpl r9 = r9.replaceRenameElement(r10, r11, r12)
            r4 = r9
            goto L_0x0070
        L_0x0085:
            r9 = r2
            if (r9 != 0) goto L_0x009f
            r9 = r0
            r10 = 0
            r11 = r3
            r12 = r4
            boolean r9 = r9.canRenameElements(r10, r11, r12)
            if (r9 == 0) goto L_0x009f
            r9 = r4
            r10 = r3
            r9.rename(r10)
            r9 = r0
            r10 = r4
            r11 = 0
            r12 = 4
            r9.callUserDataHandlers(r10, r11, r12)
            goto L_0x0070
        L_0x009f:
            r9 = r0
            r10 = r4
            r11 = r2
            r12 = r3
            org.apache.xerces.dom.ElementImpl r9 = r9.replaceRenameElement(r10, r11, r12)
            r4 = r9
            goto L_0x0070
        L_0x00a9:
            r9 = r1
            org.apache.xerces.dom.AttrImpl r9 = (org.apache.xerces.dom.AttrImpl) r9
            r4 = r9
            r9 = r4
            org.w3c.dom.Element r9 = r9.getOwnerElement()
            r5 = r9
            r9 = r5
            if (r9 == 0) goto L_0x00bc
            r9 = r5
            r10 = r4
            org.w3c.dom.Attr r9 = r9.removeAttributeNode(r10)
        L_0x00bc:
            r9 = r1
            boolean r9 = r9 instanceof org.apache.xerces.dom.AttrNSImpl
            if (r9 == 0) goto L_0x00e4
            r9 = r4
            org.apache.xerces.dom.AttrNSImpl r9 = (org.apache.xerces.dom.AttrNSImpl) r9
            r10 = r2
            r11 = r3
            r9.rename(r10, r11)
            r9 = r5
            if (r9 == 0) goto L_0x00d2
            r9 = r5
            r10 = r4
            org.w3c.dom.Attr r9 = r9.setAttributeNodeNS(r10)
        L_0x00d2:
            r9 = r0
            r10 = r4
            r11 = 0
            r12 = 4
            r9.callUserDataHandlers(r10, r11, r12)
        L_0x00d9:
            r9 = r0
            r10 = r1
            org.w3c.dom.Attr r10 = (org.w3c.dom.Attr) r10
            r11 = r4
            r9.renamedAttrNode(r10, r11)
            r9 = r4
            r0 = r9
            goto L_0x007a
        L_0x00e4:
            r9 = r2
            if (r9 != 0) goto L_0x00fd
            r9 = r4
            r10 = r3
            r9.rename(r10)
            r9 = r5
            if (r9 == 0) goto L_0x00f5
            r9 = r5
            r10 = r4
            org.w3c.dom.Attr r9 = r9.setAttributeNode(r10)
        L_0x00f5:
            r9 = r0
            r10 = r4
            r11 = 0
            r12 = 4
            r9.callUserDataHandlers(r10, r11, r12)
            goto L_0x00d9
        L_0x00fd:
            r9 = r0
            r10 = r2
            r11 = r3
            org.w3c.dom.Attr r9 = r9.createAttributeNS(r10, r11)
            org.apache.xerces.dom.AttrNSImpl r9 = (org.apache.xerces.dom.AttrNSImpl) r9
            r6 = r9
            r9 = r0
            r10 = r4
            r11 = r6
            r9.copyEventListeners(r10, r11)
            r9 = r0
            r10 = r4
            java.util.Hashtable r9 = r9.removeUserDataTable(r10)
            r7 = r9
            r9 = r4
            org.w3c.dom.Node r9 = r9.getFirstChild()
            r8 = r9
        L_0x011a:
            r9 = r8
            if (r9 != 0) goto L_0x0136
            r9 = r0
            r10 = r6
            r11 = r7
            r9.setUserDataTable(r10, r11)
            r9 = r0
            r10 = r4
            r11 = r6
            r12 = 4
            r9.callUserDataHandlers(r10, r11, r12)
            r9 = r5
            if (r9 == 0) goto L_0x0133
            r9 = r5
            r10 = r6
            org.w3c.dom.Attr r9 = r9.setAttributeNode(r10)
        L_0x0133:
            r9 = r6
            r4 = r9
            goto L_0x00d9
        L_0x0136:
            r9 = r4
            r10 = r8
            org.w3c.dom.Node r9 = r9.removeChild(r10)
            r9 = r6
            r10 = r8
            org.w3c.dom.Node r9 = r9.appendChild(r10)
            r9 = r4
            org.w3c.dom.Node r9 = r9.getFirstChild()
            r8 = r9
            goto L_0x011a
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.CoreDocumentImpl.renameNode(org.w3c.dom.Node, java.lang.String, java.lang.String):org.w3c.dom.Node");
    }

    /* access modifiers changed from: package-private */
    public void renamedAttrNode(Attr attr, Attr attr2) {
    }

    /* access modifiers changed from: package-private */
    public void renamedElement(Element element, Element element2) {
    }

    public Node replaceChild(Node node, Node node2) throws DOMException {
        Throwable th;
        Node node3 = node;
        Node node4 = node2;
        if (node3.getOwnerDocument() == null && (node3 instanceof DocumentTypeImpl)) {
            ((DocumentTypeImpl) node3).ownerDocument = this;
        }
        if (!this.errorChecking || ((this.docType == null || node4.getNodeType() == 10 || node3.getNodeType() != 10) && (this.docElement == null || node4.getNodeType() == 1 || node3.getNodeType() != 1))) {
            Node replaceChild = super.replaceChild(node3, node4);
            short nodeType = node4.getNodeType();
            if (nodeType == 1) {
                this.docElement = (ElementImpl) node3;
            } else if (nodeType == 10) {
                this.docType = (DocumentTypeImpl) node3;
            }
            return node4;
        }
        Throwable th2 = th;
        new DOMException(3, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "HIERARCHY_REQUEST_ERR", (Object[]) null));
        throw th2;
    }

    /* access modifiers changed from: package-private */
    public void replacedCharacterData(NodeImpl nodeImpl, String str, String str2) {
    }

    /* access modifiers changed from: package-private */
    public void replacedNode(NodeImpl nodeImpl) {
    }

    /* access modifiers changed from: package-private */
    public void replacedText(CharacterDataImpl characterDataImpl) {
    }

    /* access modifiers changed from: package-private */
    public void replacingData(NodeImpl nodeImpl) {
    }

    /* access modifiers changed from: package-private */
    public void replacingNode(NodeImpl nodeImpl) {
    }

    /* JADX WARNING: type inference failed for: r10v0, types: [org.w3c.dom.Node] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String saveXML(org.w3c.dom.Node r10) throws org.w3c.dom.DOMException {
        /*
            r9 = this;
            r0 = r9
            r1 = r10
            r4 = r0
            boolean r4 = r4.errorChecking
            if (r4 == 0) goto L_0x0029
            r4 = r1
            if (r4 == 0) goto L_0x0029
            r4 = r0
            r5 = r1
            org.w3c.dom.Document r5 = r5.getOwnerDocument()
            if (r4 == r5) goto L_0x0029
            java.lang.String r4 = "http://www.w3.org/dom/DOMTR"
            java.lang.String r5 = "WRONG_DOCUMENT_ERR"
            r6 = 0
            java.lang.String r4 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r4, r5, r6)
            r2 = r4
            org.w3c.dom.DOMException r4 = new org.w3c.dom.DOMException
            r8 = r4
            r4 = r8
            r5 = r8
            r6 = 4
            r7 = r2
            r5.<init>(r6, r7)
            throw r4
        L_0x0029:
            org.w3c.dom.DOMImplementation r4 = org.apache.xerces.dom.DOMImplementationImpl.getDOMImplementation()
            org.w3c.dom.ls.DOMImplementationLS r4 = (org.w3c.dom.ls.DOMImplementationLS) r4
            r2 = r4
            r4 = r2
            org.w3c.dom.ls.LSSerializer r4 = r4.createLSSerializer()
            r3 = r4
            r4 = r1
            if (r4 != 0) goto L_0x003b
            r4 = r0
            r1 = r4
        L_0x003b:
            r4 = r3
            r5 = r1
            java.lang.String r4 = r4.writeToString(r5)
            r0 = r4
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.CoreDocumentImpl.saveXML(org.w3c.dom.Node):java.lang.String");
    }

    public void setAsync(boolean z) {
        Throwable th;
        if (z) {
            Throwable th2 = th;
            new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
            throw th2;
        }
    }

    /* access modifiers changed from: package-private */
    public void setAttrNode(AttrImpl attrImpl, AttrImpl attrImpl2) {
    }

    public void setDocumentURI(String str) {
        String str2 = str;
        this.fDocumentURI = str2;
    }

    public void setEncoding(String str) {
        setXmlEncoding(str);
    }

    public void setErrorChecking(boolean z) {
        boolean z2 = z;
        this.errorChecking = z2;
    }

    public void setInputEncoding(String str) {
        String str2 = str;
        this.actualEncoding = str2;
    }

    /* access modifiers changed from: package-private */
    public void setMutationEvents(boolean z) {
    }

    public void setStandalone(boolean z) {
        setXmlStandalone(z);
    }

    public void setStrictErrorChecking(boolean z) {
        boolean z2 = z;
        this.errorChecking = z2;
    }

    public void setTextContent(String str) throws DOMException {
    }

    public Object setUserData(Node node, String str, Object obj, UserDataHandler userDataHandler) {
        Hashtable hashtable;
        Hashtable hashtable2;
        Object obj2;
        Map map;
        Hashtable hashtable3;
        Hashtable hashtable4;
        Object remove;
        Node node2 = node;
        String str2 = str;
        Object obj3 = obj;
        UserDataHandler userDataHandler2 = userDataHandler;
        if (obj3 != null) {
            if (this.userData == null) {
                new WeakHashMap();
                this.userData = map;
                new Hashtable();
                hashtable = hashtable3;
                Object put = this.userData.put(node2, hashtable);
            } else {
                hashtable = (Hashtable) this.userData.get(node2);
                if (hashtable == null) {
                    new Hashtable();
                    hashtable = hashtable2;
                    Object put2 = this.userData.put(node2, hashtable);
                }
            }
            new ParentNode.UserDataRecord(this, obj3, userDataHandler2);
            Object put3 = hashtable.put(str2, obj2);
            if (put3 != null) {
                return ((ParentNode.UserDataRecord) put3).fData;
            }
            return null;
        } else if (this.userData == null || (hashtable4 = (Hashtable) this.userData.get(node2)) == null || (remove = hashtable4.remove(str2)) == null) {
            return null;
        } else {
            return ((ParentNode.UserDataRecord) remove).fData;
        }
    }

    /* access modifiers changed from: protected */
    public void setUserData(NodeImpl nodeImpl, Object obj) {
        Object userData2 = setUserData(nodeImpl, "XERCES1DOMUSERDATA", obj, (UserDataHandler) null);
    }

    /* access modifiers changed from: package-private */
    public void setUserDataTable(Node node, Hashtable hashtable) {
        Map map;
        Node node2 = node;
        Hashtable hashtable2 = hashtable;
        if (this.userData == null) {
            new WeakHashMap();
            this.userData = map;
        }
        if (hashtable2 != null) {
            Object put = this.userData.put(node2, hashtable2);
        }
    }

    public void setVersion(String str) {
        setXmlVersion(str);
    }

    public void setXmlEncoding(String str) {
        String str2 = str;
        this.encoding = str2;
    }

    public void setXmlStandalone(boolean z) throws DOMException {
        boolean z2 = z;
        this.standalone = z2;
    }

    public void setXmlVersion(String str) {
        Throwable th;
        String str2 = str;
        if (str2.equals(BuildConfig.VERSION_NAME) || str2.equals("1.1")) {
            if (!getXmlVersion().equals(str2)) {
                this.xmlVersionChanged = true;
                isNormalized(false);
                this.version = str2;
            }
            if (getXmlVersion().equals("1.1")) {
                this.xml11Version = true;
            } else {
                this.xml11Version = false;
            }
        } else {
            Throwable th2 = th;
            new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
            throw th2;
        }
    }

    /* access modifiers changed from: protected */
    public void undeferChildren(Node node) {
        Node node2 = node;
        Node node3 = node2;
        while (null != node2) {
            if (((NodeImpl) node2).needsSyncData()) {
                ((NodeImpl) node2).synchronizeData();
            }
            NamedNodeMap attributes = node2.getAttributes();
            if (attributes != null) {
                int length = attributes.getLength();
                for (int i = 0; i < length; i++) {
                    undeferChildren(attributes.item(i));
                }
            }
            Node firstChild = node2.getFirstChild();
            while (true) {
                if (null != firstChild || node3.equals(node2)) {
                    break;
                }
                firstChild = node2.getNextSibling();
                if (null == firstChild) {
                    node2 = node2.getParentNode();
                    if (null == node2 || node3.equals(node2)) {
                        firstChild = null;
                    }
                }
            }
            node2 = firstChild;
        }
    }
}
