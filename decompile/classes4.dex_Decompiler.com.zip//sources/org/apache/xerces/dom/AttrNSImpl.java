package org.apache.xerces.dom;

import com.microsoft.appcenter.Constants;
import org.apache.xerces.impl.dv.xs.XSSimpleTypeDecl;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.grammars.XMLGrammarDescription;
import org.apache.xml.serialize.Method;
import org.w3c.dom.DOMException;

public class AttrNSImpl extends AttrImpl {
    static final long serialVersionUID = -781906615369795414L;
    static final String xmlURI = "http://www.w3.org/XML/1998/namespace";
    static final String xmlnsURI = "http://www.w3.org/2000/xmlns/";
    protected String localName;
    protected String namespaceURI;

    public AttrNSImpl() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected AttrNSImpl(CoreDocumentImpl coreDocumentImpl, String str) {
        super(coreDocumentImpl, str);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected AttrNSImpl(org.apache.xerces.dom.CoreDocumentImpl r8, java.lang.String r9, java.lang.String r10) {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r2 = r9
            r3 = r10
            r4 = r0
            r5 = r1
            r6 = r3
            r4.<init>(r5, r6)
            r4 = r0
            r5 = r2
            r6 = r3
            r4.setName(r5, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.AttrNSImpl.<init>(org.apache.xerces.dom.CoreDocumentImpl, java.lang.String, java.lang.String):void");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AttrNSImpl(CoreDocumentImpl coreDocumentImpl, String str, String str2, String str3) {
        super(coreDocumentImpl, str2);
        this.localName = str3;
        this.namespaceURI = str;
    }

    private void setName(String str, String str2) {
        Throwable th;
        String str3 = str;
        String str4 = str2;
        CoreDocumentImpl ownerDocument = ownerDocument();
        this.namespaceURI = str3;
        if (str3 != null) {
            this.namespaceURI = str3.length() == 0 ? null : str3;
        }
        int indexOf = str4.indexOf(58);
        int lastIndexOf = str4.lastIndexOf(58);
        ownerDocument.checkNamespaceWF(str4, indexOf, lastIndexOf);
        if (indexOf < 0) {
            this.localName = str4;
            if (ownerDocument.errorChecking) {
                ownerDocument.checkQName((String) null, this.localName);
                if ((str4.equals("xmlns") && (str3 == null || !str3.equals(NamespaceContext.XMLNS_URI))) || (str3 != null && str3.equals(NamespaceContext.XMLNS_URI) && !str4.equals("xmlns"))) {
                    Throwable th2 = th;
                    new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
                    throw th2;
                }
                return;
            }
            return;
        }
        String substring = str4.substring(0, indexOf);
        this.localName = str4.substring(lastIndexOf + 1);
        ownerDocument.checkQName(substring, this.localName);
        ownerDocument.checkDOMNSErr(substring, str3);
    }

    public String getLocalName() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.localName;
    }

    public String getNamespaceURI() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.namespaceURI;
    }

    public String getPrefix() {
        if (needsSyncData()) {
            synchronizeData();
        }
        int indexOf = this.name.indexOf(58);
        return indexOf < 0 ? null : this.name.substring(0, indexOf);
    }

    public String getTypeName() {
        if (this.type != null) {
            return this.type instanceof XSSimpleTypeDecl ? ((XSSimpleTypeDecl) this.type).getName() : (String) this.type;
        }
        return null;
    }

    public String getTypeNamespace() {
        if (this.type != null) {
            return this.type instanceof XSSimpleTypeDecl ? ((XSSimpleTypeDecl) this.type).getNamespace() : XMLGrammarDescription.XML_DTD;
        }
        return null;
    }

    public boolean isDerivedFrom(String str, String str2, int i) {
        String str3 = str;
        String str4 = str2;
        int i2 = i;
        if (this.type == null || !(this.type instanceof XSSimpleTypeDecl)) {
            return false;
        }
        return ((XSSimpleTypeDecl) this.type).isDOMDerivedFrom(str3, str4, i2);
    }

    /* access modifiers changed from: package-private */
    public void rename(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        if (needsSyncData()) {
            synchronizeData();
        }
        this.name = str4;
        setName(str3, str4);
    }

    public void setPrefix(String str) throws DOMException {
        StringBuffer stringBuffer;
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        Throwable th6;
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (ownerDocument().errorChecking) {
            if (isReadOnly()) {
                Throwable th7 = th6;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th7;
            } else if (!(str2 == null || str2.length() == 0)) {
                if (!CoreDocumentImpl.isXMLName(str2, ownerDocument().isXML11Version())) {
                    Throwable th8 = th5;
                    new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
                    throw th8;
                } else if (this.namespaceURI == null || str2.indexOf(58) >= 0) {
                    Throwable th9 = th;
                    new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
                    throw th9;
                } else if (str2.equals("xmlns")) {
                    if (!this.namespaceURI.equals(xmlnsURI)) {
                        Throwable th10 = th4;
                        new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
                        throw th10;
                    }
                } else if (str2.equals(Method.XML)) {
                    if (!this.namespaceURI.equals(xmlURI)) {
                        Throwable th11 = th3;
                        new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
                        throw th11;
                    }
                } else if (this.name.equals("xmlns")) {
                    Throwable th12 = th2;
                    new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
                    throw th12;
                }
            }
        }
        if (str2 == null || str2.length() == 0) {
            this.name = this.localName;
            return;
        }
        new StringBuffer();
        this.name = stringBuffer.append(str2).append(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR).append(this.localName).toString();
    }
}
