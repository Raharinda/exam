package org.apache.xerces.dom;

import java.util.ArrayList;
import org.apache.xerces.dom3.as.ASContentModel;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DeepNodeListImpl implements NodeList {
    protected int changes;
    protected boolean enableNS;
    protected ArrayList nodes;
    protected String nsName;
    protected NodeImpl rootNode;
    protected String tagName;

    public DeepNodeListImpl(NodeImpl nodeImpl, String str) {
        ArrayList arrayList;
        this.changes = 0;
        this.enableNS = false;
        this.rootNode = nodeImpl;
        this.tagName = str;
        new ArrayList();
        this.nodes = arrayList;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DeepNodeListImpl(NodeImpl nodeImpl, String str, String str2) {
        this(nodeImpl, str2);
        String str3 = str;
        this.nsName = (str3 == null || str3.length() == 0) ? null : str3;
        this.enableNS = true;
    }

    public int getLength() {
        Node item = item(ASContentModel.AS_UNBOUNDED);
        return this.nodes.size();
    }

    public Node item(int i) {
        ArrayList arrayList;
        int i2 = i;
        if (this.rootNode.changes() != this.changes) {
            new ArrayList();
            this.nodes = arrayList;
            this.changes = this.rootNode.changes();
        }
        int size = this.nodes.size();
        if (i2 < size) {
            return (Node) this.nodes.get(i2);
        }
        NodeImpl nodeImpl = size == 0 ? this.rootNode : (NodeImpl) this.nodes.get(size - 1);
        while (nodeImpl != null && i2 >= this.nodes.size()) {
            nodeImpl = nextMatchingElementAfter(nodeImpl);
            if (nodeImpl != null) {
                boolean add = this.nodes.add(nodeImpl);
            }
        }
        return nodeImpl;
    }

    /* access modifiers changed from: protected */
    public Node nextMatchingElementAfter(Node node) {
        ElementImpl elementImpl = node;
        while (elementImpl != null) {
            if (elementImpl.hasChildNodes()) {
                elementImpl = elementImpl.getFirstChild();
            } else {
                if (elementImpl != this.rootNode) {
                    Node nextSibling = elementImpl.getNextSibling();
                    Node node2 = nextSibling;
                    if (null != nextSibling) {
                        elementImpl = node2;
                    }
                }
                ElementImpl elementImpl2 = null;
                while (elementImpl != this.rootNode) {
                    elementImpl2 = elementImpl.getNextSibling();
                    if (elementImpl2 != null) {
                        break;
                    }
                    elementImpl = elementImpl.getParentNode();
                }
                elementImpl = elementImpl2;
            }
            if (!(elementImpl == this.rootNode || elementImpl == null || elementImpl.getNodeType() != 1)) {
                if (!this.enableNS) {
                    if (this.tagName.equals("*") || elementImpl.getTagName().equals(this.tagName)) {
                        return elementImpl;
                    }
                } else if (!this.tagName.equals("*")) {
                    ElementImpl elementImpl3 = elementImpl;
                    if (elementImpl3.getLocalName() != null && elementImpl3.getLocalName().equals(this.tagName)) {
                        if (this.nsName != null && this.nsName.equals("*")) {
                            return elementImpl;
                        }
                        if ((this.nsName == null && elementImpl3.getNamespaceURI() == null) || (this.nsName != null && this.nsName.equals(elementImpl3.getNamespaceURI()))) {
                            return elementImpl;
                        }
                    }
                } else if (this.nsName != null && this.nsName.equals("*")) {
                    return elementImpl;
                } else {
                    ElementImpl elementImpl4 = elementImpl;
                    if ((this.nsName == null && elementImpl4.getNamespaceURI() == null) || (this.nsName != null && this.nsName.equals(elementImpl4.getNamespaceURI()))) {
                        return elementImpl;
                    }
                }
            }
        }
        return null;
    }
}
