package org.apache.xerces.dom;

import org.w3c.dom.CDATASection;

public class CDATASectionImpl extends TextImpl implements CDATASection {
    static final long serialVersionUID = 2372071297878177780L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CDATASectionImpl(CoreDocumentImpl coreDocumentImpl, String str) {
        super(coreDocumentImpl, str);
    }

    public String getNodeName() {
        return "#cdata-section";
    }

    public short getNodeType() {
        return 4;
    }
}
