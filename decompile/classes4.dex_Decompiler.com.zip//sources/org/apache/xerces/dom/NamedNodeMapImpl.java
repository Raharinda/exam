package org.apache.xerces.dom;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import org.w3c.dom.DOMException;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class NamedNodeMapImpl implements NamedNodeMap, Serializable {
    protected static final short CHANGED = 2;
    protected static final short HASDEFAULTS = 4;
    protected static final short READONLY = 1;
    static final long serialVersionUID = -7039242451046758020L;
    protected short flags;
    protected List nodes;
    protected NodeImpl ownerNode;

    protected NamedNodeMapImpl(NodeImpl nodeImpl) {
        this.ownerNode = nodeImpl;
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        List list;
        objectInputStream.defaultReadObject();
        if (this.nodes != null) {
            new ArrayList((Vector) this.nodes);
            this.nodes = list;
        }
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        List list;
        ObjectOutputStream objectOutputStream2 = objectOutputStream;
        List list2 = this.nodes;
        if (list2 != null) {
            try {
                new Vector(list2);
                this.nodes = list;
            } catch (Throwable th) {
                Throwable th2 = th;
                this.nodes = list2;
                throw th2;
            }
        }
        objectOutputStream2.defaultWriteObject();
        this.nodes = list2;
    }

    /* access modifiers changed from: protected */
    public int addItem(Node node) {
        List list;
        Node node2 = node;
        int findNamePoint = findNamePoint(node2.getNamespaceURI(), node2.getLocalName());
        if (findNamePoint >= 0) {
            Object obj = this.nodes.set(findNamePoint, node2);
        } else {
            findNamePoint = findNamePoint(node2.getNodeName(), 0);
            if (findNamePoint >= 0) {
                this.nodes.add(findNamePoint, node2);
            } else {
                findNamePoint = -1 - findNamePoint;
                if (null == this.nodes) {
                    new ArrayList(5);
                    this.nodes = list;
                }
                this.nodes.add(findNamePoint, node2);
            }
        }
        return findNamePoint;
    }

    /* access modifiers changed from: package-private */
    public final void changed(boolean z) {
        this.flags = z ? (short) (this.flags | 2) : (short) (this.flags & -3);
    }

    /* access modifiers changed from: package-private */
    public final boolean changed() {
        return (this.flags & 2) != 0;
    }

    /* access modifiers changed from: protected */
    public void cloneContent(NamedNodeMapImpl namedNodeMapImpl) {
        int size;
        List list;
        NamedNodeMapImpl namedNodeMapImpl2 = namedNodeMapImpl;
        List list2 = namedNodeMapImpl2.nodes;
        if (list2 != null && (size = list2.size()) != 0) {
            if (this.nodes == null) {
                new ArrayList(size);
                this.nodes = list;
            } else {
                this.nodes.clear();
            }
            for (int i = 0; i < size; i++) {
                NodeImpl nodeImpl = (NodeImpl) namedNodeMapImpl2.nodes.get(i);
                NodeImpl nodeImpl2 = (NodeImpl) nodeImpl.cloneNode(true);
                nodeImpl2.isSpecified(nodeImpl.isSpecified());
                boolean add = this.nodes.add(nodeImpl2);
            }
        }
    }

    /* access modifiers changed from: protected */
    public ArrayList cloneMap(ArrayList arrayList) {
        ArrayList arrayList2;
        ArrayList arrayList3 = arrayList;
        if (arrayList3 == null) {
            new ArrayList(5);
            arrayList3 = arrayList2;
        }
        arrayList3.clear();
        if (this.nodes != null) {
            int size = this.nodes.size();
            for (int i = 0; i < size; i++) {
                boolean add = arrayList3.add(this.nodes.get(i));
            }
        }
        return arrayList3;
    }

    public NamedNodeMapImpl cloneMap(NodeImpl nodeImpl) {
        NamedNodeMapImpl namedNodeMapImpl;
        new NamedNodeMapImpl(nodeImpl);
        NamedNodeMapImpl namedNodeMapImpl2 = namedNodeMapImpl;
        namedNodeMapImpl2.cloneContent(this);
        return namedNodeMapImpl2;
    }

    /* access modifiers changed from: protected */
    public int findNamePoint(String str, int i) {
        String str2 = str;
        int i2 = i;
        int i3 = 0;
        if (this.nodes != null) {
            int i4 = i2;
            int size = this.nodes.size() - 1;
            while (i4 <= size) {
                i3 = (i4 + size) / 2;
                int compareTo = str2.compareTo(((Node) this.nodes.get(i3)).getNodeName());
                if (compareTo == 0) {
                    return i3;
                }
                if (compareTo < 0) {
                    size = i3 - 1;
                } else {
                    i4 = i3 + 1;
                }
            }
            if (i4 > i3) {
                i3 = i4;
            }
        }
        return -1 - i3;
    }

    /* access modifiers changed from: protected */
    public int findNamePoint(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        if (this.nodes == null) {
            return -1;
        }
        if (str4 == null) {
            return -1;
        }
        int size = this.nodes.size();
        for (int i = 0; i < size; i++) {
            NodeImpl nodeImpl = (NodeImpl) this.nodes.get(i);
            String namespaceURI = nodeImpl.getNamespaceURI();
            String localName = nodeImpl.getLocalName();
            if (str3 == null) {
                if (namespaceURI == null && (str4.equals(localName) || (localName == null && str4.equals(nodeImpl.getNodeName())))) {
                    return i;
                }
            } else if (str3.equals(namespaceURI) && str4.equals(localName)) {
                return i;
            }
        }
        return -1;
    }

    /* access modifiers changed from: protected */
    public Object getItem(int i) {
        int i2 = i;
        if (this.nodes != null) {
            return this.nodes.get(i2);
        }
        return null;
    }

    public int getLength() {
        return this.nodes != null ? this.nodes.size() : 0;
    }

    public Node getNamedItem(String str) {
        int findNamePoint = findNamePoint(str, 0);
        return findNamePoint < 0 ? null : (Node) this.nodes.get(findNamePoint);
    }

    /* access modifiers changed from: protected */
    public int getNamedItemIndex(String str, String str2) {
        return findNamePoint(str, str2);
    }

    public Node getNamedItemNS(String str, String str2) {
        int findNamePoint = findNamePoint(str, str2);
        return findNamePoint < 0 ? null : (Node) this.nodes.get(findNamePoint);
    }

    /* access modifiers changed from: package-private */
    public boolean getReadOnly() {
        return isReadOnly();
    }

    /* access modifiers changed from: package-private */
    public final void hasDefaults(boolean z) {
        this.flags = z ? (short) (this.flags | 4) : (short) (this.flags & -5);
    }

    /* access modifiers changed from: package-private */
    public final boolean hasDefaults() {
        return (this.flags & 4) != 0;
    }

    /* access modifiers changed from: package-private */
    public final void isReadOnly(boolean z) {
        this.flags = z ? (short) (this.flags | 1) : (short) (this.flags & -2);
    }

    /* access modifiers changed from: package-private */
    public final boolean isReadOnly() {
        return (this.flags & 1) != 0;
    }

    public Node item(int i) {
        int i2 = i;
        return (this.nodes == null || i2 >= this.nodes.size()) ? null : (Node) this.nodes.get(i2);
    }

    /* access modifiers changed from: protected */
    public boolean precedes(Node node, Node node2) {
        Node node3 = node;
        Node node4 = node2;
        if (this.nodes != null) {
            int size = this.nodes.size();
            for (int i = 0; i < size; i++) {
                Node node5 = (Node) this.nodes.get(i);
                if (node5 == node3) {
                    return true;
                }
                if (node5 == node4) {
                    return false;
                }
            }
        }
        return false;
    }

    public void removeAll() {
        if (this.nodes != null) {
            this.nodes.clear();
        }
    }

    /* access modifiers changed from: protected */
    public void removeItem(int i) {
        int i2 = i;
        if (this.nodes != null && i2 < this.nodes.size()) {
            Object remove = this.nodes.remove(i2);
        }
    }

    public Node removeNamedItem(String str) throws DOMException {
        Throwable th;
        Throwable th2;
        String str2 = str;
        if (isReadOnly()) {
            Throwable th3 = th2;
            new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
            throw th3;
        }
        int findNamePoint = findNamePoint(str2, 0);
        if (findNamePoint < 0) {
            Throwable th4 = th;
            new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
            throw th4;
        }
        NodeImpl nodeImpl = (NodeImpl) this.nodes.get(findNamePoint);
        Object remove = this.nodes.remove(findNamePoint);
        return nodeImpl;
    }

    public Node removeNamedItemNS(String str, String str2) throws DOMException {
        Throwable th;
        Throwable th2;
        String str3 = str;
        String str4 = str2;
        if (isReadOnly()) {
            Throwable th3 = th2;
            new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
            throw th3;
        }
        int findNamePoint = findNamePoint(str3, str4);
        if (findNamePoint < 0) {
            Throwable th4 = th;
            new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
            throw th4;
        }
        NodeImpl nodeImpl = (NodeImpl) this.nodes.get(findNamePoint);
        Object remove = this.nodes.remove(findNamePoint);
        return nodeImpl;
    }

    public Node setNamedItem(Node node) throws DOMException {
        List list;
        Throwable th;
        Throwable th2;
        Node node2 = node;
        CoreDocumentImpl ownerDocument = this.ownerNode.ownerDocument();
        if (ownerDocument.errorChecking) {
            if (isReadOnly()) {
                Throwable th3 = th2;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th3;
            } else if (node2.getOwnerDocument() != ownerDocument) {
                Throwable th4 = th;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th4;
            }
        }
        int findNamePoint = findNamePoint(node2.getNodeName(), 0);
        NodeImpl nodeImpl = null;
        if (findNamePoint >= 0) {
            nodeImpl = (NodeImpl) this.nodes.get(findNamePoint);
            Object obj = this.nodes.set(findNamePoint, node2);
        } else {
            int i = -1 - findNamePoint;
            if (null == this.nodes) {
                new ArrayList(5);
                this.nodes = list;
            }
            this.nodes.add(i, node2);
        }
        return nodeImpl;
    }

    public Node setNamedItemNS(Node node) throws DOMException {
        List list;
        Throwable th;
        Throwable th2;
        Node node2 = node;
        CoreDocumentImpl ownerDocument = this.ownerNode.ownerDocument();
        if (ownerDocument.errorChecking) {
            if (isReadOnly()) {
                Throwable th3 = th2;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th3;
            } else if (node2.getOwnerDocument() != ownerDocument) {
                Throwable th4 = th;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th4;
            }
        }
        int findNamePoint = findNamePoint(node2.getNamespaceURI(), node2.getLocalName());
        NodeImpl nodeImpl = null;
        if (findNamePoint >= 0) {
            nodeImpl = (NodeImpl) this.nodes.get(findNamePoint);
            Object obj = this.nodes.set(findNamePoint, node2);
        } else {
            int findNamePoint2 = findNamePoint(node2.getNodeName(), 0);
            if (findNamePoint2 >= 0) {
                nodeImpl = (NodeImpl) this.nodes.get(findNamePoint2);
                this.nodes.add(findNamePoint2, node2);
            } else {
                int i = -1 - findNamePoint2;
                if (null == this.nodes) {
                    new ArrayList(5);
                    this.nodes = list;
                }
                this.nodes.add(i, node2);
            }
        }
        return nodeImpl;
    }

    /* access modifiers changed from: protected */
    public void setOwnerDocument(CoreDocumentImpl coreDocumentImpl) {
        CoreDocumentImpl coreDocumentImpl2 = coreDocumentImpl;
        if (this.nodes != null) {
            int size = this.nodes.size();
            for (int i = 0; i < size; i++) {
                ((NodeImpl) item(i)).setOwnerDocument(coreDocumentImpl2);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void setReadOnly(boolean z, boolean z2) {
        boolean z3 = z;
        boolean z4 = z2;
        isReadOnly(z3);
        if (z4 && this.nodes != null) {
            for (int size = this.nodes.size() - 1; size >= 0; size--) {
                ((NodeImpl) this.nodes.get(size)).setReadOnly(z3, z4);
            }
        }
    }
}
