package org.apache.xerces.dom;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.UserDataHandler;

public abstract class ParentNode extends ChildNode {
    static final long serialVersionUID = 2815829867152120872L;
    protected transient NodeListCache fNodeListCache = null;
    protected ChildNode firstChild = null;
    protected CoreDocumentImpl ownerDocument;

    class UserDataRecord implements Serializable {
        private static final long serialVersionUID = 3258126977134310455L;
        Object fData;
        UserDataHandler fHandler;
        private final ParentNode this$0;

        UserDataRecord(ParentNode parentNode, Object obj, UserDataHandler userDataHandler) {
            this.this$0 = parentNode;
            this.fData = obj;
            this.fHandler = userDataHandler;
        }
    }

    public ParentNode() {
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected ParentNode(org.apache.xerces.dom.CoreDocumentImpl r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r0
            r3 = r1
            r2.<init>(r3)
            r2 = r0
            r3 = 0
            r2.firstChild = r3
            r2 = r0
            r3 = 0
            r2.fNodeListCache = r3
            r2 = r0
            r3 = r1
            r2.ownerDocument = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.ParentNode.<init>(org.apache.xerces.dom.CoreDocumentImpl):void");
    }

    static int access$000(ParentNode parentNode) {
        return parentNode.nodeListGetLength();
    }

    static Node access$100(ParentNode parentNode, int i) {
        return parentNode.nodeListItem(i);
    }

    private int nodeListGetLength() {
        ChildNode childNode;
        int i;
        if (this.fNodeListCache == null) {
            if (needsSyncChildren()) {
                synchronizeChildren();
            }
            if (this.firstChild == null) {
                return 0;
            }
            if (this.firstChild == lastChild()) {
                return 1;
            }
            this.fNodeListCache = this.ownerDocument.getNodeListCache(this);
        }
        if (this.fNodeListCache.fLength == -1) {
            if (this.fNodeListCache.fChildIndex == -1 || this.fNodeListCache.fChild == null) {
                childNode = this.firstChild;
                i = 0;
            } else {
                i = this.fNodeListCache.fChildIndex;
                childNode = this.fNodeListCache.fChild;
            }
            while (childNode != null) {
                i++;
                childNode = childNode.nextSibling;
            }
            this.fNodeListCache.fLength = i;
        }
        return this.fNodeListCache.fLength;
    }

    private Node nodeListItem(int i) {
        int i2 = i;
        if (this.fNodeListCache == null) {
            if (needsSyncChildren()) {
                synchronizeChildren();
            }
            if (this.firstChild == lastChild()) {
                return i2 == 0 ? this.firstChild : null;
            }
            this.fNodeListCache = this.ownerDocument.getNodeListCache(this);
        }
        int i3 = this.fNodeListCache.fChildIndex;
        ChildNode childNode = this.fNodeListCache.fChild;
        boolean z = true;
        if (i3 != -1 && childNode != null) {
            z = false;
            if (i3 < i2) {
                while (i3 < i2 && childNode != null) {
                    i3++;
                    childNode = childNode.nextSibling;
                }
            } else if (i3 > i2) {
                while (i3 > i2 && childNode != null) {
                    i3--;
                    childNode = childNode.previousSibling();
                }
            }
        } else if (i2 < 0) {
            return null;
        } else {
            childNode = this.firstChild;
            i3 = 0;
            while (i3 < i2 && childNode != null) {
                childNode = childNode.nextSibling;
                i3++;
            }
        }
        if (z || !(childNode == this.firstChild || childNode == lastChild())) {
            this.fNodeListCache.fChildIndex = i3;
            this.fNodeListCache.fChild = childNode;
        } else {
            this.fNodeListCache.fChildIndex = -1;
            this.fNodeListCache.fChild = null;
            this.ownerDocument.freeNodeListCache(this.fNodeListCache);
        }
        return childNode;
    }

    private void readObject(ObjectInputStream objectInputStream) throws ClassNotFoundException, IOException {
        objectInputStream.defaultReadObject();
        needsSyncChildren(false);
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        ObjectOutputStream objectOutputStream2 = objectOutputStream;
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        objectOutputStream2.defaultWriteObject();
    }

    /* access modifiers changed from: package-private */
    public void checkNormalizationAfterInsert(ChildNode childNode) {
        ChildNode childNode2 = childNode;
        if (childNode2.getNodeType() == 3) {
            ChildNode previousSibling = childNode2.previousSibling();
            ChildNode childNode3 = childNode2.nextSibling;
            if ((previousSibling != null && previousSibling.getNodeType() == 3) || (childNode3 != null && childNode3.getNodeType() == 3)) {
                isNormalized(false);
            }
        } else if (!childNode2.isNormalized()) {
            isNormalized(false);
        }
    }

    /* access modifiers changed from: package-private */
    public void checkNormalizationAfterRemove(ChildNode childNode) {
        ChildNode childNode2;
        ChildNode childNode3 = childNode;
        if (childNode3 != null && childNode3.getNodeType() == 3 && (childNode2 = childNode3.nextSibling) != null && childNode2.getNodeType() == 3) {
            isNormalized(false);
        }
    }

    public Node cloneNode(boolean z) {
        boolean z2 = z;
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        ParentNode parentNode = (ParentNode) super.cloneNode(z2);
        parentNode.ownerDocument = this.ownerDocument;
        parentNode.firstChild = null;
        parentNode.fNodeListCache = null;
        if (z2) {
            ChildNode childNode = this.firstChild;
            while (true) {
                ChildNode childNode2 = childNode;
                if (childNode2 == null) {
                    break;
                }
                Node appendChild = parentNode.appendChild(childNode2.cloneNode(true));
                childNode = childNode2.nextSibling;
            }
        }
        return parentNode;
    }

    public NodeList getChildNodes() {
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        return this;
    }

    /* access modifiers changed from: protected */
    public final NodeList getChildNodesUnoptimized() {
        NodeList nodeList;
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        new NodeList(this) {
            private final ParentNode this$0;

            {
                this.this$0 = r5;
            }

            public int getLength() {
                return ParentNode.access$000(this.this$0);
            }

            public Node item(int i) {
                return ParentNode.access$100(this.this$0, i);
            }
        };
        return nodeList;
    }

    public Node getFirstChild() {
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        return this.firstChild;
    }

    public Node getLastChild() {
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        return lastChild();
    }

    public int getLength() {
        return nodeListGetLength();
    }

    public Document getOwnerDocument() {
        return this.ownerDocument;
    }

    public String getTextContent() throws DOMException {
        StringBuffer stringBuffer;
        Node firstChild2 = getFirstChild();
        if (firstChild2 == null) {
            return "";
        }
        if (firstChild2.getNextSibling() == null) {
            return hasTextContent(firstChild2) ? ((NodeImpl) firstChild2).getTextContent() : "";
        }
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        getTextContent(stringBuffer2);
        return stringBuffer2.toString();
    }

    /* access modifiers changed from: package-private */
    public void getTextContent(StringBuffer stringBuffer) throws DOMException {
        StringBuffer stringBuffer2 = stringBuffer;
        Node firstChild2 = getFirstChild();
        while (true) {
            Node node = firstChild2;
            if (node != null) {
                if (hasTextContent(node)) {
                    ((NodeImpl) node).getTextContent(stringBuffer2);
                }
                firstChild2 = node.getNextSibling();
            } else {
                return;
            }
        }
    }

    public boolean hasChildNodes() {
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        return this.firstChild != null;
    }

    /* access modifiers changed from: package-private */
    public final boolean hasTextContent(Node node) {
        Node node2 = node;
        return (node2.getNodeType() == 8 || node2.getNodeType() == 7 || (node2.getNodeType() == 3 && ((TextImpl) node2).isIgnorableWhitespace())) ? false : true;
    }

    public Node insertBefore(Node node, Node node2) throws DOMException {
        return internalInsertBefore(node, node2, false);
    }

    /* access modifiers changed from: package-private */
    public Node internalInsertBefore(Node node, Node node2, boolean z) throws DOMException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        Throwable th6;
        Node node3 = node;
        Node node4 = node2;
        boolean z2 = z;
        boolean z3 = this.ownerDocument.errorChecking;
        if (node3.getNodeType() == 11) {
            if (z3) {
                Node firstChild2 = node3.getFirstChild();
                while (true) {
                    Node node5 = firstChild2;
                    if (node5 == null) {
                        break;
                    } else if (!this.ownerDocument.isKidOK(this, node5)) {
                        Throwable th7 = th6;
                        new DOMException(3, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "HIERARCHY_REQUEST_ERR", (Object[]) null));
                        throw th7;
                    } else {
                        firstChild2 = node5.getNextSibling();
                    }
                }
            }
            while (node3.hasChildNodes()) {
                Node insertBefore = insertBefore(node3.getFirstChild(), node4);
            }
            return node3;
        } else if (node3 == node4) {
            Node nextSibling = node4.getNextSibling();
            Node removeChild = removeChild(node3);
            Node insertBefore2 = insertBefore(node3, nextSibling);
            return node3;
        } else {
            if (needsSyncChildren()) {
                synchronizeChildren();
            }
            if (z3) {
                if (isReadOnly()) {
                    Throwable th8 = th5;
                    new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                    throw th8;
                } else if (node3.getOwnerDocument() != this.ownerDocument && node3 != this.ownerDocument) {
                    Throwable th9 = th4;
                    new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                    throw th9;
                } else if (!this.ownerDocument.isKidOK(this, node3)) {
                    Throwable th10 = th3;
                    new DOMException(3, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "HIERARCHY_REQUEST_ERR", (Object[]) null));
                    throw th10;
                } else if (node4 == null || node4.getParentNode() == this) {
                    boolean z4 = true;
                    NodeImpl nodeImpl = this;
                    while (true) {
                        NodeImpl nodeImpl2 = nodeImpl;
                        if (z4 && nodeImpl2 != null) {
                            z4 = node3 != nodeImpl2;
                            nodeImpl = nodeImpl2.parentNode();
                        }
                    }
                    if (!z4) {
                        Throwable th11 = th;
                        new DOMException(3, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "HIERARCHY_REQUEST_ERR", (Object[]) null));
                        throw th11;
                    }
                } else {
                    Throwable th12 = th2;
                    new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
                    throw th12;
                }
            }
            this.ownerDocument.insertingNode(this, z2);
            ChildNode childNode = (ChildNode) node3;
            NodeImpl parentNode = childNode.parentNode();
            if (parentNode != null) {
                Node removeChild2 = parentNode.removeChild(childNode);
            }
            ChildNode childNode2 = (ChildNode) node4;
            childNode.ownerNode = this;
            childNode.isOwned(true);
            if (this.firstChild == null) {
                this.firstChild = childNode;
                childNode.isFirstChild(true);
                childNode.previousSibling = childNode;
            } else if (childNode2 == null) {
                ChildNode childNode3 = this.firstChild.previousSibling;
                childNode3.nextSibling = childNode;
                childNode.previousSibling = childNode3;
                this.firstChild.previousSibling = childNode;
            } else if (node4 == this.firstChild) {
                this.firstChild.isFirstChild(false);
                childNode.nextSibling = this.firstChild;
                childNode.previousSibling = this.firstChild.previousSibling;
                this.firstChild.previousSibling = childNode;
                this.firstChild = childNode;
                childNode.isFirstChild(true);
            } else {
                ChildNode childNode4 = childNode2.previousSibling;
                childNode.nextSibling = childNode2;
                childNode4.nextSibling = childNode;
                childNode2.previousSibling = childNode;
                childNode.previousSibling = childNode4;
            }
            changed();
            if (this.fNodeListCache != null) {
                if (this.fNodeListCache.fLength != -1) {
                    this.fNodeListCache.fLength++;
                }
                if (this.fNodeListCache.fChildIndex != -1) {
                    if (this.fNodeListCache.fChild == childNode2) {
                        this.fNodeListCache.fChild = childNode;
                    } else {
                        this.fNodeListCache.fChildIndex = -1;
                    }
                }
            }
            this.ownerDocument.insertedNode(this, childNode, z2);
            checkNormalizationAfterInsert(childNode);
            return node3;
        }
    }

    /* access modifiers changed from: package-private */
    public Node internalRemoveChild(Node node, boolean z) throws DOMException {
        Throwable th;
        Throwable th2;
        Node node2 = node;
        boolean z2 = z;
        CoreDocumentImpl ownerDocument2 = ownerDocument();
        if (ownerDocument2.errorChecking) {
            if (isReadOnly()) {
                Throwable th3 = th2;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th3;
            } else if (!(node2 == null || node2.getParentNode() == this)) {
                Throwable th4 = th;
                new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
                throw th4;
            }
        }
        ChildNode childNode = (ChildNode) node2;
        ownerDocument2.removingNode(this, childNode, z2);
        ChildNode previousSibling = childNode.previousSibling();
        if (this.fNodeListCache != null) {
            if (this.fNodeListCache.fLength != -1) {
                NodeListCache nodeListCache = this.fNodeListCache;
                nodeListCache.fLength--;
            }
            if (this.fNodeListCache.fChildIndex != -1) {
                if (this.fNodeListCache.fChild == childNode) {
                    NodeListCache nodeListCache2 = this.fNodeListCache;
                    nodeListCache2.fChildIndex--;
                    this.fNodeListCache.fChild = previousSibling;
                } else {
                    this.fNodeListCache.fChildIndex = -1;
                }
            }
        }
        if (childNode == this.firstChild) {
            childNode.isFirstChild(false);
            this.firstChild = childNode.nextSibling;
            if (this.firstChild != null) {
                this.firstChild.isFirstChild(true);
                this.firstChild.previousSibling = childNode.previousSibling;
            }
        } else {
            ChildNode childNode2 = childNode.previousSibling;
            ChildNode childNode3 = childNode.nextSibling;
            childNode2.nextSibling = childNode3;
            if (childNode3 == null) {
                this.firstChild.previousSibling = childNode2;
            } else {
                childNode3.previousSibling = childNode2;
            }
        }
        childNode.ownerNode = ownerDocument2;
        childNode.isOwned(false);
        childNode.nextSibling = null;
        childNode.previousSibling = null;
        changed();
        ownerDocument2.removedNode(this, z2);
        checkNormalizationAfterRemove(previousSibling);
        return childNode;
    }

    public boolean isEqualNode(Node node) {
        Node node2;
        Node node3 = node;
        if (!super.isEqualNode(node3)) {
            return false;
        }
        Node firstChild2 = getFirstChild();
        Node firstChild3 = node3.getFirstChild();
        while (true) {
            node2 = firstChild3;
            if (firstChild2 != null && node2 != null) {
                if (!firstChild2.isEqualNode(node2)) {
                    return false;
                }
                firstChild2 = firstChild2.getNextSibling();
                firstChild3 = node2.getNextSibling();
            }
        }
        return firstChild2 == node2;
    }

    public Node item(int i) {
        return nodeListItem(i);
    }

    /* access modifiers changed from: package-private */
    public final ChildNode lastChild() {
        return this.firstChild != null ? this.firstChild.previousSibling : null;
    }

    /* access modifiers changed from: package-private */
    public final void lastChild(ChildNode childNode) {
        ChildNode childNode2 = childNode;
        if (this.firstChild != null) {
            this.firstChild.previousSibling = childNode2;
        }
    }

    public void normalize() {
        if (!isNormalized()) {
            if (needsSyncChildren()) {
                synchronizeChildren();
            }
            ChildNode childNode = this.firstChild;
            while (true) {
                ChildNode childNode2 = childNode;
                if (childNode2 == null) {
                    isNormalized(true);
                    return;
                } else {
                    childNode2.normalize();
                    childNode = childNode2.nextSibling;
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public CoreDocumentImpl ownerDocument() {
        return this.ownerDocument;
    }

    public Node removeChild(Node node) throws DOMException {
        return internalRemoveChild(node, false);
    }

    public Node replaceChild(Node node, Node node2) throws DOMException {
        Node node3 = node;
        Node node4 = node2;
        this.ownerDocument.replacingNode(this);
        Node internalInsertBefore = internalInsertBefore(node3, node4, true);
        if (node3 != node4) {
            Node internalRemoveChild = internalRemoveChild(node4, true);
        }
        this.ownerDocument.replacedNode(this);
        return node4;
    }

    /* access modifiers changed from: protected */
    public void setOwnerDocument(CoreDocumentImpl coreDocumentImpl) {
        CoreDocumentImpl coreDocumentImpl2 = coreDocumentImpl;
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        super.setOwnerDocument(coreDocumentImpl2);
        this.ownerDocument = coreDocumentImpl2;
        ChildNode childNode = this.firstChild;
        while (true) {
            ChildNode childNode2 = childNode;
            if (childNode2 != null) {
                childNode2.setOwnerDocument(coreDocumentImpl2);
                childNode = childNode2.nextSibling;
            } else {
                return;
            }
        }
    }

    public void setReadOnly(boolean z, boolean z2) {
        boolean z3 = z;
        boolean z4 = z2;
        super.setReadOnly(z3, z4);
        if (z4) {
            if (needsSyncChildren()) {
                synchronizeChildren();
            }
            ChildNode childNode = this.firstChild;
            while (true) {
                ChildNode childNode2 = childNode;
                if (childNode2 != null) {
                    if (childNode2.getNodeType() != 5) {
                        childNode2.setReadOnly(z3, true);
                    }
                    childNode = childNode2.nextSibling;
                } else {
                    return;
                }
            }
        }
    }

    public void setTextContent(String str) throws DOMException {
        String str2 = str;
        while (true) {
            Node firstChild2 = getFirstChild();
            Node node = firstChild2;
            if (firstChild2 == null) {
                break;
            }
            Node removeChild = removeChild(node);
        }
        if (str2 != null && str2.length() != 0) {
            Node appendChild = appendChild(ownerDocument().createTextNode(str2));
        }
    }

    /* access modifiers changed from: protected */
    public void synchronizeChildren() {
        needsSyncChildren(false);
    }
}
