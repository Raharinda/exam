package org.apache.xerces.dom;

import java.util.ArrayList;
import java.util.Hashtable;
import net.lingala.zip4j.util.Zip4jConstants;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class DeferredDocumentImpl extends DocumentImpl implements DeferredNode {
    protected static final int CHUNK_MASK = 2047;
    protected static final int CHUNK_SHIFT = 11;
    protected static final int CHUNK_SIZE = 2048;
    private static final boolean DEBUG_IDS = false;
    private static final boolean DEBUG_PRINT_REF_COUNTS = false;
    private static final boolean DEBUG_PRINT_TABLES = false;
    protected static final int INITIAL_CHUNK_COUNT = 32;
    private static final int[] INIT_ARRAY = new int[2049];
    static final long serialVersionUID = 5186323580749626857L;
    private final transient StringBuffer fBufferStr;
    protected transient int fIdCount;
    protected transient int[] fIdElement;
    protected transient String[] fIdName;
    protected boolean fNamespacesEnabled;
    protected transient int fNodeCount;
    protected transient int[][] fNodeExtra;
    protected transient int[][] fNodeLastChild;
    protected transient Object[][] fNodeName;
    protected transient int[][] fNodeParent;
    protected transient int[][] fNodePrevSib;
    protected transient int[][] fNodeType;
    protected transient Object[][] fNodeURI;
    protected transient Object[][] fNodeValue;
    private final transient ArrayList fStrChunks;

    static final class IntVector {
        private int[] data;
        private int size;

        IntVector() {
        }

        private void ensureCapacity(int i) {
            int i2 = i;
            if (this.data == null) {
                this.data = new int[(i2 + 15)];
            } else if (i2 > this.data.length) {
                int[] iArr = new int[(i2 + 15)];
                System.arraycopy(this.data, 0, iArr, 0, this.data.length);
                this.data = iArr;
            }
        }

        public void addElement(int i) {
            ensureCapacity(this.size + 1);
            int[] iArr = this.data;
            int i2 = this.size;
            int i3 = i2 + 1;
            this.size = i3;
            iArr[i2] = i;
        }

        public int elementAt(int i) {
            return this.data[i];
        }

        public void removeAllElements() {
            this.size = 0;
        }

        public int size() {
            return this.size;
        }
    }

    static final class RefCount {
        int fCount;

        RefCount() {
        }
    }

    static {
        for (int i = 0; i < 2048; i++) {
            INIT_ARRAY[i] = -1;
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DeferredDocumentImpl() {
        this(false);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DeferredDocumentImpl(boolean z) {
        this(z, false);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DeferredDocumentImpl(boolean z, boolean z2) {
        super(z2);
        StringBuffer stringBuffer;
        ArrayList arrayList;
        this.fNodeCount = 0;
        this.fNamespacesEnabled = false;
        new StringBuffer();
        this.fBufferStr = stringBuffer;
        new ArrayList();
        this.fStrChunks = arrayList;
        needsSyncData(true);
        needsSyncChildren(true);
        this.fNamespacesEnabled = z;
    }

    protected static int binarySearch(int[] iArr, int i, int i2, int i3) {
        int[] iArr2 = iArr;
        int i4 = i;
        int i5 = i2;
        int i6 = i3;
        while (i4 <= i5) {
            int i7 = (i4 + i5) >>> 1;
            int i8 = iArr2[i7];
            if (i8 == i6) {
                while (i7 > 0 && iArr2[i7 - 1] == i6) {
                    i7--;
                }
                return i7;
            } else if (i8 > i6) {
                i5 = i7 - 1;
            } else {
                i4 = i7 + 1;
            }
        }
        return -1;
    }

    private final int clearChunkIndex(int[][] iArr, int i, int i2) {
        int[][] iArr2 = iArr;
        int i3 = i;
        int i4 = i2;
        int i5 = iArr2[i3] != null ? iArr2[i3][i4] : -1;
        if (i5 != -1) {
            int[] iArr3 = iArr2[i3];
            iArr3[2048] = iArr3[2048] - 1;
            iArr2[i3][i4] = -1;
            if (iArr2[i3][2048] == 0) {
                iArr2[i3] = null;
            }
        }
        return i5;
    }

    private final String clearChunkValue(Object[][] objArr, int i, int i2) {
        Object[][] objArr2 = objArr;
        int i3 = i;
        int i4 = i2;
        String str = objArr2[i3] != null ? (String) objArr2[i3][i4] : null;
        if (str != null) {
            objArr2[i3][i4] = null;
            RefCount refCount = (RefCount) objArr2[i3][2048];
            RefCount refCount2 = refCount;
            refCount2.fCount--;
            if (refCount.fCount == 0) {
                objArr2[i3] = null;
            }
        }
        return str;
    }

    private final void createChunk(int[][] iArr, int i) {
        int[][] iArr2 = iArr;
        int i2 = i;
        iArr2[i2] = new int[2049];
        System.arraycopy(INIT_ARRAY, 0, iArr2[i2], 0, 2048);
    }

    private final void createChunk(Object[][] objArr, int i) {
        Object obj;
        Object[][] objArr2 = objArr;
        int i2 = i;
        objArr2[i2] = new Object[2049];
        new RefCount();
        objArr2[i2][2048] = obj;
    }

    private final int getChunkIndex(int[][] iArr, int i, int i2) {
        int[][] iArr2 = iArr;
        int i3 = i;
        return iArr2[i3] != null ? iArr2[i3][i2] : -1;
    }

    private final String getChunkValue(Object[][] objArr, int i, int i2) {
        Object[][] objArr2 = objArr;
        int i3 = i;
        return objArr2[i3] != null ? (String) objArr2[i3][i2] : null;
    }

    private final String getNodeValue(int i, int i2) {
        Object obj = this.fNodeValue[i][i2];
        if (obj == null) {
            return null;
        }
        return obj instanceof String ? (String) obj : obj.toString();
    }

    private static void print(int[] iArr, int i, int i2, int i3, int i4) {
    }

    private final void putIdentifier0(String str, Element element) {
        Hashtable hashtable;
        String str2 = str;
        Element element2 = element;
        if (this.identifiers == null) {
            new Hashtable();
            this.identifiers = hashtable;
        }
        Object put = this.identifiers.put(str2, element2);
    }

    private final int setChunkIndex(int[][] iArr, int i, int i2, int i3) {
        int[][] iArr2 = iArr;
        int i4 = i;
        int i5 = i2;
        int i6 = i3;
        if (i4 == -1) {
            return clearChunkIndex(iArr2, i5, i6);
        }
        int[] iArr3 = iArr2[i5];
        if (iArr3 == null) {
            createChunk(iArr2, i5);
            iArr3 = iArr2[i5];
        }
        int i7 = iArr3[i6];
        if (i7 == -1) {
            int[] iArr4 = iArr3;
            iArr4[2048] = iArr4[2048] + 1;
        }
        iArr3[i6] = i4;
        return i7;
    }

    private final String setChunkValue(Object[][] objArr, Object obj, int i, int i2) {
        Object[][] objArr2 = objArr;
        Object obj2 = obj;
        int i3 = i;
        int i4 = i2;
        if (obj2 == null) {
            return clearChunkValue(objArr2, i3, i4);
        }
        Object[] objArr3 = objArr2[i3];
        if (objArr3 == null) {
            createChunk(objArr2, i3);
            objArr3 = objArr2[i3];
        }
        String str = (String) objArr3[i4];
        if (str == null) {
            ((RefCount) objArr3[2048]).fCount++;
        }
        objArr3[i4] = obj2;
        return str;
    }

    public void appendChild(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        int i5 = i3 >> CHUNK_SHIFT;
        int i6 = i3 & CHUNK_MASK;
        int i7 = i4 >> CHUNK_SHIFT;
        int i8 = i4 & CHUNK_MASK;
        int chunkIndex = setChunkIndex(this.fNodeParent, i3, i7, i8);
        int chunkIndex2 = setChunkIndex(this.fNodePrevSib, getChunkIndex(this.fNodeLastChild, i5, i6), i7, i8);
        int chunkIndex3 = setChunkIndex(this.fNodeLastChild, i4, i5, i6);
    }

    public int cloneNode(int i, boolean z) {
        int i2 = i;
        boolean z2 = z;
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        int i5 = this.fNodeType[i3][i4];
        int createNode = createNode((short) i5);
        int i6 = createNode >> CHUNK_SHIFT;
        int i7 = createNode & CHUNK_MASK;
        String chunkValue = setChunkValue(this.fNodeName, this.fNodeName[i3][i4], i6, i7);
        String chunkValue2 = setChunkValue(this.fNodeValue, this.fNodeValue[i3][i4], i6, i7);
        String chunkValue3 = setChunkValue(this.fNodeURI, this.fNodeURI[i3][i4], i6, i7);
        int i8 = this.fNodeExtra[i3][i4];
        if (i8 != -1) {
            if (!(i5 == 2 || i5 == 3)) {
                i8 = cloneNode(i8, false);
            }
            int chunkIndex = setChunkIndex(this.fNodeExtra, i8, i6, i7);
        }
        if (z2) {
            int i9 = -1;
            int lastChild = getLastChild(i2, false);
            while (true) {
                int i10 = lastChild;
                if (i10 == -1) {
                    break;
                }
                int cloneNode = cloneNode(i10, z2);
                int insertBefore = insertBefore(createNode, cloneNode, i9);
                i9 = cloneNode;
                lastChild = getRealPrevSibling(i10, false);
            }
        }
        return createNode;
    }

    public int createDeferredAttribute(String str, String str2, String str3, boolean z) {
        int createNode = createNode(2);
        int i = createNode >> CHUNK_SHIFT;
        int i2 = createNode & CHUNK_MASK;
        String chunkValue = setChunkValue(this.fNodeName, str, i, i2);
        String chunkValue2 = setChunkValue(this.fNodeURI, str2, i, i2);
        String chunkValue3 = setChunkValue(this.fNodeValue, str3, i, i2);
        int chunkIndex = setChunkIndex(this.fNodeExtra, z ? 32 : 0, i, i2);
        return createNode;
    }

    public int createDeferredAttribute(String str, String str2, boolean z) {
        return createDeferredAttribute(str, (String) null, str2, z);
    }

    public int createDeferredCDATASection(String str) {
        int createNode = createNode(4);
        String chunkValue = setChunkValue(this.fNodeValue, str, createNode >> CHUNK_SHIFT, createNode & CHUNK_MASK);
        return createNode;
    }

    public int createDeferredComment(String str) {
        int createNode = createNode(8);
        String chunkValue = setChunkValue(this.fNodeValue, str, createNode >> CHUNK_SHIFT, createNode & CHUNK_MASK);
        return createNode;
    }

    public int createDeferredDocument() {
        return createNode(9);
    }

    public int createDeferredDocumentType(String str, String str2, String str3) {
        int createNode = createNode(10);
        int i = createNode >> CHUNK_SHIFT;
        int i2 = createNode & CHUNK_MASK;
        String chunkValue = setChunkValue(this.fNodeName, str, i, i2);
        String chunkValue2 = setChunkValue(this.fNodeValue, str2, i, i2);
        String chunkValue3 = setChunkValue(this.fNodeURI, str3, i, i2);
        return createNode;
    }

    public int createDeferredElement(String str) {
        return createDeferredElement((String) null, str);
    }

    public int createDeferredElement(String str, String str2) {
        int createNode = createNode(1);
        int i = createNode >> CHUNK_SHIFT;
        int i2 = createNode & CHUNK_MASK;
        String chunkValue = setChunkValue(this.fNodeName, str2, i, i2);
        String chunkValue2 = setChunkValue(this.fNodeURI, str, i, i2);
        return createNode;
    }

    public int createDeferredElement(String str, String str2, Object obj) {
        int createNode = createNode(1);
        int i = createNode >> CHUNK_SHIFT;
        int i2 = createNode & CHUNK_MASK;
        String chunkValue = setChunkValue(this.fNodeName, str2, i, i2);
        String chunkValue2 = setChunkValue(this.fNodeURI, str, i, i2);
        String chunkValue3 = setChunkValue(this.fNodeValue, obj, i, i2);
        return createNode;
    }

    public int createDeferredElementDefinition(String str) {
        int createNode = createNode(21);
        String chunkValue = setChunkValue(this.fNodeName, str, createNode >> CHUNK_SHIFT, createNode & CHUNK_MASK);
        return createNode;
    }

    public int createDeferredEntity(String str, String str2, String str3, String str4, String str5) {
        int createNode = createNode(6);
        int i = createNode >> CHUNK_SHIFT;
        int i2 = createNode & CHUNK_MASK;
        int createNode2 = createNode(6);
        int i3 = createNode2 >> CHUNK_SHIFT;
        int i4 = createNode2 & CHUNK_MASK;
        String chunkValue = setChunkValue(this.fNodeName, str, i, i2);
        String chunkValue2 = setChunkValue(this.fNodeValue, str2, i, i2);
        String chunkValue3 = setChunkValue(this.fNodeURI, str3, i, i2);
        int chunkIndex = setChunkIndex(this.fNodeExtra, createNode2, i, i2);
        String chunkValue4 = setChunkValue(this.fNodeName, str4, i3, i4);
        String chunkValue5 = setChunkValue(this.fNodeValue, (Object) null, i3, i4);
        String chunkValue6 = setChunkValue(this.fNodeURI, (Object) null, i3, i4);
        int createNode3 = createNode(6);
        int i5 = createNode3 >> CHUNK_SHIFT;
        int i6 = createNode3 & CHUNK_MASK;
        int chunkIndex2 = setChunkIndex(this.fNodeExtra, createNode3, i3, i4);
        String chunkValue7 = setChunkValue(this.fNodeName, str5, i5, i6);
        return createNode;
    }

    public int createDeferredEntityReference(String str, String str2) {
        int createNode = createNode(5);
        int i = createNode >> CHUNK_SHIFT;
        int i2 = createNode & CHUNK_MASK;
        String chunkValue = setChunkValue(this.fNodeName, str, i, i2);
        String chunkValue2 = setChunkValue(this.fNodeValue, str2, i, i2);
        return createNode;
    }

    public int createDeferredNotation(String str, String str2, String str3, String str4) {
        int createNode = createNode(12);
        int i = createNode >> CHUNK_SHIFT;
        int i2 = createNode & CHUNK_MASK;
        int createNode2 = createNode(12);
        int i3 = createNode2 >> CHUNK_SHIFT;
        int i4 = createNode2 & CHUNK_MASK;
        String chunkValue = setChunkValue(this.fNodeName, str, i, i2);
        String chunkValue2 = setChunkValue(this.fNodeValue, str2, i, i2);
        String chunkValue3 = setChunkValue(this.fNodeURI, str3, i, i2);
        int chunkIndex = setChunkIndex(this.fNodeExtra, createNode2, i, i2);
        String chunkValue4 = setChunkValue(this.fNodeName, str4, i3, i4);
        return createNode;
    }

    public int createDeferredProcessingInstruction(String str, String str2) {
        int createNode = createNode(7);
        int i = createNode >> CHUNK_SHIFT;
        int i2 = createNode & CHUNK_MASK;
        String chunkValue = setChunkValue(this.fNodeName, str, i, i2);
        String chunkValue2 = setChunkValue(this.fNodeValue, str2, i, i2);
        return createNode;
    }

    public int createDeferredTextNode(String str, boolean z) {
        int createNode = createNode(3);
        int i = createNode >> CHUNK_SHIFT;
        int i2 = createNode & CHUNK_MASK;
        String chunkValue = setChunkValue(this.fNodeValue, str, i, i2);
        int chunkIndex = setChunkIndex(this.fNodeExtra, z ? 1 : 0, i, i2);
        return createNode;
    }

    /* access modifiers changed from: protected */
    public int createNode(short s) {
        int i = this.fNodeCount >> CHUNK_SHIFT;
        int i2 = this.fNodeCount & CHUNK_MASK;
        ensureCapacity(i);
        int chunkIndex = setChunkIndex(this.fNodeType, s, i, i2);
        int i3 = this.fNodeCount;
        int i4 = i3 + 1;
        this.fNodeCount = i4;
        return i3;
    }

    /* access modifiers changed from: protected */
    public void ensureCapacity(int i) {
        int i2 = i;
        if (this.fNodeType == null) {
            this.fNodeType = new int[32][];
            this.fNodeName = new Object[32][];
            this.fNodeValue = new Object[32][];
            this.fNodeParent = new int[32][];
            this.fNodeLastChild = new int[32][];
            this.fNodePrevSib = new int[32][];
            this.fNodeURI = new Object[32][];
            this.fNodeExtra = new int[32][];
        } else if (this.fNodeType.length <= i2) {
            int i3 = i2 * 2;
            int[][] iArr = new int[i3][];
            System.arraycopy(this.fNodeType, 0, iArr, 0, i2);
            this.fNodeType = iArr;
            Object[][] objArr = new Object[i3][];
            System.arraycopy(this.fNodeName, 0, objArr, 0, i2);
            this.fNodeName = objArr;
            Object[][] objArr2 = new Object[i3][];
            System.arraycopy(this.fNodeValue, 0, objArr2, 0, i2);
            this.fNodeValue = objArr2;
            int[][] iArr2 = new int[i3][];
            System.arraycopy(this.fNodeParent, 0, iArr2, 0, i2);
            this.fNodeParent = iArr2;
            int[][] iArr3 = new int[i3][];
            System.arraycopy(this.fNodeLastChild, 0, iArr3, 0, i2);
            this.fNodeLastChild = iArr3;
            int[][] iArr4 = new int[i3][];
            System.arraycopy(this.fNodePrevSib, 0, iArr4, 0, i2);
            this.fNodePrevSib = iArr4;
            Object[][] objArr3 = new Object[i3][];
            System.arraycopy(this.fNodeURI, 0, objArr3, 0, i2);
            this.fNodeURI = objArr3;
            int[][] iArr5 = new int[i3][];
            System.arraycopy(this.fNodeExtra, 0, iArr5, 0, i2);
            this.fNodeExtra = iArr5;
        } else if (this.fNodeType[i2] != null) {
            return;
        }
        createChunk(this.fNodeType, i2);
        createChunk(this.fNodeName, i2);
        createChunk(this.fNodeValue, i2);
        createChunk(this.fNodeParent, i2);
        createChunk(this.fNodeLastChild, i2);
        createChunk(this.fNodePrevSib, i2);
        createChunk(this.fNodeURI, i2);
        createChunk(this.fNodeExtra, i2);
    }

    public String getAttribute(int i, String str) {
        int i2 = i;
        String str2 = str;
        if (i2 == -1 || str2 == null) {
            return null;
        }
        int chunkIndex = getChunkIndex(this.fNodeExtra, i2 >> CHUNK_SHIFT, i2 & CHUNK_MASK);
        while (true) {
            int i3 = chunkIndex;
            if (i3 == -1) {
                return null;
            }
            int i4 = i3 >> CHUNK_SHIFT;
            int i5 = i3 & CHUNK_MASK;
            if (getChunkValue(this.fNodeName, i4, i5) == str2) {
                return getChunkValue(this.fNodeValue, i4, i5);
            }
            chunkIndex = getChunkIndex(this.fNodePrevSib, i4, i5);
        }
    }

    public String getDeferredEntityBaseURI(int i) {
        int i2 = i;
        if (i2 == -1) {
            return null;
        }
        return getNodeName(getNodeExtra(getNodeExtra(i2, false), false), false);
    }

    public DOMImplementation getImplementation() {
        return DeferredDOMImplementationImpl.getDOMImplementation();
    }

    public int getLastChild(int i) {
        return getLastChild(i, true);
    }

    public int getLastChild(int i, boolean z) {
        int i2 = i;
        boolean z2 = z;
        if (i2 == -1) {
            return -1;
        }
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        return z2 ? clearChunkIndex(this.fNodeLastChild, i3, i4) : getChunkIndex(this.fNodeLastChild, i3, i4);
    }

    /* access modifiers changed from: package-private */
    public boolean getNamespacesEnabled() {
        return this.fNamespacesEnabled;
    }

    public int getNodeExtra(int i) {
        return getNodeExtra(i, true);
    }

    public int getNodeExtra(int i, boolean z) {
        int i2 = i;
        boolean z2 = z;
        if (i2 == -1) {
            return -1;
        }
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        return z2 ? clearChunkIndex(this.fNodeExtra, i3, i4) : getChunkIndex(this.fNodeExtra, i3, i4);
    }

    public int getNodeIndex() {
        return 0;
    }

    public String getNodeName(int i) {
        return getNodeName(i, true);
    }

    public String getNodeName(int i, boolean z) {
        int i2 = i;
        boolean z2 = z;
        if (i2 == -1) {
            return null;
        }
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        return z2 ? clearChunkValue(this.fNodeName, i3, i4) : getChunkValue(this.fNodeName, i3, i4);
    }

    public DeferredNode getNodeObject(int i) {
        DeferredDocumentImpl deferredDocumentImpl;
        DeferredDocumentImpl deferredDocumentImpl2;
        DeferredDocumentImpl deferredDocumentImpl3;
        DeferredDocumentImpl deferredDocumentImpl4;
        DeferredDocumentImpl deferredDocumentImpl5;
        DeferredDocumentImpl deferredDocumentImpl6;
        DeferredDocumentImpl deferredDocumentImpl7;
        Element element;
        DeferredDocumentImpl deferredDocumentImpl8;
        DocumentTypeImpl documentTypeImpl;
        DeferredDocumentImpl deferredDocumentImpl9;
        DeferredDocumentImpl deferredDocumentImpl10;
        Throwable th;
        DeferredDocumentImpl deferredDocumentImpl11;
        DeferredDocumentImpl deferredDocumentImpl12;
        Throwable th2;
        StringBuffer stringBuffer;
        int i2 = i;
        if (i2 == -1) {
            return null;
        }
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        int chunkIndex = getChunkIndex(this.fNodeType, i3, i4);
        if (!(chunkIndex == 3 || chunkIndex == 4)) {
            int clearChunkIndex = clearChunkIndex(this.fNodeType, i3, i4);
        }
        switch (chunkIndex) {
            case 1:
                if (this.fNamespacesEnabled) {
                    new DeferredElementNSImpl(this, i2);
                    deferredDocumentImpl2 = deferredDocumentImpl8;
                } else {
                    new DeferredElementImpl(this, i2);
                    deferredDocumentImpl2 = element;
                }
                if (this.fIdElement != null) {
                    for (int binarySearch = binarySearch(this.fIdElement, 0, this.fIdCount - 1, i2); binarySearch != -1; binarySearch = (binarySearch + 1 >= this.fIdCount || this.fIdElement[binarySearch + 1] != i2) ? -1 : binarySearch + 1) {
                        String str = this.fIdName[binarySearch];
                        if (str != null) {
                            putIdentifier0(str, (Element) deferredDocumentImpl2);
                            this.fIdName[binarySearch] = null;
                        }
                    }
                    break;
                }
                break;
            case 2:
                if (!this.fNamespacesEnabled) {
                    new DeferredAttrImpl(this, i2);
                    deferredDocumentImpl2 = deferredDocumentImpl11;
                    break;
                } else {
                    new DeferredAttrNSImpl(this, i2);
                    deferredDocumentImpl2 = deferredDocumentImpl12;
                    break;
                }
            case 3:
                new DeferredTextImpl(this, i2);
                deferredDocumentImpl2 = deferredDocumentImpl3;
                break;
            case 4:
                new DeferredCDATASectionImpl(this, i2);
                deferredDocumentImpl2 = deferredDocumentImpl10;
                break;
            case 5:
                new DeferredEntityReferenceImpl(this, i2);
                deferredDocumentImpl2 = deferredDocumentImpl6;
                break;
            case 6:
                new DeferredEntityImpl(this, i2);
                deferredDocumentImpl2 = deferredDocumentImpl7;
                break;
            case Zip4jConstants.DEFLATE_LEVEL_MAXIMUM:
                new DeferredProcessingInstructionImpl(this, i2);
                deferredDocumentImpl2 = deferredDocumentImpl4;
                break;
            case 8:
                new DeferredCommentImpl(this, i2);
                deferredDocumentImpl2 = deferredDocumentImpl9;
                break;
            case Zip4jConstants.DEFLATE_LEVEL_ULTRA:
                deferredDocumentImpl2 = this;
                break;
            case 10:
                new DeferredDocumentTypeImpl(this, i2);
                deferredDocumentImpl2 = documentTypeImpl;
                this.docType = deferredDocumentImpl2;
                break;
            case 12:
                new DeferredNotationImpl(this, i2);
                deferredDocumentImpl2 = deferredDocumentImpl5;
                break;
            case 21:
                new DeferredElementDefinitionImpl(this, i2);
                deferredDocumentImpl2 = deferredDocumentImpl;
                break;
            default:
                Throwable th3 = th2;
                new StringBuffer();
                new IllegalArgumentException(stringBuffer.append("type: ").append(chunkIndex).toString());
                throw th3;
        }
        if (deferredDocumentImpl2 != null) {
            return deferredDocumentImpl2;
        }
        Throwable th4 = th;
        new IllegalArgumentException();
        throw th4;
    }

    public short getNodeType(int i) {
        return getNodeType(i, true);
    }

    public short getNodeType(int i, boolean z) {
        int i2 = i;
        boolean z2 = z;
        if (i2 == -1) {
            return -1;
        }
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        return z2 ? (short) clearChunkIndex(this.fNodeType, i3, i4) : (short) getChunkIndex(this.fNodeType, i3, i4);
    }

    public String getNodeURI(int i) {
        return getNodeURI(i, true);
    }

    public String getNodeURI(int i, boolean z) {
        int i2 = i;
        boolean z2 = z;
        if (i2 == -1) {
            return null;
        }
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        return z2 ? clearChunkValue(this.fNodeURI, i3, i4) : getChunkValue(this.fNodeURI, i3, i4);
    }

    public String getNodeValue(int i) {
        return getNodeValue(i, true);
    }

    public String getNodeValue(int i, boolean z) {
        int i2 = i;
        boolean z2 = z;
        if (i2 == -1) {
            return null;
        }
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        return z2 ? clearChunkValue(this.fNodeValue, i3, i4) : getChunkValue(this.fNodeValue, i3, i4);
    }

    public String getNodeValueString(int i) {
        return getNodeValueString(i, true);
    }

    public String getNodeValueString(int i, boolean z) {
        int i2 = i;
        boolean z2 = z;
        if (i2 == -1) {
            return null;
        }
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        String clearChunkValue = z2 ? clearChunkValue(this.fNodeValue, i3, i4) : getChunkValue(this.fNodeValue, i3, i4);
        if (clearChunkValue == null) {
            return null;
        }
        int chunkIndex = getChunkIndex(this.fNodeType, i3, i4);
        if (chunkIndex == 3) {
            int realPrevSibling = getRealPrevSibling(i2);
            if (realPrevSibling != -1 && getNodeType(realPrevSibling, false) == 3) {
                boolean add = this.fStrChunks.add(clearChunkValue);
                do {
                    int i5 = realPrevSibling >> CHUNK_SHIFT;
                    int i6 = realPrevSibling & CHUNK_MASK;
                    boolean add2 = this.fStrChunks.add(getChunkValue(this.fNodeValue, i5, i6));
                    realPrevSibling = getChunkIndex(this.fNodePrevSib, i5, i6);
                    if (realPrevSibling == -1 || getNodeType(realPrevSibling, false) != 3) {
                    }
                    int i52 = realPrevSibling >> CHUNK_SHIFT;
                    int i62 = realPrevSibling & CHUNK_MASK;
                    boolean add22 = this.fStrChunks.add(getChunkValue(this.fNodeValue, i52, i62));
                    realPrevSibling = getChunkIndex(this.fNodePrevSib, i52, i62);
                    break;
                } while (getNodeType(realPrevSibling, false) != 3);
                for (int size = this.fStrChunks.size() - 1; size >= 0; size--) {
                    StringBuffer append = this.fBufferStr.append((String) this.fStrChunks.get(size));
                }
                String stringBuffer = this.fBufferStr.toString();
                this.fStrChunks.clear();
                this.fBufferStr.setLength(0);
                return stringBuffer;
            }
        } else if (chunkIndex == 4) {
            int lastChild = getLastChild(i2, false);
            if (lastChild != -1) {
                StringBuffer append2 = this.fBufferStr.append(clearChunkValue);
                while (lastChild != -1) {
                    int i7 = lastChild >> CHUNK_SHIFT;
                    int i8 = lastChild & CHUNK_MASK;
                    boolean add3 = this.fStrChunks.add(getChunkValue(this.fNodeValue, i7, i8));
                    lastChild = getChunkIndex(this.fNodePrevSib, i7, i8);
                }
                for (int size2 = this.fStrChunks.size() - 1; size2 >= 0; size2--) {
                    StringBuffer append3 = this.fBufferStr.append((String) this.fStrChunks.get(size2));
                }
                String stringBuffer2 = this.fBufferStr.toString();
                this.fStrChunks.clear();
                this.fBufferStr.setLength(0);
                return stringBuffer2;
            }
        }
        return clearChunkValue;
    }

    public int getParentNode(int i) {
        return getParentNode(i, false);
    }

    public int getParentNode(int i, boolean z) {
        int i2 = i;
        boolean z2 = z;
        if (i2 == -1) {
            return -1;
        }
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        return z2 ? clearChunkIndex(this.fNodeParent, i3, i4) : getChunkIndex(this.fNodeParent, i3, i4);
    }

    public int getPrevSibling(int i) {
        return getPrevSibling(i, true);
    }

    public int getPrevSibling(int i, boolean z) {
        int chunkIndex;
        int i2 = i;
        boolean z2 = z;
        if (i2 == -1) {
            return -1;
        }
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        if (getChunkIndex(this.fNodeType, i3, i4) == 3) {
            do {
                chunkIndex = getChunkIndex(this.fNodePrevSib, i3, i4);
                if (chunkIndex == -1) {
                    break;
                }
                i3 = chunkIndex >> CHUNK_SHIFT;
                i4 = chunkIndex & CHUNK_MASK;
            } while (getChunkIndex(this.fNodeType, i3, i4) == 3);
        } else {
            chunkIndex = getChunkIndex(this.fNodePrevSib, i3, i4);
        }
        return chunkIndex;
    }

    public int getRealPrevSibling(int i) {
        return getRealPrevSibling(i, true);
    }

    public int getRealPrevSibling(int i, boolean z) {
        int i2 = i;
        boolean z2 = z;
        if (i2 == -1) {
            return -1;
        }
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        return z2 ? clearChunkIndex(this.fNodePrevSib, i3, i4) : getChunkIndex(this.fNodePrevSib, i3, i4);
    }

    public Object getTypeInfo(int i) {
        int i2 = i;
        if (i2 == -1) {
            return null;
        }
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        Object obj = this.fNodeValue[i3] != null ? this.fNodeValue[i3][i4] : null;
        if (obj != null) {
            this.fNodeValue[i3][i4] = null;
            RefCount refCount = (RefCount) this.fNodeValue[i3][2048];
            RefCount refCount2 = refCount;
            refCount2.fCount--;
            if (refCount.fCount == 0) {
                this.fNodeValue[i3] = null;
            }
        }
        return obj;
    }

    public int insertBefore(int i, int i2, int i3) {
        int i4 = i;
        int i5 = i2;
        int i6 = i3;
        if (i6 == -1) {
            appendChild(i4, i5);
            return i5;
        }
        int i7 = i5 >> CHUNK_SHIFT;
        int i8 = i5 & CHUNK_MASK;
        int i9 = i6 >> CHUNK_SHIFT;
        int i10 = i6 & CHUNK_MASK;
        int chunkIndex = getChunkIndex(this.fNodePrevSib, i9, i10);
        int chunkIndex2 = setChunkIndex(this.fNodePrevSib, i5, i9, i10);
        int chunkIndex3 = setChunkIndex(this.fNodePrevSib, chunkIndex, i7, i8);
        return i5;
    }

    public int lookupElementDefinition(String str) {
        String str2 = str;
        if (this.fNodeCount > 1) {
            int i = -1;
            int chunkIndex = getChunkIndex(this.fNodeLastChild, 0, 0);
            while (true) {
                int i2 = chunkIndex;
                if (i2 == -1) {
                    break;
                }
                int i3 = i2 >> CHUNK_SHIFT;
                int i4 = i2 & CHUNK_MASK;
                if (getChunkIndex(this.fNodeType, i3, i4) == 10) {
                    i = i2;
                    break;
                }
                chunkIndex = getChunkIndex(this.fNodePrevSib, i3, i4);
            }
            if (i == -1) {
                return -1;
            }
            int chunkIndex2 = getChunkIndex(this.fNodeLastChild, i >> CHUNK_SHIFT, i & CHUNK_MASK);
            while (true) {
                int i5 = chunkIndex2;
                if (i5 == -1) {
                    break;
                }
                int i6 = i5 >> CHUNK_SHIFT;
                int i7 = i5 & CHUNK_MASK;
                if (getChunkIndex(this.fNodeType, i6, i7) == 21 && getChunkValue(this.fNodeName, i6, i7) == str2) {
                    return i5;
                }
                chunkIndex2 = getChunkIndex(this.fNodePrevSib, i6, i7);
            }
        }
        return -1;
    }

    public void print() {
    }

    public void putIdentifier(String str, int i) {
        String str2 = str;
        int i2 = i;
        if (this.fIdName == null) {
            this.fIdName = new String[64];
            this.fIdElement = new int[64];
        }
        if (this.fIdCount == this.fIdName.length) {
            String[] strArr = new String[(this.fIdCount * 2)];
            System.arraycopy(this.fIdName, 0, strArr, 0, this.fIdCount);
            this.fIdName = strArr;
            int[] iArr = new int[strArr.length];
            System.arraycopy(this.fIdElement, 0, iArr, 0, this.fIdCount);
            this.fIdElement = iArr;
        }
        this.fIdName[this.fIdCount] = str2;
        this.fIdElement[this.fIdCount] = i2;
        this.fIdCount++;
    }

    public void setAsLastChild(int i, int i2) {
        int i3 = i;
        int chunkIndex = setChunkIndex(this.fNodeLastChild, i2, i3 >> CHUNK_SHIFT, i3 & CHUNK_MASK);
    }

    public int setAttributeNode(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        int i5 = i3 >> CHUNK_SHIFT;
        int i6 = i3 & CHUNK_MASK;
        int i7 = i4 >> CHUNK_SHIFT;
        int i8 = i4 & CHUNK_MASK;
        String chunkValue = getChunkValue(this.fNodeName, i7, i8);
        int chunkIndex = getChunkIndex(this.fNodeExtra, i5, i6);
        int i9 = -1;
        int i10 = -1;
        int i11 = -1;
        while (chunkIndex != -1) {
            i10 = chunkIndex >> CHUNK_SHIFT;
            i11 = chunkIndex & CHUNK_MASK;
            if (getChunkValue(this.fNodeName, i10, i11).equals(chunkValue)) {
                break;
            }
            i9 = chunkIndex;
            chunkIndex = getChunkIndex(this.fNodePrevSib, i10, i11);
        }
        if (chunkIndex != -1) {
            int chunkIndex2 = getChunkIndex(this.fNodePrevSib, i10, i11);
            if (i9 == -1) {
                int chunkIndex3 = setChunkIndex(this.fNodeExtra, chunkIndex2, i5, i6);
            } else {
                int chunkIndex4 = setChunkIndex(this.fNodePrevSib, chunkIndex2, i9 >> CHUNK_SHIFT, i9 & CHUNK_MASK);
            }
            int clearChunkIndex = clearChunkIndex(this.fNodeType, i10, i11);
            String clearChunkValue = clearChunkValue(this.fNodeName, i10, i11);
            String clearChunkValue2 = clearChunkValue(this.fNodeValue, i10, i11);
            int clearChunkIndex2 = clearChunkIndex(this.fNodeParent, i10, i11);
            int clearChunkIndex3 = clearChunkIndex(this.fNodePrevSib, i10, i11);
            int clearChunkIndex4 = clearChunkIndex(this.fNodeLastChild, i10, i11);
            int i12 = clearChunkIndex4 >> CHUNK_SHIFT;
            int i13 = clearChunkIndex4 & CHUNK_MASK;
            int clearChunkIndex5 = clearChunkIndex(this.fNodeType, i12, i13);
            String clearChunkValue3 = clearChunkValue(this.fNodeValue, i12, i13);
            int clearChunkIndex6 = clearChunkIndex(this.fNodeParent, i12, i13);
            int clearChunkIndex7 = clearChunkIndex(this.fNodeLastChild, i12, i13);
        }
        int chunkIndex5 = getChunkIndex(this.fNodeExtra, i5, i6);
        int chunkIndex6 = setChunkIndex(this.fNodeExtra, i4, i5, i6);
        int chunkIndex7 = setChunkIndex(this.fNodePrevSib, chunkIndex5, i7, i8);
        return chunkIndex;
    }

    public int setDeferredAttribute(int i, String str, String str2, String str3, boolean z) {
        int i2 = i;
        int createDeferredAttribute = createDeferredAttribute(str, str2, str3, z);
        int i3 = createDeferredAttribute >> CHUNK_SHIFT;
        int i4 = createDeferredAttribute & CHUNK_MASK;
        int chunkIndex = setChunkIndex(this.fNodeParent, i2, i3, i4);
        int i5 = i2 >> CHUNK_SHIFT;
        int i6 = i2 & CHUNK_MASK;
        int chunkIndex2 = getChunkIndex(this.fNodeExtra, i5, i6);
        if (chunkIndex2 != 0) {
            int chunkIndex3 = setChunkIndex(this.fNodePrevSib, chunkIndex2, i3, i4);
        }
        int chunkIndex4 = setChunkIndex(this.fNodeExtra, createDeferredAttribute, i5, i6);
        return createDeferredAttribute;
    }

    public int setDeferredAttribute(int i, String str, String str2, String str3, boolean z, boolean z2, Object obj) {
        int i2 = i;
        boolean z3 = z2;
        Object obj2 = obj;
        int createDeferredAttribute = createDeferredAttribute(str, str2, str3, z);
        int i3 = createDeferredAttribute >> CHUNK_SHIFT;
        int i4 = createDeferredAttribute & CHUNK_MASK;
        int chunkIndex = setChunkIndex(this.fNodeParent, i2, i3, i4);
        int i5 = i2 >> CHUNK_SHIFT;
        int i6 = i2 & CHUNK_MASK;
        int chunkIndex2 = getChunkIndex(this.fNodeExtra, i5, i6);
        if (chunkIndex2 != 0) {
            int chunkIndex3 = setChunkIndex(this.fNodePrevSib, chunkIndex2, i3, i4);
        }
        int chunkIndex4 = setChunkIndex(this.fNodeExtra, createDeferredAttribute, i5, i6);
        int chunkIndex5 = getChunkIndex(this.fNodeExtra, i3, i4);
        if (z3) {
            int chunkIndex6 = setChunkIndex(this.fNodeExtra, chunkIndex5 | 512, i3, i4);
            putIdentifier(getChunkValue(this.fNodeValue, i3, i4), i2);
        }
        if (obj2 != null) {
            int createNode = createNode(20);
            int i7 = createNode >> CHUNK_SHIFT;
            int i8 = createNode & CHUNK_MASK;
            int chunkIndex7 = setChunkIndex(this.fNodeLastChild, createNode, i3, i4);
            String chunkValue = setChunkValue(this.fNodeValue, obj2, i7, i8);
        }
        return createDeferredAttribute;
    }

    public void setEntityInfo(int i, String str, String str2) {
        String str3 = str;
        String str4 = str2;
        int nodeExtra = getNodeExtra(i, false);
        if (nodeExtra != -1) {
            int i2 = nodeExtra >> CHUNK_SHIFT;
            int i3 = nodeExtra & CHUNK_MASK;
            String chunkValue = setChunkValue(this.fNodeValue, str3, i2, i3);
            String chunkValue2 = setChunkValue(this.fNodeURI, str4, i2, i3);
        }
    }

    public void setIdAttribute(int i) {
        int i2 = i;
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        int chunkIndex = setChunkIndex(this.fNodeExtra, getChunkIndex(this.fNodeExtra, i3, i4) | 512, i3, i4);
    }

    public void setIdAttributeNode(int i, int i2) {
        int i3 = i2;
        int i4 = i3 >> CHUNK_SHIFT;
        int i5 = i3 & CHUNK_MASK;
        int chunkIndex = setChunkIndex(this.fNodeExtra, getChunkIndex(this.fNodeExtra, i4, i5) | 512, i4, i5);
        putIdentifier(getChunkValue(this.fNodeValue, i4, i5), i);
    }

    public void setInputEncoding(int i, String str) {
        int nodeExtra = getNodeExtra(getNodeExtra(i, false), false);
        String chunkValue = setChunkValue(this.fNodeValue, str, nodeExtra >> CHUNK_SHIFT, nodeExtra & CHUNK_MASK);
    }

    public void setInternalSubset(int i, String str) {
        int i2 = i;
        int i3 = i2 >> CHUNK_SHIFT;
        int i4 = i2 & CHUNK_MASK;
        int createNode = createNode(10);
        int i5 = createNode >> CHUNK_SHIFT;
        int i6 = createNode & CHUNK_MASK;
        int chunkIndex = setChunkIndex(this.fNodeExtra, createNode, i3, i4);
        String chunkValue = setChunkValue(this.fNodeValue, str, i5, i6);
    }

    /* access modifiers changed from: package-private */
    public void setNamespacesEnabled(boolean z) {
        boolean z2 = z;
        this.fNamespacesEnabled = z2;
    }

    public void setTypeInfo(int i, Object obj) {
        int i2 = i;
        String chunkValue = setChunkValue(this.fNodeValue, obj, i2 >> CHUNK_SHIFT, i2 & CHUNK_MASK);
    }

    /* access modifiers changed from: protected */
    public void synchronizeChildren() {
        if (needsSyncData()) {
            synchronizeData();
            if (!needsSyncChildren()) {
                return;
            }
        }
        boolean z = this.mutationEvents;
        this.mutationEvents = false;
        needsSyncChildren(false);
        short nodeType = getNodeType(0);
        ChildNode childNode = null;
        ChildNode childNode2 = null;
        int lastChild = getLastChild(0);
        while (true) {
            int i = lastChild;
            if (i == -1) {
                break;
            }
            ChildNode childNode3 = (ChildNode) getNodeObject(i);
            if (childNode2 == null) {
                childNode2 = childNode3;
            } else {
                childNode.previousSibling = childNode3;
            }
            childNode3.ownerNode = this;
            childNode3.isOwned(true);
            childNode3.nextSibling = childNode;
            childNode = childNode3;
            short nodeType2 = childNode3.getNodeType();
            if (nodeType2 == 1) {
                this.docElement = (ElementImpl) childNode3;
            } else if (nodeType2 == 10) {
                this.docType = (DocumentTypeImpl) childNode3;
            }
            lastChild = getPrevSibling(i);
        }
        if (childNode != null) {
            this.firstChild = childNode;
            childNode.isFirstChild(true);
            lastChild(childNode2);
        }
        this.mutationEvents = z;
    }

    /* access modifiers changed from: protected */
    public final void synchronizeChildren(AttrImpl attrImpl, int i) {
        AttrImpl attrImpl2 = attrImpl;
        int i2 = i;
        boolean mutationEvents = getMutationEvents();
        setMutationEvents(false);
        attrImpl2.needsSyncChildren(false);
        int lastChild = getLastChild(i2);
        if (getPrevSibling(lastChild) == -1) {
            attrImpl2.value = getNodeValueString(i2);
            attrImpl2.hasStringValue(true);
        } else {
            ChildNode childNode = null;
            ChildNode childNode2 = null;
            int i3 = lastChild;
            while (true) {
                int i4 = i3;
                if (i4 == -1) {
                    break;
                }
                ChildNode childNode3 = (ChildNode) getNodeObject(i4);
                if (childNode2 == null) {
                    childNode2 = childNode3;
                } else {
                    childNode.previousSibling = childNode3;
                }
                childNode3.ownerNode = attrImpl2;
                childNode3.isOwned(true);
                childNode3.nextSibling = childNode;
                childNode = childNode3;
                i3 = getPrevSibling(i4);
            }
            if (childNode2 != null) {
                attrImpl2.value = childNode;
                childNode.isFirstChild(true);
                attrImpl2.lastChild(childNode2);
            }
            attrImpl2.hasStringValue(false);
        }
        setMutationEvents(mutationEvents);
    }

    /* access modifiers changed from: protected */
    public final void synchronizeChildren(ParentNode parentNode, int i) {
        ParentNode parentNode2 = parentNode;
        boolean mutationEvents = getMutationEvents();
        setMutationEvents(false);
        parentNode2.needsSyncChildren(false);
        ChildNode childNode = null;
        ChildNode childNode2 = null;
        int lastChild = getLastChild(i);
        while (true) {
            int i2 = lastChild;
            if (i2 == -1) {
                break;
            }
            ChildNode childNode3 = (ChildNode) getNodeObject(i2);
            if (childNode2 == null) {
                childNode2 = childNode3;
            } else {
                childNode.previousSibling = childNode3;
            }
            childNode3.ownerNode = parentNode2;
            childNode3.isOwned(true);
            childNode3.nextSibling = childNode;
            childNode = childNode3;
            lastChild = getPrevSibling(i2);
        }
        if (childNode2 != null) {
            parentNode2.firstChild = childNode;
            childNode.isFirstChild(true);
            parentNode2.lastChild(childNode2);
        }
        setMutationEvents(mutationEvents);
    }

    /* access modifiers changed from: protected */
    public void synchronizeData() {
        IntVector intVector;
        needsSyncData(false);
        if (this.fIdElement != null) {
            new IntVector();
            IntVector intVector2 = intVector;
            int i = 0;
            while (i < this.fIdCount) {
                int i2 = this.fIdElement[i];
                String str = this.fIdName[i];
                if (str != null) {
                    intVector2.removeAllElements();
                    int i3 = i2;
                    do {
                        intVector2.addElement(i3);
                        i3 = getChunkIndex(this.fNodeParent, i3 >> CHUNK_SHIFT, i3 & CHUNK_MASK);
                    } while (i3 != -1);
                    Node node = this;
                    for (int size = intVector2.size() - 2; size >= 0; size--) {
                        int elementAt = intVector2.elementAt(size);
                        Node lastChild = node.getLastChild();
                        while (true) {
                            Node node2 = lastChild;
                            if (node2 != null) {
                                if ((node2 instanceof DeferredNode) && ((DeferredNode) node2).getNodeIndex() == elementAt) {
                                    node = node2;
                                    break;
                                }
                                lastChild = node2.getPreviousSibling();
                            } else {
                                break;
                            }
                        }
                    }
                    Element element = (Element) node;
                    putIdentifier0(str, element);
                    this.fIdName[i] = null;
                    while (i + 1 < this.fIdCount && this.fIdElement[i + 1] == i2) {
                        i++;
                        String str2 = this.fIdName[i];
                        if (str2 != null) {
                            putIdentifier0(str2, element);
                        }
                    }
                }
                i++;
            }
        }
    }
}
