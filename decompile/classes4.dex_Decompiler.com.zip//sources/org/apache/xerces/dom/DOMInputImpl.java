package org.apache.xerces.dom;

import java.io.InputStream;
import java.io.Reader;
import org.w3c.dom.ls.LSInput;

public class DOMInputImpl implements LSInput {
    protected String fBaseSystemId = null;
    protected InputStream fByteStream = null;
    protected boolean fCertifiedText = false;
    protected Reader fCharStream = null;
    protected String fData = null;
    protected String fEncoding = null;
    protected String fPublicId = null;
    protected String fSystemId = null;

    public DOMInputImpl() {
    }

    public DOMInputImpl(String str, String str2, String str3) {
        this.fPublicId = str;
        this.fSystemId = str2;
        this.fBaseSystemId = str3;
    }

    public DOMInputImpl(String str, String str2, String str3, InputStream inputStream, String str4) {
        this.fPublicId = str;
        this.fSystemId = str2;
        this.fBaseSystemId = str3;
        this.fByteStream = inputStream;
        this.fEncoding = str4;
    }

    public DOMInputImpl(String str, String str2, String str3, Reader reader, String str4) {
        this.fPublicId = str;
        this.fSystemId = str2;
        this.fBaseSystemId = str3;
        this.fCharStream = reader;
        this.fEncoding = str4;
    }

    public DOMInputImpl(String str, String str2, String str3, String str4, String str5) {
        this.fPublicId = str;
        this.fSystemId = str2;
        this.fBaseSystemId = str3;
        this.fData = str4;
        this.fEncoding = str5;
    }

    public String getBaseURI() {
        return this.fBaseSystemId;
    }

    public InputStream getByteStream() {
        return this.fByteStream;
    }

    public boolean getCertifiedText() {
        return this.fCertifiedText;
    }

    public Reader getCharacterStream() {
        return this.fCharStream;
    }

    public String getEncoding() {
        return this.fEncoding;
    }

    public String getPublicId() {
        return this.fPublicId;
    }

    public String getStringData() {
        return this.fData;
    }

    public String getSystemId() {
        return this.fSystemId;
    }

    public void setBaseURI(String str) {
        String str2 = str;
        this.fBaseSystemId = str2;
    }

    public void setByteStream(InputStream inputStream) {
        InputStream inputStream2 = inputStream;
        this.fByteStream = inputStream2;
    }

    public void setCertifiedText(boolean z) {
        boolean z2 = z;
        this.fCertifiedText = z2;
    }

    public void setCharacterStream(Reader reader) {
        Reader reader2 = reader;
        this.fCharStream = reader2;
    }

    public void setEncoding(String str) {
        String str2 = str;
        this.fEncoding = str2;
    }

    public void setPublicId(String str) {
        String str2 = str;
        this.fPublicId = str2;
    }

    public void setStringData(String str) {
        String str2 = str;
        this.fData = str2;
    }

    public void setSystemId(String str) {
        String str2 = str;
        this.fSystemId = str2;
    }
}
