package org.apache.xerces.dom;

import org.apache.xerces.util.URI;
import org.w3c.dom.DOMException;
import org.w3c.dom.Notation;

public class NotationImpl extends NodeImpl implements Notation {
    static final long serialVersionUID = -764632195890658402L;
    protected String baseURI;
    protected String name;
    protected String publicId;
    protected String systemId;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NotationImpl(CoreDocumentImpl coreDocumentImpl, String str) {
        super(coreDocumentImpl);
        this.name = str;
    }

    public String getBaseURI() {
        URI uri;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.baseURI == null || this.baseURI.length() == 0) {
            return this.baseURI;
        }
        try {
            new URI(this.baseURI);
            return uri.toString();
        } catch (URI.MalformedURIException e) {
            URI.MalformedURIException malformedURIException = e;
            return null;
        }
    }

    public String getNodeName() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.name;
    }

    public short getNodeType() {
        return 12;
    }

    public String getPublicId() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.publicId;
    }

    public String getSystemId() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.systemId;
    }

    public void setBaseURI(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        this.baseURI = str2;
    }

    public void setPublicId(String str) {
        Throwable th;
        String str2 = str;
        if (isReadOnly()) {
            Throwable th2 = th;
            new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
            throw th2;
        }
        if (needsSyncData()) {
            synchronizeData();
        }
        this.publicId = str2;
    }

    public void setSystemId(String str) {
        Throwable th;
        String str2 = str;
        if (isReadOnly()) {
            Throwable th2 = th;
            new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
            throw th2;
        }
        if (needsSyncData()) {
            synchronizeData();
        }
        this.systemId = str2;
    }
}
