package org.apache.xerces.dom;

import org.apache.xerces.xni.parser.XMLParseException;
import org.w3c.dom.DOMError;
import org.w3c.dom.DOMLocator;

public class DOMErrorImpl implements DOMError {
    public Exception fException;
    public DOMLocatorImpl fLocator;
    public String fMessage = null;
    public Object fRelatedData;
    public short fSeverity = 1;
    public String fType;

    public DOMErrorImpl() {
        DOMLocatorImpl dOMLocatorImpl;
        new DOMLocatorImpl();
        this.fLocator = dOMLocatorImpl;
        this.fException = null;
    }

    public DOMErrorImpl(short s, XMLParseException xMLParseException) {
        DOMLocatorImpl dOMLocatorImpl;
        XMLParseException xMLParseException2 = xMLParseException;
        new DOMLocatorImpl();
        this.fLocator = dOMLocatorImpl;
        this.fException = null;
        this.fSeverity = s;
        this.fException = xMLParseException2;
        this.fLocator = createDOMLocator(xMLParseException2);
    }

    private DOMLocatorImpl createDOMLocator(XMLParseException xMLParseException) {
        DOMLocatorImpl dOMLocatorImpl;
        XMLParseException xMLParseException2 = xMLParseException;
        new DOMLocatorImpl(xMLParseException2.getLineNumber(), xMLParseException2.getColumnNumber(), xMLParseException2.getCharacterOffset(), xMLParseException2.getExpandedSystemId());
        return dOMLocatorImpl;
    }

    public DOMLocator getLocation() {
        return this.fLocator;
    }

    public String getMessage() {
        return this.fMessage;
    }

    public Object getRelatedData() {
        return this.fRelatedData;
    }

    public Object getRelatedException() {
        return this.fException;
    }

    public short getSeverity() {
        return this.fSeverity;
    }

    public String getType() {
        return this.fType;
    }

    public void reset() {
        this.fSeverity = 1;
        this.fException = null;
    }
}
