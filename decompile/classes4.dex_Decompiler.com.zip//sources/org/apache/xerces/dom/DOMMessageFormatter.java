package org.apache.xerces.dom;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class DOMMessageFormatter {
    public static final String DOM_DOMAIN = "http://www.w3.org/dom/DOMTR";
    public static final String SERIALIZER_DOMAIN = "http://apache.org/xml/serializer";
    public static final String XML_DOMAIN = "http://www.w3.org/TR/1998/REC-xml-19980210";
    private static ResourceBundle domResourceBundle = null;
    private static Locale locale = null;
    private static ResourceBundle serResourceBundle = null;
    private static ResourceBundle xmlResourceBundle = null;

    DOMMessageFormatter() {
        locale = Locale.getDefault();
    }

    public static String formatMessage(String str, String str2, Object[] objArr) throws MissingResourceException {
        Throwable th;
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        StringBuffer stringBuffer3;
        Throwable th2;
        StringBuffer stringBuffer4;
        String str3 = str;
        String str4 = str2;
        Object[] objArr2 = objArr;
        ResourceBundle resourceBundle = getResourceBundle(str3);
        if (resourceBundle == null) {
            init();
            resourceBundle = getResourceBundle(str3);
            if (resourceBundle == null) {
                Throwable th3 = th2;
                new StringBuffer();
                new MissingResourceException(stringBuffer4.append("Unknown domain").append(str3).toString(), (String) null, str4);
                throw th3;
            }
        }
        try {
            new StringBuffer();
            String stringBuffer5 = stringBuffer.append(str4).append(": ").append(resourceBundle.getString(str4)).toString();
            if (objArr2 != null) {
                try {
                    stringBuffer5 = MessageFormat.format(stringBuffer5, objArr2);
                } catch (Exception e) {
                    Exception exc = e;
                    String string = resourceBundle.getString("FormatFailed");
                    new StringBuffer();
                    stringBuffer5 = stringBuffer3.append(string).append(" ").append(resourceBundle.getString(str4)).toString();
                }
            }
            if (stringBuffer5 == null) {
                stringBuffer5 = str4;
                if (objArr2.length > 0) {
                    new StringBuffer(stringBuffer5);
                    StringBuffer stringBuffer6 = stringBuffer2;
                    StringBuffer append = stringBuffer6.append('?');
                    for (int i = 0; i < objArr2.length; i++) {
                        if (i > 0) {
                            StringBuffer append2 = stringBuffer6.append('&');
                        }
                        StringBuffer append3 = stringBuffer6.append(String.valueOf(objArr2[i]));
                    }
                }
            }
            return stringBuffer5;
        } catch (MissingResourceException e2) {
            MissingResourceException missingResourceException = e2;
            Throwable th4 = th;
            new MissingResourceException(str4, resourceBundle.getString("BadMessageKey"), str4);
            throw th4;
        }
    }

    static ResourceBundle getResourceBundle(String str) {
        String str2 = str;
        if (str2 == DOM_DOMAIN || str2.equals(DOM_DOMAIN)) {
            return domResourceBundle;
        }
        if (str2 == XML_DOMAIN || str2.equals(XML_DOMAIN)) {
            return xmlResourceBundle;
        }
        if (str2 == SERIALIZER_DOMAIN || str2.equals(SERIALIZER_DOMAIN)) {
            return serResourceBundle;
        }
        return null;
    }

    public static void init() {
        Locale locale2 = locale;
        if (locale2 == null) {
            locale2 = Locale.getDefault();
        }
        domResourceBundle = ResourceBundle.getBundle("org.apache.xerces.impl.msg.DOMMessages", locale2);
        serResourceBundle = ResourceBundle.getBundle("org.apache.xerces.impl.msg.XMLSerializerMessages", locale2);
        xmlResourceBundle = ResourceBundle.getBundle("org.apache.xerces.impl.msg.XMLMessages", locale2);
    }

    public static void setLocale(Locale locale2) {
        locale = locale2;
    }
}
