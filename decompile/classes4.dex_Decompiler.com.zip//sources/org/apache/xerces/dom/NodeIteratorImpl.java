package org.apache.xerces.dom;

import org.w3c.dom.DOMException;
import org.w3c.dom.Node;
import org.w3c.dom.traversal.NodeFilter;
import org.w3c.dom.traversal.NodeIterator;

public class NodeIteratorImpl implements NodeIterator {
    private Node fCurrentNode;
    private boolean fDetach = false;
    private DocumentImpl fDocument;
    private boolean fEntityReferenceExpansion;
    private boolean fForward = true;
    private NodeFilter fNodeFilter;
    private Node fRoot;
    private int fWhatToShow = -1;

    public NodeIteratorImpl(DocumentImpl documentImpl, Node node, int i, NodeFilter nodeFilter, boolean z) {
        this.fDocument = documentImpl;
        this.fRoot = node;
        this.fCurrentNode = null;
        this.fWhatToShow = i;
        this.fNodeFilter = nodeFilter;
        this.fEntityReferenceExpansion = z;
    }

    /* access modifiers changed from: package-private */
    public boolean acceptNode(Node node) {
        Node node2 = node;
        if (this.fNodeFilter == null) {
            return (this.fWhatToShow & (1 << (node2.getNodeType() + -1))) != 0;
        }
        return (this.fWhatToShow & (1 << (node2.getNodeType() + -1))) != 0 && this.fNodeFilter.acceptNode(node2) == 1;
    }

    public void detach() {
        this.fDetach = true;
        this.fDocument.removeNodeIterator(this);
    }

    public boolean getExpandEntityReferences() {
        return this.fEntityReferenceExpansion;
    }

    public NodeFilter getFilter() {
        return this.fNodeFilter;
    }

    public Node getRoot() {
        return this.fRoot;
    }

    public int getWhatToShow() {
        return this.fWhatToShow;
    }

    /* access modifiers changed from: package-private */
    public Node matchNodeOrParent(Node node) {
        Node node2 = node;
        if (this.fCurrentNode == null) {
            return null;
        }
        Node node3 = this.fCurrentNode;
        while (true) {
            Node node4 = node3;
            if (node4 == this.fRoot) {
                return null;
            }
            if (node2 == node4) {
                return node4;
            }
            node3 = node4.getParentNode();
        }
    }

    public Node nextNode() {
        Throwable th;
        if (this.fDetach) {
            Throwable th2 = th;
            new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
            throw th2;
        } else if (this.fRoot == null) {
            return null;
        } else {
            Node node = this.fCurrentNode;
            boolean z = false;
            while (!z) {
                node = (this.fForward || node == null) ? (this.fEntityReferenceExpansion || node == null || node.getNodeType() != 5) ? nextNode(node, true) : nextNode(node, false) : this.fCurrentNode;
                this.fForward = true;
                if (node == null) {
                    return null;
                }
                z = acceptNode(node);
                if (z) {
                    this.fCurrentNode = node;
                    return this.fCurrentNode;
                }
            }
            return null;
        }
    }

    /* access modifiers changed from: package-private */
    public Node nextNode(Node node, boolean z) {
        Node node2 = node;
        boolean z2 = z;
        if (node2 == null) {
            return this.fRoot;
        }
        if (z2 && node2.hasChildNodes()) {
            return node2.getFirstChild();
        }
        if (node2 == this.fRoot) {
            return null;
        }
        Node nextSibling = node2.getNextSibling();
        if (nextSibling != null) {
            return nextSibling;
        }
        Node parentNode = node2.getParentNode();
        while (true) {
            Node node3 = parentNode;
            if (node3 != null && node3 != this.fRoot) {
                Node nextSibling2 = node3.getNextSibling();
                if (nextSibling2 != null) {
                    return nextSibling2;
                }
                parentNode = node3.getParentNode();
            }
        }
        return null;
    }

    public Node previousNode() {
        Throwable th;
        if (this.fDetach) {
            Throwable th2 = th;
            new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
            throw th2;
        } else if (this.fRoot == null || this.fCurrentNode == null) {
            return null;
        } else {
            Node node = this.fCurrentNode;
            boolean z = false;
            while (!z) {
                node = (!this.fForward || node == null) ? previousNode(node) : this.fCurrentNode;
                this.fForward = false;
                if (node == null) {
                    return null;
                }
                z = acceptNode(node);
                if (z) {
                    this.fCurrentNode = node;
                    return this.fCurrentNode;
                }
            }
            return null;
        }
    }

    /* access modifiers changed from: package-private */
    public Node previousNode(Node node) {
        Node node2 = node;
        if (node2 == this.fRoot) {
            return null;
        }
        Node previousSibling = node2.getPreviousSibling();
        if (previousSibling == null) {
            return node2.getParentNode();
        }
        if (previousSibling.hasChildNodes() && (this.fEntityReferenceExpansion || previousSibling == null || previousSibling.getNodeType() != 5)) {
            while (previousSibling.hasChildNodes()) {
                previousSibling = previousSibling.getLastChild();
            }
        }
        return previousSibling;
    }

    public void removeNode(Node node) {
        Node matchNodeOrParent;
        Node node2 = node;
        if (node2 != null && (matchNodeOrParent = matchNodeOrParent(node2)) != null) {
            if (this.fForward) {
                this.fCurrentNode = previousNode(matchNodeOrParent);
                return;
            }
            Node nextNode = nextNode(matchNodeOrParent, false);
            if (nextNode != null) {
                this.fCurrentNode = nextNode;
                return;
            }
            this.fCurrentNode = previousNode(matchNodeOrParent);
            this.fForward = true;
        }
    }
}
