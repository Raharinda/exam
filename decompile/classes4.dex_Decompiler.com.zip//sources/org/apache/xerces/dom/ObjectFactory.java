package org.apache.xerces.dom;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

final class ObjectFactory {
    private static final boolean DEBUG = isDebugEnabled();
    private static final int DEFAULT_LINE_LENGTH = 80;
    private static final String DEFAULT_PROPERTIES_FILENAME = "xerces.properties";
    static Class class$org$apache$xerces$dom$ObjectFactory;
    private static long fLastModified = -1;
    private static Properties fXercesProperties = null;

    static final class ConfigurationError extends Error {
        static final long serialVersionUID = 1914065341994951202L;
        private Exception exception;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        ConfigurationError(String str, Exception exc) {
            super(str);
            this.exception = exc;
        }

        /* access modifiers changed from: package-private */
        public Exception getException() {
            return this.exception;
        }
    }

    ObjectFactory() {
    }

    static Class class$(String str) {
        Throwable th;
        try {
            return Class.forName(str);
        } catch (ClassNotFoundException e) {
            ClassNotFoundException classNotFoundException = e;
            Throwable th2 = th;
            new NoClassDefFoundError(classNotFoundException.getMessage());
            throw th2;
        }
    }

    static Object createObject(String str, String str2) throws ConfigurationError {
        return createObject(str, (String) null, str2);
    }

    static Object createObject(String str, String str2, String str3) throws ConfigurationError {
        File file;
        Properties properties;
        StringBuffer stringBuffer;
        Throwable th;
        StringBuffer stringBuffer2;
        StringBuffer stringBuffer3;
        Class cls;
        Properties properties2;
        StringBuffer stringBuffer4;
        File file2;
        StringBuffer stringBuffer5;
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        if (DEBUG) {
            debugPrintln("debug is on");
        }
        ClassLoader findClassLoader = findClassLoader();
        try {
            String systemProperty = SecuritySupport.getSystemProperty(str4);
            if (systemProperty != null && systemProperty.length() > 0) {
                if (DEBUG) {
                    new StringBuffer();
                    debugPrintln(stringBuffer5.append("found system property, value=").append(systemProperty).toString());
                }
                return newInstance(systemProperty, findClassLoader, true);
            }
        } catch (SecurityException e) {
            SecurityException securityException = e;
        }
        String str7 = null;
        if (str5 == null) {
            File file3 = null;
            boolean z = false;
            try {
                String systemProperty2 = SecuritySupport.getSystemProperty("java.home");
                new StringBuffer();
                str5 = stringBuffer4.append(systemProperty2).append(File.separator).append("lib").append(File.separator).append(DEFAULT_PROPERTIES_FILENAME).toString();
                new File(str5);
                file3 = file2;
                z = SecuritySupport.getFileExists(file3);
            } catch (SecurityException e2) {
                SecurityException securityException2 = e2;
                fLastModified = -1;
                fXercesProperties = null;
            }
            if (class$org$apache$xerces$dom$ObjectFactory == null) {
                Class class$ = class$("org.apache.xerces.dom.ObjectFactory");
                cls = class$;
                class$org$apache$xerces$dom$ObjectFactory = class$;
            } else {
                cls = class$org$apache$xerces$dom$ObjectFactory;
            }
            Class cls2 = cls;
            synchronized (cls2) {
                boolean z2 = false;
                FileInputStream fileInputStream = null;
                try {
                    if (fLastModified >= 0) {
                        if (z) {
                            long j = fLastModified;
                            long lastModified = SecuritySupport.getLastModified(file3);
                            fLastModified = lastModified;
                            if (j < lastModified) {
                                z2 = true;
                            }
                        }
                        if (!z) {
                            fLastModified = -1;
                            fXercesProperties = null;
                        }
                    } else if (z) {
                        z2 = true;
                        fLastModified = SecuritySupport.getLastModified(file3);
                    }
                    if (z2) {
                        new Properties();
                        fXercesProperties = properties2;
                        fileInputStream = SecuritySupport.getFileInputStream(file3);
                        fXercesProperties.load(fileInputStream);
                    }
                    if (fileInputStream != null) {
                        try {
                            fileInputStream.close();
                        } catch (IOException e3) {
                            IOException iOException = e3;
                        }
                    }
                } catch (Exception e4) {
                    Exception exc = e4;
                    fXercesProperties = null;
                    fLastModified = -1;
                    if (0 != 0) {
                        FileInputStream fileInputStream2 = null;
                        try {
                            fileInputStream2.close();
                        } catch (IOException e5) {
                            IOException iOException2 = e5;
                        }
                    }
                } catch (Throwable th2) {
                    Throwable th3 = th2;
                    if (0 != 0) {
                        FileInputStream fileInputStream3 = null;
                        try {
                            fileInputStream3.close();
                        } catch (IOException e6) {
                            IOException iOException3 = e6;
                        }
                    }
                    throw th3;
                }
                try {
                } catch (Throwable th4) {
                    Throwable th5 = th4;
                    Class cls3 = cls2;
                    throw th5;
                }
            }
            if (fXercesProperties != null) {
                str7 = fXercesProperties.getProperty(str4);
            }
        } else {
            FileInputStream fileInputStream4 = null;
            try {
                new File(str5);
                fileInputStream4 = SecuritySupport.getFileInputStream(file);
                new Properties();
                Properties properties3 = properties;
                properties3.load(fileInputStream4);
                str7 = properties3.getProperty(str4);
                if (fileInputStream4 != null) {
                    try {
                        fileInputStream4.close();
                    } catch (IOException e7) {
                        IOException iOException4 = e7;
                    }
                }
            } catch (Exception e8) {
                Exception exc2 = e8;
                if (fileInputStream4 != null) {
                    try {
                        fileInputStream4.close();
                    } catch (IOException e9) {
                        IOException iOException5 = e9;
                    }
                }
            } catch (Throwable th6) {
                Throwable th7 = th6;
                if (fileInputStream4 != null) {
                    try {
                        fileInputStream4.close();
                    } catch (IOException e10) {
                        IOException iOException6 = e10;
                    }
                }
                throw th7;
            }
        }
        if (str7 != null) {
            if (DEBUG) {
                new StringBuffer();
                debugPrintln(stringBuffer3.append("found in ").append(str5).append(", value=").append(str7).toString());
            }
            return newInstance(str7, findClassLoader, true);
        }
        Object findJarServiceProvider = findJarServiceProvider(str4);
        if (findJarServiceProvider != null) {
            return findJarServiceProvider;
        }
        if (str6 == null) {
            Throwable th8 = th;
            new StringBuffer();
            new ConfigurationError(stringBuffer2.append("Provider for ").append(str4).append(" cannot be found").toString(), (Exception) null);
            throw th8;
        }
        if (DEBUG) {
            new StringBuffer();
            debugPrintln(stringBuffer.append("using fallback, value=").append(str6).toString());
        }
        return newInstance(str6, findClassLoader, true);
    }

    private static void debugPrintln(String str) {
        StringBuffer stringBuffer;
        String str2 = str;
        if (DEBUG) {
            PrintStream printStream = System.err;
            new StringBuffer();
            printStream.println(stringBuffer.append("XERCES: ").append(str2).toString());
        }
    }

    static ClassLoader findClassLoader() throws ConfigurationError {
        Class cls;
        ClassLoader contextClassLoader = SecuritySupport.getContextClassLoader();
        ClassLoader systemClassLoader = SecuritySupport.getSystemClassLoader();
        ClassLoader classLoader = systemClassLoader;
        while (true) {
            ClassLoader classLoader2 = classLoader;
            if (contextClassLoader == classLoader2) {
                if (class$org$apache$xerces$dom$ObjectFactory == null) {
                    Class class$ = class$("org.apache.xerces.dom.ObjectFactory");
                    cls = class$;
                    class$org$apache$xerces$dom$ObjectFactory = class$;
                } else {
                    cls = class$org$apache$xerces$dom$ObjectFactory;
                }
                ClassLoader classLoader3 = cls.getClassLoader();
                ClassLoader classLoader4 = systemClassLoader;
                while (true) {
                    ClassLoader classLoader5 = classLoader4;
                    if (classLoader3 == classLoader5) {
                        return systemClassLoader;
                    }
                    if (classLoader5 == null) {
                        return classLoader3;
                    }
                    classLoader4 = SecuritySupport.getParentClassLoader(classLoader5);
                }
            } else if (classLoader2 == null) {
                return contextClassLoader;
            } else {
                classLoader = SecuritySupport.getParentClassLoader(classLoader2);
            }
        }
    }

    private static Object findJarServiceProvider(String str) throws ConfigurationError {
        StringBuffer stringBuffer;
        BufferedReader bufferedReader;
        Reader reader;
        BufferedReader bufferedReader2;
        StringBuffer stringBuffer2;
        BufferedReader bufferedReader3;
        Reader reader2;
        StringBuffer stringBuffer3;
        Class cls;
        new StringBuffer();
        String stringBuffer4 = stringBuffer.append("META-INF/services/").append(str).toString();
        ClassLoader findClassLoader = findClassLoader();
        InputStream resourceAsStream = SecuritySupport.getResourceAsStream(findClassLoader, stringBuffer4);
        if (resourceAsStream == null) {
            if (class$org$apache$xerces$dom$ObjectFactory == null) {
                Class class$ = class$("org.apache.xerces.dom.ObjectFactory");
                cls = class$;
                class$org$apache$xerces$dom$ObjectFactory = class$;
            } else {
                cls = class$org$apache$xerces$dom$ObjectFactory;
            }
            ClassLoader classLoader = cls.getClassLoader();
            if (findClassLoader != classLoader) {
                findClassLoader = classLoader;
                resourceAsStream = SecuritySupport.getResourceAsStream(findClassLoader, stringBuffer4);
            }
        }
        if (resourceAsStream == null) {
            return null;
        }
        if (DEBUG) {
            new StringBuffer();
            debugPrintln(stringBuffer3.append("found jar resource=").append(stringBuffer4).append(" using ClassLoader: ").append(findClassLoader).toString());
        }
        try {
            BufferedReader bufferedReader4 = bufferedReader3;
            new InputStreamReader(resourceAsStream, "UTF-8");
            new BufferedReader(reader2, DEFAULT_LINE_LENGTH);
            bufferedReader2 = bufferedReader4;
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException unsupportedEncodingException = e;
            new InputStreamReader(resourceAsStream);
            new BufferedReader(reader, DEFAULT_LINE_LENGTH);
            bufferedReader2 = bufferedReader;
        }
        try {
            String readLine = bufferedReader2.readLine();
            try {
                bufferedReader2.close();
            } catch (IOException e2) {
                IOException iOException = e2;
            }
            if (readLine == null || "".equals(readLine)) {
                return null;
            }
            if (DEBUG) {
                new StringBuffer();
                debugPrintln(stringBuffer2.append("found in resource, value=").append(readLine).toString());
            }
            return newInstance(readLine, findClassLoader, false);
        } catch (IOException e3) {
            IOException iOException2 = e3;
            try {
                bufferedReader2.close();
            } catch (IOException e4) {
                IOException iOException3 = e4;
            }
            return null;
        } catch (Throwable th) {
            Throwable th2 = th;
            try {
                bufferedReader2.close();
            } catch (IOException e5) {
                IOException iOException4 = e5;
            }
            throw th2;
        }
    }

    static Class findProviderClass(String str, ClassLoader classLoader, boolean z) throws ClassNotFoundException, ConfigurationError {
        Class cls;
        Class<?> loadClass;
        String str2 = str;
        ClassLoader classLoader2 = classLoader;
        boolean z2 = z;
        SecurityManager securityManager = System.getSecurityManager();
        if (securityManager != null) {
            int lastIndexOf = str2.lastIndexOf(46);
            String str3 = str2;
            if (lastIndexOf != -1) {
                str3 = str2.substring(0, lastIndexOf);
            }
            securityManager.checkPackageAccess(str3);
        }
        if (classLoader2 == null) {
            loadClass = Class.forName(str2);
        } else {
            try {
                loadClass = classLoader2.loadClass(str2);
            } catch (ClassNotFoundException e) {
                ClassNotFoundException classNotFoundException = e;
                if (z2) {
                    if (class$org$apache$xerces$dom$ObjectFactory == null) {
                        Class class$ = class$("org.apache.xerces.dom.ObjectFactory");
                        cls = class$;
                        class$org$apache$xerces$dom$ObjectFactory = class$;
                    } else {
                        cls = class$org$apache$xerces$dom$ObjectFactory;
                    }
                    ClassLoader classLoader3 = cls.getClassLoader();
                    if (classLoader3 == null) {
                        loadClass = Class.forName(str2);
                    } else if (classLoader2 != classLoader3) {
                        loadClass = classLoader3.loadClass(str2);
                    } else {
                        throw classNotFoundException;
                    }
                } else {
                    throw classNotFoundException;
                }
            }
        }
        return loadClass;
    }

    private static boolean isDebugEnabled() {
        try {
            String systemProperty = SecuritySupport.getSystemProperty("xerces.debug");
            return systemProperty != null && !"false".equals(systemProperty);
        } catch (SecurityException e) {
            SecurityException securityException = e;
            return false;
        }
    }

    static Object newInstance(String str, ClassLoader classLoader, boolean z) throws ConfigurationError {
        Throwable th;
        StringBuffer stringBuffer;
        Throwable th2;
        StringBuffer stringBuffer2;
        StringBuffer stringBuffer3;
        String str2 = str;
        ClassLoader classLoader2 = classLoader;
        try {
            Class findProviderClass = findProviderClass(str2, classLoader2, z);
            Object newInstance = findProviderClass.newInstance();
            if (DEBUG) {
                new StringBuffer();
                debugPrintln(stringBuffer3.append("created new instance of ").append(findProviderClass).append(" using ClassLoader: ").append(classLoader2).toString());
            }
            return newInstance;
        } catch (ClassNotFoundException e) {
            ClassNotFoundException classNotFoundException = e;
            Throwable th3 = th2;
            new StringBuffer();
            new ConfigurationError(stringBuffer2.append("Provider ").append(str2).append(" not found").toString(), classNotFoundException);
            throw th3;
        } catch (Exception e2) {
            Exception exc = e2;
            Throwable th4 = th;
            new StringBuffer();
            new ConfigurationError(stringBuffer.append("Provider ").append(str2).append(" could not be instantiated: ").append(exc).toString(), exc);
            throw th4;
        }
    }
}
