package org.apache.xerces.dom;

import java.util.Hashtable;
import org.apache.xerces.dom.ParentNode;
import org.w3c.dom.DOMException;
import org.w3c.dom.DocumentType;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.UserDataHandler;

public class DocumentTypeImpl extends ParentNode implements DocumentType {
    static final long serialVersionUID = 7751299192316526485L;
    private int doctypeNumber;
    protected NamedNodeMapImpl elements;
    protected NamedNodeMapImpl entities;
    protected String internalSubset;
    protected String name;
    protected NamedNodeMapImpl notations;
    protected String publicID;
    protected String systemID;
    private Hashtable userData;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DocumentTypeImpl(CoreDocumentImpl coreDocumentImpl, String str) {
        super(coreDocumentImpl);
        NamedNodeMapImpl namedNodeMapImpl;
        NamedNodeMapImpl namedNodeMapImpl2;
        NamedNodeMapImpl namedNodeMapImpl3;
        this.doctypeNumber = 0;
        this.userData = null;
        this.name = str;
        new NamedNodeMapImpl(this);
        this.entities = namedNodeMapImpl;
        new NamedNodeMapImpl(this);
        this.notations = namedNodeMapImpl2;
        new NamedNodeMapImpl(this);
        this.elements = namedNodeMapImpl3;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DocumentTypeImpl(CoreDocumentImpl coreDocumentImpl, String str, String str2, String str3) {
        this(coreDocumentImpl, str);
        this.publicID = str2;
        this.systemID = str3;
    }

    public Node cloneNode(boolean z) {
        DocumentTypeImpl documentTypeImpl = (DocumentTypeImpl) super.cloneNode(z);
        documentTypeImpl.entities = this.entities.cloneMap((NodeImpl) documentTypeImpl);
        documentTypeImpl.notations = this.notations.cloneMap((NodeImpl) documentTypeImpl);
        documentTypeImpl.elements = this.elements.cloneMap((NodeImpl) documentTypeImpl);
        return documentTypeImpl;
    }

    public NamedNodeMap getElements() {
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        return this.elements;
    }

    public NamedNodeMap getEntities() {
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        return this.entities;
    }

    public String getInternalSubset() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.internalSubset;
    }

    public String getName() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.name;
    }

    public String getNodeName() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.name;
    }

    /* access modifiers changed from: protected */
    public int getNodeNumber() {
        if (getOwnerDocument() != null) {
            return super.getNodeNumber();
        }
        if (this.doctypeNumber == 0) {
            this.doctypeNumber = ((CoreDOMImplementationImpl) CoreDOMImplementationImpl.getDOMImplementation()).assignDocTypeNumber();
        }
        return this.doctypeNumber;
    }

    public short getNodeType() {
        return 10;
    }

    public NamedNodeMap getNotations() {
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        return this.notations;
    }

    public String getPublicId() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.publicID;
    }

    public String getSystemId() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.systemID;
    }

    public String getTextContent() throws DOMException {
        return null;
    }

    public Object getUserData(String str) {
        String str2 = str;
        if (this.userData == null) {
            return null;
        }
        Object obj = this.userData.get(str2);
        if (obj != null) {
            return ((ParentNode.UserDataRecord) obj).fData;
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public Hashtable getUserDataRecord() {
        return this.userData;
    }

    public boolean isEqualNode(Node node) {
        Node node2 = node;
        if (!super.isEqualNode(node2)) {
            return false;
        }
        if (needsSyncData()) {
            synchronizeData();
        }
        DocumentTypeImpl documentTypeImpl = (DocumentTypeImpl) node2;
        if ((getPublicId() == null && documentTypeImpl.getPublicId() != null) || ((getPublicId() != null && documentTypeImpl.getPublicId() == null) || ((getSystemId() == null && documentTypeImpl.getSystemId() != null) || ((getSystemId() != null && documentTypeImpl.getSystemId() == null) || ((getInternalSubset() == null && documentTypeImpl.getInternalSubset() != null) || (getInternalSubset() != null && documentTypeImpl.getInternalSubset() == null)))))) {
            return false;
        }
        if (getPublicId() != null && !getPublicId().equals(documentTypeImpl.getPublicId())) {
            return false;
        }
        if (getSystemId() != null && !getSystemId().equals(documentTypeImpl.getSystemId())) {
            return false;
        }
        if (getInternalSubset() != null && !getInternalSubset().equals(documentTypeImpl.getInternalSubset())) {
            return false;
        }
        NamedNodeMapImpl namedNodeMapImpl = documentTypeImpl.entities;
        if ((this.entities == null && namedNodeMapImpl != null) || (this.entities != null && namedNodeMapImpl == null)) {
            return false;
        }
        if (!(this.entities == null || namedNodeMapImpl == null)) {
            if (this.entities.getLength() != namedNodeMapImpl.getLength()) {
                return false;
            }
            for (int i = 0; this.entities.item(i) != null; i++) {
                Node item = this.entities.item(i);
                if (!((NodeImpl) item).isEqualNode(namedNodeMapImpl.getNamedItem(item.getNodeName()))) {
                    return false;
                }
            }
        }
        NamedNodeMapImpl namedNodeMapImpl2 = documentTypeImpl.notations;
        if ((this.notations == null && namedNodeMapImpl2 != null) || (this.notations != null && namedNodeMapImpl2 == null)) {
            return false;
        }
        if (!(this.notations == null || namedNodeMapImpl2 == null)) {
            if (this.notations.getLength() != namedNodeMapImpl2.getLength()) {
                return false;
            }
            for (int i2 = 0; this.notations.item(i2) != null; i2++) {
                Node item2 = this.notations.item(i2);
                if (!((NodeImpl) item2).isEqualNode(namedNodeMapImpl2.getNamedItem(item2.getNodeName()))) {
                    return false;
                }
            }
        }
        return true;
    }

    public void setInternalSubset(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        this.internalSubset = str2;
    }

    /* access modifiers changed from: protected */
    public void setOwnerDocument(CoreDocumentImpl coreDocumentImpl) {
        CoreDocumentImpl coreDocumentImpl2 = coreDocumentImpl;
        super.setOwnerDocument(coreDocumentImpl2);
        this.entities.setOwnerDocument(coreDocumentImpl2);
        this.notations.setOwnerDocument(coreDocumentImpl2);
        this.elements.setOwnerDocument(coreDocumentImpl2);
    }

    public void setReadOnly(boolean z, boolean z2) {
        boolean z3 = z;
        boolean z4 = z2;
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        super.setReadOnly(z3, z4);
        this.elements.setReadOnly(z3, true);
        this.entities.setReadOnly(z3, true);
        this.notations.setReadOnly(z3, true);
    }

    public void setTextContent(String str) throws DOMException {
    }

    public Object setUserData(String str, Object obj, UserDataHandler userDataHandler) {
        Object obj2;
        Object remove;
        Hashtable hashtable;
        String str2 = str;
        Object obj3 = obj;
        UserDataHandler userDataHandler2 = userDataHandler;
        if (this.userData == null) {
            new Hashtable();
            this.userData = hashtable;
        }
        if (obj3 != null) {
            new ParentNode.UserDataRecord(this, obj3, userDataHandler2);
            Object put = this.userData.put(str2, obj2);
            if (put != null) {
                return ((ParentNode.UserDataRecord) put).fData;
            }
            return null;
        } else if (this.userData == null || (remove = this.userData.remove(str2)) == null) {
            return null;
        } else {
            return ((ParentNode.UserDataRecord) remove).fData;
        }
    }
}
