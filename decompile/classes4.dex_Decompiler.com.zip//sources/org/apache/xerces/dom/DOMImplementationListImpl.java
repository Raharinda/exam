package org.apache.xerces.dom;

import java.util.ArrayList;
import java.util.Vector;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.DOMImplementationList;

public class DOMImplementationListImpl implements DOMImplementationList {
    private final ArrayList fImplementations;

    public DOMImplementationListImpl() {
        ArrayList arrayList;
        new ArrayList();
        this.fImplementations = arrayList;
    }

    public DOMImplementationListImpl(ArrayList arrayList) {
        this.fImplementations = arrayList;
    }

    public DOMImplementationListImpl(Vector vector) {
        ArrayList arrayList;
        new ArrayList(vector);
        this.fImplementations = arrayList;
    }

    public int getLength() {
        return this.fImplementations.size();
    }

    public DOMImplementation item(int i) {
        int i2 = i;
        int length = getLength();
        if (i2 < 0 || i2 >= length) {
            return null;
        }
        return (DOMImplementation) this.fImplementations.get(i2);
    }
}
