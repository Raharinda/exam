package org.apache.xerces.dom;

import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xs.XSTypeDefinition;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class DeferredElementNSImpl extends ElementNSImpl implements DeferredNode {
    static final long serialVersionUID = -5001885145370927385L;
    protected transient int fNodeIndex;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    DeferredElementNSImpl(DeferredDocumentImpl deferredDocumentImpl, int i) {
        super(deferredDocumentImpl, (String) null);
        this.fNodeIndex = i;
        needsSyncChildren(true);
    }

    public final int getNodeIndex() {
        return this.fNodeIndex;
    }

    /* access modifiers changed from: protected */
    public final void synchronizeChildren() {
        ((DeferredDocumentImpl) ownerDocument()).synchronizeChildren((ParentNode) this, this.fNodeIndex);
    }

    /* access modifiers changed from: protected */
    public final void synchronizeData() {
        needsSyncData(false);
        DeferredDocumentImpl deferredDocumentImpl = (DeferredDocumentImpl) this.ownerDocument;
        boolean z = deferredDocumentImpl.mutationEvents;
        deferredDocumentImpl.mutationEvents = false;
        this.name = deferredDocumentImpl.getNodeName(this.fNodeIndex);
        int indexOf = this.name.indexOf(58);
        if (indexOf < 0) {
            this.localName = this.name;
        } else {
            this.localName = this.name.substring(indexOf + 1);
        }
        this.namespaceURI = deferredDocumentImpl.getNodeURI(this.fNodeIndex);
        this.type = (XSTypeDefinition) deferredDocumentImpl.getTypeInfo(this.fNodeIndex);
        setupDefaultAttributes();
        int nodeExtra = deferredDocumentImpl.getNodeExtra(this.fNodeIndex);
        if (nodeExtra != -1) {
            NamedNodeMap attributes = getAttributes();
            boolean z2 = false;
            do {
                AttrImpl attrImpl = (AttrImpl) deferredDocumentImpl.getNodeObject(nodeExtra);
                if (attrImpl.getSpecified() || (!z2 && (attrImpl.getNamespaceURI() == null || attrImpl.getNamespaceURI() == NamespaceContext.XMLNS_URI || attrImpl.getName().indexOf(58) >= 0))) {
                    Node namedItem = attributes.setNamedItem(attrImpl);
                } else {
                    z2 = true;
                    Node namedItemNS = attributes.setNamedItemNS(attrImpl);
                }
                nodeExtra = deferredDocumentImpl.getPrevSibling(nodeExtra);
            } while (nodeExtra != -1);
        }
        deferredDocumentImpl.mutationEvents = z;
    }
}
