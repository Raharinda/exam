package org.apache.xerces.dom;

import com.microsoft.appcenter.Constants;
import org.apache.xerces.impl.dv.xs.XSSimpleTypeDecl;
import org.apache.xerces.impl.xs.XSComplexTypeDecl;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xs.XSTypeDefinition;
import org.apache.xml.serialize.Method;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;

public class ElementNSImpl extends ElementImpl {
    static final long serialVersionUID = -9142310625494392642L;
    static final String xmlURI = "http://www.w3.org/XML/1998/namespace";
    protected String localName;
    protected String namespaceURI;
    transient XSTypeDefinition type;

    protected ElementNSImpl() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected ElementNSImpl(CoreDocumentImpl coreDocumentImpl, String str) {
        super(coreDocumentImpl, str);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected ElementNSImpl(org.apache.xerces.dom.CoreDocumentImpl r8, java.lang.String r9, java.lang.String r10) throws org.w3c.dom.DOMException {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r2 = r9
            r3 = r10
            r4 = r0
            r5 = r1
            r6 = r3
            r4.<init>(r5, r6)
            r4 = r0
            r5 = r2
            r6 = r3
            r4.setName(r5, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.ElementNSImpl.<init>(org.apache.xerces.dom.CoreDocumentImpl, java.lang.String, java.lang.String):void");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected ElementNSImpl(CoreDocumentImpl coreDocumentImpl, String str, String str2, String str3) throws DOMException {
        super(coreDocumentImpl, str2);
        this.localName = str3;
        this.namespaceURI = str;
    }

    private void setName(String str, String str2) {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str3 = str;
        String str4 = str2;
        this.namespaceURI = str3;
        if (str3 != null) {
            this.namespaceURI = str3.length() == 0 ? null : str3;
        }
        if (str4 == null) {
            Throwable th4 = th3;
            new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
            throw th4;
        }
        int indexOf = str4.indexOf(58);
        int lastIndexOf = str4.lastIndexOf(58);
        this.ownerDocument.checkNamespaceWF(str4, indexOf, lastIndexOf);
        if (indexOf < 0) {
            this.localName = str4;
            if (this.ownerDocument.errorChecking) {
                this.ownerDocument.checkQName((String) null, this.localName);
                if ((str4.equals("xmlns") && (str3 == null || !str3.equals(NamespaceContext.XMLNS_URI))) || (str3 != null && str3.equals(NamespaceContext.XMLNS_URI) && !str4.equals("xmlns"))) {
                    Throwable th5 = th2;
                    new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
                    throw th5;
                }
                return;
            }
            return;
        }
        String substring = str4.substring(0, indexOf);
        this.localName = str4.substring(lastIndexOf + 1);
        if (!this.ownerDocument.errorChecking) {
            return;
        }
        if (str3 == null || (substring.equals(Method.XML) && !str3.equals(NamespaceContext.XML_URI))) {
            Throwable th6 = th;
            new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
            throw th6;
        }
        this.ownerDocument.checkQName(substring, this.localName);
        this.ownerDocument.checkDOMNSErr(substring, str3);
    }

    public String getLocalName() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.localName;
    }

    public String getNamespaceURI() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.namespaceURI;
    }

    public String getPrefix() {
        if (needsSyncData()) {
            synchronizeData();
        }
        int indexOf = this.name.indexOf(58);
        return indexOf < 0 ? null : this.name.substring(0, indexOf);
    }

    public String getTypeName() {
        if (this.type != null) {
            if (this.type instanceof XSSimpleTypeDecl) {
                return this.type.getTypeName();
            }
            if (this.type instanceof XSComplexTypeDecl) {
                return this.type.getTypeName();
            }
        }
        return null;
    }

    public String getTypeNamespace() {
        if (this.type != null) {
            return this.type.getNamespace();
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public Attr getXMLBaseAttribute() {
        return (Attr) this.attributes.getNamedItemNS(xmlURI, "base");
    }

    public boolean isDerivedFrom(String str, String str2, int i) {
        String str3 = str;
        String str4 = str2;
        int i2 = i;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.type != null) {
            if (this.type instanceof XSSimpleTypeDecl) {
                return this.type.isDOMDerivedFrom(str3, str4, i2);
            }
            if (this.type instanceof XSComplexTypeDecl) {
                return this.type.isDOMDerivedFrom(str3, str4, i2);
            }
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    public void rename(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        if (needsSyncData()) {
            synchronizeData();
        }
        this.name = str4;
        setName(str3, str4);
        reconcileDefaultAttributes();
    }

    public void setPrefix(String str) throws DOMException {
        StringBuffer stringBuffer;
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.ownerDocument.errorChecking) {
            if (isReadOnly()) {
                Throwable th5 = th4;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th5;
            } else if (!(str2 == null || str2.length() == 0)) {
                if (!CoreDocumentImpl.isXMLName(str2, this.ownerDocument.isXML11Version())) {
                    Throwable th6 = th3;
                    new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
                    throw th6;
                } else if (this.namespaceURI == null || str2.indexOf(58) >= 0) {
                    Throwable th7 = th;
                    new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
                    throw th7;
                } else if (str2.equals(Method.XML) && !this.namespaceURI.equals(xmlURI)) {
                    Throwable th8 = th2;
                    new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
                    throw th8;
                }
            }
        }
        if (str2 == null || str2.length() == 0) {
            this.name = this.localName;
            return;
        }
        new StringBuffer();
        this.name = stringBuffer.append(str2).append(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR).append(this.localName).toString();
    }

    public void setType(XSTypeDefinition xSTypeDefinition) {
        XSTypeDefinition xSTypeDefinition2 = xSTypeDefinition;
        this.type = xSTypeDefinition2;
    }
}
