package org.apache.xerces.dom;

import org.w3c.dom.ranges.RangeException;

public class RangeExceptionImpl extends RangeException {
    static final long serialVersionUID = -9058052627467240856L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public RangeExceptionImpl(short s, String str) {
        super(s, str);
    }
}
