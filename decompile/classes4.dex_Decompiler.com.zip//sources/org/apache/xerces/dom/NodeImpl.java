package org.apache.xerces.dom;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Hashtable;
import net.lingala.zip4j.util.Zip4jConstants;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.UserDataHandler;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventListener;
import org.w3c.dom.events.EventTarget;

public abstract class NodeImpl implements Node, NodeList, EventTarget, Cloneable, Serializable {
    public static final short DOCUMENT_POSITION_CONTAINS = 8;
    public static final short DOCUMENT_POSITION_DISCONNECTED = 1;
    public static final short DOCUMENT_POSITION_FOLLOWING = 4;
    public static final short DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC = 32;
    public static final short DOCUMENT_POSITION_IS_CONTAINED = 16;
    public static final short DOCUMENT_POSITION_PRECEDING = 2;
    public static final short ELEMENT_DEFINITION_NODE = 21;
    protected static final short FIRSTCHILD = 16;
    protected static final short HASSTRING = 128;
    protected static final short ID = 512;
    protected static final short IGNORABLEWS = 64;
    protected static final short NORMALIZED = 256;
    protected static final short OWNED = 8;
    protected static final short READONLY = 1;
    protected static final short SPECIFIED = 32;
    protected static final short SYNCCHILDREN = 4;
    protected static final short SYNCDATA = 2;
    public static final short TREE_POSITION_ANCESTOR = 4;
    public static final short TREE_POSITION_DESCENDANT = 8;
    public static final short TREE_POSITION_DISCONNECTED = 0;
    public static final short TREE_POSITION_EQUIVALENT = 16;
    public static final short TREE_POSITION_FOLLOWING = 2;
    public static final short TREE_POSITION_PRECEDING = 1;
    public static final short TREE_POSITION_SAME_NODE = 32;
    static final long serialVersionUID = -6316591992167219696L;
    protected short flags;
    protected NodeImpl ownerNode;

    public NodeImpl() {
    }

    protected NodeImpl(CoreDocumentImpl coreDocumentImpl) {
        this.ownerNode = coreDocumentImpl;
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        ObjectOutputStream objectOutputStream2 = objectOutputStream;
        if (needsSyncData()) {
            synchronizeData();
        }
        objectOutputStream2.defaultWriteObject();
    }

    public void addEventListener(String str, EventListener eventListener, boolean z) {
        ownerDocument().addEventListener(this, str, eventListener, z);
    }

    public Node appendChild(Node node) throws DOMException {
        return insertBefore(node, (Node) null);
    }

    /* access modifiers changed from: protected */
    public void changed() {
        ownerDocument().changed();
    }

    /* access modifiers changed from: protected */
    public int changes() {
        return ownerDocument().changes();
    }

    public Node cloneNode(boolean z) {
        Throwable th;
        StringBuffer stringBuffer;
        boolean z2 = z;
        if (needsSyncData()) {
            synchronizeData();
        }
        try {
            NodeImpl nodeImpl = (NodeImpl) clone();
            nodeImpl.ownerNode = ownerDocument();
            nodeImpl.isOwned(false);
            nodeImpl.isReadOnly(false);
            ownerDocument().callUserDataHandlers(this, nodeImpl, 1);
            return nodeImpl;
        } catch (CloneNotSupportedException e) {
            CloneNotSupportedException cloneNotSupportedException = e;
            Throwable th2 = th;
            new StringBuffer();
            new RuntimeException(stringBuffer.append("**Internal Error**").append(cloneNotSupportedException).toString());
            throw th2;
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v0, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v16, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v1, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v19, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v0, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v1, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v34, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v2, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v3, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v2, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r15v0, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v4, resolved type: org.w3c.dom.Document} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v2, resolved type: org.w3c.dom.Document} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v3, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v3, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v5, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v87, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r19v20, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v16, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v6, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v7, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v4, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v111, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r15v3, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v8, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v5, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v115, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v6, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v9, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v10, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v134, resolved type: org.w3c.dom.Document} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v11, resolved type: org.apache.xerces.dom.AttrImpl} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v7, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v8, resolved type: org.w3c.dom.Node} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r18v160, resolved type: org.w3c.dom.Node} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public short compareDocumentPosition(org.w3c.dom.Node r24) throws org.w3c.dom.DOMException {
        /*
            r23 = this;
            r2 = r23
            r3 = r24
            r18 = r2
            r19 = r3
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x0013
            r18 = 0
            r2 = r18
        L_0x0012:
            return r2
        L_0x0013:
            r18 = r3
            if (r18 == 0) goto L_0x003f
            r18 = r3
            r0 = r18
            boolean r0 = r0 instanceof org.apache.xerces.dom.NodeImpl
            r18 = r0
            if (r18 != 0) goto L_0x003f
            java.lang.String r18 = "http://www.w3.org/dom/DOMTR"
            java.lang.String r19 = "NOT_SUPPORTED_ERR"
            r20 = 0
            java.lang.String r18 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r18, r19, r20)
            r4 = r18
            org.w3c.dom.DOMException r18 = new org.w3c.dom.DOMException
            r22 = r18
            r18 = r22
            r19 = r22
            r20 = 9
            r21 = r4
            r19.<init>(r20, r21)
            throw r18
        L_0x003f:
            r18 = r2
            short r18 = r18.getNodeType()
            r19 = 9
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x009d
            r18 = r2
            org.w3c.dom.Document r18 = (org.w3c.dom.Document) r18
            r4 = r18
        L_0x0053:
            r18 = r3
            short r18 = r18.getNodeType()
            r19 = 9
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x00a6
            r18 = r3
            org.w3c.dom.Document r18 = (org.w3c.dom.Document) r18
            r5 = r18
        L_0x0067:
            r18 = r4
            r19 = r5
            r0 = r18
            r1 = r19
            if (r0 == r1) goto L_0x00b5
            r18 = r4
            if (r18 == 0) goto L_0x00b5
            r18 = r5
            if (r18 == 0) goto L_0x00b5
            r18 = r5
            org.apache.xerces.dom.CoreDocumentImpl r18 = (org.apache.xerces.dom.CoreDocumentImpl) r18
            int r18 = r18.getNodeNumber()
            r6 = r18
            r18 = r4
            org.apache.xerces.dom.CoreDocumentImpl r18 = (org.apache.xerces.dom.CoreDocumentImpl) r18
            int r18 = r18.getNodeNumber()
            r7 = r18
            r18 = r6
            r19 = r7
            r0 = r18
            r1 = r19
            if (r0 <= r1) goto L_0x00af
            r18 = 37
            r2 = r18
            goto L_0x0012
        L_0x009d:
            r18 = r2
            org.w3c.dom.Document r18 = r18.getOwnerDocument()
            r4 = r18
            goto L_0x0053
        L_0x00a6:
            r18 = r3
            org.w3c.dom.Document r18 = r18.getOwnerDocument()
            r5 = r18
            goto L_0x0067
        L_0x00af:
            r18 = 35
            r2 = r18
            goto L_0x0012
        L_0x00b5:
            r18 = r2
            r7 = r18
            r18 = r3
            r8 = r18
            r18 = 0
            r9 = r18
            r18 = 0
            r10 = r18
            r18 = r2
            r6 = r18
        L_0x00c9:
            r18 = r6
            if (r18 != 0) goto L_0x0125
            r18 = r3
            r6 = r18
        L_0x00d1:
            r18 = r6
            if (r18 != 0) goto L_0x0144
            r18 = r7
            short r18 = r18.getNodeType()
            r11 = r18
            r18 = r8
            short r18 = r18.getNodeType()
            r12 = r18
            r18 = r2
            r13 = r18
            r18 = r3
            r14 = r18
            r18 = r11
            switch(r18) {
                case 2: goto L_0x0216;
                case 6: goto L_0x0164;
                case 10: goto L_0x01f2;
                case 12: goto L_0x0164;
                default: goto L_0x00f2;
            }
        L_0x00f2:
            r18 = r12
            switch(r18) {
                case 2: goto L_0x02d1;
                case 6: goto L_0x0287;
                case 10: goto L_0x02ad;
                case 12: goto L_0x0287;
                default: goto L_0x00f7;
            }
        L_0x00f7:
            r18 = r7
            r19 = r8
            r0 = r18
            r1 = r19
            if (r0 == r1) goto L_0x030c
            r18 = r7
            org.apache.xerces.dom.NodeImpl r18 = (org.apache.xerces.dom.NodeImpl) r18
            int r18 = r18.getNodeNumber()
            r15 = r18
            r18 = r8
            org.apache.xerces.dom.NodeImpl r18 = (org.apache.xerces.dom.NodeImpl) r18
            int r18 = r18.getNodeNumber()
            r16 = r18
            r18 = r15
            r19 = r16
            r0 = r18
            r1 = r19
            if (r0 <= r1) goto L_0x0306
            r18 = 37
            r2 = r18
            goto L_0x0012
        L_0x0125:
            int r9 = r9 + 1
            r18 = r6
            r19 = r3
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x0137
            r18 = 10
            r2 = r18
            goto L_0x0012
        L_0x0137:
            r18 = r6
            r7 = r18
            r18 = r6
            org.w3c.dom.Node r18 = r18.getParentNode()
            r6 = r18
            goto L_0x00c9
        L_0x0144:
            int r10 = r10 + 1
            r18 = r6
            r19 = r2
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x0156
            r18 = 20
            r2 = r18
            goto L_0x0012
        L_0x0156:
            r18 = r6
            r8 = r18
            r18 = r6
            org.w3c.dom.Node r18 = r18.getParentNode()
            r6 = r18
            goto L_0x00d1
        L_0x0164:
            r18 = r4
            org.w3c.dom.DocumentType r18 = r18.getDoctype()
            r15 = r18
            r18 = r15
            r19 = r8
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x017c
            r18 = 10
            r2 = r18
            goto L_0x0012
        L_0x017c:
            r18 = r12
            switch(r18) {
                case 6: goto L_0x018f;
                case 12: goto L_0x018f;
                default: goto L_0x0181;
            }
        L_0x0181:
            r18 = r4
            r22 = r18
            r18 = r22
            r19 = r22
            r7 = r19
            r13 = r18
            goto L_0x00f2
        L_0x018f:
            r18 = r11
            r19 = r12
            r0 = r18
            r1 = r19
            if (r0 == r1) goto L_0x01ac
            r18 = r11
            r19 = r12
            r0 = r18
            r1 = r19
            if (r0 <= r1) goto L_0x01a9
            r18 = 2
        L_0x01a5:
            r2 = r18
            goto L_0x0012
        L_0x01a9:
            r18 = 4
            goto L_0x01a5
        L_0x01ac:
            r18 = r11
            r19 = 12
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x01d4
            r18 = r15
            org.w3c.dom.NamedNodeMap r18 = r18.getNotations()
            org.apache.xerces.dom.NamedNodeMapImpl r18 = (org.apache.xerces.dom.NamedNodeMapImpl) r18
            r19 = r8
            r20 = r7
            boolean r18 = r18.precedes(r19, r20)
            if (r18 == 0) goto L_0x01ce
            r18 = 34
            r2 = r18
            goto L_0x0012
        L_0x01ce:
            r18 = 36
            r2 = r18
            goto L_0x0012
        L_0x01d4:
            r18 = r15
            org.w3c.dom.NamedNodeMap r18 = r18.getEntities()
            org.apache.xerces.dom.NamedNodeMapImpl r18 = (org.apache.xerces.dom.NamedNodeMapImpl) r18
            r19 = r8
            r20 = r7
            boolean r18 = r18.precedes(r19, r20)
            if (r18 == 0) goto L_0x01ec
            r18 = 34
            r2 = r18
            goto L_0x0012
        L_0x01ec:
            r18 = 36
            r2 = r18
            goto L_0x0012
        L_0x01f2:
            r18 = r14
            r19 = r4
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x0202
            r18 = 10
            r2 = r18
            goto L_0x0012
        L_0x0202:
            r18 = r4
            if (r18 == 0) goto L_0x00f2
            r18 = r4
            r19 = r5
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x00f2
            r18 = 4
            r2 = r18
            goto L_0x0012
        L_0x0216:
            r18 = r7
            org.apache.xerces.dom.AttrImpl r18 = (org.apache.xerces.dom.AttrImpl) r18
            org.w3c.dom.Element r18 = r18.getOwnerElement()
            r13 = r18
            r18 = r12
            r19 = 2
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x025c
            r18 = r8
            org.apache.xerces.dom.AttrImpl r18 = (org.apache.xerces.dom.AttrImpl) r18
            org.w3c.dom.Element r18 = r18.getOwnerElement()
            r14 = r18
            r18 = r14
            r19 = r13
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x025c
            r18 = r13
            org.w3c.dom.NamedNodeMap r18 = r18.getAttributes()
            org.apache.xerces.dom.NamedNodeMapImpl r18 = (org.apache.xerces.dom.NamedNodeMapImpl) r18
            r19 = r3
            r20 = r2
            boolean r18 = r18.precedes(r19, r20)
            if (r18 == 0) goto L_0x0256
            r18 = 34
            r2 = r18
            goto L_0x0012
        L_0x0256:
            r18 = 36
            r2 = r18
            goto L_0x0012
        L_0x025c:
            r18 = 0
            r9 = r18
            r18 = r13
            r6 = r18
        L_0x0264:
            r18 = r6
            if (r18 == 0) goto L_0x00f2
            int r9 = r9 + 1
            r18 = r6
            r19 = r14
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x027a
            r18 = 10
            r2 = r18
            goto L_0x0012
        L_0x027a:
            r18 = r6
            r7 = r18
            r18 = r6
            org.w3c.dom.Node r18 = r18.getParentNode()
            r6 = r18
            goto L_0x0264
        L_0x0287:
            r18 = r4
            org.w3c.dom.DocumentType r18 = r18.getDoctype()
            r15 = r18
            r18 = r15
            r19 = r2
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x029f
            r18 = 20
            r2 = r18
            goto L_0x0012
        L_0x029f:
            r18 = r4
            r22 = r18
            r18 = r22
            r19 = r22
            r8 = r19
            r14 = r18
            goto L_0x00f7
        L_0x02ad:
            r18 = r13
            r19 = r5
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x02bd
            r18 = 20
            r2 = r18
            goto L_0x0012
        L_0x02bd:
            r18 = r5
            if (r18 == 0) goto L_0x00f7
            r18 = r4
            r19 = r5
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x00f7
            r18 = 2
            r2 = r18
            goto L_0x0012
        L_0x02d1:
            r18 = 0
            r10 = r18
            r18 = r8
            org.apache.xerces.dom.AttrImpl r18 = (org.apache.xerces.dom.AttrImpl) r18
            org.w3c.dom.Element r18 = r18.getOwnerElement()
            r14 = r18
            r18 = r14
            r6 = r18
        L_0x02e3:
            r18 = r6
            if (r18 == 0) goto L_0x00f7
            int r10 = r10 + 1
            r18 = r6
            r19 = r13
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x02f9
            r18 = 20
            r2 = r18
            goto L_0x0012
        L_0x02f9:
            r18 = r6
            r8 = r18
            r18 = r6
            org.w3c.dom.Node r18 = r18.getParentNode()
            r6 = r18
            goto L_0x02e3
        L_0x0306:
            r18 = 35
            r2 = r18
            goto L_0x0012
        L_0x030c:
            r18 = r9
            r19 = r10
            r0 = r18
            r1 = r19
            if (r0 <= r1) goto L_0x0343
            r18 = 0
            r15 = r18
        L_0x031a:
            r18 = r15
            r19 = r9
            r20 = r10
            int r19 = r19 - r20
            r0 = r18
            r1 = r19
            if (r0 < r1) goto L_0x0338
            r18 = r13
            r19 = r14
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x0370
            r18 = 2
            r2 = r18
            goto L_0x0012
        L_0x0338:
            r18 = r13
            org.w3c.dom.Node r18 = r18.getParentNode()
            r13 = r18
            int r15 = r15 + 1
            goto L_0x031a
        L_0x0343:
            r18 = 0
            r15 = r18
        L_0x0347:
            r18 = r15
            r19 = r10
            r20 = r9
            int r19 = r19 - r20
            r0 = r18
            r1 = r19
            if (r0 < r1) goto L_0x0365
            r18 = r14
            r19 = r13
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x0370
            r18 = 4
            r2 = r18
            goto L_0x0012
        L_0x0365:
            r18 = r14
            org.w3c.dom.Node r18 = r18.getParentNode()
            r14 = r18
            int r15 = r15 + 1
            goto L_0x0347
        L_0x0370:
            r18 = r13
            org.w3c.dom.Node r18 = r18.getParentNode()
            r15 = r18
            r18 = r14
            org.w3c.dom.Node r18 = r18.getParentNode()
            r16 = r18
        L_0x0380:
            r18 = r15
            r19 = r16
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x039c
            r18 = r15
            org.w3c.dom.Node r18 = r18.getFirstChild()
            r17 = r18
        L_0x0392:
            r18 = r17
            if (r18 != 0) goto L_0x03b5
            r18 = 0
            r2 = r18
            goto L_0x0012
        L_0x039c:
            r18 = r15
            r13 = r18
            r18 = r16
            r14 = r18
            r18 = r15
            org.w3c.dom.Node r18 = r18.getParentNode()
            r15 = r18
            r18 = r16
            org.w3c.dom.Node r18 = r18.getParentNode()
            r16 = r18
            goto L_0x0380
        L_0x03b5:
            r18 = r17
            r19 = r14
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x03c5
            r18 = 2
            r2 = r18
            goto L_0x0012
        L_0x03c5:
            r18 = r17
            r19 = r13
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x03d5
            r18 = 4
            r2 = r18
            goto L_0x0012
        L_0x03d5:
            r18 = r17
            org.w3c.dom.Node r18 = r18.getNextSibling()
            r17 = r18
            goto L_0x0392
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.NodeImpl.compareDocumentPosition(org.w3c.dom.Node):short");
    }

    public short compareTreePosition(Node node) {
        int i;
        int i2;
        Node node2 = node;
        if (this == node2) {
            return 48;
        }
        short nodeType = getNodeType();
        short nodeType2 = node2.getNodeType();
        if (nodeType == 6 || nodeType == 12 || nodeType2 == 6 || nodeType2 == 12) {
            return 0;
        }
        Node node3 = this;
        Node node4 = node2;
        int i3 = 0;
        int i4 = 0;
        Node node5 = this;
        while (true) {
            Node node6 = node5;
            if (node6 == null) {
                Node node7 = node2;
                while (true) {
                    Node node8 = node7;
                    if (node8 == null) {
                        Node node9 = this;
                        Node node10 = node2;
                        short nodeType3 = node3.getNodeType();
                        short nodeType4 = node4.getNodeType();
                        if (nodeType3 == 2) {
                            node9 = ((AttrImpl) node3).getOwnerElement();
                        }
                        if (nodeType4 == 2) {
                            node10 = ((AttrImpl) node4).getOwnerElement();
                        }
                        if (nodeType3 == 2 && nodeType4 == 2 && node9 == node10) {
                            return 16;
                        }
                        if (nodeType3 == 2) {
                            i = 0;
                            Node node11 = node9;
                            while (true) {
                                Node node12 = node11;
                                if (node12 == null) {
                                    break;
                                }
                                i++;
                                if (node12 == node10) {
                                    return 1;
                                }
                                node3 = node12;
                                node11 = node12.getParentNode();
                            }
                        }
                        if (nodeType4 == 2) {
                            i2 = 0;
                            Node node13 = node10;
                            while (true) {
                                Node node14 = node13;
                                if (node14 == null) {
                                    break;
                                }
                                i2++;
                                if (node14 == node9) {
                                    return 2;
                                }
                                node4 = node14;
                                node13 = node14.getParentNode();
                            }
                        }
                        if (node3 != node4) {
                            return 0;
                        }
                        if (i > i2) {
                            for (int i5 = 0; i5 < i - i2; i5++) {
                                node9 = node9.getParentNode();
                            }
                            if (node9 == node10) {
                                return 1;
                            }
                        } else {
                            for (int i6 = 0; i6 < i2 - i; i6++) {
                                node10 = node10.getParentNode();
                            }
                            if (node10 == node9) {
                                return 2;
                            }
                        }
                        Node parentNode = node9.getParentNode();
                        Node parentNode2 = node10.getParentNode();
                        while (true) {
                            Node node15 = parentNode2;
                            if (parentNode == node15) {
                                break;
                            }
                            node9 = parentNode;
                            node10 = node15;
                            parentNode = parentNode.getParentNode();
                            parentNode2 = node15.getParentNode();
                        }
                        Node firstChild = parentNode.getFirstChild();
                        while (true) {
                            Node node16 = firstChild;
                            if (node16 == null) {
                                return 0;
                            }
                            if (node16 == node10) {
                                return 1;
                            }
                            if (node16 == node9) {
                                return 2;
                            }
                            firstChild = node16.getNextSibling();
                        }
                    } else {
                        i4 = i2 + 1;
                        if (node8 == this) {
                            return 10;
                        }
                        node4 = node8;
                        node7 = node8.getParentNode();
                    }
                }
            } else {
                i3 = i + 1;
                if (node6 == node2) {
                    return 5;
                }
                node3 = node6;
                node5 = node6.getParentNode();
            }
        }
    }

    public boolean dispatchEvent(Event event) {
        return ownerDocument().dispatchEvent(this, event);
    }

    public NamedNodeMap getAttributes() {
        return null;
    }

    public String getBaseURI() {
        return null;
    }

    public NodeList getChildNodes() {
        return this;
    }

    /* access modifiers changed from: protected */
    public Node getContainer() {
        return null;
    }

    /* access modifiers changed from: package-private */
    public Node getElementAncestor(Node node) {
        Node parentNode = node.getParentNode();
        while (true) {
            Node node2 = parentNode;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1) {
                return node2;
            }
            parentNode = node2.getParentNode();
        }
    }

    public Object getFeature(String str, String str2) {
        return isSupported(str, str2) ? this : null;
    }

    public Node getFirstChild() {
        return null;
    }

    public Node getLastChild() {
        return null;
    }

    public int getLength() {
        return 0;
    }

    public String getLocalName() {
        return null;
    }

    public String getNamespaceURI() {
        return null;
    }

    public Node getNextSibling() {
        return null;
    }

    public abstract String getNodeName();

    /* access modifiers changed from: protected */
    public int getNodeNumber() {
        return ((CoreDocumentImpl) getOwnerDocument()).getNodeNumber(this);
    }

    public abstract short getNodeType();

    public String getNodeValue() throws DOMException {
        return null;
    }

    public Document getOwnerDocument() {
        return isOwned() ? this.ownerNode.ownerDocument() : (Document) this.ownerNode;
    }

    public Node getParentNode() {
        return null;
    }

    public String getPrefix() {
        return null;
    }

    public Node getPreviousSibling() {
        return null;
    }

    public boolean getReadOnly() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return isReadOnly();
    }

    public String getTextContent() throws DOMException {
        return getNodeValue();
    }

    /* access modifiers changed from: package-private */
    public void getTextContent(StringBuffer stringBuffer) throws DOMException {
        StringBuffer stringBuffer2 = stringBuffer;
        String nodeValue = getNodeValue();
        if (nodeValue != null) {
            StringBuffer append = stringBuffer2.append(nodeValue);
        }
    }

    public Object getUserData() {
        return ownerDocument().getUserData(this);
    }

    public Object getUserData(String str) {
        return ownerDocument().getUserData(this, str);
    }

    /* access modifiers changed from: protected */
    public Hashtable getUserDataRecord() {
        return ownerDocument().getUserDataRecord(this);
    }

    public boolean hasAttributes() {
        return false;
    }

    public boolean hasChildNodes() {
        return false;
    }

    /* access modifiers changed from: package-private */
    public final void hasStringValue(boolean z) {
        this.flags = z ? (short) (this.flags | 128) : (short) (this.flags & -129);
    }

    /* access modifiers changed from: package-private */
    public final boolean hasStringValue() {
        return (this.flags & 128) != 0;
    }

    public Node insertBefore(Node node, Node node2) throws DOMException {
        Throwable th;
        Node node3 = node;
        Node node4 = node2;
        Throwable th2 = th;
        new DOMException(3, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "HIERARCHY_REQUEST_ERR", (Object[]) null));
        throw th2;
    }

    /* access modifiers changed from: package-private */
    public final boolean internalIsIgnorableWhitespace() {
        return (this.flags & 64) != 0;
    }

    public boolean isDefaultNamespace(String str) {
        NodeImpl nodeImpl;
        String str2 = str;
        switch (getNodeType()) {
            case 1:
                String namespaceURI = getNamespaceURI();
                String prefix = getPrefix();
                if (prefix == null || prefix.length() == 0) {
                    if (str2 != null) {
                        return str2.equals(namespaceURI);
                    }
                    return namespaceURI == str2;
                } else if (!hasAttributes() || (nodeImpl = (NodeImpl) ((ElementImpl) this).getAttributeNodeNS("http://www.w3.org/2000/xmlns/", "xmlns")) == null) {
                    NodeImpl nodeImpl2 = (NodeImpl) getElementAncestor(this);
                    if (nodeImpl2 != null) {
                        return nodeImpl2.isDefaultNamespace(str2);
                    }
                    return false;
                } else {
                    String nodeValue = nodeImpl.getNodeValue();
                    if (str2 != null) {
                        return str2.equals(nodeValue);
                    }
                    return namespaceURI == nodeValue;
                }
            case 2:
                if (this.ownerNode.getNodeType() == 1) {
                    return this.ownerNode.isDefaultNamespace(str2);
                }
                return false;
            case 6:
            case 10:
            case 11:
            case 12:
                return false;
            case Zip4jConstants.DEFLATE_LEVEL_ULTRA:
                Element documentElement = ((Document) this).getDocumentElement();
                if (documentElement != null) {
                    return documentElement.isDefaultNamespace(str2);
                }
                return false;
            default:
                NodeImpl nodeImpl3 = (NodeImpl) getElementAncestor(this);
                if (nodeImpl3 != null) {
                    return nodeImpl3.isDefaultNamespace(str2);
                }
                return false;
        }
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [org.w3c.dom.Node] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean isEqualNode(org.w3c.dom.Node r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r1
            r3 = r0
            if (r2 != r3) goto L_0x0009
            r2 = 1
            r0 = r2
        L_0x0008:
            return r0
        L_0x0009:
            r2 = r1
            short r2 = r2.getNodeType()
            r3 = r0
            short r3 = r3.getNodeType()
            if (r2 == r3) goto L_0x0018
            r2 = 0
            r0 = r2
            goto L_0x0008
        L_0x0018:
            r2 = r0
            java.lang.String r2 = r2.getNodeName()
            if (r2 != 0) goto L_0x0029
            r2 = r1
            java.lang.String r2 = r2.getNodeName()
            if (r2 == 0) goto L_0x003c
            r2 = 0
            r0 = r2
            goto L_0x0008
        L_0x0029:
            r2 = r0
            java.lang.String r2 = r2.getNodeName()
            r3 = r1
            java.lang.String r3 = r3.getNodeName()
            boolean r2 = r2.equals(r3)
            if (r2 != 0) goto L_0x003c
            r2 = 0
            r0 = r2
            goto L_0x0008
        L_0x003c:
            r2 = r0
            java.lang.String r2 = r2.getLocalName()
            if (r2 != 0) goto L_0x004d
            r2 = r1
            java.lang.String r2 = r2.getLocalName()
            if (r2 == 0) goto L_0x0060
            r2 = 0
            r0 = r2
            goto L_0x0008
        L_0x004d:
            r2 = r0
            java.lang.String r2 = r2.getLocalName()
            r3 = r1
            java.lang.String r3 = r3.getLocalName()
            boolean r2 = r2.equals(r3)
            if (r2 != 0) goto L_0x0060
            r2 = 0
            r0 = r2
            goto L_0x0008
        L_0x0060:
            r2 = r0
            java.lang.String r2 = r2.getNamespaceURI()
            if (r2 != 0) goto L_0x0071
            r2 = r1
            java.lang.String r2 = r2.getNamespaceURI()
            if (r2 == 0) goto L_0x0084
            r2 = 0
            r0 = r2
            goto L_0x0008
        L_0x0071:
            r2 = r0
            java.lang.String r2 = r2.getNamespaceURI()
            r3 = r1
            java.lang.String r3 = r3.getNamespaceURI()
            boolean r2 = r2.equals(r3)
            if (r2 != 0) goto L_0x0084
            r2 = 0
            r0 = r2
            goto L_0x0008
        L_0x0084:
            r2 = r0
            java.lang.String r2 = r2.getPrefix()
            if (r2 != 0) goto L_0x0096
            r2 = r1
            java.lang.String r2 = r2.getPrefix()
            if (r2 == 0) goto L_0x00aa
            r2 = 0
            r0 = r2
            goto L_0x0008
        L_0x0096:
            r2 = r0
            java.lang.String r2 = r2.getPrefix()
            r3 = r1
            java.lang.String r3 = r3.getPrefix()
            boolean r2 = r2.equals(r3)
            if (r2 != 0) goto L_0x00aa
            r2 = 0
            r0 = r2
            goto L_0x0008
        L_0x00aa:
            r2 = r0
            java.lang.String r2 = r2.getNodeValue()
            if (r2 != 0) goto L_0x00bc
            r2 = r1
            java.lang.String r2 = r2.getNodeValue()
            if (r2 == 0) goto L_0x00d0
            r2 = 0
            r0 = r2
            goto L_0x0008
        L_0x00bc:
            r2 = r0
            java.lang.String r2 = r2.getNodeValue()
            r3 = r1
            java.lang.String r3 = r3.getNodeValue()
            boolean r2 = r2.equals(r3)
            if (r2 != 0) goto L_0x00d0
            r2 = 0
            r0 = r2
            goto L_0x0008
        L_0x00d0:
            r2 = 1
            r0 = r2
            goto L_0x0008
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.NodeImpl.isEqualNode(org.w3c.dom.Node):boolean");
    }

    /* access modifiers changed from: package-private */
    public final void isFirstChild(boolean z) {
        this.flags = z ? (short) (this.flags | 16) : (short) (this.flags & -17);
    }

    /* access modifiers changed from: package-private */
    public final boolean isFirstChild() {
        return (this.flags & 16) != 0;
    }

    /* access modifiers changed from: package-private */
    public final void isIdAttribute(boolean z) {
        this.flags = z ? (short) (this.flags | 512) : (short) (this.flags & -513);
    }

    /* access modifiers changed from: package-private */
    public final boolean isIdAttribute() {
        return (this.flags & 512) != 0;
    }

    /* access modifiers changed from: package-private */
    public final void isIgnorableWhitespace(boolean z) {
        this.flags = z ? (short) (this.flags | 64) : (short) (this.flags & -65);
    }

    /* access modifiers changed from: package-private */
    public final void isNormalized(boolean z) {
        boolean z2 = z;
        if (!z2 && isNormalized() && this.ownerNode != null) {
            this.ownerNode.isNormalized(false);
        }
        this.flags = z2 ? (short) (this.flags | 256) : (short) (this.flags & -257);
    }

    /* access modifiers changed from: package-private */
    public final boolean isNormalized() {
        return (this.flags & 256) != 0;
    }

    /* access modifiers changed from: package-private */
    public final void isOwned(boolean z) {
        this.flags = z ? (short) (this.flags | 8) : (short) (this.flags & -9);
    }

    /* access modifiers changed from: package-private */
    public final boolean isOwned() {
        return (this.flags & 8) != 0;
    }

    /* access modifiers changed from: package-private */
    public final void isReadOnly(boolean z) {
        this.flags = z ? (short) (this.flags | 1) : (short) (this.flags & -2);
    }

    /* access modifiers changed from: package-private */
    public final boolean isReadOnly() {
        return (this.flags & 1) != 0;
    }

    /* JADX WARNING: type inference failed for: r5v0, types: [org.w3c.dom.Node] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean isSameNode(org.w3c.dom.Node r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r0
            r3 = r1
            if (r2 != r3) goto L_0x0009
            r2 = 1
        L_0x0007:
            r0 = r2
            return r0
        L_0x0009:
            r2 = 0
            goto L_0x0007
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.NodeImpl.isSameNode(org.w3c.dom.Node):boolean");
    }

    /* access modifiers changed from: package-private */
    public final void isSpecified(boolean z) {
        this.flags = z ? (short) (this.flags | 32) : (short) (this.flags & -33);
    }

    /* access modifiers changed from: package-private */
    public final boolean isSpecified() {
        return (this.flags & 32) != 0;
    }

    public boolean isSupported(String str, String str2) {
        return ownerDocument().getImplementation().hasFeature(str, str2);
    }

    public Node item(int i) {
        int i2 = i;
        return null;
    }

    /* access modifiers changed from: package-private */
    public String lookupNamespacePrefix(String str, ElementImpl elementImpl) {
        String localName;
        String lookupNamespaceURI;
        String lookupNamespaceURI2;
        String str2 = str;
        ElementImpl elementImpl2 = elementImpl;
        String namespaceURI = getNamespaceURI();
        String prefix = getPrefix();
        if (namespaceURI != null && namespaceURI.equals(str2) && prefix != null && (lookupNamespaceURI2 = elementImpl2.lookupNamespaceURI(prefix)) != null && lookupNamespaceURI2.equals(str2)) {
            return prefix;
        }
        if (hasAttributes()) {
            NamedNodeMap attributes = getAttributes();
            int length = attributes.getLength();
            for (int i = 0; i < length; i++) {
                Node item = attributes.item(i);
                String namespaceURI2 = item.getNamespaceURI();
                if (namespaceURI2 != null && namespaceURI2.equals("http://www.w3.org/2000/xmlns/")) {
                    String prefix2 = item.getPrefix();
                    String nodeValue = item.getNodeValue();
                    if ((item.getNodeName().equals("xmlns") || (prefix2 != null && prefix2.equals("xmlns") && nodeValue.equals(str2))) && (lookupNamespaceURI = elementImpl2.lookupNamespaceURI(localName)) != null && lookupNamespaceURI.equals(str2)) {
                        return (localName = item.getLocalName());
                    }
                }
            }
        }
        NodeImpl nodeImpl = (NodeImpl) getElementAncestor(this);
        if (nodeImpl != null) {
            return nodeImpl.lookupNamespacePrefix(str2, elementImpl2);
        }
        return null;
    }

    public String lookupNamespaceURI(String str) {
        String str2 = str;
        switch (getNodeType()) {
            case 1:
                String namespaceURI = getNamespaceURI();
                String prefix = getPrefix();
                if (namespaceURI != null) {
                    if (str2 == null && prefix == str2) {
                        return namespaceURI;
                    }
                    if (prefix != null && prefix.equals(str2)) {
                        return namespaceURI;
                    }
                }
                if (hasAttributes()) {
                    NamedNodeMap attributes = getAttributes();
                    int length = attributes.getLength();
                    for (int i = 0; i < length; i++) {
                        Node item = attributes.item(i);
                        String namespaceURI2 = item.getNamespaceURI();
                        if (namespaceURI2 != null && namespaceURI2.equals("http://www.w3.org/2000/xmlns/")) {
                            String prefix2 = item.getPrefix();
                            String nodeValue = item.getNodeValue();
                            if (str2 == null && item.getNodeName().equals("xmlns")) {
                                return nodeValue.length() > 0 ? nodeValue : null;
                            } else if (prefix2 != null && prefix2.equals("xmlns") && item.getLocalName().equals(str2)) {
                                return nodeValue.length() > 0 ? nodeValue : null;
                            }
                        }
                    }
                }
                NodeImpl nodeImpl = (NodeImpl) getElementAncestor(this);
                if (nodeImpl != null) {
                    return nodeImpl.lookupNamespaceURI(str2);
                }
                return null;
            case 2:
                if (this.ownerNode.getNodeType() == 1) {
                    return this.ownerNode.lookupNamespaceURI(str2);
                }
                return null;
            case 6:
            case 10:
            case 11:
            case 12:
                return null;
            case Zip4jConstants.DEFLATE_LEVEL_ULTRA:
                Element documentElement = ((Document) this).getDocumentElement();
                if (documentElement != null) {
                    return documentElement.lookupNamespaceURI(str2);
                }
                return null;
            default:
                NodeImpl nodeImpl2 = (NodeImpl) getElementAncestor(this);
                if (nodeImpl2 != null) {
                    return nodeImpl2.lookupNamespaceURI(str2);
                }
                return null;
        }
    }

    public String lookupPrefix(String str) {
        String str2 = str;
        if (str2 == null) {
            return null;
        }
        switch (getNodeType()) {
            case 1:
                String namespaceURI = getNamespaceURI();
                return lookupNamespacePrefix(str2, (ElementImpl) this);
            case 2:
                if (this.ownerNode.getNodeType() == 1) {
                    return this.ownerNode.lookupPrefix(str2);
                }
                return null;
            case 6:
            case 10:
            case 11:
            case 12:
                return null;
            case Zip4jConstants.DEFLATE_LEVEL_ULTRA:
                Element documentElement = ((Document) this).getDocumentElement();
                if (documentElement != null) {
                    return documentElement.lookupPrefix(str2);
                }
                return null;
            default:
                NodeImpl nodeImpl = (NodeImpl) getElementAncestor(this);
                if (nodeImpl != null) {
                    return nodeImpl.lookupPrefix(str2);
                }
                return null;
        }
    }

    public final void needsSyncChildren(boolean z) {
        this.flags = z ? (short) (this.flags | 4) : (short) (this.flags & -5);
    }

    /* access modifiers changed from: package-private */
    public final boolean needsSyncChildren() {
        return (this.flags & 4) != 0;
    }

    /* access modifiers changed from: package-private */
    public final void needsSyncData(boolean z) {
        this.flags = z ? (short) (this.flags | 2) : (short) (this.flags & -3);
    }

    /* access modifiers changed from: package-private */
    public final boolean needsSyncData() {
        return (this.flags & 2) != 0;
    }

    public void normalize() {
    }

    /* access modifiers changed from: package-private */
    public CoreDocumentImpl ownerDocument() {
        return isOwned() ? this.ownerNode.ownerDocument() : (CoreDocumentImpl) this.ownerNode;
    }

    /* access modifiers changed from: package-private */
    public NodeImpl parentNode() {
        return null;
    }

    /* access modifiers changed from: package-private */
    public ChildNode previousSibling() {
        return null;
    }

    public Node removeChild(Node node) throws DOMException {
        Throwable th;
        Node node2 = node;
        Throwable th2 = th;
        new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
        throw th2;
    }

    public void removeEventListener(String str, EventListener eventListener, boolean z) {
        ownerDocument().removeEventListener(this, str, eventListener, z);
    }

    public Node replaceChild(Node node, Node node2) throws DOMException {
        Throwable th;
        Node node3 = node;
        Node node4 = node2;
        Throwable th2 = th;
        new DOMException(3, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "HIERARCHY_REQUEST_ERR", (Object[]) null));
        throw th2;
    }

    public void setNodeValue(String str) throws DOMException {
    }

    /* access modifiers changed from: protected */
    public void setOwnerDocument(CoreDocumentImpl coreDocumentImpl) {
        CoreDocumentImpl coreDocumentImpl2 = coreDocumentImpl;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (!isOwned()) {
            this.ownerNode = coreDocumentImpl2;
        }
    }

    public void setPrefix(String str) throws DOMException {
        Throwable th;
        String str2 = str;
        Throwable th2 = th;
        new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
        throw th2;
    }

    public void setReadOnly(boolean z, boolean z2) {
        boolean z3 = z;
        boolean z4 = z2;
        if (needsSyncData()) {
            synchronizeData();
        }
        isReadOnly(z3);
    }

    public void setTextContent(String str) throws DOMException {
        setNodeValue(str);
    }

    public Object setUserData(String str, Object obj, UserDataHandler userDataHandler) {
        return ownerDocument().setUserData(this, str, obj, userDataHandler);
    }

    public void setUserData(Object obj) {
        ownerDocument().setUserData(this, obj);
    }

    /* access modifiers changed from: protected */
    public void synchronizeData() {
        needsSyncData(false);
    }

    public String toString() {
        StringBuffer stringBuffer;
        new StringBuffer();
        return stringBuffer.append("[").append(getNodeName()).append(": ").append(getNodeValue()).append("]").toString();
    }
}
