package org.apache.xerces.dom;

import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import org.apache.xerces.impl.dv.ValidatedInfo;
import org.apache.xerces.impl.xs.util.StringListImpl;
import org.apache.xerces.xs.AttributePSVI;
import org.apache.xerces.xs.ShortList;
import org.apache.xerces.xs.StringList;
import org.apache.xerces.xs.XSAttributeDeclaration;
import org.apache.xerces.xs.XSSimpleTypeDefinition;
import org.apache.xerces.xs.XSTypeDefinition;
import org.apache.xerces.xs.XSValue;

public class PSVIAttrNSImpl extends AttrNSImpl implements AttributePSVI {
    static final long serialVersionUID = -3241738699421018889L;
    protected XSAttributeDeclaration fDeclaration = null;
    protected StringList fErrorCodes;
    protected StringList fErrorMessages;
    protected boolean fSpecified = true;
    protected XSTypeDefinition fTypeDecl = null;
    protected short fValidationAttempted;
    protected String fValidationContext;
    protected short fValidity;
    protected ValidatedInfo fValue;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public PSVIAttrNSImpl(CoreDocumentImpl coreDocumentImpl, String str, String str2) {
        super(coreDocumentImpl, str, str2);
        ValidatedInfo validatedInfo;
        new ValidatedInfo();
        this.fValue = validatedInfo;
        this.fValidationAttempted = 0;
        this.fValidity = 0;
        this.fErrorCodes = null;
        this.fErrorMessages = null;
        this.fValidationContext = null;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public PSVIAttrNSImpl(CoreDocumentImpl coreDocumentImpl, String str, String str2, String str3) {
        super(coreDocumentImpl, str, str2, str3);
        ValidatedInfo validatedInfo;
        new ValidatedInfo();
        this.fValue = validatedInfo;
        this.fValidationAttempted = 0;
        this.fValidity = 0;
        this.fErrorCodes = null;
        this.fErrorMessages = null;
        this.fValidationContext = null;
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        Throwable th;
        ObjectInputStream objectInputStream2 = objectInputStream;
        Throwable th2 = th;
        new NotSerializableException(getClass().getName());
        throw th2;
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        Throwable th;
        ObjectOutputStream objectOutputStream2 = objectOutputStream;
        Throwable th2 = th;
        new NotSerializableException(getClass().getName());
        throw th2;
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public org.apache.xerces.xs.ItemPSVI constant() {
        /*
            r6 = this;
            r0 = r6
            org.apache.xerces.impl.xs.AttributePSVImpl r1 = new org.apache.xerces.impl.xs.AttributePSVImpl
            r5 = r1
            r1 = r5
            r2 = r5
            r3 = 1
            r4 = r0
            r2.<init>(r3, r4)
            r0 = r1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.PSVIAttrNSImpl.constant():org.apache.xerces.xs.ItemPSVI");
    }

    public Object getActualNormalizedValue() {
        return this.fValue.getActualValue();
    }

    public short getActualNormalizedValueType() {
        return this.fValue.getActualValueType();
    }

    public XSAttributeDeclaration getAttributeDeclaration() {
        return this.fDeclaration;
    }

    public StringList getErrorCodes() {
        return this.fErrorCodes != null ? this.fErrorCodes : StringListImpl.EMPTY_LIST;
    }

    public StringList getErrorMessages() {
        return this.fErrorMessages != null ? this.fErrorMessages : StringListImpl.EMPTY_LIST;
    }

    public boolean getIsSchemaSpecified() {
        return this.fSpecified;
    }

    public ShortList getItemValueTypes() {
        return this.fValue.getListValueTypes();
    }

    public XSSimpleTypeDefinition getMemberTypeDefinition() {
        return this.fValue.getMemberTypeDefinition();
    }

    public String getSchemaDefault() {
        return this.fDeclaration == null ? null : this.fDeclaration.getConstraintValue();
    }

    public String getSchemaNormalizedValue() {
        return this.fValue.getNormalizedValue();
    }

    public XSValue getSchemaValue() {
        return this.fValue;
    }

    public XSTypeDefinition getTypeDefinition() {
        return this.fTypeDecl;
    }

    public short getValidationAttempted() {
        return this.fValidationAttempted;
    }

    public String getValidationContext() {
        return this.fValidationContext;
    }

    public short getValidity() {
        return this.fValidity;
    }

    public boolean isConstant() {
        return false;
    }

    public void setPSVI(AttributePSVI attributePSVI) {
        AttributePSVI attributePSVI2 = attributePSVI;
        this.fDeclaration = attributePSVI2.getAttributeDeclaration();
        this.fValidationContext = attributePSVI2.getValidationContext();
        this.fValidity = attributePSVI2.getValidity();
        this.fValidationAttempted = attributePSVI2.getValidationAttempted();
        this.fErrorCodes = attributePSVI2.getErrorCodes();
        this.fErrorMessages = attributePSVI2.getErrorMessages();
        this.fValue.copyFrom(attributePSVI2.getSchemaValue());
        this.fTypeDecl = attributePSVI2.getTypeDefinition();
        this.fSpecified = attributePSVI2.getIsSchemaSpecified();
    }
}
