package org.apache.xerces.dom;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.DocumentType;

public class PSVIDOMImplementationImpl extends DOMImplementationImpl {
    static final PSVIDOMImplementationImpl singleton;

    static {
        PSVIDOMImplementationImpl pSVIDOMImplementationImpl;
        new PSVIDOMImplementationImpl();
        singleton = pSVIDOMImplementationImpl;
    }

    public PSVIDOMImplementationImpl() {
    }

    public static DOMImplementation getDOMImplementation() {
        return singleton;
    }

    /* access modifiers changed from: protected */
    public CoreDocumentImpl createDocument(DocumentType documentType) {
        CoreDocumentImpl coreDocumentImpl;
        new PSVIDocumentImpl(documentType);
        return coreDocumentImpl;
    }

    public boolean hasFeature(String str, String str2) {
        String str3 = str;
        return super.hasFeature(str3, str2) || str3.equalsIgnoreCase("psvi");
    }
}
