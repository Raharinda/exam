package org.apache.xerces.dom;

import java.io.Serializable;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import org.apache.xerces.dom.events.EventImpl;
import org.apache.xerces.dom.events.MutationEventImpl;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.events.DocumentEvent;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventException;
import org.w3c.dom.events.EventListener;
import org.w3c.dom.ranges.DocumentRange;
import org.w3c.dom.ranges.Range;
import org.w3c.dom.traversal.DocumentTraversal;
import org.w3c.dom.traversal.NodeFilter;
import org.w3c.dom.traversal.NodeIterator;
import org.w3c.dom.traversal.TreeWalker;

public class DocumentImpl extends CoreDocumentImpl implements DocumentTraversal, DocumentEvent, DocumentRange {
    static final long serialVersionUID = 515687835542616694L;
    protected Hashtable eventListeners;
    protected transient ReferenceQueue iteratorReferenceQueue;
    protected transient List iterators;
    protected boolean mutationEvents = false;
    protected transient ReferenceQueue rangeReferenceQueue;
    protected transient List ranges;
    EnclosingAttr savedEnclosingAttr;

    class EnclosingAttr implements Serializable {
        private static final long serialVersionUID = 5208387723391647216L;
        AttrImpl node;
        String oldvalue;
        private final DocumentImpl this$0;

        EnclosingAttr(DocumentImpl documentImpl) {
            this.this$0 = documentImpl;
        }
    }

    class LEntry implements Serializable {
        private static final long serialVersionUID = -8426757059492421631L;
        EventListener listener;
        private final DocumentImpl this$0;
        String type;
        boolean useCapture;

        LEntry(DocumentImpl documentImpl, String str, EventListener eventListener, boolean z) {
            this.this$0 = documentImpl;
            this.type = str;
            this.listener = eventListener;
            this.useCapture = z;
        }
    }

    public DocumentImpl() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DocumentImpl(DocumentType documentType) {
        super(documentType);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DocumentImpl(DocumentType documentType, boolean z) {
        super(documentType, z);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DocumentImpl(boolean z) {
        super(z);
    }

    private void mutationEventsInsertedNode(NodeImpl nodeImpl, NodeImpl nodeImpl2, boolean z) {
        MutationEventImpl mutationEventImpl;
        MutationEventImpl mutationEventImpl2;
        NodeImpl nodeImpl3 = nodeImpl;
        NodeImpl nodeImpl4 = nodeImpl2;
        boolean z2 = z;
        if (LCount.lookup(MutationEventImpl.DOM_NODE_INSERTED).total > 0) {
            new MutationEventImpl();
            MutationEventImpl mutationEventImpl3 = mutationEventImpl2;
            mutationEventImpl3.initMutationEvent(MutationEventImpl.DOM_NODE_INSERTED, true, false, nodeImpl3, (String) null, (String) null, (String) null, 0);
            boolean dispatchEvent = dispatchEvent(nodeImpl4, mutationEventImpl3);
        }
        if (LCount.lookup(MutationEventImpl.DOM_NODE_INSERTED_INTO_DOCUMENT).total > 0) {
            NodeImpl nodeImpl5 = nodeImpl3;
            if (this.savedEnclosingAttr != null) {
                nodeImpl5 = (NodeImpl) this.savedEnclosingAttr.node.getOwnerElement();
            }
            if (nodeImpl5 != null) {
                NodeImpl nodeImpl6 = nodeImpl5;
                while (true) {
                    NodeImpl nodeImpl7 = nodeImpl6;
                    if (nodeImpl7 == null) {
                        break;
                    }
                    nodeImpl5 = nodeImpl7;
                    nodeImpl6 = nodeImpl7.getNodeType() == 2 ? (NodeImpl) ((AttrImpl) nodeImpl7).getOwnerElement() : nodeImpl7.parentNode();
                }
                if (nodeImpl5.getNodeType() == 9) {
                    new MutationEventImpl();
                    MutationEventImpl mutationEventImpl4 = mutationEventImpl;
                    mutationEventImpl4.initMutationEvent(MutationEventImpl.DOM_NODE_INSERTED_INTO_DOCUMENT, false, false, (Node) null, (String) null, (String) null, (String) null, 0);
                    dispatchEventToSubtree(nodeImpl4, mutationEventImpl4);
                }
            }
        }
        if (!z2) {
            dispatchAggregateEvents(nodeImpl3, this.savedEnclosingAttr);
        }
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void mutationEventsModifiedCharacterData(org.apache.xerces.dom.NodeImpl r18, java.lang.String r19, java.lang.String r20, boolean r21) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            r2 = r19
            r3 = r20
            r4 = r21
            r7 = r4
            if (r7 != 0) goto L_0x0043
            java.lang.String r7 = "DOMCharacterDataModified"
            org.apache.xerces.dom.LCount r7 = org.apache.xerces.dom.LCount.lookup(r7)
            r5 = r7
            r7 = r5
            int r7 = r7.total
            if (r7 <= 0) goto L_0x003b
            org.apache.xerces.dom.events.MutationEventImpl r7 = new org.apache.xerces.dom.events.MutationEventImpl
            r16 = r7
            r7 = r16
            r8 = r16
            r8.<init>()
            r6 = r7
            r7 = r6
            java.lang.String r8 = "DOMCharacterDataModified"
            r9 = 1
            r10 = 0
            r11 = 0
            r12 = r2
            r13 = r3
            r14 = 0
            r15 = 0
            r7.initMutationEvent(r8, r9, r10, r11, r12, r13, r14, r15)
            r7 = r0
            r8 = r1
            r9 = r6
            boolean r7 = r7.dispatchEvent(r8, r9)
        L_0x003b:
            r7 = r0
            r8 = r1
            r9 = r0
            org.apache.xerces.dom.DocumentImpl$EnclosingAttr r9 = r9.savedEnclosingAttr
            r7.dispatchAggregateEvents(r8, r9)
        L_0x0043:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.DocumentImpl.mutationEventsModifiedCharacterData(org.apache.xerces.dom.NodeImpl, java.lang.String, java.lang.String, boolean):void");
    }

    private void mutationEventsRemovedAttrNode(AttrImpl attrImpl, NodeImpl nodeImpl, String str) {
        MutationEventImpl mutationEventImpl;
        AttrImpl attrImpl2 = attrImpl;
        NodeImpl nodeImpl2 = nodeImpl;
        String str2 = str;
        if (LCount.lookup(MutationEventImpl.DOM_ATTR_MODIFIED).total > 0) {
            new MutationEventImpl();
            MutationEventImpl mutationEventImpl2 = mutationEventImpl;
            mutationEventImpl2.initMutationEvent(MutationEventImpl.DOM_ATTR_MODIFIED, true, false, attrImpl2, attrImpl2.getNodeValue(), (String) null, str2, 3);
            boolean dispatchEvent = dispatchEvent(nodeImpl2, mutationEventImpl2);
        }
        dispatchAggregateEvents(nodeImpl2, (AttrImpl) null, (String) null, 0);
    }

    private void mutationEventsRemovingNode(NodeImpl nodeImpl, NodeImpl nodeImpl2, boolean z) {
        MutationEventImpl mutationEventImpl;
        MutationEventImpl mutationEventImpl2;
        NodeImpl nodeImpl3 = nodeImpl;
        NodeImpl nodeImpl4 = nodeImpl2;
        if (!z) {
            saveEnclosingAttr(nodeImpl3);
        }
        if (LCount.lookup(MutationEventImpl.DOM_NODE_REMOVED).total > 0) {
            new MutationEventImpl();
            MutationEventImpl mutationEventImpl3 = mutationEventImpl2;
            mutationEventImpl3.initMutationEvent(MutationEventImpl.DOM_NODE_REMOVED, true, false, nodeImpl3, (String) null, (String) null, (String) null, 0);
            boolean dispatchEvent = dispatchEvent(nodeImpl4, mutationEventImpl3);
        }
        if (LCount.lookup(MutationEventImpl.DOM_NODE_REMOVED_FROM_DOCUMENT).total > 0) {
            NodeImpl nodeImpl5 = this;
            if (this.savedEnclosingAttr != null) {
                nodeImpl5 = (NodeImpl) this.savedEnclosingAttr.node.getOwnerElement();
            }
            if (nodeImpl5 != null) {
                NodeImpl parentNode = nodeImpl5.parentNode();
                while (true) {
                    NodeImpl nodeImpl6 = parentNode;
                    if (nodeImpl6 == null) {
                        break;
                    }
                    nodeImpl5 = nodeImpl6;
                    parentNode = nodeImpl6.parentNode();
                }
                if (nodeImpl5.getNodeType() == 9) {
                    new MutationEventImpl();
                    MutationEventImpl mutationEventImpl4 = mutationEventImpl;
                    mutationEventImpl4.initMutationEvent(MutationEventImpl.DOM_NODE_REMOVED_FROM_DOCUMENT, false, false, (Node) null, (String) null, (String) null, (String) null, 0);
                    dispatchEventToSubtree(nodeImpl4, mutationEventImpl4);
                }
            }
        }
    }

    private void notifyIteratorsRemovingNode(NodeImpl nodeImpl) {
        NodeImpl nodeImpl2 = nodeImpl;
        removeStaleIteratorReferences();
        Iterator it = this.iterators.iterator();
        while (it.hasNext()) {
            NodeIteratorImpl nodeIteratorImpl = (NodeIteratorImpl) ((Reference) it.next()).get();
            if (nodeIteratorImpl != null) {
                nodeIteratorImpl.removeNode(nodeImpl2);
            } else {
                it.remove();
            }
        }
    }

    private void notifyRangesDeletedText(CharacterDataImpl characterDataImpl, int i, int i2) {
        CharacterDataImpl characterDataImpl2 = characterDataImpl;
        int i3 = i;
        int i4 = i2;
        removeStaleRangeReferences();
        Iterator it = this.ranges.iterator();
        while (it.hasNext()) {
            RangeImpl rangeImpl = (RangeImpl) ((Reference) it.next()).get();
            if (rangeImpl != null) {
                rangeImpl.receiveDeletedText(characterDataImpl2, i3, i4);
            } else {
                it.remove();
            }
        }
    }

    private void notifyRangesInsertedNode(NodeImpl nodeImpl) {
        NodeImpl nodeImpl2 = nodeImpl;
        removeStaleRangeReferences();
        Iterator it = this.ranges.iterator();
        while (it.hasNext()) {
            RangeImpl rangeImpl = (RangeImpl) ((Reference) it.next()).get();
            if (rangeImpl != null) {
                rangeImpl.insertedNodeFromDOM(nodeImpl2);
            } else {
                it.remove();
            }
        }
    }

    private void notifyRangesInsertedText(CharacterDataImpl characterDataImpl, int i, int i2) {
        CharacterDataImpl characterDataImpl2 = characterDataImpl;
        int i3 = i;
        int i4 = i2;
        removeStaleRangeReferences();
        Iterator it = this.ranges.iterator();
        while (it.hasNext()) {
            RangeImpl rangeImpl = (RangeImpl) ((Reference) it.next()).get();
            if (rangeImpl != null) {
                rangeImpl.receiveInsertedText(characterDataImpl2, i3, i4);
            } else {
                it.remove();
            }
        }
    }

    private void notifyRangesRemovingNode(NodeImpl nodeImpl) {
        NodeImpl nodeImpl2 = nodeImpl;
        removeStaleRangeReferences();
        Iterator it = this.ranges.iterator();
        while (it.hasNext()) {
            RangeImpl rangeImpl = (RangeImpl) ((Reference) it.next()).get();
            if (rangeImpl != null) {
                rangeImpl.removeNode(nodeImpl2);
            } else {
                it.remove();
            }
        }
    }

    private void notifyRangesReplacedText(CharacterDataImpl characterDataImpl) {
        CharacterDataImpl characterDataImpl2 = characterDataImpl;
        removeStaleRangeReferences();
        Iterator it = this.ranges.iterator();
        while (it.hasNext()) {
            RangeImpl rangeImpl = (RangeImpl) ((Reference) it.next()).get();
            if (rangeImpl != null) {
                rangeImpl.receiveReplacedText(characterDataImpl2);
            } else {
                it.remove();
            }
        }
    }

    private void notifyRangesSplitData(Node node, Node node2, int i) {
        Node node3 = node;
        Node node4 = node2;
        int i2 = i;
        removeStaleRangeReferences();
        Iterator it = this.ranges.iterator();
        while (it.hasNext()) {
            RangeImpl rangeImpl = (RangeImpl) ((Reference) it.next()).get();
            if (rangeImpl != null) {
                rangeImpl.receiveSplitData(node3, node4, i2);
            } else {
                it.remove();
            }
        }
    }

    private void removeStaleIteratorReferences() {
        removeStaleReferences(this.iteratorReferenceQueue, this.iterators);
    }

    private void removeStaleRangeReferences() {
        removeStaleReferences(this.rangeReferenceQueue, this.ranges);
    }

    private void removeStaleReferences(ReferenceQueue referenceQueue, List list) {
        ReferenceQueue referenceQueue2 = referenceQueue;
        List list2 = list;
        int i = 0;
        for (Reference poll = referenceQueue2.poll(); poll != null; poll = referenceQueue2.poll()) {
            i++;
        }
        if (i > 0) {
            Iterator it = list2.iterator();
            while (it.hasNext()) {
                if (((Reference) it.next()).get() == null) {
                    it.remove();
                    i--;
                    if (i <= 0) {
                        return;
                    }
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void addEventListener(NodeImpl nodeImpl, String str, EventListener eventListener, boolean z) {
        Object obj;
        Vector vector;
        NodeImpl nodeImpl2 = nodeImpl;
        String str2 = str;
        EventListener eventListener2 = eventListener;
        boolean z2 = z;
        if (str2 != null && str2.length() != 0 && eventListener2 != null) {
            removeEventListener(nodeImpl2, str2, eventListener2, z2);
            Vector eventListeners2 = getEventListeners(nodeImpl2);
            if (eventListeners2 == null) {
                new Vector();
                eventListeners2 = vector;
                setEventListeners(nodeImpl2, eventListeners2);
            }
            new LEntry(this, str2, eventListener2, z2);
            eventListeners2.addElement(obj);
            LCount lookup = LCount.lookup(str2);
            if (z2) {
                lookup.captures++;
                lookup.total++;
                return;
            }
            lookup.bubbles++;
            lookup.total++;
        }
    }

    public Node cloneNode(boolean z) {
        DocumentImpl documentImpl;
        new DocumentImpl();
        DocumentImpl documentImpl2 = documentImpl;
        callUserDataHandlers(this, documentImpl2, 1);
        cloneNode(documentImpl2, z);
        documentImpl2.mutationEvents = this.mutationEvents;
        return documentImpl2;
    }

    /* access modifiers changed from: protected */
    public void copyEventListeners(NodeImpl nodeImpl, NodeImpl nodeImpl2) {
        NodeImpl nodeImpl3 = nodeImpl2;
        Vector eventListeners2 = getEventListeners(nodeImpl);
        if (eventListeners2 != null) {
            setEventListeners(nodeImpl3, (Vector) eventListeners2.clone());
        }
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public org.w3c.dom.events.Event createEvent(java.lang.String r9) throws org.w3c.dom.DOMException {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            r3 = r1
            java.lang.String r4 = "Events"
            boolean r3 = r3.equalsIgnoreCase(r4)
            if (r3 != 0) goto L_0x0016
            java.lang.String r3 = "Event"
            r4 = r1
            boolean r3 = r3.equals(r4)
            if (r3 == 0) goto L_0x0020
        L_0x0016:
            org.apache.xerces.dom.events.EventImpl r3 = new org.apache.xerces.dom.events.EventImpl
            r7 = r3
            r3 = r7
            r4 = r7
            r4.<init>()
            r0 = r3
        L_0x001f:
            return r0
        L_0x0020:
            r3 = r1
            java.lang.String r4 = "MutationEvents"
            boolean r3 = r3.equalsIgnoreCase(r4)
            if (r3 != 0) goto L_0x0034
            java.lang.String r3 = "MutationEvent"
            r4 = r1
            boolean r3 = r3.equals(r4)
            if (r3 == 0) goto L_0x003e
        L_0x0034:
            org.apache.xerces.dom.events.MutationEventImpl r3 = new org.apache.xerces.dom.events.MutationEventImpl
            r7 = r3
            r3 = r7
            r4 = r7
            r4.<init>()
            r0 = r3
            goto L_0x001f
        L_0x003e:
            r3 = r1
            java.lang.String r4 = "UIEvents"
            boolean r3 = r3.equalsIgnoreCase(r4)
            if (r3 != 0) goto L_0x0052
            java.lang.String r3 = "UIEvent"
            r4 = r1
            boolean r3 = r3.equals(r4)
            if (r3 == 0) goto L_0x005c
        L_0x0052:
            org.apache.xerces.dom.events.UIEventImpl r3 = new org.apache.xerces.dom.events.UIEventImpl
            r7 = r3
            r3 = r7
            r4 = r7
            r4.<init>()
            r0 = r3
            goto L_0x001f
        L_0x005c:
            r3 = r1
            java.lang.String r4 = "MouseEvents"
            boolean r3 = r3.equalsIgnoreCase(r4)
            if (r3 != 0) goto L_0x0070
            java.lang.String r3 = "MouseEvent"
            r4 = r1
            boolean r3 = r3.equals(r4)
            if (r3 == 0) goto L_0x007a
        L_0x0070:
            org.apache.xerces.dom.events.MouseEventImpl r3 = new org.apache.xerces.dom.events.MouseEventImpl
            r7 = r3
            r3 = r7
            r4 = r7
            r4.<init>()
            r0 = r3
            goto L_0x001f
        L_0x007a:
            java.lang.String r3 = "http://www.w3.org/dom/DOMTR"
            java.lang.String r4 = "NOT_SUPPORTED_ERR"
            r5 = 0
            java.lang.String r3 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r3, r4, r5)
            r2 = r3
            org.w3c.dom.DOMException r3 = new org.w3c.dom.DOMException
            r7 = r3
            r3 = r7
            r4 = r7
            r5 = 9
            r6 = r2
            r4.<init>(r5, r6)
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.DocumentImpl.createEvent(java.lang.String):org.w3c.dom.events.Event");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v9, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v1, resolved type: org.w3c.dom.traversal.NodeIterator} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public org.w3c.dom.traversal.NodeIterator createNodeIterator(org.w3c.dom.Node r15, int r16, org.w3c.dom.traversal.NodeFilter r17, boolean r18) {
        /*
            r14 = this;
            r0 = r14
            r1 = r15
            r2 = r16
            r3 = r17
            r4 = r18
            r6 = r1
            if (r6 != 0) goto L_0x0023
            java.lang.String r6 = "http://www.w3.org/dom/DOMTR"
            java.lang.String r7 = "NOT_SUPPORTED_ERR"
            r8 = 0
            java.lang.String r6 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r6, r7, r8)
            r5 = r6
            org.w3c.dom.DOMException r6 = new org.w3c.dom.DOMException
            r13 = r6
            r6 = r13
            r7 = r13
            r8 = 9
            r9 = r5
            r7.<init>(r8, r9)
            throw r6
        L_0x0023:
            org.apache.xerces.dom.NodeIteratorImpl r6 = new org.apache.xerces.dom.NodeIteratorImpl
            r13 = r6
            r6 = r13
            r7 = r13
            r8 = r0
            r9 = r1
            r10 = r2
            r11 = r3
            r12 = r4
            r7.<init>(r8, r9, r10, r11, r12)
            r5 = r6
            r6 = r0
            java.util.List r6 = r6.iterators
            if (r6 != 0) goto L_0x004c
            r6 = r0
            java.util.LinkedList r7 = new java.util.LinkedList
            r13 = r7
            r7 = r13
            r8 = r13
            r8.<init>()
            r6.iterators = r7
            r6 = r0
            java.lang.ref.ReferenceQueue r7 = new java.lang.ref.ReferenceQueue
            r13 = r7
            r7 = r13
            r8 = r13
            r8.<init>()
            r6.iteratorReferenceQueue = r7
        L_0x004c:
            r6 = r0
            r6.removeStaleIteratorReferences()
            r6 = r0
            java.util.List r6 = r6.iterators
            java.lang.ref.WeakReference r7 = new java.lang.ref.WeakReference
            r13 = r7
            r7 = r13
            r8 = r13
            r9 = r5
            r10 = r0
            java.lang.ref.ReferenceQueue r10 = r10.iteratorReferenceQueue
            r8.<init>(r9, r10)
            boolean r6 = r6.add(r7)
            r6 = r5
            r0 = r6
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.DocumentImpl.createNodeIterator(org.w3c.dom.Node, int, org.w3c.dom.traversal.NodeFilter, boolean):org.w3c.dom.traversal.NodeIterator");
    }

    public NodeIterator createNodeIterator(Node node, short s, NodeFilter nodeFilter) {
        return createNodeIterator(node, s, nodeFilter, true);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v8, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v1, resolved type: org.w3c.dom.ranges.Range} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public org.w3c.dom.ranges.Range createRange() {
        /*
            r8 = this;
            r0 = r8
            r2 = r0
            java.util.List r2 = r2.ranges
            if (r2 != 0) goto L_0x001c
            r2 = r0
            java.util.LinkedList r3 = new java.util.LinkedList
            r7 = r3
            r3 = r7
            r4 = r7
            r4.<init>()
            r2.ranges = r3
            r2 = r0
            java.lang.ref.ReferenceQueue r3 = new java.lang.ref.ReferenceQueue
            r7 = r3
            r3 = r7
            r4 = r7
            r4.<init>()
            r2.rangeReferenceQueue = r3
        L_0x001c:
            org.apache.xerces.dom.RangeImpl r2 = new org.apache.xerces.dom.RangeImpl
            r7 = r2
            r2 = r7
            r3 = r7
            r4 = r0
            r3.<init>(r4)
            r1 = r2
            r2 = r0
            r2.removeStaleRangeReferences()
            r2 = r0
            java.util.List r2 = r2.ranges
            java.lang.ref.WeakReference r3 = new java.lang.ref.WeakReference
            r7 = r3
            r3 = r7
            r4 = r7
            r5 = r1
            r6 = r0
            java.lang.ref.ReferenceQueue r6 = r6.rangeReferenceQueue
            r4.<init>(r5, r6)
            boolean r2 = r2.add(r3)
            r2 = r1
            r0 = r2
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.DocumentImpl.createRange():org.w3c.dom.ranges.Range");
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public org.w3c.dom.traversal.TreeWalker createTreeWalker(org.w3c.dom.Node r14, int r15, org.w3c.dom.traversal.NodeFilter r16, boolean r17) {
        /*
            r13 = this;
            r0 = r13
            r1 = r14
            r2 = r15
            r3 = r16
            r4 = r17
            r6 = r1
            if (r6 != 0) goto L_0x0022
            java.lang.String r6 = "http://www.w3.org/dom/DOMTR"
            java.lang.String r7 = "NOT_SUPPORTED_ERR"
            r8 = 0
            java.lang.String r6 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r6, r7, r8)
            r5 = r6
            org.w3c.dom.DOMException r6 = new org.w3c.dom.DOMException
            r12 = r6
            r6 = r12
            r7 = r12
            r8 = 9
            r9 = r5
            r7.<init>(r8, r9)
            throw r6
        L_0x0022:
            org.apache.xerces.dom.TreeWalkerImpl r6 = new org.apache.xerces.dom.TreeWalkerImpl
            r12 = r6
            r6 = r12
            r7 = r12
            r8 = r1
            r9 = r2
            r10 = r3
            r11 = r4
            r7.<init>(r8, r9, r10, r11)
            r0 = r6
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.DocumentImpl.createTreeWalker(org.w3c.dom.Node, int, org.w3c.dom.traversal.NodeFilter, boolean):org.w3c.dom.traversal.TreeWalker");
    }

    public TreeWalker createTreeWalker(Node node, short s, NodeFilter nodeFilter) {
        return createTreeWalker(node, s, nodeFilter, true);
    }

    /* access modifiers changed from: package-private */
    public void deletedText(CharacterDataImpl characterDataImpl, int i, int i2) {
        CharacterDataImpl characterDataImpl2 = characterDataImpl;
        int i3 = i;
        int i4 = i2;
        if (this.ranges != null) {
            notifyRangesDeletedText(characterDataImpl2, i3, i4);
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void dispatchAggregateEvents(org.apache.xerces.dom.NodeImpl r19, org.apache.xerces.dom.AttrImpl r20, java.lang.String r21, short r22) {
        /*
            r18 = this;
            r0 = r18
            r1 = r19
            r2 = r20
            r3 = r21
            r4 = r22
            r8 = 0
            r5 = r8
            r8 = r2
            if (r8 == 0) goto L_0x0050
            java.lang.String r8 = "DOMAttrModified"
            org.apache.xerces.dom.LCount r8 = org.apache.xerces.dom.LCount.lookup(r8)
            r6 = r8
            r8 = r2
            org.w3c.dom.Element r8 = r8.getOwnerElement()
            org.apache.xerces.dom.NodeImpl r8 = (org.apache.xerces.dom.NodeImpl) r8
            r5 = r8
            r8 = r6
            int r8 = r8.total
            if (r8 <= 0) goto L_0x0050
            r8 = r5
            if (r8 == 0) goto L_0x0050
            org.apache.xerces.dom.events.MutationEventImpl r8 = new org.apache.xerces.dom.events.MutationEventImpl
            r17 = r8
            r8 = r17
            r9 = r17
            r9.<init>()
            r7 = r8
            r8 = r7
            java.lang.String r9 = "DOMAttrModified"
            r10 = 1
            r11 = 0
            r12 = r2
            r13 = r3
            r14 = r2
            java.lang.String r14 = r14.getNodeValue()
            r15 = r2
            java.lang.String r15 = r15.getNodeName()
            r16 = r4
            r8.initMutationEvent(r9, r10, r11, r12, r13, r14, r15, r16)
            r8 = r5
            r9 = r7
            boolean r8 = r8.dispatchEvent(r9)
        L_0x0050:
            java.lang.String r8 = "DOMSubtreeModified"
            org.apache.xerces.dom.LCount r8 = org.apache.xerces.dom.LCount.lookup(r8)
            r6 = r8
            r8 = r6
            int r8 = r8.total
            if (r8 <= 0) goto L_0x008c
            org.apache.xerces.dom.events.MutationEventImpl r8 = new org.apache.xerces.dom.events.MutationEventImpl
            r17 = r8
            r8 = r17
            r9 = r17
            r9.<init>()
            r7 = r8
            r8 = r7
            java.lang.String r9 = "DOMSubtreeModified"
            r10 = 1
            r11 = 0
            r12 = 0
            r13 = 0
            r14 = 0
            r15 = 0
            r16 = 0
            r8.initMutationEvent(r9, r10, r11, r12, r13, r14, r15, r16)
            r8 = r2
            if (r8 == 0) goto L_0x008d
            r8 = r0
            r9 = r2
            r10 = r7
            boolean r8 = r8.dispatchEvent(r9, r10)
            r8 = r5
            if (r8 == 0) goto L_0x008c
            r8 = r0
            r9 = r5
            r10 = r7
            boolean r8 = r8.dispatchEvent(r9, r10)
        L_0x008c:
            return
        L_0x008d:
            r8 = r0
            r9 = r1
            r10 = r7
            boolean r8 = r8.dispatchEvent(r9, r10)
            goto L_0x008c
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.DocumentImpl.dispatchAggregateEvents(org.apache.xerces.dom.NodeImpl, org.apache.xerces.dom.AttrImpl, java.lang.String, short):void");
    }

    /* access modifiers changed from: protected */
    public void dispatchAggregateEvents(NodeImpl nodeImpl, EnclosingAttr enclosingAttr) {
        NodeImpl nodeImpl2 = nodeImpl;
        EnclosingAttr enclosingAttr2 = enclosingAttr;
        if (enclosingAttr2 != null) {
            dispatchAggregateEvents(nodeImpl2, enclosingAttr2.node, enclosingAttr2.oldvalue, 1);
        } else {
            dispatchAggregateEvents(nodeImpl2, (AttrImpl) null, (String) null, 0);
        }
    }

    /* access modifiers changed from: protected */
    public boolean dispatchEvent(NodeImpl nodeImpl, Event event) {
        Throwable th;
        ArrayList arrayList;
        NodeImpl nodeImpl2 = nodeImpl;
        Event event2 = event;
        if (event2 == null) {
            return false;
        }
        EventImpl eventImpl = (EventImpl) event2;
        if (!eventImpl.initialized || eventImpl.type == null || eventImpl.type.length() == 0) {
            Throwable th2 = th;
            new EventException(0, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "UNSPECIFIED_EVENT_TYPE_ERR", (Object[]) null));
            throw th2;
        }
        LCount lookup = LCount.lookup(eventImpl.getType());
        if (lookup.total == 0) {
            return eventImpl.preventDefault;
        }
        eventImpl.target = nodeImpl2;
        eventImpl.stopPropagation = false;
        eventImpl.preventDefault = false;
        new ArrayList(10);
        ArrayList arrayList2 = arrayList;
        Node parentNode = nodeImpl2.getParentNode();
        while (true) {
            Node node = parentNode;
            if (node == null) {
                break;
            }
            boolean add = arrayList2.add(node);
            Node node2 = node;
            parentNode = node.getParentNode();
        }
        if (lookup.captures > 0) {
            eventImpl.eventPhase = 1;
            for (int size = arrayList2.size() - 1; size >= 0 && !eventImpl.stopPropagation; size--) {
                NodeImpl nodeImpl3 = (NodeImpl) arrayList2.get(size);
                eventImpl.currentTarget = nodeImpl3;
                Vector eventListeners2 = getEventListeners(nodeImpl3);
                if (eventListeners2 != null) {
                    Vector vector = (Vector) eventListeners2.clone();
                    int size2 = vector.size();
                    for (int i = 0; i < size2; i++) {
                        LEntry lEntry = (LEntry) vector.elementAt(i);
                        if (lEntry.useCapture && lEntry.type.equals(eventImpl.type) && eventListeners2.contains(lEntry)) {
                            try {
                                lEntry.listener.handleEvent(eventImpl);
                            } catch (Exception e) {
                                Exception exc = e;
                            }
                        }
                    }
                }
            }
        }
        if (lookup.bubbles > 0) {
            eventImpl.eventPhase = 2;
            eventImpl.currentTarget = nodeImpl2;
            Vector eventListeners3 = getEventListeners(nodeImpl2);
            if (!eventImpl.stopPropagation && eventListeners3 != null) {
                Vector vector2 = (Vector) eventListeners3.clone();
                int size3 = vector2.size();
                for (int i2 = 0; i2 < size3; i2++) {
                    LEntry lEntry2 = (LEntry) vector2.elementAt(i2);
                    if (!lEntry2.useCapture && lEntry2.type.equals(eventImpl.type) && eventListeners3.contains(lEntry2)) {
                        try {
                            lEntry2.listener.handleEvent(eventImpl);
                        } catch (Exception e2) {
                            Exception exc2 = e2;
                        }
                    }
                }
            }
            if (eventImpl.bubbles) {
                eventImpl.eventPhase = 3;
                int size4 = arrayList2.size();
                for (int i3 = 0; i3 < size4 && !eventImpl.stopPropagation; i3++) {
                    NodeImpl nodeImpl4 = (NodeImpl) arrayList2.get(i3);
                    eventImpl.currentTarget = nodeImpl4;
                    Vector eventListeners4 = getEventListeners(nodeImpl4);
                    if (eventListeners4 != null) {
                        Vector vector3 = (Vector) eventListeners4.clone();
                        int size5 = vector3.size();
                        for (int i4 = 0; i4 < size5; i4++) {
                            LEntry lEntry3 = (LEntry) vector3.elementAt(i4);
                            if (!lEntry3.useCapture && lEntry3.type.equals(eventImpl.type) && eventListeners4.contains(lEntry3)) {
                                try {
                                    lEntry3.listener.handleEvent(eventImpl);
                                } catch (Exception e3) {
                                    Exception exc3 = e3;
                                }
                            }
                        }
                    }
                }
            }
        }
        if (lookup.defaults <= 0 || !eventImpl.cancelable || !eventImpl.preventDefault) {
        }
        return eventImpl.preventDefault;
    }

    /* access modifiers changed from: protected */
    public void dispatchEventToSubtree(Node node, Event event) {
        Node node2 = node;
        Event event2 = event;
        boolean dispatchEvent = ((NodeImpl) node2).dispatchEvent(event2);
        if (node2.getNodeType() == 1) {
            NamedNodeMap attributes = node2.getAttributes();
            for (int length = attributes.getLength() - 1; length >= 0; length--) {
                dispatchingEventToSubtree(attributes.item(length), event2);
            }
        }
        dispatchingEventToSubtree(node2.getFirstChild(), event2);
    }

    /* access modifiers changed from: protected */
    public void dispatchingEventToSubtree(Node node, Event event) {
        Node node2 = node;
        Event event2 = event;
        if (node2 != null) {
            boolean dispatchEvent = ((NodeImpl) node2).dispatchEvent(event2);
            if (node2.getNodeType() == 1) {
                NamedNodeMap attributes = node2.getAttributes();
                for (int length = attributes.getLength() - 1; length >= 0; length--) {
                    dispatchingEventToSubtree(attributes.item(length), event2);
                }
            }
            dispatchingEventToSubtree(node2.getFirstChild(), event2);
            dispatchingEventToSubtree(node2.getNextSibling(), event2);
        }
    }

    /* access modifiers changed from: protected */
    public Vector getEventListeners(NodeImpl nodeImpl) {
        NodeImpl nodeImpl2 = nodeImpl;
        if (this.eventListeners == null) {
            return null;
        }
        return (Vector) this.eventListeners.get(nodeImpl2);
    }

    public DOMImplementation getImplementation() {
        return DOMImplementationImpl.getDOMImplementation();
    }

    /* access modifiers changed from: package-private */
    public boolean getMutationEvents() {
        return this.mutationEvents;
    }

    /* access modifiers changed from: package-private */
    public void insertedNode(NodeImpl nodeImpl, NodeImpl nodeImpl2, boolean z) {
        NodeImpl nodeImpl3 = nodeImpl;
        NodeImpl nodeImpl4 = nodeImpl2;
        boolean z2 = z;
        if (this.mutationEvents) {
            mutationEventsInsertedNode(nodeImpl3, nodeImpl4, z2);
        }
        if (this.ranges != null) {
            notifyRangesInsertedNode(nodeImpl4);
        }
    }

    /* access modifiers changed from: package-private */
    public void insertedText(CharacterDataImpl characterDataImpl, int i, int i2) {
        CharacterDataImpl characterDataImpl2 = characterDataImpl;
        int i3 = i;
        int i4 = i2;
        if (this.ranges != null) {
            notifyRangesInsertedText(characterDataImpl2, i3, i4);
        }
    }

    /* access modifiers changed from: package-private */
    public void insertingNode(NodeImpl nodeImpl, boolean z) {
        NodeImpl nodeImpl2 = nodeImpl;
        boolean z2 = z;
        if (this.mutationEvents && !z2) {
            saveEnclosingAttr(nodeImpl2);
        }
    }

    /* access modifiers changed from: package-private */
    public void modifiedAttrValue(AttrImpl attrImpl, String str) {
        AttrImpl attrImpl2 = attrImpl;
        String str2 = str;
        if (this.mutationEvents) {
            dispatchAggregateEvents(attrImpl2, attrImpl2, str2, 1);
        }
    }

    /* access modifiers changed from: package-private */
    public void modifiedCharacterData(NodeImpl nodeImpl, String str, String str2, boolean z) {
        NodeImpl nodeImpl2 = nodeImpl;
        String str3 = str;
        String str4 = str2;
        boolean z2 = z;
        if (this.mutationEvents) {
            mutationEventsModifiedCharacterData(nodeImpl2, str3, str4, z2);
        }
    }

    /* access modifiers changed from: package-private */
    public void modifyingCharacterData(NodeImpl nodeImpl, boolean z) {
        NodeImpl nodeImpl2 = nodeImpl;
        boolean z2 = z;
        if (this.mutationEvents && !z2) {
            saveEnclosingAttr(nodeImpl2);
        }
    }

    /* access modifiers changed from: protected */
    public void removeEventListener(NodeImpl nodeImpl, String str, EventListener eventListener, boolean z) {
        Vector eventListeners2;
        NodeImpl nodeImpl2 = nodeImpl;
        String str2 = str;
        EventListener eventListener2 = eventListener;
        boolean z2 = z;
        if (str2 != null && str2.length() != 0 && eventListener2 != null && (eventListeners2 = getEventListeners(nodeImpl2)) != null) {
            for (int size = eventListeners2.size() - 1; size >= 0; size--) {
                LEntry lEntry = (LEntry) eventListeners2.elementAt(size);
                if (lEntry.useCapture == z2 && lEntry.listener == eventListener2 && lEntry.type.equals(str2)) {
                    eventListeners2.removeElementAt(size);
                    if (eventListeners2.size() == 0) {
                        setEventListeners(nodeImpl2, (Vector) null);
                    }
                    LCount lookup = LCount.lookup(str2);
                    if (z2) {
                        LCount lCount = lookup;
                        lCount.captures--;
                        LCount lCount2 = lookup;
                        lCount2.total--;
                        return;
                    }
                    LCount lCount3 = lookup;
                    lCount3.bubbles--;
                    LCount lCount4 = lookup;
                    lCount4.total--;
                    return;
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void removeNodeIterator(NodeIterator nodeIterator) {
        Object obj = nodeIterator;
        if (obj != null && this.iterators != null) {
            removeStaleIteratorReferences();
            Iterator it = this.iterators.iterator();
            while (it.hasNext()) {
                Object obj2 = ((Reference) it.next()).get();
                if (obj2 == obj) {
                    it.remove();
                    return;
                } else if (obj2 == null) {
                    it.remove();
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void removeRange(Range range) {
        Object obj = range;
        if (obj != null && this.ranges != null) {
            removeStaleRangeReferences();
            Iterator it = this.ranges.iterator();
            while (it.hasNext()) {
                Object obj2 = ((Reference) it.next()).get();
                if (obj2 == obj) {
                    it.remove();
                    return;
                } else if (obj2 == null) {
                    it.remove();
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void removedAttrNode(AttrImpl attrImpl, NodeImpl nodeImpl, String str) {
        AttrImpl attrImpl2 = attrImpl;
        NodeImpl nodeImpl2 = nodeImpl;
        String str2 = str;
        if (this.mutationEvents) {
            mutationEventsRemovedAttrNode(attrImpl2, nodeImpl2, str2);
        }
    }

    /* access modifiers changed from: package-private */
    public void removedNode(NodeImpl nodeImpl, boolean z) {
        NodeImpl nodeImpl2 = nodeImpl;
        boolean z2 = z;
        if (this.mutationEvents && !z2) {
            dispatchAggregateEvents(nodeImpl2, this.savedEnclosingAttr);
        }
    }

    /* access modifiers changed from: package-private */
    public void removingNode(NodeImpl nodeImpl, NodeImpl nodeImpl2, boolean z) {
        NodeImpl nodeImpl3 = nodeImpl;
        NodeImpl nodeImpl4 = nodeImpl2;
        boolean z2 = z;
        if (this.iterators != null) {
            notifyIteratorsRemovingNode(nodeImpl4);
        }
        if (this.ranges != null) {
            notifyRangesRemovingNode(nodeImpl4);
        }
        if (this.mutationEvents) {
            mutationEventsRemovingNode(nodeImpl3, nodeImpl4, z2);
        }
    }

    /* access modifiers changed from: package-private */
    public void renamedAttrNode(Attr attr, Attr attr2) {
    }

    /* access modifiers changed from: package-private */
    public void renamedElement(Element element, Element element2) {
    }

    /* access modifiers changed from: package-private */
    public void replacedCharacterData(NodeImpl nodeImpl, String str, String str2) {
        modifiedCharacterData(nodeImpl, str, str2, false);
    }

    /* access modifiers changed from: package-private */
    public void replacedNode(NodeImpl nodeImpl) {
        NodeImpl nodeImpl2 = nodeImpl;
        if (this.mutationEvents) {
            dispatchAggregateEvents(nodeImpl2, this.savedEnclosingAttr);
        }
    }

    /* access modifiers changed from: package-private */
    public void replacedText(CharacterDataImpl characterDataImpl) {
        CharacterDataImpl characterDataImpl2 = characterDataImpl;
        if (this.ranges != null) {
            notifyRangesReplacedText(characterDataImpl2);
        }
    }

    /* access modifiers changed from: package-private */
    public void replacingData(NodeImpl nodeImpl) {
        NodeImpl nodeImpl2 = nodeImpl;
        if (this.mutationEvents) {
            saveEnclosingAttr(nodeImpl2);
        }
    }

    /* access modifiers changed from: package-private */
    public void replacingNode(NodeImpl nodeImpl) {
        NodeImpl nodeImpl2 = nodeImpl;
        if (this.mutationEvents) {
            saveEnclosingAttr(nodeImpl2);
        }
    }

    /* access modifiers changed from: protected */
    public void saveEnclosingAttr(NodeImpl nodeImpl) {
        EnclosingAttr enclosingAttr;
        NodeImpl nodeImpl2 = nodeImpl;
        this.savedEnclosingAttr = null;
        if (LCount.lookup(MutationEventImpl.DOM_ATTR_MODIFIED).total > 0) {
            NodeImpl nodeImpl3 = nodeImpl2;
            while (true) {
                NodeImpl nodeImpl4 = nodeImpl3;
                if (nodeImpl4 != null) {
                    short nodeType = nodeImpl4.getNodeType();
                    if (nodeType == 2) {
                        new EnclosingAttr(this);
                        EnclosingAttr enclosingAttr2 = enclosingAttr;
                        enclosingAttr2.node = (AttrImpl) nodeImpl4;
                        enclosingAttr2.oldvalue = enclosingAttr2.node.getNodeValue();
                        this.savedEnclosingAttr = enclosingAttr2;
                        return;
                    } else if (nodeType == 5) {
                        nodeImpl3 = nodeImpl4.parentNode();
                    } else if (nodeType == 3) {
                        nodeImpl3 = nodeImpl4.parentNode();
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void setAttrNode(AttrImpl attrImpl, AttrImpl attrImpl2) {
        AttrImpl attrImpl3 = attrImpl;
        AttrImpl attrImpl4 = attrImpl2;
        if (!this.mutationEvents) {
            return;
        }
        if (attrImpl4 == null) {
            dispatchAggregateEvents(attrImpl3.ownerNode, attrImpl3, (String) null, 2);
        } else {
            dispatchAggregateEvents(attrImpl3.ownerNode, attrImpl3, attrImpl4.getNodeValue(), 1);
        }
    }

    /* access modifiers changed from: protected */
    public void setEventListeners(NodeImpl nodeImpl, Vector vector) {
        Hashtable hashtable;
        NodeImpl nodeImpl2 = nodeImpl;
        Vector vector2 = vector;
        if (this.eventListeners == null) {
            new Hashtable();
            this.eventListeners = hashtable;
        }
        if (vector2 == null) {
            Object remove = this.eventListeners.remove(nodeImpl2);
            if (this.eventListeners.isEmpty()) {
                this.mutationEvents = false;
                return;
            }
            return;
        }
        Object put = this.eventListeners.put(nodeImpl2, vector2);
        this.mutationEvents = true;
    }

    /* access modifiers changed from: package-private */
    public void setMutationEvents(boolean z) {
        boolean z2 = z;
        this.mutationEvents = z2;
    }

    /* access modifiers changed from: package-private */
    public void splitData(Node node, Node node2, int i) {
        Node node3 = node;
        Node node4 = node2;
        int i2 = i;
        if (this.ranges != null) {
            notifyRangesSplitData(node3, node4, i2);
        }
    }
}
