package org.apache.xerces.dom;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.StringTokenizer;
import org.apache.xerces.impl.Constants;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.impl.dv.DTDDVFactory;
import org.apache.xerces.impl.validation.ValidationManager;
import org.apache.xerces.util.DOMEntityResolverWrapper;
import org.apache.xerces.util.DOMErrorHandlerWrapper;
import org.apache.xerces.util.ParserConfigurationSettings;
import org.apache.xerces.util.SecurityManager;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.XMLDTDContentModelHandler;
import org.apache.xerces.xni.XMLDTDHandler;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLComponent;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLParserConfiguration;
import org.w3c.dom.DOMConfiguration;
import org.w3c.dom.DOMErrorHandler;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMStringList;
import org.w3c.dom.ls.LSResourceResolver;

public class DOMConfigurationImpl extends ParserConfigurationSettings implements XMLParserConfiguration, DOMConfiguration {
    protected static final String BALANCE_SYNTAX_TREES = "http://apache.org/xml/features/validation/balance-syntax-trees";
    protected static final short CDATA = 8;
    protected static final short COMMENTS = 32;
    protected static final String DISALLOW_DOCTYPE_DECL_FEATURE = "http://apache.org/xml/features/disallow-doctype-decl";
    protected static final String DTD_VALIDATOR_FACTORY_PROPERTY = "http://apache.org/xml/properties/internal/datatype-validator-factory";
    protected static final String DTD_VALIDATOR_PROPERTY = "http://apache.org/xml/properties/internal/validator/dtd";
    protected static final short DTNORMALIZATION = 2;
    protected static final String DYNAMIC_VALIDATION = "http://apache.org/xml/features/validation/dynamic";
    protected static final short ENTITIES = 4;
    protected static final String ENTITY_MANAGER = "http://apache.org/xml/properties/internal/entity-manager";
    protected static final String ENTITY_RESOLVER = "http://apache.org/xml/properties/internal/entity-resolver";
    protected static final String ERROR_HANDLER = "http://apache.org/xml/properties/internal/error-handler";
    protected static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
    protected static final String GENERATE_SYNTHETIC_ANNOTATIONS = "http://apache.org/xml/features/generate-synthetic-annotations";
    protected static final String GRAMMAR_POOL = "http://apache.org/xml/properties/internal/grammar-pool";
    protected static final String HONOUR_ALL_SCHEMALOCATIONS = "http://apache.org/xml/features/honour-all-schemaLocations";
    protected static final short INFOSET_FALSE_PARAMS = 14;
    protected static final short INFOSET_MASK = 815;
    protected static final short INFOSET_TRUE_PARAMS = 801;
    protected static final String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
    protected static final String JAXP_SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";
    protected static final short NAMESPACES = 1;
    protected static final String NAMESPACE_GROWTH = "http://apache.org/xml/features/namespace-growth";
    protected static final String NORMALIZE_DATA = "http://apache.org/xml/features/validation/schema/normalized-value";
    protected static final short NSDECL = 512;
    protected static final short PSVI = 128;
    protected static final String SCHEMA = "http://apache.org/xml/features/validation/schema";
    protected static final String SCHEMA_DV_FACTORY = "http://apache.org/xml/properties/internal/validation/schema/dv-factory";
    protected static final String SCHEMA_ELEMENT_DEFAULT = "http://apache.org/xml/features/validation/schema/element-default";
    protected static final String SCHEMA_FULL_CHECKING = "http://apache.org/xml/features/validation/schema-full-checking";
    protected static final String SCHEMA_LOCATION = "http://apache.org/xml/properties/schema/external-schemaLocation";
    protected static final String SCHEMA_NONS_LOCATION = "http://apache.org/xml/properties/schema/external-noNamespaceSchemaLocation";
    protected static final String SECURITY_MANAGER = "http://apache.org/xml/properties/security-manager";
    protected static final String SEND_PSVI = "http://apache.org/xml/features/validation/schema/augment-psvi";
    protected static final short SPLITCDATA = 16;
    protected static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    protected static final String TOLERATE_DUPLICATES = "http://apache.org/xml/features/internal/tolerate-duplicates";
    protected static final String USE_GRAMMAR_POOL_ONLY = "http://apache.org/xml/features/internal/validation/schema/use-grammar-pool-only";
    protected static final short VALIDATE = 64;
    protected static final String VALIDATE_ANNOTATIONS = "http://apache.org/xml/features/validate-annotations";
    protected static final String VALIDATION_MANAGER = "http://apache.org/xml/properties/internal/validation-manager";
    protected static final String WARN_ON_DUPLICATE_ATTDEF = "http://apache.org/xml/features/validation/warn-on-duplicate-attdef";
    protected static final short WELLFORMED = 256;
    protected static final String XERCES_NAMESPACES = "http://xml.org/sax/features/namespaces";
    protected static final String XERCES_VALIDATION = "http://xml.org/sax/features/validation";
    protected static final String XML11_DATATYPE_VALIDATOR_FACTORY = "org.apache.xerces.impl.dv.dtd.XML11DTDDVFactoryImpl";
    protected static final String XML_STRING = "http://xml.org/sax/properties/xml-string";
    protected ArrayList fComponents;
    protected DTDDVFactory fCurrentDVFactory;
    protected DTDDVFactory fDatatypeValidatorFactory;
    XMLDocumentHandler fDocumentHandler;
    protected final DOMErrorHandlerWrapper fErrorHandlerWrapper;
    protected XMLErrorReporter fErrorReporter;
    protected Locale fLocale;
    private DOMStringList fRecognizedParameters;
    private String fSchemaLocation;
    protected SymbolTable fSymbolTable;
    protected ValidationManager fValidationManager;
    protected DTDDVFactory fXML11DatatypeFactory;
    protected short features;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    protected DOMConfigurationImpl() {
        this((SymbolTable) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    protected DOMConfigurationImpl(SymbolTable symbolTable) {
        this(symbolTable, (XMLComponentManager) null);
    }

    /* JADX WARNING: type inference failed for: r9v112, types: [org.apache.xerces.xni.parser.XMLComponent] */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected DOMConfigurationImpl(org.apache.xerces.util.SymbolTable r14, org.apache.xerces.xni.parser.XMLComponentManager r15) {
        /*
            r13 = this;
            r0 = r13
            r1 = r14
            r2 = r15
            r8 = r0
            r9 = r2
            r8.<init>(r9)
            r8 = r0
            r9 = 0
            r8.features = r9
            r8 = r0
            org.apache.xerces.util.DOMErrorHandlerWrapper r9 = new org.apache.xerces.util.DOMErrorHandlerWrapper
            r12 = r9
            r9 = r12
            r10 = r12
            r10.<init>()
            r8.fErrorHandlerWrapper = r9
            r8 = r0
            r9 = 0
            r8.fSchemaLocation = r9
            r8 = r0
            java.util.ArrayList r9 = new java.util.ArrayList
            r12 = r9
            r9 = r12
            r10 = r12
            r10.<init>()
            r8.fRecognizedFeatures = r9
            r8 = r0
            java.util.ArrayList r9 = new java.util.ArrayList
            r12 = r9
            r9 = r12
            r10 = r12
            r10.<init>()
            r8.fRecognizedProperties = r9
            r8 = r0
            java.util.HashMap r9 = new java.util.HashMap
            r12 = r9
            r9 = r12
            r10 = r12
            r10.<init>()
            r8.fFeatures = r9
            r8 = r0
            java.util.HashMap r9 = new java.util.HashMap
            r12 = r9
            r9 = r12
            r10 = r12
            r10.<init>()
            r8.fProperties = r9
            r8 = 18
            java.lang.String[] r8 = new java.lang.String[r8]
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 0
            java.lang.String r11 = "http://xml.org/sax/features/validation"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 1
            java.lang.String r11 = "http://xml.org/sax/features/namespaces"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 2
            java.lang.String r11 = "http://apache.org/xml/features/validation/schema"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 3
            java.lang.String r11 = "http://apache.org/xml/features/validation/schema-full-checking"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 4
            java.lang.String r11 = "http://apache.org/xml/features/validation/dynamic"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 5
            java.lang.String r11 = "http://apache.org/xml/features/validation/schema/normalized-value"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 6
            java.lang.String r11 = "http://apache.org/xml/features/validation/schema/element-default"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 7
            java.lang.String r11 = "http://apache.org/xml/features/validation/schema/augment-psvi"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 8
            java.lang.String r11 = "http://apache.org/xml/features/generate-synthetic-annotations"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 9
            java.lang.String r11 = "http://apache.org/xml/features/validate-annotations"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 10
            java.lang.String r11 = "http://apache.org/xml/features/honour-all-schemaLocations"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 11
            java.lang.String r11 = "http://apache.org/xml/features/internal/validation/schema/use-grammar-pool-only"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 12
            java.lang.String r11 = "http://apache.org/xml/features/disallow-doctype-decl"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 13
            java.lang.String r11 = "http://apache.org/xml/features/validation/balance-syntax-trees"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 14
            java.lang.String r11 = "http://apache.org/xml/features/validation/warn-on-duplicate-attdef"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 15
            java.lang.String r11 = "http://apache.org/xml/features/internal/parser-settings"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 16
            java.lang.String r11 = "http://apache.org/xml/features/namespace-growth"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 17
            java.lang.String r11 = "http://apache.org/xml/features/internal/tolerate-duplicates"
            r9[r10] = r11
            r3 = r8
            r8 = r0
            r9 = r3
            r8.addRecognizedFeatures(r9)
            r8 = r0
            java.lang.String r9 = "http://xml.org/sax/features/validation"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/validation/schema"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/validation/schema-full-checking"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/validation/dynamic"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/validation/schema/normalized-value"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/validation/schema/element-default"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://xml.org/sax/features/namespaces"
            r10 = 1
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/validation/schema/augment-psvi"
            r10 = 1
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/generate-synthetic-annotations"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/validate-annotations"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/honour-all-schemaLocations"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/internal/validation/schema/use-grammar-pool-only"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/disallow-doctype-decl"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/validation/balance-syntax-trees"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/validation/warn-on-duplicate-attdef"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/internal/parser-settings"
            r10 = 1
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/namespace-growth"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/features/internal/tolerate-duplicates"
            r10 = 0
            r8.setFeature(r9, r10)
            r8 = 16
            java.lang.String[] r8 = new java.lang.String[r8]
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 0
            java.lang.String r11 = "http://xml.org/sax/properties/xml-string"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 1
            java.lang.String r11 = "http://apache.org/xml/properties/internal/symbol-table"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 2
            java.lang.String r11 = "http://apache.org/xml/properties/internal/error-handler"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 3
            java.lang.String r11 = "http://apache.org/xml/properties/internal/entity-resolver"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 4
            java.lang.String r11 = "http://apache.org/xml/properties/internal/error-reporter"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 5
            java.lang.String r11 = "http://apache.org/xml/properties/internal/entity-manager"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 6
            java.lang.String r11 = "http://apache.org/xml/properties/internal/validation-manager"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 7
            java.lang.String r11 = "http://apache.org/xml/properties/internal/grammar-pool"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 8
            java.lang.String r11 = "http://apache.org/xml/properties/security-manager"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 9
            java.lang.String r11 = "http://java.sun.com/xml/jaxp/properties/schemaSource"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 10
            java.lang.String r11 = "http://java.sun.com/xml/jaxp/properties/schemaLanguage"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 11
            java.lang.String r11 = "http://apache.org/xml/properties/schema/external-schemaLocation"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 12
            java.lang.String r11 = "http://apache.org/xml/properties/schema/external-noNamespaceSchemaLocation"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 13
            java.lang.String r11 = "http://apache.org/xml/properties/internal/validator/dtd"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 14
            java.lang.String r11 = "http://apache.org/xml/properties/internal/datatype-validator-factory"
            r9[r10] = r11
            r12 = r8
            r8 = r12
            r9 = r12
            r10 = 15
            java.lang.String r11 = "http://apache.org/xml/properties/internal/validation/schema/dv-factory"
            r9[r10] = r11
            r4 = r8
            r8 = r0
            r9 = r4
            r8.addRecognizedProperties(r9)
            r8 = r0
            r12 = r8
            r8 = r12
            r9 = r12
            short r9 = r9.features
            r10 = 1
            r9 = r9 | 1
            short r9 = (short) r9
            r8.features = r9
            r8 = r0
            r12 = r8
            r8 = r12
            r9 = r12
            short r9 = r9.features
            r10 = 4
            r9 = r9 | 4
            short r9 = (short) r9
            r8.features = r9
            r8 = r0
            r12 = r8
            r8 = r12
            r9 = r12
            short r9 = r9.features
            r10 = 32
            r9 = r9 | 32
            short r9 = (short) r9
            r8.features = r9
            r8 = r0
            r12 = r8
            r8 = r12
            r9 = r12
            short r9 = r9.features
            r10 = 8
            r9 = r9 | 8
            short r9 = (short) r9
            r8.features = r9
            r8 = r0
            r12 = r8
            r8 = r12
            r9 = r12
            short r9 = r9.features
            r10 = 16
            r9 = r9 | 16
            short r9 = (short) r9
            r8.features = r9
            r8 = r0
            r12 = r8
            r8 = r12
            r9 = r12
            short r9 = r9.features
            r10 = 256(0x100, float:3.59E-43)
            r9 = r9 | 256(0x100, float:3.59E-43)
            short r9 = (short) r9
            r8.features = r9
            r8 = r0
            r12 = r8
            r8 = r12
            r9 = r12
            short r9 = r9.features
            r10 = 512(0x200, float:7.175E-43)
            r9 = r9 | 512(0x200, float:7.175E-43)
            short r9 = (short) r9
            r8.features = r9
            r8 = r1
            if (r8 != 0) goto L_0x0294
            org.apache.xerces.util.SymbolTable r8 = new org.apache.xerces.util.SymbolTable
            r12 = r8
            r8 = r12
            r9 = r12
            r9.<init>()
            r1 = r8
        L_0x0294:
            r8 = r0
            r9 = r1
            r8.fSymbolTable = r9
            r8 = r0
            java.util.ArrayList r9 = new java.util.ArrayList
            r12 = r9
            r9 = r12
            r10 = r12
            r10.<init>()
            r8.fComponents = r9
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/properties/internal/symbol-table"
            r10 = r0
            org.apache.xerces.util.SymbolTable r10 = r10.fSymbolTable
            r8.setProperty(r9, r10)
            r8 = r0
            org.apache.xerces.impl.XMLErrorReporter r9 = new org.apache.xerces.impl.XMLErrorReporter
            r12 = r9
            r9 = r12
            r10 = r12
            r10.<init>()
            r8.fErrorReporter = r9
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/properties/internal/error-reporter"
            r10 = r0
            org.apache.xerces.impl.XMLErrorReporter r10 = r10.fErrorReporter
            r8.setProperty(r9, r10)
            r8 = r0
            r9 = r0
            org.apache.xerces.impl.XMLErrorReporter r9 = r9.fErrorReporter
            r8.addComponent(r9)
            r8 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r9 = org.apache.xerces.impl.dv.DTDDVFactory.getInstance()
            r8.fDatatypeValidatorFactory = r9
            r8 = r0
            java.lang.String r9 = "org.apache.xerces.impl.dv.dtd.XML11DTDDVFactoryImpl"
            org.apache.xerces.impl.dv.DTDDVFactory r9 = org.apache.xerces.impl.dv.DTDDVFactory.getInstance(r9)
            r8.fXML11DatatypeFactory = r9
            r8 = r0
            r9 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r9 = r9.fDatatypeValidatorFactory
            r8.fCurrentDVFactory = r9
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/properties/internal/datatype-validator-factory"
            r10 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r10 = r10.fCurrentDVFactory
            r8.setProperty(r9, r10)
            org.apache.xerces.impl.XMLEntityManager r8 = new org.apache.xerces.impl.XMLEntityManager
            r12 = r8
            r8 = r12
            r9 = r12
            r9.<init>()
            r5 = r8
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/properties/internal/entity-manager"
            r10 = r5
            r8.setProperty(r9, r10)
            r8 = r0
            r9 = r5
            r8.addComponent(r9)
            r8 = r0
            r9 = r0
            org.apache.xerces.impl.validation.ValidationManager r9 = r9.createValidationManager()
            r8.fValidationManager = r9
            r8 = r0
            java.lang.String r9 = "http://apache.org/xml/properties/internal/validation-manager"
            r10 = r0
            org.apache.xerces.impl.validation.ValidationManager r10 = r10.fValidationManager
            r8.setProperty(r9, r10)
            r8 = r0
            org.apache.xerces.impl.XMLErrorReporter r8 = r8.fErrorReporter
            java.lang.String r9 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            org.apache.xerces.util.MessageFormatter r8 = r8.getMessageFormatter(r9)
            if (r8 != 0) goto L_0x033b
            org.apache.xerces.impl.msg.XMLMessageFormatter r8 = new org.apache.xerces.impl.msg.XMLMessageFormatter
            r12 = r8
            r8 = r12
            r9 = r12
            r9.<init>()
            r6 = r8
            r8 = r0
            org.apache.xerces.impl.XMLErrorReporter r8 = r8.fErrorReporter
            java.lang.String r9 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            r10 = r6
            r8.putMessageFormatter(r9, r10)
            r8 = r0
            org.apache.xerces.impl.XMLErrorReporter r8 = r8.fErrorReporter
            java.lang.String r9 = "http://www.w3.org/TR/1999/REC-xml-names-19990114"
            r10 = r6
            r8.putMessageFormatter(r9, r10)
        L_0x033b:
            r8 = r0
            org.apache.xerces.impl.XMLErrorReporter r8 = r8.fErrorReporter
            java.lang.String r9 = "http://www.w3.org/TR/xml-schema-1"
            org.apache.xerces.util.MessageFormatter r8 = r8.getMessageFormatter(r9)
            if (r8 != 0) goto L_0x0365
            r8 = 0
            r6 = r8
            java.lang.String r8 = "org.apache.xerces.impl.xs.XSMessageFormatter"
            java.lang.ClassLoader r9 = org.apache.xerces.dom.ObjectFactory.findClassLoader()     // Catch:{ Exception -> 0x036e }
            r10 = 1
            java.lang.Object r8 = org.apache.xerces.dom.ObjectFactory.newInstance(r8, r9, r10)     // Catch:{ Exception -> 0x036e }
            org.apache.xerces.util.MessageFormatter r8 = (org.apache.xerces.util.MessageFormatter) r8     // Catch:{ Exception -> 0x036e }
            r6 = r8
        L_0x0358:
            r8 = r6
            if (r8 == 0) goto L_0x0365
            r8 = r0
            org.apache.xerces.impl.XMLErrorReporter r8 = r8.fErrorReporter
            java.lang.String r9 = "http://www.w3.org/TR/xml-schema-1"
            r10 = r6
            r8.putMessageFormatter(r9, r10)
        L_0x0365:
            r8 = r0
            java.util.Locale r9 = java.util.Locale.getDefault()     // Catch:{ XNIException -> 0x0371 }
            r8.setLocale(r9)     // Catch:{ XNIException -> 0x0371 }
        L_0x036d:
            return
        L_0x036e:
            r8 = move-exception
            r7 = r8
            goto L_0x0358
        L_0x0371:
            r8 = move-exception
            r6 = r8
            goto L_0x036d
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.DOMConfigurationImpl.<init>(org.apache.xerces.util.SymbolTable, org.apache.xerces.xni.parser.XMLComponentManager):void");
    }

    private static DOMException newFeatureNotFoundError(String str) {
        DOMException dOMException;
        new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "FEATURE_NOT_FOUND", new Object[]{str}));
        return dOMException;
    }

    private static DOMException newFeatureNotSupportedError(String str) {
        DOMException dOMException;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "FEATURE_NOT_SUPPORTED", new Object[]{str}));
        return dOMException;
    }

    private static DOMException newTypeMismatchError(String str) {
        DOMException dOMException;
        new DOMException(17, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "TYPE_MISMATCH_ERR", new Object[]{str}));
        return dOMException;
    }

    /* access modifiers changed from: protected */
    public void addComponent(XMLComponent xMLComponent) {
        XMLComponent xMLComponent2 = xMLComponent;
        if (!this.fComponents.contains(xMLComponent2)) {
            boolean add = this.fComponents.add(xMLComponent2);
            addRecognizedFeatures(xMLComponent2.getRecognizedFeatures());
            addRecognizedProperties(xMLComponent2.getRecognizedProperties());
        }
    }

    public boolean canSetParameter(String str, Object obj) {
        String str2 = str;
        Object obj2 = obj;
        if (obj2 == null) {
            return true;
        }
        if (obj2 instanceof Boolean) {
            if (str2.equalsIgnoreCase("comments") || str2.equalsIgnoreCase("datatype-normalization") || str2.equalsIgnoreCase("cdata-sections") || str2.equalsIgnoreCase("entities") || str2.equalsIgnoreCase("split-cdata-sections") || str2.equalsIgnoreCase("namespaces") || str2.equalsIgnoreCase("validate") || str2.equalsIgnoreCase("well-formed") || str2.equalsIgnoreCase("infoset") || str2.equalsIgnoreCase("namespace-declarations")) {
                return true;
            }
            if (str2.equalsIgnoreCase("normalize-characters") || str2.equalsIgnoreCase("canonical-form") || str2.equalsIgnoreCase("validate-if-schema") || str2.equalsIgnoreCase("check-character-normalization")) {
                return !obj2.equals(Boolean.TRUE);
            } else if (!str2.equalsIgnoreCase("element-content-whitespace") && !str2.equalsIgnoreCase(SEND_PSVI)) {
                return false;
            } else {
                return obj2.equals(Boolean.TRUE);
            }
        } else if (str2.equalsIgnoreCase("error-handler")) {
            return obj2 instanceof DOMErrorHandler;
        } else if (str2.equalsIgnoreCase("resource-resolver")) {
            return obj2 instanceof LSResourceResolver;
        } else if (str2.equalsIgnoreCase("schema-location")) {
            return obj2 instanceof String;
        } else if (str2.equalsIgnoreCase("schema-type")) {
            return (obj2 instanceof String) && (obj2.equals(Constants.NS_XMLSCHEMA) || obj2.equals(Constants.NS_DTD));
        } else if (str2.equalsIgnoreCase(ENTITY_RESOLVER)) {
            return obj2 instanceof XMLEntityResolver;
        } else if (str2.equalsIgnoreCase(SYMBOL_TABLE)) {
            return obj2 instanceof SymbolTable;
        } else if (str2.equalsIgnoreCase(GRAMMAR_POOL)) {
            return obj2 instanceof XMLGrammarPool;
        } else if (!str2.equalsIgnoreCase(SECURITY_MANAGER)) {
            return false;
        } else {
            return obj2 instanceof SecurityManager;
        }
    }

    /* access modifiers changed from: protected */
    public void checkProperty(String str) throws XMLConfigurationException {
        Throwable th;
        String str2 = str;
        if (!str2.startsWith("http://xml.org/sax/properties/") || str2.length() - "http://xml.org/sax/properties/".length() != "xml-string".length() || !str2.endsWith("xml-string")) {
            super.checkProperty(str2);
            return;
        }
        Throwable th2 = th;
        new XMLConfigurationException(1, str2);
        throw th2;
    }

    /* access modifiers changed from: protected */
    public ValidationManager createValidationManager() {
        ValidationManager validationManager;
        new ValidationManager();
        return validationManager;
    }

    public XMLDTDContentModelHandler getDTDContentModelHandler() {
        return null;
    }

    public XMLDTDHandler getDTDHandler() {
        return null;
    }

    public XMLDocumentHandler getDocumentHandler() {
        return this.fDocumentHandler;
    }

    public XMLEntityResolver getEntityResolver() {
        return (XMLEntityResolver) this.fProperties.get(ENTITY_RESOLVER);
    }

    public XMLErrorHandler getErrorHandler() {
        return (XMLErrorHandler) this.fProperties.get(ERROR_HANDLER);
    }

    public boolean getFeature(String str) throws XMLConfigurationException {
        String str2 = str;
        if (str2.equals("http://apache.org/xml/features/internal/parser-settings")) {
            return true;
        }
        return super.getFeature(str2);
    }

    public Locale getLocale() {
        return this.fLocale;
    }

    public Object getParameter(String str) throws DOMException {
        String str2 = str;
        if (str2.equalsIgnoreCase("comments")) {
            return (this.features & 32) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("namespaces")) {
            return (this.features & 1) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("datatype-normalization")) {
            return (this.features & 2) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("cdata-sections")) {
            return (this.features & 8) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("entities")) {
            return (this.features & 4) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("split-cdata-sections")) {
            return (this.features & 16) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("validate")) {
            return (this.features & 64) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("well-formed")) {
            return (this.features & 256) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("namespace-declarations")) {
            return (this.features & 512) != 0 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("infoset")) {
            return (this.features & INFOSET_MASK) == 801 ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("normalize-characters") || str2.equalsIgnoreCase("canonical-form") || str2.equalsIgnoreCase("validate-if-schema") || str2.equalsIgnoreCase("check-character-normalization")) {
            return Boolean.FALSE;
        } else {
            if (str2.equalsIgnoreCase(SEND_PSVI)) {
                return Boolean.TRUE;
            }
            if (str2.equalsIgnoreCase("psvi")) {
                return (this.features & 128) != 0 ? Boolean.TRUE : Boolean.FALSE;
            } else if (str2.equalsIgnoreCase("element-content-whitespace")) {
                return Boolean.TRUE;
            } else {
                if (str2.equalsIgnoreCase("error-handler")) {
                    return this.fErrorHandlerWrapper.getErrorHandler();
                }
                if (str2.equalsIgnoreCase("resource-resolver")) {
                    XMLEntityResolver entityResolver = getEntityResolver();
                    if (entityResolver == null || !(entityResolver instanceof DOMEntityResolverWrapper)) {
                        return null;
                    }
                    return ((DOMEntityResolverWrapper) entityResolver).getEntityResolver();
                } else if (str2.equalsIgnoreCase("schema-type")) {
                    return getProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage");
                } else {
                    if (str2.equalsIgnoreCase("schema-location")) {
                        return this.fSchemaLocation;
                    }
                    if (str2.equalsIgnoreCase(ENTITY_RESOLVER)) {
                        return getEntityResolver();
                    }
                    if (str2.equalsIgnoreCase(SYMBOL_TABLE)) {
                        return getProperty(SYMBOL_TABLE);
                    }
                    if (str2.equalsIgnoreCase(GRAMMAR_POOL)) {
                        return getProperty(GRAMMAR_POOL);
                    }
                    if (str2.equalsIgnoreCase(SECURITY_MANAGER)) {
                        return getProperty(SECURITY_MANAGER);
                    }
                    throw newFeatureNotFoundError(str2);
                }
            }
        }
    }

    public DOMStringList getParameterNames() {
        ArrayList arrayList;
        DOMStringList dOMStringList;
        if (this.fRecognizedParameters == null) {
            new ArrayList();
            ArrayList arrayList2 = arrayList;
            boolean add = arrayList2.add("comments");
            boolean add2 = arrayList2.add("datatype-normalization");
            boolean add3 = arrayList2.add("cdata-sections");
            boolean add4 = arrayList2.add("entities");
            boolean add5 = arrayList2.add("split-cdata-sections");
            boolean add6 = arrayList2.add("namespaces");
            boolean add7 = arrayList2.add("validate");
            boolean add8 = arrayList2.add("infoset");
            boolean add9 = arrayList2.add("normalize-characters");
            boolean add10 = arrayList2.add("canonical-form");
            boolean add11 = arrayList2.add("validate-if-schema");
            boolean add12 = arrayList2.add("check-character-normalization");
            boolean add13 = arrayList2.add("well-formed");
            boolean add14 = arrayList2.add("namespace-declarations");
            boolean add15 = arrayList2.add("element-content-whitespace");
            boolean add16 = arrayList2.add("error-handler");
            boolean add17 = arrayList2.add("schema-type");
            boolean add18 = arrayList2.add("schema-location");
            boolean add19 = arrayList2.add("resource-resolver");
            boolean add20 = arrayList2.add(ENTITY_RESOLVER);
            boolean add21 = arrayList2.add(GRAMMAR_POOL);
            boolean add22 = arrayList2.add(SECURITY_MANAGER);
            boolean add23 = arrayList2.add(SYMBOL_TABLE);
            boolean add24 = arrayList2.add(SEND_PSVI);
            new DOMStringListImpl(arrayList2);
            this.fRecognizedParameters = dOMStringList;
        }
        return this.fRecognizedParameters;
    }

    public void parse(XMLInputSource xMLInputSource) throws XNIException, IOException {
    }

    /* access modifiers changed from: protected */
    public void reset() throws XNIException {
        if (this.fValidationManager != null) {
            this.fValidationManager.reset();
        }
        int size = this.fComponents.size();
        for (int i = 0; i < size; i++) {
            ((XMLComponent) this.fComponents.get(i)).reset(this);
        }
    }

    public void setDTDContentModelHandler(XMLDTDContentModelHandler xMLDTDContentModelHandler) {
    }

    public void setDTDHandler(XMLDTDHandler xMLDTDHandler) {
    }

    /* access modifiers changed from: protected */
    public final void setDTDValidatorFactory(String str) {
        if ("1.1".equals(str)) {
            if (this.fCurrentDVFactory != this.fXML11DatatypeFactory) {
                this.fCurrentDVFactory = this.fXML11DatatypeFactory;
                setProperty(DTD_VALIDATOR_FACTORY_PROPERTY, this.fCurrentDVFactory);
            }
        } else if (this.fCurrentDVFactory != this.fDatatypeValidatorFactory) {
            this.fCurrentDVFactory = this.fDatatypeValidatorFactory;
            setProperty(DTD_VALIDATOR_FACTORY_PROPERTY, this.fCurrentDVFactory);
        }
    }

    public void setDocumentHandler(XMLDocumentHandler xMLDocumentHandler) {
        XMLDocumentHandler xMLDocumentHandler2 = xMLDocumentHandler;
        this.fDocumentHandler = xMLDocumentHandler2;
    }

    public void setEntityResolver(XMLEntityResolver xMLEntityResolver) {
        Object put = this.fProperties.put(ENTITY_RESOLVER, xMLEntityResolver);
    }

    public void setErrorHandler(XMLErrorHandler xMLErrorHandler) {
        XMLErrorHandler xMLErrorHandler2 = xMLErrorHandler;
        if (xMLErrorHandler2 != null) {
            Object put = this.fProperties.put(ERROR_HANDLER, xMLErrorHandler2);
        }
    }

    public void setFeature(String str, boolean z) throws XMLConfigurationException {
        super.setFeature(str, z);
    }

    public void setLocale(Locale locale) throws XNIException {
        Locale locale2 = locale;
        this.fLocale = locale2;
        this.fErrorReporter.setLocale(locale2);
    }

    public void setParameter(String str, Object obj) throws DOMException {
        StringTokenizer stringTokenizer;
        ArrayList arrayList;
        XMLEntityResolver xMLEntityResolver;
        String str2 = str;
        Object obj2 = obj;
        boolean z = true;
        if (obj2 instanceof Boolean) {
            boolean booleanValue = ((Boolean) obj2).booleanValue();
            if (str2.equalsIgnoreCase("comments")) {
                this.features = booleanValue ? (short) (this.features | 32) : (short) (this.features & -33);
            } else if (str2.equalsIgnoreCase("datatype-normalization")) {
                setFeature(NORMALIZE_DATA, booleanValue);
                this.features = booleanValue ? (short) (this.features | 2) : (short) (this.features & -3);
                if (booleanValue) {
                    this.features = (short) (this.features | 64);
                }
            } else if (str2.equalsIgnoreCase("namespaces")) {
                this.features = booleanValue ? (short) (this.features | 1) : (short) (this.features & -2);
            } else if (str2.equalsIgnoreCase("cdata-sections")) {
                this.features = booleanValue ? (short) (this.features | 8) : (short) (this.features & -9);
            } else if (str2.equalsIgnoreCase("entities")) {
                this.features = booleanValue ? (short) (this.features | 4) : (short) (this.features & -5);
            } else if (str2.equalsIgnoreCase("split-cdata-sections")) {
                this.features = booleanValue ? (short) (this.features | 16) : (short) (this.features & -17);
            } else if (str2.equalsIgnoreCase("validate")) {
                this.features = booleanValue ? (short) (this.features | 64) : (short) (this.features & -65);
            } else if (str2.equalsIgnoreCase("well-formed")) {
                this.features = booleanValue ? (short) (this.features | 256) : (short) (this.features & -257);
            } else if (str2.equalsIgnoreCase("namespace-declarations")) {
                this.features = booleanValue ? (short) (this.features | 512) : (short) (this.features & -513);
            } else if (str2.equalsIgnoreCase("infoset")) {
                if (booleanValue) {
                    this.features = (short) (this.features | INFOSET_TRUE_PARAMS);
                    this.features = (short) (this.features & -15);
                    setFeature(NORMALIZE_DATA, false);
                }
            } else if (str2.equalsIgnoreCase("normalize-characters") || str2.equalsIgnoreCase("canonical-form") || str2.equalsIgnoreCase("validate-if-schema") || str2.equalsIgnoreCase("check-character-normalization")) {
                if (booleanValue) {
                    throw newFeatureNotSupportedError(str2);
                }
            } else if (str2.equalsIgnoreCase("element-content-whitespace")) {
                if (!booleanValue) {
                    throw newFeatureNotSupportedError(str2);
                }
            } else if (str2.equalsIgnoreCase(SEND_PSVI)) {
                if (!booleanValue) {
                    throw newFeatureNotSupportedError(str2);
                }
            } else if (str2.equalsIgnoreCase("psvi")) {
                this.features = booleanValue ? (short) (this.features | 128) : (short) (this.features & -129);
            } else {
                z = false;
            }
        }
        if (z && (obj2 instanceof Boolean)) {
            return;
        }
        if (str2.equalsIgnoreCase("error-handler")) {
            if ((obj2 instanceof DOMErrorHandler) || obj2 == null) {
                this.fErrorHandlerWrapper.setErrorHandler((DOMErrorHandler) obj2);
                setErrorHandler(this.fErrorHandlerWrapper);
                return;
            }
            throw newTypeMismatchError(str2);
        } else if (str2.equalsIgnoreCase("resource-resolver")) {
            if ((obj2 instanceof LSResourceResolver) || obj2 == null) {
                try {
                    new DOMEntityResolverWrapper((LSResourceResolver) obj2);
                    setEntityResolver(xMLEntityResolver);
                } catch (XMLConfigurationException e) {
                    XMLConfigurationException xMLConfigurationException = e;
                }
            } else {
                throw newTypeMismatchError(str2);
            }
        } else if (str2.equalsIgnoreCase("schema-location")) {
            if ((obj2 instanceof String) || obj2 == null) {
                if (obj2 == null) {
                    try {
                        this.fSchemaLocation = null;
                        setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource", (Object) null);
                    } catch (XMLConfigurationException e2) {
                        XMLConfigurationException xMLConfigurationException2 = e2;
                        return;
                    }
                } else {
                    this.fSchemaLocation = (String) obj2;
                    new StringTokenizer(this.fSchemaLocation, " \n\t\r");
                    StringTokenizer stringTokenizer2 = stringTokenizer;
                    if (stringTokenizer2.hasMoreTokens()) {
                        new ArrayList();
                        ArrayList arrayList2 = arrayList;
                        boolean add = arrayList2.add(stringTokenizer2.nextToken());
                        while (stringTokenizer2.hasMoreTokens()) {
                            boolean add2 = arrayList2.add(stringTokenizer2.nextToken());
                        }
                        setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource", arrayList2.toArray(new String[arrayList2.size()]));
                    } else {
                        setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource", new String[]{(String) obj2});
                    }
                }
                return;
            }
            throw newTypeMismatchError(str2);
        } else if (str2.equalsIgnoreCase("schema-type")) {
            if ((obj2 instanceof String) || obj2 == null) {
                if (obj2 == null) {
                    try {
                        setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage", (Object) null);
                    } catch (XMLConfigurationException e3) {
                        XMLConfigurationException xMLConfigurationException3 = e3;
                        return;
                    }
                } else if (obj2.equals(Constants.NS_XMLSCHEMA)) {
                    setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage", Constants.NS_XMLSCHEMA);
                } else if (obj2.equals(Constants.NS_DTD)) {
                    setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage", Constants.NS_DTD);
                }
                return;
            }
            throw newTypeMismatchError(str2);
        } else if (str2.equalsIgnoreCase(ENTITY_RESOLVER)) {
            if ((obj2 instanceof XMLEntityResolver) || obj2 == null) {
                try {
                    setEntityResolver((XMLEntityResolver) obj2);
                } catch (XMLConfigurationException e4) {
                    XMLConfigurationException xMLConfigurationException4 = e4;
                }
            } else {
                throw newTypeMismatchError(str2);
            }
        } else if (str2.equalsIgnoreCase(SYMBOL_TABLE)) {
            if (obj2 instanceof SymbolTable) {
                setProperty(SYMBOL_TABLE, obj2);
                return;
            }
            throw newTypeMismatchError(str2);
        } else if (str2.equalsIgnoreCase(GRAMMAR_POOL)) {
            if ((obj2 instanceof XMLGrammarPool) || obj2 == null) {
                setProperty(GRAMMAR_POOL, obj2);
                return;
            }
            throw newTypeMismatchError(str2);
        } else if (!str2.equalsIgnoreCase(SECURITY_MANAGER)) {
            throw newFeatureNotFoundError(str2);
        } else if ((obj2 instanceof SecurityManager) || obj2 == null) {
            setProperty(SECURITY_MANAGER, obj2);
        } else {
            throw newTypeMismatchError(str2);
        }
    }

    public void setProperty(String str, Object obj) throws XMLConfigurationException {
        super.setProperty(str, obj);
    }
}
