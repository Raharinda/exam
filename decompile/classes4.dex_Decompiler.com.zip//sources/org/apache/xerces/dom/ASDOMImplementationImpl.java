package org.apache.xerces.dom;

import org.apache.xerces.dom3.as.ASModel;
import org.apache.xerces.dom3.as.DOMASBuilder;
import org.apache.xerces.dom3.as.DOMASWriter;
import org.apache.xerces.dom3.as.DOMImplementationAS;
import org.apache.xerces.parsers.DOMASBuilderImpl;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMImplementation;

public class ASDOMImplementationImpl extends DOMImplementationImpl implements DOMImplementationAS {
    static final ASDOMImplementationImpl singleton;

    static {
        ASDOMImplementationImpl aSDOMImplementationImpl;
        new ASDOMImplementationImpl();
        singleton = aSDOMImplementationImpl;
    }

    public ASDOMImplementationImpl() {
    }

    public static DOMImplementation getDOMImplementation() {
        return singleton;
    }

    public ASModel createAS(boolean z) {
        ASModel aSModel;
        new ASModelImpl(z);
        return aSModel;
    }

    public DOMASBuilder createDOMASBuilder() {
        DOMASBuilder dOMASBuilder;
        new DOMASBuilderImpl();
        return dOMASBuilder;
    }

    public DOMASWriter createDOMASWriter() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
        throw th2;
    }
}
