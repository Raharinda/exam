package org.apache.xerces.dom;

import org.w3c.dom.Entity;
import org.w3c.dom.Node;

public class EntityImpl extends ParentNode implements Entity {
    static final long serialVersionUID = -3575760943444303423L;
    protected String baseURI;
    protected String encoding;
    protected String inputEncoding;
    protected String name;
    protected String notationName;
    protected String publicId;
    protected String systemId;
    protected String version;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public EntityImpl(CoreDocumentImpl coreDocumentImpl, String str) {
        super(coreDocumentImpl);
        this.name = str;
        isReadOnly(true);
    }

    public Node cloneNode(boolean z) {
        boolean z2 = z;
        EntityImpl entityImpl = (EntityImpl) super.cloneNode(z2);
        entityImpl.setReadOnly(true, z2);
        return entityImpl;
    }

    public String getBaseURI() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.baseURI != null ? this.baseURI : ((CoreDocumentImpl) getOwnerDocument()).getBaseURI();
    }

    public String getInputEncoding() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.inputEncoding;
    }

    public String getNodeName() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.name;
    }

    public short getNodeType() {
        return 6;
    }

    public String getNotationName() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.notationName;
    }

    public String getPublicId() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.publicId;
    }

    public String getSystemId() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.systemId;
    }

    public String getXmlEncoding() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.encoding;
    }

    public String getXmlVersion() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.version;
    }

    public void setBaseURI(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        this.baseURI = str2;
    }

    public void setInputEncoding(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        this.inputEncoding = str2;
    }

    public void setNotationName(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        this.notationName = str2;
    }

    public void setPublicId(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        this.publicId = str2;
    }

    public void setSystemId(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        this.systemId = str2;
    }

    public void setXmlEncoding(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        this.encoding = str2;
    }

    public void setXmlVersion(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        this.version = str2;
    }
}
