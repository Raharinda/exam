package org.apache.xerces.dom;

import org.w3c.dom.Node;

public abstract class ChildNode extends NodeImpl {
    static final long serialVersionUID = -6112455738802414002L;
    protected ChildNode nextSibling;
    protected ChildNode previousSibling;

    public ChildNode() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected ChildNode(CoreDocumentImpl coreDocumentImpl) {
        super(coreDocumentImpl);
    }

    public Node cloneNode(boolean z) {
        ChildNode childNode = (ChildNode) super.cloneNode(z);
        childNode.previousSibling = null;
        childNode.nextSibling = null;
        childNode.isFirstChild(false);
        return childNode;
    }

    public Node getNextSibling() {
        return this.nextSibling;
    }

    public Node getParentNode() {
        return isOwned() ? this.ownerNode : null;
    }

    public Node getPreviousSibling() {
        return isFirstChild() ? null : this.previousSibling;
    }

    /* access modifiers changed from: package-private */
    public final NodeImpl parentNode() {
        return isOwned() ? this.ownerNode : null;
    }

    /* access modifiers changed from: package-private */
    public final ChildNode previousSibling() {
        return isFirstChild() ? null : this.previousSibling;
    }
}
