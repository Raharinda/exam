package org.apache.xerces.dom.events;

import org.w3c.dom.events.UIEvent;
import org.w3c.dom.views.AbstractView;

public class UIEventImpl extends EventImpl implements UIEvent {
    private int fDetail;
    private AbstractView fView;

    public UIEventImpl() {
    }

    public int getDetail() {
        return this.fDetail;
    }

    public AbstractView getView() {
        return this.fView;
    }

    public void initUIEvent(String str, boolean z, boolean z2, AbstractView abstractView, int i) {
        this.fView = abstractView;
        this.fDetail = i;
        super.initEvent(str, z, z2);
    }
}
