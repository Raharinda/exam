package org.apache.xerces.dom;

import org.w3c.dom.CharacterData;
import org.w3c.dom.Comment;

public class CommentImpl extends CharacterDataImpl implements CharacterData, Comment {
    static final long serialVersionUID = -2685736833408134044L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CommentImpl(CoreDocumentImpl coreDocumentImpl, String str) {
        super(coreDocumentImpl, str);
    }

    public String getNodeName() {
        return "#comment";
    }

    public short getNodeType() {
        return 8;
    }
}
