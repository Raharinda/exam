package org.apache.xerces.dom;

import org.w3c.dom.DOMException;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public abstract class CharacterDataImpl extends ChildNode {
    static final long serialVersionUID = 7931170150428474230L;
    private static final transient NodeList singletonNodeList;
    protected String data;

    static {
        NodeList nodeList;
        new NodeList() {
            public int getLength() {
                return 0;
            }

            public Node item(int i) {
                int i2 = i;
                return null;
            }
        };
        singletonNodeList = nodeList;
    }

    public CharacterDataImpl() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected CharacterDataImpl(CoreDocumentImpl coreDocumentImpl, String str) {
        super(coreDocumentImpl);
        this.data = str;
    }

    public void appendData(String str) {
        StringBuffer stringBuffer;
        Throwable th;
        String str2 = str;
        if (isReadOnly()) {
            Throwable th2 = th;
            new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
            throw th2;
        } else if (str2 != null) {
            if (needsSyncData()) {
                synchronizeData();
            }
            new StringBuffer();
            setNodeValue(stringBuffer.append(this.data).append(str2).toString());
        }
    }

    public void deleteData(int i, int i2) throws DOMException {
        internalDeleteData(i, i2, false);
    }

    public NodeList getChildNodes() {
        return singletonNodeList;
    }

    public String getData() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.data;
    }

    public int getLength() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.data.length();
    }

    public String getNodeValue() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.data;
    }

    public void insertData(int i, String str) throws DOMException {
        internalInsertData(i, str, false);
    }

    /* access modifiers changed from: package-private */
    public void internalDeleteData(int i, int i2, boolean z) throws DOMException {
        Throwable th;
        StringBuffer stringBuffer;
        Throwable th2;
        Throwable th3;
        int i3 = i;
        int i4 = i2;
        boolean z2 = z;
        CoreDocumentImpl ownerDocument = ownerDocument();
        if (ownerDocument.errorChecking) {
            if (isReadOnly()) {
                Throwable th4 = th3;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th4;
            } else if (i4 < 0) {
                Throwable th5 = th2;
                new DOMException(1, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INDEX_SIZE_ERR", (Object[]) null));
                throw th5;
            }
        }
        if (needsSyncData()) {
            synchronizeData();
        }
        int max = Math.max((this.data.length() - i4) - i3, 0);
        try {
            new StringBuffer();
            setNodeValueInternal(stringBuffer.append(this.data.substring(0, i3)).append(max > 0 ? this.data.substring(i3 + i4, i3 + i4 + max) : "").toString(), z2);
            ownerDocument.deletedText(this, i3, i4);
        } catch (StringIndexOutOfBoundsException e) {
            StringIndexOutOfBoundsException stringIndexOutOfBoundsException = e;
            Throwable th6 = th;
            new DOMException(1, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INDEX_SIZE_ERR", (Object[]) null));
            throw th6;
        }
    }

    /* access modifiers changed from: package-private */
    public void internalInsertData(int i, String str, boolean z) throws DOMException {
        Throwable th;
        StringBuffer stringBuffer;
        Throwable th2;
        int i2 = i;
        String str2 = str;
        boolean z2 = z;
        CoreDocumentImpl ownerDocument = ownerDocument();
        if (!ownerDocument.errorChecking || !isReadOnly()) {
            if (needsSyncData()) {
                synchronizeData();
            }
            try {
                new StringBuffer(this.data);
                setNodeValueInternal(stringBuffer.insert(i2, str2).toString(), z2);
                ownerDocument.insertedText(this, i2, str2.length());
            } catch (StringIndexOutOfBoundsException e) {
                StringIndexOutOfBoundsException stringIndexOutOfBoundsException = e;
                Throwable th3 = th;
                new DOMException(1, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INDEX_SIZE_ERR", (Object[]) null));
                throw th3;
            }
        } else {
            Throwable th4 = th2;
            new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
            throw th4;
        }
    }

    public void replaceData(int i, int i2, String str) throws DOMException {
        Throwable th;
        int i3 = i;
        int i4 = i2;
        String str2 = str;
        CoreDocumentImpl ownerDocument = ownerDocument();
        if (!ownerDocument.errorChecking || !isReadOnly()) {
            if (needsSyncData()) {
                synchronizeData();
            }
            ownerDocument.replacingData(this);
            String str3 = this.data;
            internalDeleteData(i3, i4, true);
            internalInsertData(i3, str2, true);
            ownerDocument.replacedCharacterData(this, str3, this.data);
            return;
        }
        Throwable th2 = th;
        new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
        throw th2;
    }

    public void setData(String str) throws DOMException {
        setNodeValue(str);
    }

    public void setNodeValue(String str) {
        setNodeValueInternal(str);
        ownerDocument().replacedText(this);
    }

    /* access modifiers changed from: protected */
    public void setNodeValueInternal(String str) {
        setNodeValueInternal(str, false);
    }

    /* access modifiers changed from: protected */
    public void setNodeValueInternal(String str, boolean z) {
        Throwable th;
        String str2 = str;
        boolean z2 = z;
        CoreDocumentImpl ownerDocument = ownerDocument();
        if (!ownerDocument.errorChecking || !isReadOnly()) {
            if (needsSyncData()) {
                synchronizeData();
            }
            String str3 = this.data;
            ownerDocument.modifyingCharacterData(this, z2);
            this.data = str2;
            ownerDocument.modifiedCharacterData(this, str3, str2, z2);
            return;
        }
        Throwable th2 = th;
        new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
        throw th2;
    }

    public String substringData(int i, int i2) throws DOMException {
        Throwable th;
        int i3 = i;
        int i4 = i2;
        if (needsSyncData()) {
            synchronizeData();
        }
        int length = this.data.length();
        if (i4 < 0 || i3 < 0 || i3 > length - 1) {
            Throwable th2 = th;
            new DOMException(1, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INDEX_SIZE_ERR", (Object[]) null));
            throw th2;
        }
        return this.data.substring(i3, Math.min(i3 + i4, length));
    }
}
