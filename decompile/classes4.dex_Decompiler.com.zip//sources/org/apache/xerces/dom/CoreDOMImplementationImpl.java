package org.apache.xerces.dom;

import com.kodular.fabextension.BuildConfig;
import java.lang.ref.SoftReference;
import org.apache.xerces.impl.RevalidationHandler;
import org.apache.xerces.impl.dtd.XMLDTDLoader;
import org.apache.xerces.parsers.DOMParserImpl;
import org.apache.xerces.util.XMLChar;
import org.apache.xerces.xni.grammars.XMLGrammarDescription;
import org.apache.xml.serialize.DOMSerializerImpl;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Node;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSOutput;
import org.w3c.dom.ls.LSParser;
import org.w3c.dom.ls.LSSerializer;

public class CoreDOMImplementationImpl implements DOMImplementation, DOMImplementationLS {
    private static final int SIZE = 2;
    static final CoreDOMImplementationImpl singleton;
    private int docAndDoctypeCounter = 0;
    private int freeSchemaValidatorIndex = -1;
    private int freeXML10DTDLoaderIndex = -1;
    private int freeXML10DTDValidatorIndex = -1;
    private int freeXML11DTDLoaderIndex = -1;
    private int freeXML11DTDValidatorIndex = -1;
    private SoftReference[] schemaValidators = new SoftReference[2];
    private int schemaValidatorsCurrentSize = 2;
    private int xml10DTDLoaderCurrentSize = 2;
    private SoftReference[] xml10DTDLoaders = new SoftReference[2];
    private SoftReference[] xml10DTDValidators = new SoftReference[2];
    private int xml10DTDValidatorsCurrentSize = 2;
    private int xml11DTDLoaderCurrentSize = 2;
    private SoftReference[] xml11DTDLoaders = new SoftReference[2];
    private SoftReference[] xml11DTDValidators = new SoftReference[2];
    private int xml11DTDValidatorsCurrentSize = 2;

    static final class RevalidationHandlerHolder {
        RevalidationHandler handler;

        RevalidationHandlerHolder(RevalidationHandler revalidationHandler) {
            this.handler = revalidationHandler;
        }
    }

    static final class XMLDTDLoaderHolder {
        XMLDTDLoader loader;

        XMLDTDLoaderHolder(XMLDTDLoader xMLDTDLoader) {
            this.loader = xMLDTDLoader;
        }
    }

    static {
        CoreDOMImplementationImpl coreDOMImplementationImpl;
        new CoreDOMImplementationImpl();
        singleton = coreDOMImplementationImpl;
    }

    public CoreDOMImplementationImpl() {
    }

    public static DOMImplementation getDOMImplementation() {
        return singleton;
    }

    /* access modifiers changed from: protected */
    public synchronized int assignDocTypeNumber() {
        int i;
        synchronized (this) {
            int i2 = this.docAndDoctypeCounter + 1;
            int i3 = i2;
            this.docAndDoctypeCounter = i2;
            i = i3;
        }
        return i;
    }

    /* access modifiers changed from: protected */
    public synchronized int assignDocumentNumber() {
        int i;
        synchronized (this) {
            int i2 = this.docAndDoctypeCounter + 1;
            int i3 = i2;
            this.docAndDoctypeCounter = i2;
            i = i3;
        }
        return i;
    }

    /* access modifiers changed from: package-private */
    public final void checkQName(String str) {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        String str2 = str;
        int indexOf = str2.indexOf(58);
        int lastIndexOf = str2.lastIndexOf(58);
        int length = str2.length();
        if (indexOf == 0 || indexOf == length - 1 || lastIndexOf != indexOf) {
            Throwable th6 = th;
            new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
            throw th6;
        }
        int i = 0;
        if (indexOf > 0) {
            if (!XMLChar.isNCNameStart(str2.charAt(0))) {
                Throwable th7 = th5;
                new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
                throw th7;
            }
            for (int i2 = 1; i2 < indexOf; i2++) {
                if (!XMLChar.isNCName(str2.charAt(i2))) {
                    Throwable th8 = th4;
                    new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
                    throw th8;
                }
            }
            i = indexOf + 1;
        }
        if (!XMLChar.isNCNameStart(str2.charAt(i))) {
            Throwable th9 = th3;
            new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
            throw th9;
        }
        for (int i3 = i + 1; i3 < length; i3++) {
            if (!XMLChar.isNCName(str2.charAt(i3))) {
                Throwable th10 = th2;
                new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
                throw th10;
            }
        }
    }

    /* access modifiers changed from: protected */
    public CoreDocumentImpl createDocument(DocumentType documentType) {
        CoreDocumentImpl coreDocumentImpl;
        new CoreDocumentImpl(documentType);
        return coreDocumentImpl;
    }

    public Document createDocument(String str, String str2, DocumentType documentType) throws DOMException {
        Throwable th;
        String str3 = str;
        String str4 = str2;
        DocumentType documentType2 = documentType;
        if (documentType2 == null || documentType2.getOwnerDocument() == null) {
            CoreDocumentImpl createDocument = createDocument(documentType2);
            if (!(str4 == null && str3 == null)) {
                Node appendChild = createDocument.appendChild(createDocument.createElementNS(str3, str4));
            }
            return createDocument;
        }
        Throwable th2 = th;
        new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
        throw th2;
    }

    public DocumentType createDocumentType(String str, String str2, String str3) {
        DocumentType documentType;
        String str4 = str;
        checkQName(str4);
        new DocumentTypeImpl((CoreDocumentImpl) null, str4, str2, str3);
        return documentType;
    }

    public LSInput createLSInput() {
        LSInput lSInput;
        new DOMInputImpl();
        return lSInput;
    }

    public LSOutput createLSOutput() {
        LSOutput lSOutput;
        new DOMOutputImpl();
        return lSOutput;
    }

    public LSParser createLSParser(short s, String str) throws DOMException {
        Throwable th;
        LSParser lSParser;
        LSParser lSParser2;
        String str2 = str;
        if (s != 1 || (str2 != null && !"http://www.w3.org/2001/XMLSchema".equals(str2) && !XMLGrammarDescription.XML_DTD.equals(str2))) {
            Throwable th2 = th;
            new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
            throw th2;
        } else if (str2 == null || !str2.equals(XMLGrammarDescription.XML_DTD)) {
            new DOMParserImpl("org.apache.xerces.parsers.XIncludeAwareParserConfiguration", str2);
            return lSParser;
        } else {
            new DOMParserImpl("org.apache.xerces.parsers.XML11DTDConfiguration", str2);
            return lSParser2;
        }
    }

    public LSSerializer createLSSerializer() {
        LSSerializer lSSerializer;
        try {
            return (LSSerializer) ObjectFactory.findProviderClass("org.apache.xml.serializer.dom3.LSSerializerImpl", ObjectFactory.findClassLoader(), true).newInstance();
        } catch (Exception e) {
            Exception exc = e;
            new DOMSerializerImpl();
            return lSSerializer;
        }
    }

    /* access modifiers changed from: package-private */
    public final synchronized XMLDTDLoader getDTDLoader(String str) {
        XMLDTDLoader xMLDTDLoader;
        XMLDTDLoader xMLDTDLoader2;
        String str2 = str;
        synchronized (this) {
            if (!"1.1".equals(str2)) {
                while (true) {
                    if (this.freeXML10DTDLoaderIndex >= 0) {
                        XMLDTDLoaderHolder xMLDTDLoaderHolder = (XMLDTDLoaderHolder) this.xml10DTDLoaders[this.freeXML10DTDLoaderIndex].get();
                        if (xMLDTDLoaderHolder != null && xMLDTDLoaderHolder.loader != null) {
                            XMLDTDLoader xMLDTDLoader3 = xMLDTDLoaderHolder.loader;
                            xMLDTDLoaderHolder.loader = null;
                            this.freeXML10DTDLoaderIndex--;
                            xMLDTDLoader2 = xMLDTDLoader3;
                            break;
                        }
                        SoftReference[] softReferenceArr = this.xml10DTDLoaders;
                        int i = this.freeXML10DTDLoaderIndex;
                        int i2 = i - 1;
                        this.freeXML10DTDLoaderIndex = i2;
                        softReferenceArr[i] = null;
                    } else {
                        XMLDTDLoader xMLDTDLoader4 = xMLDTDLoader;
                        new XMLDTDLoader();
                        xMLDTDLoader2 = xMLDTDLoader4;
                        break;
                    }
                }
            } else {
                while (true) {
                    if (this.freeXML11DTDLoaderIndex >= 0) {
                        XMLDTDLoaderHolder xMLDTDLoaderHolder2 = (XMLDTDLoaderHolder) this.xml11DTDLoaders[this.freeXML11DTDLoaderIndex].get();
                        if (xMLDTDLoaderHolder2 != null && xMLDTDLoaderHolder2.loader != null) {
                            XMLDTDLoader xMLDTDLoader5 = xMLDTDLoaderHolder2.loader;
                            xMLDTDLoaderHolder2.loader = null;
                            this.freeXML11DTDLoaderIndex--;
                            xMLDTDLoader2 = xMLDTDLoader5;
                            break;
                        }
                        SoftReference[] softReferenceArr2 = this.xml11DTDLoaders;
                        int i3 = this.freeXML11DTDLoaderIndex;
                        int i4 = i3 - 1;
                        this.freeXML11DTDLoaderIndex = i4;
                        softReferenceArr2[i3] = null;
                    } else {
                        xMLDTDLoader2 = (XMLDTDLoader) ObjectFactory.newInstance("org.apache.xerces.impl.dtd.XML11DTDProcessor", ObjectFactory.findClassLoader(), true);
                        break;
                    }
                }
            }
        }
        return xMLDTDLoader2;
    }

    public Object getFeature(String str, String str2) {
        String str3 = str;
        if (singleton.hasFeature(str3, str2)) {
            if (!str3.equalsIgnoreCase("+XPath")) {
                return singleton;
            }
            try {
                Class findProviderClass = ObjectFactory.findProviderClass("org.apache.xpath.domapi.XPathEvaluatorImpl", ObjectFactory.findClassLoader(), true);
                Class[] interfaces = findProviderClass.getInterfaces();
                for (int i = 0; i < interfaces.length; i++) {
                    if (interfaces[i].getName().equals("org.w3c.dom.xpath.XPathEvaluator")) {
                        return findProviderClass.newInstance();
                    }
                }
            } catch (Exception e) {
                Exception exc = e;
                return null;
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public synchronized RevalidationHandler getValidator(String str, String str2) {
        RevalidationHandler revalidationHandler;
        String str3 = str;
        String str4 = str2;
        synchronized (this) {
            if (str3 == "http://www.w3.org/2001/XMLSchema") {
                while (true) {
                    if (this.freeSchemaValidatorIndex >= 0) {
                        RevalidationHandlerHolder revalidationHandlerHolder = (RevalidationHandlerHolder) this.schemaValidators[this.freeSchemaValidatorIndex].get();
                        if (revalidationHandlerHolder != null && revalidationHandlerHolder.handler != null) {
                            RevalidationHandler revalidationHandler2 = revalidationHandlerHolder.handler;
                            revalidationHandlerHolder.handler = null;
                            this.freeSchemaValidatorIndex--;
                            revalidationHandler = revalidationHandler2;
                            break;
                        }
                        SoftReference[] softReferenceArr = this.schemaValidators;
                        int i = this.freeSchemaValidatorIndex;
                        int i2 = i - 1;
                        this.freeSchemaValidatorIndex = i2;
                        softReferenceArr[i] = null;
                    } else {
                        revalidationHandler = (RevalidationHandler) ObjectFactory.newInstance("org.apache.xerces.impl.xs.XMLSchemaValidator", ObjectFactory.findClassLoader(), true);
                        break;
                    }
                }
            } else if (str3 == XMLGrammarDescription.XML_DTD) {
                if (!"1.1".equals(str4)) {
                    while (true) {
                        if (this.freeXML10DTDValidatorIndex >= 0) {
                            RevalidationHandlerHolder revalidationHandlerHolder2 = (RevalidationHandlerHolder) this.xml10DTDValidators[this.freeXML10DTDValidatorIndex].get();
                            if (revalidationHandlerHolder2 != null && revalidationHandlerHolder2.handler != null) {
                                RevalidationHandler revalidationHandler3 = revalidationHandlerHolder2.handler;
                                revalidationHandlerHolder2.handler = null;
                                this.freeXML10DTDValidatorIndex--;
                                revalidationHandler = revalidationHandler3;
                                break;
                            }
                            SoftReference[] softReferenceArr2 = this.xml10DTDValidators;
                            int i3 = this.freeXML10DTDValidatorIndex;
                            int i4 = i3 - 1;
                            this.freeXML10DTDValidatorIndex = i4;
                            softReferenceArr2[i3] = null;
                        } else {
                            revalidationHandler = (RevalidationHandler) ObjectFactory.newInstance("org.apache.xerces.impl.dtd.XMLDTDValidator", ObjectFactory.findClassLoader(), true);
                            break;
                        }
                    }
                } else {
                    while (true) {
                        if (this.freeXML11DTDValidatorIndex >= 0) {
                            RevalidationHandlerHolder revalidationHandlerHolder3 = (RevalidationHandlerHolder) this.xml11DTDValidators[this.freeXML11DTDValidatorIndex].get();
                            if (revalidationHandlerHolder3 != null && revalidationHandlerHolder3.handler != null) {
                                RevalidationHandler revalidationHandler4 = revalidationHandlerHolder3.handler;
                                revalidationHandlerHolder3.handler = null;
                                this.freeXML11DTDValidatorIndex--;
                                revalidationHandler = revalidationHandler4;
                                break;
                            }
                            SoftReference[] softReferenceArr3 = this.xml11DTDValidators;
                            int i5 = this.freeXML11DTDValidatorIndex;
                            int i6 = i5 - 1;
                            this.freeXML11DTDValidatorIndex = i6;
                            softReferenceArr3[i5] = null;
                        } else {
                            revalidationHandler = (RevalidationHandler) ObjectFactory.newInstance("org.apache.xerces.impl.dtd.XML11DTDValidator", ObjectFactory.findClassLoader(), true);
                            break;
                        }
                    }
                }
            } else {
                revalidationHandler = null;
            }
        }
        return revalidationHandler;
    }

    public boolean hasFeature(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        boolean z = str4 == null || str4.length() == 0;
        if (!str3.equalsIgnoreCase("+XPath") || (!z && !str4.equals("3.0"))) {
            if (str3.startsWith("+")) {
                str3 = str3.substring(1);
            }
            return (str3.equalsIgnoreCase("Core") && (z || str4.equals(BuildConfig.VERSION_NAME) || str4.equals("2.0") || str4.equals("3.0"))) || (str3.equalsIgnoreCase("XML") && (z || str4.equals(BuildConfig.VERSION_NAME) || str4.equals("2.0") || str4.equals("3.0"))) || ((str3.equalsIgnoreCase("XMLVersion") && (z || str4.equals(BuildConfig.VERSION_NAME) || str4.equals("1.1"))) || ((str3.equalsIgnoreCase("LS") && (z || str4.equals("3.0"))) || (str3.equalsIgnoreCase("ElementTraversal") && (z || str4.equals(BuildConfig.VERSION_NAME)))));
        }
        try {
            Class[] interfaces = ObjectFactory.findProviderClass("org.apache.xpath.domapi.XPathEvaluatorImpl", ObjectFactory.findClassLoader(), true).getInterfaces();
            for (int i = 0; i < interfaces.length; i++) {
                if (interfaces[i].getName().equals("org.w3c.dom.xpath.XPathEvaluator")) {
                    return true;
                }
            }
            return true;
        } catch (Exception e) {
            Exception exc = e;
            return false;
        }
    }

    /* access modifiers changed from: package-private */
    public final synchronized void releaseDTDLoader(String str, XMLDTDLoader xMLDTDLoader) {
        SoftReference softReference;
        Object obj;
        XMLDTDLoaderHolder xMLDTDLoaderHolder;
        SoftReference softReference2;
        Object obj2;
        XMLDTDLoaderHolder xMLDTDLoaderHolder2;
        String str2 = str;
        XMLDTDLoader xMLDTDLoader2 = xMLDTDLoader;
        synchronized (this) {
            if ("1.1".equals(str2)) {
                this.freeXML11DTDLoaderIndex++;
                if (this.xml11DTDLoaders.length == this.freeXML11DTDLoaderIndex) {
                    this.xml11DTDLoaderCurrentSize += 2;
                    SoftReference[] softReferenceArr = new SoftReference[this.xml11DTDLoaderCurrentSize];
                    System.arraycopy(this.xml11DTDLoaders, 0, softReferenceArr, 0, this.xml11DTDLoaders.length);
                    this.xml11DTDLoaders = softReferenceArr;
                }
                SoftReference softReference3 = this.xml11DTDLoaders[this.freeXML11DTDLoaderIndex];
                if (softReference3 == null || (xMLDTDLoaderHolder2 = (XMLDTDLoaderHolder) softReference3.get()) == null) {
                    new XMLDTDLoaderHolder(xMLDTDLoader2);
                    new SoftReference(obj2);
                    this.xml11DTDLoaders[this.freeXML11DTDLoaderIndex] = softReference2;
                } else {
                    xMLDTDLoaderHolder2.loader = xMLDTDLoader2;
                }
            } else {
                this.freeXML10DTDLoaderIndex++;
                if (this.xml10DTDLoaders.length == this.freeXML10DTDLoaderIndex) {
                    this.xml10DTDLoaderCurrentSize += 2;
                    SoftReference[] softReferenceArr2 = new SoftReference[this.xml10DTDLoaderCurrentSize];
                    System.arraycopy(this.xml10DTDLoaders, 0, softReferenceArr2, 0, this.xml10DTDLoaders.length);
                    this.xml10DTDLoaders = softReferenceArr2;
                }
                SoftReference softReference4 = this.xml10DTDLoaders[this.freeXML10DTDLoaderIndex];
                if (softReference4 == null || (xMLDTDLoaderHolder = (XMLDTDLoaderHolder) softReference4.get()) == null) {
                    new XMLDTDLoaderHolder(xMLDTDLoader2);
                    new SoftReference(obj);
                    this.xml10DTDLoaders[this.freeXML10DTDLoaderIndex] = softReference;
                } else {
                    xMLDTDLoaderHolder.loader = xMLDTDLoader2;
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public synchronized void releaseValidator(String str, String str2, RevalidationHandler revalidationHandler) {
        SoftReference softReference;
        Object obj;
        RevalidationHandlerHolder revalidationHandlerHolder;
        SoftReference softReference2;
        Object obj2;
        RevalidationHandlerHolder revalidationHandlerHolder2;
        SoftReference softReference3;
        Object obj3;
        RevalidationHandlerHolder revalidationHandlerHolder3;
        String str3 = str;
        String str4 = str2;
        RevalidationHandler revalidationHandler2 = revalidationHandler;
        synchronized (this) {
            if (str3 == "http://www.w3.org/2001/XMLSchema") {
                this.freeSchemaValidatorIndex++;
                if (this.schemaValidators.length == this.freeSchemaValidatorIndex) {
                    this.schemaValidatorsCurrentSize += 2;
                    SoftReference[] softReferenceArr = new SoftReference[this.schemaValidatorsCurrentSize];
                    System.arraycopy(this.schemaValidators, 0, softReferenceArr, 0, this.schemaValidators.length);
                    this.schemaValidators = softReferenceArr;
                }
                SoftReference softReference4 = this.schemaValidators[this.freeSchemaValidatorIndex];
                if (softReference4 == null || (revalidationHandlerHolder3 = (RevalidationHandlerHolder) softReference4.get()) == null) {
                    new RevalidationHandlerHolder(revalidationHandler2);
                    new SoftReference(obj3);
                    this.schemaValidators[this.freeSchemaValidatorIndex] = softReference3;
                } else {
                    revalidationHandlerHolder3.handler = revalidationHandler2;
                }
            } else if (str3 == XMLGrammarDescription.XML_DTD) {
                if ("1.1".equals(str4)) {
                    this.freeXML11DTDValidatorIndex++;
                    if (this.xml11DTDValidators.length == this.freeXML11DTDValidatorIndex) {
                        this.xml11DTDValidatorsCurrentSize += 2;
                        SoftReference[] softReferenceArr2 = new SoftReference[this.xml11DTDValidatorsCurrentSize];
                        System.arraycopy(this.xml11DTDValidators, 0, softReferenceArr2, 0, this.xml11DTDValidators.length);
                        this.xml11DTDValidators = softReferenceArr2;
                    }
                    SoftReference softReference5 = this.xml11DTDValidators[this.freeXML11DTDValidatorIndex];
                    if (softReference5 == null || (revalidationHandlerHolder2 = (RevalidationHandlerHolder) softReference5.get()) == null) {
                        new RevalidationHandlerHolder(revalidationHandler2);
                        new SoftReference(obj2);
                        this.xml11DTDValidators[this.freeXML11DTDValidatorIndex] = softReference2;
                    } else {
                        revalidationHandlerHolder2.handler = revalidationHandler2;
                    }
                } else {
                    this.freeXML10DTDValidatorIndex++;
                    if (this.xml10DTDValidators.length == this.freeXML10DTDValidatorIndex) {
                        this.xml10DTDValidatorsCurrentSize += 2;
                        SoftReference[] softReferenceArr3 = new SoftReference[this.xml10DTDValidatorsCurrentSize];
                        System.arraycopy(this.xml10DTDValidators, 0, softReferenceArr3, 0, this.xml10DTDValidators.length);
                        this.xml10DTDValidators = softReferenceArr3;
                    }
                    SoftReference softReference6 = this.xml10DTDValidators[this.freeXML10DTDValidatorIndex];
                    if (softReference6 == null || (revalidationHandlerHolder = (RevalidationHandlerHolder) softReference6.get()) == null) {
                        new RevalidationHandlerHolder(revalidationHandler2);
                        new SoftReference(obj);
                        this.xml10DTDValidators[this.freeXML10DTDValidatorIndex] = softReference;
                    } else {
                        revalidationHandlerHolder.handler = revalidationHandler2;
                    }
                }
            }
        }
    }
}
