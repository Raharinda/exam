package org.apache.xerces.dom;

import java.util.ArrayList;
import java.util.StringTokenizer;
import net.lingala.zip4j.util.InternalZipConstants;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.DOMImplementationList;
import org.w3c.dom.DOMImplementationSource;

public class DOMImplementationSourceImpl implements DOMImplementationSource {
    public DOMImplementationSourceImpl() {
    }

    public DOMImplementation getDOMImplementation(String str) {
        String str2 = str;
        DOMImplementation dOMImplementation = CoreDOMImplementationImpl.getDOMImplementation();
        if (testImpl(dOMImplementation, str2)) {
            return dOMImplementation;
        }
        DOMImplementation dOMImplementation2 = DOMImplementationImpl.getDOMImplementation();
        if (testImpl(dOMImplementation2, str2)) {
            return dOMImplementation2;
        }
        return null;
    }

    public DOMImplementationList getDOMImplementationList(String str) {
        ArrayList arrayList;
        DOMImplementationList dOMImplementationList;
        String str2 = str;
        DOMImplementation dOMImplementation = CoreDOMImplementationImpl.getDOMImplementation();
        new ArrayList();
        ArrayList arrayList2 = arrayList;
        if (testImpl(dOMImplementation, str2)) {
            boolean add = arrayList2.add(dOMImplementation);
        }
        DOMImplementation dOMImplementation2 = DOMImplementationImpl.getDOMImplementation();
        if (testImpl(dOMImplementation2, str2)) {
            boolean add2 = arrayList2.add(dOMImplementation2);
        }
        new DOMImplementationListImpl(arrayList2);
        return dOMImplementationList;
    }

    /* access modifiers changed from: package-private */
    public boolean testImpl(DOMImplementation dOMImplementation, String str) {
        StringTokenizer stringTokenizer;
        String str2;
        String str3;
        DOMImplementation dOMImplementation2 = dOMImplementation;
        new StringTokenizer(str);
        StringTokenizer stringTokenizer2 = stringTokenizer;
        String str4 = null;
        if (stringTokenizer2.hasMoreTokens()) {
            str4 = stringTokenizer2.nextToken();
        }
        while (str2 != null) {
            boolean z = false;
            if (stringTokenizer2.hasMoreTokens()) {
                str3 = stringTokenizer2.nextToken();
                switch (str3.charAt(0)) {
                    case '0':
                    case '1':
                    case InternalZipConstants.FOLDER_MODE_HIDDEN_ARCHIVE:
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9':
                        z = true;
                        break;
                }
            } else {
                str3 = null;
            }
            if (z) {
                if (!dOMImplementation2.hasFeature(str2, str3)) {
                    return false;
                }
                str2 = stringTokenizer2.hasMoreTokens() ? stringTokenizer2.nextToken() : null;
            } else if (!dOMImplementation2.hasFeature(str2, (String) null)) {
                return false;
            } else {
                str2 = str3;
            }
        }
        return true;
    }
}
