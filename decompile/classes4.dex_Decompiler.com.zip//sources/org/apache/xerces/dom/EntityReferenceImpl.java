package org.apache.xerces.dom;

import org.apache.xerces.util.URI;
import org.w3c.dom.DocumentType;
import org.w3c.dom.EntityReference;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class EntityReferenceImpl extends ParentNode implements EntityReference {
    static final long serialVersionUID = -7381452955687102062L;
    protected String baseURI;
    protected String name;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public EntityReferenceImpl(CoreDocumentImpl coreDocumentImpl, String str) {
        super(coreDocumentImpl);
        this.name = str;
        isReadOnly(true);
        needsSyncChildren(true);
    }

    public Node cloneNode(boolean z) {
        boolean z2 = z;
        EntityReferenceImpl entityReferenceImpl = (EntityReferenceImpl) super.cloneNode(z2);
        entityReferenceImpl.setReadOnly(true, z2);
        return entityReferenceImpl;
    }

    public String getBaseURI() {
        URI uri;
        EntityImpl entityImpl;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.baseURI == null) {
            DocumentType doctype = getOwnerDocument().getDoctype();
            DocumentType documentType = doctype;
            if (null != doctype) {
                NamedNodeMap entities = documentType.getEntities();
                NamedNodeMap namedNodeMap = entities;
                if (!(null == entities || (entityImpl = (EntityImpl) namedNodeMap.getNamedItem(getNodeName())) == null)) {
                    return entityImpl.getBaseURI();
                }
            }
        } else if (!(this.baseURI == null || this.baseURI.length() == 0)) {
            try {
                new URI(this.baseURI);
                return uri.toString();
            } catch (URI.MalformedURIException e) {
                URI.MalformedURIException malformedURIException = e;
                return null;
            }
        }
        return this.baseURI;
    }

    /* access modifiers changed from: protected */
    public String getEntityRefValue() {
        String nodeValue;
        StringBuffer stringBuffer;
        String nodeValue2;
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        Object obj = "";
        if (this.firstChild == null) {
            return "";
        }
        if (this.firstChild.getNodeType() == 5) {
            nodeValue = ((EntityReferenceImpl) this.firstChild).getEntityRefValue();
        } else if (this.firstChild.getNodeType() != 3) {
            return null;
        } else {
            nodeValue = this.firstChild.getNodeValue();
        }
        if (this.firstChild.nextSibling == null) {
            return nodeValue;
        }
        new StringBuffer(nodeValue);
        StringBuffer stringBuffer2 = stringBuffer;
        ChildNode childNode = this.firstChild.nextSibling;
        while (true) {
            ChildNode childNode2 = childNode;
            if (childNode2 == null) {
                return stringBuffer2.toString();
            }
            if (childNode2.getNodeType() == 5) {
                nodeValue2 = ((EntityReferenceImpl) childNode2).getEntityRefValue();
            } else if (childNode2.getNodeType() != 3) {
                return null;
            } else {
                nodeValue2 = childNode2.getNodeValue();
            }
            StringBuffer append = stringBuffer2.append(nodeValue2);
            childNode = childNode2.nextSibling;
        }
    }

    public String getNodeName() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.name;
    }

    public short getNodeType() {
        return 5;
    }

    public void setBaseURI(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        this.baseURI = str2;
    }

    public void setReadOnly(boolean z, boolean z2) {
        boolean z3 = z;
        boolean z4 = z2;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (z4) {
            if (needsSyncChildren()) {
                synchronizeChildren();
            }
            ChildNode childNode = this.firstChild;
            while (true) {
                ChildNode childNode2 = childNode;
                if (childNode2 == null) {
                    break;
                }
                childNode2.setReadOnly(z3, true);
                childNode = childNode2.nextSibling;
            }
        }
        isReadOnly(z3);
    }

    /* access modifiers changed from: protected */
    public void synchronizeChildren() {
        EntityImpl entityImpl;
        needsSyncChildren(false);
        DocumentType doctype = getOwnerDocument().getDoctype();
        DocumentType documentType = doctype;
        if (null != doctype) {
            NamedNodeMap entities = documentType.getEntities();
            NamedNodeMap namedNodeMap = entities;
            if (null != entities && (entityImpl = (EntityImpl) namedNodeMap.getNamedItem(getNodeName())) != null) {
                isReadOnly(false);
                Node firstChild = entityImpl.getFirstChild();
                while (true) {
                    Node node = firstChild;
                    if (node == null) {
                        setReadOnly(true, true);
                        return;
                    }
                    Node insertBefore = insertBefore(node.cloneNode(true), (Node) null);
                    firstChild = node.getNextSibling();
                }
            }
        }
    }
}
