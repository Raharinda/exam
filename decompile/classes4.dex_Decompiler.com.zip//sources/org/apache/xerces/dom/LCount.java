package org.apache.xerces.dom;

import java.util.Hashtable;

class LCount {
    static Hashtable lCounts;
    public int bubbles = 0;
    public int captures = 0;
    public int defaults;
    public int total = 0;

    static {
        Hashtable hashtable;
        new Hashtable();
        lCounts = hashtable;
    }

    LCount() {
    }

    static LCount lookup(String str) {
        LCount lCount;
        String str2 = str;
        LCount lCount2 = (LCount) lCounts.get(str2);
        if (lCount2 == null) {
            new LCount();
            LCount lCount3 = lCount;
            lCount2 = lCount3;
            Object put = lCounts.put(str2, lCount3);
        }
        return lCount2;
    }
}
