package org.apache.xerces.dom;

import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import org.apache.xerces.impl.dv.ValidatedInfo;
import org.apache.xerces.impl.xs.util.StringListImpl;
import org.apache.xerces.xs.ElementPSVI;
import org.apache.xerces.xs.ShortList;
import org.apache.xerces.xs.StringList;
import org.apache.xerces.xs.XSComplexTypeDefinition;
import org.apache.xerces.xs.XSElementDeclaration;
import org.apache.xerces.xs.XSModel;
import org.apache.xerces.xs.XSNotationDeclaration;
import org.apache.xerces.xs.XSSimpleTypeDefinition;
import org.apache.xerces.xs.XSTypeDefinition;
import org.apache.xerces.xs.XSValue;

public class PSVIElementNSImpl extends ElementNSImpl implements ElementPSVI {
    static final long serialVersionUID = 6815489624636016068L;
    protected XSElementDeclaration fDeclaration = null;
    protected StringList fErrorCodes;
    protected StringList fErrorMessages;
    protected boolean fNil = false;
    protected XSNotationDeclaration fNotation;
    protected XSModel fSchemaInformation;
    protected boolean fSpecified = true;
    protected XSTypeDefinition fTypeDecl = null;
    protected short fValidationAttempted;
    protected String fValidationContext;
    protected short fValidity;
    protected ValidatedInfo fValue;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public PSVIElementNSImpl(CoreDocumentImpl coreDocumentImpl, String str, String str2) {
        super(coreDocumentImpl, str, str2);
        ValidatedInfo validatedInfo;
        new ValidatedInfo();
        this.fValue = validatedInfo;
        this.fNotation = null;
        this.fValidationAttempted = 0;
        this.fValidity = 0;
        this.fErrorCodes = null;
        this.fErrorMessages = null;
        this.fValidationContext = null;
        this.fSchemaInformation = null;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public PSVIElementNSImpl(CoreDocumentImpl coreDocumentImpl, String str, String str2, String str3) {
        super(coreDocumentImpl, str, str2, str3);
        ValidatedInfo validatedInfo;
        new ValidatedInfo();
        this.fValue = validatedInfo;
        this.fNotation = null;
        this.fValidationAttempted = 0;
        this.fValidity = 0;
        this.fErrorCodes = null;
        this.fErrorMessages = null;
        this.fValidationContext = null;
        this.fSchemaInformation = null;
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        Throwable th;
        ObjectInputStream objectInputStream2 = objectInputStream;
        Throwable th2 = th;
        new NotSerializableException(getClass().getName());
        throw th2;
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        Throwable th;
        ObjectOutputStream objectOutputStream2 = objectOutputStream;
        Throwable th2 = th;
        new NotSerializableException(getClass().getName());
        throw th2;
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public org.apache.xerces.xs.ItemPSVI constant() {
        /*
            r6 = this;
            r0 = r6
            org.apache.xerces.impl.xs.ElementPSVImpl r1 = new org.apache.xerces.impl.xs.ElementPSVImpl
            r5 = r1
            r1 = r5
            r2 = r5
            r3 = 1
            r4 = r0
            r2.<init>(r3, r4)
            r0 = r1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.PSVIElementNSImpl.constant():org.apache.xerces.xs.ItemPSVI");
    }

    public Object getActualNormalizedValue() {
        return this.fValue.getActualValue();
    }

    public short getActualNormalizedValueType() {
        return this.fValue.getActualValueType();
    }

    public XSElementDeclaration getElementDeclaration() {
        return this.fDeclaration;
    }

    public StringList getErrorCodes() {
        return this.fErrorCodes != null ? this.fErrorCodes : StringListImpl.EMPTY_LIST;
    }

    public StringList getErrorMessages() {
        return this.fErrorMessages != null ? this.fErrorMessages : StringListImpl.EMPTY_LIST;
    }

    public boolean getIsSchemaSpecified() {
        return this.fSpecified;
    }

    public ShortList getItemValueTypes() {
        return this.fValue.getListValueTypes();
    }

    public XSSimpleTypeDefinition getMemberTypeDefinition() {
        return this.fValue.getMemberTypeDefinition();
    }

    public boolean getNil() {
        return this.fNil;
    }

    public XSNotationDeclaration getNotation() {
        return this.fNotation;
    }

    public String getSchemaDefault() {
        return this.fDeclaration == null ? null : this.fDeclaration.getConstraintValue();
    }

    public XSModel getSchemaInformation() {
        return this.fSchemaInformation;
    }

    public String getSchemaNormalizedValue() {
        return this.fValue.getNormalizedValue();
    }

    public XSValue getSchemaValue() {
        return this.fValue;
    }

    public XSTypeDefinition getTypeDefinition() {
        return this.fTypeDecl;
    }

    public short getValidationAttempted() {
        return this.fValidationAttempted;
    }

    public String getValidationContext() {
        return this.fValidationContext;
    }

    public short getValidity() {
        return this.fValidity;
    }

    public boolean isConstant() {
        return false;
    }

    public void setPSVI(ElementPSVI elementPSVI) {
        ElementPSVI elementPSVI2 = elementPSVI;
        this.fDeclaration = elementPSVI2.getElementDeclaration();
        this.fNotation = elementPSVI2.getNotation();
        this.fValidationContext = elementPSVI2.getValidationContext();
        this.fTypeDecl = elementPSVI2.getTypeDefinition();
        this.fSchemaInformation = elementPSVI2.getSchemaInformation();
        this.fValidity = elementPSVI2.getValidity();
        this.fValidationAttempted = elementPSVI2.getValidationAttempted();
        this.fErrorCodes = elementPSVI2.getErrorCodes();
        this.fErrorMessages = elementPSVI2.getErrorMessages();
        if ((this.fTypeDecl instanceof XSSimpleTypeDefinition) || ((this.fTypeDecl instanceof XSComplexTypeDefinition) && ((XSComplexTypeDefinition) this.fTypeDecl).getContentType() == 1)) {
            this.fValue.copyFrom(elementPSVI2.getSchemaValue());
        } else {
            this.fValue.reset();
        }
        this.fSpecified = elementPSVI2.getIsSchemaSpecified();
        this.fNil = elementPSVI2.getNil();
    }
}
