package org.apache.xerces.dom;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class ElementDefinitionImpl extends ParentNode {
    static final long serialVersionUID = -8373890672670022714L;
    protected NamedNodeMapImpl attributes;
    protected String name;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ElementDefinitionImpl(org.apache.xerces.dom.CoreDocumentImpl r9, java.lang.String r10) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            r2 = r10
            r3 = r0
            r4 = r1
            r3.<init>(r4)
            r3 = r0
            r4 = r2
            r3.name = r4
            r3 = r0
            org.apache.xerces.dom.NamedNodeMapImpl r4 = new org.apache.xerces.dom.NamedNodeMapImpl
            r7 = r4
            r4 = r7
            r5 = r7
            r6 = r1
            r5.<init>(r6)
            r3.attributes = r4
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.ElementDefinitionImpl.<init>(org.apache.xerces.dom.CoreDocumentImpl, java.lang.String):void");
    }

    public Node cloneNode(boolean z) {
        ElementDefinitionImpl elementDefinitionImpl = (ElementDefinitionImpl) super.cloneNode(z);
        elementDefinitionImpl.attributes = this.attributes.cloneMap((NodeImpl) elementDefinitionImpl);
        return elementDefinitionImpl;
    }

    public NamedNodeMap getAttributes() {
        if (needsSyncChildren()) {
            synchronizeChildren();
        }
        return this.attributes;
    }

    public String getNodeName() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.name;
    }

    public short getNodeType() {
        return 21;
    }
}
