package org.apache.xerces.dom;

import java.util.ArrayList;
import java.util.Vector;
import org.w3c.dom.DOMStringList;

public class DOMStringListImpl implements DOMStringList {
    private final ArrayList fStrings;

    public DOMStringListImpl() {
        ArrayList arrayList;
        new ArrayList();
        this.fStrings = arrayList;
    }

    public DOMStringListImpl(ArrayList arrayList) {
        this.fStrings = arrayList;
    }

    public DOMStringListImpl(Vector vector) {
        ArrayList arrayList;
        new ArrayList(vector);
        this.fStrings = arrayList;
    }

    public void add(String str) {
        boolean add = this.fStrings.add(str);
    }

    public boolean contains(String str) {
        return this.fStrings.contains(str);
    }

    public int getLength() {
        return this.fStrings.size();
    }

    public String item(int i) {
        int i2 = i;
        int length = getLength();
        if (i2 < 0 || i2 >= length) {
            return null;
        }
        return (String) this.fStrings.get(i2);
    }
}
