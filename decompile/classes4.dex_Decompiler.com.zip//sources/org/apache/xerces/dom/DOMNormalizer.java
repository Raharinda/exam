package org.apache.xerces.dom;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Vector;
import net.lingala.zip4j.util.Zip4jConstants;
import org.apache.xerces.impl.Constants;
import org.apache.xerces.impl.RevalidationHandler;
import org.apache.xerces.impl.dtd.XMLDTDLoader;
import org.apache.xerces.impl.dv.XSSimpleType;
import org.apache.xerces.impl.xs.util.SimpleLocator;
import org.apache.xerces.jaxp.JAXPConstants;
import org.apache.xerces.util.AugmentationsImpl;
import org.apache.xerces.util.NamespaceSupport;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.util.XML11Char;
import org.apache.xerces.util.XMLChar;
import org.apache.xerces.util.XMLSymbols;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.XMLGrammarDescription;
import org.apache.xerces.xni.parser.XMLDocumentSource;
import org.apache.xerces.xs.AttributePSVI;
import org.apache.xerces.xs.ElementPSVI;
import org.apache.xerces.xs.XSSimpleTypeDefinition;
import org.apache.xerces.xs.XSTypeDefinition;
import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Comment;
import org.w3c.dom.DOMErrorHandler;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.Entity;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;

public class DOMNormalizer implements XMLDocumentHandler {
    protected static final boolean DEBUG = false;
    protected static final boolean DEBUG_EVENTS = false;
    protected static final boolean DEBUG_ND = false;
    public static final XMLString EMPTY_STRING;
    protected static final String PREFIX = "NS";
    public static final RuntimeException abort;
    private boolean fAllWhitespace;
    protected final XMLAttributesProxy fAttrProxy;
    private final QName fAttrQName;
    protected final ArrayList fAttributeList;
    protected DOMConfigurationImpl fConfiguration = null;
    protected Node fCurrentNode;
    protected CoreDocumentImpl fDocument = null;
    private final DOMErrorImpl fError;
    protected DOMErrorHandler fErrorHandler;
    protected final NamespaceContext fLocalNSBinder;
    protected final DOMLocatorImpl fLocator;
    protected final NamespaceContext fNamespaceContext;
    protected boolean fNamespaceValidation;
    final XMLString fNormalizedValue;
    protected boolean fPSVI;
    protected final QName fQName;
    protected SymbolTable fSymbolTable;
    protected RevalidationHandler fValidationHandler;

    protected final class XMLAttributesProxy implements XMLAttributes {
        protected AttributeMap fAttributes;
        protected final Vector fAugmentations;
        protected final Vector fDTDTypes;
        protected CoreDocumentImpl fDocument;
        protected ElementImpl fElement;
        private final DOMNormalizer this$0;

        protected XMLAttributesProxy(DOMNormalizer dOMNormalizer) {
            Vector vector;
            Vector vector2;
            this.this$0 = dOMNormalizer;
            new Vector(5);
            this.fDTDTypes = vector;
            new Vector(5);
            this.fAugmentations = vector2;
        }

        private String getReportableType(String str) {
            String str2 = str;
            return str2.charAt(0) == '(' ? "NMTOKEN" : str2;
        }

        public int addAttribute(QName qName, String str, String str2) {
            Object obj;
            QName qName2 = qName;
            String str3 = str;
            String str4 = str2;
            int xercesAttribute = this.fElement.getXercesAttribute(qName2.uri, qName2.localpart);
            if (xercesAttribute < 0) {
                AttrImpl attrImpl = (AttrImpl) ((CoreDocumentImpl) this.fElement.getOwnerDocument()).createAttributeNS(qName2.uri, qName2.rawname, qName2.localpart);
                attrImpl.setNodeValue(str4);
                xercesAttribute = this.fElement.setXercesAttributeNode(attrImpl);
                this.fDTDTypes.insertElementAt(str3, xercesAttribute);
                new AugmentationsImpl();
                this.fAugmentations.insertElementAt(obj, xercesAttribute);
                attrImpl.setSpecified(false);
            }
            return xercesAttribute;
        }

        public Augmentations getAugmentations(int i) {
            return (Augmentations) this.fAugmentations.elementAt(i);
        }

        public Augmentations getAugmentations(String str) {
            String str2 = str;
            return null;
        }

        public Augmentations getAugmentations(String str, String str2) {
            String str3 = str;
            String str4 = str2;
            return null;
        }

        public int getIndex(String str) {
            String str2 = str;
            return -1;
        }

        public int getIndex(String str, String str2) {
            String str3 = str;
            String str4 = str2;
            return -1;
        }

        public int getLength() {
            return this.fAttributes != null ? this.fAttributes.getLength() : 0;
        }

        public String getLocalName(int i) {
            int i2 = i;
            if (this.fAttributes == null) {
                return null;
            }
            String localName = ((Node) this.fAttributes.getItem(i2)).getLocalName();
            return localName != null ? this.this$0.fSymbolTable.addSymbol(localName) : null;
        }

        public void getName(int i, QName qName) {
            int i2 = i;
            QName qName2 = qName;
            if (this.fAttributes != null) {
                this.this$0.updateQName((Node) this.fAttributes.getItem(i2), qName2);
            }
        }

        public String getNonNormalizedValue(int i) {
            int i2 = i;
            return null;
        }

        public String getPrefix(int i) {
            int i2 = i;
            if (this.fAttributes == null) {
                return null;
            }
            String prefix = ((Node) this.fAttributes.getItem(i2)).getPrefix();
            return (prefix == null || prefix.length() == 0) ? null : this.this$0.fSymbolTable.addSymbol(prefix);
        }

        public String getQName(int i) {
            int i2 = i;
            if (this.fAttributes == null) {
                return null;
            }
            return this.this$0.fSymbolTable.addSymbol(((Node) this.fAttributes.getItem(i2)).getNodeName());
        }

        public String getType(int i) {
            String str = (String) this.fDTDTypes.elementAt(i);
            return str != null ? getReportableType(str) : "CDATA";
        }

        public String getType(String str) {
            String str2 = str;
            return "CDATA";
        }

        public String getType(String str, String str2) {
            String str3 = str;
            String str4 = str2;
            return "CDATA";
        }

        public String getURI(int i) {
            int i2 = i;
            if (this.fAttributes == null) {
                return null;
            }
            String namespaceURI = ((Node) this.fAttributes.getItem(i2)).getNamespaceURI();
            return namespaceURI != null ? this.this$0.fSymbolTable.addSymbol(namespaceURI) : null;
        }

        public String getValue(int i) {
            return this.fAttributes != null ? this.fAttributes.item(i).getNodeValue() : "";
        }

        public String getValue(String str) {
            String str2 = str;
            return null;
        }

        public String getValue(String str, String str2) {
            String str3 = str;
            String str4 = str2;
            if (this.fAttributes == null) {
                return null;
            }
            Node namedItemNS = this.fAttributes.getNamedItemNS(str3, str4);
            return namedItemNS != null ? namedItemNS.getNodeValue() : null;
        }

        public boolean isSpecified(int i) {
            return ((Attr) this.fAttributes.getItem(i)).getSpecified();
        }

        public void removeAllAttributes() {
        }

        public void removeAttributeAt(int i) {
        }

        public void setAttributes(AttributeMap attributeMap, CoreDocumentImpl coreDocumentImpl, ElementImpl elementImpl) {
            Object obj;
            AttributeMap attributeMap2 = attributeMap;
            this.fDocument = coreDocumentImpl;
            this.fAttributes = attributeMap2;
            this.fElement = elementImpl;
            if (attributeMap2 != null) {
                int length = attributeMap2.getLength();
                this.fDTDTypes.setSize(length);
                this.fAugmentations.setSize(length);
                for (int i = 0; i < length; i++) {
                    new AugmentationsImpl();
                    this.fAugmentations.setElementAt(obj, i);
                }
                return;
            }
            this.fDTDTypes.setSize(0);
            this.fAugmentations.setSize(0);
        }

        public void setAugmentations(int i, Augmentations augmentations) {
            this.fAugmentations.setElementAt(augmentations, i);
        }

        public void setName(int i, QName qName) {
        }

        public void setNonNormalizedValue(int i, String str) {
        }

        public void setSpecified(int i, boolean z) {
            ((AttrImpl) this.fAttributes.getItem(i)).setSpecified(z);
        }

        public void setType(int i, String str) {
            this.fDTDTypes.setElementAt(str, i);
        }

        public void setValue(int i, String str) {
            int i2 = i;
            String str2 = str;
            if (this.fAttributes != null) {
                AttrImpl attrImpl = (AttrImpl) this.fAttributes.getItem(i2);
                boolean specified = attrImpl.getSpecified();
                attrImpl.setValue(str2);
                attrImpl.setSpecified(specified);
            }
        }
    }

    static {
        RuntimeException runtimeException;
        XMLString xMLString;
        new RuntimeException() {
            private static final long serialVersionUID = 5361322877988412432L;

            public Throwable fillInStackTrace() {
                return this;
            }
        };
        abort = runtimeException;
        new XMLString();
        EMPTY_STRING = xMLString;
    }

    public DOMNormalizer() {
        XMLAttributesProxy xMLAttributesProxy;
        QName qName;
        DOMErrorImpl dOMErrorImpl;
        NamespaceContext namespaceContext;
        NamespaceContext namespaceContext2;
        ArrayList arrayList;
        DOMLocatorImpl dOMLocatorImpl;
        QName qName2;
        XMLString xMLString;
        new XMLAttributesProxy(this);
        this.fAttrProxy = xMLAttributesProxy;
        new QName();
        this.fQName = qName;
        new DOMErrorImpl();
        this.fError = dOMErrorImpl;
        this.fNamespaceValidation = false;
        this.fPSVI = false;
        new NamespaceSupport();
        this.fNamespaceContext = namespaceContext;
        new NamespaceSupport();
        this.fLocalNSBinder = namespaceContext2;
        new ArrayList(5);
        this.fAttributeList = arrayList;
        new DOMLocatorImpl();
        this.fLocator = dOMLocatorImpl;
        this.fCurrentNode = null;
        new QName();
        this.fAttrQName = qName2;
        new XMLString(new char[16], 0, 0);
        this.fNormalizedValue = xMLString;
        this.fAllWhitespace = false;
    }

    public static final void isAttrValueWF(DOMErrorHandler dOMErrorHandler, DOMErrorImpl dOMErrorImpl, DOMLocatorImpl dOMLocatorImpl, NamedNodeMap namedNodeMap, Attr attr, String str, boolean z) {
        DocumentType doctype;
        DOMErrorHandler dOMErrorHandler2 = dOMErrorHandler;
        DOMErrorImpl dOMErrorImpl2 = dOMErrorImpl;
        DOMLocatorImpl dOMLocatorImpl2 = dOMLocatorImpl;
        NamedNodeMap namedNodeMap2 = namedNodeMap;
        Attr attr2 = attr;
        String str2 = str;
        boolean z2 = z;
        if (!(attr2 instanceof AttrImpl) || !((AttrImpl) attr2).hasStringValue()) {
            NodeList childNodes = attr2.getChildNodes();
            for (int i = 0; i < childNodes.getLength(); i++) {
                Node item = childNodes.item(i);
                if (item.getNodeType() == 5) {
                    Document ownerDocument = attr2.getOwnerDocument();
                    Entity entity = null;
                    if (!(ownerDocument == null || (doctype = ownerDocument.getDoctype()) == null)) {
                        entity = (Entity) doctype.getEntities().getNamedItemNS("*", item.getNodeName());
                    }
                    if (entity == null) {
                        reportDOMError(dOMErrorHandler2, dOMErrorImpl2, dOMLocatorImpl2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "UndeclaredEntRefInAttrValue", new Object[]{attr2.getNodeName()}), 2, "UndeclaredEntRefInAttrValue");
                    }
                } else {
                    isXMLCharWF(dOMErrorHandler2, dOMErrorImpl2, dOMLocatorImpl2, item.getNodeValue(), z2);
                }
            }
            return;
        }
        isXMLCharWF(dOMErrorHandler2, dOMErrorImpl2, dOMLocatorImpl2, str2, z2);
    }

    public static final void isCDataWF(DOMErrorHandler dOMErrorHandler, DOMErrorImpl dOMErrorImpl, DOMLocatorImpl dOMLocatorImpl, String str, boolean z) {
        DOMErrorHandler dOMErrorHandler2 = dOMErrorHandler;
        DOMErrorImpl dOMErrorImpl2 = dOMErrorImpl;
        DOMLocatorImpl dOMLocatorImpl2 = dOMLocatorImpl;
        String str2 = str;
        boolean z2 = z;
        if (str2 != null && str2.length() != 0) {
            char[] charArray = str2.toCharArray();
            int length = charArray.length;
            if (z2) {
                int i = 0;
                while (i < length) {
                    int i2 = i;
                    i++;
                    char c = charArray[i2];
                    if (XML11Char.isXML11Invalid(c)) {
                        if (XMLChar.isHighSurrogate(c) && i < length) {
                            int i3 = i;
                            i++;
                            char c2 = charArray[i3];
                            if (XMLChar.isLowSurrogate(c2) && XMLChar.isSupplemental(XMLChar.supplemental(c, c2))) {
                            }
                        }
                        reportDOMError(dOMErrorHandler2, dOMErrorImpl2, dOMLocatorImpl2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInCDSect", new Object[]{Integer.toString(c, 16)}), 2, "wf-invalid-character");
                    } else if (c == ']') {
                        int i4 = i;
                        if (i4 < length && charArray[i4] == ']') {
                            do {
                                i4++;
                                if (i4 >= length || charArray[i4] != ']') {
                                }
                                i4++;
                                break;
                            } while (charArray[i4] != ']');
                            if (i4 < length && charArray[i4] == '>') {
                                reportDOMError(dOMErrorHandler2, dOMErrorImpl2, dOMLocatorImpl2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.XML_DOMAIN, "CDEndInContent", (Object[]) null), 2, "wf-invalid-character");
                            }
                        }
                    }
                }
                return;
            }
            int i5 = 0;
            while (i5 < length) {
                int i6 = i5;
                i5++;
                char c3 = charArray[i6];
                if (XMLChar.isInvalid(c3)) {
                    if (XMLChar.isHighSurrogate(c3) && i5 < length) {
                        int i7 = i5;
                        i5++;
                        char c4 = charArray[i7];
                        if (XMLChar.isLowSurrogate(c4) && XMLChar.isSupplemental(XMLChar.supplemental(c3, c4))) {
                        }
                    }
                    reportDOMError(dOMErrorHandler2, dOMErrorImpl2, dOMLocatorImpl2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInCDSect", new Object[]{Integer.toString(c3, 16)}), 2, "wf-invalid-character");
                } else if (c3 == ']') {
                    int i8 = i5;
                    if (i8 < length && charArray[i8] == ']') {
                        do {
                            i8++;
                            if (i8 >= length || charArray[i8] != ']') {
                            }
                            i8++;
                            break;
                        } while (charArray[i8] != ']');
                        if (i8 < length && charArray[i8] == '>') {
                            reportDOMError(dOMErrorHandler2, dOMErrorImpl2, dOMLocatorImpl2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.XML_DOMAIN, "CDEndInContent", (Object[]) null), 2, "wf-invalid-character");
                        }
                    }
                }
            }
        }
    }

    public static final void isCommentWF(DOMErrorHandler dOMErrorHandler, DOMErrorImpl dOMErrorImpl, DOMLocatorImpl dOMLocatorImpl, String str, boolean z) {
        DOMErrorHandler dOMErrorHandler2 = dOMErrorHandler;
        DOMErrorImpl dOMErrorImpl2 = dOMErrorImpl;
        DOMLocatorImpl dOMLocatorImpl2 = dOMLocatorImpl;
        String str2 = str;
        boolean z2 = z;
        if (str2 != null && str2.length() != 0) {
            char[] charArray = str2.toCharArray();
            int length = charArray.length;
            if (z2) {
                int i = 0;
                while (i < length) {
                    int i2 = i;
                    i++;
                    char c = charArray[i2];
                    if (XML11Char.isXML11Invalid(c)) {
                        if (XMLChar.isHighSurrogate(c) && i < length) {
                            int i3 = i;
                            i++;
                            char c2 = charArray[i3];
                            if (XMLChar.isLowSurrogate(c2) && XMLChar.isSupplemental(XMLChar.supplemental(c, c2))) {
                            }
                        }
                        reportDOMError(dOMErrorHandler2, dOMErrorImpl2, dOMLocatorImpl2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInComment", new Object[]{Integer.toString(charArray[i - 1], 16)}), 2, "wf-invalid-character");
                    } else if (c == '-' && i < length && charArray[i] == '-') {
                        reportDOMError(dOMErrorHandler2, dOMErrorImpl2, dOMLocatorImpl2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.XML_DOMAIN, "DashDashInComment", (Object[]) null), 2, "wf-invalid-character");
                    }
                }
                return;
            }
            int i4 = 0;
            while (i4 < length) {
                int i5 = i4;
                i4++;
                char c3 = charArray[i5];
                if (XMLChar.isInvalid(c3)) {
                    if (XMLChar.isHighSurrogate(c3) && i4 < length) {
                        int i6 = i4;
                        i4++;
                        char c4 = charArray[i6];
                        if (XMLChar.isLowSurrogate(c4) && XMLChar.isSupplemental(XMLChar.supplemental(c3, c4))) {
                        }
                    }
                    reportDOMError(dOMErrorHandler2, dOMErrorImpl2, dOMLocatorImpl2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInComment", new Object[]{Integer.toString(charArray[i4 - 1], 16)}), 2, "wf-invalid-character");
                } else if (c3 == '-' && i4 < length && charArray[i4] == '-') {
                    reportDOMError(dOMErrorHandler2, dOMErrorImpl2, dOMLocatorImpl2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.XML_DOMAIN, "DashDashInComment", (Object[]) null), 2, "wf-invalid-character");
                }
            }
        }
    }

    public static final void isXMLCharWF(DOMErrorHandler dOMErrorHandler, DOMErrorImpl dOMErrorImpl, DOMLocatorImpl dOMLocatorImpl, String str, boolean z) {
        DOMErrorHandler dOMErrorHandler2 = dOMErrorHandler;
        DOMErrorImpl dOMErrorImpl2 = dOMErrorImpl;
        DOMLocatorImpl dOMLocatorImpl2 = dOMLocatorImpl;
        String str2 = str;
        boolean z2 = z;
        if (str2 != null && str2.length() != 0) {
            char[] charArray = str2.toCharArray();
            int length = charArray.length;
            if (z2) {
                int i = 0;
                while (i < length) {
                    int i2 = i;
                    i++;
                    if (XML11Char.isXML11Invalid(charArray[i2])) {
                        char c = charArray[i - 1];
                        if (XMLChar.isHighSurrogate(c) && i < length) {
                            int i3 = i;
                            i++;
                            char c2 = charArray[i3];
                            if (XMLChar.isLowSurrogate(c2) && XMLChar.isSupplemental(XMLChar.supplemental(c, c2))) {
                            }
                        }
                        reportDOMError(dOMErrorHandler2, dOMErrorImpl2, dOMLocatorImpl2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "InvalidXMLCharInDOM", new Object[]{Integer.toString(charArray[i - 1], 16)}), 2, "wf-invalid-character");
                    }
                }
                return;
            }
            int i4 = 0;
            while (i4 < length) {
                int i5 = i4;
                i4++;
                if (XMLChar.isInvalid(charArray[i5])) {
                    char c3 = charArray[i4 - 1];
                    if (XMLChar.isHighSurrogate(c3) && i4 < length) {
                        int i6 = i4;
                        i4++;
                        char c4 = charArray[i6];
                        if (XMLChar.isLowSurrogate(c4) && XMLChar.isSupplemental(XMLChar.supplemental(c3, c4))) {
                        }
                    }
                    reportDOMError(dOMErrorHandler2, dOMErrorImpl2, dOMLocatorImpl2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "InvalidXMLCharInDOM", new Object[]{Integer.toString(charArray[i4 - 1], 16)}), 2, "wf-invalid-character");
                }
            }
        }
    }

    private void processDTD(String str, String str2) {
        String nodeName;
        String str3 = str;
        String str4 = null;
        String str5 = str2;
        String documentURI = this.fDocument.getDocumentURI();
        String str6 = null;
        DocumentType doctype = this.fDocument.getDoctype();
        if (doctype != null) {
            nodeName = doctype.getName();
            str4 = doctype.getPublicId();
            if (str5 == null || str5.length() == 0) {
                str5 = doctype.getSystemId();
            }
            str6 = doctype.getInternalSubset();
        } else {
            Element documentElement = this.fDocument.getDocumentElement();
            if (documentElement != null) {
                nodeName = documentElement.getNodeName();
                if (str5 == null || str5.length() == 0) {
                    return;
                }
            } else {
                return;
            }
        }
        XMLDTDLoader xMLDTDLoader = null;
        try {
            this.fValidationHandler.doctypeDecl(nodeName, str4, str5, (Augmentations) null);
            xMLDTDLoader = CoreDOMImplementationImpl.singleton.getDTDLoader(str3);
            xMLDTDLoader.setFeature("http://xml.org/sax/features/validation", true);
            xMLDTDLoader.setEntityResolver(this.fConfiguration.getEntityResolver());
            xMLDTDLoader.setErrorHandler(this.fConfiguration.getErrorHandler());
            xMLDTDLoader.loadGrammarWithContext(this.fValidationHandler, nodeName, str4, str5, documentURI, str6);
            if (xMLDTDLoader != null) {
                CoreDOMImplementationImpl.singleton.releaseDTDLoader(str3, xMLDTDLoader);
            }
        } catch (IOException e) {
            IOException iOException = e;
            if (xMLDTDLoader != null) {
                CoreDOMImplementationImpl.singleton.releaseDTDLoader(str3, xMLDTDLoader);
            }
        } catch (Throwable th) {
            Throwable th2 = th;
            if (xMLDTDLoader != null) {
                CoreDOMImplementationImpl.singleton.releaseDTDLoader(str3, xMLDTDLoader);
            }
            throw th2;
        }
    }

    public static final void reportDOMError(DOMErrorHandler dOMErrorHandler, DOMErrorImpl dOMErrorImpl, DOMLocatorImpl dOMLocatorImpl, String str, short s, String str2) {
        DOMErrorHandler dOMErrorHandler2 = dOMErrorHandler;
        DOMErrorImpl dOMErrorImpl2 = dOMErrorImpl;
        DOMLocatorImpl dOMLocatorImpl2 = dOMLocatorImpl;
        String str3 = str;
        short s2 = s;
        String str4 = str2;
        if (dOMErrorHandler2 != null) {
            dOMErrorImpl2.reset();
            dOMErrorImpl2.fMessage = str3;
            dOMErrorImpl2.fSeverity = s2;
            dOMErrorImpl2.fLocator = dOMLocatorImpl2;
            dOMErrorImpl2.fType = str4;
            dOMErrorImpl2.fRelatedData = dOMLocatorImpl2.fRelatedNode;
            if (!dOMErrorHandler2.handleError(dOMErrorImpl2)) {
                throw abort;
            }
        }
        if (s2 == 3) {
            throw abort;
        }
    }

    /* access modifiers changed from: protected */
    public final void addNamespaceDecl(String str, String str2, ElementImpl elementImpl) {
        StringBuffer stringBuffer;
        String str3 = str;
        String str4 = str2;
        ElementImpl elementImpl2 = elementImpl;
        if (str3 == XMLSymbols.EMPTY_STRING) {
            elementImpl2.setAttributeNS(NamespaceContext.XMLNS_URI, XMLSymbols.PREFIX_XMLNS, str4);
            return;
        }
        String str5 = NamespaceContext.XMLNS_URI;
        new StringBuffer();
        elementImpl2.setAttributeNS(str5, stringBuffer.append("xmlns:").append(str3).toString(), str4);
    }

    public void characters(XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void comment(XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void doctypeDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
    }

    public void emptyElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        startElement(qName2, xMLAttributes, augmentations2);
        endElement(qName2, augmentations2);
    }

    public void endCDATA(Augmentations augmentations) throws XNIException {
    }

    public void endDocument(Augmentations augmentations) throws XNIException {
    }

    public void endElement(QName qName, Augmentations augmentations) throws XNIException {
        ElementPSVI elementPSVI;
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        if (augmentations2 != null && (elementPSVI = (ElementPSVI) augmentations2.getItem("ELEMENT_PSVI")) != null) {
            ElementImpl elementImpl = (ElementImpl) this.fCurrentNode;
            if (this.fPSVI) {
                ((PSVIElementNSImpl) this.fCurrentNode).setPSVI(elementPSVI);
            }
            if (elementImpl instanceof ElementNSImpl) {
                XSTypeDefinition memberTypeDefinition = elementPSVI.getMemberTypeDefinition();
                if (memberTypeDefinition == null) {
                    memberTypeDefinition = elementPSVI.getTypeDefinition();
                }
                ((ElementNSImpl) elementImpl).setType(memberTypeDefinition);
            }
            String schemaNormalizedValue = elementPSVI.getSchemaNormalizedValue();
            if ((this.fConfiguration.features & 2) != 0) {
                if (schemaNormalizedValue != null) {
                    elementImpl.setTextContent(schemaNormalizedValue);
                }
            } else if (elementImpl.getTextContent().length() == 0 && schemaNormalizedValue != null) {
                elementImpl.setTextContent(schemaNormalizedValue);
            }
        } else if (this.fCurrentNode instanceof ElementNSImpl) {
            ((ElementNSImpl) this.fCurrentNode).setType((XSTypeDefinition) null);
        }
    }

    public void endGeneralEntity(String str, Augmentations augmentations) throws XNIException {
    }

    /* access modifiers changed from: protected */
    public final void expandEntityRef(Node node, Node node2) {
        Node node3 = node;
        Node node4 = node2;
        Node firstChild = node4.getFirstChild();
        while (true) {
            Node node5 = firstChild;
            if (node5 != null) {
                Node nextSibling = node5.getNextSibling();
                Node insertBefore = node3.insertBefore(node5, node4);
                firstChild = nextSibling;
            } else {
                return;
            }
        }
    }

    public XMLDocumentSource getDocumentSource() {
        return null;
    }

    public void ignorableWhitespace(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        this.fAllWhitespace = true;
    }

    /* access modifiers changed from: protected */
    public final void namespaceFixUp(ElementImpl elementImpl, AttributeMap attributeMap) {
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        ElementImpl elementImpl2 = elementImpl;
        AttributeMap attributeMap2 = attributeMap;
        if (attributeMap2 != null) {
            for (int i = 0; i < attributeMap2.getLength(); i++) {
                Attr attr = (Attr) attributeMap2.getItem(i);
                String namespaceURI = attr.getNamespaceURI();
                if (namespaceURI != null && namespaceURI.equals(NamespaceContext.XMLNS_URI)) {
                    String nodeValue = attr.getNodeValue();
                    if (nodeValue == null) {
                        nodeValue = XMLSymbols.EMPTY_STRING;
                    }
                    if (!this.fDocument.errorChecking || !nodeValue.equals(NamespaceContext.XMLNS_URI)) {
                        String prefix = attr.getPrefix();
                        String addSymbol = (prefix == null || prefix.length() == 0) ? XMLSymbols.EMPTY_STRING : this.fSymbolTable.addSymbol(prefix);
                        String addSymbol2 = this.fSymbolTable.addSymbol(attr.getLocalName());
                        if (addSymbol == XMLSymbols.PREFIX_XMLNS) {
                            String addSymbol3 = this.fSymbolTable.addSymbol(nodeValue);
                            if (addSymbol3.length() != 0) {
                                boolean declarePrefix = this.fNamespaceContext.declarePrefix(addSymbol2, addSymbol3);
                            }
                        } else {
                            String addSymbol4 = this.fSymbolTable.addSymbol(nodeValue);
                            boolean declarePrefix2 = this.fNamespaceContext.declarePrefix(XMLSymbols.EMPTY_STRING, addSymbol4.length() != 0 ? addSymbol4 : null);
                        }
                    } else {
                        this.fLocator.fRelatedNode = attr;
                        reportDOMError(this.fErrorHandler, this.fError, this.fLocator, DOMMessageFormatter.formatMessage(DOMMessageFormatter.XML_DOMAIN, "CantBindXMLNS", (Object[]) null), 2, "CantBindXMLNS");
                    }
                }
            }
        }
        String namespaceURI2 = elementImpl2.getNamespaceURI();
        String prefix2 = elementImpl2.getPrefix();
        if (namespaceURI2 != null) {
            String addSymbol5 = this.fSymbolTable.addSymbol(namespaceURI2);
            String addSymbol6 = (prefix2 == null || prefix2.length() == 0) ? XMLSymbols.EMPTY_STRING : this.fSymbolTable.addSymbol(prefix2);
            if (this.fNamespaceContext.getURI(addSymbol6) != addSymbol5) {
                addNamespaceDecl(addSymbol6, addSymbol5, elementImpl2);
                boolean declarePrefix3 = this.fLocalNSBinder.declarePrefix(addSymbol6, addSymbol5);
                boolean declarePrefix4 = this.fNamespaceContext.declarePrefix(addSymbol6, addSymbol5);
            }
        } else if (elementImpl2.getLocalName() != null) {
            String uri = this.fNamespaceContext.getURI(XMLSymbols.EMPTY_STRING);
            if (uri != null && uri.length() > 0) {
                addNamespaceDecl(XMLSymbols.EMPTY_STRING, XMLSymbols.EMPTY_STRING, elementImpl2);
                boolean declarePrefix5 = this.fLocalNSBinder.declarePrefix(XMLSymbols.EMPTY_STRING, (String) null);
                boolean declarePrefix6 = this.fNamespaceContext.declarePrefix(XMLSymbols.EMPTY_STRING, (String) null);
            }
        } else if (this.fNamespaceValidation) {
            reportDOMError(this.fErrorHandler, this.fError, this.fLocator, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NullLocalElementName", new Object[]{elementImpl2.getNodeName()}), 3, "NullLocalElementName");
        } else {
            reportDOMError(this.fErrorHandler, this.fError, this.fLocator, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NullLocalElementName", new Object[]{elementImpl2.getNodeName()}), 2, "NullLocalElementName");
        }
        if (attributeMap2 != null) {
            ArrayList cloneMap = attributeMap2.cloneMap(this.fAttributeList);
            for (int i2 = 0; i2 < this.fAttributeList.size(); i2++) {
                Attr attr2 = (Attr) this.fAttributeList.get(i2);
                this.fLocator.fRelatedNode = attr2;
                attr2.normalize();
                String value = attr2.getValue();
                String namespaceURI3 = attr2.getNamespaceURI();
                if (value == null) {
                    value = XMLSymbols.EMPTY_STRING;
                }
                if (this.fDocument.errorChecking && (this.fConfiguration.features & XSSimpleTypeDefinition.FACET_MININCLUSIVE) != 0) {
                    isAttrValueWF(this.fErrorHandler, this.fError, this.fLocator, attributeMap2, attr2, value, this.fDocument.isXML11Version());
                    if (this.fDocument.isXMLVersionChanged()) {
                        if (!(this.fNamespaceValidation ? CoreDocumentImpl.isValidQName(attr2.getPrefix(), attr2.getLocalName(), this.fDocument.isXML11Version()) : CoreDocumentImpl.isXMLName(attr2.getNodeName(), this.fDocument.isXML11Version()))) {
                            Object[] objArr = new Object[2];
                            objArr[0] = "Attr";
                            Object[] objArr2 = objArr;
                            objArr2[1] = attr2.getNodeName();
                            reportDOMError(this.fErrorHandler, this.fError, this.fLocator, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "wf-invalid-character-in-node-name", objArr2), 2, "wf-invalid-character-in-node-name");
                        }
                    }
                }
                if (namespaceURI3 != null) {
                    String prefix3 = attr2.getPrefix();
                    String addSymbol7 = (prefix3 == null || prefix3.length() == 0) ? XMLSymbols.EMPTY_STRING : this.fSymbolTable.addSymbol(prefix3);
                    String addSymbol8 = this.fSymbolTable.addSymbol(attr2.getLocalName());
                    if (namespaceURI3 == null || !namespaceURI3.equals(NamespaceContext.XMLNS_URI)) {
                        ((AttrImpl) attr2).setIdAttribute(false);
                        String addSymbol9 = this.fSymbolTable.addSymbol(namespaceURI3);
                        String uri2 = this.fNamespaceContext.getURI(addSymbol7);
                        if (addSymbol7 == XMLSymbols.EMPTY_STRING || uri2 != addSymbol9) {
                            String prefix4 = this.fNamespaceContext.getPrefix(addSymbol9);
                            if (prefix4 == null || prefix4 == XMLSymbols.EMPTY_STRING) {
                                if (addSymbol7 == XMLSymbols.EMPTY_STRING || this.fLocalNSBinder.getURI(addSymbol7) != null) {
                                    SymbolTable symbolTable = this.fSymbolTable;
                                    new StringBuffer();
                                    int i3 = 1 + 1;
                                    String addSymbol10 = symbolTable.addSymbol(stringBuffer.append(PREFIX).append(1).toString());
                                    while (true) {
                                        addSymbol7 = addSymbol10;
                                        if (this.fLocalNSBinder.getURI(addSymbol7) == null) {
                                            break;
                                        }
                                        SymbolTable symbolTable2 = this.fSymbolTable;
                                        new StringBuffer();
                                        int i4 = i3;
                                        i3++;
                                        addSymbol10 = symbolTable2.addSymbol(stringBuffer2.append(PREFIX).append(i4).toString());
                                    }
                                }
                                addNamespaceDecl(addSymbol7, addSymbol9, elementImpl2);
                                boolean declarePrefix7 = this.fLocalNSBinder.declarePrefix(addSymbol7, this.fSymbolTable.addSymbol(value));
                                boolean declarePrefix8 = this.fNamespaceContext.declarePrefix(addSymbol7, addSymbol9);
                            } else {
                                addSymbol7 = prefix4;
                            }
                            attr2.setPrefix(addSymbol7);
                        }
                    }
                } else {
                    ((AttrImpl) attr2).setIdAttribute(false);
                    if (attr2.getLocalName() == null) {
                        if (this.fNamespaceValidation) {
                            reportDOMError(this.fErrorHandler, this.fError, this.fLocator, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NullLocalAttrName", new Object[]{attr2.getNodeName()}), 3, "NullLocalAttrName");
                        } else {
                            reportDOMError(this.fErrorHandler, this.fError, this.fLocator, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NullLocalAttrName", new Object[]{attr2.getNodeName()}), 2, "NullLocalAttrName");
                        }
                    }
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public final String normalizeAttributeValue(String str, Attr attr) {
        String str2 = str;
        Attr attr2 = attr;
        if (!attr2.getSpecified()) {
            return str2;
        }
        int length = str2.length();
        if (this.fNormalizedValue.ch.length < length) {
            this.fNormalizedValue.ch = new char[length];
        }
        this.fNormalizedValue.length = 0;
        boolean z = false;
        int i = 0;
        while (i < length) {
            char charAt = str2.charAt(i);
            if (charAt == 9 || charAt == 10) {
                char[] cArr = this.fNormalizedValue.ch;
                XMLString xMLString = this.fNormalizedValue;
                int i2 = xMLString.length;
                xMLString.length = i2 + 1;
                cArr[i2] = ' ';
                z = true;
            } else if (charAt == 13) {
                z = true;
                char[] cArr2 = this.fNormalizedValue.ch;
                XMLString xMLString2 = this.fNormalizedValue;
                int i3 = xMLString2.length;
                xMLString2.length = i3 + 1;
                cArr2[i3] = ' ';
                int i4 = i + 1;
                if (i4 < length && str2.charAt(i4) == 10) {
                    i = i4;
                }
            } else {
                char[] cArr3 = this.fNormalizedValue.ch;
                XMLString xMLString3 = this.fNormalizedValue;
                int i5 = xMLString3.length;
                xMLString3.length = i5 + 1;
                cArr3[i5] = charAt;
            }
            i++;
        }
        if (z) {
            str2 = this.fNormalizedValue.toString();
            attr2.setValue(str2);
        }
        return str2;
    }

    /* access modifiers changed from: protected */
    public void normalizeDocument(CoreDocumentImpl coreDocumentImpl, DOMConfigurationImpl dOMConfigurationImpl) {
        String str;
        XMLLocator xMLLocator;
        this.fDocument = coreDocumentImpl;
        this.fConfiguration = dOMConfigurationImpl;
        this.fAllWhitespace = false;
        this.fNamespaceValidation = false;
        String xmlVersion = this.fDocument.getXmlVersion();
        String str2 = null;
        String[] strArr = null;
        this.fSymbolTable = (SymbolTable) this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/symbol-table");
        this.fNamespaceContext.reset();
        boolean declarePrefix = this.fNamespaceContext.declarePrefix(XMLSymbols.EMPTY_STRING, (String) null);
        if ((this.fConfiguration.features & 64) != 0) {
            String str3 = (String) this.fConfiguration.getProperty(JAXPConstants.JAXP_SCHEMA_LANGUAGE);
            if (str3 == null || !str3.equals(Constants.NS_XMLSCHEMA)) {
                str2 = XMLGrammarDescription.XML_DTD;
                if (str3 != null) {
                    strArr = (String[]) this.fConfiguration.getProperty(JAXPConstants.JAXP_SCHEMA_SOURCE);
                }
                this.fConfiguration.setDTDValidatorFactory(xmlVersion);
                this.fValidationHandler = CoreDOMImplementationImpl.singleton.getValidator(str2, xmlVersion);
                this.fPSVI = false;
            } else {
                str2 = "http://www.w3.org/2001/XMLSchema";
                this.fValidationHandler = CoreDOMImplementationImpl.singleton.getValidator(str2, xmlVersion);
                this.fConfiguration.setFeature("http://apache.org/xml/features/validation/schema", true);
                this.fConfiguration.setFeature("http://apache.org/xml/features/validation/schema-full-checking", true);
                this.fNamespaceValidation = true;
                this.fPSVI = (this.fConfiguration.features & XSSimpleTypeDefinition.FACET_MINEXCLUSIVE) != 0;
            }
            this.fConfiguration.setFeature("http://xml.org/sax/features/validation", true);
            this.fDocument.clearIdentifiers();
            if (this.fValidationHandler != null) {
                this.fValidationHandler.reset(this.fConfiguration);
            }
        } else {
            this.fValidationHandler = null;
        }
        this.fErrorHandler = (DOMErrorHandler) this.fConfiguration.getParameter("error-handler");
        if (this.fValidationHandler != null) {
            this.fValidationHandler.setDocumentHandler(this);
            new SimpleLocator(this.fDocument.fDocumentURI, this.fDocument.fDocumentURI, -1, -1);
            this.fValidationHandler.startDocument(xMLLocator, this.fDocument.encoding, this.fNamespaceContext, (Augmentations) null);
            this.fValidationHandler.xmlDecl(this.fDocument.getXmlVersion(), this.fDocument.getXmlEncoding(), this.fDocument.getXmlStandalone() ? "yes" : "no", (Augmentations) null);
        }
        if (str2 == XMLGrammarDescription.XML_DTD) {
            String str4 = xmlVersion;
            if (strArr != null) {
                try {
                    str = strArr[0];
                } catch (RuntimeException e) {
                    RuntimeException runtimeException = e;
                    if (this.fValidationHandler != null) {
                        this.fValidationHandler.setDocumentHandler((XMLDocumentHandler) null);
                        CoreDOMImplementationImpl.singleton.releaseValidator(str2, xmlVersion, this.fValidationHandler);
                        this.fValidationHandler = null;
                    }
                    if (runtimeException != abort) {
                        throw runtimeException;
                    }
                    return;
                }
            } else {
                str = null;
            }
            processDTD(str4, str);
        }
        Node firstChild = this.fDocument.getFirstChild();
        while (true) {
            Node node = firstChild;
            if (node == null) {
                break;
            }
            Node nextSibling = node.getNextSibling();
            Node normalizeNode = normalizeNode(node);
            if (normalizeNode != null) {
                nextSibling = normalizeNode;
            }
            firstChild = nextSibling;
        }
        if (this.fValidationHandler != null) {
            this.fValidationHandler.endDocument((Augmentations) null);
            this.fValidationHandler.setDocumentHandler((XMLDocumentHandler) null);
            CoreDOMImplementationImpl.singleton.releaseValidator(str2, xmlVersion, this.fValidationHandler);
            this.fValidationHandler = null;
        }
    }

    /* access modifiers changed from: protected */
    public Node normalizeNode(Node node) {
        Node nextSibling;
        CDATASection cDATASection = node;
        short nodeType = cDATASection.getNodeType();
        this.fLocator.fRelatedNode = cDATASection;
        switch (nodeType) {
            case 1:
                if (this.fDocument.errorChecking && (this.fConfiguration.features & XSSimpleTypeDefinition.FACET_MININCLUSIVE) != 0 && this.fDocument.isXMLVersionChanged()) {
                    if (!(this.fNamespaceValidation ? CoreDocumentImpl.isValidQName(cDATASection.getPrefix(), cDATASection.getLocalName(), this.fDocument.isXML11Version()) : CoreDocumentImpl.isXMLName(cDATASection.getNodeName(), this.fDocument.isXML11Version()))) {
                        Object[] objArr = new Object[2];
                        objArr[0] = "Element";
                        Object[] objArr2 = objArr;
                        objArr2[1] = cDATASection.getNodeName();
                        reportDOMError(this.fErrorHandler, this.fError, this.fLocator, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "wf-invalid-character-in-node-name", objArr2), 2, "wf-invalid-character-in-node-name");
                    }
                }
                this.fNamespaceContext.pushContext();
                this.fLocalNSBinder.reset();
                ElementImpl elementImpl = (ElementImpl) cDATASection;
                if (elementImpl.needsSyncChildren()) {
                    elementImpl.synchronizeChildren();
                }
                AttributeMap attributeMap = elementImpl.hasAttributes() ? (AttributeMap) elementImpl.getAttributes() : null;
                if ((this.fConfiguration.features & 1) != 0) {
                    namespaceFixUp(elementImpl, attributeMap);
                    if ((this.fConfiguration.features & XSSimpleTypeDefinition.FACET_TOTALDIGITS) == 0) {
                        if (attributeMap == null) {
                            attributeMap = elementImpl.hasAttributes() ? (AttributeMap) elementImpl.getAttributes() : null;
                        }
                        if (attributeMap != null) {
                            int i = 0;
                            while (i < attributeMap.getLength()) {
                                Attr attr = (Attr) attributeMap.getItem(i);
                                if (XMLSymbols.PREFIX_XMLNS.equals(attr.getPrefix()) || XMLSymbols.PREFIX_XMLNS.equals(attr.getName())) {
                                    Attr removeAttributeNode = elementImpl.removeAttributeNode(attr);
                                    i--;
                                }
                                i++;
                            }
                        }
                    }
                } else if (attributeMap != null) {
                    for (int i2 = 0; i2 < attributeMap.getLength(); i2++) {
                        Attr attr2 = (Attr) attributeMap.item(i2);
                        attr2.normalize();
                        if (this.fDocument.errorChecking && (this.fConfiguration.features & XSSimpleTypeDefinition.FACET_MININCLUSIVE) != 0) {
                            isAttrValueWF(this.fErrorHandler, this.fError, this.fLocator, attributeMap, attr2, attr2.getValue(), this.fDocument.isXML11Version());
                            if (this.fDocument.isXMLVersionChanged()) {
                                if (!(this.fNamespaceValidation ? CoreDocumentImpl.isValidQName(cDATASection.getPrefix(), cDATASection.getLocalName(), this.fDocument.isXML11Version()) : CoreDocumentImpl.isXMLName(cDATASection.getNodeName(), this.fDocument.isXML11Version()))) {
                                    Object[] objArr3 = new Object[2];
                                    objArr3[0] = "Attr";
                                    Object[] objArr4 = objArr3;
                                    objArr4[1] = cDATASection.getNodeName();
                                    reportDOMError(this.fErrorHandler, this.fError, this.fLocator, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "wf-invalid-character-in-node-name", objArr4), 2, "wf-invalid-character-in-node-name");
                                }
                            }
                        }
                    }
                }
                if (this.fValidationHandler != null) {
                    this.fAttrProxy.setAttributes(attributeMap, this.fDocument, elementImpl);
                    updateQName(elementImpl, this.fQName);
                    this.fConfiguration.fErrorHandlerWrapper.fCurrentNode = cDATASection;
                    this.fCurrentNode = cDATASection;
                    this.fValidationHandler.startElement(this.fQName, this.fAttrProxy, (Augmentations) null);
                }
                Node firstChild = elementImpl.getFirstChild();
                while (true) {
                    Node node2 = firstChild;
                    if (node2 == null) {
                        if (this.fValidationHandler != null) {
                            updateQName(elementImpl, this.fQName);
                            this.fConfiguration.fErrorHandlerWrapper.fCurrentNode = cDATASection;
                            this.fCurrentNode = cDATASection;
                            this.fValidationHandler.endElement(this.fQName, (Augmentations) null);
                        }
                        this.fNamespaceContext.popContext();
                        break;
                    } else {
                        Node nextSibling2 = node2.getNextSibling();
                        Node normalizeNode = normalizeNode(node2);
                        if (normalizeNode != null) {
                            nextSibling2 = normalizeNode;
                        }
                        firstChild = nextSibling2;
                    }
                }
                break;
            case 3:
                Node nextSibling3 = cDATASection.getNextSibling();
                if (nextSibling3 == null || nextSibling3.getNodeType() != 3) {
                    if (cDATASection.getNodeValue().length() != 0) {
                        short nodeType2 = nextSibling3 != null ? nextSibling3.getNodeType() : -1;
                        if (nodeType2 == -1 || !(((this.fConfiguration.features & 4) == 0 && nodeType2 == 6) || (((this.fConfiguration.features & 32) == 0 && nodeType2 == 8) || ((this.fConfiguration.features & 8) == 0 && nodeType2 == 4)))) {
                            if (this.fDocument.errorChecking && (this.fConfiguration.features & XSSimpleTypeDefinition.FACET_MININCLUSIVE) != 0) {
                                isXMLCharWF(this.fErrorHandler, this.fError, this.fLocator, cDATASection.getNodeValue(), this.fDocument.isXML11Version());
                            }
                            if (this.fValidationHandler != null) {
                                this.fConfiguration.fErrorHandlerWrapper.fCurrentNode = cDATASection;
                                this.fCurrentNode = cDATASection;
                                boolean characterData = this.fValidationHandler.characterData(cDATASection.getNodeValue(), (Augmentations) null);
                                if (!this.fNamespaceValidation) {
                                    if (!this.fAllWhitespace) {
                                        ((TextImpl) cDATASection).setIgnorableWhitespace(false);
                                        break;
                                    } else {
                                        this.fAllWhitespace = false;
                                        ((TextImpl) cDATASection).setIgnorableWhitespace(true);
                                        break;
                                    }
                                }
                            }
                        }
                    } else {
                        Node removeChild = cDATASection.getParentNode().removeChild(cDATASection);
                        break;
                    }
                } else {
                    ((Text) cDATASection).appendData(nextSibling3.getNodeValue());
                    Node removeChild2 = cDATASection.getParentNode().removeChild(nextSibling3);
                    return cDATASection;
                }
                break;
            case 4:
                if ((this.fConfiguration.features & 8) != 0) {
                    if (this.fValidationHandler != null) {
                        this.fConfiguration.fErrorHandlerWrapper.fCurrentNode = cDATASection;
                        this.fCurrentNode = cDATASection;
                        this.fValidationHandler.startCDATA((Augmentations) null);
                        boolean characterData2 = this.fValidationHandler.characterData(cDATASection.getNodeValue(), (Augmentations) null);
                        this.fValidationHandler.endCDATA((Augmentations) null);
                    }
                    String nodeValue = cDATASection.getNodeValue();
                    if ((this.fConfiguration.features & 16) == 0) {
                        if (this.fDocument.errorChecking) {
                            isCDataWF(this.fErrorHandler, this.fError, this.fLocator, nodeValue, this.fDocument.isXML11Version());
                            break;
                        }
                    } else {
                        Node parentNode = cDATASection.getParentNode();
                        if (this.fDocument.errorChecking) {
                            isXMLCharWF(this.fErrorHandler, this.fError, this.fLocator, cDATASection.getNodeValue(), this.fDocument.isXML11Version());
                        }
                        while (true) {
                            int indexOf = nodeValue.indexOf("]]>");
                            int i3 = indexOf;
                            if (indexOf < 0) {
                                break;
                            } else {
                                cDATASection.setNodeValue(nodeValue.substring(0, i3 + 2));
                                nodeValue = nodeValue.substring(i3 + 2);
                                Node node3 = cDATASection;
                                CDATASection createCDATASection = this.fDocument.createCDATASection(nodeValue);
                                Node insertBefore = parentNode.insertBefore(createCDATASection, cDATASection.getNextSibling());
                                cDATASection = createCDATASection;
                                this.fLocator.fRelatedNode = node3;
                                reportDOMError(this.fErrorHandler, this.fError, this.fLocator, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "cdata-sections-splitted", (Object[]) null), 1, "cdata-sections-splitted");
                            }
                        }
                    }
                } else {
                    Node previousSibling = cDATASection.getPreviousSibling();
                    if (previousSibling == null || previousSibling.getNodeType() != 3) {
                        Text createTextNode = this.fDocument.createTextNode(cDATASection.getNodeValue());
                        Node replaceChild = cDATASection.getParentNode().replaceChild(createTextNode, cDATASection);
                        return createTextNode;
                    }
                    ((Text) previousSibling).appendData(cDATASection.getNodeValue());
                    Node removeChild3 = cDATASection.getParentNode().removeChild(cDATASection);
                    return previousSibling;
                }
                break;
            case 5:
                if ((this.fConfiguration.features & 4) != 0) {
                    if (this.fDocument.errorChecking && (this.fConfiguration.features & XSSimpleTypeDefinition.FACET_MININCLUSIVE) != 0 && this.fDocument.isXMLVersionChanged()) {
                        boolean isXMLName = CoreDocumentImpl.isXMLName(cDATASection.getNodeName(), this.fDocument.isXML11Version());
                        break;
                    }
                } else {
                    Node previousSibling2 = cDATASection.getPreviousSibling();
                    Node parentNode2 = cDATASection.getParentNode();
                    ((EntityReferenceImpl) cDATASection).setReadOnly(false, true);
                    expandEntityRef(parentNode2, cDATASection);
                    Node removeChild4 = parentNode2.removeChild(cDATASection);
                    Node nextSibling4 = previousSibling2 != null ? previousSibling2.getNextSibling() : parentNode2.getFirstChild();
                    return (previousSibling2 == null || nextSibling4 == null || previousSibling2.getNodeType() != 3 || nextSibling4.getNodeType() != 3) ? nextSibling4 : previousSibling2;
                }
                break;
            case Zip4jConstants.DEFLATE_LEVEL_MAXIMUM:
                if (this.fDocument.errorChecking && (this.fConfiguration.features & XSSimpleTypeDefinition.FACET_MININCLUSIVE) != 0) {
                    ProcessingInstruction processingInstruction = (ProcessingInstruction) cDATASection;
                    String target = processingInstruction.getTarget();
                    if (!(this.fDocument.isXML11Version() ? XML11Char.isXML11ValidName(target) : XMLChar.isValidName(target))) {
                        Object[] objArr5 = new Object[2];
                        objArr5[0] = "Element";
                        Object[] objArr6 = objArr5;
                        objArr6[1] = cDATASection.getNodeName();
                        reportDOMError(this.fErrorHandler, this.fError, this.fLocator, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "wf-invalid-character-in-node-name", objArr6), 2, "wf-invalid-character-in-node-name");
                    }
                    isXMLCharWF(this.fErrorHandler, this.fError, this.fLocator, processingInstruction.getData(), this.fDocument.isXML11Version());
                }
                if (this.fValidationHandler != null) {
                    this.fValidationHandler.processingInstruction(((ProcessingInstruction) cDATASection).getTarget(), EMPTY_STRING, (Augmentations) null);
                    break;
                }
                break;
            case 8:
                if ((this.fConfiguration.features & 32) != 0) {
                    if (this.fDocument.errorChecking && (this.fConfiguration.features & XSSimpleTypeDefinition.FACET_MININCLUSIVE) != 0) {
                        isCommentWF(this.fErrorHandler, this.fError, this.fLocator, ((Comment) cDATASection).getData(), this.fDocument.isXML11Version());
                    }
                    if (this.fValidationHandler != null) {
                        this.fValidationHandler.comment(EMPTY_STRING, (Augmentations) null);
                        break;
                    }
                } else {
                    Node previousSibling3 = cDATASection.getPreviousSibling();
                    Node parentNode3 = cDATASection.getParentNode();
                    Node removeChild5 = parentNode3.removeChild(cDATASection);
                    if (previousSibling3 != null && previousSibling3.getNodeType() == 3 && (nextSibling = previousSibling3.getNextSibling()) != null && nextSibling.getNodeType() == 3) {
                        ((TextImpl) nextSibling).insertData(0, previousSibling3.getNodeValue());
                        Node removeChild6 = parentNode3.removeChild(previousSibling3);
                        return nextSibling;
                    }
                }
                break;
        }
        return null;
    }

    public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void setDocumentSource(XMLDocumentSource xMLDocumentSource) {
    }

    public void startCDATA(Augmentations augmentations) throws XNIException {
    }

    public void startDocument(XMLLocator xMLLocator, String str, NamespaceContext namespaceContext, Augmentations augmentations) throws XNIException {
    }

    public void startElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        String schemaNormalizedValue;
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        Element element = (Element) this.fCurrentNode;
        int length = xMLAttributes2.getLength();
        for (int i = 0; i < length; i++) {
            xMLAttributes2.getName(i, this.fAttrQName);
            Attr attributeNodeNS = element.getAttributeNodeNS(this.fAttrQName.uri, this.fAttrQName.localpart);
            if (attributeNodeNS == null) {
                attributeNodeNS = element.getAttributeNode(this.fAttrQName.rawname);
            }
            AttributePSVI attributePSVI = (AttributePSVI) xMLAttributes2.getAugmentations(i).getItem("ATTRIBUTE_PSVI");
            if (attributePSVI != null) {
                XSSimpleType memberTypeDefinition = attributePSVI.getMemberTypeDefinition();
                boolean z = false;
                if (memberTypeDefinition != null) {
                    z = memberTypeDefinition.isIDType();
                } else {
                    memberTypeDefinition = attributePSVI.getTypeDefinition();
                    if (memberTypeDefinition != null) {
                        z = memberTypeDefinition.isIDType();
                    }
                }
                if (z) {
                    ((ElementImpl) element).setIdAttributeNode(attributeNodeNS, true);
                }
                if (this.fPSVI) {
                    ((PSVIAttrNSImpl) attributeNodeNS).setPSVI(attributePSVI);
                }
                ((AttrImpl) attributeNodeNS).setType(memberTypeDefinition);
                if (!((this.fConfiguration.features & 2) == 0 || (schemaNormalizedValue = attributePSVI.getSchemaNormalizedValue()) == null)) {
                    boolean specified = attributeNodeNS.getSpecified();
                    attributeNodeNS.setValue(schemaNormalizedValue);
                    if (!specified) {
                        ((AttrImpl) attributeNodeNS).setSpecified(specified);
                    }
                }
            } else {
                String str = null;
                if (Boolean.TRUE.equals(xMLAttributes2.getAugmentations(i).getItem("ATTRIBUTE_DECLARED"))) {
                    str = xMLAttributes2.getType(i);
                    if ("ID".equals(str)) {
                        ((ElementImpl) element).setIdAttributeNode(attributeNodeNS, true);
                    }
                }
                ((AttrImpl) attributeNodeNS).setType(str);
            }
        }
    }

    public void startGeneralEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
    }

    public void textDecl(String str, String str2, Augmentations augmentations) throws XNIException {
    }

    /* access modifiers changed from: protected */
    public final void updateQName(Node node, QName qName) {
        Node node2 = node;
        QName qName2 = qName;
        String prefix = node2.getPrefix();
        String namespaceURI = node2.getNamespaceURI();
        String localName = node2.getLocalName();
        qName2.prefix = (prefix == null || prefix.length() == 0) ? null : this.fSymbolTable.addSymbol(prefix);
        qName2.localpart = localName != null ? this.fSymbolTable.addSymbol(localName) : null;
        qName2.rawname = this.fSymbolTable.addSymbol(node2.getNodeName());
        qName2.uri = namespaceURI != null ? this.fSymbolTable.addSymbol(namespaceURI) : null;
    }

    public void xmlDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
    }
}
