package org.apache.xerces.dom;

import org.w3c.dom.ProcessingInstruction;

public class ProcessingInstructionImpl extends CharacterDataImpl implements ProcessingInstruction {
    static final long serialVersionUID = 7554435174099981510L;
    protected String target;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ProcessingInstructionImpl(CoreDocumentImpl coreDocumentImpl, String str, String str2) {
        super(coreDocumentImpl, str2);
        this.target = str;
    }

    public String getBaseURI() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.ownerNode.getBaseURI();
    }

    public String getNodeName() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.target;
    }

    public short getNodeType() {
        return 7;
    }

    public String getTarget() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.target;
    }
}
