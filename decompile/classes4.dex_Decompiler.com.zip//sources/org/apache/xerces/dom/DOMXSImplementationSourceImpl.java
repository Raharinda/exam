package org.apache.xerces.dom;

import java.util.ArrayList;
import org.apache.xerces.impl.xs.XSImplementationImpl;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.DOMImplementationList;

public class DOMXSImplementationSourceImpl extends DOMImplementationSourceImpl {
    public DOMXSImplementationSourceImpl() {
    }

    public DOMImplementation getDOMImplementation(String str) {
        String str2 = str;
        DOMImplementation dOMImplementation = super.getDOMImplementation(str2);
        if (dOMImplementation != null) {
            return dOMImplementation;
        }
        DOMImplementation dOMImplementation2 = PSVIDOMImplementationImpl.getDOMImplementation();
        if (testImpl(dOMImplementation2, str2)) {
            return dOMImplementation2;
        }
        DOMImplementation dOMImplementation3 = XSImplementationImpl.getDOMImplementation();
        if (testImpl(dOMImplementation3, str2)) {
            return dOMImplementation3;
        }
        return null;
    }

    public DOMImplementationList getDOMImplementationList(String str) {
        ArrayList arrayList;
        DOMImplementationList dOMImplementationList;
        String str2 = str;
        new ArrayList();
        ArrayList arrayList2 = arrayList;
        DOMImplementationList dOMImplementationList2 = super.getDOMImplementationList(str2);
        for (int i = 0; i < dOMImplementationList2.getLength(); i++) {
            boolean add = arrayList2.add(dOMImplementationList2.item(i));
        }
        DOMImplementation dOMImplementation = PSVIDOMImplementationImpl.getDOMImplementation();
        if (testImpl(dOMImplementation, str2)) {
            boolean add2 = arrayList2.add(dOMImplementation);
        }
        DOMImplementation dOMImplementation2 = XSImplementationImpl.getDOMImplementation();
        if (testImpl(dOMImplementation2, str2)) {
            boolean add3 = arrayList2.add(dOMImplementation2);
        }
        new DOMImplementationListImpl(arrayList2);
        return dOMImplementationList;
    }
}
