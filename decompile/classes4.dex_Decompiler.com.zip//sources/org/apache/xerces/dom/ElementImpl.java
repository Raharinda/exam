package org.apache.xerces.dom;

import com.microsoft.appcenter.Constants;
import org.apache.xerces.util.URI;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.ElementTraversal;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.w3c.dom.TypeInfo;

public class ElementImpl extends ParentNode implements Element, ElementTraversal, TypeInfo {
    static final long serialVersionUID = 3717253516652722278L;
    protected AttributeMap attributes;
    protected String name;

    protected ElementImpl() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ElementImpl(CoreDocumentImpl coreDocumentImpl, String str) {
        super(coreDocumentImpl);
        this.name = str;
        needsSyncData(true);
    }

    private Element getFirstElementChild(Node node) {
        Node node2 = node;
        Node node3 = node2;
        while (node2 != null) {
            if (node2.getNodeType() == 1) {
                return (Element) node2;
            }
            Node firstChild = node2.getFirstChild();
            while (firstChild == null && node3 != node2) {
                firstChild = node2.getNextSibling();
                if (firstChild == null) {
                    node2 = node2.getParentNode();
                    if (node2 == null || node3 == node2) {
                        return null;
                    }
                }
            }
            node2 = firstChild;
        }
        return null;
    }

    private Element getLastElementChild(Node node) {
        Node node2 = node;
        Node node3 = node2;
        while (node2 != null) {
            if (node2.getNodeType() == 1) {
                return (Element) node2;
            }
            Node lastChild = node2.getLastChild();
            while (lastChild == null && node3 != node2) {
                lastChild = node2.getPreviousSibling();
                if (lastChild == null) {
                    node2 = node2.getParentNode();
                    if (node2 == null || node3 == node2) {
                        return null;
                    }
                }
            }
            node2 = lastChild;
        }
        return null;
    }

    private Node getNextLogicalSibling(Node node) {
        Node node2 = node;
        Node nextSibling = node2.getNextSibling();
        if (nextSibling == null) {
            Node parentNode = node2.getParentNode();
            while (true) {
                Node node3 = parentNode;
                if (node3 == null || node3.getNodeType() != 5) {
                    break;
                }
                nextSibling = node3.getNextSibling();
                if (nextSibling != null) {
                    break;
                }
                parentNode = node3.getParentNode();
            }
        }
        return nextSibling;
    }

    private Node getPreviousLogicalSibling(Node node) {
        Node node2 = node;
        Node previousSibling = node2.getPreviousSibling();
        if (previousSibling == null) {
            Node parentNode = node2.getParentNode();
            while (true) {
                Node node3 = parentNode;
                if (node3 == null || node3.getNodeType() != 5) {
                    break;
                }
                previousSibling = node3.getPreviousSibling();
                if (previousSibling != null) {
                    break;
                }
                parentNode = node3.getParentNode();
            }
        }
        return previousSibling;
    }

    public Node cloneNode(boolean z) {
        ElementImpl elementImpl = (ElementImpl) super.cloneNode(z);
        if (this.attributes != null) {
            elementImpl.attributes = (AttributeMap) this.attributes.cloneMap(elementImpl);
        }
        return elementImpl;
    }

    public String getAttribute(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.attributes == null) {
            return "";
        }
        Attr attr = (Attr) this.attributes.getNamedItem(str2);
        return attr == null ? "" : attr.getValue();
    }

    public String getAttributeNS(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.attributes == null) {
            return "";
        }
        Attr attr = (Attr) this.attributes.getNamedItemNS(str3, str4);
        return attr == null ? "" : attr.getValue();
    }

    public Attr getAttributeNode(String str) {
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.attributes == null) {
            return null;
        }
        return (Attr) this.attributes.getNamedItem(str2);
    }

    public Attr getAttributeNodeNS(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.attributes == null) {
            return null;
        }
        return (Attr) this.attributes.getNamedItemNS(str3, str4);
    }

    public NamedNodeMap getAttributes() {
        AttributeMap attributeMap;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.attributes == null) {
            new AttributeMap(this, (NamedNodeMapImpl) null);
            this.attributes = attributeMap;
        }
        return this.attributes;
    }

    public String getBaseURI() {
        Attr xMLBaseAttribute;
        URI uri;
        URI uri2;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (!(this.attributes == null || (xMLBaseAttribute = getXMLBaseAttribute()) == null)) {
            String nodeValue = xMLBaseAttribute.getNodeValue();
            if (nodeValue.length() != 0) {
                try {
                    new URI(nodeValue, true);
                    URI uri3 = uri;
                    if (uri3.isAbsoluteURI()) {
                        return uri3.toString();
                    }
                    String baseURI = this.ownerNode != null ? this.ownerNode.getBaseURI() : null;
                    if (baseURI == null) {
                        return null;
                    }
                    try {
                        new URI(baseURI);
                        uri3.absolutize(uri2);
                        return uri3.toString();
                    } catch (URI.MalformedURIException e) {
                        URI.MalformedURIException malformedURIException = e;
                        return null;
                    }
                } catch (URI.MalformedURIException e2) {
                    URI.MalformedURIException malformedURIException2 = e2;
                    return null;
                }
            }
        }
        return this.ownerNode != null ? this.ownerNode.getBaseURI() : null;
    }

    public final int getChildElementCount() {
        int i = 0;
        Element firstElementChild = getFirstElementChild();
        while (true) {
            Element element = firstElementChild;
            if (element == null) {
                return i;
            }
            i++;
            firstElementChild = ((ElementImpl) element).getNextElementSibling();
        }
    }

    /* access modifiers changed from: protected */
    public NamedNodeMapImpl getDefaultAttributes() {
        DocumentTypeImpl documentTypeImpl = (DocumentTypeImpl) this.ownerDocument.getDoctype();
        if (documentTypeImpl == null) {
            return null;
        }
        ElementDefinitionImpl elementDefinitionImpl = (ElementDefinitionImpl) documentTypeImpl.getElements().getNamedItem(getNodeName());
        if (elementDefinitionImpl == null) {
            return null;
        }
        return (NamedNodeMapImpl) elementDefinitionImpl.getAttributes();
    }

    public NodeList getElementsByTagName(String str) {
        NodeList nodeList;
        new DeepNodeListImpl(this, str);
        return nodeList;
    }

    public NodeList getElementsByTagNameNS(String str, String str2) {
        NodeList nodeList;
        new DeepNodeListImpl(this, str, str2);
        return nodeList;
    }

    public final Element getFirstElementChild() {
        Node firstChild = getFirstChild();
        while (true) {
            Node node = firstChild;
            if (node == null) {
                return null;
            }
            switch (node.getNodeType()) {
                case 1:
                    return (Element) node;
                case 5:
                    Element firstElementChild = getFirstElementChild(node);
                    if (firstElementChild == null) {
                        break;
                    } else {
                        return firstElementChild;
                    }
            }
            firstChild = node.getNextSibling();
        }
    }

    public final Element getLastElementChild() {
        Node lastChild = getLastChild();
        while (true) {
            Node node = lastChild;
            if (node == null) {
                return null;
            }
            switch (node.getNodeType()) {
                case 1:
                    return (Element) node;
                case 5:
                    Element lastElementChild = getLastElementChild(node);
                    if (lastElementChild == null) {
                        break;
                    } else {
                        return lastElementChild;
                    }
            }
            lastChild = node.getPreviousSibling();
        }
    }

    public final Element getNextElementSibling() {
        Node nextLogicalSibling = getNextLogicalSibling(this);
        while (true) {
            Node node = nextLogicalSibling;
            if (node == null) {
                return null;
            }
            switch (node.getNodeType()) {
                case 1:
                    return (Element) node;
                case 5:
                    Element firstElementChild = getFirstElementChild(node);
                    if (firstElementChild == null) {
                        break;
                    } else {
                        return firstElementChild;
                    }
            }
            nextLogicalSibling = getNextLogicalSibling(node);
        }
    }

    public String getNodeName() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.name;
    }

    public short getNodeType() {
        return 1;
    }

    public final Element getPreviousElementSibling() {
        Node previousLogicalSibling = getPreviousLogicalSibling(this);
        while (true) {
            Node node = previousLogicalSibling;
            if (node == null) {
                return null;
            }
            switch (node.getNodeType()) {
                case 1:
                    return (Element) node;
                case 5:
                    Element lastElementChild = getLastElementChild(node);
                    if (lastElementChild == null) {
                        break;
                    } else {
                        return lastElementChild;
                    }
            }
            previousLogicalSibling = getPreviousLogicalSibling(node);
        }
    }

    public TypeInfo getSchemaTypeInfo() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this;
    }

    public String getTagName() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return this.name;
    }

    public String getTypeName() {
        return null;
    }

    public String getTypeNamespace() {
        return null;
    }

    /* access modifiers changed from: protected */
    public Attr getXMLBaseAttribute() {
        return (Attr) this.attributes.getNamedItem("xml:base");
    }

    /* access modifiers changed from: protected */
    public int getXercesAttribute(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.attributes == null) {
            return -1;
        }
        return this.attributes.getNamedItemIndex(str3, str4);
    }

    public boolean hasAttribute(String str) {
        return getAttributeNode(str) != null;
    }

    public boolean hasAttributeNS(String str, String str2) {
        return getAttributeNodeNS(str, str2) != null;
    }

    public boolean hasAttributes() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return (this.attributes == null || this.attributes.getLength() == 0) ? false : true;
    }

    public boolean isDerivedFrom(String str, String str2, int i) {
        String str3 = str;
        String str4 = str2;
        int i2 = i;
        return false;
    }

    public boolean isEqualNode(Node node) {
        Node node2 = node;
        if (!super.isEqualNode(node2)) {
            return false;
        }
        boolean hasAttributes = hasAttributes();
        if (hasAttributes != ((Element) node2).hasAttributes()) {
            return false;
        }
        if (hasAttributes) {
            NamedNodeMap attributes2 = getAttributes();
            NamedNodeMap attributes3 = ((Element) node2).getAttributes();
            int length = attributes2.getLength();
            if (length != attributes3.getLength()) {
                return false;
            }
            for (int i = 0; i < length; i++) {
                Node item = attributes2.item(i);
                if (item.getLocalName() == null) {
                    Node namedItem = attributes3.getNamedItem(item.getNodeName());
                    if (namedItem == null || !((NodeImpl) item).isEqualNode(namedItem)) {
                        return false;
                    }
                } else {
                    Node namedItemNS = attributes3.getNamedItemNS(item.getNamespaceURI(), item.getLocalName());
                    if (namedItemNS == null || !((NodeImpl) item).isEqualNode(namedItemNS)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    public void moveSpecifiedAttributes(ElementImpl elementImpl) {
        AttributeMap attributeMap;
        ElementImpl elementImpl2 = elementImpl;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (elementImpl2.hasAttributes()) {
            if (this.attributes == null) {
                new AttributeMap(this, (NamedNodeMapImpl) null);
                this.attributes = attributeMap;
            }
            this.attributes.moveSpecifiedAttributes(elementImpl2.attributes);
        }
    }

    public void normalize() {
        if (!isNormalized()) {
            if (needsSyncChildren()) {
                synchronizeChildren();
            }
            ChildNode childNode = this.firstChild;
            while (true) {
                ChildNode childNode2 = childNode;
                if (childNode2 == null) {
                    break;
                }
                ChildNode childNode3 = childNode2.nextSibling;
                if (childNode2.getNodeType() == 3) {
                    if (childNode3 != null && childNode3.getNodeType() == 3) {
                        ((Text) childNode2).appendData(childNode3.getNodeValue());
                        Node removeChild = removeChild(childNode3);
                        childNode3 = childNode2;
                    } else if (childNode2.getNodeValue() == null || childNode2.getNodeValue().length() == 0) {
                        Node removeChild2 = removeChild(childNode2);
                    }
                } else if (childNode2.getNodeType() == 1) {
                    childNode2.normalize();
                }
                childNode = childNode3;
            }
            if (this.attributes != null) {
                for (int i = 0; i < this.attributes.getLength(); i++) {
                    this.attributes.item(i).normalize();
                }
            }
            isNormalized(true);
        }
    }

    /* access modifiers changed from: protected */
    public void reconcileDefaultAttributes() {
        if (this.attributes != null) {
            this.attributes.reconcileDefaults(getDefaultAttributes());
        }
    }

    public void removeAttribute(String str) {
        Throwable th;
        String str2 = str;
        if (!this.ownerDocument.errorChecking || !isReadOnly()) {
            if (needsSyncData()) {
                synchronizeData();
            }
            if (this.attributes != null) {
                Node safeRemoveNamedItem = this.attributes.safeRemoveNamedItem(str2);
                return;
            }
            return;
        }
        Throwable th2 = th;
        new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
        throw th2;
    }

    public void removeAttributeNS(String str, String str2) {
        Throwable th;
        String str3 = str;
        String str4 = str2;
        if (!this.ownerDocument.errorChecking || !isReadOnly()) {
            if (needsSyncData()) {
                synchronizeData();
            }
            if (this.attributes != null) {
                Node safeRemoveNamedItemNS = this.attributes.safeRemoveNamedItemNS(str3, str4);
                return;
            }
            return;
        }
        Throwable th2 = th;
        new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
        throw th2;
    }

    public Attr removeAttributeNode(Attr attr) throws DOMException {
        Throwable th;
        Throwable th2;
        Attr attr2 = attr;
        if (!this.ownerDocument.errorChecking || !isReadOnly()) {
            if (needsSyncData()) {
                synchronizeData();
            }
            if (this.attributes != null) {
                return (Attr) this.attributes.removeItem(attr2, true);
            }
            Throwable th3 = th;
            new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
            throw th3;
        }
        Throwable th4 = th2;
        new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
        throw th4;
    }

    /* access modifiers changed from: package-private */
    public void rename(String str) {
        Throwable th;
        Throwable th2;
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.ownerDocument.errorChecking) {
            if (str2.indexOf(58) != -1) {
                Throwable th3 = th2;
                new DOMException(14, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NAMESPACE_ERR", (Object[]) null));
                throw th3;
            } else if (!CoreDocumentImpl.isXMLName(str2, this.ownerDocument.isXML11Version())) {
                Throwable th4 = th;
                new DOMException(5, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_CHARACTER_ERR", (Object[]) null));
                throw th4;
            }
        }
        this.name = str2;
        reconcileDefaultAttributes();
    }

    public void setAttribute(String str, String str2) {
        AttributeMap attributeMap;
        Throwable th;
        String str3 = str;
        String str4 = str2;
        if (!this.ownerDocument.errorChecking || !isReadOnly()) {
            if (needsSyncData()) {
                synchronizeData();
            }
            Attr attributeNode = getAttributeNode(str3);
            if (attributeNode == null) {
                Attr createAttribute = getOwnerDocument().createAttribute(str3);
                if (this.attributes == null) {
                    new AttributeMap(this, (NamedNodeMapImpl) null);
                    this.attributes = attributeMap;
                }
                createAttribute.setNodeValue(str4);
                Node namedItem = this.attributes.setNamedItem(createAttribute);
                return;
            }
            attributeNode.setNodeValue(str4);
            return;
        }
        Throwable th2 = th;
        new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
        throw th2;
    }

    public void setAttributeNS(String str, String str2, String str3) {
        String substring;
        String substring2;
        String str4;
        StringBuffer stringBuffer;
        AttributeMap attributeMap;
        Throwable th;
        String str5 = str;
        String str6 = str2;
        String str7 = str3;
        if (!this.ownerDocument.errorChecking || !isReadOnly()) {
            if (needsSyncData()) {
                synchronizeData();
            }
            int indexOf = str6.indexOf(58);
            if (indexOf < 0) {
                substring = null;
                substring2 = str6;
            } else {
                substring = str6.substring(0, indexOf);
                substring2 = str6.substring(indexOf + 1);
            }
            Attr attributeNodeNS = getAttributeNodeNS(str5, substring2);
            if (attributeNodeNS == null) {
                Attr createAttributeNS = getOwnerDocument().createAttributeNS(str5, str6);
                if (this.attributes == null) {
                    new AttributeMap(this, (NamedNodeMapImpl) null);
                    this.attributes = attributeMap;
                }
                createAttributeNS.setNodeValue(str7);
                Node namedItemNS = this.attributes.setNamedItemNS(createAttributeNS);
                return;
            }
            if (attributeNodeNS instanceof AttrNSImpl) {
                AttrNSImpl attrNSImpl = (AttrNSImpl) attributeNodeNS;
                if (substring != null) {
                    new StringBuffer();
                    str4 = stringBuffer.append(substring).append(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR).append(substring2).toString();
                } else {
                    str4 = substring2;
                }
                attrNSImpl.name = str4;
            } else {
                attributeNodeNS = ((CoreDocumentImpl) getOwnerDocument()).createAttributeNS(str5, str6, substring2);
                Node namedItemNS2 = this.attributes.setNamedItemNS(attributeNodeNS);
            }
            attributeNodeNS.setNodeValue(str7);
            return;
        }
        Throwable th2 = th;
        new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
        throw th2;
    }

    public Attr setAttributeNode(Attr attr) throws DOMException {
        AttributeMap attributeMap;
        Throwable th;
        Throwable th2;
        Attr attr2 = attr;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.ownerDocument.errorChecking) {
            if (isReadOnly()) {
                Throwable th3 = th2;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th3;
            } else if (attr2.getOwnerDocument() != this.ownerDocument) {
                Throwable th4 = th;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th4;
            }
        }
        if (this.attributes == null) {
            new AttributeMap(this, (NamedNodeMapImpl) null);
            this.attributes = attributeMap;
        }
        return (Attr) this.attributes.setNamedItem(attr2);
    }

    public Attr setAttributeNodeNS(Attr attr) throws DOMException {
        AttributeMap attributeMap;
        Throwable th;
        Throwable th2;
        Attr attr2 = attr;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.ownerDocument.errorChecking) {
            if (isReadOnly()) {
                Throwable th3 = th2;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th3;
            } else if (attr2.getOwnerDocument() != this.ownerDocument) {
                Throwable th4 = th;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th4;
            }
        }
        if (this.attributes == null) {
            new AttributeMap(this, (NamedNodeMapImpl) null);
            this.attributes = attributeMap;
        }
        return (Attr) this.attributes.setNamedItemNS(attr2);
    }

    public void setIdAttribute(String str, boolean z) {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        boolean z2 = z;
        if (needsSyncData()) {
            synchronizeData();
        }
        Attr attributeNode = getAttributeNode(str2);
        if (attributeNode == null) {
            Throwable th4 = th3;
            new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
            throw th4;
        }
        if (this.ownerDocument.errorChecking) {
            if (isReadOnly()) {
                Throwable th5 = th2;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th5;
            } else if (attributeNode.getOwnerElement() != this) {
                Throwable th6 = th;
                new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
                throw th6;
            }
        }
        ((AttrImpl) attributeNode).isIdAttribute(z2);
        if (!z2) {
            this.ownerDocument.removeIdentifier(attributeNode.getValue());
        } else {
            this.ownerDocument.putIdentifier(attributeNode.getValue(), this);
        }
    }

    public void setIdAttributeNS(String str, String str2, boolean z) {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str3 = str;
        String str4 = str2;
        boolean z2 = z;
        if (needsSyncData()) {
            synchronizeData();
        }
        Attr attributeNodeNS = getAttributeNodeNS(str3, str4);
        if (attributeNodeNS == null) {
            Throwable th4 = th3;
            new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
            throw th4;
        }
        if (this.ownerDocument.errorChecking) {
            if (isReadOnly()) {
                Throwable th5 = th2;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th5;
            } else if (attributeNodeNS.getOwnerElement() != this) {
                Throwable th6 = th;
                new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
                throw th6;
            }
        }
        ((AttrImpl) attributeNodeNS).isIdAttribute(z2);
        if (!z2) {
            this.ownerDocument.removeIdentifier(attributeNodeNS.getValue());
        } else {
            this.ownerDocument.putIdentifier(attributeNodeNS.getValue(), this);
        }
    }

    public void setIdAttributeNode(Attr attr, boolean z) {
        Throwable th;
        Throwable th2;
        Attr attr2 = attr;
        boolean z2 = z;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.ownerDocument.errorChecking) {
            if (isReadOnly()) {
                Throwable th3 = th2;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th3;
            } else if (attr2.getOwnerElement() != this) {
                Throwable th4 = th;
                new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
                throw th4;
            }
        }
        ((AttrImpl) attr2).isIdAttribute(z2);
        if (!z2) {
            this.ownerDocument.removeIdentifier(attr2.getValue());
        } else {
            this.ownerDocument.putIdentifier(attr2.getValue(), this);
        }
    }

    /* access modifiers changed from: protected */
    public void setOwnerDocument(CoreDocumentImpl coreDocumentImpl) {
        CoreDocumentImpl coreDocumentImpl2 = coreDocumentImpl;
        super.setOwnerDocument(coreDocumentImpl2);
        if (this.attributes != null) {
            this.attributes.setOwnerDocument(coreDocumentImpl2);
        }
    }

    public void setReadOnly(boolean z, boolean z2) {
        boolean z3 = z;
        super.setReadOnly(z3, z2);
        if (this.attributes != null) {
            this.attributes.setReadOnly(z3, true);
        }
    }

    /* access modifiers changed from: protected */
    public int setXercesAttributeNode(Attr attr) {
        AttributeMap attributeMap;
        Attr attr2 = attr;
        if (needsSyncData()) {
            synchronizeData();
        }
        if (this.attributes == null) {
            new AttributeMap(this, (NamedNodeMapImpl) null);
            this.attributes = attributeMap;
        }
        return this.attributes.addItem(attr2);
    }

    /* access modifiers changed from: protected */
    public void setupDefaultAttributes() {
        AttributeMap attributeMap;
        NamedNodeMapImpl defaultAttributes = getDefaultAttributes();
        if (defaultAttributes != null) {
            new AttributeMap(this, defaultAttributes);
            this.attributes = attributeMap;
        }
    }

    /* access modifiers changed from: protected */
    public void synchronizeData() {
        needsSyncData(false);
        boolean mutationEvents = this.ownerDocument.getMutationEvents();
        this.ownerDocument.setMutationEvents(false);
        setupDefaultAttributes();
        this.ownerDocument.setMutationEvents(mutationEvents);
    }
}
