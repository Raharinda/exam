package org.apache.xerces.dom;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.traversal.NodeFilter;
import org.w3c.dom.traversal.TreeWalker;

public class TreeWalkerImpl implements TreeWalker {
    Node fCurrentNode;
    private boolean fEntityReferenceExpansion = false;
    NodeFilter fNodeFilter;
    Node fRoot;
    private boolean fUseIsSameNode;
    int fWhatToShow = -1;

    public TreeWalkerImpl(Node node, int i, NodeFilter nodeFilter, boolean z) {
        Node node2 = node;
        this.fCurrentNode = node2;
        this.fRoot = node2;
        this.fUseIsSameNode = useIsSameNode(node2);
        this.fWhatToShow = i;
        this.fNodeFilter = nodeFilter;
        this.fEntityReferenceExpansion = z;
    }

    private boolean isSameNode(Node node, Node node2) {
        Node node3 = node;
        Node node4 = node2;
        return this.fUseIsSameNode ? node3.isSameNode(node4) : node3 == node4;
    }

    private boolean useIsSameNode(Node node) {
        Node node2 = node;
        if (node2 instanceof NodeImpl) {
            return false;
        }
        Document ownerDocument = node2.getNodeType() == 9 ? (Document) node2 : node2.getOwnerDocument();
        return ownerDocument != null && ownerDocument.getImplementation().hasFeature("Core", "3.0");
    }

    /* access modifiers changed from: package-private */
    public short acceptNode(Node node) {
        Node node2 = node;
        if (this.fNodeFilter == null) {
            return (this.fWhatToShow & (1 << (node2.getNodeType() + -1))) != 0 ? (short) 1 : 3;
        }
        if ((this.fWhatToShow & (1 << (node2.getNodeType() - 1))) != 0) {
            return this.fNodeFilter.acceptNode(node2);
        }
        return 3;
    }

    public Node firstChild() {
        if (this.fCurrentNode == null) {
            return null;
        }
        Node firstChild = getFirstChild(this.fCurrentNode);
        if (firstChild != null) {
            this.fCurrentNode = firstChild;
        }
        return firstChild;
    }

    public Node getCurrentNode() {
        return this.fCurrentNode;
    }

    public boolean getExpandEntityReferences() {
        return this.fEntityReferenceExpansion;
    }

    public NodeFilter getFilter() {
        return this.fNodeFilter;
    }

    /* access modifiers changed from: package-private */
    public Node getFirstChild(Node node) {
        Node node2 = node;
        if (node2 == null) {
            return null;
        }
        if (!this.fEntityReferenceExpansion && node2.getNodeType() == 5) {
            return null;
        }
        Node firstChild = node2.getFirstChild();
        if (firstChild == null) {
            return null;
        }
        short acceptNode = acceptNode(firstChild);
        if (acceptNode == 1) {
            return firstChild;
        }
        if (acceptNode != 3 || !firstChild.hasChildNodes()) {
            return getNextSibling(firstChild, node2);
        }
        Node firstChild2 = getFirstChild(firstChild);
        return firstChild2 == null ? getNextSibling(firstChild, node2) : firstChild2;
    }

    /* access modifiers changed from: package-private */
    public Node getLastChild(Node node) {
        Node node2 = node;
        if (node2 == null) {
            return null;
        }
        if (!this.fEntityReferenceExpansion && node2.getNodeType() == 5) {
            return null;
        }
        Node lastChild = node2.getLastChild();
        if (lastChild == null) {
            return null;
        }
        short acceptNode = acceptNode(lastChild);
        if (acceptNode == 1) {
            return lastChild;
        }
        if (acceptNode != 3 || !lastChild.hasChildNodes()) {
            return getPreviousSibling(lastChild, node2);
        }
        Node lastChild2 = getLastChild(lastChild);
        return lastChild2 == null ? getPreviousSibling(lastChild, node2) : lastChild2;
    }

    /* access modifiers changed from: package-private */
    public Node getNextSibling(Node node) {
        return getNextSibling(node, this.fRoot);
    }

    /* access modifiers changed from: package-private */
    public Node getNextSibling(Node node, Node node2) {
        Node node3 = node;
        Node node4 = node2;
        if (node3 == null || isSameNode(node3, node4)) {
            return null;
        }
        Node nextSibling = node3.getNextSibling();
        if (nextSibling == null) {
            Node parentNode = node3.getParentNode();
            if (parentNode == null || isSameNode(parentNode, node4)) {
                return null;
            }
            if (acceptNode(parentNode) == 3) {
                return getNextSibling(parentNode, node4);
            }
            return null;
        }
        short acceptNode = acceptNode(nextSibling);
        if (acceptNode == 1) {
            return nextSibling;
        }
        if (acceptNode != 3) {
            return getNextSibling(nextSibling, node4);
        }
        Node firstChild = getFirstChild(nextSibling);
        return firstChild == null ? getNextSibling(nextSibling, node4) : firstChild;
    }

    /* access modifiers changed from: package-private */
    public Node getParentNode(Node node) {
        Node node2 = node;
        if (node2 == null || isSameNode(node2, this.fRoot)) {
            return null;
        }
        Node parentNode = node2.getParentNode();
        if (parentNode == null) {
            return null;
        }
        return acceptNode(parentNode) == 1 ? parentNode : getParentNode(parentNode);
    }

    /* access modifiers changed from: package-private */
    public Node getPreviousSibling(Node node) {
        return getPreviousSibling(node, this.fRoot);
    }

    /* access modifiers changed from: package-private */
    public Node getPreviousSibling(Node node, Node node2) {
        Node node3 = node;
        Node node4 = node2;
        if (node3 == null || isSameNode(node3, node4)) {
            return null;
        }
        Node previousSibling = node3.getPreviousSibling();
        if (previousSibling == null) {
            Node parentNode = node3.getParentNode();
            if (parentNode == null || isSameNode(parentNode, node4)) {
                return null;
            }
            if (acceptNode(parentNode) == 3) {
                return getPreviousSibling(parentNode, node4);
            }
            return null;
        }
        short acceptNode = acceptNode(previousSibling);
        if (acceptNode == 1) {
            return previousSibling;
        }
        if (acceptNode != 3) {
            return getPreviousSibling(previousSibling, node4);
        }
        Node lastChild = getLastChild(previousSibling);
        return lastChild == null ? getPreviousSibling(previousSibling, node4) : lastChild;
    }

    public Node getRoot() {
        return this.fRoot;
    }

    public int getWhatToShow() {
        return this.fWhatToShow;
    }

    public Node lastChild() {
        if (this.fCurrentNode == null) {
            return null;
        }
        Node lastChild = getLastChild(this.fCurrentNode);
        if (lastChild != null) {
            this.fCurrentNode = lastChild;
        }
        return lastChild;
    }

    public Node nextNode() {
        if (this.fCurrentNode == null) {
            return null;
        }
        Node firstChild = getFirstChild(this.fCurrentNode);
        if (firstChild != null) {
            this.fCurrentNode = firstChild;
            return firstChild;
        }
        Node nextSibling = getNextSibling(this.fCurrentNode);
        if (nextSibling != null) {
            this.fCurrentNode = nextSibling;
            return nextSibling;
        }
        Node parentNode = getParentNode(this.fCurrentNode);
        while (true) {
            Node node = parentNode;
            if (node == null) {
                return null;
            }
            Node nextSibling2 = getNextSibling(node);
            if (nextSibling2 != null) {
                this.fCurrentNode = nextSibling2;
                return nextSibling2;
            }
            parentNode = getParentNode(node);
        }
    }

    public Node nextSibling() {
        if (this.fCurrentNode == null) {
            return null;
        }
        Node nextSibling = getNextSibling(this.fCurrentNode);
        if (nextSibling != null) {
            this.fCurrentNode = nextSibling;
        }
        return nextSibling;
    }

    public Node parentNode() {
        if (this.fCurrentNode == null) {
            return null;
        }
        Node parentNode = getParentNode(this.fCurrentNode);
        if (parentNode != null) {
            this.fCurrentNode = parentNode;
        }
        return parentNode;
    }

    public Node previousNode() {
        if (this.fCurrentNode == null) {
            return null;
        }
        Node previousSibling = getPreviousSibling(this.fCurrentNode);
        if (previousSibling == null) {
            Node parentNode = getParentNode(this.fCurrentNode);
            if (parentNode == null) {
                return null;
            }
            this.fCurrentNode = parentNode;
            return this.fCurrentNode;
        }
        Node lastChild = getLastChild(previousSibling);
        Node node = lastChild;
        while (lastChild != null) {
            node = lastChild;
            lastChild = getLastChild(node);
        }
        Node node2 = node;
        if (node2 != null) {
            this.fCurrentNode = node2;
            return this.fCurrentNode;
        } else if (previousSibling == null) {
            return null;
        } else {
            this.fCurrentNode = previousSibling;
            return this.fCurrentNode;
        }
    }

    public Node previousSibling() {
        if (this.fCurrentNode == null) {
            return null;
        }
        Node previousSibling = getPreviousSibling(this.fCurrentNode);
        if (previousSibling != null) {
            this.fCurrentNode = previousSibling;
        }
        return previousSibling;
    }

    public void setCurrentNode(Node node) {
        Throwable th;
        Node node2 = node;
        if (node2 == null) {
            Throwable th2 = th;
            new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_SUPPORTED_ERR", (Object[]) null));
            throw th2;
        }
        this.fCurrentNode = node2;
    }

    public void setWhatShow(int i) {
        int i2 = i;
        this.fWhatToShow = i2;
    }
}
