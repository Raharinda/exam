package org.apache.xerces.dom;

import org.w3c.dom.Node;

public class DeferredElementDefinitionImpl extends ElementDefinitionImpl implements DeferredNode {
    static final long serialVersionUID = 6703238199538041591L;
    protected transient int fNodeIndex;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    DeferredElementDefinitionImpl(DeferredDocumentImpl deferredDocumentImpl, int i) {
        super(deferredDocumentImpl, (String) null);
        this.fNodeIndex = i;
        needsSyncData(true);
        needsSyncChildren(true);
    }

    public int getNodeIndex() {
        return this.fNodeIndex;
    }

    /* access modifiers changed from: protected */
    public void synchronizeChildren() {
        NamedNodeMapImpl namedNodeMapImpl;
        boolean mutationEvents = this.ownerDocument.getMutationEvents();
        this.ownerDocument.setMutationEvents(false);
        needsSyncChildren(false);
        DeferredDocumentImpl deferredDocumentImpl = (DeferredDocumentImpl) this.ownerDocument;
        new NamedNodeMapImpl(deferredDocumentImpl);
        this.attributes = namedNodeMapImpl;
        int lastChild = deferredDocumentImpl.getLastChild(this.fNodeIndex);
        while (true) {
            int i = lastChild;
            if (i == -1) {
                deferredDocumentImpl.setMutationEvents(mutationEvents);
                return;
            }
            Node namedItem = this.attributes.setNamedItem(deferredDocumentImpl.getNodeObject(i));
            lastChild = deferredDocumentImpl.getPrevSibling(i);
        }
    }

    /* access modifiers changed from: protected */
    public void synchronizeData() {
        needsSyncData(false);
        this.name = ((DeferredDocumentImpl) this.ownerDocument).getNodeName(this.fNodeIndex);
    }
}
