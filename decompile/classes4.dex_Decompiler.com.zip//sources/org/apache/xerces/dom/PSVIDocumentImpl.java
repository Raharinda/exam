package org.apache.xerces.dom;

import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMConfiguration;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class PSVIDocumentImpl extends DocumentImpl {
    static final long serialVersionUID = -8822220250676434522L;

    public PSVIDocumentImpl() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public PSVIDocumentImpl(DocumentType documentType) {
        super(documentType);
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        Throwable th;
        ObjectInputStream objectInputStream2 = objectInputStream;
        Throwable th2 = th;
        new NotSerializableException(getClass().getName());
        throw th2;
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        Throwable th;
        ObjectOutputStream objectOutputStream2 = objectOutputStream;
        Throwable th2 = th;
        new NotSerializableException(getClass().getName());
        throw th2;
    }

    public Node cloneNode(boolean z) {
        PSVIDocumentImpl pSVIDocumentImpl;
        new PSVIDocumentImpl();
        PSVIDocumentImpl pSVIDocumentImpl2 = pSVIDocumentImpl;
        callUserDataHandlers(this, pSVIDocumentImpl2, 1);
        cloneNode(pSVIDocumentImpl2, z);
        pSVIDocumentImpl2.mutationEvents = this.mutationEvents;
        return pSVIDocumentImpl2;
    }

    public Attr createAttributeNS(String str, String str2) throws DOMException {
        Attr attr;
        new PSVIAttrNSImpl(this, str, str2);
        return attr;
    }

    public Attr createAttributeNS(String str, String str2, String str3) throws DOMException {
        Attr attr;
        new PSVIAttrNSImpl(this, str, str2, str3);
        return attr;
    }

    public Element createElementNS(String str, String str2) throws DOMException {
        Element element;
        new PSVIElementNSImpl(this, str, str2);
        return element;
    }

    public Element createElementNS(String str, String str2, String str3) throws DOMException {
        Element element;
        new PSVIElementNSImpl(this, str, str2, str3);
        return element;
    }

    public DOMConfiguration getDomConfig() {
        DOMConfiguration domConfig = super.getDomConfig();
        return this.fConfiguration;
    }

    public DOMImplementation getImplementation() {
        return PSVIDOMImplementationImpl.getDOMImplementation();
    }
}
