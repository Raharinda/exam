package org.apache.xerces.dom;

import org.w3c.dom.CharacterData;
import org.w3c.dom.DOMException;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

public class TextImpl extends CharacterDataImpl implements CharacterData, Text {
    static final long serialVersionUID = -5294980852957403469L;

    public TextImpl() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public TextImpl(CoreDocumentImpl coreDocumentImpl, String str) {
        super(coreDocumentImpl, str);
    }

    private boolean canModifyNext(Node node) {
        boolean z = false;
        Node nextSibling = node.getNextSibling();
        while (true) {
            Node node2 = nextSibling;
            if (node2 == null) {
                return true;
            }
            short nodeType = node2.getNodeType();
            if (nodeType == 5) {
                Node firstChild = node2.getFirstChild();
                if (firstChild == null) {
                    return false;
                }
                while (firstChild != null) {
                    short nodeType2 = firstChild.getNodeType();
                    if (!(nodeType2 == 3 || nodeType2 == 4)) {
                        if (nodeType2 != 5) {
                            return !z;
                        }
                        if (!canModifyNext(firstChild)) {
                            return false;
                        }
                    }
                    z = true;
                    firstChild = firstChild.getNextSibling();
                }
                continue;
            } else if (!(nodeType == 3 || nodeType == 4)) {
                return true;
            }
            nextSibling = node2.getNextSibling();
        }
    }

    private boolean canModifyPrev(Node node) {
        boolean z = false;
        Node previousSibling = node.getPreviousSibling();
        while (true) {
            Node node2 = previousSibling;
            if (node2 == null) {
                return true;
            }
            short nodeType = node2.getNodeType();
            if (nodeType == 5) {
                Node lastChild = node2.getLastChild();
                if (lastChild == null) {
                    return false;
                }
                while (lastChild != null) {
                    short nodeType2 = lastChild.getNodeType();
                    if (!(nodeType2 == 3 || nodeType2 == 4)) {
                        if (nodeType2 != 5) {
                            return !z;
                        }
                        if (!canModifyPrev(lastChild)) {
                            return false;
                        }
                    }
                    z = true;
                    lastChild = lastChild.getPreviousSibling();
                }
                continue;
            } else if (!(nodeType == 3 || nodeType == 4)) {
                return true;
            }
            previousSibling = node2.getPreviousSibling();
        }
    }

    private boolean getWholeTextBackward(Node node, StringBuffer stringBuffer, Node node2) {
        StringBuffer stringBuffer2 = stringBuffer;
        Node node3 = node2;
        boolean z = false;
        if (node3 != null) {
            z = node3.getNodeType() == 5;
        }
        for (Node node4 = node; node4 != null; node4 = node4.getPreviousSibling()) {
            short nodeType = node4.getNodeType();
            if (nodeType == 5) {
                if (getWholeTextBackward(node4.getLastChild(), stringBuffer2, node4)) {
                    return true;
                }
            } else if (nodeType != 3 && nodeType != 4) {
                return true;
            } else {
                ((TextImpl) node4).insertTextContent(stringBuffer2);
            }
        }
        if (!z) {
            return false;
        }
        boolean wholeTextBackward = getWholeTextBackward(node3.getPreviousSibling(), stringBuffer2, node3.getParentNode());
        return true;
    }

    private boolean getWholeTextForward(Node node, StringBuffer stringBuffer, Node node2) {
        StringBuffer stringBuffer2 = stringBuffer;
        Node node3 = node2;
        boolean z = false;
        if (node3 != null) {
            z = node3.getNodeType() == 5;
        }
        for (Node node4 = node; node4 != null; node4 = node4.getNextSibling()) {
            short nodeType = node4.getNodeType();
            if (nodeType == 5) {
                if (getWholeTextForward(node4.getFirstChild(), stringBuffer2, node4)) {
                    return true;
                }
            } else if (nodeType != 3 && nodeType != 4) {
                return true;
            } else {
                ((NodeImpl) node4).getTextContent(stringBuffer2);
            }
        }
        if (!z) {
            return false;
        }
        boolean wholeTextForward = getWholeTextForward(node3.getNextSibling(), stringBuffer2, node3.getParentNode());
        return true;
    }

    private boolean hasTextOnlyChildren(Node node) {
        Node node2 = node;
        if (node2 == null) {
            return false;
        }
        Node firstChild = node2.getFirstChild();
        while (true) {
            Node node3 = firstChild;
            if (node3 == null) {
                return true;
            }
            short nodeType = node3.getNodeType();
            if (nodeType == 5) {
                return hasTextOnlyChildren(node3);
            }
            if (nodeType != 3 && nodeType != 4 && nodeType != 5) {
                return false;
            }
            firstChild = node3.getNextSibling();
        }
    }

    public String getNodeName() {
        return "#text";
    }

    public short getNodeType() {
        return 3;
    }

    public String getWholeText() {
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        if (needsSyncData()) {
            synchronizeData();
        }
        new StringBuffer();
        StringBuffer stringBuffer3 = stringBuffer;
        if (!(this.data == null || this.data.length() == 0)) {
            StringBuffer append = stringBuffer3.append(this.data);
        }
        boolean wholeTextBackward = getWholeTextBackward(getPreviousSibling(), stringBuffer3, getParentNode());
        String stringBuffer4 = stringBuffer3.toString();
        stringBuffer3.setLength(0);
        boolean wholeTextForward = getWholeTextForward(getNextSibling(), stringBuffer3, getParentNode());
        new StringBuffer();
        return stringBuffer2.append(stringBuffer4).append(stringBuffer3.toString()).toString();
    }

    /* access modifiers changed from: protected */
    public void insertTextContent(StringBuffer stringBuffer) throws DOMException {
        StringBuffer stringBuffer2 = stringBuffer;
        String nodeValue = getNodeValue();
        if (nodeValue != null) {
            StringBuffer insert = stringBuffer2.insert(0, nodeValue);
        }
    }

    public boolean isElementContentWhitespace() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return internalIsIgnorableWhitespace();
    }

    public boolean isIgnorableWhitespace() {
        if (needsSyncData()) {
            synchronizeData();
        }
        return internalIsIgnorableWhitespace();
    }

    public String removeData() {
        String str = this.data;
        this.data = "";
        return str;
    }

    public void replaceData(String str) {
        String str2 = str;
        this.data = str2;
    }

    public Text replaceWholeText(String str) throws DOMException {
        Text text;
        Throwable th;
        Throwable th2;
        String str2 = str;
        if (needsSyncData()) {
            synchronizeData();
        }
        Node parentNode = getParentNode();
        if (str2 == null || str2.length() == 0) {
            if (parentNode != null) {
                Node removeChild = parentNode.removeChild(this);
            }
            return null;
        }
        if (ownerDocument().errorChecking) {
            if (!canModifyPrev(this)) {
                Throwable th3 = th2;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th3;
            } else if (!canModifyNext(this)) {
                Throwable th4 = th;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th4;
            }
        }
        if (isReadOnly()) {
            Text createTextNode = ownerDocument().createTextNode(str2);
            if (parentNode == null) {
                return createTextNode;
            }
            Node insertBefore = parentNode.insertBefore(createTextNode, this);
            Node removeChild2 = parentNode.removeChild(this);
            text = createTextNode;
        } else {
            setData(str2);
            text = this;
        }
        Node previousSibling = text.getPreviousSibling();
        while (true) {
            Node node = previousSibling;
            if (node != null && (node.getNodeType() == 3 || node.getNodeType() == 4 || (node.getNodeType() == 5 && hasTextOnlyChildren(node)))) {
                Node removeChild3 = parentNode.removeChild(node);
                previousSibling = text.getPreviousSibling();
            }
        }
        Node nextSibling = text.getNextSibling();
        while (true) {
            Node node2 = nextSibling;
            if (node2 != null && (node2.getNodeType() == 3 || node2.getNodeType() == 4 || (node2.getNodeType() == 5 && hasTextOnlyChildren(node2)))) {
                Node removeChild4 = parentNode.removeChild(node2);
                nextSibling = text.getNextSibling();
            }
        }
        return text;
    }

    public void setIgnorableWhitespace(boolean z) {
        boolean z2 = z;
        if (needsSyncData()) {
            synchronizeData();
        }
        isIgnorableWhitespace(z2);
    }

    public void setValues(CoreDocumentImpl coreDocumentImpl, String str) {
        this.flags = 0;
        this.nextSibling = null;
        this.previousSibling = null;
        setOwnerDocument(coreDocumentImpl);
        this.data = str;
    }

    public Text splitText(int i) throws DOMException {
        Throwable th;
        Throwable th2;
        int i2 = i;
        if (isReadOnly()) {
            Throwable th3 = th2;
            new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
            throw th3;
        }
        if (needsSyncData()) {
            synchronizeData();
        }
        if (i2 < 0 || i2 > this.data.length()) {
            Throwable th4 = th;
            new DOMException(1, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INDEX_SIZE_ERR", (Object[]) null));
            throw th4;
        }
        Text createTextNode = getOwnerDocument().createTextNode(this.data.substring(i2));
        setNodeValue(this.data.substring(0, i2));
        Node parentNode = getParentNode();
        if (parentNode != null) {
            Node insertBefore = parentNode.insertBefore(createTextNode, this.nextSibling);
        }
        return createTextNode;
    }
}
