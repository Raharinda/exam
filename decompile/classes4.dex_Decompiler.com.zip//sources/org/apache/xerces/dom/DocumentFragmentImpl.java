package org.apache.xerces.dom;

import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

public class DocumentFragmentImpl extends ParentNode implements DocumentFragment {
    static final long serialVersionUID = -7596449967279236746L;

    public DocumentFragmentImpl() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DocumentFragmentImpl(CoreDocumentImpl coreDocumentImpl) {
        super(coreDocumentImpl);
    }

    public String getNodeName() {
        return "#document-fragment";
    }

    public short getNodeType() {
        return 11;
    }

    public void normalize() {
        if (!isNormalized()) {
            if (needsSyncChildren()) {
                synchronizeChildren();
            }
            ChildNode childNode = this.firstChild;
            while (true) {
                ChildNode childNode2 = childNode;
                if (childNode2 == null) {
                    isNormalized(true);
                    return;
                }
                ChildNode childNode3 = childNode2.nextSibling;
                if (childNode2.getNodeType() == 3) {
                    if (childNode3 != null && childNode3.getNodeType() == 3) {
                        ((Text) childNode2).appendData(childNode3.getNodeValue());
                        Node removeChild = removeChild(childNode3);
                        childNode3 = childNode2;
                    } else if (childNode2.getNodeValue() == null || childNode2.getNodeValue().length() == 0) {
                        Node removeChild2 = removeChild(childNode2);
                    }
                }
                childNode2.normalize();
                childNode = childNode3;
            }
        }
    }
}
