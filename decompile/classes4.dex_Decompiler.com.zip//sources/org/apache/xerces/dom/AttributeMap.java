package org.apache.xerces.dom;

import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.DOMException;
import org.w3c.dom.Node;

public class AttributeMap extends NamedNodeMapImpl {
    static final long serialVersionUID = 8872606282138665383L;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected AttributeMap(ElementImpl elementImpl, NamedNodeMapImpl namedNodeMapImpl) {
        super(elementImpl);
        NamedNodeMapImpl namedNodeMapImpl2 = namedNodeMapImpl;
        if (namedNodeMapImpl2 != null) {
            cloneContent(namedNodeMapImpl2);
            if (this.nodes != null) {
                hasDefaults(true);
            }
        }
    }

    private final Node remove(AttrImpl attrImpl, int i, boolean z) {
        AttrImpl attrImpl2 = attrImpl;
        int i2 = i;
        boolean z2 = z;
        CoreDocumentImpl ownerDocument = this.ownerNode.ownerDocument();
        String nodeName = attrImpl2.getNodeName();
        if (attrImpl2.isIdAttribute()) {
            ownerDocument.removeIdentifier(attrImpl2.getValue());
        }
        if (!hasDefaults() || !z2) {
            Object remove = this.nodes.remove(i2);
        } else {
            NamedNodeMapImpl defaultAttributes = ((ElementImpl) this.ownerNode).getDefaultAttributes();
            if (defaultAttributes != null) {
                Node namedItem = defaultAttributes.getNamedItem(nodeName);
                Node node = namedItem;
                if (namedItem != null && findNamePoint(nodeName, i2 + 1) < 0) {
                    NodeImpl nodeImpl = (NodeImpl) node.cloneNode(true);
                    if (node.getLocalName() != null) {
                        ((AttrNSImpl) nodeImpl).namespaceURI = attrImpl2.getNamespaceURI();
                    }
                    nodeImpl.ownerNode = this.ownerNode;
                    nodeImpl.isOwned(true);
                    nodeImpl.isSpecified(false);
                    Object obj = this.nodes.set(i2, nodeImpl);
                    if (attrImpl2.isIdAttribute()) {
                        ownerDocument.putIdentifier(nodeImpl.getNodeValue(), (ElementImpl) this.ownerNode);
                    }
                }
            }
            Object remove2 = this.nodes.remove(i2);
        }
        attrImpl2.ownerNode = ownerDocument;
        attrImpl2.isOwned(false);
        attrImpl2.isSpecified(true);
        attrImpl2.isIdAttribute(false);
        ownerDocument.removedAttrNode(attrImpl2, this.ownerNode, nodeName);
        return attrImpl2;
    }

    /* access modifiers changed from: protected */
    public final int addItem(Node node) {
        List list;
        Node node2 = node;
        AttrImpl attrImpl = (AttrImpl) node2;
        attrImpl.ownerNode = this.ownerNode;
        attrImpl.isOwned(true);
        int findNamePoint = findNamePoint(attrImpl.getNamespaceURI(), attrImpl.getLocalName());
        if (findNamePoint >= 0) {
            Object obj = this.nodes.set(findNamePoint, node2);
        } else {
            findNamePoint = findNamePoint(attrImpl.getNodeName(), 0);
            if (findNamePoint >= 0) {
                this.nodes.add(findNamePoint, node2);
            } else {
                findNamePoint = -1 - findNamePoint;
                if (null == this.nodes) {
                    new ArrayList(5);
                    this.nodes = list;
                }
                this.nodes.add(findNamePoint, node2);
            }
        }
        this.ownerNode.ownerDocument().setAttrNode(attrImpl, (AttrImpl) null);
        return findNamePoint;
    }

    /* access modifiers changed from: protected */
    public void cloneContent(NamedNodeMapImpl namedNodeMapImpl) {
        int size;
        List list;
        List list2 = namedNodeMapImpl.nodes;
        if (list2 != null && (size = list2.size()) != 0) {
            if (this.nodes == null) {
                new ArrayList(size);
                this.nodes = list;
            } else {
                this.nodes.clear();
            }
            for (int i = 0; i < size; i++) {
                NodeImpl nodeImpl = (NodeImpl) list2.get(i);
                NodeImpl nodeImpl2 = (NodeImpl) nodeImpl.cloneNode(true);
                nodeImpl2.isSpecified(nodeImpl.isSpecified());
                boolean add = this.nodes.add(nodeImpl2);
                nodeImpl2.ownerNode = this.ownerNode;
                nodeImpl2.isOwned(true);
            }
        }
    }

    public NamedNodeMapImpl cloneMap(NodeImpl nodeImpl) {
        AttributeMap attributeMap;
        new AttributeMap((ElementImpl) nodeImpl, (NamedNodeMapImpl) null);
        AttributeMap attributeMap2 = attributeMap;
        attributeMap2.hasDefaults(hasDefaults());
        attributeMap2.cloneContent(this);
        return attributeMap2;
    }

    /* access modifiers changed from: protected */
    public final Node internalRemoveNamedItem(String str, boolean z) {
        Throwable th;
        Throwable th2;
        String str2 = str;
        boolean z2 = z;
        if (isReadOnly()) {
            Throwable th3 = th2;
            new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
            throw th3;
        }
        int findNamePoint = findNamePoint(str2, 0);
        if (findNamePoint >= 0) {
            return remove((AttrImpl) this.nodes.get(findNamePoint), findNamePoint, true);
        }
        if (!z2) {
            return null;
        }
        Throwable th4 = th;
        new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
        throw th4;
    }

    /* access modifiers changed from: protected */
    public final Node internalRemoveNamedItemNS(String str, String str2, boolean z) {
        Throwable th;
        Throwable th2;
        String str3 = str;
        String str4 = str2;
        boolean z2 = z;
        CoreDocumentImpl ownerDocument = this.ownerNode.ownerDocument();
        if (!ownerDocument.errorChecking || !isReadOnly()) {
            int findNamePoint = findNamePoint(str3, str4);
            if (findNamePoint >= 0) {
                AttrImpl attrImpl = (AttrImpl) this.nodes.get(findNamePoint);
                if (attrImpl.isIdAttribute()) {
                    ownerDocument.removeIdentifier(attrImpl.getValue());
                }
                String nodeName = attrImpl.getNodeName();
                if (hasDefaults()) {
                    NamedNodeMapImpl defaultAttributes = ((ElementImpl) this.ownerNode).getDefaultAttributes();
                    if (defaultAttributes != null) {
                        Node namedItem = defaultAttributes.getNamedItem(nodeName);
                        Node node = namedItem;
                        if (namedItem != null) {
                            int findNamePoint2 = findNamePoint(nodeName, 0);
                            if (findNamePoint2 < 0 || findNamePoint(nodeName, findNamePoint2 + 1) >= 0) {
                                Object remove = this.nodes.remove(findNamePoint);
                            } else {
                                NodeImpl nodeImpl = (NodeImpl) node.cloneNode(true);
                                nodeImpl.ownerNode = this.ownerNode;
                                if (node.getLocalName() != null) {
                                    ((AttrNSImpl) nodeImpl).namespaceURI = str3;
                                }
                                nodeImpl.isOwned(true);
                                nodeImpl.isSpecified(false);
                                Object obj = this.nodes.set(findNamePoint, nodeImpl);
                                if (nodeImpl.isIdAttribute()) {
                                    ownerDocument.putIdentifier(nodeImpl.getNodeValue(), (ElementImpl) this.ownerNode);
                                }
                            }
                        }
                    }
                    Object remove2 = this.nodes.remove(findNamePoint);
                } else {
                    Object remove3 = this.nodes.remove(findNamePoint);
                }
                attrImpl.ownerNode = ownerDocument;
                attrImpl.isOwned(false);
                attrImpl.isSpecified(true);
                attrImpl.isIdAttribute(false);
                ownerDocument.removedAttrNode(attrImpl, this.ownerNode, str4);
                return attrImpl;
            } else if (!z2) {
                return null;
            } else {
                Throwable th3 = th;
                new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
                throw th3;
            }
        } else {
            Throwable th4 = th2;
            new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
            throw th4;
        }
    }

    /* access modifiers changed from: package-private */
    public void moveSpecifiedAttributes(AttributeMap attributeMap) {
        AttributeMap attributeMap2 = attributeMap;
        for (int size = (attributeMap2.nodes != null ? attributeMap2.nodes.size() : 0) - 1; size >= 0; size--) {
            AttrImpl attrImpl = (AttrImpl) attributeMap2.nodes.get(size);
            if (attrImpl.isSpecified()) {
                Node remove = attributeMap2.remove(attrImpl, size, false);
                if (attrImpl.getLocalName() != null) {
                    Node namedItem = setNamedItem(attrImpl);
                } else {
                    Node namedItemNS = setNamedItemNS(attrImpl);
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void reconcileDefaults(NamedNodeMapImpl namedNodeMapImpl) {
        NamedNodeMapImpl namedNodeMapImpl2 = namedNodeMapImpl;
        for (int size = (this.nodes != null ? this.nodes.size() : 0) - 1; size >= 0; size--) {
            AttrImpl attrImpl = (AttrImpl) this.nodes.get(size);
            if (!attrImpl.isSpecified()) {
                Node remove = remove(attrImpl, size, false);
            }
        }
        if (namedNodeMapImpl2 != null) {
            if (this.nodes == null || this.nodes.size() == 0) {
                cloneContent(namedNodeMapImpl2);
                return;
            }
            int size2 = namedNodeMapImpl2.nodes.size();
            for (int i = 0; i < size2; i++) {
                AttrImpl attrImpl2 = (AttrImpl) namedNodeMapImpl2.nodes.get(i);
                int findNamePoint = findNamePoint(attrImpl2.getNodeName(), 0);
                if (findNamePoint < 0) {
                    NodeImpl nodeImpl = (NodeImpl) attrImpl2.cloneNode(true);
                    nodeImpl.ownerNode = this.ownerNode;
                    nodeImpl.isOwned(true);
                    nodeImpl.isSpecified(false);
                    this.nodes.add(-1 - findNamePoint, nodeImpl);
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public Node removeItem(Node node, boolean z) throws DOMException {
        Throwable th;
        Node node2 = node;
        boolean z2 = z;
        int i = -1;
        if (this.nodes != null) {
            int size = this.nodes.size();
            int i2 = 0;
            while (true) {
                if (i2 >= size) {
                    break;
                } else if (this.nodes.get(i2) == node2) {
                    i = i2;
                    break;
                } else {
                    i2++;
                }
            }
        }
        if (i >= 0) {
            return remove((AttrImpl) node2, i, z2);
        }
        Throwable th2 = th;
        new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NOT_FOUND_ERR", (Object[]) null));
        throw th2;
    }

    public Node removeNamedItem(String str) throws DOMException {
        return internalRemoveNamedItem(str, true);
    }

    public Node removeNamedItemNS(String str, String str2) throws DOMException {
        return internalRemoveNamedItemNS(str, str2, true);
    }

    /* access modifiers changed from: package-private */
    public Node safeRemoveNamedItem(String str) {
        return internalRemoveNamedItem(str, false);
    }

    /* access modifiers changed from: package-private */
    public Node safeRemoveNamedItemNS(String str, String str2) {
        return internalRemoveNamedItemNS(str, str2, false);
    }

    public Node setNamedItem(Node node) throws DOMException {
        List list;
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        Node node2 = node;
        boolean z = this.ownerNode.ownerDocument().errorChecking;
        if (z) {
            if (isReadOnly()) {
                Throwable th5 = th4;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th5;
            } else if (node2.getOwnerDocument() != this.ownerNode.ownerDocument()) {
                Throwable th6 = th3;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th6;
            } else if (node2.getNodeType() != 2) {
                Throwable th7 = th2;
                new DOMException(3, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "HIERARCHY_REQUEST_ERR", (Object[]) null));
                throw th7;
            }
        }
        AttrImpl attrImpl = (AttrImpl) node2;
        if (!attrImpl.isOwned()) {
            attrImpl.ownerNode = this.ownerNode;
            attrImpl.isOwned(true);
            int findNamePoint = findNamePoint(attrImpl.getNodeName(), 0);
            AttrImpl attrImpl2 = null;
            if (findNamePoint >= 0) {
                attrImpl2 = (AttrImpl) this.nodes.get(findNamePoint);
                Object obj = this.nodes.set(findNamePoint, node2);
                attrImpl2.ownerNode = this.ownerNode.ownerDocument();
                attrImpl2.isOwned(false);
                attrImpl2.isSpecified(true);
            } else {
                int i = -1 - findNamePoint;
                if (null == this.nodes) {
                    new ArrayList(5);
                    this.nodes = list;
                }
                this.nodes.add(i, node2);
            }
            this.ownerNode.ownerDocument().setAttrNode(attrImpl, attrImpl2);
            if (!attrImpl.isNormalized()) {
                this.ownerNode.isNormalized(false);
            }
            return attrImpl2;
        } else if (!z || attrImpl.getOwnerElement() == this.ownerNode) {
            return node2;
        } else {
            Throwable th8 = th;
            new DOMException(10, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INUSE_ATTRIBUTE_ERR", (Object[]) null));
            throw th8;
        }
    }

    public Node setNamedItemNS(Node node) throws DOMException {
        List list;
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        Node node2 = node;
        boolean z = this.ownerNode.ownerDocument().errorChecking;
        if (z) {
            if (isReadOnly()) {
                Throwable th5 = th4;
                new DOMException(7, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "NO_MODIFICATION_ALLOWED_ERR", (Object[]) null));
                throw th5;
            } else if (node2.getOwnerDocument() != this.ownerNode.ownerDocument()) {
                Throwable th6 = th3;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th6;
            } else if (node2.getNodeType() != 2) {
                Throwable th7 = th2;
                new DOMException(3, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "HIERARCHY_REQUEST_ERR", (Object[]) null));
                throw th7;
            }
        }
        AttrImpl attrImpl = (AttrImpl) node2;
        if (!attrImpl.isOwned()) {
            attrImpl.ownerNode = this.ownerNode;
            attrImpl.isOwned(true);
            int findNamePoint = findNamePoint(attrImpl.getNamespaceURI(), attrImpl.getLocalName());
            AttrImpl attrImpl2 = null;
            if (findNamePoint >= 0) {
                attrImpl2 = (AttrImpl) this.nodes.get(findNamePoint);
                Object obj = this.nodes.set(findNamePoint, node2);
                attrImpl2.ownerNode = this.ownerNode.ownerDocument();
                attrImpl2.isOwned(false);
                attrImpl2.isSpecified(true);
            } else {
                int findNamePoint2 = findNamePoint(node2.getNodeName(), 0);
                if (findNamePoint2 >= 0) {
                    attrImpl2 = (AttrImpl) this.nodes.get(findNamePoint2);
                    this.nodes.add(findNamePoint2, node2);
                } else {
                    int i = -1 - findNamePoint2;
                    if (null == this.nodes) {
                        new ArrayList(5);
                        this.nodes = list;
                    }
                    this.nodes.add(i, node2);
                }
            }
            this.ownerNode.ownerDocument().setAttrNode(attrImpl, attrImpl2);
            if (!attrImpl.isNormalized()) {
                this.ownerNode.isNormalized(false);
            }
            return attrImpl2;
        } else if (!z || attrImpl.getOwnerElement() == this.ownerNode) {
            return node2;
        } else {
            Throwable th8 = th;
            new DOMException(10, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INUSE_ATTRIBUTE_ERR", (Object[]) null));
            throw th8;
        }
    }
}
