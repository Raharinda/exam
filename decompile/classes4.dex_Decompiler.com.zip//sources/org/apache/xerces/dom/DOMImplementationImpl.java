package org.apache.xerces.dom;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.DocumentType;

public class DOMImplementationImpl extends CoreDOMImplementationImpl implements DOMImplementation {
    static final DOMImplementationImpl singleton;

    static {
        DOMImplementationImpl dOMImplementationImpl;
        new DOMImplementationImpl();
        singleton = dOMImplementationImpl;
    }

    public DOMImplementationImpl() {
    }

    public static DOMImplementation getDOMImplementation() {
        return singleton;
    }

    /* access modifiers changed from: protected */
    public CoreDocumentImpl createDocument(DocumentType documentType) {
        CoreDocumentImpl coreDocumentImpl;
        new DocumentImpl(documentType);
        return coreDocumentImpl;
    }

    public boolean hasFeature(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        boolean hasFeature = super.hasFeature(str3, str4);
        if (hasFeature) {
            return hasFeature;
        }
        boolean z = str4 == null || str4.length() == 0;
        if (str3.startsWith("+")) {
            str3 = str3.substring(1);
        }
        return (str3.equalsIgnoreCase("Events") && (z || str4.equals("2.0"))) || (str3.equalsIgnoreCase("MutationEvents") && (z || str4.equals("2.0"))) || ((str3.equalsIgnoreCase("Traversal") && (z || str4.equals("2.0"))) || ((str3.equalsIgnoreCase("Range") && (z || str4.equals("2.0"))) || (str3.equalsIgnoreCase("MutationEvents") && (z || str4.equals("2.0")))));
    }
}
