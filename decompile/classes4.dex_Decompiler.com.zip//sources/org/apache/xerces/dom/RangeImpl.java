package org.apache.xerces.dom;

import java.util.ArrayList;
import net.lingala.zip4j.util.Zip4jConstants;
import org.w3c.dom.CharacterData;
import org.w3c.dom.DOMException;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Node;
import org.w3c.dom.ranges.Range;
import org.w3c.dom.ranges.RangeException;

public class RangeImpl implements Range {
    static final int CLONE_CONTENTS = 2;
    static final int DELETE_CONTENTS = 3;
    static final int EXTRACT_CONTENTS = 1;
    private Node fDeleteNode = null;
    private boolean fDetach = false;
    private DocumentImpl fDocument;
    private Node fEndContainer;
    private int fEndOffset;
    private Node fInsertNode = null;
    private boolean fInsertedFromRange = false;
    private Node fRemoveChild = null;
    private Node fSplitNode = null;
    private Node fStartContainer;
    private int fStartOffset;

    public RangeImpl(DocumentImpl documentImpl) {
        DocumentImpl documentImpl2 = documentImpl;
        this.fDocument = documentImpl2;
        this.fStartContainer = documentImpl2;
        this.fEndContainer = documentImpl2;
        this.fStartOffset = 0;
        this.fEndOffset = 0;
        this.fDetach = false;
    }

    private Node getRootContainer(Node node) {
        Node node2 = node;
        if (node2 == null) {
            return null;
        }
        while (node2.getParentNode() != null) {
            node2 = node2.getParentNode();
        }
        return node2;
    }

    private Node getSelectedNode(Node node, int i) {
        Node node2;
        Node node3 = node;
        int i2 = i;
        if (node3.getNodeType() == 3) {
            return node3;
        }
        if (i2 < 0) {
            return node3;
        }
        Node firstChild = node3.getFirstChild();
        while (true) {
            node2 = firstChild;
            if (node2 != null && i2 > 0) {
                i2--;
                firstChild = node2.getNextSibling();
            }
        }
        return node2 != null ? node2 : node3;
    }

    private boolean hasLegalRootContainer(Node node) {
        Node node2 = node;
        if (node2 == null) {
            return false;
        }
        switch (getRootContainer(node2).getNodeType()) {
            case 2:
            case Zip4jConstants.DEFLATE_LEVEL_ULTRA:
            case 11:
                return true;
            default:
                return false;
        }
    }

    private boolean isLegalContainedNode(Node node) {
        Node node2 = node;
        if (node2 == null) {
            return false;
        }
        switch (node2.getNodeType()) {
            case 2:
            case 6:
            case Zip4jConstants.DEFLATE_LEVEL_ULTRA:
            case 11:
            case 12:
                return false;
            default:
                return true;
        }
    }

    private boolean isLegalContainer(Node node) {
        Node node2 = node;
        if (node2 == null) {
            return false;
        }
        while (node2 != null) {
            switch (node2.getNodeType()) {
                case 6:
                case 10:
                case 12:
                    return false;
                default:
                    node2 = node2.getParentNode();
            }
        }
        return true;
    }

    private Node traverseCharacterDataNode(Node node, boolean z, int i) {
        String substring;
        String substring2;
        Node node2 = node;
        int i2 = i;
        String nodeValue = node2.getNodeValue();
        if (z) {
            int startOffset = getStartOffset();
            substring = nodeValue.substring(startOffset);
            substring2 = nodeValue.substring(0, startOffset);
        } else {
            int endOffset = getEndOffset();
            substring = nodeValue.substring(0, endOffset);
            substring2 = nodeValue.substring(endOffset);
        }
        if (i2 != 2) {
            node2.setNodeValue(substring2);
        }
        if (i2 == 3) {
            return null;
        }
        Node cloneNode = node2.cloneNode(false);
        cloneNode.setNodeValue(substring);
        return cloneNode;
    }

    private DocumentFragment traverseCommonAncestors(Node node, Node node2, int i) {
        Node node3 = node;
        Node node4 = node2;
        int i2 = i;
        DocumentFragment documentFragment = null;
        if (i2 != 3) {
            documentFragment = this.fDocument.createDocumentFragment();
        }
        Node traverseLeftBoundary = traverseLeftBoundary(node3, i2);
        if (documentFragment != null) {
            Node appendChild = documentFragment.appendChild(traverseLeftBoundary);
        }
        Node parentNode = node3.getParentNode();
        Node nextSibling = node3.getNextSibling();
        for (int indexOf = indexOf(node4, parentNode) - (indexOf(node3, parentNode) + 1); indexOf > 0; indexOf--) {
            Node nextSibling2 = nextSibling.getNextSibling();
            Node traverseFullySelected = traverseFullySelected(nextSibling, i2);
            if (documentFragment != null) {
                Node appendChild2 = documentFragment.appendChild(traverseFullySelected);
            }
            nextSibling = nextSibling2;
        }
        Node traverseRightBoundary = traverseRightBoundary(node4, i2);
        if (documentFragment != null) {
            Node appendChild3 = documentFragment.appendChild(traverseRightBoundary);
        }
        if (i2 != 2) {
            setStartAfter(node3);
            collapse(true);
        }
        return documentFragment;
    }

    private DocumentFragment traverseCommonEndContainer(Node node, int i) {
        Node node2 = node;
        int i2 = i;
        DocumentFragment documentFragment = null;
        if (i2 != 3) {
            documentFragment = this.fDocument.createDocumentFragment();
        }
        Node traverseLeftBoundary = traverseLeftBoundary(node2, i2);
        if (documentFragment != null) {
            Node appendChild = documentFragment.appendChild(traverseLeftBoundary);
        }
        int indexOf = this.fEndOffset - (indexOf(node2, this.fEndContainer) + 1);
        Node nextSibling = node2.getNextSibling();
        while (true) {
            Node node3 = nextSibling;
            if (indexOf <= 0) {
                break;
            }
            Node nextSibling2 = node3.getNextSibling();
            Node traverseFullySelected = traverseFullySelected(node3, i2);
            if (documentFragment != null) {
                Node appendChild2 = documentFragment.appendChild(traverseFullySelected);
            }
            indexOf--;
            nextSibling = nextSibling2;
        }
        if (i2 != 2) {
            setStartAfter(node2);
            collapse(true);
        }
        return documentFragment;
    }

    private DocumentFragment traverseCommonStartContainer(Node node, int i) {
        Node node2 = node;
        int i2 = i;
        DocumentFragment documentFragment = null;
        if (i2 != 3) {
            documentFragment = this.fDocument.createDocumentFragment();
        }
        Node traverseRightBoundary = traverseRightBoundary(node2, i2);
        if (documentFragment != null) {
            Node appendChild = documentFragment.appendChild(traverseRightBoundary);
        }
        int indexOf = indexOf(node2, this.fStartContainer) - this.fStartOffset;
        if (indexOf <= 0) {
            if (i2 != 2) {
                setEndBefore(node2);
                collapse(false);
            }
            return documentFragment;
        }
        Node previousSibling = node2.getPreviousSibling();
        while (true) {
            Node node3 = previousSibling;
            if (indexOf <= 0) {
                break;
            }
            Node previousSibling2 = node3.getPreviousSibling();
            Node traverseFullySelected = traverseFullySelected(node3, i2);
            if (documentFragment != null) {
                Node insertBefore = documentFragment.insertBefore(traverseFullySelected, documentFragment.getFirstChild());
            }
            indexOf--;
            previousSibling = previousSibling2;
        }
        if (i2 != 2) {
            setEndBefore(node2);
            collapse(false);
        }
        return documentFragment;
    }

    private DocumentFragment traverseContents(int i) throws DOMException {
        Throwable th;
        int i2 = i;
        if (this.fStartContainer == null || this.fEndContainer == null) {
            return null;
        }
        if (this.fDetach) {
            Throwable th2 = th;
            new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
            throw th2;
        } else if (this.fStartContainer == this.fEndContainer) {
            return traverseSameContainer(i2);
        } else {
            int i3 = 0;
            Node node = this.fEndContainer;
            Node parentNode = node.getParentNode();
            while (true) {
                Node node2 = parentNode;
                if (node2 == null) {
                    int i4 = 0;
                    Node node3 = this.fStartContainer;
                    Node parentNode2 = node3.getParentNode();
                    while (true) {
                        Node node4 = parentNode2;
                        if (node4 == null) {
                            int i5 = i4 - i3;
                            Node node5 = this.fStartContainer;
                            while (i5 > 0) {
                                node5 = node5.getParentNode();
                                i5--;
                            }
                            Node node6 = this.fEndContainer;
                            while (i5 < 0) {
                                node6 = node6.getParentNode();
                                i5++;
                            }
                            Node parentNode3 = node5.getParentNode();
                            Node parentNode4 = node6.getParentNode();
                            while (true) {
                                Node node7 = parentNode4;
                                if (parentNode3 == node7) {
                                    return traverseCommonAncestors(node5, node6, i2);
                                }
                                node5 = parentNode3;
                                node6 = node7;
                                parentNode3 = parentNode3.getParentNode();
                                parentNode4 = node7.getParentNode();
                            }
                        } else if (node4 == this.fEndContainer) {
                            return traverseCommonEndContainer(node3, i2);
                        } else {
                            i4++;
                            node3 = node4;
                            parentNode2 = node4.getParentNode();
                        }
                    }
                } else if (node2 == this.fStartContainer) {
                    return traverseCommonStartContainer(node, i2);
                } else {
                    i3++;
                    node = node2;
                    parentNode = node2.getParentNode();
                }
            }
        }
    }

    private Node traverseFullySelected(Node node, int i) {
        Throwable th;
        Node node2 = node;
        switch (i) {
            case 1:
                if (node2.getNodeType() != 10) {
                    return node2;
                }
                Throwable th2 = th;
                new DOMException(3, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "HIERARCHY_REQUEST_ERR", (Object[]) null));
                throw th2;
            case 2:
                return node2.cloneNode(true);
            case 3:
                Node removeChild = node2.getParentNode().removeChild(node2);
                return null;
            default:
                return null;
        }
    }

    private Node traverseLeftBoundary(Node node, int i) {
        Node node2 = node;
        int i2 = i;
        Node selectedNode = getSelectedNode(getStartContainer(), getStartOffset());
        boolean z = selectedNode != getStartContainer();
        if (selectedNode == node2) {
            return traverseNode(selectedNode, z, true, i2);
        }
        Node parentNode = selectedNode.getParentNode();
        Node traverseNode = traverseNode(parentNode, false, true, i2);
        while (true) {
            Node node3 = traverseNode;
            if (parentNode == null) {
                return null;
            }
            while (selectedNode != null) {
                Node nextSibling = selectedNode.getNextSibling();
                Node traverseNode2 = traverseNode(selectedNode, z, true, i2);
                if (i2 != 3) {
                    Node appendChild = node3.appendChild(traverseNode2);
                }
                z = true;
                selectedNode = nextSibling;
            }
            if (parentNode == node2) {
                return node3;
            }
            selectedNode = parentNode.getNextSibling();
            parentNode = parentNode.getParentNode();
            Node traverseNode3 = traverseNode(parentNode, false, true, i2);
            if (i2 != 3) {
                Node appendChild2 = traverseNode3.appendChild(node3);
            }
            traverseNode = traverseNode3;
        }
    }

    private Node traverseNode(Node node, boolean z, boolean z2, int i) {
        Node node2 = node;
        boolean z3 = z2;
        int i2 = i;
        if (z) {
            return traverseFullySelected(node2, i2);
        }
        short nodeType = node2.getNodeType();
        return (nodeType == 3 || nodeType == 4 || nodeType == 8 || nodeType == 7) ? traverseCharacterDataNode(node2, z3, i2) : traversePartiallySelected(node2, i2);
    }

    private Node traversePartiallySelected(Node node, int i) {
        Node node2 = node;
        switch (i) {
            case 1:
            case 2:
                return node2.cloneNode(false);
            case 3:
                return null;
            default:
                return null;
        }
    }

    private Node traverseRightBoundary(Node node, int i) {
        Node node2 = node;
        int i2 = i;
        Node selectedNode = getSelectedNode(this.fEndContainer, this.fEndOffset - 1);
        boolean z = selectedNode != this.fEndContainer;
        if (selectedNode == node2) {
            return traverseNode(selectedNode, z, false, i2);
        }
        Node parentNode = selectedNode.getParentNode();
        Node traverseNode = traverseNode(parentNode, false, false, i2);
        while (true) {
            Node node3 = traverseNode;
            if (parentNode == null) {
                return null;
            }
            while (selectedNode != null) {
                Node previousSibling = selectedNode.getPreviousSibling();
                Node traverseNode2 = traverseNode(selectedNode, z, false, i2);
                if (i2 != 3) {
                    Node insertBefore = node3.insertBefore(traverseNode2, node3.getFirstChild());
                }
                z = true;
                selectedNode = previousSibling;
            }
            if (parentNode == node2) {
                return node3;
            }
            selectedNode = parentNode.getPreviousSibling();
            parentNode = parentNode.getParentNode();
            Node traverseNode3 = traverseNode(parentNode, false, false, i2);
            if (i2 != 3) {
                Node appendChild = traverseNode3.appendChild(node3);
            }
            traverseNode = traverseNode3;
        }
    }

    private DocumentFragment traverseSameContainer(int i) {
        int i2 = i;
        DocumentFragment documentFragment = null;
        if (i2 != 3) {
            documentFragment = this.fDocument.createDocumentFragment();
        }
        if (this.fStartOffset == this.fEndOffset) {
            return documentFragment;
        }
        short nodeType = this.fStartContainer.getNodeType();
        if (nodeType == 3 || nodeType == 4 || nodeType == 8 || nodeType == 7) {
            String substring = this.fStartContainer.getNodeValue().substring(this.fStartOffset, this.fEndOffset);
            if (i2 != 2) {
                ((CharacterDataImpl) this.fStartContainer).deleteData(this.fStartOffset, this.fEndOffset - this.fStartOffset);
                collapse(true);
            }
            if (i2 == 3) {
                return null;
            }
            if (nodeType == 3) {
                Node appendChild = documentFragment.appendChild(this.fDocument.createTextNode(substring));
            } else if (nodeType == 4) {
                Node appendChild2 = documentFragment.appendChild(this.fDocument.createCDATASection(substring));
            } else if (nodeType == 8) {
                Node appendChild3 = documentFragment.appendChild(this.fDocument.createComment(substring));
            } else {
                Node appendChild4 = documentFragment.appendChild(this.fDocument.createProcessingInstruction(this.fStartContainer.getNodeName(), substring));
            }
            return documentFragment;
        }
        Node selectedNode = getSelectedNode(this.fStartContainer, this.fStartOffset);
        int i3 = this.fEndOffset - this.fStartOffset;
        while (i3 > 0) {
            Node nextSibling = selectedNode.getNextSibling();
            Node traverseFullySelected = traverseFullySelected(selectedNode, i2);
            if (documentFragment != null) {
                Node appendChild5 = documentFragment.appendChild(traverseFullySelected);
            }
            i3--;
            selectedNode = nextSibling;
        }
        if (i2 != 2) {
            collapse(true);
        }
        return documentFragment;
    }

    /* access modifiers changed from: package-private */
    public void checkIndex(Node node, int i) throws DOMException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Node node2 = node;
        int i2 = i;
        if (i2 < 0) {
            Throwable th4 = th3;
            new DOMException(1, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INDEX_SIZE_ERR", (Object[]) null));
            throw th4;
        }
        short nodeType = node2.getNodeType();
        if (nodeType == 3 || nodeType == 4 || nodeType == 8 || nodeType == 7) {
            if (i2 > node2.getNodeValue().length()) {
                Throwable th5 = th;
                new DOMException(1, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INDEX_SIZE_ERR", (Object[]) null));
                throw th5;
            }
        } else if (i2 > node2.getChildNodes().getLength()) {
            Throwable th6 = th2;
            new DOMException(1, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INDEX_SIZE_ERR", (Object[]) null));
            throw th6;
        }
    }

    public DocumentFragment cloneContents() throws DOMException {
        return traverseContents(2);
    }

    public Range cloneRange() {
        Throwable th;
        if (this.fDetach) {
            Throwable th2 = th;
            new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
            throw th2;
        }
        Range createRange = this.fDocument.createRange();
        createRange.setStart(this.fStartContainer, this.fStartOffset);
        createRange.setEnd(this.fEndContainer, this.fEndOffset);
        return createRange;
    }

    public void collapse(boolean z) {
        Throwable th;
        boolean z2 = z;
        if (this.fDetach) {
            Throwable th2 = th;
            new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
            throw th2;
        } else if (z2) {
            this.fEndContainer = this.fStartContainer;
            this.fEndOffset = this.fStartOffset;
        } else {
            this.fStartContainer = this.fEndContainer;
            this.fStartOffset = this.fEndOffset;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x006c, code lost:
        if (r4.getStartContainer() != null) goto L_0x00a2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x00a0, code lost:
        if (r4.getStartContainer() != null) goto L_0x00a2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x00a2, code lost:
        r19 = r25;
        new org.w3c.dom.DOMException(4, org.apache.xerces.dom.DOMMessageFormatter.formatMessage(org.apache.xerces.dom.DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (java.lang.Object[]) null));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x00bb, code lost:
        throw r19;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public short compareBoundaryPoints(short r27, org.w3c.dom.ranges.Range r28) throws org.w3c.dom.DOMException {
        /*
            r26 = this;
            r2 = r26
            r3 = r27
            r4 = r28
            r19 = r2
            r0 = r19
            org.apache.xerces.dom.DocumentImpl r0 = r0.fDocument
            r19 = r0
            r0 = r19
            boolean r0 = r0.errorChecking
            r19 = r0
            if (r19 == 0) goto L_0x00bc
            r19 = r2
            r0 = r19
            boolean r0 = r0.fDetach
            r19 = r0
            if (r19 == 0) goto L_0x003a
            org.w3c.dom.DOMException r19 = new org.w3c.dom.DOMException
            r25 = r19
            r19 = r25
            r20 = r25
            r21 = 11
            java.lang.String r22 = "http://www.w3.org/dom/DOMTR"
            java.lang.String r23 = "INVALID_STATE_ERR"
            r24 = 0
            java.lang.String r22 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r22, r23, r24)
            r20.<init>(r21, r22)
            throw r19
        L_0x003a:
            r19 = r2
            r0 = r19
            org.apache.xerces.dom.DocumentImpl r0 = r0.fDocument
            r19 = r0
            r20 = r4
            org.w3c.dom.Node r20 = r20.getStartContainer()
            org.w3c.dom.Document r20 = r20.getOwnerDocument()
            r0 = r19
            r1 = r20
            if (r0 == r1) goto L_0x006e
            r19 = r2
            r0 = r19
            org.apache.xerces.dom.DocumentImpl r0 = r0.fDocument
            r19 = r0
            r20 = r4
            org.w3c.dom.Node r20 = r20.getStartContainer()
            r0 = r19
            r1 = r20
            if (r0 == r1) goto L_0x006e
            r19 = r4
            org.w3c.dom.Node r19 = r19.getStartContainer()
            if (r19 != 0) goto L_0x00a2
        L_0x006e:
            r19 = r2
            r0 = r19
            org.apache.xerces.dom.DocumentImpl r0 = r0.fDocument
            r19 = r0
            r20 = r4
            org.w3c.dom.Node r20 = r20.getEndContainer()
            org.w3c.dom.Document r20 = r20.getOwnerDocument()
            r0 = r19
            r1 = r20
            if (r0 == r1) goto L_0x00bc
            r19 = r2
            r0 = r19
            org.apache.xerces.dom.DocumentImpl r0 = r0.fDocument
            r19 = r0
            r20 = r4
            org.w3c.dom.Node r20 = r20.getEndContainer()
            r0 = r19
            r1 = r20
            if (r0 == r1) goto L_0x00bc
            r19 = r4
            org.w3c.dom.Node r19 = r19.getStartContainer()
            if (r19 == 0) goto L_0x00bc
        L_0x00a2:
            org.w3c.dom.DOMException r19 = new org.w3c.dom.DOMException
            r25 = r19
            r19 = r25
            r20 = r25
            r21 = 4
            java.lang.String r22 = "http://www.w3.org/dom/DOMTR"
            java.lang.String r23 = "WRONG_DOCUMENT_ERR"
            r24 = 0
            java.lang.String r22 = org.apache.xerces.dom.DOMMessageFormatter.formatMessage(r22, r23, r24)
            r20.<init>(r21, r22)
            throw r19
        L_0x00bc:
            r19 = r3
            if (r19 != 0) goto L_0x00fd
            r19 = r4
            org.w3c.dom.Node r19 = r19.getStartContainer()
            r5 = r19
            r19 = r2
            r0 = r19
            org.w3c.dom.Node r0 = r0.fStartContainer
            r19 = r0
            r6 = r19
            r19 = r4
            int r19 = r19.getStartOffset()
            r7 = r19
            r19 = r2
            r0 = r19
            int r0 = r0.fStartOffset
            r19 = r0
            r8 = r19
        L_0x00e4:
            r19 = r5
            r20 = r6
            r0 = r19
            r1 = r20
            if (r0 != r1) goto L_0x0197
            r19 = r7
            r20 = r8
            r0 = r19
            r1 = r20
            if (r0 >= r1) goto L_0x0181
            r19 = 1
            r2 = r19
        L_0x00fc:
            return r2
        L_0x00fd:
            r19 = r3
            r20 = 1
            r0 = r19
            r1 = r20
            if (r0 != r1) goto L_0x012c
            r19 = r4
            org.w3c.dom.Node r19 = r19.getStartContainer()
            r5 = r19
            r19 = r2
            r0 = r19
            org.w3c.dom.Node r0 = r0.fEndContainer
            r19 = r0
            r6 = r19
            r19 = r4
            int r19 = r19.getStartOffset()
            r7 = r19
            r19 = r2
            r0 = r19
            int r0 = r0.fEndOffset
            r19 = r0
            r8 = r19
            goto L_0x00e4
        L_0x012c:
            r19 = r3
            r20 = 3
            r0 = r19
            r1 = r20
            if (r0 != r1) goto L_0x015b
            r19 = r4
            org.w3c.dom.Node r19 = r19.getEndContainer()
            r5 = r19
            r19 = r2
            r0 = r19
            org.w3c.dom.Node r0 = r0.fStartContainer
            r19 = r0
            r6 = r19
            r19 = r4
            int r19 = r19.getEndOffset()
            r7 = r19
            r19 = r2
            r0 = r19
            int r0 = r0.fStartOffset
            r19 = r0
            r8 = r19
            goto L_0x00e4
        L_0x015b:
            r19 = r4
            org.w3c.dom.Node r19 = r19.getEndContainer()
            r5 = r19
            r19 = r2
            r0 = r19
            org.w3c.dom.Node r0 = r0.fEndContainer
            r19 = r0
            r6 = r19
            r19 = r4
            int r19 = r19.getEndOffset()
            r7 = r19
            r19 = r2
            r0 = r19
            int r0 = r0.fEndOffset
            r19 = r0
            r8 = r19
            goto L_0x00e4
        L_0x0181:
            r19 = r7
            r20 = r8
            r0 = r19
            r1 = r20
            if (r0 != r1) goto L_0x0191
            r19 = 0
            r2 = r19
            goto L_0x00fc
        L_0x0191:
            r19 = -1
            r2 = r19
            goto L_0x00fc
        L_0x0197:
            r19 = r6
            r9 = r19
            r19 = r9
            org.w3c.dom.Node r19 = r19.getParentNode()
            r10 = r19
        L_0x01a3:
            r19 = r10
            if (r19 != 0) goto L_0x01ff
            r19 = r5
            r11 = r19
            r19 = r11
            org.w3c.dom.Node r19 = r19.getParentNode()
            r12 = r19
        L_0x01b3:
            r19 = r12
            if (r19 != 0) goto L_0x0239
            r19 = 0
            r13 = r19
            r19 = r5
            r14 = r19
        L_0x01bf:
            r19 = r14
            if (r19 != 0) goto L_0x0273
            r19 = r6
            r15 = r19
        L_0x01c7:
            r19 = r15
            if (r19 != 0) goto L_0x027f
        L_0x01cb:
            r19 = r13
            if (r19 > 0) goto L_0x028b
        L_0x01cf:
            r19 = r13
            if (r19 < 0) goto L_0x0297
            r19 = r5
            org.w3c.dom.Node r19 = r19.getParentNode()
            r16 = r19
            r19 = r6
            org.w3c.dom.Node r19 = r19.getParentNode()
            r17 = r19
        L_0x01e3:
            r19 = r16
            r20 = r17
            r0 = r19
            r1 = r20
            if (r0 != r1) goto L_0x02a3
            r19 = r5
            org.w3c.dom.Node r19 = r19.getNextSibling()
            r18 = r19
        L_0x01f5:
            r19 = r18
            if (r19 != 0) goto L_0x02bd
            r19 = -1
            r2 = r19
            goto L_0x00fc
        L_0x01ff:
            r19 = r10
            r20 = r5
            r0 = r19
            r1 = r20
            if (r0 != r1) goto L_0x022b
            r19 = r2
            r20 = r9
            r21 = r5
            int r19 = r19.indexOf(r20, r21)
            r11 = r19
            r19 = r7
            r20 = r11
            r0 = r19
            r1 = r20
            if (r0 > r1) goto L_0x0225
            r19 = 1
            r2 = r19
            goto L_0x00fc
        L_0x0225:
            r19 = -1
            r2 = r19
            goto L_0x00fc
        L_0x022b:
            r19 = r10
            r9 = r19
            r19 = r10
            org.w3c.dom.Node r19 = r19.getParentNode()
            r10 = r19
            goto L_0x01a3
        L_0x0239:
            r19 = r12
            r20 = r6
            r0 = r19
            r1 = r20
            if (r0 != r1) goto L_0x0265
            r19 = r2
            r20 = r11
            r21 = r6
            int r19 = r19.indexOf(r20, r21)
            r13 = r19
            r19 = r13
            r20 = r8
            r0 = r19
            r1 = r20
            if (r0 >= r1) goto L_0x025f
            r19 = 1
            r2 = r19
            goto L_0x00fc
        L_0x025f:
            r19 = -1
            r2 = r19
            goto L_0x00fc
        L_0x0265:
            r19 = r12
            r11 = r19
            r19 = r12
            org.w3c.dom.Node r19 = r19.getParentNode()
            r12 = r19
            goto L_0x01b3
        L_0x0273:
            int r13 = r13 + 1
            r19 = r14
            org.w3c.dom.Node r19 = r19.getParentNode()
            r14 = r19
            goto L_0x01bf
        L_0x027f:
            int r13 = r13 + -1
            r19 = r15
            org.w3c.dom.Node r19 = r19.getParentNode()
            r15 = r19
            goto L_0x01c7
        L_0x028b:
            r19 = r5
            org.w3c.dom.Node r19 = r19.getParentNode()
            r5 = r19
            int r13 = r13 + -1
            goto L_0x01cb
        L_0x0297:
            r19 = r6
            org.w3c.dom.Node r19 = r19.getParentNode()
            r6 = r19
            int r13 = r13 + 1
            goto L_0x01cf
        L_0x02a3:
            r19 = r16
            r5 = r19
            r19 = r17
            r6 = r19
            r19 = r16
            org.w3c.dom.Node r19 = r19.getParentNode()
            r16 = r19
            r19 = r17
            org.w3c.dom.Node r19 = r19.getParentNode()
            r17 = r19
            goto L_0x01e3
        L_0x02bd:
            r19 = r18
            r20 = r6
            r0 = r19
            r1 = r20
            if (r0 != r1) goto L_0x02cd
            r19 = 1
            r2 = r19
            goto L_0x00fc
        L_0x02cd:
            r19 = r18
            org.w3c.dom.Node r19 = r19.getNextSibling()
            r18 = r19
            goto L_0x01f5
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.dom.RangeImpl.compareBoundaryPoints(short, org.w3c.dom.ranges.Range):short");
    }

    public void deleteContents() throws DOMException {
        DocumentFragment traverseContents = traverseContents(3);
    }

    /* access modifiers changed from: package-private */
    public void deleteData(CharacterData characterData, int i, int i2) {
        CharacterData characterData2 = characterData;
        this.fDeleteNode = characterData2;
        characterData2.deleteData(i, i2);
        this.fDeleteNode = null;
    }

    public void detach() {
        Throwable th;
        if (this.fDetach) {
            Throwable th2 = th;
            new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
            throw th2;
        }
        this.fDetach = true;
        this.fDocument.removeRange(this);
    }

    public DocumentFragment extractContents() throws DOMException {
        return traverseContents(1);
    }

    public boolean getCollapsed() {
        Throwable th;
        if (this.fDetach) {
            Throwable th2 = th;
            new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
            throw th2;
        }
        return this.fStartContainer == this.fEndContainer && this.fStartOffset == this.fEndOffset;
    }

    public Node getCommonAncestorContainer() {
        ArrayList arrayList;
        ArrayList arrayList2;
        Throwable th;
        if (this.fDetach) {
            Throwable th2 = th;
            new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
            throw th2;
        }
        new ArrayList();
        ArrayList arrayList3 = arrayList;
        Node node = this.fStartContainer;
        while (true) {
            Node node2 = node;
            if (node2 == null) {
                break;
            }
            boolean add = arrayList3.add(node2);
            node = node2.getParentNode();
        }
        new ArrayList();
        ArrayList arrayList4 = arrayList2;
        Node node3 = this.fEndContainer;
        while (true) {
            Node node4 = node3;
            if (node4 == null) {
                break;
            }
            boolean add2 = arrayList4.add(node4);
            node3 = node4.getParentNode();
        }
        int size = arrayList3.size() - 1;
        int size2 = arrayList4.size() - 1;
        Object obj = null;
        while (size >= 0 && size2 >= 0 && arrayList3.get(size) == arrayList4.get(size2)) {
            obj = arrayList3.get(size);
            size--;
            size2--;
        }
        return (Node) obj;
    }

    public Node getEndContainer() {
        Throwable th;
        if (!this.fDetach) {
            return this.fEndContainer;
        }
        Throwable th2 = th;
        new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
        throw th2;
    }

    public int getEndOffset() {
        Throwable th;
        if (!this.fDetach) {
            return this.fEndOffset;
        }
        Throwable th2 = th;
        new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
        throw th2;
    }

    public Node getStartContainer() {
        Throwable th;
        if (!this.fDetach) {
            return this.fStartContainer;
        }
        Throwable th2 = th;
        new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
        throw th2;
    }

    public int getStartOffset() {
        Throwable th;
        if (!this.fDetach) {
            return this.fStartOffset;
        }
        Throwable th2 = th;
        new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
        throw th2;
    }

    /* access modifiers changed from: package-private */
    public int indexOf(Node node, Node node2) {
        Node node3 = node;
        Node node4 = node2;
        if (node3.getParentNode() != node4) {
            return -1;
        }
        int i = 0;
        Node firstChild = node4.getFirstChild();
        while (true) {
            Node node5 = firstChild;
            if (node5 == node3) {
                return i;
            }
            i++;
            firstChild = node5.getNextSibling();
        }
    }

    /* access modifiers changed from: package-private */
    public void insertData(CharacterData characterData, int i, String str) {
        CharacterData characterData2 = characterData;
        this.fInsertNode = characterData2;
        characterData2.insertData(i, str);
        this.fInsertNode = null;
    }

    public void insertNode(Node node) throws DOMException, RangeException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Node node2 = node;
        if (node2 != null) {
            short nodeType = node2.getNodeType();
            if (this.fDocument.errorChecking) {
                if (this.fDetach) {
                    Throwable th4 = th3;
                    new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
                    throw th4;
                } else if (this.fDocument != node2.getOwnerDocument()) {
                    Throwable th5 = th2;
                    new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                    throw th5;
                } else if (nodeType == 2 || nodeType == 6 || nodeType == 12 || nodeType == 9) {
                    Throwable th6 = th;
                    new RangeExceptionImpl(2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_NODE_TYPE_ERR", (Object[]) null));
                    throw th6;
                }
            }
            int i = 0;
            this.fInsertedFromRange = true;
            if (this.fStartContainer.getNodeType() == 3) {
                Node parentNode = this.fStartContainer.getParentNode();
                int length = parentNode.getChildNodes().getLength();
                Node cloneNode = this.fStartContainer.cloneNode(false);
                ((TextImpl) cloneNode).setNodeValueInternal(cloneNode.getNodeValue().substring(this.fStartOffset));
                ((TextImpl) this.fStartContainer).setNodeValueInternal(this.fStartContainer.getNodeValue().substring(0, this.fStartOffset));
                Node nextSibling = this.fStartContainer.getNextSibling();
                if (nextSibling != null) {
                    if (parentNode != null) {
                        Node insertBefore = parentNode.insertBefore(node2, nextSibling);
                        Node insertBefore2 = parentNode.insertBefore(cloneNode, nextSibling);
                    }
                } else if (parentNode != null) {
                    Node appendChild = parentNode.appendChild(node2);
                    Node appendChild2 = parentNode.appendChild(cloneNode);
                }
                if (this.fEndContainer == this.fStartContainer) {
                    this.fEndContainer = cloneNode;
                    this.fEndOffset -= this.fStartOffset;
                } else if (this.fEndContainer == parentNode) {
                    this.fEndOffset += parentNode.getChildNodes().getLength() - length;
                }
                signalSplitData(this.fStartContainer, cloneNode, this.fStartOffset);
            } else {
                if (this.fEndContainer == this.fStartContainer) {
                    i = this.fEndContainer.getChildNodes().getLength();
                }
                Node firstChild = this.fStartContainer.getFirstChild();
                for (int i2 = 0; i2 < this.fStartOffset && firstChild != null; i2++) {
                    firstChild = firstChild.getNextSibling();
                }
                if (firstChild != null) {
                    Node insertBefore3 = this.fStartContainer.insertBefore(node2, firstChild);
                } else {
                    Node appendChild3 = this.fStartContainer.appendChild(node2);
                }
                if (this.fEndContainer == this.fStartContainer && this.fEndOffset != 0) {
                    this.fEndOffset += this.fEndContainer.getChildNodes().getLength() - i;
                }
            }
            this.fInsertedFromRange = false;
        }
    }

    public void insertedNodeFromDOM(Node node) {
        Node node2 = node;
        if (node2 != null && this.fInsertNode != node2 && !this.fInsertedFromRange) {
            Node parentNode = node2.getParentNode();
            if (parentNode == this.fStartContainer && indexOf(node2, this.fStartContainer) < this.fStartOffset) {
                this.fStartOffset++;
            }
            if (parentNode == this.fEndContainer && indexOf(node2, this.fEndContainer) < this.fEndOffset) {
                this.fEndOffset++;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public boolean isAncestorOf(Node node, Node node2) {
        Node node3 = node;
        Node node4 = node2;
        while (true) {
            Node node5 = node4;
            if (node5 == null) {
                return false;
            }
            if (node5 == node3) {
                return true;
            }
            node4 = node5.getParentNode();
        }
    }

    /* access modifiers changed from: package-private */
    public Node nextNode(Node node, boolean z) {
        Node firstChild;
        Node node2 = node;
        boolean z2 = z;
        if (node2 == null) {
            return null;
        }
        if (z2 && (firstChild = node2.getFirstChild()) != null) {
            return firstChild;
        }
        Node nextSibling = node2.getNextSibling();
        if (nextSibling != null) {
            return nextSibling;
        }
        Node parentNode = node2.getParentNode();
        while (true) {
            Node node3 = parentNode;
            if (node3 != null && node3 != this.fDocument) {
                Node nextSibling2 = node3.getNextSibling();
                if (nextSibling2 != null) {
                    return nextSibling2;
                }
                parentNode = node3.getParentNode();
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public void receiveDeletedText(CharacterDataImpl characterDataImpl, int i, int i2) {
        CharacterDataImpl characterDataImpl2 = characterDataImpl;
        int i3 = i;
        int i4 = i2;
        if (characterDataImpl2 != null && this.fDeleteNode != characterDataImpl2) {
            if (characterDataImpl2 == this.fStartContainer) {
                if (this.fStartOffset > i3 + i4) {
                    this.fStartOffset = i3 + (this.fStartOffset - (i3 + i4));
                } else if (this.fStartOffset > i3) {
                    this.fStartOffset = i3;
                }
            }
            if (characterDataImpl2 != this.fEndContainer) {
                return;
            }
            if (this.fEndOffset > i3 + i4) {
                this.fEndOffset = i3 + (this.fEndOffset - (i3 + i4));
            } else if (this.fEndOffset > i3) {
                this.fEndOffset = i3;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void receiveInsertedText(CharacterDataImpl characterDataImpl, int i, int i2) {
        CharacterDataImpl characterDataImpl2 = characterDataImpl;
        int i3 = i;
        int i4 = i2;
        if (characterDataImpl2 != null && this.fInsertNode != characterDataImpl2) {
            if (characterDataImpl2 == this.fStartContainer && i3 < this.fStartOffset) {
                this.fStartOffset += i4;
            }
            if (characterDataImpl2 == this.fEndContainer && i3 < this.fEndOffset) {
                this.fEndOffset += i4;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void receiveReplacedText(CharacterDataImpl characterDataImpl) {
        CharacterDataImpl characterDataImpl2 = characterDataImpl;
        if (characterDataImpl2 != null) {
            if (characterDataImpl2 == this.fStartContainer) {
                this.fStartOffset = 0;
            }
            if (characterDataImpl2 == this.fEndContainer) {
                this.fEndOffset = 0;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void receiveSplitData(Node node, Node node2, int i) {
        Node node3 = node;
        Node node4 = node2;
        int i2 = i;
        if (node3 != null && node4 != null && this.fSplitNode != node3) {
            if (node3 == this.fStartContainer && this.fStartContainer.getNodeType() == 3 && this.fStartOffset > i2) {
                this.fStartOffset -= i2;
                this.fStartContainer = node4;
            }
            if (node3 == this.fEndContainer && this.fEndContainer.getNodeType() == 3 && this.fEndOffset > i2) {
                this.fEndOffset -= i2;
                this.fEndContainer = node4;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public Node removeChild(Node node, Node node2) {
        Node node3 = node2;
        this.fRemoveChild = node3;
        Node removeChild = node.removeChild(node3);
        this.fRemoveChild = null;
        return removeChild;
    }

    /* access modifiers changed from: package-private */
    public void removeNode(Node node) {
        Node node2 = node;
        if (node2 != null && this.fRemoveChild != node2) {
            Node parentNode = node2.getParentNode();
            if (parentNode == this.fStartContainer && indexOf(node2, this.fStartContainer) < this.fStartOffset) {
                this.fStartOffset--;
            }
            if (parentNode == this.fEndContainer && indexOf(node2, this.fEndContainer) < this.fEndOffset) {
                this.fEndOffset--;
            }
            if (parentNode != this.fStartContainer || parentNode != this.fEndContainer) {
                if (isAncestorOf(node2, this.fStartContainer)) {
                    this.fStartContainer = parentNode;
                    this.fStartOffset = indexOf(node2, parentNode);
                }
                if (isAncestorOf(node2, this.fEndContainer)) {
                    this.fEndContainer = parentNode;
                    this.fEndOffset = indexOf(node2, parentNode);
                }
            }
        }
    }

    public void selectNode(Node node) throws RangeException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Node node2 = node;
        if (this.fDocument.errorChecking) {
            if (this.fDetach) {
                Throwable th4 = th3;
                new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
                throw th4;
            } else if (!isLegalContainer(node2.getParentNode()) || !isLegalContainedNode(node2)) {
                Throwable th5 = th;
                new RangeExceptionImpl(2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_NODE_TYPE_ERR", (Object[]) null));
                throw th5;
            } else if (!(this.fDocument == node2.getOwnerDocument() || this.fDocument == node2)) {
                Throwable th6 = th2;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th6;
            }
        }
        Node parentNode = node2.getParentNode();
        if (parentNode != null) {
            this.fStartContainer = parentNode;
            this.fEndContainer = parentNode;
            int i = 0;
            Node node3 = node2;
            while (true) {
                Node node4 = node3;
                if (node4 == null) {
                    this.fStartOffset = i - 1;
                    this.fEndOffset = this.fStartOffset + 1;
                    return;
                }
                i++;
                node3 = node4.getPreviousSibling();
            }
        }
    }

    public void selectNodeContents(Node node) throws RangeException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Node node2 = node;
        if (this.fDocument.errorChecking) {
            if (this.fDetach) {
                Throwable th4 = th3;
                new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
                throw th4;
            } else if (!isLegalContainer(node2)) {
                Throwable th5 = th2;
                new RangeExceptionImpl(2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_NODE_TYPE_ERR", (Object[]) null));
                throw th5;
            } else if (!(this.fDocument == node2.getOwnerDocument() || this.fDocument == node2)) {
                Throwable th6 = th;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th6;
            }
        }
        this.fStartContainer = node2;
        this.fEndContainer = node2;
        Node firstChild = node2.getFirstChild();
        this.fStartOffset = 0;
        if (firstChild == null) {
            this.fEndOffset = 0;
            return;
        }
        int i = 0;
        Node node3 = firstChild;
        while (true) {
            Node node4 = node3;
            if (node4 == null) {
                this.fEndOffset = i;
                return;
            }
            i++;
            node3 = node4.getNextSibling();
        }
    }

    public void setEnd(Node node, int i) throws RangeException, DOMException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Node node2 = node;
        int i2 = i;
        if (this.fDocument.errorChecking) {
            if (this.fDetach) {
                Throwable th4 = th3;
                new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
                throw th4;
            } else if (!isLegalContainer(node2)) {
                Throwable th5 = th2;
                new RangeExceptionImpl(2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_NODE_TYPE_ERR", (Object[]) null));
                throw th5;
            } else if (!(this.fDocument == node2.getOwnerDocument() || this.fDocument == node2)) {
                Throwable th6 = th;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th6;
            }
        }
        checkIndex(node2, i2);
        this.fEndContainer = node2;
        this.fEndOffset = i2;
        if (getCommonAncestorContainer() == null || (this.fStartContainer == this.fEndContainer && this.fEndOffset < this.fStartOffset)) {
            collapse(false);
        }
    }

    public void setEndAfter(Node node) throws RangeException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Node node2 = node;
        if (this.fDocument.errorChecking) {
            if (this.fDetach) {
                Throwable th4 = th3;
                new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
                throw th4;
            } else if (!hasLegalRootContainer(node2) || !isLegalContainedNode(node2)) {
                Throwable th5 = th;
                new RangeExceptionImpl(2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_NODE_TYPE_ERR", (Object[]) null));
                throw th5;
            } else if (!(this.fDocument == node2.getOwnerDocument() || this.fDocument == node2)) {
                Throwable th6 = th2;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th6;
            }
        }
        this.fEndContainer = node2.getParentNode();
        int i = 0;
        Node node3 = node2;
        while (true) {
            Node node4 = node3;
            if (node4 == null) {
                break;
            }
            i++;
            node3 = node4.getPreviousSibling();
        }
        this.fEndOffset = i;
        if (getCommonAncestorContainer() == null || (this.fStartContainer == this.fEndContainer && this.fEndOffset < this.fStartOffset)) {
            collapse(false);
        }
    }

    public void setEndBefore(Node node) throws RangeException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Node node2 = node;
        if (this.fDocument.errorChecking) {
            if (this.fDetach) {
                Throwable th4 = th3;
                new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
                throw th4;
            } else if (!hasLegalRootContainer(node2) || !isLegalContainedNode(node2)) {
                Throwable th5 = th;
                new RangeExceptionImpl(2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_NODE_TYPE_ERR", (Object[]) null));
                throw th5;
            } else if (!(this.fDocument == node2.getOwnerDocument() || this.fDocument == node2)) {
                Throwable th6 = th2;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th6;
            }
        }
        this.fEndContainer = node2.getParentNode();
        int i = 0;
        Node node3 = node2;
        while (true) {
            Node node4 = node3;
            if (node4 == null) {
                break;
            }
            i++;
            node3 = node4.getPreviousSibling();
        }
        this.fEndOffset = i - 1;
        if (getCommonAncestorContainer() == null || (this.fStartContainer == this.fEndContainer && this.fEndOffset < this.fStartOffset)) {
            collapse(false);
        }
    }

    public void setStart(Node node, int i) throws RangeException, DOMException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Node node2 = node;
        int i2 = i;
        if (this.fDocument.errorChecking) {
            if (this.fDetach) {
                Throwable th4 = th3;
                new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
                throw th4;
            } else if (!isLegalContainer(node2)) {
                Throwable th5 = th2;
                new RangeExceptionImpl(2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_NODE_TYPE_ERR", (Object[]) null));
                throw th5;
            } else if (!(this.fDocument == node2.getOwnerDocument() || this.fDocument == node2)) {
                Throwable th6 = th;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th6;
            }
        }
        checkIndex(node2, i2);
        this.fStartContainer = node2;
        this.fStartOffset = i2;
        if (getCommonAncestorContainer() == null || (this.fStartContainer == this.fEndContainer && this.fEndOffset < this.fStartOffset)) {
            collapse(true);
        }
    }

    public void setStartAfter(Node node) throws RangeException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Node node2 = node;
        if (this.fDocument.errorChecking) {
            if (this.fDetach) {
                Throwable th4 = th3;
                new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
                throw th4;
            } else if (!hasLegalRootContainer(node2) || !isLegalContainedNode(node2)) {
                Throwable th5 = th;
                new RangeExceptionImpl(2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_NODE_TYPE_ERR", (Object[]) null));
                throw th5;
            } else if (!(this.fDocument == node2.getOwnerDocument() || this.fDocument == node2)) {
                Throwable th6 = th2;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th6;
            }
        }
        this.fStartContainer = node2.getParentNode();
        int i = 0;
        Node node3 = node2;
        while (true) {
            Node node4 = node3;
            if (node4 == null) {
                break;
            }
            i++;
            node3 = node4.getPreviousSibling();
        }
        this.fStartOffset = i;
        if (getCommonAncestorContainer() == null || (this.fStartContainer == this.fEndContainer && this.fEndOffset < this.fStartOffset)) {
            collapse(true);
        }
    }

    public void setStartBefore(Node node) throws RangeException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Node node2 = node;
        if (this.fDocument.errorChecking) {
            if (this.fDetach) {
                Throwable th4 = th3;
                new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
                throw th4;
            } else if (!hasLegalRootContainer(node2) || !isLegalContainedNode(node2)) {
                Throwable th5 = th;
                new RangeExceptionImpl(2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_NODE_TYPE_ERR", (Object[]) null));
                throw th5;
            } else if (!(this.fDocument == node2.getOwnerDocument() || this.fDocument == node2)) {
                Throwable th6 = th2;
                new DOMException(4, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "WRONG_DOCUMENT_ERR", (Object[]) null));
                throw th6;
            }
        }
        this.fStartContainer = node2.getParentNode();
        int i = 0;
        Node node3 = node2;
        while (true) {
            Node node4 = node3;
            if (node4 == null) {
                break;
            }
            i++;
            node3 = node4.getPreviousSibling();
        }
        this.fStartOffset = i - 1;
        if (getCommonAncestorContainer() == null || (this.fStartContainer == this.fEndContainer && this.fEndOffset < this.fStartOffset)) {
            collapse(true);
        }
    }

    /* access modifiers changed from: package-private */
    public void signalSplitData(Node node, Node node2, int i) {
        Node node3 = node;
        this.fSplitNode = node3;
        this.fDocument.splitData(node3, node2, i);
        this.fSplitNode = null;
    }

    public void surroundContents(Node node) throws DOMException, RangeException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Node node2 = node;
        if (node2 != null) {
            short nodeType = node2.getNodeType();
            if (this.fDocument.errorChecking) {
                if (this.fDetach) {
                    Throwable th4 = th3;
                    new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
                    throw th4;
                } else if (nodeType == 2 || nodeType == 6 || nodeType == 12 || nodeType == 10 || nodeType == 9 || nodeType == 11) {
                    Throwable th5 = th2;
                    new RangeExceptionImpl(2, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_NODE_TYPE_ERR", (Object[]) null));
                    throw th5;
                }
            }
            Node node3 = this.fStartContainer;
            Node node4 = this.fEndContainer;
            if (this.fStartContainer.getNodeType() == 3) {
                node3 = this.fStartContainer.getParentNode();
            }
            if (this.fEndContainer.getNodeType() == 3) {
                node4 = this.fEndContainer.getParentNode();
            }
            if (node3 != node4) {
                Throwable th6 = th;
                new RangeExceptionImpl(1, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "BAD_BOUNDARYPOINTS_ERR", (Object[]) null));
                throw th6;
            }
            DocumentFragment extractContents = extractContents();
            insertNode(node2);
            Node appendChild = node2.appendChild(extractContents);
            selectNode(node2);
        }
    }

    public String toString() {
        StringBuffer stringBuffer;
        Node node;
        Throwable th;
        if (this.fDetach) {
            Throwable th2 = th;
            new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
            throw th2;
        }
        Node node2 = this.fStartContainer;
        Node node3 = this.fEndContainer;
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        if (this.fStartContainer.getNodeType() != 3 && this.fStartContainer.getNodeType() != 4) {
            node = node2.getFirstChild();
            if (this.fStartOffset > 0) {
                for (int i = 0; i < this.fStartOffset && node != null; i++) {
                    node = node.getNextSibling();
                }
            }
            if (node == null) {
                node = nextNode(this.fStartContainer, false);
            }
        } else if (this.fStartContainer == this.fEndContainer) {
            StringBuffer append = stringBuffer2.append(this.fStartContainer.getNodeValue().substring(this.fStartOffset, this.fEndOffset));
            return stringBuffer2.toString();
        } else {
            StringBuffer append2 = stringBuffer2.append(this.fStartContainer.getNodeValue().substring(this.fStartOffset));
            node = nextNode(node2, true);
        }
        if (!(this.fEndContainer.getNodeType() == 3 || this.fEndContainer.getNodeType() == 4)) {
            int i2 = this.fEndOffset;
            Node firstChild = this.fEndContainer.getFirstChild();
            while (true) {
                node3 = firstChild;
                if (i2 > 0 && node3 != null) {
                    i2--;
                    firstChild = node3.getNextSibling();
                }
            }
            if (node3 == null) {
                node3 = nextNode(this.fEndContainer, false);
            }
        }
        while (node != node3 && node != null) {
            if (node.getNodeType() == 3 || node.getNodeType() == 4) {
                StringBuffer append3 = stringBuffer2.append(node.getNodeValue());
            }
            node = nextNode(node, true);
        }
        if (this.fEndContainer.getNodeType() == 3 || this.fEndContainer.getNodeType() == 4) {
            StringBuffer append4 = stringBuffer2.append(this.fEndContainer.getNodeValue().substring(0, this.fEndOffset));
        }
        return stringBuffer2.toString();
    }
}
