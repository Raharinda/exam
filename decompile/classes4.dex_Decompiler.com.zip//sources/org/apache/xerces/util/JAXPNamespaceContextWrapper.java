package org.apache.xerces.util;

import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.TreeSet;
import java.util.Vector;
import org.apache.xerces.xni.NamespaceContext;

public final class JAXPNamespaceContextWrapper implements NamespaceContext {
    private final Vector fAllPrefixes;
    private int[] fContext = new int[8];
    private int fCurrentContext;
    private javax.xml.namespace.NamespaceContext fNamespaceContext;
    private List fPrefixes;
    private SymbolTable fSymbolTable;

    public JAXPNamespaceContextWrapper(SymbolTable symbolTable) {
        Vector vector;
        new Vector();
        this.fAllPrefixes = vector;
        setSymbolTable(symbolTable);
    }

    public boolean declarePrefix(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        return true;
    }

    public Enumeration getAllPrefixes() {
        Collection collection;
        new TreeSet(this.fAllPrefixes);
        return Collections.enumeration(collection);
    }

    public String getDeclaredPrefixAt(int i) {
        return (String) this.fPrefixes.get(i);
    }

    public int getDeclaredPrefixCount() {
        return this.fPrefixes != null ? this.fPrefixes.size() : 0;
    }

    public List getDeclaredPrefixes() {
        return this.fPrefixes;
    }

    public javax.xml.namespace.NamespaceContext getNamespaceContext() {
        return this.fNamespaceContext;
    }

    public String getPrefix(String str) {
        String str2 = str;
        if (this.fNamespaceContext == null) {
            return null;
        }
        if (str2 == null) {
            str2 = "";
        }
        String prefix = this.fNamespaceContext.getPrefix(str2);
        if (prefix == null) {
            prefix = "";
        }
        return this.fSymbolTable != null ? this.fSymbolTable.addSymbol(prefix) : prefix.intern();
    }

    public SymbolTable getSymbolTable() {
        return this.fSymbolTable;
    }

    public String getURI(String str) {
        String namespaceURI;
        String str2 = str;
        if (this.fNamespaceContext == null || (namespaceURI = this.fNamespaceContext.getNamespaceURI(str2)) == null || "".equals(namespaceURI)) {
            return null;
        }
        return this.fSymbolTable != null ? this.fSymbolTable.addSymbol(namespaceURI) : namespaceURI.intern();
    }

    public void popContext() {
        Vector vector = this.fAllPrefixes;
        int[] iArr = this.fContext;
        int i = this.fCurrentContext;
        int i2 = i - 1;
        this.fCurrentContext = i2;
        vector.setSize(iArr[i]);
    }

    public void pushContext() {
        if (this.fCurrentContext + 1 == this.fContext.length) {
            int[] iArr = new int[(this.fContext.length * 2)];
            System.arraycopy(this.fContext, 0, iArr, 0, this.fContext.length);
            this.fContext = iArr;
        }
        int[] iArr2 = this.fContext;
        int i = this.fCurrentContext + 1;
        int i2 = i;
        this.fCurrentContext = i2;
        iArr2[i] = this.fAllPrefixes.size();
        if (this.fPrefixes != null) {
            boolean addAll = this.fAllPrefixes.addAll(this.fPrefixes);
        }
    }

    public void reset() {
        this.fCurrentContext = 0;
        this.fContext[this.fCurrentContext] = 0;
        this.fAllPrefixes.clear();
    }

    public void setDeclaredPrefixes(List list) {
        List list2 = list;
        this.fPrefixes = list2;
    }

    public void setNamespaceContext(javax.xml.namespace.NamespaceContext namespaceContext) {
        javax.xml.namespace.NamespaceContext namespaceContext2 = namespaceContext;
        this.fNamespaceContext = namespaceContext2;
    }

    public void setSymbolTable(SymbolTable symbolTable) {
        SymbolTable symbolTable2 = symbolTable;
        this.fSymbolTable = symbolTable2;
    }
}
