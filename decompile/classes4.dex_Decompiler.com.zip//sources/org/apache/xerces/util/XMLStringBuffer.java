package org.apache.xerces.util;

import org.apache.xerces.xni.XMLString;

public class XMLStringBuffer extends XMLString {
    public static final int DEFAULT_SIZE = 32;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XMLStringBuffer() {
        this(32);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XMLStringBuffer(char c) {
        this(1);
        append(c);
    }

    public XMLStringBuffer(int i) {
        this.ch = new char[i];
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XMLStringBuffer(java.lang.String r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r0
            r3 = r1
            int r3 = r3.length()
            r2.<init>((int) r3)
            r2 = r0
            r3 = r1
            r2.append((java.lang.String) r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.util.XMLStringBuffer.<init>(java.lang.String):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XMLStringBuffer(org.apache.xerces.xni.XMLString r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r0
            r3 = r1
            int r3 = r3.length
            r2.<init>((int) r3)
            r2 = r0
            r3 = r1
            r2.append((org.apache.xerces.xni.XMLString) r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.util.XMLStringBuffer.<init>(org.apache.xerces.xni.XMLString):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XMLStringBuffer(char[] r9, int r10, int r11) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            r2 = r10
            r3 = r11
            r4 = r0
            r5 = r3
            r4.<init>((int) r5)
            r4 = r0
            r5 = r1
            r6 = r2
            r7 = r3
            r4.append(r5, r6, r7)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.util.XMLStringBuffer.<init>(char[], int, int):void");
    }

    public void append(char c) {
        char c2 = c;
        if (this.length + 1 > this.ch.length) {
            int length = this.ch.length * 2;
            if (length < this.ch.length + 32) {
                length = this.ch.length + 32;
            }
            char[] cArr = new char[length];
            System.arraycopy(this.ch, 0, cArr, 0, this.length);
            this.ch = cArr;
        }
        this.ch[this.length] = c2;
        this.length++;
    }

    public void append(String str) {
        String str2 = str;
        int length = str2.length();
        if (this.length + length > this.ch.length) {
            int length2 = this.ch.length * 2;
            if (length2 < this.length + length + 32) {
                length2 = this.ch.length + length + 32;
            }
            char[] cArr = new char[length2];
            System.arraycopy(this.ch, 0, cArr, 0, this.length);
            this.ch = cArr;
        }
        str2.getChars(0, length, this.ch, this.length);
        this.length += length;
    }

    public void append(XMLString xMLString) {
        XMLString xMLString2 = xMLString;
        append(xMLString2.ch, xMLString2.offset, xMLString2.length);
    }

    public void append(char[] cArr, int i, int i2) {
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        if (this.length + i4 > this.ch.length) {
            int length = this.ch.length * 2;
            if (length < this.length + i4 + 32) {
                length = this.ch.length + i4 + 32;
            }
            char[] cArr3 = new char[length];
            System.arraycopy(this.ch, 0, cArr3, 0, this.length);
            this.ch = cArr3;
        }
        System.arraycopy(cArr2, i3, this.ch, this.length, i4);
        this.length += i4;
    }

    public void clear() {
        this.offset = 0;
        this.length = 0;
    }
}
