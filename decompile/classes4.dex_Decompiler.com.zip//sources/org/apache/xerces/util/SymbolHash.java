package org.apache.xerces.util;

import org.apache.xerces.dom3.as.ASContentModel;

public class SymbolHash {
    protected static final int MAX_HASH_COLLISIONS = 40;
    protected static final int MULTIPLIERS_MASK = 31;
    protected static final int MULTIPLIERS_SIZE = 32;
    protected static final int TABLE_SIZE = 101;
    protected Entry[] fBuckets;
    protected int[] fHashMultipliers;
    protected int fNum;
    protected int fTableSize;

    protected static final class Entry {
        public Object key;
        public Entry next;
        public Object value;

        public Entry() {
            this.key = null;
            this.value = null;
            this.next = null;
        }

        public Entry(Object obj, Object obj2, Entry entry) {
            this.key = obj;
            this.value = obj2;
            this.next = entry;
        }

        public Entry makeClone() {
            Entry entry;
            new Entry();
            Entry entry2 = entry;
            entry2.key = this.key;
            entry2.value = this.value;
            if (this.next != null) {
                entry2.next = this.next.makeClone();
            }
            return entry2;
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SymbolHash() {
        this(TABLE_SIZE);
    }

    public SymbolHash(int i) {
        this.fNum = 0;
        this.fTableSize = i;
        this.fBuckets = new Entry[this.fTableSize];
    }

    private int hash0(String str) {
        String str2 = str;
        int i = 0;
        int length = str2.length();
        int[] iArr = this.fHashMultipliers;
        for (int i2 = 0; i2 < length; i2++) {
            i = (i * iArr[i2 & MULTIPLIERS_MASK]) + str2.charAt(i2);
        }
        return i & ASContentModel.AS_UNBOUNDED;
    }

    private void rehashCommon(int i) {
        int i2 = i;
        int length = this.fBuckets.length;
        Entry[] entryArr = this.fBuckets;
        Entry[] entryArr2 = new Entry[i2];
        this.fBuckets = entryArr2;
        this.fTableSize = this.fBuckets.length;
        int i3 = length;
        while (true) {
            int i4 = i3;
            i3 = i4 - 1;
            if (i4 > 0) {
                Entry entry = entryArr[i3];
                while (entry != null) {
                    Entry entry2 = entry;
                    entry = entry.next;
                    int hash = hash(entry2.key) % i2;
                    entry2.next = entryArr2[hash];
                    entryArr2[hash] = entry2;
                }
            } else {
                return;
            }
        }
    }

    public void clear() {
        for (int i = 0; i < this.fTableSize; i++) {
            this.fBuckets[i] = null;
        }
        this.fNum = 0;
        this.fHashMultipliers = null;
    }

    public Object get(Object obj) {
        Object obj2 = obj;
        Entry search = search(obj2, hash(obj2) % this.fTableSize);
        if (search != null) {
            return search.value;
        }
        return null;
    }

    public Object[] getEntries() {
        Object[] objArr = new Object[(this.fNum << 1)];
        int i = 0;
        for (int i2 = 0; i2 < this.fTableSize && i < (this.fNum << 1); i2++) {
            Entry entry = this.fBuckets[i2];
            while (true) {
                Entry entry2 = entry;
                if (entry2 == null) {
                    break;
                }
                objArr[i] = entry2.key;
                int i3 = i + 1;
                objArr[i3] = entry2.value;
                i = i3 + 1;
                entry = entry2.next;
            }
        }
        return objArr;
    }

    public int getLength() {
        return this.fNum;
    }

    public int getValues(Object[] objArr, int i) {
        Object[] objArr2 = objArr;
        int i2 = i;
        int i3 = 0;
        for (int i4 = 0; i4 < this.fTableSize && i3 < this.fNum; i4++) {
            Entry entry = this.fBuckets[i4];
            while (true) {
                Entry entry2 = entry;
                if (entry2 == null) {
                    break;
                }
                objArr2[i2 + i3] = entry2.value;
                i3++;
                entry = entry2.next;
            }
        }
        return this.fNum;
    }

    /* access modifiers changed from: protected */
    public int hash(Object obj) {
        Object obj2 = obj;
        return (this.fHashMultipliers == null || !(obj2 instanceof String)) ? obj2.hashCode() & ASContentModel.AS_UNBOUNDED : hash0((String) obj2);
    }

    public SymbolHash makeClone() {
        SymbolHash symbolHash;
        new SymbolHash(this.fTableSize);
        SymbolHash symbolHash2 = symbolHash;
        symbolHash2.fNum = this.fNum;
        symbolHash2.fHashMultipliers = this.fHashMultipliers != null ? (int[]) this.fHashMultipliers.clone() : null;
        for (int i = 0; i < this.fTableSize; i++) {
            if (this.fBuckets[i] != null) {
                symbolHash2.fBuckets[i] = this.fBuckets[i].makeClone();
            }
        }
        return symbolHash2;
    }

    public void put(Object obj, Object obj2) {
        Entry entry;
        Object obj3 = obj;
        Object obj4 = obj2;
        int i = 0;
        int hash = hash(obj3);
        int i2 = hash % this.fTableSize;
        Entry entry2 = this.fBuckets[i2];
        while (true) {
            Entry entry3 = entry2;
            if (entry3 == null) {
                if (this.fNum >= this.fTableSize) {
                    rehash();
                    i2 = hash % this.fTableSize;
                } else if (i >= MAX_HASH_COLLISIONS && (obj3 instanceof String)) {
                    rebalance();
                    i2 = hash(obj3) % this.fTableSize;
                }
                new Entry(obj3, obj4, this.fBuckets[i2]);
                this.fBuckets[i2] = entry;
                this.fNum++;
                return;
            } else if (obj3.equals(entry3.key)) {
                entry3.value = obj4;
                return;
            } else {
                i++;
                entry2 = entry3.next;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void rebalance() {
        if (this.fHashMultipliers == null) {
            this.fHashMultipliers = new int[32];
        }
        PrimeNumberSequenceGenerator.generateSequence(this.fHashMultipliers);
        rehashCommon(this.fBuckets.length);
    }

    /* access modifiers changed from: protected */
    public void rehash() {
        rehashCommon((this.fBuckets.length << 1) + 1);
    }

    /* access modifiers changed from: protected */
    public Entry search(Object obj, int i) {
        Object obj2 = obj;
        Entry entry = this.fBuckets[i];
        while (true) {
            Entry entry2 = entry;
            if (entry2 == null) {
                return null;
            }
            if (obj2.equals(entry2.key)) {
                return entry2;
            }
            entry = entry2.next;
        }
    }
}
