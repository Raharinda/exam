package org.apache.xerces.util;

import java.io.InputStream;
import java.io.Reader;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

public final class SAXInputSource extends XMLInputSource {
    private InputSource fInputSource;
    private XMLReader fXMLReader;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SAXInputSource() {
        this((InputSource) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SAXInputSource(InputSource inputSource) {
        this((XMLReader) null, inputSource);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public SAXInputSource(org.xml.sax.XMLReader r8, org.xml.sax.InputSource r9) {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r2 = r9
            r3 = r0
            r4 = r2
            if (r4 == 0) goto L_0x003f
            r4 = r2
            java.lang.String r4 = r4.getPublicId()
        L_0x000c:
            r5 = r2
            if (r5 == 0) goto L_0x0041
            r5 = r2
            java.lang.String r5 = r5.getSystemId()
        L_0x0014:
            r6 = 0
            r3.<init>(r4, r5, r6)
            r3 = r2
            if (r3 == 0) goto L_0x0036
            r3 = r0
            r4 = r2
            java.io.InputStream r4 = r4.getByteStream()
            r3.setByteStream(r4)
            r3 = r0
            r4 = r2
            java.io.Reader r4 = r4.getCharacterStream()
            r3.setCharacterStream(r4)
            r3 = r0
            r4 = r2
            java.lang.String r4 = r4.getEncoding()
            r3.setEncoding(r4)
        L_0x0036:
            r3 = r0
            r4 = r2
            r3.fInputSource = r4
            r3 = r0
            r4 = r1
            r3.fXMLReader = r4
            return
        L_0x003f:
            r4 = 0
            goto L_0x000c
        L_0x0041:
            r5 = 0
            goto L_0x0014
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.util.SAXInputSource.<init>(org.xml.sax.XMLReader, org.xml.sax.InputSource):void");
    }

    public InputSource getInputSource() {
        return this.fInputSource;
    }

    public XMLReader getXMLReader() {
        return this.fXMLReader;
    }

    public void setByteStream(InputStream inputStream) {
        InputSource inputSource;
        InputStream inputStream2 = inputStream;
        super.setByteStream(inputStream2);
        if (this.fInputSource == null) {
            new InputSource();
            this.fInputSource = inputSource;
        }
        this.fInputSource.setByteStream(inputStream2);
    }

    public void setCharacterStream(Reader reader) {
        InputSource inputSource;
        Reader reader2 = reader;
        super.setCharacterStream(reader2);
        if (this.fInputSource == null) {
            new InputSource();
            this.fInputSource = inputSource;
        }
        this.fInputSource.setCharacterStream(reader2);
    }

    public void setEncoding(String str) {
        InputSource inputSource;
        String str2 = str;
        super.setEncoding(str2);
        if (this.fInputSource == null) {
            new InputSource();
            this.fInputSource = inputSource;
        }
        this.fInputSource.setEncoding(str2);
    }

    public void setInputSource(InputSource inputSource) {
        InputSource inputSource2 = inputSource;
        if (inputSource2 != null) {
            setPublicId(inputSource2.getPublicId());
            setSystemId(inputSource2.getSystemId());
            setByteStream(inputSource2.getByteStream());
            setCharacterStream(inputSource2.getCharacterStream());
            setEncoding(inputSource2.getEncoding());
        } else {
            setPublicId((String) null);
            setSystemId((String) null);
            setByteStream((InputStream) null);
            setCharacterStream((Reader) null);
            setEncoding((String) null);
        }
        this.fInputSource = inputSource2;
    }

    public void setPublicId(String str) {
        InputSource inputSource;
        String str2 = str;
        super.setPublicId(str2);
        if (this.fInputSource == null) {
            new InputSource();
            this.fInputSource = inputSource;
        }
        this.fInputSource.setPublicId(str2);
    }

    public void setSystemId(String str) {
        InputSource inputSource;
        String str2 = str;
        super.setSystemId(str2);
        if (this.fInputSource == null) {
            new InputSource();
            this.fInputSource = inputSource;
        }
        this.fInputSource.setSystemId(str2);
    }

    public void setXMLReader(XMLReader xMLReader) {
        XMLReader xMLReader2 = xMLReader;
        this.fXMLReader = xMLReader2;
    }
}
