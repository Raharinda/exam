package org.apache.xerces.util;

import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public abstract class ErrorHandlerProxy implements ErrorHandler {
    public ErrorHandlerProxy() {
    }

    public void error(SAXParseException sAXParseException) throws SAXException {
        SAXParseException sAXParseException2 = sAXParseException;
        XMLErrorHandler errorHandler = getErrorHandler();
        if (errorHandler instanceof ErrorHandlerWrapper) {
            ((ErrorHandlerWrapper) errorHandler).fErrorHandler.error(sAXParseException2);
        } else {
            errorHandler.error("", "", ErrorHandlerWrapper.createXMLParseException(sAXParseException2));
        }
    }

    public void fatalError(SAXParseException sAXParseException) throws SAXException {
        SAXParseException sAXParseException2 = sAXParseException;
        XMLErrorHandler errorHandler = getErrorHandler();
        if (errorHandler instanceof ErrorHandlerWrapper) {
            ((ErrorHandlerWrapper) errorHandler).fErrorHandler.fatalError(sAXParseException2);
        } else {
            errorHandler.fatalError("", "", ErrorHandlerWrapper.createXMLParseException(sAXParseException2));
        }
    }

    /* access modifiers changed from: protected */
    public abstract XMLErrorHandler getErrorHandler();

    public void warning(SAXParseException sAXParseException) throws SAXException {
        SAXParseException sAXParseException2 = sAXParseException;
        XMLErrorHandler errorHandler = getErrorHandler();
        if (errorHandler instanceof ErrorHandlerWrapper) {
            ((ErrorHandlerWrapper) errorHandler).fErrorHandler.warning(sAXParseException2);
        } else {
            errorHandler.warning("", "", ErrorHandlerWrapper.createXMLParseException(sAXParseException2));
        }
    }
}
