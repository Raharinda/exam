package org.apache.xerces.util;

import java.util.ArrayList;
import java.util.HashMap;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;

public class ParserConfigurationSettings implements XMLComponentManager {
    protected static final String PARSER_SETTINGS = "http://apache.org/xml/features/internal/parser-settings";
    protected HashMap fFeatures;
    protected XMLComponentManager fParentSettings;
    protected HashMap fProperties;
    protected ArrayList fRecognizedFeatures;
    protected ArrayList fRecognizedProperties;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public ParserConfigurationSettings() {
        this((XMLComponentManager) null);
    }

    public ParserConfigurationSettings(XMLComponentManager xMLComponentManager) {
        ArrayList arrayList;
        ArrayList arrayList2;
        HashMap hashMap;
        HashMap hashMap2;
        new ArrayList();
        this.fRecognizedFeatures = arrayList;
        new ArrayList();
        this.fRecognizedProperties = arrayList2;
        new HashMap();
        this.fFeatures = hashMap;
        new HashMap();
        this.fProperties = hashMap2;
        this.fParentSettings = xMLComponentManager;
    }

    public void addRecognizedFeatures(String[] strArr) {
        String[] strArr2 = strArr;
        int length = strArr2 != null ? strArr2.length : 0;
        for (int i = 0; i < length; i++) {
            String str = strArr2[i];
            if (!this.fRecognizedFeatures.contains(str)) {
                boolean add = this.fRecognizedFeatures.add(str);
            }
        }
    }

    public void addRecognizedProperties(String[] strArr) {
        String[] strArr2 = strArr;
        int length = strArr2 != null ? strArr2.length : 0;
        for (int i = 0; i < length; i++) {
            String str = strArr2[i];
            if (!this.fRecognizedProperties.contains(str)) {
                boolean add = this.fRecognizedProperties.add(str);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void checkFeature(String str) throws XMLConfigurationException {
        Throwable th;
        String str2 = str;
        if (this.fRecognizedFeatures.contains(str2)) {
            return;
        }
        if (this.fParentSettings != null) {
            boolean feature = this.fParentSettings.getFeature(str2);
            return;
        }
        Throwable th2 = th;
        new XMLConfigurationException(0, str2);
        throw th2;
    }

    /* access modifiers changed from: protected */
    public void checkProperty(String str) throws XMLConfigurationException {
        Throwable th;
        String str2 = str;
        if (this.fRecognizedProperties.contains(str2)) {
            return;
        }
        if (this.fParentSettings != null) {
            Object property = this.fParentSettings.getProperty(str2);
            return;
        }
        Throwable th2 = th;
        new XMLConfigurationException(0, str2);
        throw th2;
    }

    public boolean getFeature(String str) throws XMLConfigurationException {
        String str2 = str;
        Boolean bool = (Boolean) this.fFeatures.get(str2);
        if (bool != null) {
            return bool.booleanValue();
        }
        checkFeature(str2);
        return false;
    }

    public Object getProperty(String str) throws XMLConfigurationException {
        String str2 = str;
        Object obj = this.fProperties.get(str2);
        if (obj == null) {
            checkProperty(str2);
        }
        return obj;
    }

    public void setFeature(String str, boolean z) throws XMLConfigurationException {
        String str2 = str;
        checkFeature(str2);
        Object put = this.fFeatures.put(str2, z ? Boolean.TRUE : Boolean.FALSE);
    }

    public void setProperty(String str, Object obj) throws XMLConfigurationException {
        String str2 = str;
        checkProperty(str2);
        Object put = this.fProperties.put(str2, obj);
    }
}
