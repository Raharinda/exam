package org.apache.xerces.util;

import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import org.apache.xerces.xni.Augmentations;

public class AugmentationsImpl implements Augmentations {
    private AugmentationsItemsContainer fAugmentationsContainer;

    static abstract class AugmentationsItemsContainer {
        AugmentationsItemsContainer() {
        }

        public abstract void clear();

        public abstract AugmentationsItemsContainer expand();

        public abstract Object getItem(Object obj);

        public abstract boolean isFull();

        public abstract Enumeration keys();

        public abstract Object putItem(Object obj, Object obj2);

        public abstract Object removeItem(Object obj);
    }

    static final class LargeContainer extends AugmentationsItemsContainer {
        private final HashMap fAugmentations;

        LargeContainer() {
            HashMap hashMap;
            new HashMap();
            this.fAugmentations = hashMap;
        }

        public void clear() {
            this.fAugmentations.clear();
        }

        public AugmentationsItemsContainer expand() {
            return this;
        }

        public Object getItem(Object obj) {
            return this.fAugmentations.get(obj);
        }

        public boolean isFull() {
            return false;
        }

        public Enumeration keys() {
            return Collections.enumeration(this.fAugmentations.keySet());
        }

        public Object putItem(Object obj, Object obj2) {
            return this.fAugmentations.put(obj, obj2);
        }

        public Object removeItem(Object obj) {
            return this.fAugmentations.remove(obj);
        }

        public String toString() {
            StringBuffer stringBuffer;
            new StringBuffer();
            StringBuffer stringBuffer2 = stringBuffer;
            StringBuffer append = stringBuffer2.append("LargeContainer");
            for (Map.Entry entry : this.fAugmentations.entrySet()) {
                StringBuffer append2 = stringBuffer2.append("\nkey == ");
                StringBuffer append3 = stringBuffer2.append(entry.getKey());
                StringBuffer append4 = stringBuffer2.append("; value == ");
                StringBuffer append5 = stringBuffer2.append(entry.getValue());
            }
            return stringBuffer2.toString();
        }
    }

    static final class SmallContainer extends AugmentationsItemsContainer {
        static final int SIZE_LIMIT = 10;
        final Object[] fAugmentations = new Object[20];
        int fNumEntries = 0;

        final class SmallContainerKeyEnumeration implements Enumeration {
            Object[] enumArray = new Object[this.this$0.fNumEntries];
            int next = 0;
            private final SmallContainer this$0;

            SmallContainerKeyEnumeration(SmallContainer smallContainer) {
                SmallContainer smallContainer2 = smallContainer;
                this.this$0 = smallContainer2;
                for (int i = 0; i < smallContainer2.fNumEntries; i++) {
                    this.enumArray[i] = smallContainer2.fAugmentations[i * 2];
                }
            }

            public boolean hasMoreElements() {
                return this.next < this.enumArray.length;
            }

            public Object nextElement() {
                Throwable th;
                if (this.next >= this.enumArray.length) {
                    Throwable th2 = th;
                    new NoSuchElementException();
                    throw th2;
                }
                Object obj = this.enumArray[this.next];
                this.enumArray[this.next] = null;
                this.next++;
                return obj;
            }
        }

        SmallContainer() {
        }

        public void clear() {
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= this.fNumEntries * 2) {
                    this.fNumEntries = 0;
                    return;
                }
                this.fAugmentations[i2] = null;
                this.fAugmentations[i2 + 1] = null;
                i = i2 + 2;
            }
        }

        public AugmentationsItemsContainer expand() {
            LargeContainer largeContainer;
            new LargeContainer();
            LargeContainer largeContainer2 = largeContainer;
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= this.fNumEntries * 2) {
                    return largeContainer2;
                }
                Object putItem = largeContainer2.putItem(this.fAugmentations[i2], this.fAugmentations[i2 + 1]);
                i = i2 + 2;
            }
        }

        public Object getItem(Object obj) {
            Object obj2 = obj;
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= this.fNumEntries * 2) {
                    return null;
                }
                if (this.fAugmentations[i2].equals(obj2)) {
                    return this.fAugmentations[i2 + 1];
                }
                i = i2 + 2;
            }
        }

        public boolean isFull() {
            return this.fNumEntries == 10;
        }

        public Enumeration keys() {
            Enumeration enumeration;
            new SmallContainerKeyEnumeration(this);
            return enumeration;
        }

        public Object putItem(Object obj, Object obj2) {
            Object obj3 = obj;
            Object obj4 = obj2;
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= this.fNumEntries * 2) {
                    this.fAugmentations[this.fNumEntries * 2] = obj3;
                    this.fAugmentations[(this.fNumEntries * 2) + 1] = obj4;
                    this.fNumEntries++;
                    return null;
                } else if (this.fAugmentations[i2].equals(obj3)) {
                    Object obj5 = this.fAugmentations[i2 + 1];
                    this.fAugmentations[i2 + 1] = obj4;
                    return obj5;
                } else {
                    i = i2 + 2;
                }
            }
        }

        public Object removeItem(Object obj) {
            Object obj2 = obj;
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= this.fNumEntries * 2) {
                    return null;
                }
                if (this.fAugmentations[i2].equals(obj2)) {
                    Object obj3 = this.fAugmentations[i2 + 1];
                    int i3 = i2;
                    while (true) {
                        int i4 = i3;
                        if (i4 >= (this.fNumEntries * 2) - 2) {
                            this.fAugmentations[(this.fNumEntries * 2) - 2] = null;
                            this.fAugmentations[(this.fNumEntries * 2) - 1] = null;
                            this.fNumEntries--;
                            return obj3;
                        }
                        this.fAugmentations[i4] = this.fAugmentations[i4 + 2];
                        this.fAugmentations[i4 + 1] = this.fAugmentations[i4 + 3];
                        i3 = i4 + 2;
                    }
                } else {
                    i = i2 + 2;
                }
            }
        }

        public String toString() {
            StringBuffer stringBuffer;
            new StringBuffer();
            StringBuffer stringBuffer2 = stringBuffer;
            StringBuffer append = stringBuffer2.append("SmallContainer - fNumEntries == ").append(this.fNumEntries);
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= 20) {
                    return stringBuffer2.toString();
                }
                StringBuffer append2 = stringBuffer2.append("\nfAugmentations[");
                StringBuffer append3 = stringBuffer2.append(i2);
                StringBuffer append4 = stringBuffer2.append("] == ");
                StringBuffer append5 = stringBuffer2.append(this.fAugmentations[i2]);
                StringBuffer append6 = stringBuffer2.append("; fAugmentations[");
                StringBuffer append7 = stringBuffer2.append(i2 + 1);
                StringBuffer append8 = stringBuffer2.append("] == ");
                StringBuffer append9 = stringBuffer2.append(this.fAugmentations[i2 + 1]);
                i = i2 + 2;
            }
        }
    }

    public AugmentationsImpl() {
        AugmentationsItemsContainer augmentationsItemsContainer;
        new SmallContainer();
        this.fAugmentationsContainer = augmentationsItemsContainer;
    }

    public Object getItem(String str) {
        return this.fAugmentationsContainer.getItem(str);
    }

    public Enumeration keys() {
        return this.fAugmentationsContainer.keys();
    }

    public Object putItem(String str, Object obj) {
        Object putItem = this.fAugmentationsContainer.putItem(str, obj);
        if (putItem == null && this.fAugmentationsContainer.isFull()) {
            this.fAugmentationsContainer = this.fAugmentationsContainer.expand();
        }
        return putItem;
    }

    public void removeAllItems() {
        this.fAugmentationsContainer.clear();
    }

    public Object removeItem(String str) {
        return this.fAugmentationsContainer.removeItem(str);
    }

    public String toString() {
        return this.fAugmentationsContainer.toString();
    }
}
