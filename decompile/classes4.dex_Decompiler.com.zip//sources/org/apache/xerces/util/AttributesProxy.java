package org.apache.xerces.util;

import org.apache.xerces.xni.XMLAttributes;
import org.xml.sax.AttributeList;
import org.xml.sax.ext.Attributes2;

public final class AttributesProxy implements AttributeList, Attributes2 {
    private XMLAttributes fAttributes;

    public AttributesProxy(XMLAttributes xMLAttributes) {
        this.fAttributes = xMLAttributes;
    }

    public XMLAttributes getAttributes() {
        return this.fAttributes;
    }

    public int getIndex(String str) {
        return this.fAttributes.getIndex(str);
    }

    public int getIndex(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        return str3.equals(XMLSymbols.EMPTY_STRING) ? this.fAttributes.getIndex((String) null, str4) : this.fAttributes.getIndex(str3, str4);
    }

    public int getLength() {
        return this.fAttributes.getLength();
    }

    public String getLocalName(int i) {
        return this.fAttributes.getLocalName(i);
    }

    public String getName(int i) {
        return this.fAttributes.getQName(i);
    }

    public String getQName(int i) {
        return this.fAttributes.getQName(i);
    }

    public String getType(int i) {
        return this.fAttributes.getType(i);
    }

    public String getType(String str) {
        return this.fAttributes.getType(str);
    }

    public String getType(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        return str3.equals(XMLSymbols.EMPTY_STRING) ? this.fAttributes.getType((String) null, str4) : this.fAttributes.getType(str3, str4);
    }

    public String getURI(int i) {
        String uri = this.fAttributes.getURI(i);
        return uri != null ? uri : XMLSymbols.EMPTY_STRING;
    }

    public String getValue(int i) {
        return this.fAttributes.getValue(i);
    }

    public String getValue(String str) {
        return this.fAttributes.getValue(str);
    }

    public String getValue(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        return str3.equals(XMLSymbols.EMPTY_STRING) ? this.fAttributes.getValue((String) null, str4) : this.fAttributes.getValue(str3, str4);
    }

    public boolean isDeclared(int i) {
        Throwable th;
        int i2 = i;
        if (i2 >= 0 && i2 < this.fAttributes.getLength()) {
            return Boolean.TRUE.equals(this.fAttributes.getAugmentations(i2).getItem("ATTRIBUTE_DECLARED"));
        }
        Throwable th2 = th;
        new ArrayIndexOutOfBoundsException(i2);
        throw th2;
    }

    public boolean isDeclared(String str) {
        Throwable th;
        String str2 = str;
        int index = getIndex(str2);
        if (index != -1) {
            return Boolean.TRUE.equals(this.fAttributes.getAugmentations(index).getItem("ATTRIBUTE_DECLARED"));
        }
        Throwable th2 = th;
        new IllegalArgumentException(str2);
        throw th2;
    }

    public boolean isDeclared(String str, String str2) {
        Throwable th;
        String str3 = str2;
        int index = getIndex(str, str3);
        if (index != -1) {
            return Boolean.TRUE.equals(this.fAttributes.getAugmentations(index).getItem("ATTRIBUTE_DECLARED"));
        }
        Throwable th2 = th;
        new IllegalArgumentException(str3);
        throw th2;
    }

    public boolean isSpecified(int i) {
        Throwable th;
        int i2 = i;
        if (i2 >= 0 && i2 < this.fAttributes.getLength()) {
            return this.fAttributes.isSpecified(i2);
        }
        Throwable th2 = th;
        new ArrayIndexOutOfBoundsException(i2);
        throw th2;
    }

    public boolean isSpecified(String str) {
        Throwable th;
        String str2 = str;
        int index = getIndex(str2);
        if (index != -1) {
            return this.fAttributes.isSpecified(index);
        }
        Throwable th2 = th;
        new IllegalArgumentException(str2);
        throw th2;
    }

    public boolean isSpecified(String str, String str2) {
        Throwable th;
        String str3 = str2;
        int index = getIndex(str, str3);
        if (index != -1) {
            return this.fAttributes.isSpecified(index);
        }
        Throwable th2 = th;
        new IllegalArgumentException(str3);
        throw th2;
    }

    public void setAttributes(XMLAttributes xMLAttributes) {
        XMLAttributes xMLAttributes2 = xMLAttributes;
        this.fAttributes = xMLAttributes2;
    }
}
