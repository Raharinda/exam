package org.apache.xerces.util;

public final class IntStack {
    private int[] fData;
    private int fDepth;

    public IntStack() {
    }

    private void ensureCapacity(int i) {
        int i2 = i;
        if (this.fData == null) {
            this.fData = new int[32];
        } else if (this.fData.length <= i2) {
            int[] iArr = new int[(this.fData.length * 2)];
            System.arraycopy(this.fData, 0, iArr, 0, this.fData.length);
            this.fData = iArr;
        }
    }

    public void clear() {
        this.fDepth = 0;
    }

    public int elementAt(int i) {
        return this.fData[i];
    }

    public int peek() {
        return this.fData[this.fDepth - 1];
    }

    public int pop() {
        int[] iArr = this.fData;
        int i = this.fDepth - 1;
        int i2 = i;
        this.fDepth = i2;
        return iArr[i];
    }

    public void print() {
        System.out.print('(');
        System.out.print(this.fDepth);
        System.out.print(") {");
        int i = 0;
        while (true) {
            if (i >= this.fDepth) {
                break;
            } else if (i == 3) {
                System.out.print(" ...");
                break;
            } else {
                System.out.print(' ');
                System.out.print(this.fData[i]);
                if (i < this.fDepth - 1) {
                    System.out.print(',');
                }
                i++;
            }
        }
        System.out.print(" }");
        System.out.println();
    }

    public void push(int i) {
        ensureCapacity(this.fDepth + 1);
        int[] iArr = this.fData;
        int i2 = this.fDepth;
        int i3 = i2 + 1;
        this.fDepth = i3;
        iArr[i2] = i;
    }

    public int size() {
        return this.fDepth;
    }
}
