package org.apache.xerces.util;

import org.apache.xerces.dom3.as.ASContentModel;

public class SymbolTable {
    protected static final int MAX_HASH_COLLISIONS = 40;
    protected static final int MULTIPLIERS_MASK = 31;
    protected static final int MULTIPLIERS_SIZE = 32;
    protected static final int TABLE_SIZE = 101;
    protected Entry[] fBuckets;
    protected final int fCollisionThreshold;
    protected transient int fCount;
    protected int[] fHashMultipliers;
    protected float fLoadFactor;
    protected int fTableSize;
    protected int fThreshold;

    protected static final class Entry {
        public final char[] characters;
        public Entry next;
        public final String symbol;

        public Entry(String str, Entry entry) {
            String str2 = str;
            this.symbol = str2.intern();
            this.characters = new char[str2.length()];
            str2.getChars(0, this.characters.length, this.characters, 0);
            this.next = entry;
        }

        public Entry(char[] cArr, int i, int i2, Entry entry) {
            String str;
            int i3 = i2;
            this.characters = new char[i3];
            System.arraycopy(cArr, i, this.characters, 0, i3);
            new String(this.characters);
            this.symbol = str.intern();
            this.next = entry;
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SymbolTable() {
        this(TABLE_SIZE, 0.75f);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SymbolTable(int i) {
        this(i, 0.75f);
    }

    public SymbolTable(int i, float f) {
        Throwable th;
        StringBuffer stringBuffer;
        Throwable th2;
        StringBuffer stringBuffer2;
        int i2 = i;
        float f2 = f;
        this.fBuckets = null;
        if (i2 < 0) {
            Throwable th3 = th2;
            new StringBuffer();
            new IllegalArgumentException(stringBuffer2.append("Illegal Capacity: ").append(i2).toString());
            throw th3;
        } else if (f2 <= 0.0f || Float.isNaN(f2)) {
            Throwable th4 = th;
            new StringBuffer();
            new IllegalArgumentException(stringBuffer.append("Illegal Load: ").append(f2).toString());
            throw th4;
        } else {
            i2 = i2 == 0 ? 1 : i2;
            this.fLoadFactor = f2;
            this.fTableSize = i2;
            this.fBuckets = new Entry[this.fTableSize];
            this.fThreshold = (int) (((float) this.fTableSize) * f2);
            this.fCollisionThreshold = (int) (40.0f * f2);
            this.fCount = 0;
        }
    }

    private String addSymbol0(String str, int i, int i2) {
        Entry entry;
        String str2 = str;
        int i3 = i;
        int i4 = i2;
        if (this.fCount >= this.fThreshold) {
            rehash();
            i3 = hash(str2) % this.fTableSize;
        } else if (i4 >= this.fCollisionThreshold) {
            rebalance();
            i3 = hash(str2) % this.fTableSize;
        }
        new Entry(str2, this.fBuckets[i3]);
        Entry entry2 = entry;
        this.fBuckets[i3] = entry2;
        this.fCount++;
        return entry2.symbol;
    }

    private String addSymbol0(char[] cArr, int i, int i2, int i3, int i4) {
        Entry entry;
        char[] cArr2 = cArr;
        int i5 = i;
        int i6 = i2;
        int i7 = i3;
        int i8 = i4;
        if (this.fCount >= this.fThreshold) {
            rehash();
            i7 = hash(cArr2, i5, i6) % this.fTableSize;
        } else if (i8 >= this.fCollisionThreshold) {
            rebalance();
            i7 = hash(cArr2, i5, i6) % this.fTableSize;
        }
        new Entry(cArr2, i5, i6, this.fBuckets[i7]);
        Entry entry2 = entry;
        this.fBuckets[i7] = entry2;
        this.fCount++;
        return entry2.symbol;
    }

    private int hash0(String str) {
        String str2 = str;
        int i = 0;
        int length = str2.length();
        int[] iArr = this.fHashMultipliers;
        for (int i2 = 0; i2 < length; i2++) {
            i = (i * iArr[i2 & MULTIPLIERS_MASK]) + str2.charAt(i2);
        }
        return i & ASContentModel.AS_UNBOUNDED;
    }

    private int hash0(char[] cArr, int i, int i2) {
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        int i5 = 0;
        int[] iArr = this.fHashMultipliers;
        for (int i6 = 0; i6 < i4; i6++) {
            i5 = (i5 * iArr[i6 & MULTIPLIERS_MASK]) + cArr2[i3 + i6];
        }
        return i5 & ASContentModel.AS_UNBOUNDED;
    }

    private void rehashCommon(int i) {
        int i2 = i;
        int length = this.fBuckets.length;
        Entry[] entryArr = this.fBuckets;
        Entry[] entryArr2 = new Entry[i2];
        this.fThreshold = (int) (((float) i2) * this.fLoadFactor);
        this.fBuckets = entryArr2;
        this.fTableSize = this.fBuckets.length;
        int i3 = length;
        while (true) {
            int i4 = i3;
            i3 = i4 - 1;
            if (i4 > 0) {
                Entry entry = entryArr[i3];
                while (entry != null) {
                    Entry entry2 = entry;
                    entry = entry.next;
                    int hash = hash(entry2.symbol) % i2;
                    entry2.next = entryArr2[hash];
                    entryArr2[hash] = entry2;
                }
            } else {
                return;
            }
        }
    }

    public String addSymbol(String str) {
        String str2 = str;
        int i = 0;
        int hash = hash(str2) % this.fTableSize;
        Entry entry = this.fBuckets[hash];
        while (true) {
            Entry entry2 = entry;
            if (entry2 == null) {
                return addSymbol0(str2, hash, i);
            }
            if (entry2.symbol.equals(str2)) {
                return entry2.symbol;
            }
            i++;
            entry = entry2.next;
        }
    }

    public String addSymbol(char[] cArr, int i, int i2) {
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        int i5 = 0;
        int hash = hash(cArr2, i3, i4) % this.fTableSize;
        Entry entry = this.fBuckets[hash];
        while (true) {
            Entry entry2 = entry;
            if (entry2 == null) {
                return addSymbol0(cArr2, i3, i4, hash, i5);
            }
            if (i4 == entry2.characters.length) {
                int i6 = 0;
                while (i6 < i4) {
                    if (cArr2[i3 + i6] == entry2.characters[i6]) {
                        i6++;
                    }
                }
                return entry2.symbol;
            }
            i5++;
            entry = entry2.next;
        }
    }

    public boolean containsSymbol(String str) {
        String str2 = str;
        int hash = hash(str2) % this.fTableSize;
        int length = str2.length();
        Entry entry = this.fBuckets[hash];
        while (true) {
            Entry entry2 = entry;
            if (entry2 == null) {
                return false;
            }
            if (length == entry2.characters.length) {
                int i = 0;
                while (i < length) {
                    if (str2.charAt(i) == entry2.characters[i]) {
                        i++;
                    }
                }
                return true;
            }
            entry = entry2.next;
        }
    }

    public boolean containsSymbol(char[] cArr, int i, int i2) {
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        Entry entry = this.fBuckets[hash(cArr2, i3, i4) % this.fTableSize];
        while (true) {
            Entry entry2 = entry;
            if (entry2 == null) {
                return false;
            }
            if (i4 == entry2.characters.length) {
                int i5 = 0;
                while (i5 < i4) {
                    if (cArr2[i3 + i5] == entry2.characters[i5]) {
                        i5++;
                    }
                }
                return true;
            }
            entry = entry2.next;
        }
    }

    public int hash(String str) {
        String str2 = str;
        return this.fHashMultipliers == null ? str2.hashCode() & ASContentModel.AS_UNBOUNDED : hash0(str2);
    }

    public int hash(char[] cArr, int i, int i2) {
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        if (this.fHashMultipliers != null) {
            return hash0(cArr2, i3, i4);
        }
        int i5 = 0;
        for (int i6 = 0; i6 < i4; i6++) {
            i5 = (i5 * MULTIPLIERS_MASK) + cArr2[i3 + i6];
        }
        return i5 & ASContentModel.AS_UNBOUNDED;
    }

    /* access modifiers changed from: protected */
    public void rebalance() {
        if (this.fHashMultipliers == null) {
            this.fHashMultipliers = new int[32];
        }
        PrimeNumberSequenceGenerator.generateSequence(this.fHashMultipliers);
        rehashCommon(this.fBuckets.length);
    }

    /* access modifiers changed from: protected */
    public void rehash() {
        rehashCommon((this.fBuckets.length * 2) + 1);
    }
}
