package org.apache.xerces.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class EntityResolverWrapper implements XMLEntityResolver {
    protected EntityResolver fEntityResolver;

    public EntityResolverWrapper() {
    }

    public EntityResolverWrapper(EntityResolver entityResolver) {
        setEntityResolver(entityResolver);
    }

    public EntityResolver getEntityResolver() {
        return this.fEntityResolver;
    }

    public XMLInputSource resolveEntity(XMLResourceIdentifier xMLResourceIdentifier) throws XNIException, IOException {
        Throwable th;
        XMLInputSource xMLInputSource;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String publicId = xMLResourceIdentifier2.getPublicId();
        String expandedSystemId = xMLResourceIdentifier2.getExpandedSystemId();
        if (publicId == null && expandedSystemId == null) {
            return null;
        }
        if (!(this.fEntityResolver == null || xMLResourceIdentifier2 == null)) {
            try {
                InputSource resolveEntity = this.fEntityResolver.resolveEntity(publicId, expandedSystemId);
                if (resolveEntity != null) {
                    String publicId2 = resolveEntity.getPublicId();
                    String systemId = resolveEntity.getSystemId();
                    String baseSystemId = xMLResourceIdentifier2.getBaseSystemId();
                    InputStream byteStream = resolveEntity.getByteStream();
                    Reader characterStream = resolveEntity.getCharacterStream();
                    String encoding = resolveEntity.getEncoding();
                    new XMLInputSource(publicId2, systemId, baseSystemId);
                    XMLInputSource xMLInputSource2 = xMLInputSource;
                    xMLInputSource2.setByteStream(byteStream);
                    xMLInputSource2.setCharacterStream(characterStream);
                    xMLInputSource2.setEncoding(encoding);
                    return xMLInputSource2;
                }
            } catch (SAXException e) {
                Exception exc = e;
                Exception exception = exc.getException();
                if (exception == null) {
                    exception = exc;
                }
                Throwable th2 = th;
                new XNIException(exception);
                throw th2;
            }
        }
        return null;
    }

    public void setEntityResolver(EntityResolver entityResolver) {
        EntityResolver entityResolver2 = entityResolver;
        this.fEntityResolver = entityResolver2;
    }
}
