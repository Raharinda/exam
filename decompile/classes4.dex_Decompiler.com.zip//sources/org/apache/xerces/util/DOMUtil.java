package org.apache.xerces.util;

import java.lang.reflect.Method;
import java.util.Hashtable;
import net.lingala.zip4j.util.Zip4jConstants;
import org.apache.xerces.dom.AttrImpl;
import org.apache.xerces.dom.DocumentImpl;
import org.apache.xerces.impl.xs.opti.ElementImpl;
import org.apache.xerces.impl.xs.opti.NodeImpl;
import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.ls.LSException;

public class DOMUtil {

    static class ThrowableMethods {
        static Class class$java$lang$Throwable;
        private static Method fgThrowableInitCauseMethod;
        private static boolean fgThrowableMethodsAvailable;

        static {
            Class cls;
            Class cls2;
            fgThrowableInitCauseMethod = null;
            fgThrowableMethodsAvailable = false;
            try {
                if (class$java$lang$Throwable == null) {
                    Class class$ = class$("java.lang.Throwable");
                    cls = class$;
                    class$java$lang$Throwable = class$;
                } else {
                    cls = class$java$lang$Throwable;
                }
                Class[] clsArr = new Class[1];
                Class[] clsArr2 = clsArr;
                Class[] clsArr3 = clsArr;
                if (class$java$lang$Throwable == null) {
                    Class class$2 = class$("java.lang.Throwable");
                    cls2 = class$2;
                    class$java$lang$Throwable = class$2;
                } else {
                    cls2 = class$java$lang$Throwable;
                }
                clsArr3[0] = cls2;
                fgThrowableInitCauseMethod = cls.getMethod("initCause", clsArr2);
                fgThrowableMethodsAvailable = true;
            } catch (Exception e) {
                Exception exc = e;
                fgThrowableInitCauseMethod = null;
                fgThrowableMethodsAvailable = false;
            }
        }

        private ThrowableMethods() {
        }

        static boolean access$000() {
            return fgThrowableMethodsAvailable;
        }

        static Method access$100() {
            return fgThrowableInitCauseMethod;
        }

        static Class class$(String str) {
            Throwable th;
            try {
                return Class.forName(str);
            } catch (ClassNotFoundException e) {
                ClassNotFoundException classNotFoundException = e;
                Throwable th2 = th;
                new NoClassDefFoundError(classNotFoundException.getMessage());
                throw th2;
            }
        }
    }

    protected DOMUtil() {
    }

    public static void copyInto(Node node, Node node2) throws DOMException {
        Throwable th;
        StringBuffer stringBuffer;
        CDATASection createTextNode;
        Node node3 = node;
        Node node4 = node2;
        Document ownerDocument = node4.getOwnerDocument();
        boolean z = ownerDocument instanceof DocumentImpl;
        Node node5 = node3;
        Node node6 = node3;
        Node node7 = node3;
        while (node7 != null) {
            short nodeType = node7.getNodeType();
            switch (nodeType) {
                case 1:
                    Element createElement = ownerDocument.createElement(node7.getNodeName());
                    createTextNode = createElement;
                    NamedNodeMap attributes = node7.getAttributes();
                    int length = attributes.getLength();
                    for (int i = 0; i < length; i++) {
                        Attr attr = (Attr) attributes.item(i);
                        String nodeName = attr.getNodeName();
                        createElement.setAttribute(nodeName, attr.getNodeValue());
                        if (z && !attr.getSpecified()) {
                            ((AttrImpl) createElement.getAttributeNode(nodeName)).setSpecified(false);
                        }
                    }
                    break;
                case 3:
                    createTextNode = ownerDocument.createTextNode(node7.getNodeValue());
                    break;
                case 4:
                    createTextNode = ownerDocument.createCDATASection(node7.getNodeValue());
                    break;
                case 5:
                    createTextNode = ownerDocument.createEntityReference(node7.getNodeName());
                    break;
                case Zip4jConstants.DEFLATE_LEVEL_MAXIMUM:
                    createTextNode = ownerDocument.createProcessingInstruction(node7.getNodeName(), node7.getNodeValue());
                    break;
                case 8:
                    createTextNode = ownerDocument.createComment(node7.getNodeValue());
                    break;
                default:
                    Throwable th2 = th;
                    new StringBuffer();
                    new IllegalArgumentException(stringBuffer.append("can't copy node type, ").append(nodeType).append(" (").append(node7.getNodeName()).append(')').toString());
                    throw th2;
            }
            Node appendChild = node4.appendChild(createTextNode);
            if (node7.hasChildNodes()) {
                node6 = node7;
                node7 = node7.getFirstChild();
                node4 = createTextNode;
            } else {
                node7 = node7.getNextSibling();
                while (node7 == null && node6 != node5) {
                    node7 = node6.getNextSibling();
                    node6 = node6.getParentNode();
                    node4 = node4.getParentNode();
                }
            }
        }
    }

    public static DOMException createDOMException(short s, Throwable th) {
        Throwable th2 = th;
        DOMException dOMException = r10;
        DOMException dOMException2 = new DOMException(s, th2 != null ? th2.getMessage() : null);
        DOMException dOMException3 = dOMException;
        if (th2 != null && ThrowableMethods.access$000()) {
            try {
                Object invoke = ThrowableMethods.access$100().invoke(dOMException3, new Object[]{th2});
            } catch (Exception e) {
                Exception exc = e;
            }
        }
        return dOMException3;
    }

    public static LSException createLSException(short s, Throwable th) {
        Throwable th2 = th;
        LSException lSException = r10;
        LSException lSException2 = new LSException(s, th2 != null ? th2.getMessage() : null);
        LSException lSException3 = lSException;
        if (th2 != null && ThrowableMethods.access$000()) {
            try {
                Object invoke = ThrowableMethods.access$100().invoke(lSException3, new Object[]{th2});
            } catch (Exception e) {
                Exception exc = e;
            }
        }
        return lSException3;
    }

    public static String getAnnotation(Node node) {
        Node node2 = node;
        if (node2 instanceof ElementImpl) {
            return ((ElementImpl) node2).getAnnotation();
        }
        return null;
    }

    public static Attr getAttr(Element element, String str) {
        return element.getAttributeNode(str);
    }

    public static Attr getAttrNS(Element element, String str, String str2) {
        return element.getAttributeNodeNS(str, str2);
    }

    public static String getAttrValue(Element element, String str) {
        return element.getAttribute(str);
    }

    public static String getAttrValueNS(Element element, String str, String str2) {
        return element.getAttributeNS(str, str2);
    }

    public static Attr[] getAttrs(Element element) {
        NamedNodeMap attributes = element.getAttributes();
        Attr[] attrArr = new Attr[attributes.getLength()];
        for (int i = 0; i < attributes.getLength(); i++) {
            attrArr[i] = (Attr) attributes.item(i);
        }
        return attrArr;
    }

    public static String getChildText(Node node) {
        StringBuffer stringBuffer;
        Node node2 = node;
        if (node2 == null) {
            return null;
        }
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        Node firstChild = node2.getFirstChild();
        while (true) {
            Node node3 = firstChild;
            if (node3 == null) {
                return stringBuffer2.toString();
            }
            short nodeType = node3.getNodeType();
            if (nodeType == 3) {
                StringBuffer append = stringBuffer2.append(node3.getNodeValue());
            } else if (nodeType == 4) {
                StringBuffer append2 = stringBuffer2.append(getChildText(node3));
            }
            firstChild = node3.getNextSibling();
        }
    }

    public static Document getDocument(Node node) {
        return node.getOwnerDocument();
    }

    public static Element getFirstChildElement(Node node) {
        Node firstChild = node.getFirstChild();
        while (true) {
            Node node2 = firstChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1) {
                return (Element) node2;
            }
            firstChild = node2.getNextSibling();
        }
    }

    public static Element getFirstChildElement(Node node, String str) {
        String str2 = str;
        Node firstChild = node.getFirstChild();
        while (true) {
            Node node2 = firstChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1 && node2.getNodeName().equals(str2)) {
                return (Element) node2;
            }
            firstChild = node2.getNextSibling();
        }
    }

    public static Element getFirstChildElement(Node node, String str, String str2, String str3) {
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        Node firstChild = node.getFirstChild();
        while (true) {
            Node node2 = firstChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1) {
                Element element = (Element) node2;
                if (element.getNodeName().equals(str4) && element.getAttribute(str5).equals(str6)) {
                    return element;
                }
            }
            firstChild = node2.getNextSibling();
        }
    }

    public static Element getFirstChildElement(Node node, String[] strArr) {
        String[] strArr2 = strArr;
        Node firstChild = node.getFirstChild();
        while (true) {
            Node node2 = firstChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1) {
                for (int i = 0; i < strArr2.length; i++) {
                    if (node2.getNodeName().equals(strArr2[i])) {
                        return (Element) node2;
                    }
                }
                continue;
            }
            firstChild = node2.getNextSibling();
        }
    }

    public static Element getFirstChildElementNS(Node node, String str, String str2) {
        String namespaceURI;
        String str3 = str;
        String str4 = str2;
        Node firstChild = node.getFirstChild();
        while (true) {
            Node node2 = firstChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1 && (namespaceURI = node2.getNamespaceURI()) != null && namespaceURI.equals(str3) && node2.getLocalName().equals(str4)) {
                return (Element) node2;
            }
            firstChild = node2.getNextSibling();
        }
    }

    public static Element getFirstChildElementNS(Node node, String[][] strArr) {
        String[][] strArr2 = strArr;
        Node firstChild = node.getFirstChild();
        while (true) {
            Node node2 = firstChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1) {
                for (int i = 0; i < strArr2.length; i++) {
                    String namespaceURI = node2.getNamespaceURI();
                    if (namespaceURI != null && namespaceURI.equals(strArr2[i][0]) && node2.getLocalName().equals(strArr2[i][1])) {
                        return (Element) node2;
                    }
                }
                continue;
            }
            firstChild = node2.getNextSibling();
        }
    }

    public static Element getFirstVisibleChildElement(Node node) {
        Node firstChild = node.getFirstChild();
        while (true) {
            Node node2 = firstChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1 && !isHidden(node2)) {
                return (Element) node2;
            }
            firstChild = node2.getNextSibling();
        }
    }

    public static Element getFirstVisibleChildElement(Node node, Hashtable hashtable) {
        Hashtable hashtable2 = hashtable;
        Node firstChild = node.getFirstChild();
        while (true) {
            Node node2 = firstChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1 && !isHidden(node2, hashtable2)) {
                return (Element) node2;
            }
            firstChild = node2.getNextSibling();
        }
    }

    public static Element getLastChildElement(Node node) {
        Node lastChild = node.getLastChild();
        while (true) {
            Node node2 = lastChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1) {
                return (Element) node2;
            }
            lastChild = node2.getPreviousSibling();
        }
    }

    public static Element getLastChildElement(Node node, String str) {
        String str2 = str;
        Node lastChild = node.getLastChild();
        while (true) {
            Node node2 = lastChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1 && node2.getNodeName().equals(str2)) {
                return (Element) node2;
            }
            lastChild = node2.getPreviousSibling();
        }
    }

    public static Element getLastChildElement(Node node, String str, String str2, String str3) {
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        Node lastChild = node.getLastChild();
        while (true) {
            Node node2 = lastChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1) {
                Element element = (Element) node2;
                if (element.getNodeName().equals(str4) && element.getAttribute(str5).equals(str6)) {
                    return element;
                }
            }
            lastChild = node2.getPreviousSibling();
        }
    }

    public static Element getLastChildElement(Node node, String[] strArr) {
        String[] strArr2 = strArr;
        Node lastChild = node.getLastChild();
        while (true) {
            Node node2 = lastChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1) {
                for (int i = 0; i < strArr2.length; i++) {
                    if (node2.getNodeName().equals(strArr2[i])) {
                        return (Element) node2;
                    }
                }
                continue;
            }
            lastChild = node2.getPreviousSibling();
        }
    }

    public static Element getLastChildElementNS(Node node, String str, String str2) {
        String namespaceURI;
        String str3 = str;
        String str4 = str2;
        Node lastChild = node.getLastChild();
        while (true) {
            Node node2 = lastChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1 && (namespaceURI = node2.getNamespaceURI()) != null && namespaceURI.equals(str3) && node2.getLocalName().equals(str4)) {
                return (Element) node2;
            }
            lastChild = node2.getPreviousSibling();
        }
    }

    public static Element getLastChildElementNS(Node node, String[][] strArr) {
        String[][] strArr2 = strArr;
        Node lastChild = node.getLastChild();
        while (true) {
            Node node2 = lastChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1) {
                for (int i = 0; i < strArr2.length; i++) {
                    String namespaceURI = node2.getNamespaceURI();
                    if (namespaceURI != null && namespaceURI.equals(strArr2[i][0]) && node2.getLocalName().equals(strArr2[i][1])) {
                        return (Element) node2;
                    }
                }
                continue;
            }
            lastChild = node2.getPreviousSibling();
        }
    }

    public static Element getLastVisibleChildElement(Node node) {
        Node lastChild = node.getLastChild();
        while (true) {
            Node node2 = lastChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1 && !isHidden(node2)) {
                return (Element) node2;
            }
            lastChild = node2.getPreviousSibling();
        }
    }

    public static Element getLastVisibleChildElement(Node node, Hashtable hashtable) {
        Hashtable hashtable2 = hashtable;
        Node lastChild = node.getLastChild();
        while (true) {
            Node node2 = lastChild;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1 && !isHidden(node2, hashtable2)) {
                return (Element) node2;
            }
            lastChild = node2.getPreviousSibling();
        }
    }

    public static String getLocalName(Node node) {
        Node node2 = node;
        String localName = node2.getLocalName();
        return localName != null ? localName : node2.getNodeName();
    }

    public static String getName(Node node) {
        return node.getNodeName();
    }

    public static String getNamespaceURI(Node node) {
        return node.getNamespaceURI();
    }

    public static Element getNextSiblingElement(Node node) {
        Node nextSibling = node.getNextSibling();
        while (true) {
            Node node2 = nextSibling;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1) {
                return (Element) node2;
            }
            nextSibling = node2.getNextSibling();
        }
    }

    public static Element getNextSiblingElement(Node node, String str) {
        String str2 = str;
        Node nextSibling = node.getNextSibling();
        while (true) {
            Node node2 = nextSibling;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1 && node2.getNodeName().equals(str2)) {
                return (Element) node2;
            }
            nextSibling = node2.getNextSibling();
        }
    }

    public static Element getNextSiblingElement(Node node, String str, String str2, String str3) {
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        Node nextSibling = node.getNextSibling();
        while (true) {
            Node node2 = nextSibling;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1) {
                Element element = (Element) node2;
                if (element.getNodeName().equals(str4) && element.getAttribute(str5).equals(str6)) {
                    return element;
                }
            }
            nextSibling = node2.getNextSibling();
        }
    }

    public static Element getNextSiblingElement(Node node, String[] strArr) {
        String[] strArr2 = strArr;
        Node nextSibling = node.getNextSibling();
        while (true) {
            Node node2 = nextSibling;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1) {
                for (int i = 0; i < strArr2.length; i++) {
                    if (node2.getNodeName().equals(strArr2[i])) {
                        return (Element) node2;
                    }
                }
                continue;
            }
            nextSibling = node2.getNextSibling();
        }
    }

    public static Element getNextSiblingElementNS(Node node, String str, String str2) {
        String namespaceURI;
        String str3 = str;
        String str4 = str2;
        Node nextSibling = node.getNextSibling();
        while (true) {
            Node node2 = nextSibling;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1 && (namespaceURI = node2.getNamespaceURI()) != null && namespaceURI.equals(str3) && node2.getLocalName().equals(str4)) {
                return (Element) node2;
            }
            nextSibling = node2.getNextSibling();
        }
    }

    public static Element getNextSiblingElementNS(Node node, String[][] strArr) {
        String[][] strArr2 = strArr;
        Node nextSibling = node.getNextSibling();
        while (true) {
            Node node2 = nextSibling;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1) {
                for (int i = 0; i < strArr2.length; i++) {
                    String namespaceURI = node2.getNamespaceURI();
                    if (namespaceURI != null && namespaceURI.equals(strArr2[i][0]) && node2.getLocalName().equals(strArr2[i][1])) {
                        return (Element) node2;
                    }
                }
                continue;
            }
            nextSibling = node2.getNextSibling();
        }
    }

    public static Element getNextVisibleSiblingElement(Node node) {
        Node nextSibling = node.getNextSibling();
        while (true) {
            Node node2 = nextSibling;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1 && !isHidden(node2)) {
                return (Element) node2;
            }
            nextSibling = node2.getNextSibling();
        }
    }

    public static Element getNextVisibleSiblingElement(Node node, Hashtable hashtable) {
        Hashtable hashtable2 = hashtable;
        Node nextSibling = node.getNextSibling();
        while (true) {
            Node node2 = nextSibling;
            if (node2 == null) {
                return null;
            }
            if (node2.getNodeType() == 1 && !isHidden(node2, hashtable2)) {
                return (Element) node2;
            }
            nextSibling = node2.getNextSibling();
        }
    }

    public static Element getParent(Element element) {
        Node parentNode = element.getParentNode();
        if (parentNode instanceof Element) {
            return (Element) parentNode;
        }
        return null;
    }

    public static String getPrefix(Node node) {
        return node.getPrefix();
    }

    public static Element getRoot(Document document) {
        return document.getDocumentElement();
    }

    public static String getSyntheticAnnotation(Node node) {
        Node node2 = node;
        if (node2 instanceof ElementImpl) {
            return ((ElementImpl) node2).getSyntheticAnnotation();
        }
        return null;
    }

    public static String getValue(Attr attr) {
        return attr.getValue();
    }

    public static boolean isHidden(Node node) {
        Node node2 = node;
        if (node2 instanceof NodeImpl) {
            return ((NodeImpl) node2).getReadOnly();
        }
        if (node2 instanceof org.apache.xerces.dom.NodeImpl) {
            return ((org.apache.xerces.dom.NodeImpl) node2).getReadOnly();
        }
        return false;
    }

    public static boolean isHidden(Node node, Hashtable hashtable) {
        Node node2 = node;
        return node2 instanceof NodeImpl ? ((NodeImpl) node2).getReadOnly() : hashtable.containsKey(node2);
    }

    public static void setHidden(Node node) {
        Node node2 = node;
        if (node2 instanceof NodeImpl) {
            ((NodeImpl) node2).setReadOnly(true, false);
        } else if (node2 instanceof org.apache.xerces.dom.NodeImpl) {
            ((org.apache.xerces.dom.NodeImpl) node2).setReadOnly(true, false);
        }
    }

    public static void setHidden(Node node, Hashtable hashtable) {
        Node node2 = node;
        Hashtable hashtable2 = hashtable;
        if (node2 instanceof NodeImpl) {
            ((NodeImpl) node2).setReadOnly(true, false);
        } else {
            Object put = hashtable2.put(node2, "");
        }
    }

    public static void setVisible(Node node) {
        Node node2 = node;
        if (node2 instanceof NodeImpl) {
            ((NodeImpl) node2).setReadOnly(false, false);
        } else if (node2 instanceof org.apache.xerces.dom.NodeImpl) {
            ((org.apache.xerces.dom.NodeImpl) node2).setReadOnly(false, false);
        }
    }

    public static void setVisible(Node node, Hashtable hashtable) {
        Node node2 = node;
        Hashtable hashtable2 = hashtable;
        if (node2 instanceof NodeImpl) {
            ((NodeImpl) node2).setReadOnly(false, false);
        } else {
            Object remove = hashtable2.remove(node2);
        }
    }
}
