package org.apache.xerces.util;

import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.apache.xerces.xni.parser.XMLParseException;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class ErrorHandlerWrapper implements XMLErrorHandler {
    protected ErrorHandler fErrorHandler;

    public ErrorHandlerWrapper() {
    }

    public ErrorHandlerWrapper(ErrorHandler errorHandler) {
        setErrorHandler(errorHandler);
    }

    protected static SAXParseException createSAXParseException(XMLParseException xMLParseException) {
        SAXParseException sAXParseException;
        XMLParseException xMLParseException2 = xMLParseException;
        new SAXParseException(xMLParseException2.getMessage(), xMLParseException2.getPublicId(), xMLParseException2.getExpandedSystemId(), xMLParseException2.getLineNumber(), xMLParseException2.getColumnNumber(), xMLParseException2.getException());
        return sAXParseException;
    }

    protected static XMLParseException createXMLParseException(SAXParseException sAXParseException) {
        XMLLocator xMLLocator;
        XMLParseException xMLParseException;
        SAXParseException sAXParseException2 = sAXParseException;
        String publicId = sAXParseException2.getPublicId();
        String systemId = sAXParseException2.getSystemId();
        int lineNumber = sAXParseException2.getLineNumber();
        new XMLLocator(publicId, systemId, sAXParseException2.getColumnNumber(), lineNumber) {
            private final int val$fColumnNumber;
            private final String val$fExpandedSystemId;
            private final int val$fLineNumber;
            private final String val$fPublicId;

            {
                this.val$fPublicId = r8;
                this.val$fExpandedSystemId = r9;
                this.val$fColumnNumber = r10;
                this.val$fLineNumber = r11;
            }

            public String getBaseSystemId() {
                return null;
            }

            public int getCharacterOffset() {
                return -1;
            }

            public int getColumnNumber() {
                return this.val$fColumnNumber;
            }

            public String getEncoding() {
                return null;
            }

            public String getExpandedSystemId() {
                return this.val$fExpandedSystemId;
            }

            public int getLineNumber() {
                return this.val$fLineNumber;
            }

            public String getLiteralSystemId() {
                return null;
            }

            public String getPublicId() {
                return this.val$fPublicId;
            }

            public String getXMLVersion() {
                return null;
            }
        };
        new XMLParseException(xMLLocator, sAXParseException2.getMessage(), sAXParseException2);
        return xMLParseException;
    }

    protected static XNIException createXNIException(SAXException sAXException) {
        XNIException xNIException;
        SAXException sAXException2 = sAXException;
        new XNIException(sAXException2.getMessage(), sAXException2);
        return xNIException;
    }

    public void error(String str, String str2, XMLParseException xMLParseException) throws XNIException {
        String str3 = str;
        String str4 = str2;
        XMLParseException xMLParseException2 = xMLParseException;
        if (this.fErrorHandler != null) {
            try {
                this.fErrorHandler.error(createSAXParseException(xMLParseException2));
            } catch (SAXParseException e) {
                throw createXMLParseException(e);
            } catch (SAXException e2) {
                throw createXNIException(e2);
            }
        }
    }

    public void fatalError(String str, String str2, XMLParseException xMLParseException) throws XNIException {
        String str3 = str;
        String str4 = str2;
        XMLParseException xMLParseException2 = xMLParseException;
        if (this.fErrorHandler != null) {
            try {
                this.fErrorHandler.fatalError(createSAXParseException(xMLParseException2));
            } catch (SAXParseException e) {
                throw createXMLParseException(e);
            } catch (SAXException e2) {
                throw createXNIException(e2);
            }
        }
    }

    public ErrorHandler getErrorHandler() {
        return this.fErrorHandler;
    }

    public void setErrorHandler(ErrorHandler errorHandler) {
        ErrorHandler errorHandler2 = errorHandler;
        this.fErrorHandler = errorHandler2;
    }

    public void warning(String str, String str2, XMLParseException xMLParseException) throws XNIException {
        String str3 = str;
        String str4 = str2;
        XMLParseException xMLParseException2 = xMLParseException;
        if (this.fErrorHandler != null) {
            try {
                this.fErrorHandler.warning(createSAXParseException(xMLParseException2));
            } catch (SAXParseException e) {
                throw createXMLParseException(e);
            } catch (SAXException e2) {
                throw createXNIException(e2);
            }
        }
    }
}
