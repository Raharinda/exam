package org.apache.xerces.util;

import org.apache.xerces.dom3.as.ASContentModel;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;

public class XMLAttributesImpl implements XMLAttributes {
    protected static final int MAX_HASH_COLLISIONS = 40;
    protected static final int MULTIPLIERS_MASK = 31;
    protected static final int MULTIPLIERS_SIZE = 32;
    protected static final int SIZE_LIMIT = 20;
    protected static final int TABLE_SIZE = 101;
    protected Attribute[] fAttributeTableView;
    protected int[] fAttributeTableViewChainState;
    protected Attribute[] fAttributes;
    protected int[] fHashMultipliers;
    protected boolean fIsTableViewConsistent;
    protected int fLargeCount;
    protected int fLength;
    protected boolean fNamespaces;
    protected int fTableViewBuckets;

    static class Attribute {
        public Augmentations augs;
        public final QName name;
        public Attribute next;
        public String nonNormalizedValue;
        public boolean specified;
        public String type;
        public String value;

        Attribute() {
            QName qName;
            Augmentations augmentations;
            new QName();
            this.name = qName;
            new AugmentationsImpl();
            this.augs = augmentations;
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XMLAttributesImpl() {
        this(TABLE_SIZE);
    }

    public XMLAttributesImpl(int i) {
        Attribute attribute;
        this.fNamespaces = true;
        this.fLargeCount = 1;
        this.fAttributes = new Attribute[4];
        this.fTableViewBuckets = i;
        for (int i2 = 0; i2 < this.fAttributes.length; i2++) {
            new Attribute();
            this.fAttributes[i2] = attribute;
        }
    }

    private QName checkManyDuplicatesNS() {
        this.fIsTableViewConsistent = false;
        prepareTableView();
        int i = this.fLength;
        Attribute[] attributeArr = this.fAttributes;
        Attribute[] attributeArr2 = this.fAttributeTableView;
        int[] iArr = this.fAttributeTableViewChainState;
        int i2 = this.fLargeCount;
        for (int i3 = 0; i3 < i; i3++) {
            Attribute attribute = attributeArr[i3];
            int tableViewBucket = getTableViewBucket(attribute.name.localpart, attribute.name.uri);
            if (iArr[tableViewBucket] != i2) {
                iArr[tableViewBucket] = i2;
                attribute.next = null;
                attributeArr2[tableViewBucket] = attribute;
            } else {
                int i4 = 0;
                Attribute attribute2 = attributeArr2[tableViewBucket];
                while (attribute2 != null) {
                    if (attribute2.name.localpart == attribute.name.localpart && attribute2.name.uri == attribute.name.uri) {
                        return attribute.name;
                    }
                    attribute2 = attribute2.next;
                    i4++;
                }
                if (i4 >= MAX_HASH_COLLISIONS) {
                    rebalanceTableViewNS(i3 + 1);
                    i2 = this.fLargeCount;
                } else {
                    attribute.next = attributeArr2[tableViewBucket];
                    attributeArr2[tableViewBucket] = attribute;
                }
            }
        }
        return null;
    }

    private String getReportableType(String str) {
        String str2 = str;
        return str2.charAt(0) == MAX_HASH_COLLISIONS ? "NMTOKEN" : str2;
    }

    private void growTableView() {
        int i = this.fLength;
        int i2 = this.fTableViewBuckets;
        while (true) {
            i2 = (i2 << 1) + 1;
            if (i2 >= 0) {
                if (i <= i2) {
                    break;
                }
            } else {
                i2 = Integer.MAX_VALUE;
                break;
            }
        }
        this.fTableViewBuckets = i2;
        this.fAttributeTableView = null;
        this.fLargeCount = 1;
    }

    private int hash(String str) {
        String str2 = str;
        return this.fHashMultipliers == null ? str2.hashCode() : hash0(str2);
    }

    private int hash(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        return this.fHashMultipliers == null ? str3.hashCode() + (str4.hashCode() * MULTIPLIERS_MASK) : hash0(str3) + (hash0(str4) * this.fHashMultipliers[32]);
    }

    private int hash0(String str) {
        String str2 = str;
        int i = 0;
        int length = str2.length();
        int[] iArr = this.fHashMultipliers;
        for (int i2 = 0; i2 < length; i2++) {
            i = (i * iArr[i2 & MULTIPLIERS_MASK]) + str2.charAt(i2);
        }
        return i;
    }

    private void prepareAndPopulateTableView(int i) {
        int i2 = i;
        prepareTableView();
        for (int i3 = 0; i3 < i2; i3++) {
            Attribute attribute = this.fAttributes[i3];
            int tableViewBucket = getTableViewBucket(attribute.name.rawname);
            if (this.fAttributeTableViewChainState[tableViewBucket] != this.fLargeCount) {
                this.fAttributeTableViewChainState[tableViewBucket] = this.fLargeCount;
                attribute.next = null;
                this.fAttributeTableView[tableViewBucket] = attribute;
            } else {
                attribute.next = this.fAttributeTableView[tableViewBucket];
                this.fAttributeTableView[tableViewBucket] = attribute;
            }
        }
    }

    private void prepareAndPopulateTableViewNS(int i) {
        int i2 = i;
        prepareTableView();
        for (int i3 = 0; i3 < i2; i3++) {
            Attribute attribute = this.fAttributes[i3];
            int tableViewBucket = getTableViewBucket(attribute.name.localpart, attribute.name.uri);
            if (this.fAttributeTableViewChainState[tableViewBucket] != this.fLargeCount) {
                this.fAttributeTableViewChainState[tableViewBucket] = this.fLargeCount;
                attribute.next = null;
                this.fAttributeTableView[tableViewBucket] = attribute;
            } else {
                attribute.next = this.fAttributeTableView[tableViewBucket];
                this.fAttributeTableView[tableViewBucket] = attribute;
            }
        }
    }

    private void rebalanceTableView(int i) {
        int i2 = i;
        if (this.fHashMultipliers == null) {
            this.fHashMultipliers = new int[33];
        }
        PrimeNumberSequenceGenerator.generateSequence(this.fHashMultipliers);
        prepareAndPopulateTableView(i2);
    }

    private void rebalanceTableViewNS(int i) {
        int i2 = i;
        if (this.fHashMultipliers == null) {
            this.fHashMultipliers = new int[33];
        }
        PrimeNumberSequenceGenerator.generateSequence(this.fHashMultipliers);
        prepareAndPopulateTableViewNS(i2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:24:0x00cc, code lost:
        if (r15 == -1) goto L_0x00ce;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int addAttribute(org.apache.xerces.xni.QName r18, java.lang.String r19, java.lang.String r20) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            r2 = r19
            r3 = r20
            r10 = r0
            int r10 = r10.fLength
            r11 = 20
            if (r10 >= r11) goto L_0x00ae
            r10 = r1
            java.lang.String r10 = r10.uri
            if (r10 == 0) goto L_0x0096
            r10 = r1
            java.lang.String r10 = r10.uri
            int r10 = r10.length()
            if (r10 == 0) goto L_0x0096
            r10 = r0
            r11 = r1
            java.lang.String r11 = r11.uri
            r12 = r1
            java.lang.String r12 = r12.localpart
            int r10 = r10.getIndexFast(r11, r12)
        L_0x0028:
            r4 = r10
            r10 = r4
            r11 = -1
            if (r10 != r11) goto L_0x006f
            r10 = r0
            int r10 = r10.fLength
            r4 = r10
            r10 = r0
            r15 = r10
            r10 = r15
            r11 = r15
            int r11 = r11.fLength
            r15 = r10
            r16 = r11
            r10 = r16
            r11 = r15
            r12 = r16
            r13 = 1
            int r12 = r12 + 1
            r11.fLength = r12
            r11 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r11 = r11.fAttributes
            int r11 = r11.length
            if (r10 != r11) goto L_0x006f
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributes
            int r10 = r10.length
            r11 = 4
            int r10 = r10 + 4
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = new org.apache.xerces.util.XMLAttributesImpl.Attribute[r10]
            r5 = r10
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributes
            r11 = 0
            r12 = r5
            r13 = 0
            r14 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r14 = r14.fAttributes
            int r14 = r14.length
            java.lang.System.arraycopy(r10, r11, r12, r13, r14)
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributes
            int r10 = r10.length
            r6 = r10
        L_0x0066:
            r10 = r6
            r11 = r5
            int r11 = r11.length
            if (r10 < r11) goto L_0x009f
            r10 = r0
            r11 = r5
            r10.fAttributes = r11
        L_0x006f:
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributes
            r11 = r4
            r10 = r10[r11]
            r5 = r10
            r10 = r5
            org.apache.xerces.xni.QName r10 = r10.name
            r11 = r1
            r10.setValues(r11)
            r10 = r5
            r11 = r2
            r10.type = r11
            r10 = r5
            r11 = r3
            r10.value = r11
            r10 = r5
            r11 = r3
            r10.nonNormalizedValue = r11
            r10 = r5
            r11 = 0
            r10.specified = r11
            r10 = r5
            org.apache.xerces.xni.Augmentations r10 = r10.augs
            r10.removeAllItems()
            r10 = r4
            r0 = r10
            return r0
        L_0x0096:
            r10 = r0
            r11 = r1
            java.lang.String r11 = r11.rawname
            int r10 = r10.getIndexFast(r11)
            goto L_0x0028
        L_0x009f:
            r10 = r5
            r11 = r6
            org.apache.xerces.util.XMLAttributesImpl$Attribute r12 = new org.apache.xerces.util.XMLAttributesImpl$Attribute
            r15 = r12
            r12 = r15
            r13 = r15
            r13.<init>()
            r10[r11] = r12
            int r6 = r6 + 1
            goto L_0x0066
        L_0x00ae:
            r10 = r1
            java.lang.String r10 = r10.uri
            if (r10 == 0) goto L_0x00ce
            r10 = r1
            java.lang.String r10 = r10.uri
            int r10 = r10.length()
            if (r10 == 0) goto L_0x00ce
            r10 = r0
            r11 = r1
            java.lang.String r11 = r11.uri
            r12 = r1
            java.lang.String r12 = r12.localpart
            int r10 = r10.getIndexFast(r11, r12)
            r15 = r10
            r10 = r15
            r11 = r15
            r4 = r11
            r11 = -1
            if (r10 != r11) goto L_0x006f
        L_0x00ce:
            r10 = r0
            boolean r10 = r10.fIsTableViewConsistent
            if (r10 == 0) goto L_0x00e9
            r10 = r0
            int r10 = r10.fLength
            r11 = 20
            if (r10 == r11) goto L_0x00e9
            r10 = r0
            int r10 = r10.fLength
            r11 = 20
            if (r10 <= r11) goto L_0x00f1
            r10 = r0
            int r10 = r10.fLength
            r11 = r0
            int r11 = r11.fTableViewBuckets
            if (r10 <= r11) goto L_0x00f1
        L_0x00e9:
            r10 = r0
            r10.prepareAndPopulateTableView()
            r10 = r0
            r11 = 1
            r10.fIsTableViewConsistent = r11
        L_0x00f1:
            r10 = r0
            r11 = r1
            java.lang.String r11 = r11.rawname
            int r10 = r10.getTableViewBucket(r11)
            r5 = r10
            r10 = r0
            int[] r10 = r10.fAttributeTableViewChainState
            r11 = r5
            r10 = r10[r11]
            r11 = r0
            int r11 = r11.fLargeCount
            if (r10 == r11) goto L_0x0176
            r10 = r0
            int r10 = r10.fLength
            r4 = r10
            r10 = r0
            r15 = r10
            r10 = r15
            r11 = r15
            int r11 = r11.fLength
            r15 = r10
            r16 = r11
            r10 = r16
            r11 = r15
            r12 = r16
            r13 = 1
            int r12 = r12 + 1
            r11.fLength = r12
            r11 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r11 = r11.fAttributes
            int r11 = r11.length
            if (r10 != r11) goto L_0x0147
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributes
            int r10 = r10.length
            r11 = 1
            int r10 = r10 << 1
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = new org.apache.xerces.util.XMLAttributesImpl.Attribute[r10]
            r6 = r10
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributes
            r11 = 0
            r12 = r6
            r13 = 0
            r14 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r14 = r14.fAttributes
            int r14 = r14.length
            java.lang.System.arraycopy(r10, r11, r12, r13, r14)
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributes
            int r10 = r10.length
            r7 = r10
        L_0x013e:
            r10 = r7
            r11 = r6
            int r11 = r11.length
            if (r10 < r11) goto L_0x0167
            r10 = r0
            r11 = r6
            r10.fAttributes = r11
        L_0x0147:
            r10 = r0
            int[] r10 = r10.fAttributeTableViewChainState
            r11 = r5
            r12 = r0
            int r12 = r12.fLargeCount
            r10[r11] = r12
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributes
            r11 = r4
            r10 = r10[r11]
            r11 = 0
            r10.next = r11
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributeTableView
            r11 = r5
            r12 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r12 = r12.fAttributes
            r13 = r4
            r12 = r12[r13]
            r10[r11] = r12
            goto L_0x006f
        L_0x0167:
            r10 = r6
            r11 = r7
            org.apache.xerces.util.XMLAttributesImpl$Attribute r12 = new org.apache.xerces.util.XMLAttributesImpl$Attribute
            r15 = r12
            r12 = r15
            r13 = r15
            r13.<init>()
            r10[r11] = r12
            int r7 = r7 + 1
            goto L_0x013e
        L_0x0176:
            r10 = 0
            r6 = r10
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributeTableView
            r11 = r5
            r10 = r10[r11]
            r7 = r10
        L_0x017f:
            r10 = r7
            if (r10 != 0) goto L_0x01e1
        L_0x0182:
            r10 = r7
            if (r10 != 0) goto L_0x021e
            r10 = r0
            int r10 = r10.fLength
            r4 = r10
            r10 = r0
            r15 = r10
            r10 = r15
            r11 = r15
            int r11 = r11.fLength
            r15 = r10
            r16 = r11
            r10 = r16
            r11 = r15
            r12 = r16
            r13 = 1
            int r12 = r12 + 1
            r11.fLength = r12
            r11 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r11 = r11.fAttributes
            int r11 = r11.length
            if (r10 != r11) goto L_0x01c7
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributes
            int r10 = r10.length
            r11 = 1
            int r10 = r10 << 1
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = new org.apache.xerces.util.XMLAttributesImpl.Attribute[r10]
            r8 = r10
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributes
            r11 = 0
            r12 = r8
            r13 = 0
            r14 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r14 = r14.fAttributes
            int r14 = r14.length
            java.lang.System.arraycopy(r10, r11, r12, r13, r14)
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributes
            int r10 = r10.length
            r9 = r10
        L_0x01be:
            r10 = r9
            r11 = r8
            int r11 = r11.length
            if (r10 < r11) goto L_0x01f3
            r10 = r0
            r11 = r8
            r10.fAttributes = r11
        L_0x01c7:
            r10 = r6
            r11 = 40
            if (r10 < r11) goto L_0x0202
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributes
            r11 = r4
            r10 = r10[r11]
            org.apache.xerces.xni.QName r10 = r10.name
            r11 = r1
            r10.setValues(r11)
            r10 = r0
            r11 = r0
            int r11 = r11.fLength
            r10.rebalanceTableView(r11)
            goto L_0x006f
        L_0x01e1:
            r10 = r7
            org.apache.xerces.xni.QName r10 = r10.name
            java.lang.String r10 = r10.rawname
            r11 = r1
            java.lang.String r11 = r11.rawname
            if (r10 != r11) goto L_0x01ec
            goto L_0x0182
        L_0x01ec:
            r10 = r7
            org.apache.xerces.util.XMLAttributesImpl$Attribute r10 = r10.next
            r7 = r10
            int r6 = r6 + 1
            goto L_0x017f
        L_0x01f3:
            r10 = r8
            r11 = r9
            org.apache.xerces.util.XMLAttributesImpl$Attribute r12 = new org.apache.xerces.util.XMLAttributesImpl$Attribute
            r15 = r12
            r12 = r15
            r13 = r15
            r13.<init>()
            r10[r11] = r12
            int r9 = r9 + 1
            goto L_0x01be
        L_0x0202:
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributes
            r11 = r4
            r10 = r10[r11]
            r11 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r11 = r11.fAttributeTableView
            r12 = r5
            r11 = r11[r12]
            r10.next = r11
            r10 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r10 = r10.fAttributeTableView
            r11 = r5
            r12 = r0
            org.apache.xerces.util.XMLAttributesImpl$Attribute[] r12 = r12.fAttributes
            r13 = r4
            r12 = r12[r13]
            r10[r11] = r12
            goto L_0x006f
        L_0x021e:
            r10 = r0
            r11 = r1
            java.lang.String r11 = r11.rawname
            int r10 = r10.getIndexFast(r11)
            r4 = r10
            goto L_0x006f
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.util.XMLAttributesImpl.addAttribute(org.apache.xerces.xni.QName, java.lang.String, java.lang.String):int");
    }

    public void addAttributeNS(QName qName, String str, String str2) {
        Attribute attribute;
        QName qName2 = qName;
        String str3 = str;
        String str4 = str2;
        int i = this.fLength;
        int i2 = this.fLength;
        int i3 = i2;
        this.fLength = i2 + 1;
        if (i3 == this.fAttributes.length) {
            Attribute[] attributeArr = this.fLength < 20 ? new Attribute[(this.fAttributes.length + 4)] : new Attribute[(this.fAttributes.length << 1)];
            System.arraycopy(this.fAttributes, 0, attributeArr, 0, this.fAttributes.length);
            for (int length = this.fAttributes.length; length < attributeArr.length; length++) {
                new Attribute();
                attributeArr[length] = attribute;
            }
            this.fAttributes = attributeArr;
        }
        Attribute attribute2 = this.fAttributes[i];
        attribute2.name.setValues(qName2);
        attribute2.type = str3;
        attribute2.value = str4;
        attribute2.nonNormalizedValue = str4;
        attribute2.specified = false;
        attribute2.augs.removeAllItems();
    }

    public QName checkDuplicatesNS() {
        int i = this.fLength;
        if (i > 20) {
            return checkManyDuplicatesNS();
        }
        Attribute[] attributeArr = this.fAttributes;
        for (int i2 = 0; i2 < i - 1; i2++) {
            Attribute attribute = attributeArr[i2];
            for (int i3 = i2 + 1; i3 < i; i3++) {
                Attribute attribute2 = attributeArr[i3];
                if (attribute.name.localpart == attribute2.name.localpart && attribute.name.uri == attribute2.name.uri) {
                    return attribute2.name;
                }
            }
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public void cleanTableView() {
        int i = this.fLargeCount + 1;
        int i2 = i;
        this.fLargeCount = i;
        if (i2 < 0) {
            if (this.fAttributeTableViewChainState != null) {
                for (int i3 = this.fTableViewBuckets - 1; i3 >= 0; i3--) {
                    this.fAttributeTableViewChainState[i3] = 0;
                }
            }
            this.fLargeCount = 1;
        }
    }

    public Augmentations getAugmentations(int i) {
        int i2 = i;
        if (i2 < 0 || i2 >= this.fLength) {
            return null;
        }
        return this.fAttributes[i2].augs;
    }

    public Augmentations getAugmentations(String str) {
        int index = getIndex(str);
        return index != -1 ? this.fAttributes[index].augs : null;
    }

    public Augmentations getAugmentations(String str, String str2) {
        int index = getIndex(str, str2);
        return index != -1 ? this.fAttributes[index].augs : null;
    }

    public int getIndex(String str) {
        String str2 = str;
        for (int i = 0; i < this.fLength; i++) {
            Attribute attribute = this.fAttributes[i];
            if (attribute.name.rawname != null && attribute.name.rawname.equals(str2)) {
                return i;
            }
        }
        return -1;
    }

    public int getIndex(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        for (int i = 0; i < this.fLength; i++) {
            Attribute attribute = this.fAttributes[i];
            if (attribute.name.localpart != null && attribute.name.localpart.equals(str4) && (str3 == attribute.name.uri || (str3 != null && attribute.name.uri != null && attribute.name.uri.equals(str3)))) {
                return i;
            }
        }
        return -1;
    }

    public int getIndexFast(String str) {
        String str2 = str;
        for (int i = 0; i < this.fLength; i++) {
            if (this.fAttributes[i].name.rawname == str2) {
                return i;
            }
        }
        return -1;
    }

    public int getIndexFast(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        for (int i = 0; i < this.fLength; i++) {
            Attribute attribute = this.fAttributes[i];
            if (attribute.name.localpart == str4 && attribute.name.uri == str3) {
                return i;
            }
        }
        return -1;
    }

    public int getLength() {
        return this.fLength;
    }

    public String getLocalName(int i) {
        int i2 = i;
        if (!this.fNamespaces) {
            return "";
        }
        if (i2 < 0 || i2 >= this.fLength) {
            return null;
        }
        return this.fAttributes[i2].name.localpart;
    }

    public String getName(int i) {
        int i2 = i;
        if (i2 < 0 || i2 >= this.fLength) {
            return null;
        }
        return this.fAttributes[i2].name.rawname;
    }

    public void getName(int i, QName qName) {
        qName.setValues(this.fAttributes[i].name);
    }

    public String getNonNormalizedValue(int i) {
        return this.fAttributes[i].nonNormalizedValue;
    }

    public String getPrefix(int i) {
        int i2 = i;
        if (i2 < 0 || i2 >= this.fLength) {
            return null;
        }
        String str = this.fAttributes[i2].name.prefix;
        return str != null ? str : "";
    }

    public String getQName(int i) {
        int i2 = i;
        if (i2 < 0 || i2 >= this.fLength) {
            return null;
        }
        String str = this.fAttributes[i2].name.rawname;
        return str != null ? str : "";
    }

    /* access modifiers changed from: protected */
    public int getTableViewBucket(String str) {
        return (hash(str) & ASContentModel.AS_UNBOUNDED) % this.fTableViewBuckets;
    }

    /* access modifiers changed from: protected */
    public int getTableViewBucket(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        return str4 == null ? (hash(str3) & ASContentModel.AS_UNBOUNDED) % this.fTableViewBuckets : (hash(str3, str4) & ASContentModel.AS_UNBOUNDED) % this.fTableViewBuckets;
    }

    public String getType(int i) {
        int i2 = i;
        if (i2 < 0 || i2 >= this.fLength) {
            return null;
        }
        return getReportableType(this.fAttributes[i2].type);
    }

    public String getType(String str) {
        int index = getIndex(str);
        return index != -1 ? getReportableType(this.fAttributes[index].type) : null;
    }

    public String getType(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        if (!this.fNamespaces) {
            return null;
        }
        int index = getIndex(str3, str4);
        return index != -1 ? getReportableType(this.fAttributes[index].type) : null;
    }

    public String getURI(int i) {
        int i2 = i;
        if (i2 < 0 || i2 >= this.fLength) {
            return null;
        }
        return this.fAttributes[i2].name.uri;
    }

    public String getValue(int i) {
        int i2 = i;
        if (i2 < 0 || i2 >= this.fLength) {
            return null;
        }
        return this.fAttributes[i2].value;
    }

    public String getValue(String str) {
        int index = getIndex(str);
        return index != -1 ? this.fAttributes[index].value : null;
    }

    public String getValue(String str, String str2) {
        int index = getIndex(str, str2);
        return index != -1 ? getValue(index) : null;
    }

    public boolean isSpecified(int i) {
        return this.fAttributes[i].specified;
    }

    /* access modifiers changed from: protected */
    public void prepareAndPopulateTableView() {
        prepareAndPopulateTableView(this.fLength);
    }

    /* access modifiers changed from: protected */
    public void prepareTableView() {
        if (this.fLength > this.fTableViewBuckets) {
            growTableView();
        }
        if (this.fAttributeTableView == null) {
            this.fAttributeTableView = new Attribute[this.fTableViewBuckets];
            this.fAttributeTableViewChainState = new int[this.fTableViewBuckets];
            return;
        }
        cleanTableView();
    }

    public void removeAllAttributes() {
        this.fLength = 0;
    }

    public void removeAttributeAt(int i) {
        int i2 = i;
        this.fIsTableViewConsistent = false;
        if (i2 < this.fLength - 1) {
            Attribute attribute = this.fAttributes[i2];
            System.arraycopy(this.fAttributes, i2 + 1, this.fAttributes, i2, (this.fLength - i2) - 1);
            this.fAttributes[this.fLength - 1] = attribute;
        }
        this.fLength--;
    }

    public void setAugmentations(int i, Augmentations augmentations) {
        this.fAttributes[i].augs = augmentations;
    }

    public void setName(int i, QName qName) {
        this.fAttributes[i].name.setValues(qName);
    }

    public void setNamespaces(boolean z) {
        boolean z2 = z;
        this.fNamespaces = z2;
    }

    public void setNonNormalizedValue(int i, String str) {
        int i2 = i;
        String str2 = str;
        if (str2 == null) {
            str2 = this.fAttributes[i2].value;
        }
        this.fAttributes[i2].nonNormalizedValue = str2;
    }

    public void setSpecified(int i, boolean z) {
        this.fAttributes[i].specified = z;
    }

    public void setType(int i, String str) {
        this.fAttributes[i].type = str;
    }

    public void setURI(int i, String str) {
        String str2 = str;
        this.fAttributes[i].name.uri = str2;
    }

    public void setValue(int i, String str) {
        String str2 = str;
        Attribute attribute = this.fAttributes[i];
        attribute.value = str2;
        attribute.nonNormalizedValue = str2;
    }
}
