package org.apache.xerces.util;

import java.io.IOException;
import javax.xml.parsers.SAXParserFactory;
import org.apache.xerces.dom.DOMInputImpl;
import org.apache.xerces.jaxp.SAXParserFactoryImpl;
import org.apache.xerces.util.URI;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xml.resolver.Catalog;
import org.apache.xml.resolver.CatalogManager;
import org.apache.xml.resolver.readers.SAXCatalogReader;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSResourceResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.ext.EntityResolver2;

public class XMLCatalogResolver implements XMLEntityResolver, EntityResolver2, LSResourceResolver {
    private Catalog fCatalog;
    private boolean fCatalogsChanged;
    private String[] fCatalogsList;
    private boolean fPreferPublic;
    private CatalogManager fResolverCatalogManager;
    private boolean fUseLiteralSystemId;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XMLCatalogResolver() {
        this((String[]) null, true);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XMLCatalogResolver(String[] strArr) {
        this(strArr, true);
    }

    public XMLCatalogResolver(String[] strArr, boolean z) {
        this.fResolverCatalogManager = null;
        this.fCatalog = null;
        this.fCatalogsList = null;
        this.fCatalogsChanged = true;
        this.fPreferPublic = true;
        this.fUseLiteralSystemId = true;
        init(strArr, z);
    }

    private void attachReaderToCatalog(Catalog catalog) {
        SAXParserFactory sAXParserFactory;
        SAXCatalogReader sAXCatalogReader;
        new SAXParserFactoryImpl();
        SAXParserFactory sAXParserFactory2 = sAXParserFactory;
        sAXParserFactory2.setNamespaceAware(true);
        sAXParserFactory2.setValidating(false);
        new SAXCatalogReader(sAXParserFactory2);
        SAXCatalogReader sAXCatalogReader2 = sAXCatalogReader;
        sAXCatalogReader2.setCatalogParser("urn:oasis:names:tc:entity:xmlns:xml:catalog", "catalog", "org.apache.xml.resolver.readers.OASISXMLCatalogReader");
        catalog.addReader("application/xml", sAXCatalogReader2);
    }

    private void init(String[] strArr, boolean z) {
        CatalogManager catalogManager;
        String[] strArr2 = strArr;
        boolean z2 = z;
        this.fCatalogsList = strArr2 != null ? (String[]) strArr2.clone() : null;
        this.fPreferPublic = z2;
        new CatalogManager();
        this.fResolverCatalogManager = catalogManager;
        this.fResolverCatalogManager.setAllowOasisXMLCatalogPI(false);
        this.fResolverCatalogManager.setCatalogClassName("org.apache.xml.resolver.Catalog");
        this.fResolverCatalogManager.setCatalogFiles("");
        this.fResolverCatalogManager.setIgnoreMissingProperties(true);
        this.fResolverCatalogManager.setPreferPublic(this.fPreferPublic);
        this.fResolverCatalogManager.setRelativeCatalogs(false);
        this.fResolverCatalogManager.setUseStaticCatalog(false);
        this.fResolverCatalogManager.setVerbosity(0);
    }

    private void parseCatalogs() throws IOException {
        Catalog catalog;
        if (this.fCatalogsList != null) {
            new Catalog(this.fResolverCatalogManager);
            this.fCatalog = catalog;
            attachReaderToCatalog(this.fCatalog);
            for (int i = 0; i < this.fCatalogsList.length; i++) {
                String str = this.fCatalogsList[i];
                if (str != null && str.length() > 0) {
                    this.fCatalog.parseCatalog(str);
                }
            }
            return;
        }
        this.fCatalog = null;
    }

    public final synchronized void clear() {
        synchronized (this) {
            this.fCatalog = null;
        }
    }

    public final synchronized String[] getCatalogList() {
        String[] strArr;
        synchronized (this) {
            strArr = this.fCatalogsList != null ? (String[]) this.fCatalogsList.clone() : null;
        }
        return strArr;
    }

    public InputSource getExternalSubset(String str, String str2) throws SAXException, IOException {
        String str3 = str;
        String str4 = str2;
        return null;
    }

    public final boolean getPreferPublic() {
        return this.fPreferPublic;
    }

    public final boolean getUseLiteralSystemId() {
        return this.fUseLiteralSystemId;
    }

    public XMLInputSource resolveEntity(XMLResourceIdentifier xMLResourceIdentifier) throws XNIException, IOException {
        XMLInputSource xMLInputSource;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String resolveIdentifier = resolveIdentifier(xMLResourceIdentifier2);
        if (resolveIdentifier == null) {
            return null;
        }
        new XMLInputSource(xMLResourceIdentifier2.getPublicId(), resolveIdentifier, xMLResourceIdentifier2.getBaseSystemId());
        return xMLInputSource;
    }

    public InputSource resolveEntity(String str, String str2) throws SAXException, IOException {
        InputSource inputSource;
        String str3 = str;
        String str4 = str2;
        String str5 = null;
        if (str3 != null && str4 != null) {
            str5 = resolvePublic(str3, str4);
        } else if (str4 != null) {
            str5 = resolveSystem(str4);
        }
        if (str5 == null) {
            return null;
        }
        new InputSource(str5);
        InputSource inputSource2 = inputSource;
        inputSource2.setPublicId(str3);
        return inputSource2;
    }

    public InputSource resolveEntity(String str, String str2, String str3, String str4) throws SAXException, IOException {
        InputSource inputSource;
        URI uri;
        URI uri2;
        String str5 = str;
        String str6 = str2;
        String str7 = str3;
        String str8 = str4;
        String str9 = null;
        if (!getUseLiteralSystemId() && str7 != null) {
            try {
                new URI(str7);
                new URI(uri2, str8);
                str8 = uri.toString();
            } catch (URI.MalformedURIException e) {
                URI.MalformedURIException malformedURIException = e;
            }
        }
        if (str6 != null && str8 != null) {
            str9 = resolvePublic(str6, str8);
        } else if (str8 != null) {
            str9 = resolveSystem(str8);
        }
        if (str9 == null) {
            return null;
        }
        new InputSource(str9);
        InputSource inputSource2 = inputSource;
        inputSource2.setPublicId(str6);
        return inputSource2;
    }

    public String resolveIdentifier(XMLResourceIdentifier xMLResourceIdentifier) throws IOException, XNIException {
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String str = null;
        String namespace = xMLResourceIdentifier2.getNamespace();
        if (namespace != null) {
            str = resolveURI(namespace);
        }
        if (str == null) {
            String publicId = xMLResourceIdentifier2.getPublicId();
            String literalSystemId = getUseLiteralSystemId() ? xMLResourceIdentifier2.getLiteralSystemId() : xMLResourceIdentifier2.getExpandedSystemId();
            if (publicId != null && literalSystemId != null) {
                str = resolvePublic(publicId, literalSystemId);
            } else if (literalSystemId != null) {
                str = resolveSystem(literalSystemId);
            }
        }
        return str;
    }

    public final synchronized String resolvePublic(String str, String str2) throws IOException {
        String resolvePublic;
        String str3 = str;
        String str4 = str2;
        synchronized (this) {
            if (this.fCatalogsChanged) {
                parseCatalogs();
                this.fCatalogsChanged = false;
            }
            resolvePublic = this.fCatalog != null ? this.fCatalog.resolvePublic(str3, str4) : null;
        }
        return resolvePublic;
    }

    public LSInput resolveResource(String str, String str2, String str3, String str4, String str5) {
        LSInput lSInput;
        URI uri;
        URI uri2;
        String str6 = str;
        String str7 = str2;
        String str8 = str3;
        String str9 = str4;
        String str10 = str5;
        String str11 = null;
        if (str7 != null) {
            try {
                str11 = resolveURI(str7);
            } catch (IOException e) {
                IOException iOException = e;
            }
        }
        if (!getUseLiteralSystemId() && str10 != null) {
            try {
                new URI(str10);
                new URI(uri2, str9);
                str9 = uri.toString();
            } catch (URI.MalformedURIException e2) {
                URI.MalformedURIException malformedURIException = e2;
            }
        }
        if (str11 == null) {
            if (str8 != null && str9 != null) {
                str11 = resolvePublic(str8, str9);
            } else if (str9 != null) {
                str11 = resolveSystem(str9);
            }
        }
        if (str11 == null) {
            return null;
        }
        new DOMInputImpl(str8, str11, str10);
        return lSInput;
    }

    public final synchronized String resolveSystem(String str) throws IOException {
        String resolveSystem;
        String str2 = str;
        synchronized (this) {
            if (this.fCatalogsChanged) {
                parseCatalogs();
                this.fCatalogsChanged = false;
            }
            resolveSystem = this.fCatalog != null ? this.fCatalog.resolveSystem(str2) : null;
        }
        return resolveSystem;
    }

    public final synchronized String resolveURI(String str) throws IOException {
        String resolveURI;
        String str2 = str;
        synchronized (this) {
            if (this.fCatalogsChanged) {
                parseCatalogs();
                this.fCatalogsChanged = false;
            }
            resolveURI = this.fCatalog != null ? this.fCatalog.resolveURI(str2) : null;
        }
        return resolveURI;
    }

    public final synchronized void setCatalogList(String[] strArr) {
        String[] strArr2 = strArr;
        synchronized (this) {
            this.fCatalogsChanged = true;
            this.fCatalogsList = strArr2 != null ? (String[]) strArr2.clone() : null;
        }
    }

    public final void setPreferPublic(boolean z) {
        boolean z2 = z;
        this.fPreferPublic = z2;
        this.fResolverCatalogManager.setPreferPublic(z2);
    }

    public final void setUseLiteralSystemId(boolean z) {
        boolean z2 = z;
        this.fUseLiteralSystemId = z2;
    }
}
