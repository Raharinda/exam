package org.apache.xerces.util;

import java.io.IOException;
import java.io.Serializable;
import java.util.Locale;
import net.lingala.zip4j.util.InternalZipConstants;

public class URI implements Serializable {
    private static final int ASCII_ALPHA_CHARACTERS = 16;
    private static final int ASCII_DIGIT_CHARACTERS = 32;
    private static final int ASCII_HEX_CHARACTERS = 64;
    private static final int MARK_CHARACTERS = 2;
    private static final int MASK_ALPHA_NUMERIC = 48;
    private static final int MASK_PATH_CHARACTER = 178;
    private static final int MASK_SCHEME_CHARACTER = 52;
    private static final int MASK_UNRESERVED_MASK = 50;
    private static final int MASK_URI_CHARACTER = 51;
    private static final int MASK_USERINFO_CHARACTER = 58;
    private static final int PATH_CHARACTERS = 128;
    private static final int RESERVED_CHARACTERS = 1;
    private static final int SCHEME_CHARACTERS = 4;
    private static final int USERINFO_CHARACTERS = 8;
    private static final byte[] fgLookupTable = new byte[128];
    static final long serialVersionUID = 1601921774685357214L;
    private String m_fragment;
    private String m_host;
    private String m_path;
    private int m_port;
    private String m_queryString;
    private String m_regAuthority;
    private String m_scheme;
    private String m_userinfo;

    public static class MalformedURIException extends IOException {
        static final long serialVersionUID = -6695054834342951930L;

        public MalformedURIException() {
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public MalformedURIException(String str) {
            super(str);
        }
    }

    static {
        for (int i = 48; i <= 57; i++) {
            byte[] bArr = fgLookupTable;
            int i2 = i;
            bArr[i2] = (byte) (bArr[i2] | 96);
        }
        for (int i3 = 65; i3 <= 70; i3++) {
            byte[] bArr2 = fgLookupTable;
            int i4 = i3;
            bArr2[i4] = (byte) (bArr2[i4] | 80);
            byte[] bArr3 = fgLookupTable;
            int i5 = i3 + 32;
            bArr3[i5] = (byte) (bArr3[i5] | 80);
        }
        for (int i6 = 71; i6 <= 90; i6++) {
            byte[] bArr4 = fgLookupTable;
            int i7 = i6;
            bArr4[i7] = (byte) (bArr4[i7] | 16);
            byte[] bArr5 = fgLookupTable;
            int i8 = i6 + 32;
            bArr5[i8] = (byte) (bArr5[i8] | 16);
        }
        byte[] bArr6 = fgLookupTable;
        bArr6[59] = (byte) (bArr6[59] | 1);
        byte[] bArr7 = fgLookupTable;
        bArr7[47] = (byte) (bArr7[47] | 1);
        byte[] bArr8 = fgLookupTable;
        bArr8[63] = (byte) (bArr8[63] | 1);
        byte[] bArr9 = fgLookupTable;
        bArr9[58] = (byte) (bArr9[58] | 1);
        byte[] bArr10 = fgLookupTable;
        bArr10[64] = (byte) (bArr10[64] | 1);
        byte[] bArr11 = fgLookupTable;
        bArr11[38] = (byte) (bArr11[38] | 1);
        byte[] bArr12 = fgLookupTable;
        bArr12[61] = (byte) (bArr12[61] | 1);
        byte[] bArr13 = fgLookupTable;
        bArr13[43] = (byte) (bArr13[43] | 1);
        byte[] bArr14 = fgLookupTable;
        bArr14[36] = (byte) (bArr14[36] | 1);
        byte[] bArr15 = fgLookupTable;
        bArr15[44] = (byte) (bArr15[44] | 1);
        byte[] bArr16 = fgLookupTable;
        bArr16[91] = (byte) (bArr16[91] | 1);
        byte[] bArr17 = fgLookupTable;
        bArr17[93] = (byte) (bArr17[93] | 1);
        byte[] bArr18 = fgLookupTable;
        bArr18[45] = (byte) (bArr18[45] | 2);
        byte[] bArr19 = fgLookupTable;
        bArr19[95] = (byte) (bArr19[95] | 2);
        byte[] bArr20 = fgLookupTable;
        bArr20[46] = (byte) (bArr20[46] | 2);
        byte[] bArr21 = fgLookupTable;
        bArr21[33] = (byte) (bArr21[33] | 2);
        byte[] bArr22 = fgLookupTable;
        bArr22[126] = (byte) (bArr22[126] | 2);
        byte[] bArr23 = fgLookupTable;
        bArr23[42] = (byte) (bArr23[42] | 2);
        byte[] bArr24 = fgLookupTable;
        bArr24[39] = (byte) (bArr24[39] | 2);
        byte[] bArr25 = fgLookupTable;
        bArr25[40] = (byte) (bArr25[40] | 2);
        byte[] bArr26 = fgLookupTable;
        bArr26[41] = (byte) (bArr26[41] | 2);
        byte[] bArr27 = fgLookupTable;
        bArr27[43] = (byte) (bArr27[43] | 4);
        byte[] bArr28 = fgLookupTable;
        bArr28[45] = (byte) (bArr28[45] | 4);
        byte[] bArr29 = fgLookupTable;
        bArr29[46] = (byte) (bArr29[46] | 4);
        byte[] bArr30 = fgLookupTable;
        bArr30[59] = (byte) (bArr30[59] | 8);
        byte[] bArr31 = fgLookupTable;
        bArr31[58] = (byte) (bArr31[58] | 8);
        byte[] bArr32 = fgLookupTable;
        bArr32[38] = (byte) (bArr32[38] | 8);
        byte[] bArr33 = fgLookupTable;
        bArr33[61] = (byte) (bArr33[61] | 8);
        byte[] bArr34 = fgLookupTable;
        bArr34[43] = (byte) (bArr34[43] | 8);
        byte[] bArr35 = fgLookupTable;
        bArr35[36] = (byte) (bArr35[36] | 8);
        byte[] bArr36 = fgLookupTable;
        bArr36[44] = (byte) (bArr36[44] | 8);
        byte[] bArr37 = fgLookupTable;
        bArr37[59] = (byte) (bArr37[59] | 128);
        byte[] bArr38 = fgLookupTable;
        bArr38[47] = (byte) (bArr38[47] | 128);
        byte[] bArr39 = fgLookupTable;
        bArr39[58] = (byte) (bArr39[58] | 128);
        byte[] bArr40 = fgLookupTable;
        bArr40[64] = (byte) (bArr40[64] | 128);
        byte[] bArr41 = fgLookupTable;
        bArr41[38] = (byte) (bArr41[38] | 128);
        byte[] bArr42 = fgLookupTable;
        bArr42[61] = (byte) (bArr42[61] | 128);
        byte[] bArr43 = fgLookupTable;
        bArr43[43] = (byte) (bArr43[43] | 128);
        byte[] bArr44 = fgLookupTable;
        bArr44[36] = (byte) (bArr44[36] | 128);
        byte[] bArr45 = fgLookupTable;
        bArr45[44] = (byte) (bArr45[44] | 128);
    }

    public URI() {
        this.m_scheme = null;
        this.m_userinfo = null;
        this.m_host = null;
        this.m_port = -1;
        this.m_regAuthority = null;
        this.m_path = null;
        this.m_queryString = null;
        this.m_fragment = null;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public URI(String str) throws MalformedURIException {
        this((URI) null, str);
    }

    public URI(String str, String str2) throws MalformedURIException {
        Throwable th;
        Throwable th2;
        String str3 = str;
        String str4 = str2;
        this.m_scheme = null;
        this.m_userinfo = null;
        this.m_host = null;
        this.m_port = -1;
        this.m_regAuthority = null;
        this.m_path = null;
        this.m_queryString = null;
        this.m_fragment = null;
        if (str3 == null || str3.trim().length() == 0) {
            Throwable th3 = th;
            new MalformedURIException("Cannot construct URI with null/empty scheme!");
            throw th3;
        } else if (str4 == null || str4.trim().length() == 0) {
            Throwable th4 = th2;
            new MalformedURIException("Cannot construct URI with null/empty scheme-specific part!");
            throw th4;
        } else {
            setScheme(str3);
            setPath(str4);
        }
    }

    public URI(String str, String str2, String str3, int i, String str4, String str5, String str6) throws MalformedURIException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        String str7 = str;
        String str8 = str2;
        String str9 = str3;
        int i2 = i;
        String str10 = str4;
        String str11 = str5;
        String str12 = str6;
        this.m_scheme = null;
        this.m_userinfo = null;
        this.m_host = null;
        this.m_port = -1;
        this.m_regAuthority = null;
        this.m_path = null;
        this.m_queryString = null;
        this.m_fragment = null;
        if (str7 == null || str7.trim().length() == 0) {
            Throwable th6 = th;
            new MalformedURIException("Scheme is required!");
            throw th6;
        }
        if (str9 == null) {
            if (str8 != null) {
                Throwable th7 = th5;
                new MalformedURIException("Userinfo may not be specified if host is not specified!");
                throw th7;
            } else if (i2 != -1) {
                Throwable th8 = th4;
                new MalformedURIException("Port may not be specified if host is not specified!");
                throw th8;
            }
        }
        if (str10 != null) {
            if (str10.indexOf(63) != -1 && str11 != null) {
                Throwable th9 = th3;
                new MalformedURIException("Query string cannot be specified in path and query string!");
                throw th9;
            } else if (!(str10.indexOf(35) == -1 || str12 == null)) {
                Throwable th10 = th2;
                new MalformedURIException("Fragment cannot be specified in both the path and fragment!");
                throw th10;
            }
        }
        setScheme(str7);
        setHost(str9);
        setPort(i2);
        setUserinfo(str8);
        setPath(str10);
        setQueryString(str11);
        setFragment(str12);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public URI(String str, String str2, String str3, String str4, String str5) throws MalformedURIException {
        this(str, (String) null, str2, -1, str3, str4, str5);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public URI(String str, boolean z) throws MalformedURIException {
        this((URI) null, str, z);
    }

    public URI(URI uri) {
        this.m_scheme = null;
        this.m_userinfo = null;
        this.m_host = null;
        this.m_port = -1;
        this.m_regAuthority = null;
        this.m_path = null;
        this.m_queryString = null;
        this.m_fragment = null;
        initialize(uri);
    }

    public URI(URI uri, String str) throws MalformedURIException {
        this.m_scheme = null;
        this.m_userinfo = null;
        this.m_host = null;
        this.m_port = -1;
        this.m_regAuthority = null;
        this.m_path = null;
        this.m_queryString = null;
        this.m_fragment = null;
        initialize(uri, str);
    }

    public URI(URI uri, String str, boolean z) throws MalformedURIException {
        this.m_scheme = null;
        this.m_userinfo = null;
        this.m_host = null;
        this.m_port = -1;
        this.m_regAuthority = null;
        this.m_path = null;
        this.m_queryString = null;
        this.m_fragment = null;
        initialize(uri, str, z);
    }

    private void initialize(URI uri) {
        URI uri2 = uri;
        this.m_scheme = uri2.getScheme();
        this.m_userinfo = uri2.getUserinfo();
        this.m_host = uri2.getHost();
        this.m_port = uri2.getPort();
        this.m_regAuthority = uri2.getRegBasedAuthority();
        this.m_path = uri2.getPath();
        this.m_queryString = uri2.getQueryString();
        this.m_fragment = uri2.getFragment();
    }

    private void initialize(URI uri, String str) throws MalformedURIException {
        int i;
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        URI uri2 = uri;
        String str2 = str;
        int length = str2 != null ? str2.length() : 0;
        if (uri2 == null && length == 0) {
            Throwable th5 = th4;
            new MalformedURIException("Cannot initialize URI with empty parameters.");
            throw th5;
        } else if (length == 0) {
            initialize(uri2);
        } else {
            int i2 = 0;
            int indexOf = str2.indexOf(58);
            if (indexOf != -1) {
                int i3 = indexOf - 1;
                int lastIndexOf = str2.lastIndexOf(47, i3);
                int lastIndexOf2 = str2.lastIndexOf(63, i3);
                int lastIndexOf3 = str2.lastIndexOf(35, i3);
                if (indexOf != 0 && lastIndexOf == -1 && lastIndexOf2 == -1 && lastIndexOf3 == -1) {
                    initializeScheme(str2);
                    i2 = this.m_scheme.length() + 1;
                    if (indexOf == length - 1 || str2.charAt(indexOf + 1) == '#') {
                        Throwable th6 = th3;
                        new MalformedURIException("Scheme specific part cannot be empty.");
                        throw th6;
                    }
                } else if (indexOf == 0 || (uri2 == null && lastIndexOf3 != 0)) {
                    Throwable th7 = th2;
                    new MalformedURIException("No scheme found in URI.");
                    throw th7;
                }
            } else if (uri2 == null && str2.indexOf(35) != 0) {
                Throwable th8 = th;
                new MalformedURIException("No scheme found in URI.");
                throw th8;
            }
            if (i + 1 < length && str2.charAt(i) == '/' && str2.charAt(i + 1) == '/') {
                i += 2;
                int i4 = i;
                while (i < length && (r8 = str2.charAt(i)) != '/' && r8 != '?' && r8 != '#') {
                    i++;
                }
                if (i <= i4) {
                    this.m_host = "";
                } else if (!initializeAuthority(str2.substring(i4, i))) {
                    i = i4 - 2;
                }
            }
            initializePath(str2, i);
            if (uri2 != null) {
                absolutize(uri2);
            }
        }
    }

    private void initialize(URI uri, String str, boolean z) throws MalformedURIException {
        int i;
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        URI uri2 = uri;
        boolean z2 = z;
        String str2 = str;
        int length = str2 != null ? str2.length() : 0;
        if (uri2 == null && length == 0) {
            if (z2) {
                this.m_path = "";
                return;
            }
            Throwable th5 = th4;
            new MalformedURIException("Cannot initialize URI with empty parameters.");
            throw th5;
        } else if (length == 0) {
            initialize(uri2);
        } else {
            int i2 = 0;
            int indexOf = str2.indexOf(58);
            if (indexOf != -1) {
                int i3 = indexOf - 1;
                int lastIndexOf = str2.lastIndexOf(47, i3);
                int lastIndexOf2 = str2.lastIndexOf(63, i3);
                int lastIndexOf3 = str2.lastIndexOf(35, i3);
                if (indexOf != 0 && lastIndexOf == -1 && lastIndexOf2 == -1 && lastIndexOf3 == -1) {
                    initializeScheme(str2);
                    i2 = this.m_scheme.length() + 1;
                    if (indexOf == length - 1 || str2.charAt(indexOf + 1) == '#') {
                        Throwable th6 = th3;
                        new MalformedURIException("Scheme specific part cannot be empty.");
                        throw th6;
                    }
                } else if (indexOf == 0 || (uri2 == null && lastIndexOf3 != 0 && !z2)) {
                    Throwable th7 = th2;
                    new MalformedURIException("No scheme found in URI.");
                    throw th7;
                }
            } else if (uri2 == null && str2.indexOf(35) != 0 && !z2) {
                Throwable th8 = th;
                new MalformedURIException("No scheme found in URI.");
                throw th8;
            }
            if (i + 1 < length && str2.charAt(i) == '/' && str2.charAt(i + 1) == '/') {
                i += 2;
                int i4 = i;
                while (i < length && (r9 = str2.charAt(i)) != '/' && r9 != '?' && r9 != '#') {
                    i++;
                }
                if (i <= i4) {
                    this.m_host = "";
                } else if (!initializeAuthority(str2.substring(i4, i))) {
                    i = i4 - 2;
                }
            }
            initializePath(str2, i);
            if (uri2 != null) {
                absolutize(uri2);
            }
        }
    }

    private boolean initializeAuthority(String str) {
        String str2 = str;
        int i = 0;
        int length = str2.length();
        String str3 = null;
        if (str2.indexOf(64, 0) != -1) {
            while (i < length && str2.charAt(i) != '@') {
                i++;
            }
            str3 = str2.substring(0, i);
            i++;
        }
        int i2 = i;
        boolean z = false;
        if (i < length) {
            if (str2.charAt(i2) == '[') {
                int indexOf = str2.indexOf(93, i2);
                int i3 = indexOf != -1 ? indexOf : length;
                if (i3 + 1 >= length || str2.charAt(i3 + 1) != ':') {
                    i = length;
                } else {
                    i = i3 + 1;
                    z = true;
                }
            } else {
                int lastIndexOf = str2.lastIndexOf(58, length);
                i = lastIndexOf > i2 ? lastIndexOf : length;
                z = i != length;
            }
        }
        String substring = str2.substring(i2, i);
        int i4 = -1;
        if (substring.length() > 0 && z) {
            int i5 = i + 1;
            int i6 = i5;
            while (i5 < length) {
                i5++;
            }
            String substring2 = str2.substring(i6, i5);
            if (substring2.length() > 0) {
                try {
                    i4 = Integer.parseInt(substring2);
                    if (i4 == -1) {
                        i4--;
                    }
                } catch (NumberFormatException e) {
                    NumberFormatException numberFormatException = e;
                    i4 = -2;
                }
            }
        }
        if (isValidServerBasedAuthority(substring, i4, str3)) {
            this.m_host = substring;
            this.m_port = i4;
            this.m_userinfo = str3;
            return true;
        } else if (!isValidRegistryBasedAuthority(str2)) {
            return false;
        } else {
            this.m_regAuthority = str2;
            return true;
        }
    }

    private void initializePath(String str, int i) throws MalformedURIException {
        int i2;
        Throwable th;
        StringBuffer stringBuffer;
        Throwable th2;
        Throwable th3;
        StringBuffer stringBuffer2;
        Throwable th4;
        Throwable th5;
        StringBuffer stringBuffer3;
        Throwable th6;
        Throwable th7;
        StringBuffer stringBuffer4;
        Throwable th8;
        Throwable th9;
        String str2 = str;
        int i3 = i;
        if (str2 == null) {
            Throwable th10 = th9;
            new MalformedURIException("Cannot initialize path from null string!");
            throw th10;
        }
        int i4 = i3;
        int i5 = i3;
        int length = str2.length();
        char c = 0;
        if (i5 < length) {
            if (getScheme() != null && str2.charAt(i5) != '/') {
                while (i4 < length) {
                    c = str2.charAt(i4);
                    if (c == '?' || c == '#') {
                        break;
                    }
                    if (c == '%') {
                        if (i4 + 2 >= length || !isHex(str2.charAt(i4 + 1)) || !isHex(str2.charAt(i4 + 2))) {
                            Throwable th11 = th8;
                            new MalformedURIException("Opaque part contains invalid escape sequence!");
                            throw th11;
                        }
                        i4 += 2;
                    } else if (!isURICharacter(c)) {
                        Throwable th12 = th7;
                        new StringBuffer();
                        new MalformedURIException(stringBuffer4.append("Opaque part contains invalid character: ").append(c).toString());
                        throw th12;
                    }
                    i4++;
                }
            } else {
                while (true) {
                    if (i4 >= length) {
                        break;
                    }
                    c = str2.charAt(i4);
                    if (c == '%') {
                        if (i4 + 2 >= length || !isHex(str2.charAt(i4 + 1)) || !isHex(str2.charAt(i4 + 2))) {
                            Throwable th13 = th6;
                            new MalformedURIException("Path contains invalid escape sequence!");
                        } else {
                            i4 += 2;
                        }
                    } else if (!isPathCharacter(c)) {
                        if (c != '?' && c != '#') {
                            Throwable th14 = th5;
                            new StringBuffer();
                            new MalformedURIException(stringBuffer3.append("Path contains invalid character: ").append(c).toString());
                            throw th14;
                        }
                    }
                    i4++;
                }
                Throwable th132 = th6;
                new MalformedURIException("Path contains invalid escape sequence!");
                throw th132;
            }
        }
        this.m_path = str2.substring(i5, i2);
        if (c == '?') {
            i2++;
            int i6 = i2;
            while (i2 < length) {
                c = str2.charAt(i2);
                if (c == '#') {
                    break;
                }
                if (c == '%') {
                    if (i2 + 2 >= length || !isHex(str2.charAt(i2 + 1)) || !isHex(str2.charAt(i2 + 2))) {
                        Throwable th15 = th4;
                        new MalformedURIException("Query string contains invalid escape sequence!");
                        throw th15;
                    }
                    i2 += 2;
                } else if (!isURICharacter(c)) {
                    Throwable th16 = th3;
                    new StringBuffer();
                    new MalformedURIException(stringBuffer2.append("Query string contains invalid character: ").append(c).toString());
                    throw th16;
                }
                i2++;
            }
            this.m_queryString = str2.substring(i6, i2);
        }
        if (c == '#') {
            int i7 = i2 + 1;
            int i8 = i7;
            while (i7 < length) {
                char charAt = str2.charAt(i7);
                if (charAt == '%') {
                    if (i7 + 2 >= length || !isHex(str2.charAt(i7 + 1)) || !isHex(str2.charAt(i7 + 2))) {
                        Throwable th17 = th2;
                        new MalformedURIException("Fragment contains invalid escape sequence!");
                        throw th17;
                    }
                    i7 += 2;
                } else if (!isURICharacter(charAt)) {
                    Throwable th18 = th;
                    new StringBuffer();
                    new MalformedURIException(stringBuffer.append("Fragment contains invalid character: ").append(charAt).toString());
                    throw th18;
                }
                i7++;
            }
            this.m_fragment = str2.substring(i8, i7);
        }
    }

    private void initializeScheme(String str) throws MalformedURIException {
        Throwable th;
        String str2 = str;
        int length = str2.length();
        int i = 0;
        while (i < length && (r5 = str2.charAt(i)) != ':' && r5 != '/' && r5 != '?' && r5 != '#') {
            i++;
        }
        String substring = str2.substring(0, i);
        if (substring.length() == 0) {
            Throwable th2 = th;
            new MalformedURIException("No scheme found in URI.");
            throw th2;
        }
        setScheme(substring);
    }

    private static boolean isAlpha(char c) {
        char c2 = c;
        return (c2 >= 'a' && c2 <= 'z') || (c2 >= 'A' && c2 <= 'Z');
    }

    private static boolean isAlphanum(char c) {
        char c2 = c;
        return c2 <= 'z' && (fgLookupTable[c2] & 48) != 0;
    }

    public static boolean isConformantSchemeName(String str) {
        String str2 = str;
        if (str2 == null || str2.trim().length() == 0) {
            return false;
        }
        if (!isAlpha(str2.charAt(0))) {
            return false;
        }
        int length = str2.length();
        for (int i = 1; i < length; i++) {
            if (!isSchemeCharacter(str2.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private static boolean isDigit(char c) {
        char c2 = c;
        return c2 >= '0' && c2 <= '9';
    }

    private static boolean isHex(char c) {
        char c2 = c;
        return c2 <= 'f' && (fgLookupTable[c2] & 64) != 0;
    }

    private static boolean isPathCharacter(char c) {
        char c2 = c;
        return c2 <= '~' && (fgLookupTable[c2] & 178) != 0;
    }

    private static boolean isReservedCharacter(char c) {
        char c2 = c;
        return c2 <= ']' && (fgLookupTable[c2] & 1) != 0;
    }

    private static boolean isSchemeCharacter(char c) {
        char c2 = c;
        return c2 <= 'z' && (fgLookupTable[c2] & 52) != 0;
    }

    private static boolean isURICharacter(char c) {
        char c2 = c;
        return c2 <= '~' && (fgLookupTable[c2] & 51) != 0;
    }

    private static boolean isURIString(String str) {
        String str2 = str;
        if (str2 == null) {
            return false;
        }
        int length = str2.length();
        int i = 0;
        while (i < length) {
            char charAt = str2.charAt(i);
            if (charAt == '%') {
                if (i + 2 >= length || !isHex(str2.charAt(i + 1)) || !isHex(str2.charAt(i + 2))) {
                    return false;
                }
                i += 2;
            } else if (!isURICharacter(charAt)) {
                return false;
            }
            i++;
        }
        return true;
    }

    private static boolean isUnreservedCharacter(char c) {
        char c2 = c;
        return c2 <= '~' && (fgLookupTable[c2] & 50) != 0;
    }

    private static boolean isUserinfoCharacter(char c) {
        char c2 = c;
        return c2 <= 'z' && (fgLookupTable[c2] & 58) != 0;
    }

    private boolean isValidRegistryBasedAuthority(String str) {
        String str2 = str;
        int i = 0;
        int length = str2.length();
        while (i < length) {
            char charAt = str2.charAt(i);
            if (charAt == '%') {
                if (i + 2 >= length || !isHex(str2.charAt(i + 1)) || !isHex(str2.charAt(i + 2))) {
                    return false;
                }
                i += 2;
            } else if (!isPathCharacter(charAt)) {
                return false;
            }
            i++;
        }
        return true;
    }

    private boolean isValidServerBasedAuthority(String str, int i, String str2) {
        int i2 = i;
        String str3 = str2;
        if (!isWellFormedAddress(str)) {
            return false;
        }
        if (i2 < -1 || i2 > 65535) {
            return false;
        }
        if (str3 != null) {
            int i3 = 0;
            int length = str3.length();
            while (i3 < length) {
                char charAt = str3.charAt(i3);
                if (charAt == '%') {
                    if (i3 + 2 >= length || !isHex(str3.charAt(i3 + 1)) || !isHex(str3.charAt(i3 + 2))) {
                        return false;
                    }
                    i3 += 2;
                } else if (!isUserinfoCharacter(charAt)) {
                    return false;
                }
                i3++;
            }
        }
        return true;
    }

    public static boolean isWellFormedAddress(String str) {
        String str2 = str;
        if (str2 == null) {
            return false;
        }
        int length = str2.length();
        if (length == 0) {
            return false;
        }
        if (str2.startsWith("[")) {
            return isWellFormedIPv6Reference(str2);
        }
        if (str2.startsWith(".") || str2.startsWith("-") || str2.endsWith("-")) {
            return false;
        }
        int lastIndexOf = str2.lastIndexOf(46);
        if (str2.endsWith(".")) {
            lastIndexOf = str2.substring(0, lastIndexOf).lastIndexOf(46);
        }
        if (lastIndexOf + 1 < length && isDigit(str2.charAt(lastIndexOf + 1))) {
            return isWellFormedIPv4Address(str2);
        }
        if (length > 255) {
            return false;
        }
        int i = 0;
        for (int i2 = 0; i2 < length; i2++) {
            char charAt = str2.charAt(i2);
            if (charAt == '.') {
                if (!isAlphanum(str2.charAt(i2 - 1))) {
                    return false;
                }
                if (i2 + 1 < length && !isAlphanum(str2.charAt(i2 + 1))) {
                    return false;
                }
                i = 0;
            } else if (!isAlphanum(charAt) && charAt != '-') {
                return false;
            } else {
                i++;
                if (i > 63) {
                    return false;
                }
            }
        }
        return true;
    }

    public static boolean isWellFormedIPv4Address(String str) {
        String str2 = str;
        int length = str2.length();
        int i = 0;
        int i2 = 0;
        for (int i3 = 0; i3 < length; i3++) {
            char charAt = str2.charAt(i3);
            if (charAt == '.') {
                if ((i3 > 0 && !isDigit(str2.charAt(i3 - 1))) || (i3 + 1 < length && !isDigit(str2.charAt(i3 + 1)))) {
                    return false;
                }
                i2 = 0;
                i++;
                if (i > 3) {
                    return false;
                }
            } else if (!isDigit(charAt)) {
                return false;
            } else {
                i2++;
                if (i2 > 3) {
                    return false;
                }
                if (i2 == 3) {
                    char charAt2 = str2.charAt(i3 - 2);
                    char charAt3 = str2.charAt(i3 - 1);
                    if (charAt2 >= '2' && (charAt2 != '2' || (charAt3 >= '5' && (charAt3 != '5' || charAt > '5')))) {
                        return false;
                    }
                } else {
                    continue;
                }
            }
        }
        return i == 3;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:45:0x00de, code lost:
        if (isWellFormedIPv4Address(r0.substring(r4[0] > r5 ? r2 + 1 : r2, r3)) != false) goto L_0x00e0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean isWellFormedIPv6Reference(java.lang.String r13) {
        /*
            r0 = r13
            r6 = r0
            int r6 = r6.length()
            r1 = r6
            r6 = 1
            r2 = r6
            r6 = r1
            r7 = 1
            int r6 = r6 + -1
            r3 = r6
            r6 = r1
            r7 = 2
            if (r6 <= r7) goto L_0x0026
            r6 = r0
            r7 = 0
            char r6 = r6.charAt(r7)
            r7 = 91
            if (r6 != r7) goto L_0x0026
            r6 = r0
            r7 = r3
            char r6 = r6.charAt(r7)
            r7 = 93
            if (r6 == r7) goto L_0x0029
        L_0x0026:
            r6 = 0
            r0 = r6
        L_0x0028:
            return r0
        L_0x0029:
            r6 = 1
            int[] r6 = new int[r6]
            r4 = r6
            r6 = r0
            r7 = r2
            r8 = r3
            r9 = r4
            int r6 = scanHexSequence(r6, r7, r8, r9)
            r2 = r6
            r6 = r2
            r7 = -1
            if (r6 != r7) goto L_0x003d
            r6 = 0
            r0 = r6
            goto L_0x0028
        L_0x003d:
            r6 = r2
            r7 = r3
            if (r6 != r7) goto L_0x004e
            r6 = r4
            r7 = 0
            r6 = r6[r7]
            r7 = 8
            if (r6 != r7) goto L_0x004c
            r6 = 1
        L_0x004a:
            r0 = r6
            goto L_0x0028
        L_0x004c:
            r6 = 0
            goto L_0x004a
        L_0x004e:
            r6 = r2
            r7 = 1
            int r6 = r6 + 1
            r7 = r3
            if (r6 >= r7) goto L_0x00af
            r6 = r0
            r7 = r2
            char r6 = r6.charAt(r7)
            r7 = 58
            if (r6 != r7) goto L_0x00af
            r6 = r0
            r7 = r2
            r8 = 1
            int r7 = r7 + 1
            char r6 = r6.charAt(r7)
            r7 = 58
            if (r6 != r7) goto L_0x0092
            r6 = r4
            r7 = 0
            r10 = r6
            r11 = r7
            r6 = r10
            r7 = r11
            r8 = r10
            r9 = r11
            r8 = r8[r9]
            r9 = 1
            int r8 = r8 + 1
            r10 = r6
            r11 = r7
            r12 = r8
            r6 = r12
            r7 = r10
            r8 = r11
            r9 = r12
            r7[r8] = r9
            r7 = 8
            if (r6 <= r7) goto L_0x0089
            r6 = 0
            r0 = r6
            goto L_0x0028
        L_0x0089:
            int r2 = r2 + 2
            r6 = r2
            r7 = r3
            if (r6 != r7) goto L_0x00b3
            r6 = 1
            r0 = r6
            goto L_0x0028
        L_0x0092:
            r6 = r4
            r7 = 0
            r6 = r6[r7]
            r7 = 6
            if (r6 != r7) goto L_0x00ad
            r6 = r0
            r7 = r2
            r8 = 1
            int r7 = r7 + 1
            r8 = r3
            java.lang.String r6 = r6.substring(r7, r8)
            boolean r6 = isWellFormedIPv4Address(r6)
            if (r6 == 0) goto L_0x00ad
            r6 = 1
        L_0x00aa:
            r0 = r6
            goto L_0x0028
        L_0x00ad:
            r6 = 0
            goto L_0x00aa
        L_0x00af:
            r6 = 0
            r0 = r6
            goto L_0x0028
        L_0x00b3:
            r6 = r4
            r7 = 0
            r6 = r6[r7]
            r5 = r6
            r6 = r0
            r7 = r2
            r8 = r3
            r9 = r4
            int r6 = scanHexSequence(r6, r7, r8, r9)
            r2 = r6
            r6 = r2
            r7 = r3
            if (r6 == r7) goto L_0x00e0
            r6 = r2
            r7 = -1
            if (r6 == r7) goto L_0x00e6
            r6 = r0
            r7 = r4
            r8 = 0
            r7 = r7[r8]
            r8 = r5
            if (r7 <= r8) goto L_0x00e4
            r7 = r2
            r8 = 1
            int r7 = r7 + 1
        L_0x00d5:
            r8 = r3
            java.lang.String r6 = r6.substring(r7, r8)
            boolean r6 = isWellFormedIPv4Address(r6)
            if (r6 == 0) goto L_0x00e6
        L_0x00e0:
            r6 = 1
        L_0x00e1:
            r0 = r6
            goto L_0x0028
        L_0x00e4:
            r7 = r2
            goto L_0x00d5
        L_0x00e6:
            r6 = 0
            goto L_0x00e1
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.util.URI.isWellFormedIPv6Reference(java.lang.String):boolean");
    }

    private static int scanHexSequence(String str, int i, int i2, int[] iArr) {
        int i3;
        String str2 = str;
        int i4 = i;
        int i5 = i2;
        int[] iArr2 = iArr;
        int i6 = 0;
        int i7 = i4;
        while (i4 < i5) {
            char charAt = str2.charAt(i4);
            if (charAt == ':') {
                if (i6 > 0) {
                    int[] iArr3 = iArr2;
                    int i8 = iArr3[0] + 1;
                    int i9 = i8;
                    iArr3[0] = i8;
                    if (i9 > 8) {
                        return -1;
                    }
                }
                if (i6 == 0 || (i4 + 1 < i5 && str2.charAt(i4 + 1) == ':')) {
                    return i4;
                }
                i6 = 0;
            } else if (isHex(charAt)) {
                i6++;
                if (i6 > 4) {
                    return -1;
                }
            } else if (charAt != '.' || i6 >= 4 || i6 <= 0 || iArr2[0] > 6) {
                return -1;
            } else {
                int i10 = (i4 - i6) - 1;
                return i10 >= i7 ? i10 : i10 + 1;
            }
            i4++;
        }
        if (i6 > 0) {
            int[] iArr4 = iArr2;
            int i11 = iArr4[0] + 1;
            int i12 = i11;
            iArr4[0] = i11;
            if (i12 <= 8) {
                i3 = i5;
                return i3;
            }
        }
        i3 = -1;
        return i3;
    }

    public void absolutize(URI uri) {
        int lastIndexOf;
        URI uri2 = uri;
        if (this.m_path.length() == 0 && this.m_scheme == null && this.m_host == null && this.m_regAuthority == null) {
            this.m_scheme = uri2.getScheme();
            this.m_userinfo = uri2.getUserinfo();
            this.m_host = uri2.getHost();
            this.m_port = uri2.getPort();
            this.m_regAuthority = uri2.getRegBasedAuthority();
            this.m_path = uri2.getPath();
            if (this.m_queryString == null) {
                this.m_queryString = uri2.getQueryString();
                if (this.m_fragment == null) {
                    this.m_fragment = uri2.getFragment();
                }
            }
        } else if (this.m_scheme == null) {
            this.m_scheme = uri2.getScheme();
            if (this.m_host == null && this.m_regAuthority == null) {
                this.m_userinfo = uri2.getUserinfo();
                this.m_host = uri2.getHost();
                this.m_port = uri2.getPort();
                this.m_regAuthority = uri2.getRegBasedAuthority();
                if (this.m_path.length() <= 0 || !this.m_path.startsWith(InternalZipConstants.ZIP_FILE_SEPARATOR)) {
                    String str = "";
                    String path = uri2.getPath();
                    if (path != null && path.length() > 0) {
                        int lastIndexOf2 = path.lastIndexOf(47);
                        if (lastIndexOf2 != -1) {
                            str = path.substring(0, lastIndexOf2 + 1);
                        }
                    } else if (this.m_path.length() > 0) {
                        str = InternalZipConstants.ZIP_FILE_SEPARATOR;
                    }
                    String concat = str.concat(this.m_path);
                    while (true) {
                        int indexOf = concat.indexOf("/./");
                        int i = indexOf;
                        if (indexOf == -1) {
                            break;
                        }
                        concat = concat.substring(0, i + 1).concat(concat.substring(i + 3));
                    }
                    if (concat.endsWith("/.")) {
                        concat = concat.substring(0, concat.length() - 1);
                    }
                    int i2 = 1;
                    while (true) {
                        int indexOf2 = concat.indexOf("/../", i2);
                        int i3 = indexOf2;
                        if (indexOf2 <= 0) {
                            break;
                        }
                        String substring = concat.substring(0, concat.indexOf("/../"));
                        int lastIndexOf3 = substring.lastIndexOf(47);
                        if (lastIndexOf3 == -1) {
                            i2 = i3 + 4;
                        } else if (!substring.substring(lastIndexOf3).equals("..")) {
                            concat = concat.substring(0, lastIndexOf3 + 1).concat(concat.substring(i3 + 4));
                            i2 = lastIndexOf3;
                        } else {
                            i2 = i3 + 4;
                        }
                    }
                    if (concat.endsWith("/..") && (lastIndexOf = concat.substring(0, concat.length() - 3).lastIndexOf(47)) != -1) {
                        concat = concat.substring(0, lastIndexOf + 1);
                    }
                    this.m_path = concat;
                }
            }
        }
    }

    public void appendPath(String str) throws MalformedURIException {
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        Throwable th;
        String str2 = str;
        if (str2 != null && str2.trim().length() != 0) {
            if (!isURIString(str2)) {
                Throwable th2 = th;
                new MalformedURIException("Path contains invalid character!");
                throw th2;
            } else if (this.m_path == null || this.m_path.trim().length() == 0) {
                if (str2.startsWith(InternalZipConstants.ZIP_FILE_SEPARATOR)) {
                    this.m_path = str2;
                    return;
                }
                new StringBuffer();
                this.m_path = stringBuffer.append(InternalZipConstants.ZIP_FILE_SEPARATOR).append(str2).toString();
            } else if (this.m_path.endsWith(InternalZipConstants.ZIP_FILE_SEPARATOR)) {
                if (str2.startsWith(InternalZipConstants.ZIP_FILE_SEPARATOR)) {
                    this.m_path = this.m_path.concat(str2.substring(1));
                    return;
                }
                this.m_path = this.m_path.concat(str2);
            } else if (str2.startsWith(InternalZipConstants.ZIP_FILE_SEPARATOR)) {
                this.m_path = this.m_path.concat(str2);
            } else {
                String str3 = this.m_path;
                new StringBuffer();
                this.m_path = str3.concat(stringBuffer2.append(InternalZipConstants.ZIP_FILE_SEPARATOR).append(str2).toString());
            }
        }
    }

    public boolean equals(Object obj) {
        Object obj2 = obj;
        if (obj2 instanceof URI) {
            URI uri = (URI) obj2;
            if (((this.m_scheme == null && uri.m_scheme == null) || !(this.m_scheme == null || uri.m_scheme == null || !this.m_scheme.equals(uri.m_scheme))) && (((this.m_userinfo == null && uri.m_userinfo == null) || !(this.m_userinfo == null || uri.m_userinfo == null || !this.m_userinfo.equals(uri.m_userinfo))) && (((this.m_host == null && uri.m_host == null) || !(this.m_host == null || uri.m_host == null || !this.m_host.equals(uri.m_host))) && this.m_port == uri.m_port && (((this.m_path == null && uri.m_path == null) || !(this.m_path == null || uri.m_path == null || !this.m_path.equals(uri.m_path))) && (((this.m_queryString == null && uri.m_queryString == null) || !(this.m_queryString == null || uri.m_queryString == null || !this.m_queryString.equals(uri.m_queryString))) && ((this.m_fragment == null && uri.m_fragment == null) || !(this.m_fragment == null || uri.m_fragment == null || !this.m_fragment.equals(uri.m_fragment)))))))) {
                return true;
            }
        }
        return false;
    }

    public String getAuthority() {
        StringBuffer stringBuffer;
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        if (!(this.m_host == null && this.m_regAuthority == null)) {
            StringBuffer append = stringBuffer2.append("//");
            if (this.m_host != null) {
                if (this.m_userinfo != null) {
                    StringBuffer append2 = stringBuffer2.append(this.m_userinfo);
                    StringBuffer append3 = stringBuffer2.append('@');
                }
                StringBuffer append4 = stringBuffer2.append(this.m_host);
                if (this.m_port != -1) {
                    StringBuffer append5 = stringBuffer2.append(':');
                    StringBuffer append6 = stringBuffer2.append(this.m_port);
                }
            } else {
                StringBuffer append7 = stringBuffer2.append(this.m_regAuthority);
            }
        }
        return stringBuffer2.toString();
    }

    public String getFragment() {
        return this.m_fragment;
    }

    public String getHost() {
        return this.m_host;
    }

    public String getPath() {
        return this.m_path;
    }

    public String getPath(boolean z, boolean z2) {
        StringBuffer stringBuffer;
        boolean z3 = z2;
        new StringBuffer(this.m_path);
        StringBuffer stringBuffer2 = stringBuffer;
        if (z && this.m_queryString != null) {
            StringBuffer append = stringBuffer2.append('?');
            StringBuffer append2 = stringBuffer2.append(this.m_queryString);
        }
        if (z3 && this.m_fragment != null) {
            StringBuffer append3 = stringBuffer2.append('#');
            StringBuffer append4 = stringBuffer2.append(this.m_fragment);
        }
        return stringBuffer2.toString();
    }

    public int getPort() {
        return this.m_port;
    }

    public String getQueryString() {
        return this.m_queryString;
    }

    public String getRegBasedAuthority() {
        return this.m_regAuthority;
    }

    public String getScheme() {
        return this.m_scheme;
    }

    public String getSchemeSpecificPart() {
        StringBuffer stringBuffer;
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        if (!(this.m_host == null && this.m_regAuthority == null)) {
            StringBuffer append = stringBuffer2.append("//");
            if (this.m_host != null) {
                if (this.m_userinfo != null) {
                    StringBuffer append2 = stringBuffer2.append(this.m_userinfo);
                    StringBuffer append3 = stringBuffer2.append('@');
                }
                StringBuffer append4 = stringBuffer2.append(this.m_host);
                if (this.m_port != -1) {
                    StringBuffer append5 = stringBuffer2.append(':');
                    StringBuffer append6 = stringBuffer2.append(this.m_port);
                }
            } else {
                StringBuffer append7 = stringBuffer2.append(this.m_regAuthority);
            }
        }
        if (this.m_path != null) {
            StringBuffer append8 = stringBuffer2.append(this.m_path);
        }
        if (this.m_queryString != null) {
            StringBuffer append9 = stringBuffer2.append('?');
            StringBuffer append10 = stringBuffer2.append(this.m_queryString);
        }
        if (this.m_fragment != null) {
            StringBuffer append11 = stringBuffer2.append('#');
            StringBuffer append12 = stringBuffer2.append(this.m_fragment);
        }
        return stringBuffer2.toString();
    }

    public String getUserinfo() {
        return this.m_userinfo;
    }

    public boolean isAbsoluteURI() {
        return this.m_scheme != null;
    }

    public boolean isGenericURI() {
        return this.m_host != null;
    }

    public void setFragment(String str) throws MalformedURIException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        if (str2 == null) {
            this.m_fragment = null;
        } else if (!isGenericURI()) {
            Throwable th4 = th3;
            new MalformedURIException("Fragment can only be set for a generic URI!");
            throw th4;
        } else if (getPath() == null) {
            Throwable th5 = th2;
            new MalformedURIException("Fragment cannot be set when path is null!");
            throw th5;
        } else if (!isURIString(str2)) {
            Throwable th6 = th;
            new MalformedURIException("Fragment contains invalid character!");
            throw th6;
        } else {
            this.m_fragment = str2;
        }
    }

    public void setHost(String str) throws MalformedURIException {
        Throwable th;
        String str2 = str;
        if (str2 == null || str2.length() == 0) {
            if (str2 != null) {
                this.m_regAuthority = null;
            }
            this.m_host = str2;
            this.m_userinfo = null;
            this.m_port = -1;
        } else if (!isWellFormedAddress(str2)) {
            Throwable th2 = th;
            new MalformedURIException("Host is not a well formed address!");
            throw th2;
        } else {
            this.m_host = str2;
            this.m_regAuthority = null;
        }
    }

    public void setPath(String str) throws MalformedURIException {
        String str2 = str;
        if (str2 == null) {
            this.m_path = null;
            this.m_queryString = null;
            this.m_fragment = null;
            return;
        }
        initializePath(str2, 0);
    }

    public void setPort(int i) throws MalformedURIException {
        Throwable th;
        Throwable th2;
        int i2 = i;
        if (i2 < 0 || i2 > 65535) {
            if (i2 != -1) {
                Throwable th3 = th;
                new MalformedURIException("Invalid port number!");
                throw th3;
            }
        } else if (this.m_host == null) {
            Throwable th4 = th2;
            new MalformedURIException("Port cannot be set when host is null!");
            throw th4;
        }
        this.m_port = i2;
    }

    public void setQueryString(String str) throws MalformedURIException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        if (str2 == null) {
            this.m_queryString = null;
        } else if (!isGenericURI()) {
            Throwable th4 = th3;
            new MalformedURIException("Query string can only be set for a generic URI!");
            throw th4;
        } else if (getPath() == null) {
            Throwable th5 = th2;
            new MalformedURIException("Query string cannot be set when path is null!");
            throw th5;
        } else if (!isURIString(str2)) {
            Throwable th6 = th;
            new MalformedURIException("Query string contains invalid character!");
            throw th6;
        } else {
            this.m_queryString = str2;
        }
    }

    public void setRegBasedAuthority(String str) throws MalformedURIException {
        Throwable th;
        String str2 = str;
        if (str2 == null) {
            this.m_regAuthority = null;
        } else if (str2.length() < 1 || !isValidRegistryBasedAuthority(str2) || str2.indexOf(47) != -1) {
            Throwable th2 = th;
            new MalformedURIException("Registry based authority is not well formed.");
            throw th2;
        } else {
            this.m_regAuthority = str2;
            this.m_host = null;
            this.m_userinfo = null;
            this.m_port = -1;
        }
    }

    public void setScheme(String str) throws MalformedURIException {
        Throwable th;
        Throwable th2;
        String str2 = str;
        if (str2 == null) {
            Throwable th3 = th2;
            new MalformedURIException("Cannot set scheme from null string!");
            throw th3;
        } else if (!isConformantSchemeName(str2)) {
            Throwable th4 = th;
            new MalformedURIException("The scheme is not conformant.");
            throw th4;
        } else {
            this.m_scheme = str2.toLowerCase(Locale.ENGLISH);
        }
    }

    public void setUserinfo(String str) throws MalformedURIException {
        Throwable th;
        StringBuffer stringBuffer;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        if (str2 == null) {
            this.m_userinfo = null;
        } else if (this.m_host == null) {
            Throwable th4 = th3;
            new MalformedURIException("Userinfo cannot be set when host is null!");
            throw th4;
        } else {
            int length = str2.length();
            for (int i = 0; i < length; i++) {
                char charAt = str2.charAt(i);
                if (charAt == '%') {
                    if (i + 2 >= length || !isHex(str2.charAt(i + 1)) || !isHex(str2.charAt(i + 2))) {
                        Throwable th5 = th2;
                        new MalformedURIException("Userinfo contains invalid escape sequence!");
                        throw th5;
                    }
                } else if (!isUserinfoCharacter(charAt)) {
                    Throwable th6 = th;
                    new StringBuffer();
                    new MalformedURIException(stringBuffer.append("Userinfo contains invalid character:").append(charAt).toString());
                    throw th6;
                }
            }
            this.m_userinfo = str2;
        }
    }

    public String toString() {
        StringBuffer stringBuffer;
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        if (this.m_scheme != null) {
            StringBuffer append = stringBuffer2.append(this.m_scheme);
            StringBuffer append2 = stringBuffer2.append(':');
        }
        StringBuffer append3 = stringBuffer2.append(getSchemeSpecificPart());
        return stringBuffer2.toString();
    }
}
