package org.apache.xerces.util;

import org.apache.xerces.xni.parser.XMLInputSource;
import org.w3c.dom.Node;

public final class DOMInputSource extends XMLInputSource {
    private Node fNode;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DOMInputSource() {
        this((Node) null);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public DOMInputSource(org.w3c.dom.Node r7) {
        /*
            r6 = this;
            r0 = r6
            r1 = r7
            r2 = r0
            r3 = 0
            r4 = r1
            java.lang.String r4 = getSystemIdFromNode(r4)
            r5 = 0
            r2.<init>(r3, r4, r5)
            r2 = r0
            r3 = r1
            r2.fNode = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.util.DOMInputSource.<init>(org.w3c.dom.Node):void");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DOMInputSource(Node node, String str) {
        super((String) null, str, (String) null);
        this.fNode = node;
    }

    private static String getSystemIdFromNode(Node node) {
        Node node2 = node;
        if (node2 == null) {
            return null;
        }
        try {
            return node2.getBaseURI();
        } catch (NoSuchMethodError e) {
            NoSuchMethodError noSuchMethodError = e;
            return null;
        } catch (Exception e2) {
            Exception exc = e2;
            return null;
        }
    }

    public Node getNode() {
        return this.fNode;
    }

    public void setNode(Node node) {
        Node node2 = node;
        this.fNode = node2;
    }
}
