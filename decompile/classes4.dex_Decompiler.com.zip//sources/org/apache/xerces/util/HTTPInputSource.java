package org.apache.xerces.util;

import java.io.InputStream;
import java.io.Reader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.parser.XMLInputSource;

public final class HTTPInputSource extends XMLInputSource {
    protected boolean fFollowRedirects = true;
    protected Map fHTTPRequestProperties;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTTPInputSource(String str, String str2, String str3) {
        super(str, str2, str3);
        Map map;
        new HashMap();
        this.fHTTPRequestProperties = map;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTTPInputSource(String str, String str2, String str3, InputStream inputStream, String str4) {
        super(str, str2, str3, inputStream, str4);
        Map map;
        new HashMap();
        this.fHTTPRequestProperties = map;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTTPInputSource(String str, String str2, String str3, Reader reader, String str4) {
        super(str, str2, str3, reader, str4);
        Map map;
        new HashMap();
        this.fHTTPRequestProperties = map;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public HTTPInputSource(XMLResourceIdentifier xMLResourceIdentifier) {
        super(xMLResourceIdentifier);
        Map map;
        new HashMap();
        this.fHTTPRequestProperties = map;
    }

    public boolean getFollowHTTPRedirects() {
        return this.fFollowRedirects;
    }

    public Iterator getHTTPRequestProperties() {
        return this.fHTTPRequestProperties.entrySet().iterator();
    }

    public String getHTTPRequestProperty(String str) {
        return (String) this.fHTTPRequestProperties.get(str);
    }

    public void setFollowHTTPRedirects(boolean z) {
        boolean z2 = z;
        this.fFollowRedirects = z2;
    }

    public void setHTTPRequestProperty(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        if (str4 != null) {
            Object put = this.fHTTPRequestProperties.put(str3, str4);
        } else {
            Object remove = this.fHTTPRequestProperties.remove(str3);
        }
    }
}
