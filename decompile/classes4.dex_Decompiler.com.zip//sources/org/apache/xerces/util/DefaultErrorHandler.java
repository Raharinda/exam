package org.apache.xerces.util;

import java.io.PrintWriter;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.apache.xerces.xni.parser.XMLParseException;

public class DefaultErrorHandler implements XMLErrorHandler {
    protected PrintWriter fOut;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public DefaultErrorHandler() {
        /*
            r6 = this;
            r0 = r6
            r1 = r0
            java.io.PrintWriter r2 = new java.io.PrintWriter
            r5 = r2
            r2 = r5
            r3 = r5
            java.io.PrintStream r4 = java.lang.System.err
            r3.<init>(r4)
            r1.<init>(r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.util.DefaultErrorHandler.<init>():void");
    }

    public DefaultErrorHandler(PrintWriter printWriter) {
        this.fOut = printWriter;
    }

    private void printError(String str, XMLParseException xMLParseException) {
        XMLParseException xMLParseException2 = xMLParseException;
        this.fOut.print("[");
        this.fOut.print(str);
        this.fOut.print("] ");
        String expandedSystemId = xMLParseException2.getExpandedSystemId();
        if (expandedSystemId != null) {
            int lastIndexOf = expandedSystemId.lastIndexOf(47);
            if (lastIndexOf != -1) {
                expandedSystemId = expandedSystemId.substring(lastIndexOf + 1);
            }
            this.fOut.print(expandedSystemId);
        }
        this.fOut.print(':');
        this.fOut.print(xMLParseException2.getLineNumber());
        this.fOut.print(':');
        this.fOut.print(xMLParseException2.getColumnNumber());
        this.fOut.print(": ");
        this.fOut.print(xMLParseException2.getMessage());
        this.fOut.println();
        this.fOut.flush();
    }

    public void error(String str, String str2, XMLParseException xMLParseException) throws XNIException {
        String str3 = str;
        String str4 = str2;
        printError("Error", xMLParseException);
    }

    public void fatalError(String str, String str2, XMLParseException xMLParseException) throws XNIException {
        String str3 = str;
        String str4 = str2;
        XMLParseException xMLParseException2 = xMLParseException;
        printError("Fatal Error", xMLParseException2);
        throw xMLParseException2;
    }

    public void warning(String str, String str2, XMLParseException xMLParseException) throws XNIException {
        String str3 = str;
        String str4 = str2;
        printError("Warning", xMLParseException);
    }
}
