package org.apache.xerces.util;

import org.apache.xerces.impl.XMLEntityDescription;

public class XMLEntityDescriptionImpl extends XMLResourceIdentifierImpl implements XMLEntityDescription {
    protected String fEntityName;

    public XMLEntityDescriptionImpl() {
    }

    public XMLEntityDescriptionImpl(String str, String str2, String str3, String str4, String str5) {
        setDescription(str, str2, str3, str4, str5);
    }

    public XMLEntityDescriptionImpl(String str, String str2, String str3, String str4, String str5, String str6) {
        setDescription(str, str2, str3, str4, str5, str6);
    }

    public void clear() {
        super.clear();
        this.fEntityName = null;
    }

    public String getEntityName() {
        return this.fEntityName;
    }

    public int hashCode() {
        int hashCode = super.hashCode();
        if (this.fEntityName != null) {
            hashCode += this.fEntityName.hashCode();
        }
        return hashCode;
    }

    public void setDescription(String str, String str2, String str3, String str4, String str5) {
        setDescription(str, str2, str3, str4, str5, (String) null);
    }

    public void setDescription(String str, String str2, String str3, String str4, String str5, String str6) {
        this.fEntityName = str;
        setValues(str2, str3, str4, str5, str6);
    }

    public void setEntityName(String str) {
        String str2 = str;
        this.fEntityName = str2;
    }

    public String toString() {
        StringBuffer stringBuffer;
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        if (this.fEntityName != null) {
            StringBuffer append = stringBuffer2.append(this.fEntityName);
        }
        StringBuffer append2 = stringBuffer2.append(':');
        if (this.fPublicId != null) {
            StringBuffer append3 = stringBuffer2.append(this.fPublicId);
        }
        StringBuffer append4 = stringBuffer2.append(':');
        if (this.fLiteralSystemId != null) {
            StringBuffer append5 = stringBuffer2.append(this.fLiteralSystemId);
        }
        StringBuffer append6 = stringBuffer2.append(':');
        if (this.fBaseSystemId != null) {
            StringBuffer append7 = stringBuffer2.append(this.fBaseSystemId);
        }
        StringBuffer append8 = stringBuffer2.append(':');
        if (this.fExpandedSystemId != null) {
            StringBuffer append9 = stringBuffer2.append(this.fExpandedSystemId);
        }
        StringBuffer append10 = stringBuffer2.append(':');
        if (this.fNamespace != null) {
            StringBuffer append11 = stringBuffer2.append(this.fNamespace);
        }
        return stringBuffer2.toString();
    }
}
