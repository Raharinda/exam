package org.apache.xerces.util;

import org.apache.xerces.xni.XMLResourceIdentifier;

public class XMLResourceIdentifierImpl implements XMLResourceIdentifier {
    protected String fBaseSystemId;
    protected String fExpandedSystemId;
    protected String fLiteralSystemId;
    protected String fNamespace;
    protected String fPublicId;

    public XMLResourceIdentifierImpl() {
    }

    public XMLResourceIdentifierImpl(String str, String str2, String str3, String str4) {
        setValues(str, str2, str3, str4, (String) null);
    }

    public XMLResourceIdentifierImpl(String str, String str2, String str3, String str4, String str5) {
        setValues(str, str2, str3, str4, str5);
    }

    public void clear() {
        this.fPublicId = null;
        this.fLiteralSystemId = null;
        this.fBaseSystemId = null;
        this.fExpandedSystemId = null;
        this.fNamespace = null;
    }

    public String getBaseSystemId() {
        return this.fBaseSystemId;
    }

    public String getExpandedSystemId() {
        return this.fExpandedSystemId;
    }

    public String getLiteralSystemId() {
        return this.fLiteralSystemId;
    }

    public String getNamespace() {
        return this.fNamespace;
    }

    public String getPublicId() {
        return this.fPublicId;
    }

    public int hashCode() {
        int i = 0;
        if (this.fPublicId != null) {
            i = 0 + this.fPublicId.hashCode();
        }
        if (this.fLiteralSystemId != null) {
            i += this.fLiteralSystemId.hashCode();
        }
        if (this.fBaseSystemId != null) {
            i += this.fBaseSystemId.hashCode();
        }
        if (this.fExpandedSystemId != null) {
            i += this.fExpandedSystemId.hashCode();
        }
        if (this.fNamespace != null) {
            i += this.fNamespace.hashCode();
        }
        return i;
    }

    public void setBaseSystemId(String str) {
        String str2 = str;
        this.fBaseSystemId = str2;
    }

    public void setExpandedSystemId(String str) {
        String str2 = str;
        this.fExpandedSystemId = str2;
    }

    public void setLiteralSystemId(String str) {
        String str2 = str;
        this.fLiteralSystemId = str2;
    }

    public void setNamespace(String str) {
        String str2 = str;
        this.fNamespace = str2;
    }

    public void setPublicId(String str) {
        String str2 = str;
        this.fPublicId = str2;
    }

    public void setValues(String str, String str2, String str3, String str4) {
        setValues(str, str2, str3, str4, (String) null);
    }

    public void setValues(String str, String str2, String str3, String str4, String str5) {
        this.fPublicId = str;
        this.fLiteralSystemId = str2;
        this.fBaseSystemId = str3;
        this.fExpandedSystemId = str4;
        this.fNamespace = str5;
    }

    public String toString() {
        StringBuffer stringBuffer;
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        if (this.fPublicId != null) {
            StringBuffer append = stringBuffer2.append(this.fPublicId);
        }
        StringBuffer append2 = stringBuffer2.append(':');
        if (this.fLiteralSystemId != null) {
            StringBuffer append3 = stringBuffer2.append(this.fLiteralSystemId);
        }
        StringBuffer append4 = stringBuffer2.append(':');
        if (this.fBaseSystemId != null) {
            StringBuffer append5 = stringBuffer2.append(this.fBaseSystemId);
        }
        StringBuffer append6 = stringBuffer2.append(':');
        if (this.fExpandedSystemId != null) {
            StringBuffer append7 = stringBuffer2.append(this.fExpandedSystemId);
        }
        StringBuffer append8 = stringBuffer2.append(':');
        if (this.fNamespace != null) {
            StringBuffer append9 = stringBuffer2.append(this.fNamespace);
        }
        return stringBuffer2.toString();
    }
}
