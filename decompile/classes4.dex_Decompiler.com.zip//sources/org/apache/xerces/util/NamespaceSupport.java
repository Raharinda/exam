package org.apache.xerces.util;

import java.util.Enumeration;
import java.util.NoSuchElementException;
import org.apache.xerces.xni.NamespaceContext;

public class NamespaceSupport implements NamespaceContext {
    protected int[] fContext = new int[8];
    protected int fCurrentContext;
    protected String[] fNamespace = new String[32];
    protected int fNamespaceSize;
    protected String[] fPrefixes = new String[16];

    protected final class Prefixes implements Enumeration {
        private int counter = 0;
        private String[] prefixes;
        private int size = 0;
        private final NamespaceSupport this$0;

        public Prefixes(NamespaceSupport namespaceSupport, String[] strArr, int i) {
            this.this$0 = namespaceSupport;
            this.prefixes = strArr;
            this.size = i;
        }

        public boolean hasMoreElements() {
            return this.counter < this.size;
        }

        public Object nextElement() {
            Throwable th;
            if (this.counter < this.size) {
                String[] strArr = this.this$0.fPrefixes;
                int i = this.counter;
                int i2 = i + 1;
                this.counter = i2;
                return strArr[i];
            }
            Throwable th2 = th;
            new NoSuchElementException("Illegal access to Namespace prefixes enumeration.");
            throw th2;
        }

        public String toString() {
            StringBuffer stringBuffer;
            new StringBuffer();
            StringBuffer stringBuffer2 = stringBuffer;
            for (int i = 0; i < this.size; i++) {
                StringBuffer append = stringBuffer2.append(this.prefixes[i]);
                StringBuffer append2 = stringBuffer2.append(' ');
            }
            return stringBuffer2.toString();
        }
    }

    public NamespaceSupport() {
    }

    public NamespaceSupport(NamespaceContext namespaceContext) {
        NamespaceContext namespaceContext2 = namespaceContext;
        pushContext();
        Enumeration allPrefixes = namespaceContext2.getAllPrefixes();
        while (allPrefixes.hasMoreElements()) {
            String str = (String) allPrefixes.nextElement();
            boolean declarePrefix = declarePrefix(str, namespaceContext2.getURI(str));
        }
    }

    public boolean containsPrefix(String str) {
        String str2 = str;
        for (int i = this.fNamespaceSize; i > 0; i -= 2) {
            if (this.fNamespace[i - 2] == str2) {
                return true;
            }
        }
        return false;
    }

    public boolean declarePrefix(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        if (str3 == XMLSymbols.PREFIX_XML || str3 == XMLSymbols.PREFIX_XMLNS) {
            return false;
        }
        for (int i = this.fNamespaceSize; i > this.fContext[this.fCurrentContext]; i -= 2) {
            if (this.fNamespace[i - 2] == str3) {
                this.fNamespace[i - 1] = str4;
                return true;
            }
        }
        if (this.fNamespaceSize == this.fNamespace.length) {
            String[] strArr = new String[(this.fNamespaceSize * 2)];
            System.arraycopy(this.fNamespace, 0, strArr, 0, this.fNamespaceSize);
            this.fNamespace = strArr;
        }
        String[] strArr2 = this.fNamespace;
        int i2 = this.fNamespaceSize;
        int i3 = i2 + 1;
        this.fNamespaceSize = i3;
        strArr2[i2] = str3;
        String[] strArr3 = this.fNamespace;
        int i4 = this.fNamespaceSize;
        int i5 = i4 + 1;
        this.fNamespaceSize = i5;
        strArr3[i4] = str4;
        return true;
    }

    public Enumeration getAllPrefixes() {
        Enumeration enumeration;
        int i = 0;
        if (this.fPrefixes.length < this.fNamespace.length / 2) {
            this.fPrefixes = new String[this.fNamespaceSize];
        }
        boolean z = true;
        for (int i2 = 2; i2 < this.fNamespaceSize - 2; i2 += 2) {
            String str = this.fNamespace[i2 + 2];
            int i3 = 0;
            while (true) {
                if (i3 >= i) {
                    break;
                } else if (this.fPrefixes[i3] == str) {
                    z = false;
                    break;
                } else {
                    i3++;
                }
            }
            if (z) {
                int i4 = i;
                i++;
                this.fPrefixes[i4] = str;
            }
            z = true;
        }
        new Prefixes(this, this.fPrefixes, i);
        return enumeration;
    }

    public String getDeclaredPrefixAt(int i) {
        return this.fNamespace[this.fContext[this.fCurrentContext] + (i * 2)];
    }

    public int getDeclaredPrefixCount() {
        return (this.fNamespaceSize - this.fContext[this.fCurrentContext]) / 2;
    }

    public String getPrefix(String str) {
        String str2 = str;
        for (int i = this.fNamespaceSize; i > 0; i -= 2) {
            if (this.fNamespace[i - 1] == str2 && getURI(this.fNamespace[i - 2]) == str2) {
                return this.fNamespace[i - 2];
            }
        }
        return null;
    }

    public String getURI(String str) {
        String str2 = str;
        for (int i = this.fNamespaceSize; i > 0; i -= 2) {
            if (this.fNamespace[i - 2] == str2) {
                return this.fNamespace[i - 1];
            }
        }
        return null;
    }

    public void popContext() {
        int[] iArr = this.fContext;
        int i = this.fCurrentContext;
        int i2 = i - 1;
        this.fCurrentContext = i2;
        this.fNamespaceSize = iArr[i];
    }

    public void pushContext() {
        if (this.fCurrentContext + 1 == this.fContext.length) {
            int[] iArr = new int[(this.fContext.length * 2)];
            System.arraycopy(this.fContext, 0, iArr, 0, this.fContext.length);
            this.fContext = iArr;
        }
        int[] iArr2 = this.fContext;
        int i = this.fCurrentContext + 1;
        int i2 = i;
        this.fCurrentContext = i2;
        iArr2[i] = this.fNamespaceSize;
    }

    public void reset() {
        this.fNamespaceSize = 0;
        this.fCurrentContext = 0;
        this.fContext[this.fCurrentContext] = this.fNamespaceSize;
        String[] strArr = this.fNamespace;
        int i = this.fNamespaceSize;
        int i2 = i + 1;
        this.fNamespaceSize = i2;
        strArr[i] = XMLSymbols.PREFIX_XML;
        String[] strArr2 = this.fNamespace;
        int i3 = this.fNamespaceSize;
        int i4 = i3 + 1;
        this.fNamespaceSize = i4;
        strArr2[i3] = NamespaceContext.XML_URI;
        String[] strArr3 = this.fNamespace;
        int i5 = this.fNamespaceSize;
        int i6 = i5 + 1;
        this.fNamespaceSize = i6;
        strArr3[i5] = XMLSymbols.PREFIX_XMLNS;
        String[] strArr4 = this.fNamespace;
        int i7 = this.fNamespaceSize;
        int i8 = i7 + 1;
        this.fNamespaceSize = i8;
        strArr4[i7] = NamespaceContext.XMLNS_URI;
        this.fCurrentContext++;
    }
}
