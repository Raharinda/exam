package org.apache.xerces.util;

import com.microsoft.appcenter.Constants;
import java.io.PrintWriter;
import java.util.Hashtable;
import org.apache.xerces.dom.DOMErrorImpl;
import org.apache.xerces.dom.DOMLocatorImpl;
import org.apache.xerces.dom.DOMMessageFormatter;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.apache.xerces.xni.parser.XMLParseException;
import org.w3c.dom.DOMError;
import org.w3c.dom.DOMErrorHandler;
import org.w3c.dom.DOMLocator;
import org.w3c.dom.Node;

public class DOMErrorHandlerWrapper implements XMLErrorHandler, DOMErrorHandler {
    boolean eStatus = true;
    public Node fCurrentNode;
    protected final DOMErrorImpl fDOMError;
    protected DOMErrorHandler fDomErrorHandler;
    protected final XMLErrorCode fErrorCode;
    protected PrintWriter fOut;

    private static class DOMErrorTypeMap {
        private static Hashtable fgDOMErrorTypeTable;

        static {
            Hashtable hashtable;
            Object obj;
            Object obj2;
            Object obj3;
            Object obj4;
            Object obj5;
            Object obj6;
            Object obj7;
            Object obj8;
            Object obj9;
            Object obj10;
            Object obj11;
            Object obj12;
            Object obj13;
            Object obj14;
            Object obj15;
            Object obj16;
            Object obj17;
            Object obj18;
            Object obj19;
            Object obj20;
            Object obj21;
            Object obj22;
            Object obj23;
            Object obj24;
            Object obj25;
            Object obj26;
            Object obj27;
            Object obj28;
            Object obj29;
            Object obj30;
            Object obj31;
            Object obj32;
            Object obj33;
            Object obj34;
            Object obj35;
            Object obj36;
            Object obj37;
            Object obj38;
            Object obj39;
            Object obj40;
            Object obj41;
            Object obj42;
            Object obj43;
            Object obj44;
            Object obj45;
            Object obj46;
            Object obj47;
            Object obj48;
            Object obj49;
            Object obj50;
            Object obj51;
            Object obj52;
            Object obj53;
            Object obj54;
            Object obj55;
            Object obj56;
            Object obj57;
            Object obj58;
            Object obj59;
            Object obj60;
            Object obj61;
            Object obj62;
            Object obj63;
            Object obj64;
            Object obj65;
            Object obj66;
            Object obj67;
            Object obj68;
            Object obj69;
            Object obj70;
            Object obj71;
            Object obj72;
            Object obj73;
            Object obj74;
            Object obj75;
            Object obj76;
            Object obj77;
            Object obj78;
            Object obj79;
            Object obj80;
            Object obj81;
            Object obj82;
            Object obj83;
            Object obj84;
            Object obj85;
            Object obj86;
            Object obj87;
            Object obj88;
            Object obj89;
            Object obj90;
            Object obj91;
            Object obj92;
            Object obj93;
            Object obj94;
            Object obj95;
            Object obj96;
            Object obj97;
            Object obj98;
            Object obj99;
            Object obj100;
            Object obj101;
            Object obj102;
            Object obj103;
            Object obj104;
            Object obj105;
            Object obj106;
            Object obj107;
            Object obj108;
            Object obj109;
            new Hashtable();
            fgDOMErrorTypeTable = hashtable;
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInCDSect");
            Object put = fgDOMErrorTypeTable.put(obj, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInContent");
            Object put2 = fgDOMErrorTypeTable.put(obj2, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "TwoColonsInQName");
            Object put3 = fgDOMErrorTypeTable.put(obj3, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "ColonNotLegalWithNS");
            Object put4 = fgDOMErrorTypeTable.put(obj4, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInProlog");
            Object put5 = fgDOMErrorTypeTable.put(obj5, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "CDEndInContent");
            Object put6 = fgDOMErrorTypeTable.put(obj6, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "CDSectUnterminated");
            Object put7 = fgDOMErrorTypeTable.put(obj7, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "DoctypeNotAllowed");
            Object put8 = fgDOMErrorTypeTable.put(obj8, "doctype-not-allowed");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "ETagRequired");
            Object put9 = fgDOMErrorTypeTable.put(obj9, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "ElementUnterminated");
            Object put10 = fgDOMErrorTypeTable.put(obj10, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "EqRequiredInAttribute");
            Object put11 = fgDOMErrorTypeTable.put(obj11, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "OpenQuoteExpected");
            Object put12 = fgDOMErrorTypeTable.put(obj12, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "CloseQuoteExpected");
            Object put13 = fgDOMErrorTypeTable.put(obj13, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "ETagUnterminated");
            Object put14 = fgDOMErrorTypeTable.put(obj14, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MarkupNotRecognizedInContent");
            Object put15 = fgDOMErrorTypeTable.put(obj15, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "DoctypeIllegalInContent");
            Object put16 = fgDOMErrorTypeTable.put(obj16, "doctype-not-allowed");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInAttValue");
            Object put17 = fgDOMErrorTypeTable.put(obj17, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInPI");
            Object put18 = fgDOMErrorTypeTable.put(obj18, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInInternalSubset");
            Object put19 = fgDOMErrorTypeTable.put(obj19, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "QuoteRequiredInAttValue");
            Object put20 = fgDOMErrorTypeTable.put(obj20, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "LessthanInAttValue");
            Object put21 = fgDOMErrorTypeTable.put(obj21, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "AttributeValueUnterminated");
            Object put22 = fgDOMErrorTypeTable.put(obj22, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "PITargetRequired");
            Object put23 = fgDOMErrorTypeTable.put(obj23, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "SpaceRequiredInPI");
            Object put24 = fgDOMErrorTypeTable.put(obj24, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "PIUnterminated");
            Object put25 = fgDOMErrorTypeTable.put(obj25, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "ReservedPITarget");
            Object put26 = fgDOMErrorTypeTable.put(obj26, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "PI_NOT_IN_ONE_ENTITY");
            Object put27 = fgDOMErrorTypeTable.put(obj27, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "PINotInOneEntity");
            Object put28 = fgDOMErrorTypeTable.put(obj28, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "EncodingDeclInvalid");
            Object put29 = fgDOMErrorTypeTable.put(obj29, "unsupported-encoding");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "EncodingByteOrderUnsupported");
            Object put30 = fgDOMErrorTypeTable.put(obj30, "unsupported-encoding");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInEntityValue");
            Object put31 = fgDOMErrorTypeTable.put(obj31, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInExternalSubset");
            Object put32 = fgDOMErrorTypeTable.put(obj32, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInIgnoreSect");
            Object put33 = fgDOMErrorTypeTable.put(obj33, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInPublicID");
            Object put34 = fgDOMErrorTypeTable.put(obj34, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "InvalidCharInSystemID");
            Object put35 = fgDOMErrorTypeTable.put(obj35, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "SpaceRequiredAfterSYSTEM");
            Object put36 = fgDOMErrorTypeTable.put(obj36, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "QuoteRequiredInSystemID");
            Object put37 = fgDOMErrorTypeTable.put(obj37, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "SystemIDUnterminated");
            Object put38 = fgDOMErrorTypeTable.put(obj38, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "SpaceRequiredAfterPUBLIC");
            Object put39 = fgDOMErrorTypeTable.put(obj39, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "QuoteRequiredInPublicID");
            Object put40 = fgDOMErrorTypeTable.put(obj40, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "PublicIDUnterminated");
            Object put41 = fgDOMErrorTypeTable.put(obj41, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "PubidCharIllegal");
            Object put42 = fgDOMErrorTypeTable.put(obj42, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "SpaceRequiredBetweenPublicAndSystem");
            Object put43 = fgDOMErrorTypeTable.put(obj43, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_ROOT_ELEMENT_TYPE_IN_DOCTYPEDECL");
            Object put44 = fgDOMErrorTypeTable.put(obj44, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_ROOT_ELEMENT_TYPE_REQUIRED");
            Object put45 = fgDOMErrorTypeTable.put(obj45, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "DoctypedeclUnterminated");
            Object put46 = fgDOMErrorTypeTable.put(obj46, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "PEReferenceWithinMarkup");
            Object put47 = fgDOMErrorTypeTable.put(obj47, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_MARKUP_NOT_RECOGNIZED_IN_DTD");
            Object put48 = fgDOMErrorTypeTable.put(obj48, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_ELEMENT_TYPE_IN_ELEMENTDECL");
            Object put49 = fgDOMErrorTypeTable.put(obj49, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_ELEMENT_TYPE_REQUIRED_IN_ELEMENTDECL");
            Object put50 = fgDOMErrorTypeTable.put(obj50, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_CONTENTSPEC_IN_ELEMENTDECL");
            Object put51 = fgDOMErrorTypeTable.put(obj51, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_CONTENTSPEC_REQUIRED_IN_ELEMENTDECL");
            Object put52 = fgDOMErrorTypeTable.put(obj52, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "ElementDeclUnterminated");
            Object put53 = fgDOMErrorTypeTable.put(obj53, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_OPEN_PAREN_OR_ELEMENT_TYPE_REQUIRED_IN_CHILDREN");
            Object put54 = fgDOMErrorTypeTable.put(obj54, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_CLOSE_PAREN_REQUIRED_IN_CHILDREN");
            Object put55 = fgDOMErrorTypeTable.put(obj55, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_ELEMENT_TYPE_REQUIRED_IN_MIXED_CONTENT");
            Object put56 = fgDOMErrorTypeTable.put(obj56, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_CLOSE_PAREN_REQUIRED_IN_MIXED");
            Object put57 = fgDOMErrorTypeTable.put(obj57, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MixedContentUnterminated");
            Object put58 = fgDOMErrorTypeTable.put(obj58, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_ELEMENT_TYPE_IN_ATTLISTDECL");
            Object put59 = fgDOMErrorTypeTable.put(obj59, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_ELEMENT_TYPE_REQUIRED_IN_ATTLISTDECL");
            Object put60 = fgDOMErrorTypeTable.put(obj60, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_ATTRIBUTE_NAME_IN_ATTDEF");
            Object put61 = fgDOMErrorTypeTable.put(obj61, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "AttNameRequiredInAttDef");
            Object put62 = fgDOMErrorTypeTable.put(obj62, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_ATTTYPE_IN_ATTDEF");
            Object put63 = fgDOMErrorTypeTable.put(obj63, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "AttTypeRequiredInAttDef");
            Object put64 = fgDOMErrorTypeTable.put(obj64, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_DEFAULTDECL_IN_ATTDEF");
            Object put65 = fgDOMErrorTypeTable.put(obj65, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_DUPLICATE_ATTRIBUTE_DEFINITION");
            Object put66 = fgDOMErrorTypeTable.put(obj66, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_AFTER_NOTATION_IN_NOTATIONTYPE");
            Object put67 = fgDOMErrorTypeTable.put(obj67, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_OPEN_PAREN_REQUIRED_IN_NOTATIONTYPE");
            Object put68 = fgDOMErrorTypeTable.put(obj68, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_NAME_REQUIRED_IN_NOTATIONTYPE");
            Object put69 = fgDOMErrorTypeTable.put(obj69, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "NotationTypeUnterminated");
            Object put70 = fgDOMErrorTypeTable.put(obj70, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_NMTOKEN_REQUIRED_IN_ENUMERATION");
            Object put71 = fgDOMErrorTypeTable.put(obj71, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "EnumerationUnterminated");
            Object put72 = fgDOMErrorTypeTable.put(obj72, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_DISTINCT_TOKENS_IN_ENUMERATION");
            Object put73 = fgDOMErrorTypeTable.put(obj73, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_DISTINCT_NOTATION_IN_ENUMERATION");
            Object put74 = fgDOMErrorTypeTable.put(obj74, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_AFTER_FIXED_IN_DEFAULTDECL");
            Object put75 = fgDOMErrorTypeTable.put(obj75, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "IncludeSectUnterminated");
            Object put76 = fgDOMErrorTypeTable.put(obj76, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "IgnoreSectUnterminated");
            Object put77 = fgDOMErrorTypeTable.put(obj77, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "NameRequiredInPEReference");
            Object put78 = fgDOMErrorTypeTable.put(obj78, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "SemicolonRequiredInPEReference");
            Object put79 = fgDOMErrorTypeTable.put(obj79, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_ENTITY_NAME_IN_ENTITYDECL");
            Object put80 = fgDOMErrorTypeTable.put(obj80, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_PERCENT_IN_PEDECL");
            Object put81 = fgDOMErrorTypeTable.put(obj81, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_ENTITY_NAME_IN_PEDECL");
            Object put82 = fgDOMErrorTypeTable.put(obj82, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_ENTITY_NAME_REQUIRED_IN_ENTITYDECL");
            Object put83 = fgDOMErrorTypeTable.put(obj83, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_AFTER_ENTITY_NAME_IN_ENTITYDECL");
            Object put84 = fgDOMErrorTypeTable.put(obj84, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_NOTATION_NAME_IN_UNPARSED_ENTITYDECL");
            Object put85 = fgDOMErrorTypeTable.put(obj85, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_NDATA_IN_UNPARSED_ENTITYDECL");
            Object put86 = fgDOMErrorTypeTable.put(obj86, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_NOTATION_NAME_REQUIRED_FOR_UNPARSED_ENTITYDECL");
            Object put87 = fgDOMErrorTypeTable.put(obj87, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "EntityDeclUnterminated");
            Object put88 = fgDOMErrorTypeTable.put(obj88, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_DUPLICATE_ENTITY_DEFINITION");
            Object put89 = fgDOMErrorTypeTable.put(obj89, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "ExternalIDRequired");
            Object put90 = fgDOMErrorTypeTable.put(obj90, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_PUBIDLITERAL_IN_EXTERNALID");
            Object put91 = fgDOMErrorTypeTable.put(obj91, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_AFTER_PUBIDLITERAL_IN_EXTERNALID");
            Object put92 = fgDOMErrorTypeTable.put(obj92, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_SYSTEMLITERAL_IN_EXTERNALID");
            Object put93 = fgDOMErrorTypeTable.put(obj93, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_URI_FRAGMENT_IN_SYSTEMID");
            Object put94 = fgDOMErrorTypeTable.put(obj94, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_BEFORE_NOTATION_NAME_IN_NOTATIONDECL");
            Object put95 = fgDOMErrorTypeTable.put(obj95, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_NOTATION_NAME_REQUIRED_IN_NOTATIONDECL");
            Object put96 = fgDOMErrorTypeTable.put(obj96, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "MSG_SPACE_REQUIRED_AFTER_NOTATION_NAME_IN_NOTATIONDECL");
            Object put97 = fgDOMErrorTypeTable.put(obj97, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "ExternalIDorPublicIDRequired");
            Object put98 = fgDOMErrorTypeTable.put(obj98, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "NotationDeclUnterminated");
            Object put99 = fgDOMErrorTypeTable.put(obj99, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "ReferenceToExternalEntity");
            Object put100 = fgDOMErrorTypeTable.put(obj100, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "ReferenceToUnparsedEntity");
            Object put101 = fgDOMErrorTypeTable.put(obj101, "wf-invalid-character");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "EncodingNotSupported");
            Object put102 = fgDOMErrorTypeTable.put(obj102, "unsupported-encoding");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "EncodingRequired");
            Object put103 = fgDOMErrorTypeTable.put(obj103, "unsupported-encoding");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "IllegalQName");
            Object put104 = fgDOMErrorTypeTable.put(obj104, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "ElementXMLNSPrefix");
            Object put105 = fgDOMErrorTypeTable.put(obj105, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "ElementPrefixUnbound");
            Object put106 = fgDOMErrorTypeTable.put(obj106, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "AttributePrefixUnbound");
            Object put107 = fgDOMErrorTypeTable.put(obj107, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "EmptyPrefixedAttName");
            Object put108 = fgDOMErrorTypeTable.put(obj108, "wf-invalid-character-in-node-name");
            new XMLErrorCode(DOMMessageFormatter.XML_DOMAIN, "PrefixDeclared");
            Object put109 = fgDOMErrorTypeTable.put(obj109, "wf-invalid-character-in-node-name");
        }

        private DOMErrorTypeMap() {
        }

        public static String getDOMErrorType(XMLErrorCode xMLErrorCode) {
            return (String) fgDOMErrorTypeTable.get(xMLErrorCode);
        }
    }

    public DOMErrorHandlerWrapper() {
        XMLErrorCode xMLErrorCode;
        DOMErrorImpl dOMErrorImpl;
        PrintWriter printWriter;
        new XMLErrorCode((String) null, (String) null);
        this.fErrorCode = xMLErrorCode;
        new DOMErrorImpl();
        this.fDOMError = dOMErrorImpl;
        new PrintWriter(System.err);
        this.fOut = printWriter;
    }

    public DOMErrorHandlerWrapper(DOMErrorHandler dOMErrorHandler) {
        XMLErrorCode xMLErrorCode;
        DOMErrorImpl dOMErrorImpl;
        new XMLErrorCode((String) null, (String) null);
        this.fErrorCode = xMLErrorCode;
        new DOMErrorImpl();
        this.fDOMError = dOMErrorImpl;
        this.fDomErrorHandler = dOMErrorHandler;
    }

    private void printError(DOMError dOMError) {
        DOMError dOMError2 = dOMError;
        short severity = dOMError2.getSeverity();
        this.fOut.print("[");
        if (severity == 1) {
            this.fOut.print("Warning");
        } else if (severity == 2) {
            this.fOut.print("Error");
        } else {
            this.fOut.print("FatalError");
            this.eStatus = false;
        }
        this.fOut.print("] ");
        DOMLocator location = dOMError2.getLocation();
        if (location != null) {
            this.fOut.print(location.getLineNumber());
            this.fOut.print(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR);
            this.fOut.print(location.getColumnNumber());
            this.fOut.print(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR);
            this.fOut.print(location.getByteOffset());
            this.fOut.print(",");
            this.fOut.print(location.getUtf16Offset());
            Node relatedNode = location.getRelatedNode();
            if (relatedNode != null) {
                this.fOut.print("[");
                this.fOut.print(relatedNode.getNodeName());
                this.fOut.print("]");
            }
            String uri = location.getUri();
            if (uri != null) {
                int lastIndexOf = uri.lastIndexOf(47);
                if (lastIndexOf != -1) {
                    uri = uri.substring(lastIndexOf + 1);
                }
                this.fOut.print(": ");
                this.fOut.print(uri);
            }
        }
        this.fOut.print(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR);
        this.fOut.print(dOMError2.getMessage());
        this.fOut.println();
        this.fOut.flush();
    }

    public void error(String str, String str2, XMLParseException xMLParseException) throws XNIException {
        String str3 = str;
        XMLParseException xMLParseException2 = xMLParseException;
        this.fDOMError.fSeverity = 2;
        this.fDOMError.fException = xMLParseException2;
        this.fDOMError.fType = str2;
        DOMErrorImpl dOMErrorImpl = this.fDOMError;
        String message = xMLParseException2.getMessage();
        String str4 = message;
        this.fDOMError.fMessage = str4;
        dOMErrorImpl.fRelatedData = message;
        DOMLocatorImpl dOMLocatorImpl = this.fDOMError.fLocator;
        if (dOMLocatorImpl != null) {
            dOMLocatorImpl.fColumnNumber = xMLParseException2.getColumnNumber();
            dOMLocatorImpl.fLineNumber = xMLParseException2.getLineNumber();
            dOMLocatorImpl.fUtf16Offset = xMLParseException2.getCharacterOffset();
            dOMLocatorImpl.fUri = xMLParseException2.getExpandedSystemId();
            dOMLocatorImpl.fRelatedNode = this.fCurrentNode;
        }
        if (this.fDomErrorHandler != null) {
            boolean handleError = this.fDomErrorHandler.handleError(this.fDOMError);
        }
    }

    public void fatalError(String str, String str2, XMLParseException xMLParseException) throws XNIException {
        String str3 = str2;
        XMLParseException xMLParseException2 = xMLParseException;
        this.fDOMError.fSeverity = 3;
        this.fDOMError.fException = xMLParseException2;
        this.fErrorCode.setValues(str, str3);
        String dOMErrorType = DOMErrorTypeMap.getDOMErrorType(this.fErrorCode);
        this.fDOMError.fType = dOMErrorType != null ? dOMErrorType : str3;
        DOMErrorImpl dOMErrorImpl = this.fDOMError;
        String message = xMLParseException2.getMessage();
        this.fDOMError.fMessage = message;
        dOMErrorImpl.fRelatedData = message;
        DOMLocatorImpl dOMLocatorImpl = this.fDOMError.fLocator;
        if (dOMLocatorImpl != null) {
            dOMLocatorImpl.fColumnNumber = xMLParseException2.getColumnNumber();
            dOMLocatorImpl.fLineNumber = xMLParseException2.getLineNumber();
            dOMLocatorImpl.fUtf16Offset = xMLParseException2.getCharacterOffset();
            dOMLocatorImpl.fUri = xMLParseException2.getExpandedSystemId();
            dOMLocatorImpl.fRelatedNode = this.fCurrentNode;
        }
        if (this.fDomErrorHandler != null) {
            boolean handleError = this.fDomErrorHandler.handleError(this.fDOMError);
        }
    }

    public DOMErrorHandler getErrorHandler() {
        return this.fDomErrorHandler;
    }

    public boolean handleError(DOMError dOMError) {
        printError(dOMError);
        return this.eStatus;
    }

    public void setErrorHandler(DOMErrorHandler dOMErrorHandler) {
        DOMErrorHandler dOMErrorHandler2 = dOMErrorHandler;
        this.fDomErrorHandler = dOMErrorHandler2;
    }

    public void warning(String str, String str2, XMLParseException xMLParseException) throws XNIException {
        String str3 = str;
        XMLParseException xMLParseException2 = xMLParseException;
        this.fDOMError.fSeverity = 1;
        this.fDOMError.fException = xMLParseException2;
        this.fDOMError.fType = str2;
        DOMErrorImpl dOMErrorImpl = this.fDOMError;
        String message = xMLParseException2.getMessage();
        String str4 = message;
        this.fDOMError.fMessage = str4;
        dOMErrorImpl.fRelatedData = message;
        DOMLocatorImpl dOMLocatorImpl = this.fDOMError.fLocator;
        if (dOMLocatorImpl != null) {
            dOMLocatorImpl.fColumnNumber = xMLParseException2.getColumnNumber();
            dOMLocatorImpl.fLineNumber = xMLParseException2.getLineNumber();
            dOMLocatorImpl.fUtf16Offset = xMLParseException2.getCharacterOffset();
            dOMLocatorImpl.fUri = xMLParseException2.getExpandedSystemId();
            dOMLocatorImpl.fRelatedNode = this.fCurrentNode;
        }
        if (this.fDomErrorHandler != null) {
            boolean handleError = this.fDomErrorHandler.handleError(this.fDOMError);
        }
    }
}
