package org.apache.xerces.util;

public final class SynchronizedSymbolTable extends SymbolTable {
    protected SymbolTable fSymbolTable;

    public SynchronizedSymbolTable() {
        SymbolTable symbolTable;
        new SymbolTable();
        this.fSymbolTable = symbolTable;
    }

    public SynchronizedSymbolTable(int i) {
        SymbolTable symbolTable;
        new SymbolTable(i);
        this.fSymbolTable = symbolTable;
    }

    public SynchronizedSymbolTable(SymbolTable symbolTable) {
        this.fSymbolTable = symbolTable;
    }

    public String addSymbol(String str) {
        String addSymbol;
        String str2 = str;
        SymbolTable symbolTable = this.fSymbolTable;
        synchronized (symbolTable) {
            try {
                addSymbol = this.fSymbolTable.addSymbol(str2);
            } catch (Throwable th) {
                Throwable th2 = th;
                SymbolTable symbolTable2 = symbolTable;
                throw th2;
            }
        }
        return addSymbol;
    }

    public String addSymbol(char[] cArr, int i, int i2) {
        String addSymbol;
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        SymbolTable symbolTable = this.fSymbolTable;
        synchronized (symbolTable) {
            try {
                addSymbol = this.fSymbolTable.addSymbol(cArr2, i3, i4);
            } catch (Throwable th) {
                Throwable th2 = th;
                SymbolTable symbolTable2 = symbolTable;
                throw th2;
            }
        }
        return addSymbol;
    }

    public boolean containsSymbol(String str) {
        boolean containsSymbol;
        String str2 = str;
        SymbolTable symbolTable = this.fSymbolTable;
        synchronized (symbolTable) {
            try {
                containsSymbol = this.fSymbolTable.containsSymbol(str2);
            } catch (Throwable th) {
                Throwable th2 = th;
                SymbolTable symbolTable2 = symbolTable;
                throw th2;
            }
        }
        return containsSymbol;
    }

    public boolean containsSymbol(char[] cArr, int i, int i2) {
        boolean containsSymbol;
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        SymbolTable symbolTable = this.fSymbolTable;
        synchronized (symbolTable) {
            try {
                containsSymbol = this.fSymbolTable.containsSymbol(cArr2, i3, i4);
            } catch (Throwable th) {
                Throwable th2 = th;
                SymbolTable symbolTable2 = symbolTable;
                throw th2;
            }
        }
        return containsSymbol;
    }
}
