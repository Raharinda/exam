package org.apache.xerces.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.XMLGrammarDescription;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSResourceResolver;

public class DOMEntityResolverWrapper implements XMLEntityResolver {
    private static final String XML_TYPE = "http://www.w3.org/TR/REC-xml";
    private static final String XSD_TYPE = "http://www.w3.org/2001/XMLSchema";
    protected LSResourceResolver fEntityResolver;

    public DOMEntityResolverWrapper() {
    }

    public DOMEntityResolverWrapper(LSResourceResolver lSResourceResolver) {
        setEntityResolver(lSResourceResolver);
    }

    private String getType(XMLResourceIdentifier xMLResourceIdentifier) {
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        return (!(xMLResourceIdentifier2 instanceof XMLGrammarDescription) || !"http://www.w3.org/2001/XMLSchema".equals(((XMLGrammarDescription) xMLResourceIdentifier2).getGrammarType())) ? "http://www.w3.org/TR/REC-xml" : "http://www.w3.org/2001/XMLSchema";
    }

    public LSResourceResolver getEntityResolver() {
        return this.fEntityResolver;
    }

    public XMLInputSource resolveEntity(XMLResourceIdentifier xMLResourceIdentifier) throws XNIException, IOException {
        XMLInputSource xMLInputSource;
        Reader reader;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        if (this.fEntityResolver != null) {
            LSInput resolveResource = xMLResourceIdentifier2 == null ? this.fEntityResolver.resolveResource((String) null, (String) null, (String) null, (String) null, (String) null) : this.fEntityResolver.resolveResource(getType(xMLResourceIdentifier2), xMLResourceIdentifier2.getNamespace(), xMLResourceIdentifier2.getPublicId(), xMLResourceIdentifier2.getLiteralSystemId(), xMLResourceIdentifier2.getBaseSystemId());
            if (resolveResource != null) {
                String publicId = resolveResource.getPublicId();
                String systemId = resolveResource.getSystemId();
                String baseURI = resolveResource.getBaseURI();
                InputStream byteStream = resolveResource.getByteStream();
                Reader characterStream = resolveResource.getCharacterStream();
                String encoding = resolveResource.getEncoding();
                String stringData = resolveResource.getStringData();
                new XMLInputSource(publicId, systemId, baseURI);
                XMLInputSource xMLInputSource2 = xMLInputSource;
                if (characterStream != null) {
                    xMLInputSource2.setCharacterStream(characterStream);
                } else if (byteStream != null) {
                    xMLInputSource2.setByteStream(byteStream);
                } else if (!(stringData == null || stringData.length() == 0)) {
                    new StringReader(stringData);
                    xMLInputSource2.setCharacterStream(reader);
                }
                xMLInputSource2.setEncoding(encoding);
                return xMLInputSource2;
            }
        }
        return null;
    }

    public void setEntityResolver(LSResourceResolver lSResourceResolver) {
        LSResourceResolver lSResourceResolver2 = lSResourceResolver;
        this.fEntityResolver = lSResourceResolver2;
    }
}
