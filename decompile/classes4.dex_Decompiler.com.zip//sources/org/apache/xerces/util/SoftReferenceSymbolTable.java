package org.apache.xerces.util;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.SoftReference;

public class SoftReferenceSymbolTable extends SymbolTable {
    protected SREntry[] fBuckets;
    private final ReferenceQueue fReferenceQueue;

    protected static final class SREntry extends SoftReference {
        public int bucket;
        public SREntry next;
        public SREntry prev;

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public SREntry(java.lang.String r11, org.apache.xerces.util.SoftReferenceSymbolTable.SREntry r12, int r13, java.lang.ref.ReferenceQueue r14) {
            /*
                r10 = this;
                r0 = r10
                r1 = r11
                r2 = r12
                r3 = r13
                r4 = r14
                r5 = r0
                org.apache.xerces.util.SoftReferenceSymbolTable$SREntryData r6 = new org.apache.xerces.util.SoftReferenceSymbolTable$SREntryData
                r9 = r6
                r6 = r9
                r7 = r9
                r8 = r1
                r7.<init>(r8)
                r7 = r4
                r5.<init>(r6, r7)
                r5 = r0
                r6 = r2
                r7 = r3
                r5.initialize(r6, r7)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.util.SoftReferenceSymbolTable.SREntry.<init>(java.lang.String, org.apache.xerces.util.SoftReferenceSymbolTable$SREntry, int, java.lang.ref.ReferenceQueue):void");
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public SREntry(java.lang.String r17, char[] r18, int r19, int r20, org.apache.xerces.util.SoftReferenceSymbolTable.SREntry r21, int r22, java.lang.ref.ReferenceQueue r23) {
            /*
                r16 = this;
                r0 = r16
                r1 = r17
                r2 = r18
                r3 = r19
                r4 = r20
                r5 = r21
                r6 = r22
                r7 = r23
                r8 = r0
                org.apache.xerces.util.SoftReferenceSymbolTable$SREntryData r9 = new org.apache.xerces.util.SoftReferenceSymbolTable$SREntryData
                r15 = r9
                r9 = r15
                r10 = r15
                r11 = r1
                r12 = r2
                r13 = r3
                r14 = r4
                r10.<init>(r11, r12, r13, r14)
                r10 = r7
                r8.<init>(r9, r10)
                r8 = r0
                r9 = r5
                r10 = r6
                r8.initialize(r9, r10)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.util.SoftReferenceSymbolTable.SREntry.<init>(java.lang.String, char[], int, int, org.apache.xerces.util.SoftReferenceSymbolTable$SREntry, int, java.lang.ref.ReferenceQueue):void");
        }

        private void initialize(SREntry sREntry, int i) {
            SREntry sREntry2 = sREntry;
            int i2 = i;
            this.next = sREntry2;
            if (sREntry2 != null) {
                sREntry2.prev = this;
            }
            this.prev = null;
            this.bucket = i2;
        }
    }

    protected static final class SREntryData {
        public final char[] characters;
        public final String symbol;

        public SREntryData(String str) {
            this.symbol = str;
            this.characters = new char[this.symbol.length()];
            this.symbol.getChars(0, this.characters.length, this.characters, 0);
        }

        public SREntryData(String str, char[] cArr, int i, int i2) {
            int i3 = i2;
            this.symbol = str;
            this.characters = new char[i3];
            System.arraycopy(cArr, i, this.characters, 0, i3);
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SoftReferenceSymbolTable() {
        this(101, 0.75f);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SoftReferenceSymbolTable(int i) {
        this(i, 0.75f);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public SoftReferenceSymbolTable(int r9, float r10) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            r2 = r10
            r3 = r0
            r4 = 1
            r5 = r2
            r3.<init>(r4, r5)
            r3 = r0
            r4 = 0
            r3.fBuckets = r4
            r3 = r1
            if (r3 >= 0) goto L_0x0031
            java.lang.IllegalArgumentException r3 = new java.lang.IllegalArgumentException
            r7 = r3
            r3 = r7
            r4 = r7
            java.lang.StringBuffer r5 = new java.lang.StringBuffer
            r7 = r5
            r5 = r7
            r6 = r7
            r6.<init>()
            java.lang.String r6 = "Illegal Capacity: "
            java.lang.StringBuffer r5 = r5.append(r6)
            r6 = r1
            java.lang.StringBuffer r5 = r5.append(r6)
            java.lang.String r5 = r5.toString()
            r4.<init>(r5)
            throw r3
        L_0x0031:
            r3 = r2
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L_0x003e
            r3 = r2
            boolean r3 = java.lang.Float.isNaN(r3)
            if (r3 == 0) goto L_0x005f
        L_0x003e:
            java.lang.IllegalArgumentException r3 = new java.lang.IllegalArgumentException
            r7 = r3
            r3 = r7
            r4 = r7
            java.lang.StringBuffer r5 = new java.lang.StringBuffer
            r7 = r5
            r5 = r7
            r6 = r7
            r6.<init>()
            java.lang.String r6 = "Illegal Load: "
            java.lang.StringBuffer r5 = r5.append(r6)
            r6 = r2
            java.lang.StringBuffer r5 = r5.append(r6)
            java.lang.String r5 = r5.toString()
            r4.<init>(r5)
            throw r3
        L_0x005f:
            r3 = r1
            if (r3 != 0) goto L_0x0064
            r3 = 1
            r1 = r3
        L_0x0064:
            r3 = r0
            r4 = r2
            r3.fLoadFactor = r4
            r3 = r0
            r4 = r1
            r3.fTableSize = r4
            r3 = r0
            r4 = r0
            int r4 = r4.fTableSize
            org.apache.xerces.util.SoftReferenceSymbolTable$SREntry[] r4 = new org.apache.xerces.util.SoftReferenceSymbolTable.SREntry[r4]
            r3.fBuckets = r4
            r3 = r0
            r4 = r0
            int r4 = r4.fTableSize
            float r4 = (float) r4
            r5 = r2
            float r4 = r4 * r5
            int r4 = (int) r4
            r3.fThreshold = r4
            r3 = r0
            r4 = 0
            r3.fCount = r4
            r3 = r0
            java.lang.ref.ReferenceQueue r4 = new java.lang.ref.ReferenceQueue
            r7 = r4
            r4 = r7
            r5 = r7
            r5.<init>()
            r3.fReferenceQueue = r4
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.util.SoftReferenceSymbolTable.<init>(int, float):void");
    }

    private String addSymbol0(String str, int i, int i2) {
        SREntry sREntry;
        String str2 = str;
        int i3 = i;
        int i4 = i2;
        if (this.fCount >= this.fThreshold) {
            rehash();
            i3 = hash(str2) % this.fTableSize;
        } else if (i4 >= this.fCollisionThreshold) {
            rebalance();
            i3 = hash(str2) % this.fTableSize;
        }
        String intern = str2.intern();
        new SREntry(intern, this.fBuckets[i3], i3, this.fReferenceQueue);
        this.fBuckets[i3] = sREntry;
        this.fCount++;
        return intern;
    }

    private String addSymbol0(char[] cArr, int i, int i2, int i3, int i4) {
        String str;
        SREntry sREntry;
        char[] cArr2 = cArr;
        int i5 = i;
        int i6 = i2;
        int i7 = i3;
        int i8 = i4;
        if (this.fCount >= this.fThreshold) {
            rehash();
            i7 = hash(cArr2, i5, i6) % this.fTableSize;
        } else if (i8 >= this.fCollisionThreshold) {
            rebalance();
            i7 = hash(cArr2, i5, i6) % this.fTableSize;
        }
        new String(cArr2, i5, i6);
        String intern = str.intern();
        new SREntry(intern, cArr2, i5, i6, this.fBuckets[i7], i7, this.fReferenceQueue);
        this.fBuckets[i7] = sREntry;
        this.fCount++;
        return intern;
    }

    private void clean() {
        SREntry sREntry = (SREntry) this.fReferenceQueue.poll();
        if (sREntry != null) {
            do {
                removeEntry(sREntry);
                sREntry = (SREntry) this.fReferenceQueue.poll();
            } while (sREntry != null);
            if (this.fCount < (this.fThreshold >> 2)) {
                compact();
            }
        }
    }

    private void rehashCommon(int i) {
        int i2 = i;
        int length = this.fBuckets.length;
        SREntry[] sREntryArr = this.fBuckets;
        SREntry[] sREntryArr2 = new SREntry[i2];
        this.fThreshold = (int) (((float) i2) * this.fLoadFactor);
        this.fBuckets = sREntryArr2;
        this.fTableSize = this.fBuckets.length;
        int i3 = length;
        while (true) {
            int i4 = i3;
            i3 = i4 - 1;
            if (i4 > 0) {
                SREntry sREntry = sREntryArr[i3];
                while (sREntry != null) {
                    SREntry sREntry2 = sREntry;
                    sREntry = sREntry.next;
                    SREntryData sREntryData = (SREntryData) sREntry2.get();
                    if (sREntryData != null) {
                        int hash = hash(sREntryData.symbol) % i2;
                        if (sREntryArr2[hash] != null) {
                            sREntryArr2[hash].prev = sREntry2;
                        }
                        sREntry2.bucket = hash;
                        sREntry2.next = sREntryArr2[hash];
                        sREntryArr2[hash] = sREntry2;
                    } else {
                        sREntry2.bucket = -1;
                        sREntry2.next = null;
                        this.fCount--;
                    }
                    sREntry2.prev = null;
                }
            } else {
                return;
            }
        }
    }

    private void removeEntry(SREntry sREntry) {
        SREntry sREntry2 = sREntry;
        int i = sREntry2.bucket;
        if (i >= 0) {
            if (sREntry2.next != null) {
                sREntry2.next.prev = sREntry2.prev;
            }
            if (sREntry2.prev != null) {
                sREntry2.prev.next = sREntry2.next;
            } else {
                this.fBuckets[i] = sREntry2.next;
            }
            this.fCount--;
        }
    }

    public String addSymbol(String str) {
        String str2 = str;
        clean();
        int i = 0;
        int hash = hash(str2) % this.fTableSize;
        SREntry sREntry = this.fBuckets[hash];
        while (true) {
            SREntry sREntry2 = sREntry;
            if (sREntry2 == null) {
                return addSymbol0(str2, hash, i);
            }
            SREntryData sREntryData = (SREntryData) sREntry2.get();
            if (sREntryData != null) {
                if (sREntryData.symbol.equals(str2)) {
                    return sREntryData.symbol;
                }
                i++;
            }
            sREntry = sREntry2.next;
        }
    }

    public String addSymbol(char[] cArr, int i, int i2) {
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        clean();
        int i5 = 0;
        int hash = hash(cArr2, i3, i4) % this.fTableSize;
        SREntry sREntry = this.fBuckets[hash];
        while (true) {
            SREntry sREntry2 = sREntry;
            if (sREntry2 == null) {
                return addSymbol0(cArr2, i3, i4, hash, i5);
            }
            SREntryData sREntryData = (SREntryData) sREntry2.get();
            if (sREntryData != null) {
                if (i4 == sREntryData.characters.length) {
                    int i6 = 0;
                    while (i6 < i4) {
                        if (cArr2[i3 + i6] != sREntryData.characters[i6]) {
                            i5++;
                        } else {
                            i6++;
                        }
                    }
                    return sREntryData.symbol;
                }
                i5++;
            }
            sREntry = sREntry2.next;
        }
    }

    /* access modifiers changed from: protected */
    public void compact() {
        rehashCommon((((int) (((float) this.fCount) / this.fLoadFactor)) * 2) + 1);
    }

    public boolean containsSymbol(String str) {
        String str2 = str;
        int hash = hash(str2) % this.fTableSize;
        int length = str2.length();
        SREntry sREntry = this.fBuckets[hash];
        while (true) {
            SREntry sREntry2 = sREntry;
            if (sREntry2 == null) {
                return false;
            }
            SREntryData sREntryData = (SREntryData) sREntry2.get();
            if (sREntryData != null && length == sREntryData.characters.length) {
                int i = 0;
                while (i < length) {
                    if (str2.charAt(i) == sREntryData.characters[i]) {
                        i++;
                    }
                }
                return true;
            }
            sREntry = sREntry2.next;
        }
    }

    public boolean containsSymbol(char[] cArr, int i, int i2) {
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        SREntry sREntry = this.fBuckets[hash(cArr2, i3, i4) % this.fTableSize];
        while (true) {
            SREntry sREntry2 = sREntry;
            if (sREntry2 == null) {
                return false;
            }
            SREntryData sREntryData = (SREntryData) sREntry2.get();
            if (sREntryData != null && i4 == sREntryData.characters.length) {
                int i5 = 0;
                while (i5 < i4) {
                    if (cArr2[i3 + i5] == sREntryData.characters[i5]) {
                        i5++;
                    }
                }
                return true;
            }
            sREntry = sREntry2.next;
        }
    }

    /* access modifiers changed from: protected */
    public void rebalance() {
        if (this.fHashMultipliers == null) {
            this.fHashMultipliers = new int[32];
        }
        PrimeNumberSequenceGenerator.generateSequence(this.fHashMultipliers);
        rehashCommon(this.fBuckets.length);
    }

    /* access modifiers changed from: protected */
    public void rehash() {
        rehashCommon((this.fBuckets.length * 2) + 1);
    }
}
