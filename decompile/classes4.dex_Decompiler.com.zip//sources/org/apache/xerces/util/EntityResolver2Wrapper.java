package org.apache.xerces.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import org.apache.xerces.impl.ExternalSubsetResolver;
import org.apache.xerces.impl.XMLEntityDescription;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.XMLDTDDescription;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.ext.EntityResolver2;

public class EntityResolver2Wrapper implements ExternalSubsetResolver {
    protected EntityResolver2 fEntityResolver;

    public EntityResolver2Wrapper() {
    }

    public EntityResolver2Wrapper(EntityResolver2 entityResolver2) {
        setEntityResolver(entityResolver2);
    }

    private XMLInputSource createXMLInputSource(InputSource inputSource, String str) {
        XMLInputSource xMLInputSource;
        InputSource inputSource2 = inputSource;
        InputStream byteStream = inputSource2.getByteStream();
        Reader characterStream = inputSource2.getCharacterStream();
        String encoding = inputSource2.getEncoding();
        new XMLInputSource(inputSource2.getPublicId(), inputSource2.getSystemId(), str);
        XMLInputSource xMLInputSource2 = xMLInputSource;
        xMLInputSource2.setByteStream(byteStream);
        xMLInputSource2.setCharacterStream(characterStream);
        xMLInputSource2.setEncoding(encoding);
        return xMLInputSource2;
    }

    public EntityResolver2 getEntityResolver() {
        return this.fEntityResolver;
    }

    public XMLInputSource getExternalSubset(XMLDTDDescription xMLDTDDescription) throws XNIException, IOException {
        Throwable th;
        XMLDTDDescription xMLDTDDescription2 = xMLDTDDescription;
        if (this.fEntityResolver == null) {
            return null;
        }
        String rootName = xMLDTDDescription2.getRootName();
        String baseSystemId = xMLDTDDescription2.getBaseSystemId();
        try {
            InputSource externalSubset = this.fEntityResolver.getExternalSubset(rootName, baseSystemId);
            return externalSubset != null ? createXMLInputSource(externalSubset, baseSystemId) : null;
        } catch (SAXException e) {
            Exception exc = e;
            Exception exception = exc.getException();
            if (exception == null) {
                exception = exc;
            }
            Throwable th2 = th;
            new XNIException(exception);
            throw th2;
        }
    }

    public XMLInputSource resolveEntity(XMLResourceIdentifier xMLResourceIdentifier) throws XNIException, IOException {
        Throwable th;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        if (this.fEntityResolver == null) {
            return null;
        }
        String publicId = xMLResourceIdentifier2.getPublicId();
        String literalSystemId = xMLResourceIdentifier2.getLiteralSystemId();
        String baseSystemId = xMLResourceIdentifier2.getBaseSystemId();
        String str = null;
        if (xMLResourceIdentifier2 instanceof XMLDTDDescription) {
            str = "[dtd]";
        } else if (xMLResourceIdentifier2 instanceof XMLEntityDescription) {
            str = ((XMLEntityDescription) xMLResourceIdentifier2).getEntityName();
        }
        if (publicId == null && literalSystemId == null) {
            return null;
        }
        try {
            InputSource resolveEntity = this.fEntityResolver.resolveEntity(str, publicId, baseSystemId, literalSystemId);
            return resolveEntity != null ? createXMLInputSource(resolveEntity, baseSystemId) : null;
        } catch (SAXException e) {
            Exception exc = e;
            Exception exception = exc.getException();
            if (exception == null) {
                exception = exc;
            }
            Throwable th2 = th;
            new XNIException(exception);
            throw th2;
        }
    }

    public void setEntityResolver(EntityResolver2 entityResolver2) {
        EntityResolver2 entityResolver22 = entityResolver2;
        this.fEntityResolver = entityResolver22;
    }
}
