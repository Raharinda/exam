package org.apache.xerces.util;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.apache.xerces.xni.parser.XMLInputSource;

public final class StAXInputSource extends XMLInputSource {
    private final boolean fConsumeRemainingContent;
    private final XMLEventReader fEventReader;
    private final XMLStreamReader fStreamReader;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public StAXInputSource(XMLEventReader xMLEventReader) {
        this(xMLEventReader, false);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public StAXInputSource(javax.xml.stream.XMLEventReader r9, boolean r10) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            r2 = r10
            r3 = r0
            r4 = 0
            r5 = r1
            java.lang.String r5 = getEventReaderSystemId(r5)
            r6 = 0
            r3.<init>(r4, r5, r6)
            r3 = r1
            if (r3 != 0) goto L_0x001d
            java.lang.IllegalArgumentException r3 = new java.lang.IllegalArgumentException
            r7 = r3
            r3 = r7
            r4 = r7
            java.lang.String r5 = "XMLEventReader parameter cannot be null."
            r4.<init>(r5)
            throw r3
        L_0x001d:
            r3 = r0
            r4 = 0
            r3.fStreamReader = r4
            r3 = r0
            r4 = r1
            r3.fEventReader = r4
            r3 = r0
            r4 = r2
            r3.fConsumeRemainingContent = r4
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.util.StAXInputSource.<init>(javax.xml.stream.XMLEventReader, boolean):void");
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public StAXInputSource(XMLStreamReader xMLStreamReader) {
        this(xMLStreamReader, false);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public StAXInputSource(javax.xml.stream.XMLStreamReader r9, boolean r10) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            r2 = r10
            r3 = r0
            r4 = 0
            r5 = r1
            java.lang.String r5 = getStreamReaderSystemId(r5)
            r6 = 0
            r3.<init>(r4, r5, r6)
            r3 = r1
            if (r3 != 0) goto L_0x001d
            java.lang.IllegalArgumentException r3 = new java.lang.IllegalArgumentException
            r7 = r3
            r3 = r7
            r4 = r7
            java.lang.String r5 = "XMLStreamReader parameter cannot be null."
            r4.<init>(r5)
            throw r3
        L_0x001d:
            r3 = r0
            r4 = r1
            r3.fStreamReader = r4
            r3 = r0
            r4 = 0
            r3.fEventReader = r4
            r3 = r0
            r4 = r2
            r3.fConsumeRemainingContent = r4
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.util.StAXInputSource.<init>(javax.xml.stream.XMLStreamReader, boolean):void");
    }

    private static String getEventReaderSystemId(XMLEventReader xMLEventReader) {
        XMLEventReader xMLEventReader2 = xMLEventReader;
        if (xMLEventReader2 != null) {
            try {
                return xMLEventReader2.peek().getLocation().getSystemId();
            } catch (XMLStreamException e) {
                XMLStreamException xMLStreamException = e;
            }
        }
        return null;
    }

    private static String getStreamReaderSystemId(XMLStreamReader xMLStreamReader) {
        XMLStreamReader xMLStreamReader2 = xMLStreamReader;
        if (xMLStreamReader2 != null) {
            return xMLStreamReader2.getLocation().getSystemId();
        }
        return null;
    }

    public XMLEventReader getXMLEventReader() {
        return this.fEventReader;
    }

    public XMLStreamReader getXMLStreamReader() {
        return this.fStreamReader;
    }

    public void setSystemId(String str) {
        Throwable th;
        String str2 = str;
        Throwable th2 = th;
        new UnsupportedOperationException("Cannot set the system ID on a StAXInputSource");
        throw th2;
    }

    public boolean shouldConsumeRemainingContent() {
        return this.fConsumeRemainingContent;
    }
}
