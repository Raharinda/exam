package org.apache.xerces.util;

final class XMLErrorCode {
    private String fDomain;
    private String fKey;

    public XMLErrorCode(String str, String str2) {
        this.fDomain = str;
        this.fKey = str2;
    }

    public boolean equals(Object obj) {
        Object obj2 = obj;
        if (!(obj2 instanceof XMLErrorCode)) {
            return false;
        }
        XMLErrorCode xMLErrorCode = (XMLErrorCode) obj2;
        return this.fDomain.equals(xMLErrorCode.fDomain) && this.fKey.equals(xMLErrorCode.fKey);
    }

    public int hashCode() {
        return this.fDomain.hashCode() + this.fKey.hashCode();
    }

    public void setValues(String str, String str2) {
        this.fDomain = str;
        this.fKey = str2;
    }
}
