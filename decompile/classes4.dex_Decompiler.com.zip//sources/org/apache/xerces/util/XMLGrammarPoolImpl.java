package org.apache.xerces.util;

import org.apache.xerces.dom3.as.ASContentModel;
import org.apache.xerces.xni.grammars.Grammar;
import org.apache.xerces.xni.grammars.XMLGrammarDescription;
import org.apache.xerces.xni.grammars.XMLGrammarPool;

public class XMLGrammarPoolImpl implements XMLGrammarPool {
    private static final boolean DEBUG = false;
    protected static final int TABLE_SIZE = 11;
    protected int fGrammarCount;
    protected Entry[] fGrammars;
    protected boolean fPoolIsLocked;

    protected static final class Entry {
        public XMLGrammarDescription desc;
        public Grammar grammar;
        public int hash;
        public Entry next;

        protected Entry(int i, XMLGrammarDescription xMLGrammarDescription, Grammar grammar2, Entry entry) {
            this.hash = i;
            this.desc = xMLGrammarDescription;
            this.grammar = grammar2;
            this.next = entry;
        }

        /* access modifiers changed from: protected */
        public void clear() {
            this.desc = null;
            this.grammar = null;
            if (this.next != null) {
                this.next.clear();
                this.next = null;
            }
        }
    }

    public XMLGrammarPoolImpl() {
        this.fGrammars = null;
        this.fGrammarCount = 0;
        this.fGrammars = new Entry[TABLE_SIZE];
        this.fPoolIsLocked = false;
    }

    public XMLGrammarPoolImpl(int i) {
        this.fGrammars = null;
        this.fGrammarCount = 0;
        this.fGrammars = new Entry[i];
        this.fPoolIsLocked = false;
    }

    public void cacheGrammars(String str, Grammar[] grammarArr) {
        String str2 = str;
        Grammar[] grammarArr2 = grammarArr;
        if (!this.fPoolIsLocked) {
            for (int i = 0; i < grammarArr2.length; i++) {
                putGrammar(grammarArr2[i]);
            }
        }
    }

    public void clear() {
        for (int i = 0; i < this.fGrammars.length; i++) {
            if (this.fGrammars[i] != null) {
                this.fGrammars[i].clear();
                this.fGrammars[i] = null;
            }
        }
        this.fGrammarCount = 0;
    }

    /* JADX INFO: finally extract failed */
    public boolean containsGrammar(XMLGrammarDescription xMLGrammarDescription) {
        XMLGrammarDescription xMLGrammarDescription2 = xMLGrammarDescription;
        Entry[] entryArr = this.fGrammars;
        synchronized (entryArr) {
            try {
                int hashCode = hashCode(xMLGrammarDescription2);
                Entry entry = this.fGrammars[(hashCode & ASContentModel.AS_UNBOUNDED) % this.fGrammars.length];
                while (true) {
                    Entry entry2 = entry;
                    if (entry2 == null) {
                        return false;
                    }
                    if (entry2.hash == hashCode && equals(entry2.desc, xMLGrammarDescription2)) {
                        return true;
                    }
                    entry = entry2.next;
                }
            } catch (Throwable th) {
                Throwable th2 = th;
                Entry[] entryArr2 = entryArr;
                throw th2;
            }
        }
    }

    public boolean equals(XMLGrammarDescription xMLGrammarDescription, XMLGrammarDescription xMLGrammarDescription2) {
        return xMLGrammarDescription.equals(xMLGrammarDescription2);
    }

    /* JADX INFO: finally extract failed */
    public Grammar getGrammar(XMLGrammarDescription xMLGrammarDescription) {
        XMLGrammarDescription xMLGrammarDescription2 = xMLGrammarDescription;
        Entry[] entryArr = this.fGrammars;
        synchronized (entryArr) {
            try {
                int hashCode = hashCode(xMLGrammarDescription2);
                Entry entry = this.fGrammars[(hashCode & ASContentModel.AS_UNBOUNDED) % this.fGrammars.length];
                while (true) {
                    Entry entry2 = entry;
                    if (entry2 == null) {
                        return null;
                    }
                    if (entry2.hash != hashCode || !equals(entry2.desc, xMLGrammarDescription2)) {
                        entry = entry2.next;
                    } else {
                        Grammar grammar = entry2.grammar;
                        return grammar;
                    }
                }
            } catch (Throwable th) {
                Throwable th2 = th;
                Entry[] entryArr2 = entryArr;
                throw th2;
            }
        }
    }

    public int hashCode(XMLGrammarDescription xMLGrammarDescription) {
        return xMLGrammarDescription.hashCode();
    }

    public void lockPool() {
        this.fPoolIsLocked = true;
    }

    /* JADX INFO: finally extract failed */
    public void putGrammar(Grammar grammar) {
        Entry entry;
        Grammar grammar2 = grammar;
        if (!this.fPoolIsLocked) {
            Entry[] entryArr = this.fGrammars;
            synchronized (entryArr) {
                try {
                    XMLGrammarDescription grammarDescription = grammar2.getGrammarDescription();
                    int hashCode = hashCode(grammarDescription);
                    int length = (hashCode & ASContentModel.AS_UNBOUNDED) % this.fGrammars.length;
                    Entry entry2 = this.fGrammars[length];
                    while (true) {
                        Entry entry3 = entry2;
                        if (entry3 == null) {
                            new Entry(hashCode, grammarDescription, grammar2, this.fGrammars[length]);
                            this.fGrammars[length] = entry;
                            this.fGrammarCount++;
                            return;
                        } else if (entry3.hash != hashCode || !equals(entry3.desc, grammarDescription)) {
                            entry2 = entry3.next;
                        } else {
                            entry3.grammar = grammar2;
                            return;
                        }
                    }
                } catch (Throwable th) {
                    Throwable th2 = th;
                    Entry[] entryArr2 = entryArr;
                    throw th2;
                }
            }
        }
    }

    /* JADX INFO: finally extract failed */
    public Grammar removeGrammar(XMLGrammarDescription xMLGrammarDescription) {
        XMLGrammarDescription xMLGrammarDescription2 = xMLGrammarDescription;
        Entry[] entryArr = this.fGrammars;
        synchronized (entryArr) {
            try {
                int hashCode = hashCode(xMLGrammarDescription2);
                int length = (hashCode & ASContentModel.AS_UNBOUNDED) % this.fGrammars.length;
                Entry entry = this.fGrammars[length];
                Entry entry2 = null;
                while (entry != null) {
                    if (entry.hash != hashCode || !equals(entry.desc, xMLGrammarDescription2)) {
                        entry2 = entry;
                        entry = entry.next;
                    } else {
                        if (entry2 != null) {
                            entry2.next = entry.next;
                        } else {
                            this.fGrammars[length] = entry.next;
                        }
                        Grammar grammar = entry.grammar;
                        entry.grammar = null;
                        this.fGrammarCount--;
                        Grammar grammar2 = grammar;
                        return grammar2;
                    }
                }
                return null;
            } catch (Throwable th) {
                Throwable th2 = th;
                Entry[] entryArr2 = entryArr;
                throw th2;
            }
        }
    }

    public Grammar retrieveGrammar(XMLGrammarDescription xMLGrammarDescription) {
        return getGrammar(xMLGrammarDescription);
    }

    /* JADX INFO: finally extract failed */
    public Grammar[] retrieveInitialGrammarSet(String str) {
        Grammar[] grammarArr;
        String str2 = str;
        Entry[] entryArr = this.fGrammars;
        synchronized (entryArr) {
            try {
                int length = this.fGrammars.length;
                Grammar[] grammarArr2 = new Grammar[this.fGrammarCount];
                int i = 0;
                for (int i2 = 0; i2 < length; i2++) {
                    Entry entry = this.fGrammars[i2];
                    while (true) {
                        Entry entry2 = entry;
                        if (entry2 == null) {
                            break;
                        }
                        if (entry2.desc.getGrammarType().equals(str2)) {
                            int i3 = i;
                            i++;
                            grammarArr2[i3] = entry2.grammar;
                        }
                        entry = entry2.next;
                    }
                }
                Grammar[] grammarArr3 = new Grammar[i];
                System.arraycopy(grammarArr2, 0, grammarArr3, 0, i);
                grammarArr = grammarArr3;
            } catch (Throwable th) {
                Throwable th2 = th;
                Entry[] entryArr2 = entryArr;
                throw th2;
            }
        }
        return grammarArr;
    }

    public void unlockPool() {
        this.fPoolIsLocked = false;
    }
}
