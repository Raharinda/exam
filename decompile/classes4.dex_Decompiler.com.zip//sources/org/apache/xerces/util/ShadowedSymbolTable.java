package org.apache.xerces.util;

public final class ShadowedSymbolTable extends SymbolTable {
    protected SymbolTable fSymbolTable;

    public ShadowedSymbolTable(SymbolTable symbolTable) {
        this.fSymbolTable = symbolTable;
    }

    public String addSymbol(String str) {
        String str2 = str;
        return this.fSymbolTable.containsSymbol(str2) ? this.fSymbolTable.addSymbol(str2) : super.addSymbol(str2);
    }

    public String addSymbol(char[] cArr, int i, int i2) {
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        return this.fSymbolTable.containsSymbol(cArr2, i3, i4) ? this.fSymbolTable.addSymbol(cArr2, i3, i4) : super.addSymbol(cArr2, i3, i4);
    }

    public int hash(String str) {
        return this.fSymbolTable.hash(str);
    }

    public int hash(char[] cArr, int i, int i2) {
        return this.fSymbolTable.hash(cArr, i, i2);
    }
}
