package org.apache.xerces.dom3.as;

public interface DocumentEditAS extends NodeEditAS {
    boolean getContinuousValidityChecking();

    void setContinuousValidityChecking(boolean z);
}
