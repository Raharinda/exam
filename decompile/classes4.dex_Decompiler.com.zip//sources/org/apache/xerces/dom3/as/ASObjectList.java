package org.apache.xerces.dom3.as;

public interface ASObjectList {
    int getLength();

    ASObject item(int i);
}
