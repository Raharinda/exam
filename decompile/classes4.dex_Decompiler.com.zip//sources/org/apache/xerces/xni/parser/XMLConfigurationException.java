package org.apache.xerces.xni.parser;

import org.apache.xerces.xni.XNIException;

public class XMLConfigurationException extends XNIException {
    public static final short NOT_RECOGNIZED = 0;
    public static final short NOT_SUPPORTED = 1;
    static final long serialVersionUID = -5437427404547669188L;
    protected String fIdentifier;
    protected short fType;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XMLConfigurationException(short r6, java.lang.String r7) {
        /*
            r5 = this;
            r0 = r5
            r1 = r6
            r2 = r7
            r3 = r0
            r4 = r2
            r3.<init>((java.lang.String) r4)
            r3 = r0
            r4 = r1
            r3.fType = r4
            r3 = r0
            r4 = r2
            r3.fIdentifier = r4
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.xni.parser.XMLConfigurationException.<init>(short, java.lang.String):void");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public XMLConfigurationException(short s, String str, String str2) {
        super(str2);
        this.fType = s;
        this.fIdentifier = str;
    }

    public String getIdentifier() {
        return this.fIdentifier;
    }

    public short getType() {
        return this.fType;
    }
}
