package org.apache.xerces.xni;

public class QName implements Cloneable {
    public String localpart;
    public String prefix;
    public String rawname;
    public String uri;

    public QName() {
        clear();
    }

    public QName(String str, String str2, String str3, String str4) {
        setValues(str, str2, str3, str4);
    }

    public QName(QName qName) {
        setValues(qName);
    }

    public void clear() {
        this.prefix = null;
        this.localpart = null;
        this.rawname = null;
        this.uri = null;
    }

    public Object clone() {
        Object obj;
        new QName(this);
        return obj;
    }

    public boolean equals(Object obj) {
        Object obj2 = obj;
        if (obj2 instanceof QName) {
            QName qName = (QName) obj2;
            if (qName.uri != null) {
                return this.uri == qName.uri && this.localpart == qName.localpart;
            } else if (this.uri == null) {
                return this.rawname == qName.rawname;
            }
        }
        return false;
    }

    public int hashCode() {
        if (this.uri != null) {
            return this.uri.hashCode() + (this.localpart != null ? this.localpart.hashCode() : 0);
        }
        return this.rawname != null ? this.rawname.hashCode() : 0;
    }

    public void setValues(String str, String str2, String str3, String str4) {
        this.prefix = str;
        this.localpart = str2;
        this.rawname = str3;
        this.uri = str4;
    }

    public void setValues(QName qName) {
        QName qName2 = qName;
        this.prefix = qName2.prefix;
        this.localpart = qName2.localpart;
        this.rawname = qName2.rawname;
        this.uri = qName2.uri;
    }

    public String toString() {
        StringBuffer stringBuffer;
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        boolean z = false;
        if (this.prefix != null) {
            StringBuffer append = stringBuffer2.append("prefix=\"").append(this.prefix).append('\"');
            z = true;
        }
        if (this.localpart != null) {
            if (z) {
                StringBuffer append2 = stringBuffer2.append(',');
            }
            StringBuffer append3 = stringBuffer2.append("localpart=\"").append(this.localpart).append('\"');
            z = true;
        }
        if (this.rawname != null) {
            if (z) {
                StringBuffer append4 = stringBuffer2.append(',');
            }
            StringBuffer append5 = stringBuffer2.append("rawname=\"").append(this.rawname).append('\"');
            z = true;
        }
        if (this.uri != null) {
            if (z) {
                StringBuffer append6 = stringBuffer2.append(',');
            }
            StringBuffer append7 = stringBuffer2.append("uri=\"").append(this.uri).append('\"');
        }
        return stringBuffer2.toString();
    }
}
