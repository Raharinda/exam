package org.apache.xerces.xni;

public class XMLString {
    public char[] ch;
    public int length;
    public int offset;

    public XMLString() {
    }

    public XMLString(XMLString xMLString) {
        setValues(xMLString);
    }

    public XMLString(char[] cArr, int i, int i2) {
        setValues(cArr, i, i2);
    }

    public void clear() {
        this.ch = null;
        this.offset = 0;
        this.length = -1;
    }

    public boolean equals(String str) {
        String str2 = str;
        if (str2 == null) {
            return false;
        }
        if (this.length != str2.length()) {
            return false;
        }
        for (int i = 0; i < this.length; i++) {
            if (this.ch[this.offset + i] != str2.charAt(i)) {
                return false;
            }
        }
        return true;
    }

    public boolean equals(char[] cArr, int i, int i2) {
        char[] cArr2 = cArr;
        int i3 = i;
        int i4 = i2;
        if (cArr2 == null) {
            return false;
        }
        if (this.length != i4) {
            return false;
        }
        for (int i5 = 0; i5 < i4; i5++) {
            if (this.ch[this.offset + i5] != cArr2[i3 + i5]) {
                return false;
            }
        }
        return true;
    }

    public void setValues(XMLString xMLString) {
        XMLString xMLString2 = xMLString;
        setValues(xMLString2.ch, xMLString2.offset, xMLString2.length);
    }

    public void setValues(char[] cArr, int i, int i2) {
        this.ch = cArr;
        this.offset = i;
        this.length = i2;
    }

    public String toString() {
        String str;
        String str2;
        if (this.length > 0) {
            str = str2;
            new String(this.ch, this.offset, this.length);
        } else {
            str = "";
        }
        return str;
    }
}
