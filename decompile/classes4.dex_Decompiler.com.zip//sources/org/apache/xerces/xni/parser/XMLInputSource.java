package org.apache.xerces.xni.parser;

import java.io.InputStream;
import java.io.Reader;
import org.apache.xerces.xni.XMLResourceIdentifier;

public class XMLInputSource {
    protected String fBaseSystemId;
    protected InputStream fByteStream;
    protected Reader fCharStream;
    protected String fEncoding;
    protected String fPublicId;
    protected String fSystemId;

    public XMLInputSource(String str, String str2, String str3) {
        this.fPublicId = str;
        this.fSystemId = str2;
        this.fBaseSystemId = str3;
    }

    public XMLInputSource(String str, String str2, String str3, InputStream inputStream, String str4) {
        this.fPublicId = str;
        this.fSystemId = str2;
        this.fBaseSystemId = str3;
        this.fByteStream = inputStream;
        this.fEncoding = str4;
    }

    public XMLInputSource(String str, String str2, String str3, Reader reader, String str4) {
        this.fPublicId = str;
        this.fSystemId = str2;
        this.fBaseSystemId = str3;
        this.fCharStream = reader;
        this.fEncoding = str4;
    }

    public XMLInputSource(XMLResourceIdentifier xMLResourceIdentifier) {
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        this.fPublicId = xMLResourceIdentifier2.getPublicId();
        this.fSystemId = xMLResourceIdentifier2.getLiteralSystemId();
        this.fBaseSystemId = xMLResourceIdentifier2.getBaseSystemId();
    }

    public String getBaseSystemId() {
        return this.fBaseSystemId;
    }

    public InputStream getByteStream() {
        return this.fByteStream;
    }

    public Reader getCharacterStream() {
        return this.fCharStream;
    }

    public String getEncoding() {
        return this.fEncoding;
    }

    public String getPublicId() {
        return this.fPublicId;
    }

    public String getSystemId() {
        return this.fSystemId;
    }

    public void setBaseSystemId(String str) {
        String str2 = str;
        this.fBaseSystemId = str2;
    }

    public void setByteStream(InputStream inputStream) {
        InputStream inputStream2 = inputStream;
        this.fByteStream = inputStream2;
    }

    public void setCharacterStream(Reader reader) {
        Reader reader2 = reader;
        this.fCharStream = reader2;
    }

    public void setEncoding(String str) {
        String str2 = str;
        this.fEncoding = str2;
    }

    public void setPublicId(String str) {
        String str2 = str;
        this.fPublicId = str2;
    }

    public void setSystemId(String str) {
        String str2 = str;
        this.fSystemId = str2;
    }
}
