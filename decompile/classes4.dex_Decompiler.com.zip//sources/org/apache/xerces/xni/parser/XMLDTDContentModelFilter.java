package org.apache.xerces.xni.parser;

import org.apache.xerces.xni.XMLDTDContentModelHandler;

public interface XMLDTDContentModelFilter extends XMLDTDContentModelHandler, XMLDTDContentModelSource {
}
