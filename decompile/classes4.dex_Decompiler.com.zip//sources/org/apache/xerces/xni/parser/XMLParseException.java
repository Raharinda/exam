package org.apache.xerces.xni.parser;

import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XNIException;

public class XMLParseException extends XNIException {
    static final long serialVersionUID = 1732959359448549967L;
    protected String fBaseSystemId;
    protected int fCharacterOffset = -1;
    protected int fColumnNumber = -1;
    protected String fExpandedSystemId;
    protected int fLineNumber = -1;
    protected String fLiteralSystemId;
    protected String fPublicId;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public XMLParseException(XMLLocator xMLLocator, String str) {
        super(str);
        XMLLocator xMLLocator2 = xMLLocator;
        if (xMLLocator2 != null) {
            this.fPublicId = xMLLocator2.getPublicId();
            this.fLiteralSystemId = xMLLocator2.getLiteralSystemId();
            this.fExpandedSystemId = xMLLocator2.getExpandedSystemId();
            this.fBaseSystemId = xMLLocator2.getBaseSystemId();
            this.fLineNumber = xMLLocator2.getLineNumber();
            this.fColumnNumber = xMLLocator2.getColumnNumber();
            this.fCharacterOffset = xMLLocator2.getCharacterOffset();
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public XMLParseException(XMLLocator xMLLocator, String str, Exception exc) {
        super(str, exc);
        XMLLocator xMLLocator2 = xMLLocator;
        if (xMLLocator2 != null) {
            this.fPublicId = xMLLocator2.getPublicId();
            this.fLiteralSystemId = xMLLocator2.getLiteralSystemId();
            this.fExpandedSystemId = xMLLocator2.getExpandedSystemId();
            this.fBaseSystemId = xMLLocator2.getBaseSystemId();
            this.fLineNumber = xMLLocator2.getLineNumber();
            this.fColumnNumber = xMLLocator2.getColumnNumber();
            this.fCharacterOffset = xMLLocator2.getCharacterOffset();
        }
    }

    public String getBaseSystemId() {
        return this.fBaseSystemId;
    }

    public int getCharacterOffset() {
        return this.fCharacterOffset;
    }

    public int getColumnNumber() {
        return this.fColumnNumber;
    }

    public String getExpandedSystemId() {
        return this.fExpandedSystemId;
    }

    public int getLineNumber() {
        return this.fLineNumber;
    }

    public String getLiteralSystemId() {
        return this.fLiteralSystemId;
    }

    public String getPublicId() {
        return this.fPublicId;
    }

    public String toString() {
        StringBuffer stringBuffer;
        Exception exception;
        new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer;
        if (this.fPublicId != null) {
            StringBuffer append = stringBuffer2.append(this.fPublicId);
        }
        StringBuffer append2 = stringBuffer2.append(':');
        if (this.fLiteralSystemId != null) {
            StringBuffer append3 = stringBuffer2.append(this.fLiteralSystemId);
        }
        StringBuffer append4 = stringBuffer2.append(':');
        if (this.fExpandedSystemId != null) {
            StringBuffer append5 = stringBuffer2.append(this.fExpandedSystemId);
        }
        StringBuffer append6 = stringBuffer2.append(':');
        if (this.fBaseSystemId != null) {
            StringBuffer append7 = stringBuffer2.append(this.fBaseSystemId);
        }
        StringBuffer append8 = stringBuffer2.append(':');
        StringBuffer append9 = stringBuffer2.append(this.fLineNumber);
        StringBuffer append10 = stringBuffer2.append(':');
        StringBuffer append11 = stringBuffer2.append(this.fColumnNumber);
        StringBuffer append12 = stringBuffer2.append(':');
        StringBuffer append13 = stringBuffer2.append(this.fCharacterOffset);
        StringBuffer append14 = stringBuffer2.append(':');
        String message = getMessage();
        if (message == null && (exception = getException()) != null) {
            message = exception.getMessage();
        }
        if (message != null) {
            StringBuffer append15 = stringBuffer2.append(message);
        }
        return stringBuffer2.toString();
    }
}
