package org.apache.xerces.xni.parser;

import org.apache.xerces.xni.XMLDocumentHandler;

public interface XMLDocumentFilter extends XMLDocumentHandler, XMLDocumentSource {
}
