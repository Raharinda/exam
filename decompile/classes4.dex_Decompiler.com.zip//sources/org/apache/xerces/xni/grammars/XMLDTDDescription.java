package org.apache.xerces.xni.grammars;

public interface XMLDTDDescription extends XMLGrammarDescription {
    String getRootName();
}
