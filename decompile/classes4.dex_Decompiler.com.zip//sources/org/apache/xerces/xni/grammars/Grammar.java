package org.apache.xerces.xni.grammars;

public interface Grammar {
    XMLGrammarDescription getGrammarDescription();
}
