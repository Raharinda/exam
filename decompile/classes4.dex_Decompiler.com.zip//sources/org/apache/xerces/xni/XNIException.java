package org.apache.xerces.xni;

public class XNIException extends RuntimeException {
    static final long serialVersionUID = 9019819772686063775L;
    private Exception fException = this;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XNIException(java.lang.Exception r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r0
            r3 = r1
            java.lang.String r3 = r3.getMessage()
            r2.<init>(r3)
            r2 = r0
            r3 = r0
            r2.fException = r3
            r2 = r0
            r3 = r1
            r2.fException = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.xni.XNIException.<init>(java.lang.Exception):void");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public XNIException(String str) {
        super(str);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public XNIException(String str, Exception exc) {
        super(str);
        this.fException = exc;
    }

    public Throwable getCause() {
        return getException();
    }

    public Exception getException() {
        return this.fException != this ? this.fException : null;
    }

    /* JADX WARNING: type inference failed for: r7v0, types: [java.lang.Throwable] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized java.lang.Throwable initCause(java.lang.Throwable r7) {
        /*
            r6 = this;
            r0 = r6
            r1 = r7
            r4 = r6
            monitor-enter(r4)
            r2 = r0
            java.lang.Exception r2 = r2.fException     // Catch:{ all -> 0x0013 }
            r3 = r0
            if (r2 == r3) goto L_0x0016
            java.lang.IllegalStateException r2 = new java.lang.IllegalStateException     // Catch:{ all -> 0x0013 }
            r5 = r2
            r2 = r5
            r3 = r5
            r3.<init>()     // Catch:{ all -> 0x0013 }
            throw r2     // Catch:{ all -> 0x0013 }
        L_0x0013:
            r0 = move-exception
            monitor-exit(r4)
            throw r0
        L_0x0016:
            r2 = r1
            r3 = r0
            if (r2 != r3) goto L_0x0023
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x0013 }
            r5 = r2
            r2 = r5
            r3 = r5
            r3.<init>()     // Catch:{ all -> 0x0013 }
            throw r2     // Catch:{ all -> 0x0013 }
        L_0x0023:
            r2 = r0
            r3 = r1
            java.lang.Exception r3 = (java.lang.Exception) r3     // Catch:{ all -> 0x0013 }
            r2.fException = r3     // Catch:{ all -> 0x0013 }
            r2 = r0
            r0 = r2
            monitor-exit(r4)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.xni.XNIException.initCause(java.lang.Throwable):java.lang.Throwable");
    }
}
