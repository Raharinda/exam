package org.apache.xerces.xpointer;

import java.util.HashMap;
import net.lingala.zip4j.util.Zip4jConstants;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.util.MessageFormatter;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLErrorHandler;

final class ElementSchemePointer implements XPointerPart {
    private int[] fChildSequence;
    private int fCurrentChildDepth = 0;
    private int fCurrentChildPosition = 1;
    private int[] fCurrentChildSequence;
    protected XMLErrorHandler fErrorHandler;
    protected XMLErrorReporter fErrorReporter;
    int fFoundDepth = 0;
    private boolean fIsElementFound = false;
    private boolean fIsFragmentResolved = false;
    private boolean fIsResolveElement = false;
    boolean fIsShortHand = false;
    private String fSchemeData;
    private String fSchemeName;
    private ShortHandPointer fShortHandPointer;
    private String fShortHandPointerName;
    private SymbolTable fSymbolTable;
    private boolean fWasOnlyEmptyElementFound = false;

    private class Scanner {
        private static final byte CHARTYPE_DIGIT = 5;
        private static final byte CHARTYPE_INVALID = 0;
        private static final byte CHARTYPE_LETTER = 6;
        private static final byte CHARTYPE_MINUS = 2;
        private static final byte CHARTYPE_NONASCII = 8;
        private static final byte CHARTYPE_OTHER = 1;
        private static final byte CHARTYPE_PERIOD = 3;
        private static final byte CHARTYPE_SLASH = 4;
        private static final byte CHARTYPE_UNDERSCORE = 7;
        private final byte[] fASCIICharMap;
        private SymbolTable fSymbolTable;
        private final ElementSchemePointer this$0;

        private Scanner(ElementSchemePointer elementSchemePointer, SymbolTable symbolTable) {
            this.this$0 = elementSchemePointer;
            this.fASCIICharMap = new byte[]{CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_OTHER, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_MINUS, CHARTYPE_MINUS, CHARTYPE_SLASH, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_UNDERSCORE, CHARTYPE_OTHER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER};
            this.fSymbolTable = symbolTable;
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        Scanner(ElementSchemePointer elementSchemePointer, SymbolTable symbolTable, AnonymousClass1 r10) {
            this(elementSchemePointer, symbolTable);
            AnonymousClass1 r3 = r10;
        }

        static boolean access$300(Scanner scanner, SymbolTable symbolTable, Tokens tokens, String str, int i, int i2) throws XNIException {
            return scanner.scanExpr(symbolTable, tokens, str, i, i2);
        }

        private boolean scanExpr(SymbolTable symbolTable, Tokens tokens, String str, int i, int i2) throws XNIException {
            Object obj;
            SymbolTable symbolTable2 = symbolTable;
            Tokens tokens2 = tokens;
            String str2 = str;
            int i3 = i;
            int i4 = i2;
            while (i3 != i4) {
                char charAt = str2.charAt(i3);
                switch (charAt >= 128 ? CHARTYPE_NONASCII : this.fASCIICharMap[charAt]) {
                    case 1:
                    case 2:
                    case 3:
                    case 5:
                    case 6:
                    case Zip4jConstants.DEFLATE_LEVEL_MAXIMUM:
                    case 8:
                        int i5 = i3;
                        i3 = scanNCName(str2, i4, i3);
                        if (i3 != i5) {
                            char charAt2 = i3 < i4 ? str2.charAt(i3) : 65535;
                            String addSymbol = symbolTable2.addSymbol(str2.substring(i5, i3));
                            addToken(tokens2, 0);
                            Tokens.access$800(tokens2, addSymbol);
                            break;
                        } else {
                            this.this$0.reportError("InvalidNCNameInElementSchemeData", new Object[]{str2});
                            return false;
                        }
                    case 4:
                        i3++;
                        if (i3 != i4) {
                            addToken(tokens2, 1);
                            char charAt3 = str2.charAt(i3);
                            int i6 = 0;
                            while (charAt3 >= '0' && charAt3 <= '9') {
                                i6 = (i6 * 10) + (charAt3 - '0');
                                i3++;
                                if (i3 != i4) {
                                    charAt3 = str2.charAt(i3);
                                }
                            }
                            if (i6 != 0) {
                                Tokens.access$700(tokens2, i6);
                                break;
                            } else {
                                new Character((char) charAt3);
                                this.this$0.reportError("InvalidChildSequenceCharacter", new Object[]{obj});
                                return false;
                            }
                        } else {
                            return false;
                        }
                        break;
                }
            }
            return true;
        }

        /* JADX WARNING: CFG modification limit reached, blocks count: 132 */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x0042, code lost:
            r5 = r0.fASCIICharMap[r4];
         */
        /* JADX WARNING: Code restructure failed: missing block: B:17:0x004b, code lost:
            if (r5 == 6) goto L_0x005e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:19:0x004f, code lost:
            if (r5 == 5) goto L_0x005e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:21:0x0053, code lost:
            if (r5 == 3) goto L_0x005e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:0x0057, code lost:
            if (r5 == 2) goto L_0x005e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:0x005b, code lost:
            if (r5 == 7) goto L_0x005e;
         */
        /* JADX WARNING: Removed duplicated region for block: B:11:0x002c  */
        /* JADX WARNING: Removed duplicated region for block: B:28:0x003f A[EDGE_INSN: B:28:0x003f->B:15:0x003f ?: BREAK  , SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private int scanNCName(java.lang.String r9, int r10, int r11) {
            /*
                r8 = this;
                r0 = r8
                r1 = r9
                r2 = r10
                r3 = r11
                r6 = r1
                r7 = r3
                char r6 = r6.charAt(r7)
                r4 = r6
                r6 = r4
                r7 = 128(0x80, float:1.794E-43)
                if (r6 < r7) goto L_0x001a
                r6 = r4
                boolean r6 = org.apache.xerces.util.XMLChar.isNameStart(r6)
                if (r6 != 0) goto L_0x005e
                r6 = r3
                r0 = r6
            L_0x0019:
                return r0
            L_0x001a:
                r6 = r0
                byte[] r6 = r6.fASCIICharMap
                r7 = r4
                byte r6 = r6[r7]
                r5 = r6
                r6 = r5
                r7 = 6
                if (r6 == r7) goto L_0x005e
                r6 = r5
                r7 = 7
                if (r6 == r7) goto L_0x005e
                r6 = r3
                r0 = r6
                goto L_0x0019
            L_0x002c:
                r6 = r1
                r7 = r3
                char r6 = r6.charAt(r7)
                r4 = r6
                r6 = r4
                r7 = 128(0x80, float:1.794E-43)
                if (r6 < r7) goto L_0x0042
                r6 = r4
                boolean r6 = org.apache.xerces.util.XMLChar.isName(r6)
                if (r6 != 0) goto L_0x005e
            L_0x003f:
                r6 = r3
                r0 = r6
                goto L_0x0019
            L_0x0042:
                r6 = r0
                byte[] r6 = r6.fASCIICharMap
                r7 = r4
                byte r6 = r6[r7]
                r5 = r6
                r6 = r5
                r7 = 6
                if (r6 == r7) goto L_0x005e
                r6 = r5
                r7 = 5
                if (r6 == r7) goto L_0x005e
                r6 = r5
                r7 = 3
                if (r6 == r7) goto L_0x005e
                r6 = r5
                r7 = 2
                if (r6 == r7) goto L_0x005e
                r6 = r5
                r7 = 7
                if (r6 == r7) goto L_0x005e
                goto L_0x003f
            L_0x005e:
                int r3 = r3 + 1
                r6 = r3
                r7 = r2
                if (r6 < r7) goto L_0x002c
                goto L_0x003f
            */
            throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.xpointer.ElementSchemePointer.Scanner.scanNCName(java.lang.String, int, int):int");
        }

        /* access modifiers changed from: protected */
        public void addToken(Tokens tokens, int i) throws XNIException {
            Tokens.access$700(tokens, i);
        }
    }

    private final class Tokens {
        private static final int INITIAL_TOKEN_COUNT = 256;
        private static final int XPTRTOKEN_ELEM_CHILD = 1;
        private static final int XPTRTOKEN_ELEM_NCNAME = 0;
        private int fCurrentTokenIndex;
        private SymbolTable fSymbolTable;
        private int fTokenCount;
        private HashMap fTokenNames;
        private int[] fTokens;
        private final String[] fgTokenNames;
        private final ElementSchemePointer this$0;

        private Tokens(ElementSchemePointer elementSchemePointer, SymbolTable symbolTable) {
            HashMap hashMap;
            Object obj;
            Object obj2;
            this.this$0 = elementSchemePointer;
            String[] strArr = new String[2];
            strArr[0] = "XPTRTOKEN_ELEM_NCNAME";
            String[] strArr2 = strArr;
            strArr2[1] = "XPTRTOKEN_ELEM_CHILD";
            this.fgTokenNames = strArr2;
            this.fTokens = new int[256];
            this.fTokenCount = 0;
            new HashMap();
            this.fTokenNames = hashMap;
            this.fSymbolTable = symbolTable;
            new Integer(0);
            Object put = this.fTokenNames.put(obj, "XPTRTOKEN_ELEM_NCNAME");
            new Integer(1);
            Object put2 = this.fTokenNames.put(obj2, "XPTRTOKEN_ELEM_CHILD");
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        Tokens(ElementSchemePointer elementSchemePointer, SymbolTable symbolTable, AnonymousClass1 r10) {
            this(elementSchemePointer, symbolTable);
            AnonymousClass1 r3 = r10;
        }

        static String access$200(Tokens tokens, int i) {
            return tokens.getTokenString(i);
        }

        static int access$400(Tokens tokens) {
            return tokens.getTokenCount();
        }

        static boolean access$500(Tokens tokens) {
            return tokens.hasMore();
        }

        static int access$600(Tokens tokens) throws XNIException {
            return tokens.nextToken();
        }

        static void access$700(Tokens tokens, int i) {
            tokens.addToken(i);
        }

        static void access$800(Tokens tokens, String str) {
            tokens.addToken(str);
        }

        private void addToken(int i) {
            int i2 = i;
            try {
                this.fTokens[this.fTokenCount] = i2;
            } catch (ArrayIndexOutOfBoundsException e) {
                ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException = e;
                int[] iArr = this.fTokens;
                this.fTokens = new int[(this.fTokenCount << 1)];
                System.arraycopy(iArr, 0, this.fTokens, 0, this.fTokenCount);
                this.fTokens[this.fTokenCount] = i2;
            }
            this.fTokenCount++;
        }

        private void addToken(String str) {
            Integer num;
            String str2 = str;
            Integer num2 = (Integer) this.fTokenNames.get(str2);
            if (num2 == null) {
                new Integer(this.fTokenNames.size());
                num2 = num;
                Object put = this.fTokenNames.put(num2, str2);
            }
            addToken(num2.intValue());
        }

        private Integer getToken(int i) {
            Object obj;
            new Integer(i);
            return (Integer) this.fTokenNames.get(obj);
        }

        private int getTokenCount() {
            return this.fTokenCount;
        }

        private String getTokenString(int i) {
            Object obj;
            new Integer(i);
            return (String) this.fTokenNames.get(obj);
        }

        private boolean hasMore() {
            return this.fCurrentTokenIndex < this.fTokenCount;
        }

        private int nextToken() throws XNIException {
            if (this.fCurrentTokenIndex == this.fTokenCount) {
                this.this$0.reportError("XPointerElementSchemeProcessingError", (Object[]) null);
            }
            int[] iArr = this.fTokens;
            int i = this.fCurrentTokenIndex;
            int i2 = i + 1;
            this.fCurrentTokenIndex = i2;
            return iArr[i];
        }

        private String nextTokenAsString() throws XNIException {
            String tokenString = getTokenString(nextToken());
            if (tokenString == null) {
                this.this$0.reportError("XPointerElementSchemeProcessingError", (Object[]) null);
            }
            return tokenString;
        }

        private int peekToken() throws XNIException {
            if (this.fCurrentTokenIndex == this.fTokenCount) {
                this.this$0.reportError("XPointerElementSchemeProcessingError", (Object[]) null);
            }
            return this.fTokens[this.fCurrentTokenIndex];
        }

        private void rewind() {
            this.fCurrentTokenIndex = 0;
        }
    }

    public ElementSchemePointer() {
    }

    public ElementSchemePointer(SymbolTable symbolTable) {
        this.fSymbolTable = symbolTable;
    }

    public ElementSchemePointer(SymbolTable symbolTable, XMLErrorReporter xMLErrorReporter) {
        this.fSymbolTable = symbolTable;
        this.fErrorReporter = xMLErrorReporter;
    }

    /* access modifiers changed from: protected */
    public boolean checkMatch() {
        if (!this.fIsShortHand) {
            if (this.fChildSequence.length > this.fCurrentChildDepth + 1) {
                return false;
            }
            for (int i = 0; i < this.fChildSequence.length; i++) {
                if (this.fChildSequence[i] != this.fCurrentChildSequence[i]) {
                    return false;
                }
            }
        } else if (this.fChildSequence.length > this.fCurrentChildDepth + 1) {
            return false;
        } else {
            for (int i2 = 0; i2 < this.fChildSequence.length; i2++) {
                if (this.fCurrentChildSequence.length < i2 + 2) {
                    return false;
                }
                if (this.fChildSequence[i2] != this.fCurrentChildSequence[i2 + 1]) {
                    return false;
                }
            }
        }
        return true;
    }

    public String getSchemeData() {
        return this.fSchemeData;
    }

    public String getSchemeName() {
        return this.fSchemeName;
    }

    /* access modifiers changed from: protected */
    public void init() {
        this.fSchemeName = null;
        this.fSchemeData = null;
        this.fShortHandPointerName = null;
        this.fIsResolveElement = false;
        this.fIsElementFound = false;
        this.fWasOnlyEmptyElementFound = false;
        this.fFoundDepth = 0;
        this.fCurrentChildPosition = 1;
        this.fCurrentChildDepth = 0;
        this.fIsFragmentResolved = false;
        this.fShortHandPointer = null;
        initErrorReporter();
    }

    /* access modifiers changed from: protected */
    public void initErrorReporter() {
        MessageFormatter messageFormatter;
        XMLErrorHandler xMLErrorHandler;
        XMLErrorReporter xMLErrorReporter;
        if (this.fErrorReporter == null) {
            new XMLErrorReporter();
            this.fErrorReporter = xMLErrorReporter;
        }
        if (this.fErrorHandler == null) {
            new XPointerErrorHandler();
            this.fErrorHandler = xMLErrorHandler;
        }
        new XPointerMessageFormatter();
        this.fErrorReporter.putMessageFormatter(XPointerMessageFormatter.XPOINTER_DOMAIN, messageFormatter);
    }

    public boolean isChildFragmentResolved() {
        if (this.fIsShortHand && this.fShortHandPointer != null && this.fChildSequence.length <= 0) {
            return this.fShortHandPointer.isChildFragmentResolved();
        }
        return this.fWasOnlyEmptyElementFound ? !this.fWasOnlyEmptyElementFound : this.fIsFragmentResolved && this.fCurrentChildDepth >= this.fFoundDepth;
    }

    public boolean isFragmentResolved() throws XNIException {
        return this.fIsFragmentResolved;
    }

    /* access modifiers changed from: protected */
    public boolean matchChildSequence(QName qName, int i) throws XNIException {
        QName qName2 = qName;
        int i2 = i;
        if (this.fCurrentChildDepth >= this.fCurrentChildSequence.length) {
            int[] iArr = new int[this.fCurrentChildSequence.length];
            System.arraycopy(this.fCurrentChildSequence, 0, iArr, 0, this.fCurrentChildSequence.length);
            this.fCurrentChildSequence = new int[(this.fCurrentChildDepth * 2)];
            System.arraycopy(iArr, 0, this.fCurrentChildSequence, 0, iArr.length);
        }
        if (this.fIsResolveElement) {
            if (i2 == 0) {
                this.fCurrentChildSequence[this.fCurrentChildDepth] = this.fCurrentChildPosition;
                this.fCurrentChildDepth++;
                this.fCurrentChildPosition = 1;
                if (this.fCurrentChildDepth <= this.fFoundDepth || this.fFoundDepth == 0) {
                    if (checkMatch()) {
                        this.fIsElementFound = true;
                        this.fFoundDepth = this.fCurrentChildDepth;
                    } else {
                        this.fIsElementFound = false;
                        this.fFoundDepth = 0;
                    }
                }
            } else if (i2 == 1) {
                if (this.fCurrentChildDepth == this.fFoundDepth) {
                    this.fIsElementFound = true;
                } else if ((this.fCurrentChildDepth < this.fFoundDepth && this.fFoundDepth != 0) || (this.fCurrentChildDepth > this.fFoundDepth && this.fFoundDepth == 0)) {
                    this.fIsElementFound = false;
                }
                this.fCurrentChildSequence[this.fCurrentChildDepth] = 0;
                this.fCurrentChildDepth--;
                this.fCurrentChildPosition = this.fCurrentChildSequence[this.fCurrentChildDepth] + 1;
            } else if (i2 == 2) {
                this.fCurrentChildSequence[this.fCurrentChildDepth] = this.fCurrentChildPosition;
                this.fCurrentChildPosition++;
                if (checkMatch()) {
                    if (!this.fIsElementFound) {
                        this.fWasOnlyEmptyElementFound = true;
                    } else {
                        this.fWasOnlyEmptyElementFound = false;
                    }
                    this.fIsElementFound = true;
                } else {
                    this.fIsElementFound = false;
                    this.fWasOnlyEmptyElementFound = false;
                }
            }
        }
        return this.fIsElementFound;
    }

    public void parseXPointer(String str) throws XNIException {
        Tokens tokens;
        Scanner scanner;
        ShortHandPointer shortHandPointer;
        String str2 = str;
        init();
        new Tokens(this, this.fSymbolTable, (AnonymousClass1) null);
        Tokens tokens2 = tokens;
        new Scanner(this, this.fSymbolTable) {
            private final ElementSchemePointer this$0;

            {
                ElementSchemePointer elementSchemePointer = r8;
                this.this$0 = elementSchemePointer;
            }

            /* access modifiers changed from: protected */
            public void addToken(Tokens tokens, int i) throws XNIException {
                Tokens tokens2 = tokens;
                int i2 = i;
                if (i2 == 1 || i2 == 0) {
                    super.addToken(tokens2, i2);
                    return;
                }
                this.this$0.reportError("InvalidElementSchemeToken", new Object[]{Tokens.access$200(tokens2, i2)});
            }
        };
        if (!Scanner.access$300(scanner, this.fSymbolTable, tokens2, str2, 0, str2.length())) {
            reportError("InvalidElementSchemeXPointer", new Object[]{str2});
        }
        int[] iArr = new int[((Tokens.access$400(tokens2) / 2) + 1)];
        int i = 0;
        while (Tokens.access$500(tokens2)) {
            switch (Tokens.access$600(tokens2)) {
                case 0:
                    this.fShortHandPointerName = Tokens.access$200(tokens2, Tokens.access$600(tokens2));
                    new ShortHandPointer(this.fSymbolTable);
                    this.fShortHandPointer = shortHandPointer;
                    this.fShortHandPointer.setSchemeName(this.fShortHandPointerName);
                    break;
                case 1:
                    iArr[i] = Tokens.access$600(tokens2);
                    i++;
                    break;
                default:
                    reportError("InvalidElementSchemeXPointer", new Object[]{str2});
                    break;
            }
        }
        this.fChildSequence = new int[i];
        this.fCurrentChildSequence = new int[i];
        System.arraycopy(iArr, 0, this.fChildSequence, 0, i);
    }

    /* access modifiers changed from: protected */
    public void reportError(String str, Object[] objArr) throws XNIException {
        Throwable th;
        Throwable th2 = th;
        new XNIException(this.fErrorReporter.getMessageFormatter(XPointerMessageFormatter.XPOINTER_DOMAIN).formatMessage(this.fErrorReporter.getLocale(), str, objArr));
        throw th2;
    }

    public boolean resolveXPointer(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations, int i) throws XNIException {
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        int i2 = i;
        boolean z = false;
        if (this.fShortHandPointerName != null) {
            z = this.fShortHandPointer.resolveXPointer(qName2, xMLAttributes2, augmentations2, i2);
            if (z) {
                this.fIsResolveElement = true;
                this.fIsShortHand = true;
            } else {
                this.fIsResolveElement = false;
            }
        } else {
            this.fIsResolveElement = true;
        }
        if (this.fChildSequence.length > 0) {
            this.fIsFragmentResolved = matchChildSequence(qName2, i2);
        } else if (!z || this.fChildSequence.length > 0) {
            this.fIsFragmentResolved = false;
        } else {
            this.fIsFragmentResolved = z;
        }
        return this.fIsFragmentResolved;
    }

    public void setSchemeData(String str) {
        String str2 = str;
        this.fSchemeData = str2;
    }

    public void setSchemeName(String str) {
        String str2 = str;
        this.fSchemeName = str2;
    }
}
