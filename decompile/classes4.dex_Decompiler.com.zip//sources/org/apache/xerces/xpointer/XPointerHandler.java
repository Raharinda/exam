package org.apache.xerces.xpointer;

import java.util.ArrayList;
import java.util.HashMap;
import net.lingala.zip4j.util.Zip4jConstants;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.util.MessageFormatter;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.util.XMLSymbols;
import org.apache.xerces.xinclude.XIncludeHandler;
import org.apache.xerces.xinclude.XIncludeNamespaceSupport;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLErrorHandler;

public final class XPointerHandler extends XIncludeHandler implements XPointerProcessor {
    private final String ELEMENT_SCHEME_NAME = "element";
    protected XMLErrorHandler fErrorHandler;
    protected boolean fFixupBase = false;
    protected boolean fFixupLang = false;
    protected boolean fFoundMatchingPtrPart = false;
    protected boolean fIsXPointerResolved = false;
    protected SymbolTable fSymbolTable = null;
    protected XMLErrorReporter fXPointerErrorReporter;
    protected XPointerPart fXPointerPart = null;
    protected ArrayList fXPointerParts = null;

    private class Scanner {
        private static final byte CHARTYPE_CARRET = 3;
        private static final byte CHARTYPE_CLOSE_PAREN = 5;
        private static final byte CHARTYPE_COLON = 10;
        private static final byte CHARTYPE_DIGIT = 9;
        private static final byte CHARTYPE_EQUAL = 11;
        private static final byte CHARTYPE_INVALID = 0;
        private static final byte CHARTYPE_LETTER = 12;
        private static final byte CHARTYPE_MINUS = 6;
        private static final byte CHARTYPE_NONASCII = 14;
        private static final byte CHARTYPE_OPEN_PAREN = 4;
        private static final byte CHARTYPE_OTHER = 1;
        private static final byte CHARTYPE_PERIOD = 7;
        private static final byte CHARTYPE_SLASH = 8;
        private static final byte CHARTYPE_UNDERSCORE = 13;
        private static final byte CHARTYPE_WHITESPACE = 2;
        private final byte[] fASCIICharMap;
        private SymbolTable fSymbolTable;
        private final XPointerHandler this$0;

        private Scanner(XPointerHandler xPointerHandler, SymbolTable symbolTable) {
            this.this$0 = xPointerHandler;
            this.fASCIICharMap = new byte[]{CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_WHITESPACE, CHARTYPE_WHITESPACE, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_WHITESPACE, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_INVALID, CHARTYPE_WHITESPACE, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OPEN_PAREN, CHARTYPE_CLOSE_PAREN, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_MINUS, CHARTYPE_PERIOD, CHARTYPE_SLASH, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_DIGIT, CHARTYPE_COLON, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_EQUAL, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_CARRET, CHARTYPE_UNDERSCORE, CHARTYPE_OTHER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_LETTER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER, CHARTYPE_OTHER};
            this.fSymbolTable = symbolTable;
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        Scanner(XPointerHandler xPointerHandler, SymbolTable symbolTable, AnonymousClass1 r10) {
            this(xPointerHandler, symbolTable);
            AnonymousClass1 r3 = r10;
        }

        static boolean access$400(Scanner scanner, SymbolTable symbolTable, Tokens tokens, String str, int i, int i2) throws XNIException {
            return scanner.scanExpr(symbolTable, tokens, str, i, i2);
        }

        private int scanData(String str, StringBuffer stringBuffer, int i, int i2) {
            String str2 = str;
            StringBuffer stringBuffer2 = stringBuffer;
            int i3 = i;
            int i4 = i2;
            while (i4 != i3) {
                char charAt = str2.charAt(i4);
                byte b = charAt >= 128 ? CHARTYPE_NONASCII : this.fASCIICharMap[charAt];
                if (b == 4) {
                    StringBuffer append = stringBuffer2.append(charAt);
                    int scanData = scanData(str2, stringBuffer2, i3, i4 + 1);
                    if (scanData == i3) {
                        return scanData;
                    }
                    char charAt2 = str2.charAt(scanData);
                    if ((charAt2 >= 128 ? CHARTYPE_NONASCII : this.fASCIICharMap[charAt2]) != 5) {
                        return i3;
                    }
                    StringBuffer append2 = stringBuffer2.append((char) charAt2);
                    i4 = scanData + 1;
                } else if (b == 5) {
                    return i4;
                } else {
                    if (b == 3) {
                        i4++;
                        char charAt3 = str2.charAt(i4);
                        byte b2 = charAt3 >= 128 ? CHARTYPE_NONASCII : this.fASCIICharMap[charAt3];
                        if (b2 != 3 && b2 != 4 && b2 != 5) {
                            break;
                        }
                        StringBuffer append3 = stringBuffer2.append((char) charAt3);
                        i4++;
                    } else {
                        StringBuffer append4 = stringBuffer2.append((char) charAt);
                        i4++;
                    }
                }
            }
            return i4;
        }

        private boolean scanExpr(SymbolTable symbolTable, Tokens tokens, String str, int i, int i2) throws XNIException {
            StringBuffer stringBuffer;
            char c;
            SymbolTable symbolTable2 = symbolTable;
            Tokens tokens2 = tokens;
            String str2 = str;
            int i3 = i;
            int i4 = i2;
            int i5 = 0;
            int i6 = 0;
            String str3 = null;
            new StringBuffer();
            StringBuffer stringBuffer2 = stringBuffer;
            while (i3 != i4) {
                char charAt = str2.charAt(i3);
                while (true) {
                    c = charAt;
                    if (c == ' ' || c == 10 || c == 9 || c == 13) {
                        i3++;
                        if (i3 != i4) {
                            charAt = str2.charAt(i3);
                        }
                    }
                }
                if (i3 != i4) {
                    switch (c >= 128 ? CHARTYPE_NONASCII : this.fASCIICharMap[c]) {
                        case 1:
                        case 2:
                        case 3:
                        case 6:
                        case Zip4jConstants.DEFLATE_LEVEL_MAXIMUM:
                        case 8:
                        case Zip4jConstants.DEFLATE_LEVEL_ULTRA:
                        case 10:
                        case 11:
                        case 12:
                        case 13:
                        case 14:
                            if (i5 != 0) {
                                if (i5 > 0 && i6 == 0 && str3 != null) {
                                    int i7 = i3;
                                    i3 = scanData(str2, stringBuffer2, i4, i3);
                                    if (i3 != i7) {
                                        char charAt2 = i3 < i4 ? str2.charAt(i3) : 65535;
                                        String addSymbol = symbolTable2.addSymbol(stringBuffer2.toString());
                                        addToken(tokens2, 4);
                                        Tokens.access$800(tokens2, addSymbol);
                                        i5 = 0;
                                        StringBuffer delete = stringBuffer2.delete(0, stringBuffer2.length());
                                        break;
                                    } else {
                                        XPointerHandler.access$300(this.this$0, "InvalidSchemeDataInXPointer", new Object[]{str2});
                                        return false;
                                    }
                                } else {
                                    return false;
                                }
                            } else {
                                int i8 = i3;
                                i3 = scanNCName(str2, i4, i3);
                                if (i3 != i8) {
                                    char charAt3 = i3 < i4 ? str2.charAt(i3) : 65535;
                                    str3 = symbolTable2.addSymbol(str2.substring(i8, i3));
                                    String str4 = XMLSymbols.EMPTY_STRING;
                                    if (charAt3 == ':') {
                                        int i9 = i3 + 1;
                                        if (i9 == i4) {
                                            return false;
                                        }
                                        char charAt4 = str2.charAt(i9);
                                        str4 = str3;
                                        int i10 = i9;
                                        i3 = scanNCName(str2, i4, i9);
                                        if (i3 == i10) {
                                            return false;
                                        }
                                        if (i3 < i4) {
                                            char charAt5 = str2.charAt(i3);
                                        }
                                        str3 = symbolTable2.addSymbol(str2.substring(i10, i3));
                                    }
                                    if (i3 != i4) {
                                        addToken(tokens2, 3);
                                        Tokens.access$800(tokens2, str4);
                                        Tokens.access$800(tokens2, str3);
                                    } else if (i3 == i4) {
                                        addToken(tokens2, 2);
                                        Tokens.access$800(tokens2, str3);
                                    }
                                    i6 = 0;
                                    break;
                                } else {
                                    XPointerHandler.access$300(this.this$0, "InvalidShortHandPointer", new Object[]{str2});
                                    return false;
                                }
                            }
                            break;
                        case 4:
                            addToken(tokens2, 0);
                            i5++;
                            i3++;
                            break;
                        case 5:
                            addToken(tokens2, 1);
                            i6++;
                            i3++;
                            break;
                    }
                } else {
                    return true;
                }
            }
            return true;
        }

        /* JADX WARNING: CFG modification limit reached, blocks count: 132 */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x0044, code lost:
            r5 = r0.fASCIICharMap[r4];
         */
        /* JADX WARNING: Code restructure failed: missing block: B:17:0x004e, code lost:
            if (r5 == 12) goto L_0x0063;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:19:0x0053, code lost:
            if (r5 == 9) goto L_0x0063;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:21:0x0057, code lost:
            if (r5 == 7) goto L_0x0063;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:0x005b, code lost:
            if (r5 == 6) goto L_0x0063;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:0x0060, code lost:
            if (r5 == 13) goto L_0x0063;
         */
        /* JADX WARNING: Removed duplicated region for block: B:11:0x002e  */
        /* JADX WARNING: Removed duplicated region for block: B:28:0x0041 A[EDGE_INSN: B:28:0x0041->B:15:0x0041 ?: BREAK  , SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private int scanNCName(java.lang.String r9, int r10, int r11) {
            /*
                r8 = this;
                r0 = r8
                r1 = r9
                r2 = r10
                r3 = r11
                r6 = r1
                r7 = r3
                char r6 = r6.charAt(r7)
                r4 = r6
                r6 = r4
                r7 = 128(0x80, float:1.794E-43)
                if (r6 < r7) goto L_0x001a
                r6 = r4
                boolean r6 = org.apache.xerces.util.XMLChar.isNameStart(r6)
                if (r6 != 0) goto L_0x0063
                r6 = r3
                r0 = r6
            L_0x0019:
                return r0
            L_0x001a:
                r6 = r0
                byte[] r6 = r6.fASCIICharMap
                r7 = r4
                byte r6 = r6[r7]
                r5 = r6
                r6 = r5
                r7 = 12
                if (r6 == r7) goto L_0x0063
                r6 = r5
                r7 = 13
                if (r6 == r7) goto L_0x0063
                r6 = r3
                r0 = r6
                goto L_0x0019
            L_0x002e:
                r6 = r1
                r7 = r3
                char r6 = r6.charAt(r7)
                r4 = r6
                r6 = r4
                r7 = 128(0x80, float:1.794E-43)
                if (r6 < r7) goto L_0x0044
                r6 = r4
                boolean r6 = org.apache.xerces.util.XMLChar.isName(r6)
                if (r6 != 0) goto L_0x0063
            L_0x0041:
                r6 = r3
                r0 = r6
                goto L_0x0019
            L_0x0044:
                r6 = r0
                byte[] r6 = r6.fASCIICharMap
                r7 = r4
                byte r6 = r6[r7]
                r5 = r6
                r6 = r5
                r7 = 12
                if (r6 == r7) goto L_0x0063
                r6 = r5
                r7 = 9
                if (r6 == r7) goto L_0x0063
                r6 = r5
                r7 = 7
                if (r6 == r7) goto L_0x0063
                r6 = r5
                r7 = 6
                if (r6 == r7) goto L_0x0063
                r6 = r5
                r7 = 13
                if (r6 == r7) goto L_0x0063
                goto L_0x0041
            L_0x0063:
                int r3 = r3 + 1
                r6 = r3
                r7 = r2
                if (r6 < r7) goto L_0x002e
                goto L_0x0041
            */
            throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.xpointer.XPointerHandler.Scanner.scanNCName(java.lang.String, int, int):int");
        }

        /* access modifiers changed from: protected */
        public void addToken(Tokens tokens, int i) throws XNIException {
            Tokens.access$900(tokens, i);
        }
    }

    private final class Tokens {
        private static final int INITIAL_TOKEN_COUNT = 256;
        private static final int XPTRTOKEN_CLOSE_PAREN = 1;
        private static final int XPTRTOKEN_OPEN_PAREN = 0;
        private static final int XPTRTOKEN_SCHEMEDATA = 4;
        private static final int XPTRTOKEN_SCHEMENAME = 3;
        private static final int XPTRTOKEN_SHORTHAND = 2;
        private int fCurrentTokenIndex;
        private SymbolTable fSymbolTable;
        private int fTokenCount;
        private HashMap fTokenNames;
        private int[] fTokens;
        private final String[] fgTokenNames;
        private final XPointerHandler this$0;

        private Tokens(XPointerHandler xPointerHandler, SymbolTable symbolTable) {
            HashMap hashMap;
            Object obj;
            Object obj2;
            Object obj3;
            Object obj4;
            Object obj5;
            this.this$0 = xPointerHandler;
            String[] strArr = new String[5];
            strArr[0] = "XPTRTOKEN_OPEN_PAREN";
            String[] strArr2 = strArr;
            strArr2[1] = "XPTRTOKEN_CLOSE_PAREN";
            String[] strArr3 = strArr2;
            strArr3[2] = "XPTRTOKEN_SHORTHAND";
            String[] strArr4 = strArr3;
            strArr4[3] = "XPTRTOKEN_SCHEMENAME";
            String[] strArr5 = strArr4;
            strArr5[4] = "XPTRTOKEN_SCHEMEDATA";
            this.fgTokenNames = strArr5;
            this.fTokens = new int[256];
            this.fTokenCount = 0;
            new HashMap();
            this.fTokenNames = hashMap;
            this.fSymbolTable = symbolTable;
            new Integer(0);
            Object put = this.fTokenNames.put(obj, "XPTRTOKEN_OPEN_PAREN");
            new Integer(1);
            Object put2 = this.fTokenNames.put(obj2, "XPTRTOKEN_CLOSE_PAREN");
            new Integer(2);
            Object put3 = this.fTokenNames.put(obj3, "XPTRTOKEN_SHORTHAND");
            new Integer(3);
            Object put4 = this.fTokenNames.put(obj4, "XPTRTOKEN_SCHEMENAME");
            new Integer(4);
            Object put5 = this.fTokenNames.put(obj5, "XPTRTOKEN_SCHEMEDATA");
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        Tokens(XPointerHandler xPointerHandler, SymbolTable symbolTable, AnonymousClass1 r10) {
            this(xPointerHandler, symbolTable);
            AnonymousClass1 r3 = r10;
        }

        static String access$200(Tokens tokens, int i) {
            return tokens.getTokenString(i);
        }

        static boolean access$500(Tokens tokens) {
            return tokens.hasMore();
        }

        static int access$600(Tokens tokens) throws XNIException {
            return tokens.nextToken();
        }

        static int access$700(Tokens tokens) throws XNIException {
            return tokens.peekToken();
        }

        static void access$800(Tokens tokens, String str) {
            tokens.addToken(str);
        }

        static void access$900(Tokens tokens, int i) {
            tokens.addToken(i);
        }

        private void addToken(int i) {
            int i2 = i;
            try {
                this.fTokens[this.fTokenCount] = i2;
            } catch (ArrayIndexOutOfBoundsException e) {
                ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException = e;
                int[] iArr = this.fTokens;
                this.fTokens = new int[(this.fTokenCount << 1)];
                System.arraycopy(iArr, 0, this.fTokens, 0, this.fTokenCount);
                this.fTokens[this.fTokenCount] = i2;
            }
            this.fTokenCount++;
        }

        private void addToken(String str) {
            Integer num;
            String str2 = str;
            Integer num2 = (Integer) this.fTokenNames.get(str2);
            if (num2 == null) {
                new Integer(this.fTokenNames.size());
                num2 = num;
                Object put = this.fTokenNames.put(num2, str2);
            }
            addToken(num2.intValue());
        }

        private String getTokenString(int i) {
            Object obj;
            new Integer(i);
            return (String) this.fTokenNames.get(obj);
        }

        private boolean hasMore() {
            return this.fCurrentTokenIndex < this.fTokenCount;
        }

        private int nextToken() throws XNIException {
            if (this.fCurrentTokenIndex == this.fTokenCount) {
                XPointerHandler.access$300(this.this$0, "XPointerProcessingError", (Object[]) null);
            }
            int[] iArr = this.fTokens;
            int i = this.fCurrentTokenIndex;
            int i2 = i + 1;
            this.fCurrentTokenIndex = i2;
            return iArr[i];
        }

        private String nextTokenAsString() throws XNIException {
            String tokenString = getTokenString(nextToken());
            if (tokenString == null) {
                XPointerHandler.access$300(this.this$0, "XPointerProcessingError", (Object[]) null);
            }
            return tokenString;
        }

        private int peekToken() throws XNIException {
            if (this.fCurrentTokenIndex == this.fTokenCount) {
                XPointerHandler.access$300(this.this$0, "XPointerProcessingError", (Object[]) null);
            }
            return this.fTokens[this.fCurrentTokenIndex];
        }

        private void rewind() {
            this.fCurrentTokenIndex = 0;
        }
    }

    public XPointerHandler() {
        ArrayList arrayList;
        SymbolTable symbolTable;
        new ArrayList();
        this.fXPointerParts = arrayList;
        new SymbolTable();
        this.fSymbolTable = symbolTable;
    }

    public XPointerHandler(SymbolTable symbolTable, XMLErrorHandler xMLErrorHandler, XMLErrorReporter xMLErrorReporter) {
        ArrayList arrayList;
        new ArrayList();
        this.fXPointerParts = arrayList;
        this.fSymbolTable = symbolTable;
        this.fErrorHandler = xMLErrorHandler;
        this.fXPointerErrorReporter = xMLErrorReporter;
    }

    static void access$300(XPointerHandler xPointerHandler, String str, Object[] objArr) throws XNIException {
        xPointerHandler.reportError(str, objArr);
    }

    private void reportError(String str, Object[] objArr) throws XNIException {
        Throwable th;
        Throwable th2 = th;
        new XNIException(this.fErrorReporter.getMessageFormatter(XPointerMessageFormatter.XPOINTER_DOMAIN).formatMessage(this.fErrorReporter.getLocale(), str, objArr));
        throw th2;
    }

    private void reportWarning(String str, Object[] objArr) throws XNIException {
        String reportError = this.fXPointerErrorReporter.reportError(XPointerMessageFormatter.XPOINTER_DOMAIN, str, objArr, 0);
    }

    public void characters(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (isChildFragmentResolved()) {
            super.characters(xMLString2, augmentations2);
        }
    }

    public void comment(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (isChildFragmentResolved()) {
            super.comment(xMLString2, augmentations2);
        }
    }

    public void emptyElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        if (!resolveXPointer(qName2, xMLAttributes2, augmentations2, 2)) {
            if (this.fFixupBase) {
                processXMLBaseAttributes(xMLAttributes2);
            }
            if (this.fFixupLang) {
                processXMLLangAttributes(xMLAttributes2);
            }
            this.fNamespaceContext.setContextInvalid();
            return;
        }
        super.emptyElement(qName2, xMLAttributes2, augmentations2);
    }

    public void endCDATA(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        if (isChildFragmentResolved()) {
            super.endCDATA(augmentations2);
        }
    }

    public void endElement(QName qName, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        if (resolveXPointer(qName2, (XMLAttributes) null, augmentations2, 1)) {
            super.endElement(qName2, augmentations2);
        }
    }

    public ArrayList getPointerParts() {
        return this.fXPointerParts;
    }

    public XPointerPart getXPointerPart() {
        return this.fXPointerPart;
    }

    public void ignorableWhitespace(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (isChildFragmentResolved()) {
            super.ignorableWhitespace(xMLString2, augmentations2);
        }
    }

    /* access modifiers changed from: protected */
    public void init() {
        this.fXPointerParts.clear();
        this.fXPointerPart = null;
        this.fFoundMatchingPtrPart = false;
        this.fIsXPointerResolved = false;
        initErrorReporter();
    }

    /* access modifiers changed from: protected */
    public void initErrorReporter() {
        MessageFormatter messageFormatter;
        XMLErrorHandler xMLErrorHandler;
        XMLErrorReporter xMLErrorReporter;
        if (this.fXPointerErrorReporter == null) {
            new XMLErrorReporter();
            this.fXPointerErrorReporter = xMLErrorReporter;
        }
        if (this.fErrorHandler == null) {
            new XPointerErrorHandler();
            this.fErrorHandler = xMLErrorHandler;
        }
        new XPointerMessageFormatter();
        this.fXPointerErrorReporter.putMessageFormatter(XPointerMessageFormatter.XPOINTER_DOMAIN, messageFormatter);
    }

    public boolean isChildFragmentResolved() throws XNIException {
        return this.fXPointerPart != null ? this.fXPointerPart.isChildFragmentResolved() : false;
    }

    public boolean isFragmentResolved() throws XNIException {
        boolean isFragmentResolved = this.fXPointerPart != null ? this.fXPointerPart.isFragmentResolved() : false;
        if (!this.fIsXPointerResolved) {
            this.fIsXPointerResolved = isFragmentResolved;
        }
        return isFragmentResolved;
    }

    public boolean isXPointerResolved() throws XNIException {
        return this.fIsXPointerResolved;
    }

    /* JADX WARNING: Removed duplicated region for block: B:23:0x01d3  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x0203  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0258  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x02f2 A[LOOP:2: B:24:0x01f1->B:40:0x02f2, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0307  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void parseXPointer(java.lang.String r29) throws org.apache.xerces.xni.XNIException {
        /*
            r28 = this;
            r2 = r28
            r3 = r29
            r19 = r2
            r19.init()
            org.apache.xerces.xpointer.XPointerHandler$Tokens r19 = new org.apache.xerces.xpointer.XPointerHandler$Tokens
            r27 = r19
            r19 = r27
            r20 = r27
            r21 = r2
            r22 = r2
            r0 = r22
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r22 = r0
            r23 = 0
            r20.<init>(r21, r22, r23)
            r4 = r19
            org.apache.xerces.xpointer.XPointerHandler$1 r19 = new org.apache.xerces.xpointer.XPointerHandler$1
            r27 = r19
            r19 = r27
            r20 = r27
            r21 = r2
            r22 = r2
            r0 = r22
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r22 = r0
            r20.<init>(r21, r22)
            r5 = r19
            r19 = r3
            int r19 = r19.length()
            r6 = r19
            r19 = r5
            r20 = r2
            r0 = r20
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r20 = r0
            r21 = r4
            r22 = r3
            r23 = 0
            r24 = r6
            boolean r19 = org.apache.xerces.xpointer.XPointerHandler.Scanner.access$400(r19, r20, r21, r22, r23, r24)
            r7 = r19
            r19 = r7
            if (r19 != 0) goto L_0x0079
            r19 = r2
            java.lang.String r20 = "InvalidXPointerExpression"
            r21 = 1
            r0 = r21
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r21 = r0
            r27 = r21
            r21 = r27
            r22 = r27
            r23 = 0
            r24 = r3
            r22[r23] = r24
            r19.reportError(r20, r21)
        L_0x0079:
            r19 = r4
            boolean r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$500(r19)
            if (r19 != 0) goto L_0x0082
            return
        L_0x0082:
            r19 = r4
            int r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$600(r19)
            r8 = r19
            r19 = r8
            switch(r19) {
                case 2: goto L_0x00ac;
                case 3: goto L_0x010a;
                default: goto L_0x008f;
            }
        L_0x008f:
            r19 = r2
            java.lang.String r20 = "InvalidXPointerExpression"
            r21 = 1
            r0 = r21
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r21 = r0
            r27 = r21
            r21 = r27
            r22 = r27
            r23 = 0
            r24 = r3
            r22[r23] = r24
            r19.reportError(r20, r21)
            goto L_0x0079
        L_0x00ac:
            r19 = r4
            int r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$600(r19)
            r8 = r19
            r19 = r4
            r20 = r8
            java.lang.String r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$200(r19, r20)
            r9 = r19
            r19 = r9
            if (r19 != 0) goto L_0x00de
            r19 = r2
            java.lang.String r20 = "InvalidXPointerExpression"
            r21 = 1
            r0 = r21
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r21 = r0
            r27 = r21
            r21 = r27
            r22 = r27
            r23 = 0
            r24 = r3
            r22[r23] = r24
            r19.reportError(r20, r21)
        L_0x00de:
            org.apache.xerces.xpointer.ShortHandPointer r19 = new org.apache.xerces.xpointer.ShortHandPointer
            r27 = r19
            r19 = r27
            r20 = r27
            r21 = r2
            r0 = r21
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r21 = r0
            r20.<init>(r21)
            r10 = r19
            r19 = r10
            r20 = r9
            r19.setSchemeName(r20)
            r19 = r2
            r0 = r19
            java.util.ArrayList r0 = r0.fXPointerParts
            r19 = r0
            r20 = r10
            boolean r19 = r19.add(r20)
            goto L_0x0079
        L_0x010a:
            r19 = r4
            int r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$600(r19)
            r8 = r19
            r19 = r4
            r20 = r8
            java.lang.String r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$200(r19, r20)
            r9 = r19
            r19 = r4
            int r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$600(r19)
            r8 = r19
            r19 = r4
            r20 = r8
            java.lang.String r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$200(r19, r20)
            r10 = r19
            java.lang.StringBuffer r19 = new java.lang.StringBuffer
            r27 = r19
            r19 = r27
            r20 = r27
            r20.<init>()
            r20 = r9
            java.lang.StringBuffer r19 = r19.append(r20)
            r20 = r10
            java.lang.StringBuffer r19 = r19.append(r20)
            java.lang.String r19 = r19.toString()
            r11 = r19
            r19 = 0
            r12 = r19
            r19 = 0
            r13 = r19
            r19 = r4
            int r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$600(r19)
            r8 = r19
            r19 = r4
            r20 = r8
            java.lang.String r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$200(r19, r20)
            r14 = r19
            r19 = r14
            java.lang.String r20 = "XPTRTOKEN_OPEN_PAREN"
            r0 = r19
            r1 = r20
            if (r0 == r1) goto L_0x0196
            r19 = r8
            r20 = 2
            r0 = r19
            r1 = r20
            if (r0 != r1) goto L_0x029a
            r19 = r2
            java.lang.String r20 = "MultipleShortHandPointers"
            r21 = 1
            r0 = r21
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r21 = r0
            r27 = r21
            r21 = r27
            r22 = r27
            r23 = 0
            r24 = r3
            r22[r23] = r24
            r19.reportError(r20, r21)
        L_0x0196:
            int r12 = r12 + 1
            r19 = 0
            r15 = r19
        L_0x019c:
            r19 = r4
            boolean r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$500(r19)
            if (r19 != 0) goto L_0x02b8
        L_0x01a4:
            r19 = r4
            int r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$600(r19)
            r8 = r19
            r19 = r4
            r20 = r8
            java.lang.String r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$200(r19, r20)
            r15 = r19
            r19 = r4
            int r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$600(r19)
            r8 = r19
            r19 = r4
            r20 = r8
            java.lang.String r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$200(r19, r20)
            r16 = r19
            r19 = r16
            java.lang.String r20 = "XPTRTOKEN_CLOSE_PAREN"
            r0 = r19
            r1 = r20
            if (r0 == r1) goto L_0x01ef
            r19 = r2
            java.lang.String r20 = "SchemeDataNotFollowedByCloseParenthesis"
            r21 = 1
            r0 = r21
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r21 = r0
            r27 = r21
            r21 = r27
            r22 = r27
            r23 = 0
            r24 = r3
            r22[r23] = r24
            r19.reportError(r20, r21)
        L_0x01ef:
            int r13 = r13 + 1
        L_0x01f1:
            r19 = r4
            boolean r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$500(r19)
            if (r19 != 0) goto L_0x02db
        L_0x01f9:
            r19 = r12
            r20 = r13
            r0 = r19
            r1 = r20
            if (r0 == r1) goto L_0x024d
            r19 = r2
            java.lang.String r20 = "UnbalancedParenthesisInXPointerExpression"
            r21 = 3
            r0 = r21
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r21 = r0
            r27 = r21
            r21 = r27
            r22 = r27
            r23 = 0
            r24 = r3
            r22[r23] = r24
            r27 = r21
            r21 = r27
            r22 = r27
            r23 = 1
            java.lang.Integer r24 = new java.lang.Integer
            r27 = r24
            r24 = r27
            r25 = r27
            r26 = r12
            r25.<init>(r26)
            r22[r23] = r24
            r27 = r21
            r21 = r27
            r22 = r27
            r23 = 2
            java.lang.Integer r24 = new java.lang.Integer
            r27 = r24
            r24 = r27
            r25 = r27
            r26 = r13
            r25.<init>(r26)
            r22[r23] = r24
            r19.reportError(r20, r21)
        L_0x024d:
            r19 = r11
            java.lang.String r20 = "element"
            boolean r19 = r19.equals(r20)
            if (r19 == 0) goto L_0x0307
            org.apache.xerces.xpointer.ElementSchemePointer r19 = new org.apache.xerces.xpointer.ElementSchemePointer
            r27 = r19
            r19 = r27
            r20 = r27
            r21 = r2
            r0 = r21
            org.apache.xerces.util.SymbolTable r0 = r0.fSymbolTable
            r21 = r0
            r22 = r2
            r0 = r22
            org.apache.xerces.impl.XMLErrorReporter r0 = r0.fErrorReporter
            r22 = r0
            r20.<init>(r21, r22)
            r17 = r19
            r19 = r17
            r20 = r11
            r19.setSchemeName(r20)
            r19 = r17
            r20 = r15
            r19.setSchemeData(r20)
            r19 = r17
            r20 = r15
            r19.parseXPointer(r20)     // Catch:{ XNIException -> 0x02f6 }
            r19 = r2
            r0 = r19
            java.util.ArrayList r0 = r0.fXPointerParts     // Catch:{ XNIException -> 0x02f6 }
            r19 = r0
            r20 = r17
            boolean r19 = r19.add(r20)     // Catch:{ XNIException -> 0x02f6 }
            goto L_0x0079
        L_0x029a:
            r19 = r2
            java.lang.String r20 = "InvalidXPointerExpression"
            r21 = 1
            r0 = r21
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r21 = r0
            r27 = r21
            r21 = r27
            r22 = r27
            r23 = 0
            r24 = r3
            r22[r23] = r24
            r19.reportError(r20, r21)
            goto L_0x0196
        L_0x02b8:
            r19 = r4
            int r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$600(r19)
            r8 = r19
            r19 = r4
            r20 = r8
            java.lang.String r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$200(r19, r20)
            r15 = r19
            r19 = r15
            java.lang.String r20 = "XPTRTOKEN_OPEN_PAREN"
            r0 = r19
            r1 = r20
            if (r0 == r1) goto L_0x02d7
            goto L_0x01a4
        L_0x02d7:
            int r12 = r12 + 1
            goto L_0x019c
        L_0x02db:
            r19 = r4
            r20 = r4
            int r20 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$700(r20)
            java.lang.String r19 = org.apache.xerces.xpointer.XPointerHandler.Tokens.access$200(r19, r20)
            java.lang.String r20 = "XPTRTOKEN_OPEN_PAREN"
            r0 = r19
            r1 = r20
            if (r0 == r1) goto L_0x02f2
            goto L_0x01f9
        L_0x02f2:
            int r13 = r13 + 1
            goto L_0x01f1
        L_0x02f6:
            r19 = move-exception
            r18 = r19
            org.apache.xerces.xni.XNIException r19 = new org.apache.xerces.xni.XNIException
            r27 = r19
            r19 = r27
            r20 = r27
            r21 = r18
            r20.<init>((java.lang.Exception) r21)
            throw r19
        L_0x0307:
            r19 = r2
            java.lang.String r20 = "SchemeUnsupported"
            r21 = 1
            r0 = r21
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r21 = r0
            r27 = r21
            r21 = r27
            r22 = r27
            r23 = 0
            r24 = r11
            r22[r23] = r24
            r19.reportWarning(r20, r21)
            goto L_0x0079
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.xpointer.XPointerHandler.parseXPointer(java.lang.String):void");
    }

    public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
        String str2 = str;
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (isChildFragmentResolved()) {
            super.processingInstruction(str2, xMLString2, augmentations2);
        }
    }

    public boolean resolveXPointer(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations, int i) throws XNIException {
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        int i2 = i;
        boolean z = false;
        if (!this.fFoundMatchingPtrPart) {
            for (int i3 = 0; i3 < this.fXPointerParts.size(); i3++) {
                this.fXPointerPart = (XPointerPart) this.fXPointerParts.get(i3);
                if (this.fXPointerPart.resolveXPointer(qName2, xMLAttributes2, augmentations2, i2)) {
                    this.fFoundMatchingPtrPart = true;
                    z = true;
                }
            }
        } else if (this.fXPointerPart.resolveXPointer(qName2, xMLAttributes2, augmentations2, i2)) {
            z = true;
        }
        if (!this.fIsXPointerResolved) {
            this.fIsXPointerResolved = z;
        }
        return z;
    }

    public void setDocumentHandler(XMLDocumentHandler xMLDocumentHandler) {
        XMLDocumentHandler xMLDocumentHandler2 = xMLDocumentHandler;
        this.fDocumentHandler = xMLDocumentHandler2;
    }

    public void setProperty(String str, Object obj) throws XMLConfigurationException {
        String str2 = str;
        Object obj2 = obj;
        if (str2 == "http://apache.org/xml/properties/internal/error-reporter") {
            if (obj2 != null) {
                this.fXPointerErrorReporter = (XMLErrorReporter) obj2;
            } else {
                this.fXPointerErrorReporter = null;
            }
        }
        if (str2 == "http://apache.org/xml/properties/internal/error-handler") {
            if (obj2 != null) {
                this.fErrorHandler = (XMLErrorHandler) obj2;
            } else {
                this.fErrorHandler = null;
            }
        }
        if (str2 == "http://apache.org/xml/features/xinclude/fixup-language") {
            if (obj2 != null) {
                this.fFixupLang = ((Boolean) obj2).booleanValue();
            } else {
                this.fFixupLang = false;
            }
        }
        if (str2 == "http://apache.org/xml/features/xinclude/fixup-base-uris") {
            if (obj2 != null) {
                this.fFixupBase = ((Boolean) obj2).booleanValue();
            } else {
                this.fFixupBase = false;
            }
        }
        if (str2 == "http://apache.org/xml/properties/internal/namespace-context") {
            this.fNamespaceContext = (XIncludeNamespaceSupport) obj2;
        }
        super.setProperty(str2, obj2);
    }

    public void startCDATA(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        if (isChildFragmentResolved()) {
            super.startCDATA(augmentations2);
        }
    }

    public void startElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        if (!resolveXPointer(qName2, xMLAttributes2, augmentations2, 0)) {
            if (this.fFixupBase) {
                processXMLBaseAttributes(xMLAttributes2);
            }
            if (this.fFixupLang) {
                processXMLLangAttributes(xMLAttributes2);
            }
            this.fNamespaceContext.setContextInvalid();
            return;
        }
        super.startElement(qName2, xMLAttributes2, augmentations2);
    }
}
