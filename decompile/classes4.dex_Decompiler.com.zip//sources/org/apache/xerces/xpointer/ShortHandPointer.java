package org.apache.xerces.xpointer;

import org.apache.xerces.impl.dv.XSSimpleType;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xs.AttributePSVI;
import org.apache.xerces.xs.XSTypeDefinition;

final class ShortHandPointer implements XPointerPart {
    private boolean fIsFragmentResolved = false;
    int fMatchingChildCount = 0;
    private String fShortHandPointer;
    private SymbolTable fSymbolTable;

    public ShortHandPointer() {
    }

    public ShortHandPointer(SymbolTable symbolTable) {
        this.fSymbolTable = symbolTable;
    }

    private boolean hasMatchingIdentifier(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations, int i) throws XNIException {
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        int i2 = i;
        String str = null;
        if (xMLAttributes2 != null) {
            for (int i3 = 0; i3 < xMLAttributes2.getLength(); i3++) {
                str = getSchemaDeterminedID(xMLAttributes2, i3);
                if (str != null) {
                    break;
                }
                str = getChildrenSchemaDeterminedID(xMLAttributes2, i3);
                if (str != null) {
                    break;
                }
                str = getDTDDeterminedID(xMLAttributes2, i3);
                if (str != null) {
                    break;
                }
            }
        }
        return str != null && str.equals(this.fShortHandPointer);
    }

    public String getChildrenSchemaDeterminedID(XMLAttributes xMLAttributes, int i) throws XNIException {
        XMLAttributes xMLAttributes2 = xMLAttributes;
        int i2 = i;
        return null;
    }

    public String getDTDDeterminedID(XMLAttributes xMLAttributes, int i) throws XNIException {
        XMLAttributes xMLAttributes2 = xMLAttributes;
        int i2 = i;
        if (xMLAttributes2.getType(i2).equals("ID")) {
            return xMLAttributes2.getValue(i2);
        }
        return null;
    }

    public String getSchemaDeterminedID(XMLAttributes xMLAttributes, int i) throws XNIException {
        AttributePSVI attributePSVI = (AttributePSVI) xMLAttributes.getAugmentations(i).getItem("ATTRIBUTE_PSVI");
        if (attributePSVI != null) {
            XSTypeDefinition memberTypeDefinition = attributePSVI.getMemberTypeDefinition();
            if (memberTypeDefinition != null) {
                memberTypeDefinition = attributePSVI.getTypeDefinition();
            }
            if (memberTypeDefinition != null && ((XSSimpleType) memberTypeDefinition).isIDType()) {
                return attributePSVI.getSchemaNormalizedValue();
            }
        }
        return null;
    }

    public String getSchemeData() {
        return null;
    }

    public String getSchemeName() {
        return this.fShortHandPointer;
    }

    public boolean isChildFragmentResolved() {
        return this.fIsFragmentResolved && this.fMatchingChildCount > 0;
    }

    public boolean isFragmentResolved() {
        return this.fIsFragmentResolved;
    }

    public void parseXPointer(String str) throws XNIException {
        this.fShortHandPointer = str;
        this.fIsFragmentResolved = false;
    }

    public boolean resolveXPointer(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations, int i) throws XNIException {
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        int i2 = i;
        if (this.fMatchingChildCount == 0) {
            this.fIsFragmentResolved = false;
        }
        if (i2 == 0) {
            if (this.fMatchingChildCount == 0) {
                this.fIsFragmentResolved = hasMatchingIdentifier(qName2, xMLAttributes2, augmentations2, i2);
            }
            if (this.fIsFragmentResolved) {
                this.fMatchingChildCount++;
            }
        } else if (i2 == 2) {
            if (this.fMatchingChildCount == 0) {
                this.fIsFragmentResolved = hasMatchingIdentifier(qName2, xMLAttributes2, augmentations2, i2);
            }
        } else if (this.fIsFragmentResolved) {
            this.fMatchingChildCount--;
        }
        return this.fIsFragmentResolved;
    }

    public void setSchemeData(String str) {
    }

    public void setSchemeName(String str) {
        String str2 = str;
        this.fShortHandPointer = str2;
    }
}
