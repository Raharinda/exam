package org.apache.xerces.parsers;

import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLDTDContentModelHandler;
import org.apache.xerces.xni.XMLDTDHandler;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLDTDContentModelSource;
import org.apache.xerces.xni.parser.XMLDTDSource;
import org.apache.xerces.xni.parser.XMLDocumentSource;

public abstract class AbstractXMLDocumentParser extends XMLParser implements XMLDocumentHandler, XMLDTDHandler, XMLDTDContentModelHandler {
    protected XMLDTDContentModelSource fDTDContentModelSource;
    protected XMLDTDSource fDTDSource;
    protected XMLDocumentSource fDocumentSource;
    protected boolean fInDTD;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected AbstractXMLDocumentParser(org.apache.xerces.xni.parser.XMLParserConfiguration r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r0
            r3 = r1
            r2.<init>(r3)
            r2 = r1
            r3 = r0
            r2.setDocumentHandler(r3)
            r2 = r1
            r3 = r0
            r2.setDTDHandler(r3)
            r2 = r1
            r3 = r0
            r2.setDTDContentModelHandler(r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.AbstractXMLDocumentParser.<init>(org.apache.xerces.xni.parser.XMLParserConfiguration):void");
    }

    public void any(Augmentations augmentations) throws XNIException {
    }

    public void attributeDecl(String str, String str2, String str3, String[] strArr, String str4, XMLString xMLString, XMLString xMLString2, Augmentations augmentations) throws XNIException {
    }

    public void characters(XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void comment(XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void doctypeDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
    }

    public void element(String str, Augmentations augmentations) throws XNIException {
    }

    public void elementDecl(String str, String str2, Augmentations augmentations) throws XNIException {
    }

    public void empty(Augmentations augmentations) throws XNIException {
    }

    public void emptyElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        startElement(qName2, xMLAttributes, augmentations2);
        endElement(qName2, augmentations2);
    }

    public void endAttlist(Augmentations augmentations) throws XNIException {
    }

    public void endCDATA(Augmentations augmentations) throws XNIException {
    }

    public void endConditional(Augmentations augmentations) throws XNIException {
    }

    public void endContentModel(Augmentations augmentations) throws XNIException {
    }

    public void endDTD(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        this.fInDTD = false;
    }

    public void endDocument(Augmentations augmentations) throws XNIException {
    }

    public void endElement(QName qName, Augmentations augmentations) throws XNIException {
    }

    public void endExternalSubset(Augmentations augmentations) throws XNIException {
    }

    public void endGeneralEntity(String str, Augmentations augmentations) throws XNIException {
    }

    public void endGroup(Augmentations augmentations) throws XNIException {
    }

    public void endParameterEntity(String str, Augmentations augmentations) throws XNIException {
    }

    public void externalEntityDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
    }

    public XMLDTDContentModelSource getDTDContentModelSource() {
        return this.fDTDContentModelSource;
    }

    public XMLDTDSource getDTDSource() {
        return this.fDTDSource;
    }

    public XMLDocumentSource getDocumentSource() {
        return this.fDocumentSource;
    }

    public void ignorableWhitespace(XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void ignoredCharacters(XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void internalEntityDecl(String str, XMLString xMLString, XMLString xMLString2, Augmentations augmentations) throws XNIException {
    }

    public void notationDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
    }

    public void occurrence(short s, Augmentations augmentations) throws XNIException {
    }

    public void pcdata(Augmentations augmentations) throws XNIException {
    }

    public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    /* access modifiers changed from: protected */
    public void reset() throws XNIException {
        super.reset();
        this.fInDTD = false;
    }

    public void separator(short s, Augmentations augmentations) throws XNIException {
    }

    public void setDTDContentModelSource(XMLDTDContentModelSource xMLDTDContentModelSource) {
        XMLDTDContentModelSource xMLDTDContentModelSource2 = xMLDTDContentModelSource;
        this.fDTDContentModelSource = xMLDTDContentModelSource2;
    }

    public void setDTDSource(XMLDTDSource xMLDTDSource) {
        XMLDTDSource xMLDTDSource2 = xMLDTDSource;
        this.fDTDSource = xMLDTDSource2;
    }

    public void setDocumentSource(XMLDocumentSource xMLDocumentSource) {
        XMLDocumentSource xMLDocumentSource2 = xMLDocumentSource;
        this.fDocumentSource = xMLDocumentSource2;
    }

    public void startAttlist(String str, Augmentations augmentations) throws XNIException {
    }

    public void startCDATA(Augmentations augmentations) throws XNIException {
    }

    public void startConditional(short s, Augmentations augmentations) throws XNIException {
    }

    public void startContentModel(String str, Augmentations augmentations) throws XNIException {
    }

    public void startDTD(XMLLocator xMLLocator, Augmentations augmentations) throws XNIException {
        XMLLocator xMLLocator2 = xMLLocator;
        Augmentations augmentations2 = augmentations;
        this.fInDTD = true;
    }

    public void startDocument(XMLLocator xMLLocator, String str, NamespaceContext namespaceContext, Augmentations augmentations) throws XNIException {
    }

    public void startElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
    }

    public void startExternalSubset(XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
    }

    public void startGeneralEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
    }

    public void startGroup(Augmentations augmentations) throws XNIException {
    }

    public void startParameterEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
    }

    public void textDecl(String str, String str2, Augmentations augmentations) throws XNIException {
    }

    public void unparsedEntityDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
    }

    public void xmlDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
    }
}
