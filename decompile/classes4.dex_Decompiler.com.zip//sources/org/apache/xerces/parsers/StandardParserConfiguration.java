package org.apache.xerces.parsers;

import org.apache.xerces.impl.xs.XMLSchemaValidator;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;

public class StandardParserConfiguration extends DTDConfiguration {
    protected static final String GENERATE_SYNTHETIC_ANNOTATIONS = "http://apache.org/xml/features/generate-synthetic-annotations";
    protected static final String HONOUR_ALL_SCHEMALOCATIONS = "http://apache.org/xml/features/honour-all-schemaLocations";
    protected static final String IDENTITY_CONSTRAINT_CHECKING = "http://apache.org/xml/features/validation/identity-constraint-checking";
    protected static final String ID_IDREF_CHECKING = "http://apache.org/xml/features/validation/id-idref-checking";
    protected static final String IGNORE_XSI_TYPE = "http://apache.org/xml/features/validation/schema/ignore-xsi-type-until-elemdecl";
    protected static final String NAMESPACE_GROWTH = "http://apache.org/xml/features/namespace-growth";
    protected static final String NORMALIZE_DATA = "http://apache.org/xml/features/validation/schema/normalized-value";
    protected static final String ROOT_ELEMENT_DECL = "http://apache.org/xml/properties/validation/schema/root-element-declaration";
    protected static final String ROOT_TYPE_DEF = "http://apache.org/xml/properties/validation/schema/root-type-definition";
    protected static final String SCHEMA_AUGMENT_PSVI = "http://apache.org/xml/features/validation/schema/augment-psvi";
    protected static final String SCHEMA_DV_FACTORY = "http://apache.org/xml/properties/internal/validation/schema/dv-factory";
    protected static final String SCHEMA_ELEMENT_DEFAULT = "http://apache.org/xml/features/validation/schema/element-default";
    protected static final String SCHEMA_LOCATION = "http://apache.org/xml/properties/schema/external-schemaLocation";
    protected static final String SCHEMA_NONS_LOCATION = "http://apache.org/xml/properties/schema/external-noNamespaceSchemaLocation";
    protected static final String SCHEMA_VALIDATOR = "http://apache.org/xml/properties/internal/validator/schema";
    protected static final String TOLERATE_DUPLICATES = "http://apache.org/xml/features/internal/tolerate-duplicates";
    protected static final String UNPARSED_ENTITY_CHECKING = "http://apache.org/xml/features/validation/unparsed-entity-checking";
    protected static final String VALIDATE_ANNOTATIONS = "http://apache.org/xml/features/validate-annotations";
    protected static final String XMLSCHEMA_FULL_CHECKING = "http://apache.org/xml/features/validation/schema-full-checking";
    protected static final String XMLSCHEMA_VALIDATION = "http://apache.org/xml/features/validation/schema";
    protected XMLSchemaValidator fSchemaValidator;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public StandardParserConfiguration() {
        this((SymbolTable) null, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public StandardParserConfiguration(SymbolTable symbolTable) {
        this(symbolTable, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public StandardParserConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool) {
        this(symbolTable, xMLGrammarPool, (XMLComponentManager) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public StandardParserConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool, XMLComponentManager xMLComponentManager) {
        super(symbolTable, xMLGrammarPool, xMLComponentManager);
        String[] strArr = new String[14];
        strArr[0] = NORMALIZE_DATA;
        String[] strArr2 = strArr;
        strArr2[1] = SCHEMA_ELEMENT_DEFAULT;
        String[] strArr3 = strArr2;
        strArr3[2] = SCHEMA_AUGMENT_PSVI;
        String[] strArr4 = strArr3;
        strArr4[3] = GENERATE_SYNTHETIC_ANNOTATIONS;
        String[] strArr5 = strArr4;
        strArr5[4] = VALIDATE_ANNOTATIONS;
        String[] strArr6 = strArr5;
        strArr6[5] = HONOUR_ALL_SCHEMALOCATIONS;
        String[] strArr7 = strArr6;
        strArr7[6] = NAMESPACE_GROWTH;
        String[] strArr8 = strArr7;
        strArr8[7] = TOLERATE_DUPLICATES;
        String[] strArr9 = strArr8;
        strArr9[8] = XMLSCHEMA_VALIDATION;
        String[] strArr10 = strArr9;
        strArr10[9] = XMLSCHEMA_FULL_CHECKING;
        String[] strArr11 = strArr10;
        strArr11[10] = IGNORE_XSI_TYPE;
        String[] strArr12 = strArr11;
        strArr12[11] = ID_IDREF_CHECKING;
        String[] strArr13 = strArr12;
        strArr13[12] = IDENTITY_CONSTRAINT_CHECKING;
        String[] strArr14 = strArr13;
        strArr14[13] = UNPARSED_ENTITY_CHECKING;
        addRecognizedFeatures(strArr14);
        setFeature(SCHEMA_ELEMENT_DEFAULT, true);
        setFeature(NORMALIZE_DATA, true);
        setFeature(SCHEMA_AUGMENT_PSVI, true);
        setFeature(GENERATE_SYNTHETIC_ANNOTATIONS, false);
        setFeature(VALIDATE_ANNOTATIONS, false);
        setFeature(HONOUR_ALL_SCHEMALOCATIONS, false);
        setFeature(NAMESPACE_GROWTH, false);
        setFeature(TOLERATE_DUPLICATES, false);
        setFeature(IGNORE_XSI_TYPE, false);
        setFeature(ID_IDREF_CHECKING, true);
        setFeature(IDENTITY_CONSTRAINT_CHECKING, true);
        setFeature(UNPARSED_ENTITY_CHECKING, true);
        String[] strArr15 = new String[5];
        strArr15[0] = SCHEMA_LOCATION;
        String[] strArr16 = strArr15;
        strArr16[1] = SCHEMA_NONS_LOCATION;
        String[] strArr17 = strArr16;
        strArr17[2] = ROOT_TYPE_DEF;
        String[] strArr18 = strArr17;
        strArr18[3] = ROOT_ELEMENT_DECL;
        String[] strArr19 = strArr18;
        strArr19[4] = SCHEMA_DV_FACTORY;
        addRecognizedProperties(strArr19);
    }

    /* access modifiers changed from: protected */
    public void checkFeature(String str) throws XMLConfigurationException {
        String str2 = str;
        if (str2.startsWith("http://apache.org/xml/features/")) {
            int length = str2.length() - "http://apache.org/xml/features/".length();
            if (length == "validation/schema".length() && str2.endsWith("validation/schema")) {
                return;
            }
            if (length == "validation/schema-full-checking".length() && str2.endsWith("validation/schema-full-checking")) {
                return;
            }
            if (length == "validation/schema/normalized-value".length() && str2.endsWith("validation/schema/normalized-value")) {
                return;
            }
            if (length == "validation/schema/element-default".length() && str2.endsWith("validation/schema/element-default")) {
                return;
            }
        }
        super.checkFeature(str2);
    }

    /* access modifiers changed from: protected */
    public void checkProperty(String str) throws XMLConfigurationException {
        String str2 = str;
        if (str2.startsWith("http://apache.org/xml/properties/")) {
            int length = str2.length() - "http://apache.org/xml/properties/".length();
            if (length == "schema/external-schemaLocation".length() && str2.endsWith("schema/external-schemaLocation")) {
                return;
            }
            if (length == "schema/external-noNamespaceSchemaLocation".length() && str2.endsWith("schema/external-noNamespaceSchemaLocation")) {
                return;
            }
        }
        if (!str2.startsWith("http://java.sun.com/xml/jaxp/properties/") || str2.length() - "http://java.sun.com/xml/jaxp/properties/".length() != "schemaSource".length() || !str2.endsWith("schemaSource")) {
            super.checkProperty(str2);
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void configurePipeline() {
        /*
            r6 = this;
            r0 = r6
            r2 = r0
            super.configurePipeline()
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/features/validation/schema"
            boolean r2 = r2.getFeature(r3)
            if (r2 == 0) goto L_0x0073
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r2 = r2.fSchemaValidator
            if (r2 != 0) goto L_0x0052
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = new org.apache.xerces.impl.xs.XMLSchemaValidator
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r2.fSchemaValidator = r3
            r2 = r0
            java.util.HashMap r2 = r2.fProperties
            java.lang.String r3 = "http://apache.org/xml/properties/internal/validator/schema"
            r4 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r4 = r4.fSchemaValidator
            java.lang.Object r2 = r2.put(r3, r4)
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.addComponent(r3)
            r2 = r0
            org.apache.xerces.impl.XMLErrorReporter r2 = r2.fErrorReporter
            java.lang.String r3 = "http://www.w3.org/TR/xml-schema-1"
            org.apache.xerces.util.MessageFormatter r2 = r2.getMessageFormatter(r3)
            if (r2 != 0) goto L_0x0052
            org.apache.xerces.impl.xs.XSMessageFormatter r2 = new org.apache.xerces.impl.xs.XSMessageFormatter
            r5 = r2
            r2 = r5
            r3 = r5
            r3.<init>()
            r1 = r2
            r2 = r0
            org.apache.xerces.impl.XMLErrorReporter r2 = r2.fErrorReporter
            java.lang.String r3 = "http://www.w3.org/TR/xml-schema-1"
            r4 = r1
            r2.putMessageFormatter(r3, r4)
        L_0x0052:
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.fLastComponent = r3
            r2 = r0
            org.apache.xerces.impl.XMLNamespaceBinder r2 = r2.fNamespaceBinder
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r2 = r2.fSchemaValidator
            r3 = r0
            org.apache.xerces.xni.XMLDocumentHandler r3 = r3.fDocumentHandler
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r2 = r2.fSchemaValidator
            r3 = r0
            org.apache.xerces.impl.XMLNamespaceBinder r3 = r3.fNamespaceBinder
            r2.setDocumentSource(r3)
        L_0x0073:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.StandardParserConfiguration.configurePipeline():void");
    }
}
