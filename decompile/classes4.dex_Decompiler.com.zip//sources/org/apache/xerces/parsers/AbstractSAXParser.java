package org.apache.xerces.parsers;

import com.kodular.fabextension.BuildConfig;
import java.io.CharConversionException;
import java.io.IOException;
import java.util.Locale;
import org.apache.xerces.util.EntityResolver2Wrapper;
import org.apache.xerces.util.EntityResolverWrapper;
import org.apache.xerces.util.ErrorHandlerWrapper;
import org.apache.xerces.util.SAXMessageFormatter;
import org.apache.xerces.util.SymbolHash;
import org.apache.xerces.util.XMLSymbols;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLParseException;
import org.apache.xerces.xs.AttributePSVI;
import org.apache.xerces.xs.ElementPSVI;
import org.apache.xerces.xs.PSVIProvider;
import org.xml.sax.AttributeList;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.DocumentHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.Parser;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.ext.Attributes2;
import org.xml.sax.ext.DeclHandler;
import org.xml.sax.ext.EntityResolver2;
import org.xml.sax.ext.LexicalHandler;
import org.xml.sax.ext.Locator2;
import org.xml.sax.ext.Locator2Impl;

public abstract class AbstractSAXParser extends AbstractXMLDocumentParser implements PSVIProvider, Parser, XMLReader {
    protected static final String ALLOW_UE_AND_NOTATION_EVENTS = "http://xml.org/sax/features/allow-dtd-events-after-endDTD";
    protected static final String DECLARATION_HANDLER = "http://xml.org/sax/properties/declaration-handler";
    protected static final String DOM_NODE = "http://xml.org/sax/properties/dom-node";
    protected static final String LEXICAL_HANDLER = "http://xml.org/sax/properties/lexical-handler";
    protected static final String NAMESPACES = "http://xml.org/sax/features/namespaces";
    private static final String[] RECOGNIZED_FEATURES;
    private static final String[] RECOGNIZED_PROPERTIES;
    protected static final String STRING_INTERNING = "http://xml.org/sax/features/string-interning";
    private final AttributesProxy fAttributesProxy;
    private Augmentations fAugmentations;
    protected ContentHandler fContentHandler;
    protected DTDHandler fDTDHandler;
    protected DeclHandler fDeclHandler;
    protected SymbolHash fDeclaredAttrs;
    protected DocumentHandler fDocumentHandler;
    protected LexicalHandler fLexicalHandler;
    protected boolean fLexicalHandlerParameterEntities = true;
    protected NamespaceContext fNamespaceContext;
    protected boolean fNamespacePrefixes = false;
    protected boolean fNamespaces;
    protected boolean fParseInProgress;
    protected final QName fQName;
    protected boolean fResolveDTDURIs = true;
    protected boolean fStandalone;
    protected boolean fUseEntityResolver2 = true;
    protected String fVersion;
    protected boolean fXMLNSURIs = false;

    protected static final class AttributesProxy implements AttributeList, Attributes2 {
        protected XMLAttributes fAttributes;

        protected AttributesProxy() {
        }

        public int getIndex(String str) {
            return this.fAttributes.getIndex(str);
        }

        public int getIndex(String str, String str2) {
            String str3 = str;
            String str4 = str2;
            return str3.length() == 0 ? this.fAttributes.getIndex((String) null, str4) : this.fAttributes.getIndex(str3, str4);
        }

        public int getLength() {
            return this.fAttributes.getLength();
        }

        public String getLocalName(int i) {
            return this.fAttributes.getLocalName(i);
        }

        public String getName(int i) {
            return this.fAttributes.getQName(i);
        }

        public String getQName(int i) {
            return this.fAttributes.getQName(i);
        }

        public String getType(int i) {
            return this.fAttributes.getType(i);
        }

        public String getType(String str) {
            return this.fAttributes.getType(str);
        }

        public String getType(String str, String str2) {
            String str3 = str;
            String str4 = str2;
            return str3.length() == 0 ? this.fAttributes.getType((String) null, str4) : this.fAttributes.getType(str3, str4);
        }

        public String getURI(int i) {
            String uri = this.fAttributes.getURI(i);
            return uri != null ? uri : "";
        }

        public String getValue(int i) {
            return this.fAttributes.getValue(i);
        }

        public String getValue(String str) {
            return this.fAttributes.getValue(str);
        }

        public String getValue(String str, String str2) {
            String str3 = str;
            String str4 = str2;
            return str3.length() == 0 ? this.fAttributes.getValue((String) null, str4) : this.fAttributes.getValue(str3, str4);
        }

        public boolean isDeclared(int i) {
            Throwable th;
            int i2 = i;
            if (i2 >= 0 && i2 < this.fAttributes.getLength()) {
                return Boolean.TRUE.equals(this.fAttributes.getAugmentations(i2).getItem("ATTRIBUTE_DECLARED"));
            }
            Throwable th2 = th;
            new ArrayIndexOutOfBoundsException(i2);
            throw th2;
        }

        public boolean isDeclared(String str) {
            Throwable th;
            String str2 = str;
            int index = getIndex(str2);
            if (index != -1) {
                return Boolean.TRUE.equals(this.fAttributes.getAugmentations(index).getItem("ATTRIBUTE_DECLARED"));
            }
            Throwable th2 = th;
            new IllegalArgumentException(str2);
            throw th2;
        }

        public boolean isDeclared(String str, String str2) {
            Throwable th;
            String str3 = str2;
            int index = getIndex(str, str3);
            if (index != -1) {
                return Boolean.TRUE.equals(this.fAttributes.getAugmentations(index).getItem("ATTRIBUTE_DECLARED"));
            }
            Throwable th2 = th;
            new IllegalArgumentException(str3);
            throw th2;
        }

        public boolean isSpecified(int i) {
            Throwable th;
            int i2 = i;
            if (i2 >= 0 && i2 < this.fAttributes.getLength()) {
                return this.fAttributes.isSpecified(i2);
            }
            Throwable th2 = th;
            new ArrayIndexOutOfBoundsException(i2);
            throw th2;
        }

        public boolean isSpecified(String str) {
            Throwable th;
            String str2 = str;
            int index = getIndex(str2);
            if (index != -1) {
                return this.fAttributes.isSpecified(index);
            }
            Throwable th2 = th;
            new IllegalArgumentException(str2);
            throw th2;
        }

        public boolean isSpecified(String str, String str2) {
            Throwable th;
            String str3 = str2;
            int index = getIndex(str, str3);
            if (index != -1) {
                return this.fAttributes.isSpecified(index);
            }
            Throwable th2 = th;
            new IllegalArgumentException(str3);
            throw th2;
        }

        public void setAttributes(XMLAttributes xMLAttributes) {
            XMLAttributes xMLAttributes2 = xMLAttributes;
            this.fAttributes = xMLAttributes2;
        }
    }

    protected static final class LocatorProxy implements Locator2 {
        protected XMLLocator fLocator;

        public LocatorProxy(XMLLocator xMLLocator) {
            this.fLocator = xMLLocator;
        }

        public int getColumnNumber() {
            return this.fLocator.getColumnNumber();
        }

        public String getEncoding() {
            return this.fLocator.getEncoding();
        }

        public int getLineNumber() {
            return this.fLocator.getLineNumber();
        }

        public String getPublicId() {
            return this.fLocator.getPublicId();
        }

        public String getSystemId() {
            return this.fLocator.getExpandedSystemId();
        }

        public String getXMLVersion() {
            return this.fLocator.getXMLVersion();
        }
    }

    static {
        String[] strArr = new String[2];
        strArr[0] = NAMESPACES;
        String[] strArr2 = strArr;
        strArr2[1] = STRING_INTERNING;
        RECOGNIZED_FEATURES = strArr2;
        String[] strArr3 = new String[3];
        strArr3[0] = LEXICAL_HANDLER;
        String[] strArr4 = strArr3;
        strArr4[1] = DECLARATION_HANDLER;
        String[] strArr5 = strArr4;
        strArr5[2] = DOM_NODE;
        RECOGNIZED_PROPERTIES = strArr5;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected AbstractSAXParser(org.apache.xerces.xni.parser.XMLParserConfiguration r8) {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r3 = r0
            r4 = r1
            r3.<init>(r4)
            r3 = r0
            r4 = 0
            r3.fNamespacePrefixes = r4
            r3 = r0
            r4 = 1
            r3.fLexicalHandlerParameterEntities = r4
            r3 = r0
            r4 = 1
            r3.fResolveDTDURIs = r4
            r3 = r0
            r4 = 1
            r3.fUseEntityResolver2 = r4
            r3 = r0
            r4 = 0
            r3.fXMLNSURIs = r4
            r3 = r0
            org.apache.xerces.xni.QName r4 = new org.apache.xerces.xni.QName
            r6 = r4
            r4 = r6
            r5 = r6
            r5.<init>()
            r3.fQName = r4
            r3 = r0
            r4 = 0
            r3.fParseInProgress = r4
            r3 = r0
            org.apache.xerces.parsers.AbstractSAXParser$AttributesProxy r4 = new org.apache.xerces.parsers.AbstractSAXParser$AttributesProxy
            r6 = r4
            r4 = r6
            r5 = r6
            r5.<init>()
            r3.fAttributesProxy = r4
            r3 = r0
            r4 = 0
            r3.fAugmentations = r4
            r3 = r0
            r4 = 0
            r3.fDeclaredAttrs = r4
            r3 = r1
            java.lang.String[] r4 = RECOGNIZED_FEATURES
            r3.addRecognizedFeatures(r4)
            r3 = r1
            java.lang.String[] r4 = RECOGNIZED_PROPERTIES
            r3.addRecognizedProperties(r4)
            r3 = r1
            java.lang.String r4 = "http://xml.org/sax/features/allow-dtd-events-after-endDTD"
            r5 = 0
            r3.setFeature(r4, r5)     // Catch:{ XMLConfigurationException -> 0x0052 }
        L_0x0051:
            return
        L_0x0052:
            r3 = move-exception
            r2 = r3
            goto L_0x0051
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.AbstractSAXParser.<init>(org.apache.xerces.xni.parser.XMLParserConfiguration):void");
    }

    public void attributeDecl(String str, String str2, String str3, String[] strArr, String str4, XMLString xMLString, XMLString xMLString2, Augmentations augmentations) throws XNIException {
        Throwable th;
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        String str5 = str;
        String str6 = str2;
        String str7 = str3;
        String[] strArr2 = strArr;
        String str8 = str4;
        XMLString xMLString3 = xMLString;
        XMLString xMLString4 = xMLString2;
        Augmentations augmentations2 = augmentations;
        try {
            if (this.fDeclHandler != null) {
                new StringBuffer(str5);
                String stringBuffer3 = stringBuffer.append('<').append(str6).toString();
                if (this.fDeclaredAttrs.get(stringBuffer3) == null) {
                    this.fDeclaredAttrs.put(stringBuffer3, Boolean.TRUE);
                    if (str7.equals("NOTATION") || str7.equals("ENUMERATION")) {
                        new StringBuffer();
                        StringBuffer stringBuffer4 = stringBuffer2;
                        if (str7.equals("NOTATION")) {
                            StringBuffer append = stringBuffer4.append(str7);
                            StringBuffer append2 = stringBuffer4.append(" (");
                        } else {
                            StringBuffer append3 = stringBuffer4.append('(');
                        }
                        for (int i = 0; i < strArr2.length; i++) {
                            StringBuffer append4 = stringBuffer4.append(strArr2[i]);
                            if (i < strArr2.length - 1) {
                                StringBuffer append5 = stringBuffer4.append('|');
                            }
                        }
                        StringBuffer append6 = stringBuffer4.append(')');
                        str7 = stringBuffer4.toString();
                    }
                    this.fDeclHandler.attributeDecl(str5, str6, str7, str8, xMLString3 == null ? null : xMLString3.toString());
                }
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void characters(XMLString xMLString, Augmentations augmentations) throws XNIException {
        Throwable th;
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (xMLString2.length != 0) {
            try {
                if (this.fDocumentHandler != null) {
                    this.fDocumentHandler.characters(xMLString2.ch, xMLString2.offset, xMLString2.length);
                }
                if (this.fContentHandler != null) {
                    this.fContentHandler.characters(xMLString2.ch, xMLString2.offset, xMLString2.length);
                }
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }
    }

    public void comment(XMLString xMLString, Augmentations augmentations) throws XNIException {
        Throwable th;
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        try {
            if (this.fLexicalHandler != null) {
                this.fLexicalHandler.comment(xMLString2.ch, 0, xMLString2.length);
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void doctypeDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
        Throwable th;
        SymbolHash symbolHash;
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        Augmentations augmentations2 = augmentations;
        this.fInDTD = true;
        try {
            if (this.fLexicalHandler != null) {
                this.fLexicalHandler.startDTD(str4, str5, str6);
            }
            if (this.fDeclHandler != null) {
                new SymbolHash(25);
                this.fDeclaredAttrs = symbolHash;
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void elementDecl(String str, String str2, Augmentations augmentations) throws XNIException {
        Throwable th;
        String str3 = str;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        try {
            if (this.fDeclHandler != null) {
                this.fDeclHandler.elementDecl(str3, str4);
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void endCDATA(Augmentations augmentations) throws XNIException {
        Throwable th;
        Augmentations augmentations2 = augmentations;
        try {
            if (this.fLexicalHandler != null) {
                this.fLexicalHandler.endCDATA();
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void endDTD(Augmentations augmentations) throws XNIException {
        Throwable th;
        Augmentations augmentations2 = augmentations;
        this.fInDTD = false;
        try {
            if (this.fLexicalHandler != null) {
                this.fLexicalHandler.endDTD();
            }
            if (this.fDeclaredAttrs != null) {
                this.fDeclaredAttrs.clear();
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void endDocument(Augmentations augmentations) throws XNIException {
        Throwable th;
        Augmentations augmentations2 = augmentations;
        try {
            if (this.fDocumentHandler != null) {
                this.fDocumentHandler.endDocument();
            }
            if (this.fContentHandler != null) {
                this.fContentHandler.endDocument();
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void endElement(QName qName, Augmentations augmentations) throws XNIException {
        Throwable th;
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        try {
            if (this.fDocumentHandler != null) {
                this.fDocumentHandler.endElement(qName2.rawname);
            }
            if (this.fContentHandler != null) {
                this.fAugmentations = augmentations2;
                this.fContentHandler.endElement(qName2.uri != null ? qName2.uri : "", this.fNamespaces ? qName2.localpart : "", qName2.rawname);
                if (this.fNamespaces) {
                    endNamespaceMapping();
                }
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void endExternalSubset(Augmentations augmentations) throws XNIException {
        endParameterEntity("[dtd]", augmentations);
    }

    public void endGeneralEntity(String str, Augmentations augmentations) throws XNIException {
        Throwable th;
        String str2 = str;
        Augmentations augmentations2 = augmentations;
        if (augmentations2 != null) {
            try {
                if (Boolean.TRUE.equals(augmentations2.getItem("ENTITY_SKIPPED"))) {
                    return;
                }
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }
        if (this.fLexicalHandler != null) {
            this.fLexicalHandler.endEntity(str2);
        }
    }

    /* access modifiers changed from: protected */
    public final void endNamespaceMapping() throws SAXException {
        int declaredPrefixCount = this.fNamespaceContext.getDeclaredPrefixCount();
        if (declaredPrefixCount > 0) {
            for (int i = 0; i < declaredPrefixCount; i++) {
                this.fContentHandler.endPrefixMapping(this.fNamespaceContext.getDeclaredPrefixAt(i));
            }
        }
    }

    public void endParameterEntity(String str, Augmentations augmentations) throws XNIException {
        Throwable th;
        String str2 = str;
        Augmentations augmentations2 = augmentations;
        if (augmentations2 != null) {
            try {
                if (Boolean.TRUE.equals(augmentations2.getItem("ENTITY_SKIPPED"))) {
                    return;
                }
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }
        if (this.fLexicalHandler != null && this.fLexicalHandlerParameterEntities) {
            this.fLexicalHandler.endEntity(str2);
        }
    }

    public void externalEntityDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
        Throwable th;
        String str2 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        Augmentations augmentations2 = augmentations;
        try {
            if (this.fDeclHandler != null) {
                this.fDeclHandler.externalEntityDecl(str2, xMLResourceIdentifier2.getPublicId(), this.fResolveDTDURIs ? xMLResourceIdentifier2.getExpandedSystemId() : xMLResourceIdentifier2.getLiteralSystemId());
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public AttributePSVI getAttributePSVI(int i) {
        return (AttributePSVI) this.fAttributesProxy.fAttributes.getAugmentations(i).getItem("ATTRIBUTE_PSVI");
    }

    public AttributePSVI getAttributePSVIByName(String str, String str2) {
        return (AttributePSVI) this.fAttributesProxy.fAttributes.getAugmentations(str, str2).getItem("ATTRIBUTE_PSVI");
    }

    public ContentHandler getContentHandler() {
        return this.fContentHandler;
    }

    public DTDHandler getDTDHandler() {
        return this.fDTDHandler;
    }

    /* access modifiers changed from: protected */
    public DeclHandler getDeclHandler() throws SAXNotRecognizedException, SAXNotSupportedException {
        return this.fDeclHandler;
    }

    public ElementPSVI getElementPSVI() {
        return this.fAugmentations != null ? (ElementPSVI) this.fAugmentations.getItem("ELEMENT_PSVI") : null;
    }

    public EntityResolver getEntityResolver() {
        EntityResolver2 entityResolver2 = null;
        try {
            XMLEntityResolver xMLEntityResolver = (XMLEntityResolver) this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/entity-resolver");
            if (xMLEntityResolver != null) {
                if (xMLEntityResolver instanceof EntityResolverWrapper) {
                    entityResolver2 = ((EntityResolverWrapper) xMLEntityResolver).getEntityResolver();
                } else if (xMLEntityResolver instanceof EntityResolver2Wrapper) {
                    entityResolver2 = ((EntityResolver2Wrapper) xMLEntityResolver).getEntityResolver();
                }
            }
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
        }
        return entityResolver2;
    }

    public ErrorHandler getErrorHandler() {
        ErrorHandler errorHandler = null;
        try {
            XMLErrorHandler xMLErrorHandler = (XMLErrorHandler) this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/error-handler");
            if (xMLErrorHandler != null && (xMLErrorHandler instanceof ErrorHandlerWrapper)) {
                errorHandler = ((ErrorHandlerWrapper) xMLErrorHandler).getErrorHandler();
            }
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
        }
        return errorHandler;
    }

    public boolean getFeature(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        String str2 = str;
        try {
            if (str2.startsWith("http://xml.org/sax/features/")) {
                int length = str2.length() - "http://xml.org/sax/features/".length();
                if (length == "namespace-prefixes".length() && str2.endsWith("namespace-prefixes")) {
                    return this.fNamespacePrefixes;
                }
                if (length == "string-interning".length() && str2.endsWith("string-interning")) {
                    return true;
                }
                if (length == "is-standalone".length() && str2.endsWith("is-standalone")) {
                    return this.fStandalone;
                }
                if (length == "xml-1.1".length() && str2.endsWith("xml-1.1")) {
                    return this.fConfiguration instanceof XML11Configurable;
                }
                if (length == "lexical-handler/parameter-entities".length() && str2.endsWith("lexical-handler/parameter-entities")) {
                    return this.fLexicalHandlerParameterEntities;
                }
                if (length == "resolve-dtd-uris".length() && str2.endsWith("resolve-dtd-uris")) {
                    return this.fResolveDTDURIs;
                }
                if (length == "xmlns-uris".length() && str2.endsWith("xmlns-uris")) {
                    return this.fXMLNSURIs;
                }
                if (length == "unicode-normalization-checking".length() && str2.endsWith("unicode-normalization-checking")) {
                    return false;
                }
                if (length == "use-entity-resolver2".length() && str2.endsWith("use-entity-resolver2")) {
                    return this.fUseEntityResolver2;
                }
                if ((length == "use-attributes2".length() && str2.endsWith("use-attributes2")) || (length == "use-locator2".length() && str2.endsWith("use-locator2"))) {
                    return true;
                }
            }
            return this.fConfiguration.getFeature(str2);
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
            String identifier = xMLConfigurationException.getIdentifier();
            if (xMLConfigurationException.getType() == 0) {
                Throwable th3 = th2;
                new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-not-recognized", new Object[]{identifier}));
                throw th3;
            }
            Throwable th4 = th;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-not-supported", new Object[]{identifier}));
            throw th4;
        }
    }

    /* access modifiers changed from: protected */
    public LexicalHandler getLexicalHandler() throws SAXNotRecognizedException, SAXNotSupportedException {
        return this.fLexicalHandler;
    }

    public Object getProperty(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        try {
            if (str2.startsWith("http://xml.org/sax/properties/")) {
                int length = str2.length() - "http://xml.org/sax/properties/".length();
                if (length == "document-xml-version".length() && str2.endsWith("document-xml-version")) {
                    return this.fVersion;
                }
                if (length == "lexical-handler".length() && str2.endsWith("lexical-handler")) {
                    return getLexicalHandler();
                }
                if (length == "declaration-handler".length() && str2.endsWith("declaration-handler")) {
                    return getDeclHandler();
                }
                if (length == "dom-node".length() && str2.endsWith("dom-node")) {
                    Throwable th4 = th3;
                    new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "dom-node-read-not-supported", (Object[]) null));
                    throw th4;
                }
            }
            return this.fConfiguration.getProperty(str2);
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
            String identifier = xMLConfigurationException.getIdentifier();
            if (xMLConfigurationException.getType() == 0) {
                Throwable th5 = th2;
                new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-recognized", new Object[]{identifier}));
                throw th5;
            }
            Throwable th6 = th;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-supported", new Object[]{identifier}));
            throw th6;
        }
    }

    public void ignorableWhitespace(XMLString xMLString, Augmentations augmentations) throws XNIException {
        Throwable th;
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        try {
            if (this.fDocumentHandler != null) {
                this.fDocumentHandler.ignorableWhitespace(xMLString2.ch, xMLString2.offset, xMLString2.length);
            }
            if (this.fContentHandler != null) {
                this.fContentHandler.ignorableWhitespace(xMLString2.ch, xMLString2.offset, xMLString2.length);
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void internalEntityDecl(String str, XMLString xMLString, XMLString xMLString2, Augmentations augmentations) throws XNIException {
        Throwable th;
        String str2 = str;
        XMLString xMLString3 = xMLString;
        XMLString xMLString4 = xMLString2;
        Augmentations augmentations2 = augmentations;
        try {
            if (this.fDeclHandler != null) {
                this.fDeclHandler.internalEntityDecl(str2, xMLString3.toString());
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void notationDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
        Throwable th;
        String str2 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        Augmentations augmentations2 = augmentations;
        try {
            if (this.fDTDHandler != null) {
                this.fDTDHandler.notationDecl(str2, xMLResourceIdentifier2.getPublicId(), this.fResolveDTDURIs ? xMLResourceIdentifier2.getExpandedSystemId() : xMLResourceIdentifier2.getLiteralSystemId());
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void parse(String str) throws SAXException, IOException {
        XMLInputSource xMLInputSource;
        Throwable th;
        Throwable th2;
        Locator2Impl locator2Impl;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        Throwable th6;
        new XMLInputSource((String) null, str, (String) null);
        try {
            parse(xMLInputSource);
        } catch (XMLParseException e) {
            XMLParseException xMLParseException = e;
            Exception exception = xMLParseException.getException();
            if (exception == null || (exception instanceof CharConversionException)) {
                new Locator2Impl();
                Locator2Impl locator2Impl2 = locator2Impl;
                locator2Impl2.setXMLVersion(this.fVersion);
                locator2Impl2.setPublicId(xMLParseException.getPublicId());
                locator2Impl2.setSystemId(xMLParseException.getExpandedSystemId());
                locator2Impl2.setLineNumber(xMLParseException.getLineNumber());
                locator2Impl2.setColumnNumber(xMLParseException.getColumnNumber());
                if (exception == null) {
                    th4 = th5;
                    new SAXParseException(xMLParseException.getMessage(), locator2Impl2);
                } else {
                    th4 = th3;
                    new SAXParseException(xMLParseException.getMessage(), locator2Impl2, exception);
                }
                throw th4;
            } else if (exception instanceof SAXException) {
                throw ((SAXException) exception);
            } else if (exception instanceof IOException) {
                throw ((IOException) exception);
            } else {
                Throwable th7 = th6;
                new SAXException(exception);
                throw th7;
            }
        } catch (XNIException e2) {
            XNIException xNIException = e2;
            Exception exception2 = xNIException.getException();
            if (exception2 == null) {
                Throwable th8 = th2;
                new SAXException(xNIException.getMessage());
                throw th8;
            } else if (exception2 instanceof SAXException) {
                throw ((SAXException) exception2);
            } else if (exception2 instanceof IOException) {
                throw ((IOException) exception2);
            } else {
                Throwable th9 = th;
                new SAXException(exception2);
                throw th9;
            }
        }
    }

    public void parse(InputSource inputSource) throws SAXException, IOException {
        Throwable th;
        Throwable th2;
        Locator2Impl locator2Impl;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        Throwable th6;
        XMLInputSource xMLInputSource;
        InputSource inputSource2 = inputSource;
        try {
            new XMLInputSource(inputSource2.getPublicId(), inputSource2.getSystemId(), (String) null);
            XMLInputSource xMLInputSource2 = xMLInputSource;
            xMLInputSource2.setByteStream(inputSource2.getByteStream());
            xMLInputSource2.setCharacterStream(inputSource2.getCharacterStream());
            xMLInputSource2.setEncoding(inputSource2.getEncoding());
            parse(xMLInputSource2);
        } catch (XMLParseException e) {
            XMLParseException xMLParseException = e;
            Exception exception = xMLParseException.getException();
            if (exception == null || (exception instanceof CharConversionException)) {
                new Locator2Impl();
                Locator2Impl locator2Impl2 = locator2Impl;
                locator2Impl2.setXMLVersion(this.fVersion);
                locator2Impl2.setPublicId(xMLParseException.getPublicId());
                locator2Impl2.setSystemId(xMLParseException.getExpandedSystemId());
                locator2Impl2.setLineNumber(xMLParseException.getLineNumber());
                locator2Impl2.setColumnNumber(xMLParseException.getColumnNumber());
                if (exception == null) {
                    th4 = th5;
                    new SAXParseException(xMLParseException.getMessage(), locator2Impl2);
                } else {
                    th4 = th3;
                    new SAXParseException(xMLParseException.getMessage(), locator2Impl2, exception);
                }
                throw th4;
            } else if (exception instanceof SAXException) {
                throw ((SAXException) exception);
            } else if (exception instanceof IOException) {
                throw ((IOException) exception);
            } else {
                Throwable th7 = th6;
                new SAXException(exception);
                throw th7;
            }
        } catch (XNIException e2) {
            XNIException xNIException = e2;
            Exception exception2 = xNIException.getException();
            if (exception2 == null) {
                Throwable th8 = th2;
                new SAXException(xNIException.getMessage());
                throw th8;
            } else if (exception2 instanceof SAXException) {
                throw ((SAXException) exception2);
            } else if (exception2 instanceof IOException) {
                throw ((IOException) exception2);
            } else {
                Throwable th9 = th;
                new SAXException(exception2);
                throw th9;
            }
        }
    }

    public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
        Throwable th;
        String str2 = str;
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        try {
            if (this.fDocumentHandler != null) {
                this.fDocumentHandler.processingInstruction(str2, xMLString2.toString());
            }
            if (this.fContentHandler != null) {
                this.fContentHandler.processingInstruction(str2, xMLString2.toString());
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void reset() throws XNIException {
        super.reset();
        this.fInDTD = false;
        this.fVersion = BuildConfig.VERSION_NAME;
        this.fStandalone = false;
        this.fNamespaces = this.fConfiguration.getFeature(NAMESPACES);
        this.fAugmentations = null;
        this.fDeclaredAttrs = null;
    }

    public void setContentHandler(ContentHandler contentHandler) {
        ContentHandler contentHandler2 = contentHandler;
        this.fContentHandler = contentHandler2;
    }

    public void setDTDHandler(DTDHandler dTDHandler) {
        DTDHandler dTDHandler2 = dTDHandler;
        this.fDTDHandler = dTDHandler2;
    }

    /* access modifiers changed from: protected */
    public void setDeclHandler(DeclHandler declHandler) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        DeclHandler declHandler2 = declHandler;
        if (this.fParseInProgress) {
            Throwable th2 = th;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-parsing-supported", new Object[]{DECLARATION_HANDLER}));
            throw th2;
        }
        this.fDeclHandler = declHandler2;
    }

    public void setDocumentHandler(DocumentHandler documentHandler) {
        DocumentHandler documentHandler2 = documentHandler;
        this.fDocumentHandler = documentHandler2;
    }

    public void setEntityResolver(EntityResolver entityResolver) {
        Object obj;
        Object obj2;
        EntityResolver entityResolver2 = entityResolver;
        try {
            XMLEntityResolver xMLEntityResolver = (XMLEntityResolver) this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/entity-resolver");
            if (!this.fUseEntityResolver2 || !(entityResolver2 instanceof EntityResolver2)) {
                if (xMLEntityResolver instanceof EntityResolverWrapper) {
                    ((EntityResolverWrapper) xMLEntityResolver).setEntityResolver(entityResolver2);
                    return;
                }
                new EntityResolverWrapper(entityResolver2);
                this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/entity-resolver", obj);
            } else if (xMLEntityResolver instanceof EntityResolver2Wrapper) {
                ((EntityResolver2Wrapper) xMLEntityResolver).setEntityResolver((EntityResolver2) entityResolver2);
            } else {
                new EntityResolver2Wrapper((EntityResolver2) entityResolver2);
                this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/entity-resolver", obj2);
            }
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
        }
    }

    public void setErrorHandler(ErrorHandler errorHandler) {
        Object obj;
        ErrorHandler errorHandler2 = errorHandler;
        try {
            XMLErrorHandler xMLErrorHandler = (XMLErrorHandler) this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/error-handler");
            if (xMLErrorHandler instanceof ErrorHandlerWrapper) {
                ((ErrorHandlerWrapper) xMLErrorHandler).setErrorHandler(errorHandler2);
                return;
            }
            new ErrorHandlerWrapper(errorHandler2);
            this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/error-handler", obj);
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
        }
    }

    public void setFeature(String str, boolean z) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        String str2 = str;
        boolean z2 = z;
        try {
            if (str2.startsWith("http://xml.org/sax/features/")) {
                int length = str2.length() - "http://xml.org/sax/features/".length();
                if (length == "namespaces".length() && str2.endsWith("namespaces")) {
                    this.fConfiguration.setFeature(str2, z2);
                    this.fNamespaces = z2;
                    return;
                } else if (length == "namespace-prefixes".length() && str2.endsWith("namespace-prefixes")) {
                    this.fNamespacePrefixes = z2;
                    return;
                } else if (length != "string-interning".length() || !str2.endsWith("string-interning")) {
                    if (length == "lexical-handler/parameter-entities".length() && str2.endsWith("lexical-handler/parameter-entities")) {
                        this.fLexicalHandlerParameterEntities = z2;
                        return;
                    } else if (length == "resolve-dtd-uris".length() && str2.endsWith("resolve-dtd-uris")) {
                        this.fResolveDTDURIs = z2;
                        return;
                    } else if (length != "unicode-normalization-checking".length() || !str2.endsWith("unicode-normalization-checking")) {
                        if (length == "xmlns-uris".length() && str2.endsWith("xmlns-uris")) {
                            this.fXMLNSURIs = z2;
                            return;
                        } else if (length == "use-entity-resolver2".length() && str2.endsWith("use-entity-resolver2")) {
                            if (z2 != this.fUseEntityResolver2) {
                                this.fUseEntityResolver2 = z2;
                                setEntityResolver(getEntityResolver());
                            }
                            return;
                        } else if ((length == "is-standalone".length() && str2.endsWith("is-standalone")) || ((length == "use-attributes2".length() && str2.endsWith("use-attributes2")) || ((length == "use-locator2".length() && str2.endsWith("use-locator2")) || (length == "xml-1.1".length() && str2.endsWith("xml-1.1"))))) {
                            Throwable th6 = th3;
                            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-read-only", new Object[]{str2}));
                            throw th6;
                        }
                    } else if (z2) {
                        Throwable th7 = th4;
                        new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "true-not-supported", new Object[]{str2}));
                        throw th7;
                    } else {
                        return;
                    }
                } else if (!z2) {
                    Throwable th8 = th5;
                    new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "false-not-supported", new Object[]{str2}));
                    throw th8;
                } else {
                    return;
                }
            }
            this.fConfiguration.setFeature(str2, z2);
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
            String identifier = xMLConfigurationException.getIdentifier();
            if (xMLConfigurationException.getType() == 0) {
                Throwable th9 = th2;
                new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-not-recognized", new Object[]{identifier}));
                throw th9;
            }
            Throwable th10 = th;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-not-supported", new Object[]{identifier}));
            throw th10;
        }
    }

    /* access modifiers changed from: protected */
    public void setLexicalHandler(LexicalHandler lexicalHandler) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        LexicalHandler lexicalHandler2 = lexicalHandler;
        if (this.fParseInProgress) {
            Throwable th2 = th;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-parsing-supported", new Object[]{LEXICAL_HANDLER}));
            throw th2;
        }
        this.fLexicalHandler = lexicalHandler2;
    }

    public void setLocale(Locale locale) throws SAXException {
        this.fConfiguration.setLocale(locale);
    }

    public void setProperty(String str, Object obj) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        String str2 = str;
        Object obj2 = obj;
        try {
            if (str2.startsWith("http://xml.org/sax/properties/")) {
                int length = str2.length() - "http://xml.org/sax/properties/".length();
                if (length == "lexical-handler".length() && str2.endsWith("lexical-handler")) {
                    setLexicalHandler((LexicalHandler) obj2);
                    return;
                } else if (length == "declaration-handler".length() && str2.endsWith("declaration-handler")) {
                    setDeclHandler((DeclHandler) obj2);
                    return;
                } else if ((length == "dom-node".length() && str2.endsWith("dom-node")) || (length == "document-xml-version".length() && str2.endsWith("document-xml-version"))) {
                    Throwable th6 = th3;
                    new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-read-only", new Object[]{str2}));
                    throw th6;
                }
            }
            this.fConfiguration.setProperty(str2, obj2);
        } catch (ClassCastException e) {
            ClassCastException classCastException = e;
            Throwable th7 = th4;
            Locale locale = this.fConfiguration.getLocale();
            Object[] objArr = new Object[2];
            objArr[0] = str2;
            Object[] objArr2 = objArr;
            objArr2[1] = "org.xml.sax.ext.DeclHandler";
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(locale, "incompatible-class", objArr2));
            throw th7;
        } catch (ClassCastException e2) {
            ClassCastException classCastException2 = e2;
            Throwable th8 = th5;
            Locale locale2 = this.fConfiguration.getLocale();
            Object[] objArr3 = new Object[2];
            objArr3[0] = str2;
            Object[] objArr4 = objArr3;
            objArr4[1] = "org.xml.sax.ext.LexicalHandler";
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(locale2, "incompatible-class", objArr4));
            throw th8;
        } catch (XMLConfigurationException e3) {
            XMLConfigurationException xMLConfigurationException = e3;
            String identifier = xMLConfigurationException.getIdentifier();
            if (xMLConfigurationException.getType() == 0) {
                Throwable th9 = th2;
                new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-recognized", new Object[]{identifier}));
                throw th9;
            }
            Throwable th10 = th;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-supported", new Object[]{identifier}));
            throw th10;
        }
    }

    public void startCDATA(Augmentations augmentations) throws XNIException {
        Throwable th;
        Augmentations augmentations2 = augmentations;
        try {
            if (this.fLexicalHandler != null) {
                this.fLexicalHandler.startCDATA();
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void startDocument(XMLLocator xMLLocator, String str, NamespaceContext namespaceContext, Augmentations augmentations) throws XNIException {
        Throwable th;
        Locator locator;
        Locator locator2;
        XMLLocator xMLLocator2 = xMLLocator;
        String str2 = str;
        Augmentations augmentations2 = augmentations;
        this.fNamespaceContext = namespaceContext;
        try {
            if (this.fDocumentHandler != null) {
                if (xMLLocator2 != null) {
                    new LocatorProxy(xMLLocator2);
                    this.fDocumentHandler.setDocumentLocator(locator2);
                }
                if (this.fDocumentHandler != null) {
                    this.fDocumentHandler.startDocument();
                }
            }
            if (this.fContentHandler != null) {
                if (xMLLocator2 != null) {
                    new LocatorProxy(xMLLocator2);
                    this.fContentHandler.setDocumentLocator(locator);
                }
                if (this.fContentHandler != null) {
                    this.fContentHandler.startDocument();
                }
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void startElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        Throwable th;
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        try {
            if (this.fDocumentHandler != null) {
                this.fAttributesProxy.setAttributes(xMLAttributes2);
                this.fDocumentHandler.startElement(qName2.rawname, this.fAttributesProxy);
            }
            if (this.fContentHandler != null) {
                if (this.fNamespaces) {
                    startNamespaceMapping();
                    int length = xMLAttributes2.getLength();
                    if (!this.fNamespacePrefixes) {
                        for (int i = length - 1; i >= 0; i--) {
                            xMLAttributes2.getName(i, this.fQName);
                            if (this.fQName.prefix == XMLSymbols.PREFIX_XMLNS || this.fQName.rawname == XMLSymbols.PREFIX_XMLNS) {
                                xMLAttributes2.removeAttributeAt(i);
                            }
                        }
                    } else if (!this.fXMLNSURIs) {
                        for (int i2 = length - 1; i2 >= 0; i2--) {
                            xMLAttributes2.getName(i2, this.fQName);
                            if (this.fQName.prefix == XMLSymbols.PREFIX_XMLNS || this.fQName.rawname == XMLSymbols.PREFIX_XMLNS) {
                                this.fQName.prefix = "";
                                this.fQName.uri = "";
                                this.fQName.localpart = "";
                                xMLAttributes2.setName(i2, this.fQName);
                            }
                        }
                    }
                }
                this.fAugmentations = augmentations2;
                String str = qName2.uri != null ? qName2.uri : "";
                String str2 = this.fNamespaces ? qName2.localpart : "";
                this.fAttributesProxy.setAttributes(xMLAttributes2);
                this.fContentHandler.startElement(str, str2, qName2.rawname, this.fAttributesProxy);
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void startExternalSubset(XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        startParameterEntity("[dtd]", (XMLResourceIdentifier) null, (String) null, augmentations);
    }

    public void startGeneralEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
        Throwable th;
        String str3 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        if (augmentations2 != null) {
            try {
                if (Boolean.TRUE.equals(augmentations2.getItem("ENTITY_SKIPPED"))) {
                    if (this.fContentHandler != null) {
                        this.fContentHandler.skippedEntity(str3);
                        return;
                    }
                    return;
                }
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }
        if (this.fLexicalHandler != null) {
            this.fLexicalHandler.startEntity(str3);
        }
    }

    /* access modifiers changed from: protected */
    public final void startNamespaceMapping() throws SAXException {
        int declaredPrefixCount = this.fNamespaceContext.getDeclaredPrefixCount();
        if (declaredPrefixCount > 0) {
            for (int i = 0; i < declaredPrefixCount; i++) {
                String declaredPrefixAt = this.fNamespaceContext.getDeclaredPrefixAt(i);
                String uri = this.fNamespaceContext.getURI(declaredPrefixAt);
                this.fContentHandler.startPrefixMapping(declaredPrefixAt, uri == null ? "" : uri);
            }
        }
    }

    public void startParameterEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
        Throwable th;
        String str3 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        if (augmentations2 != null) {
            try {
                if (Boolean.TRUE.equals(augmentations2.getItem("ENTITY_SKIPPED"))) {
                    if (this.fContentHandler != null) {
                        this.fContentHandler.skippedEntity(str3);
                        return;
                    }
                    return;
                }
            } catch (SAXException e) {
                SAXException sAXException = e;
                Throwable th2 = th;
                new XNIException((Exception) sAXException);
                throw th2;
            }
        }
        if (this.fLexicalHandler != null && this.fLexicalHandlerParameterEntities) {
            this.fLexicalHandler.startEntity(str3);
        }
    }

    public void unparsedEntityDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
        Throwable th;
        String str3 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        try {
            if (this.fDTDHandler != null) {
                this.fDTDHandler.unparsedEntityDecl(str3, xMLResourceIdentifier2.getPublicId(), this.fResolveDTDURIs ? xMLResourceIdentifier2.getExpandedSystemId() : xMLResourceIdentifier2.getLiteralSystemId(), str4);
            }
        } catch (SAXException e) {
            SAXException sAXException = e;
            Throwable th2 = th;
            new XNIException((Exception) sAXException);
            throw th2;
        }
    }

    public void xmlDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        this.fVersion = str;
        this.fStandalone = "yes".equals(str3);
    }
}
