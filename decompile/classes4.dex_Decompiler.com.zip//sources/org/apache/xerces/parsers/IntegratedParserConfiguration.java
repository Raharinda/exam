package org.apache.xerces.parsers;

import org.apache.xerces.impl.XMLDocumentScannerImpl;
import org.apache.xerces.impl.XMLNSDocumentScannerImpl;
import org.apache.xerces.impl.dtd.XMLDTDValidator;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLDocumentScanner;

public class IntegratedParserConfiguration extends StandardParserConfiguration {
    protected XMLNSDocumentScannerImpl fNamespaceScanner;
    protected XMLDTDValidator fNonNSDTDValidator;
    protected XMLDocumentScannerImpl fNonNSScanner;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public IntegratedParserConfiguration() {
        this((SymbolTable) null, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public IntegratedParserConfiguration(SymbolTable symbolTable) {
        this(symbolTable, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public IntegratedParserConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool) {
        this(symbolTable, xMLGrammarPool, (XMLComponentManager) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public IntegratedParserConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool, XMLComponentManager xMLComponentManager) {
        super(symbolTable, xMLGrammarPool, xMLComponentManager);
        XMLDocumentScannerImpl xMLDocumentScannerImpl;
        XMLDTDValidator xMLDTDValidator;
        new XMLDocumentScannerImpl();
        this.fNonNSScanner = xMLDocumentScannerImpl;
        new XMLDTDValidator();
        this.fNonNSDTDValidator = xMLDTDValidator;
        addComponent(this.fNonNSScanner);
        addComponent(this.fNonNSDTDValidator);
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void configurePipeline() {
        /*
            r6 = this;
            r0 = r6
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/datatype-validator-factory"
            r4 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r4 = r4.fDatatypeValidatorFactory
            r2.setProperty(r3, r4)
            r2 = r0
            r2.configureDTDPipeline()
            r2 = r0
            java.util.HashMap r2 = r2.fFeatures
            java.lang.String r3 = "http://xml.org/sax/features/namespaces"
            java.lang.Object r2 = r2.get(r3)
            java.lang.Boolean r3 = java.lang.Boolean.TRUE
            if (r2 != r3) goto L_0x012e
            r2 = r0
            java.util.HashMap r2 = r2.fProperties
            java.lang.String r3 = "http://apache.org/xml/properties/internal/namespace-binder"
            r4 = r0
            org.apache.xerces.impl.XMLNamespaceBinder r4 = r4.fNamespaceBinder
            java.lang.Object r2 = r2.put(r3, r4)
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r3 = r3.fNamespaceScanner
            r2.fScanner = r3
            r2 = r0
            java.util.HashMap r2 = r2.fProperties
            java.lang.String r3 = "http://apache.org/xml/properties/internal/document-scanner"
            r4 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r4 = r4.fNamespaceScanner
            java.lang.Object r2 = r2.put(r3, r4)
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r2 = r2.fDTDValidator
            if (r2 == 0) goto L_0x0108
            r2 = r0
            java.util.HashMap r2 = r2.fProperties
            java.lang.String r3 = "http://apache.org/xml/properties/internal/validator/dtd"
            r4 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r4 = r4.fDTDValidator
            java.lang.Object r2 = r2.put(r3, r4)
            r2 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r2 = r2.fNamespaceScanner
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fDTDValidator
            r2.setDTDValidator(r3)
            r2 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r2 = r2.fNamespaceScanner
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fDTDValidator
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r2 = r2.fDTDValidator
            r3 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r3 = r3.fNamespaceScanner
            r2.setDocumentSource(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r2 = r2.fDTDValidator
            r3 = r0
            org.apache.xerces.xni.XMLDocumentHandler r3 = r3.fDocumentHandler
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            if (r2 == 0) goto L_0x0081
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fDTDValidator
            r2.setDocumentSource(r3)
        L_0x0081:
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fDTDValidator
            r2.fLastComponent = r3
        L_0x0087:
            r2 = r0
            java.util.HashMap r2 = r2.fFeatures
            java.lang.String r3 = "http://apache.org/xml/features/validation/schema"
            java.lang.Object r2 = r2.get(r3)
            java.lang.Boolean r3 = java.lang.Boolean.TRUE
            if (r2 != r3) goto L_0x0107
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r2 = r2.fSchemaValidator
            if (r2 != 0) goto L_0x00d8
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = new org.apache.xerces.impl.xs.XMLSchemaValidator
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r2.fSchemaValidator = r3
            r2 = r0
            java.util.HashMap r2 = r2.fProperties
            java.lang.String r3 = "http://apache.org/xml/properties/internal/validator/schema"
            r4 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r4 = r4.fSchemaValidator
            java.lang.Object r2 = r2.put(r3, r4)
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.addComponent(r3)
            r2 = r0
            org.apache.xerces.impl.XMLErrorReporter r2 = r2.fErrorReporter
            java.lang.String r3 = "http://www.w3.org/TR/xml-schema-1"
            org.apache.xerces.util.MessageFormatter r2 = r2.getMessageFormatter(r3)
            if (r2 != 0) goto L_0x00d8
            org.apache.xerces.impl.xs.XSMessageFormatter r2 = new org.apache.xerces.impl.xs.XSMessageFormatter
            r5 = r2
            r2 = r5
            r3 = r5
            r3.<init>()
            r1 = r2
            r2 = r0
            org.apache.xerces.impl.XMLErrorReporter r2 = r2.fErrorReporter
            java.lang.String r3 = "http://www.w3.org/TR/xml-schema-1"
            r4 = r1
            r2.putMessageFormatter(r3, r4)
        L_0x00d8:
            r2 = r0
            org.apache.xerces.xni.parser.XMLDocumentSource r2 = r2.fLastComponent
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r2 = r2.fSchemaValidator
            r3 = r0
            org.apache.xerces.xni.parser.XMLDocumentSource r3 = r3.fLastComponent
            r2.setDocumentSource(r3)
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r2 = r2.fSchemaValidator
            r3 = r0
            org.apache.xerces.xni.XMLDocumentHandler r3 = r3.fDocumentHandler
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            if (r2 == 0) goto L_0x0101
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.setDocumentSource(r3)
        L_0x0101:
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.fLastComponent = r3
        L_0x0107:
            return
        L_0x0108:
            r2 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r2 = r2.fNamespaceScanner
            r3 = r0
            org.apache.xerces.xni.XMLDocumentHandler r3 = r3.fDocumentHandler
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r2 = r2.fNamespaceScanner
            r3 = 0
            r2.setDTDValidator(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            if (r2 == 0) goto L_0x0126
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            r3 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r3 = r3.fNamespaceScanner
            r2.setDocumentSource(r3)
        L_0x0126:
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r3 = r3.fNamespaceScanner
            r2.fLastComponent = r3
            goto L_0x0087
        L_0x012e:
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.XMLDocumentScannerImpl r3 = r3.fNonNSScanner
            r2.fScanner = r3
            r2 = r0
            java.util.HashMap r2 = r2.fProperties
            java.lang.String r3 = "http://apache.org/xml/properties/internal/document-scanner"
            r4 = r0
            org.apache.xerces.impl.XMLDocumentScannerImpl r4 = r4.fNonNSScanner
            java.lang.Object r2 = r2.put(r3, r4)
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r2 = r2.fNonNSDTDValidator
            if (r2 == 0) goto L_0x0184
            r2 = r0
            java.util.HashMap r2 = r2.fProperties
            java.lang.String r3 = "http://apache.org/xml/properties/internal/validator/dtd"
            r4 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r4 = r4.fNonNSDTDValidator
            java.lang.Object r2 = r2.put(r3, r4)
            r2 = r0
            org.apache.xerces.impl.XMLDocumentScannerImpl r2 = r2.fNonNSScanner
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fNonNSDTDValidator
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r2 = r2.fNonNSDTDValidator
            r3 = r0
            org.apache.xerces.impl.XMLDocumentScannerImpl r3 = r3.fNonNSScanner
            r2.setDocumentSource(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r2 = r2.fNonNSDTDValidator
            r3 = r0
            org.apache.xerces.xni.XMLDocumentHandler r3 = r3.fDocumentHandler
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            if (r2 == 0) goto L_0x017c
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fNonNSDTDValidator
            r2.setDocumentSource(r3)
        L_0x017c:
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fNonNSDTDValidator
            r2.fLastComponent = r3
            goto L_0x0087
        L_0x0184:
            r2 = r0
            org.apache.xerces.xni.parser.XMLDocumentScanner r2 = r2.fScanner
            r3 = r0
            org.apache.xerces.xni.XMLDocumentHandler r3 = r3.fDocumentHandler
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            if (r2 == 0) goto L_0x019b
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            r3 = r0
            org.apache.xerces.xni.parser.XMLDocumentScanner r3 = r3.fScanner
            r2.setDocumentSource(r3)
        L_0x019b:
            r2 = r0
            r3 = r0
            org.apache.xerces.xni.parser.XMLDocumentScanner r3 = r3.fScanner
            r2.fLastComponent = r3
            goto L_0x0087
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.IntegratedParserConfiguration.configurePipeline():void");
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public org.apache.xerces.impl.dtd.XMLDTDValidator createDTDValidator() {
        /*
            r4 = this;
            r0 = r4
            org.apache.xerces.impl.dtd.XMLNSDTDValidator r1 = new org.apache.xerces.impl.dtd.XMLNSDTDValidator
            r3 = r1
            r1 = r3
            r2 = r3
            r2.<init>()
            r0 = r1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.IntegratedParserConfiguration.createDTDValidator():org.apache.xerces.impl.dtd.XMLDTDValidator");
    }

    /* access modifiers changed from: protected */
    public XMLDocumentScanner createDocumentScanner() {
        XMLNSDocumentScannerImpl xMLNSDocumentScannerImpl;
        new XMLNSDocumentScannerImpl();
        this.fNamespaceScanner = xMLNSDocumentScannerImpl;
        return this.fNamespaceScanner;
    }
}
