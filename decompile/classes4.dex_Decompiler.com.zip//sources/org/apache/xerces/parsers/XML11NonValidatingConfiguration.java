package org.apache.xerces.parsers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import org.apache.xerces.impl.XML11DTDScannerImpl;
import org.apache.xerces.impl.XML11DocumentScannerImpl;
import org.apache.xerces.impl.XML11NSDocumentScannerImpl;
import org.apache.xerces.impl.XMLDocumentScannerImpl;
import org.apache.xerces.impl.XMLEntityManager;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.impl.XMLNSDocumentScannerImpl;
import org.apache.xerces.impl.XMLVersionDetector;
import org.apache.xerces.impl.dtd.XMLDTDValidatorFilter;
import org.apache.xerces.impl.dv.DTDDVFactory;
import org.apache.xerces.impl.validation.ValidationManager;
import org.apache.xerces.util.ParserConfigurationSettings;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.XMLDTDContentModelHandler;
import org.apache.xerces.xni.XMLDTDHandler;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLComponent;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLDTDScanner;
import org.apache.xerces.xni.parser.XMLDocumentScanner;
import org.apache.xerces.xni.parser.XMLDocumentSource;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLPullParserConfiguration;

public class XML11NonValidatingConfiguration extends ParserConfigurationSettings implements XMLPullParserConfiguration, XML11Configurable {
    protected static final String CONTINUE_AFTER_FATAL_ERROR = "http://apache.org/xml/features/continue-after-fatal-error";
    protected static final String DATATYPE_VALIDATOR_FACTORY = "http://apache.org/xml/properties/internal/datatype-validator-factory";
    protected static final String DOCUMENT_SCANNER = "http://apache.org/xml/properties/internal/document-scanner";
    protected static final String DTD_SCANNER = "http://apache.org/xml/properties/internal/dtd-scanner";
    protected static final String DTD_VALIDATOR = "http://apache.org/xml/properties/internal/validator/dtd";
    protected static final String ENTITY_MANAGER = "http://apache.org/xml/properties/internal/entity-manager";
    protected static final String ENTITY_RESOLVER = "http://apache.org/xml/properties/internal/entity-resolver";
    protected static final String ERROR_HANDLER = "http://apache.org/xml/properties/internal/error-handler";
    protected static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
    protected static final String EXTERNAL_GENERAL_ENTITIES = "http://xml.org/sax/features/external-general-entities";
    protected static final String EXTERNAL_PARAMETER_ENTITIES = "http://xml.org/sax/features/external-parameter-entities";
    protected static final String NAMESPACES = "http://xml.org/sax/features/namespaces";
    protected static final String NAMESPACE_BINDER = "http://apache.org/xml/properties/internal/namespace-binder";
    protected static final boolean PRINT_EXCEPTION_STACK_TRACE = false;
    protected static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    protected static final String VALIDATION = "http://xml.org/sax/features/validation";
    protected static final String VALIDATION_MANAGER = "http://apache.org/xml/properties/internal/validation-manager";
    protected static final String XML11_DATATYPE_VALIDATOR_FACTORY = "org.apache.xerces.impl.dv.dtd.XML11DTDDVFactoryImpl";
    protected static final String XMLGRAMMAR_POOL = "http://apache.org/xml/properties/internal/grammar-pool";
    protected static final String XML_STRING = "http://xml.org/sax/properties/xml-string";
    private boolean f11Initialized;
    protected ArrayList fCommonComponents;
    protected ArrayList fComponents;
    protected boolean fConfigUpdated;
    protected XMLDTDScanner fCurrentDTDScanner;
    protected DTDDVFactory fCurrentDVFactory;
    protected XMLDocumentScanner fCurrentScanner;
    protected XMLDTDContentModelHandler fDTDContentModelHandler;
    protected XMLDTDHandler fDTDHandler;
    protected XMLDTDScanner fDTDScanner;
    protected DTDDVFactory fDatatypeValidatorFactory;
    protected XMLDocumentHandler fDocumentHandler;
    protected XMLEntityManager fEntityManager;
    protected XMLErrorReporter fErrorReporter;
    protected XMLGrammarPool fGrammarPool;
    protected XMLInputSource fInputSource;
    protected XMLDocumentSource fLastComponent;
    protected Locale fLocale;
    protected XMLLocator fLocator;
    protected XMLNSDocumentScannerImpl fNamespaceScanner;
    protected XMLDocumentScannerImpl fNonNSScanner;
    protected boolean fParseInProgress;
    protected SymbolTable fSymbolTable;
    protected ValidationManager fValidationManager;
    protected XMLVersionDetector fVersionDetector;
    protected ArrayList fXML11Components;
    protected XML11DTDScannerImpl fXML11DTDScanner;
    protected DTDDVFactory fXML11DatatypeFactory;
    protected XML11DocumentScannerImpl fXML11DocScanner;
    protected XML11NSDocumentScannerImpl fXML11NSDocScanner;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XML11NonValidatingConfiguration() {
        this((SymbolTable) null, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XML11NonValidatingConfiguration(SymbolTable symbolTable) {
        this(symbolTable, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XML11NonValidatingConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool) {
        this(symbolTable, xMLGrammarPool, (XMLComponentManager) null);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v29, resolved type: org.apache.xerces.xni.parser.XMLDTDScanner} */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XML11NonValidatingConfiguration(org.apache.xerces.util.SymbolTable r13, org.apache.xerces.xni.grammars.XMLGrammarPool r14, org.apache.xerces.xni.parser.XMLComponentManager r15) {
        /*
            r12 = this;
            r0 = r12
            r1 = r13
            r2 = r14
            r3 = r15
            r7 = r0
            r8 = r3
            r7.<init>(r8)
            r7 = r0
            r8 = 0
            r7.fXML11Components = r8
            r7 = r0
            r8 = 0
            r7.fCommonComponents = r8
            r7 = r0
            r8 = 0
            r7.fParseInProgress = r8
            r7 = r0
            r8 = 0
            r7.fConfigUpdated = r8
            r7 = r0
            r8 = 0
            r7.fXML11DatatypeFactory = r8
            r7 = r0
            r8 = 0
            r7.fXML11NSDocScanner = r8
            r7 = r0
            r8 = 0
            r7.fXML11DocScanner = r8
            r7 = r0
            r8 = 0
            r7.fXML11DTDScanner = r8
            r7 = r0
            r8 = 0
            r7.f11Initialized = r8
            r7 = r0
            java.util.ArrayList r8 = new java.util.ArrayList
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fComponents = r8
            r7 = r0
            java.util.ArrayList r8 = new java.util.ArrayList
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fXML11Components = r8
            r7 = r0
            java.util.ArrayList r8 = new java.util.ArrayList
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fCommonComponents = r8
            r7 = r0
            java.util.ArrayList r8 = new java.util.ArrayList
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fRecognizedFeatures = r8
            r7 = r0
            java.util.ArrayList r8 = new java.util.ArrayList
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fRecognizedProperties = r8
            r7 = r0
            java.util.HashMap r8 = new java.util.HashMap
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fFeatures = r8
            r7 = r0
            java.util.HashMap r8 = new java.util.HashMap
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fProperties = r8
            r7 = 6
            java.lang.String[] r7 = new java.lang.String[r7]
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 0
            java.lang.String r10 = "http://apache.org/xml/features/continue-after-fatal-error"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 1
            java.lang.String r10 = "http://xml.org/sax/features/validation"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 2
            java.lang.String r10 = "http://xml.org/sax/features/namespaces"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 3
            java.lang.String r10 = "http://xml.org/sax/features/external-general-entities"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 4
            java.lang.String r10 = "http://xml.org/sax/features/external-parameter-entities"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 5
            java.lang.String r10 = "http://apache.org/xml/features/internal/parser-settings"
            r8[r9] = r10
            r4 = r7
            r7 = r0
            r8 = r4
            r7.addRecognizedFeatures(r8)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://xml.org/sax/features/validation"
            java.lang.Boolean r9 = java.lang.Boolean.FALSE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://xml.org/sax/features/namespaces"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://xml.org/sax/features/external-general-entities"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://xml.org/sax/features/external-parameter-entities"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/continue-after-fatal-error"
            java.lang.Boolean r9 = java.lang.Boolean.FALSE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/internal/parser-settings"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = 13
            java.lang.String[] r7 = new java.lang.String[r7]
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 0
            java.lang.String r10 = "http://xml.org/sax/properties/xml-string"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 1
            java.lang.String r10 = "http://apache.org/xml/properties/internal/symbol-table"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 2
            java.lang.String r10 = "http://apache.org/xml/properties/internal/error-handler"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 3
            java.lang.String r10 = "http://apache.org/xml/properties/internal/entity-resolver"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 4
            java.lang.String r10 = "http://apache.org/xml/properties/internal/error-reporter"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 5
            java.lang.String r10 = "http://apache.org/xml/properties/internal/entity-manager"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 6
            java.lang.String r10 = "http://apache.org/xml/properties/internal/document-scanner"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 7
            java.lang.String r10 = "http://apache.org/xml/properties/internal/dtd-scanner"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 8
            java.lang.String r10 = "http://apache.org/xml/properties/internal/validator/dtd"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 9
            java.lang.String r10 = "http://apache.org/xml/properties/internal/datatype-validator-factory"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 10
            java.lang.String r10 = "http://apache.org/xml/properties/internal/validation-manager"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 11
            java.lang.String r10 = "http://xml.org/sax/properties/xml-string"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 12
            java.lang.String r10 = "http://apache.org/xml/properties/internal/grammar-pool"
            r8[r9] = r10
            r5 = r7
            r7 = r0
            r8 = r5
            r7.addRecognizedProperties(r8)
            r7 = r1
            if (r7 != 0) goto L_0x0191
            org.apache.xerces.util.SymbolTable r7 = new org.apache.xerces.util.SymbolTable
            r11 = r7
            r7 = r11
            r8 = r11
            r8.<init>()
            r1 = r7
        L_0x0191:
            r7 = r0
            r8 = r1
            r7.fSymbolTable = r8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/symbol-table"
            r9 = r0
            org.apache.xerces.util.SymbolTable r9 = r9.fSymbolTable
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            r8 = r2
            r7.fGrammarPool = r8
            r7 = r0
            org.apache.xerces.xni.grammars.XMLGrammarPool r7 = r7.fGrammarPool
            if (r7 == 0) goto L_0x01b8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/grammar-pool"
            r9 = r0
            org.apache.xerces.xni.grammars.XMLGrammarPool r9 = r9.fGrammarPool
            java.lang.Object r7 = r7.put(r8, r9)
        L_0x01b8:
            r7 = r0
            org.apache.xerces.impl.XMLEntityManager r8 = new org.apache.xerces.impl.XMLEntityManager
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fEntityManager = r8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/entity-manager"
            r9 = r0
            org.apache.xerces.impl.XMLEntityManager r9 = r9.fEntityManager
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.XMLEntityManager r8 = r8.fEntityManager
            r7.addCommonComponent(r8)
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r8 = new org.apache.xerces.impl.XMLErrorReporter
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fErrorReporter = r8
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r7 = r7.fErrorReporter
            r8 = r0
            org.apache.xerces.impl.XMLEntityManager r8 = r8.fEntityManager
            org.apache.xerces.impl.XMLEntityScanner r8 = r8.getEntityScanner()
            r7.setDocumentLocator(r8)
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/error-reporter"
            r9 = r0
            org.apache.xerces.impl.XMLErrorReporter r9 = r9.fErrorReporter
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.XMLErrorReporter r8 = r8.fErrorReporter
            r7.addCommonComponent(r8)
            r7 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r8 = new org.apache.xerces.impl.XMLNSDocumentScannerImpl
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fNamespaceScanner = r8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/document-scanner"
            r9 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r9 = r9.fNamespaceScanner
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r8 = r8.fNamespaceScanner
            r7.addComponent(r8)
            r7 = r0
            org.apache.xerces.impl.XMLDTDScannerImpl r8 = new org.apache.xerces.impl.XMLDTDScannerImpl
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fDTDScanner = r8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/dtd-scanner"
            r9 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r9 = r9.fDTDScanner
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r8 = r8.fDTDScanner
            org.apache.xerces.xni.parser.XMLComponent r8 = (org.apache.xerces.xni.parser.XMLComponent) r8
            r7.addComponent(r8)
            r7 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r8 = org.apache.xerces.impl.dv.DTDDVFactory.getInstance()
            r7.fDatatypeValidatorFactory = r8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/datatype-validator-factory"
            r9 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r9 = r9.fDatatypeValidatorFactory
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            org.apache.xerces.impl.validation.ValidationManager r8 = new org.apache.xerces.impl.validation.ValidationManager
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fValidationManager = r8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/validation-manager"
            r9 = r0
            org.apache.xerces.impl.validation.ValidationManager r9 = r9.fValidationManager
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            org.apache.xerces.impl.XMLVersionDetector r8 = new org.apache.xerces.impl.XMLVersionDetector
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fVersionDetector = r8
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r7 = r7.fErrorReporter
            java.lang.String r8 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            org.apache.xerces.util.MessageFormatter r7 = r7.getMessageFormatter(r8)
            if (r7 != 0) goto L_0x02a3
            org.apache.xerces.impl.msg.XMLMessageFormatter r7 = new org.apache.xerces.impl.msg.XMLMessageFormatter
            r11 = r7
            r7 = r11
            r8 = r11
            r8.<init>()
            r6 = r7
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r7 = r7.fErrorReporter
            java.lang.String r8 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            r9 = r6
            r7.putMessageFormatter(r8, r9)
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r7 = r7.fErrorReporter
            java.lang.String r8 = "http://www.w3.org/TR/1999/REC-xml-names-19990114"
            r9 = r6
            r7.putMessageFormatter(r8, r9)
        L_0x02a3:
            r7 = r0
            java.util.Locale r8 = java.util.Locale.getDefault()     // Catch:{ XNIException -> 0x02b0 }
            r7.setLocale(r8)     // Catch:{ XNIException -> 0x02b0 }
        L_0x02ab:
            r7 = r0
            r8 = 0
            r7.fConfigUpdated = r8
            return
        L_0x02b0:
            r7 = move-exception
            r6 = r7
            goto L_0x02ab
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.XML11NonValidatingConfiguration.<init>(org.apache.xerces.util.SymbolTable, org.apache.xerces.xni.grammars.XMLGrammarPool, org.apache.xerces.xni.parser.XMLComponentManager):void");
    }

    private void initXML11Components() {
        XML11DTDScannerImpl xML11DTDScannerImpl;
        XML11NSDocumentScannerImpl xML11NSDocumentScannerImpl;
        if (!this.f11Initialized) {
            this.fXML11DatatypeFactory = DTDDVFactory.getInstance(XML11_DATATYPE_VALIDATOR_FACTORY);
            new XML11DTDScannerImpl();
            this.fXML11DTDScanner = xML11DTDScannerImpl;
            addXML11Component(this.fXML11DTDScanner);
            new XML11NSDocumentScannerImpl();
            this.fXML11NSDocScanner = xML11NSDocumentScannerImpl;
            addXML11Component(this.fXML11NSDocScanner);
            this.f11Initialized = true;
        }
    }

    /* access modifiers changed from: protected */
    public void addCommonComponent(XMLComponent xMLComponent) {
        XMLComponent xMLComponent2 = xMLComponent;
        if (!this.fCommonComponents.contains(xMLComponent2)) {
            boolean add = this.fCommonComponents.add(xMLComponent2);
            addRecognizedParamsAndSetDefaults(xMLComponent2);
        }
    }

    /* access modifiers changed from: protected */
    public void addComponent(XMLComponent xMLComponent) {
        XMLComponent xMLComponent2 = xMLComponent;
        if (!this.fComponents.contains(xMLComponent2)) {
            boolean add = this.fComponents.add(xMLComponent2);
            addRecognizedParamsAndSetDefaults(xMLComponent2);
        }
    }

    /* access modifiers changed from: protected */
    public void addRecognizedParamsAndSetDefaults(XMLComponent xMLComponent) {
        XMLComponent xMLComponent2 = xMLComponent;
        String[] recognizedFeatures = xMLComponent2.getRecognizedFeatures();
        addRecognizedFeatures(recognizedFeatures);
        String[] recognizedProperties = xMLComponent2.getRecognizedProperties();
        addRecognizedProperties(recognizedProperties);
        if (recognizedFeatures != null) {
            for (int i = 0; i < recognizedFeatures.length; i++) {
                String str = recognizedFeatures[i];
                Boolean featureDefault = xMLComponent2.getFeatureDefault(str);
                if (featureDefault != null && !this.fFeatures.containsKey(str)) {
                    Object put = this.fFeatures.put(str, featureDefault);
                    this.fConfigUpdated = true;
                }
            }
        }
        if (recognizedProperties != null) {
            for (int i2 = 0; i2 < recognizedProperties.length; i2++) {
                String str2 = recognizedProperties[i2];
                Object propertyDefault = xMLComponent2.getPropertyDefault(str2);
                if (propertyDefault != null && !this.fProperties.containsKey(str2)) {
                    Object put2 = this.fProperties.put(str2, propertyDefault);
                    this.fConfigUpdated = true;
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void addXML11Component(XMLComponent xMLComponent) {
        XMLComponent xMLComponent2 = xMLComponent;
        if (!this.fXML11Components.contains(xMLComponent2)) {
            boolean add = this.fXML11Components.add(xMLComponent2);
            addRecognizedParamsAndSetDefaults(xMLComponent2);
        }
    }

    /* access modifiers changed from: protected */
    public void checkFeature(String str) throws XMLConfigurationException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        String str2 = str;
        if (str2.startsWith("http://apache.org/xml/features/")) {
            int length = str2.length() - "http://apache.org/xml/features/".length();
            if (length == "validation/dynamic".length() && str2.endsWith("validation/dynamic")) {
                return;
            }
            if (length == "validation/default-attribute-values".length() && str2.endsWith("validation/default-attribute-values")) {
                Throwable th5 = th4;
                new XMLConfigurationException(1, str2);
                throw th5;
            } else if (length == "validation/validate-content-models".length() && str2.endsWith("validation/validate-content-models")) {
                Throwable th6 = th3;
                new XMLConfigurationException(1, str2);
                throw th6;
            } else if (length == "nonvalidating/load-dtd-grammar".length() && str2.endsWith("nonvalidating/load-dtd-grammar")) {
                return;
            } else {
                if (length == "nonvalidating/load-external-dtd".length() && str2.endsWith("nonvalidating/load-external-dtd")) {
                    return;
                }
                if (length == "validation/validate-datatypes".length() && str2.endsWith("validation/validate-datatypes")) {
                    Throwable th7 = th2;
                    new XMLConfigurationException(1, str2);
                    throw th7;
                } else if (length == "internal/parser-settings".length() && str2.endsWith("internal/parser-settings")) {
                    Throwable th8 = th;
                    new XMLConfigurationException(1, str2);
                    throw th8;
                }
            }
        }
        super.checkFeature(str2);
    }

    /* access modifiers changed from: protected */
    public void checkProperty(String str) throws XMLConfigurationException {
        Throwable th;
        String str2 = str;
        if (str2.startsWith("http://apache.org/xml/properties/") && str2.length() - "http://apache.org/xml/properties/".length() == "internal/dtd-scanner".length() && str2.endsWith("internal/dtd-scanner")) {
            return;
        }
        if (str2.startsWith("http://java.sun.com/xml/jaxp/properties/") && str2.length() - "http://java.sun.com/xml/jaxp/properties/".length() == "schemaSource".length() && str2.endsWith("schemaSource")) {
            return;
        }
        if (!str2.startsWith("http://xml.org/sax/properties/") || str2.length() - "http://xml.org/sax/properties/".length() != "xml-string".length() || !str2.endsWith("xml-string")) {
            super.checkProperty(str2);
            return;
        }
        Throwable th2 = th;
        new XMLConfigurationException(1, str2);
        throw th2;
    }

    public void cleanup() {
        this.fEntityManager.closeReaders();
    }

    /* access modifiers changed from: protected */
    public void configurePipeline() {
        XMLDocumentScannerImpl xMLDocumentScannerImpl;
        if (this.fCurrentDVFactory != this.fDatatypeValidatorFactory) {
            this.fCurrentDVFactory = this.fDatatypeValidatorFactory;
            setProperty(DATATYPE_VALIDATOR_FACTORY, this.fCurrentDVFactory);
        }
        if (this.fCurrentDTDScanner != this.fDTDScanner) {
            this.fCurrentDTDScanner = this.fDTDScanner;
            setProperty(DTD_SCANNER, this.fCurrentDTDScanner);
        }
        this.fDTDScanner.setDTDHandler(this.fDTDHandler);
        this.fDTDScanner.setDTDContentModelHandler(this.fDTDContentModelHandler);
        if (this.fFeatures.get(NAMESPACES) == Boolean.TRUE) {
            if (this.fCurrentScanner != this.fNamespaceScanner) {
                this.fCurrentScanner = this.fNamespaceScanner;
                setProperty(DOCUMENT_SCANNER, this.fNamespaceScanner);
            }
            this.fNamespaceScanner.setDTDValidator((XMLDTDValidatorFilter) null);
            this.fNamespaceScanner.setDocumentHandler(this.fDocumentHandler);
            if (this.fDocumentHandler != null) {
                this.fDocumentHandler.setDocumentSource(this.fNamespaceScanner);
            }
            this.fLastComponent = this.fNamespaceScanner;
            return;
        }
        if (this.fNonNSScanner == null) {
            new XMLDocumentScannerImpl();
            this.fNonNSScanner = xMLDocumentScannerImpl;
            addComponent(this.fNonNSScanner);
        }
        if (this.fCurrentScanner != this.fNonNSScanner) {
            this.fCurrentScanner = this.fNonNSScanner;
            setProperty(DOCUMENT_SCANNER, this.fNonNSScanner);
        }
        this.fNonNSScanner.setDocumentHandler(this.fDocumentHandler);
        if (this.fDocumentHandler != null) {
            this.fDocumentHandler.setDocumentSource(this.fNonNSScanner);
        }
        this.fLastComponent = this.fNonNSScanner;
    }

    /* access modifiers changed from: protected */
    public void configureXML11Pipeline() {
        XML11DocumentScannerImpl xML11DocumentScannerImpl;
        if (this.fCurrentDVFactory != this.fXML11DatatypeFactory) {
            this.fCurrentDVFactory = this.fXML11DatatypeFactory;
            setProperty(DATATYPE_VALIDATOR_FACTORY, this.fCurrentDVFactory);
        }
        if (this.fCurrentDTDScanner != this.fXML11DTDScanner) {
            this.fCurrentDTDScanner = this.fXML11DTDScanner;
            setProperty(DTD_SCANNER, this.fCurrentDTDScanner);
        }
        this.fXML11DTDScanner.setDTDHandler(this.fDTDHandler);
        this.fXML11DTDScanner.setDTDContentModelHandler(this.fDTDContentModelHandler);
        if (this.fFeatures.get(NAMESPACES) == Boolean.TRUE) {
            if (this.fCurrentScanner != this.fXML11NSDocScanner) {
                this.fCurrentScanner = this.fXML11NSDocScanner;
                setProperty(DOCUMENT_SCANNER, this.fXML11NSDocScanner);
            }
            this.fXML11NSDocScanner.setDTDValidator((XMLDTDValidatorFilter) null);
            this.fXML11NSDocScanner.setDocumentHandler(this.fDocumentHandler);
            if (this.fDocumentHandler != null) {
                this.fDocumentHandler.setDocumentSource(this.fXML11NSDocScanner);
            }
            this.fLastComponent = this.fXML11NSDocScanner;
            return;
        }
        if (this.fXML11DocScanner == null) {
            new XML11DocumentScannerImpl();
            this.fXML11DocScanner = xML11DocumentScannerImpl;
            addXML11Component(this.fXML11DocScanner);
        }
        if (this.fCurrentScanner != this.fXML11DocScanner) {
            this.fCurrentScanner = this.fXML11DocScanner;
            setProperty(DOCUMENT_SCANNER, this.fXML11DocScanner);
        }
        this.fXML11DocScanner.setDocumentHandler(this.fDocumentHandler);
        if (this.fDocumentHandler != null) {
            this.fDocumentHandler.setDocumentSource(this.fXML11DocScanner);
        }
        this.fLastComponent = this.fXML11DocScanner;
    }

    public XMLDTDContentModelHandler getDTDContentModelHandler() {
        return this.fDTDContentModelHandler;
    }

    public XMLDTDHandler getDTDHandler() {
        return this.fDTDHandler;
    }

    public XMLDocumentHandler getDocumentHandler() {
        return this.fDocumentHandler;
    }

    public XMLEntityResolver getEntityResolver() {
        return (XMLEntityResolver) this.fProperties.get(ENTITY_RESOLVER);
    }

    public XMLErrorHandler getErrorHandler() {
        return (XMLErrorHandler) this.fProperties.get(ERROR_HANDLER);
    }

    public boolean getFeature(String str) throws XMLConfigurationException {
        String str2 = str;
        return str2.equals("http://apache.org/xml/features/internal/parser-settings") ? this.fConfigUpdated : super.getFeature(str2);
    }

    public Locale getLocale() {
        return this.fLocale;
    }

    public void parse(XMLInputSource xMLInputSource) throws XNIException, IOException {
        Throwable th;
        Throwable th2;
        XMLInputSource xMLInputSource2 = xMLInputSource;
        if (this.fParseInProgress) {
            Throwable th3 = th2;
            new XNIException("FWK005 parse may not be called while parsing.");
            throw th3;
        }
        this.fParseInProgress = true;
        try {
            setInputSource(xMLInputSource2);
            boolean parse = parse(true);
            this.fParseInProgress = false;
            cleanup();
        } catch (XNIException e) {
            throw e;
        } catch (IOException e2) {
            throw e2;
        } catch (RuntimeException e3) {
            throw e3;
        } catch (Exception e4) {
            Exception exc = e4;
            Throwable th4 = th;
            new XNIException(exc);
            throw th4;
        } catch (Throwable th5) {
            Throwable th6 = th5;
            this.fParseInProgress = false;
            cleanup();
            throw th6;
        }
    }

    public boolean parse(boolean z) throws XNIException, IOException {
        Throwable th;
        Throwable th2;
        boolean z2 = z;
        if (this.fInputSource != null) {
            try {
                this.fValidationManager.reset();
                this.fVersionDetector.reset(this);
                resetCommon();
                short determineDocVersion = this.fVersionDetector.determineDocVersion(this.fInputSource);
                if (determineDocVersion == 1) {
                    configurePipeline();
                    reset();
                } else if (determineDocVersion != 2) {
                    return false;
                } else {
                    initXML11Components();
                    configureXML11Pipeline();
                    resetXML11();
                }
                this.fConfigUpdated = false;
                this.fVersionDetector.startDocumentParsing(this.fCurrentScanner, determineDocVersion);
                this.fInputSource = null;
            } catch (XNIException e) {
                throw e;
            } catch (IOException e2) {
                throw e2;
            } catch (RuntimeException e3) {
                throw e3;
            } catch (Exception e4) {
                Exception exc = e4;
                Throwable th3 = th2;
                new XNIException(exc);
                throw th3;
            }
        }
        try {
            return this.fCurrentScanner.scanDocument(z2);
        } catch (XNIException e5) {
            throw e5;
        } catch (IOException e6) {
            throw e6;
        } catch (RuntimeException e7) {
            throw e7;
        } catch (Exception e8) {
            Exception exc2 = e8;
            Throwable th4 = th;
            new XNIException(exc2);
            throw th4;
        }
    }

    /* access modifiers changed from: protected */
    public void reset() throws XNIException {
        int size = this.fComponents.size();
        for (int i = 0; i < size; i++) {
            ((XMLComponent) this.fComponents.get(i)).reset(this);
        }
    }

    /* access modifiers changed from: protected */
    public void resetCommon() throws XNIException {
        int size = this.fCommonComponents.size();
        for (int i = 0; i < size; i++) {
            ((XMLComponent) this.fCommonComponents.get(i)).reset(this);
        }
    }

    /* access modifiers changed from: protected */
    public void resetXML11() throws XNIException {
        int size = this.fXML11Components.size();
        for (int i = 0; i < size; i++) {
            ((XMLComponent) this.fXML11Components.get(i)).reset(this);
        }
    }

    public void setDTDContentModelHandler(XMLDTDContentModelHandler xMLDTDContentModelHandler) {
        XMLDTDContentModelHandler xMLDTDContentModelHandler2 = xMLDTDContentModelHandler;
        this.fDTDContentModelHandler = xMLDTDContentModelHandler2;
    }

    public void setDTDHandler(XMLDTDHandler xMLDTDHandler) {
        XMLDTDHandler xMLDTDHandler2 = xMLDTDHandler;
        this.fDTDHandler = xMLDTDHandler2;
    }

    public void setDocumentHandler(XMLDocumentHandler xMLDocumentHandler) {
        this.fDocumentHandler = xMLDocumentHandler;
        if (this.fLastComponent != null) {
            this.fLastComponent.setDocumentHandler(this.fDocumentHandler);
            if (this.fDocumentHandler != null) {
                this.fDocumentHandler.setDocumentSource(this.fLastComponent);
            }
        }
    }

    public void setEntityResolver(XMLEntityResolver xMLEntityResolver) {
        Object put = this.fProperties.put(ENTITY_RESOLVER, xMLEntityResolver);
    }

    public void setErrorHandler(XMLErrorHandler xMLErrorHandler) {
        Object put = this.fProperties.put(ERROR_HANDLER, xMLErrorHandler);
    }

    public void setFeature(String str, boolean z) throws XMLConfigurationException {
        String str2 = str;
        boolean z2 = z;
        this.fConfigUpdated = true;
        int size = this.fComponents.size();
        for (int i = 0; i < size; i++) {
            ((XMLComponent) this.fComponents.get(i)).setFeature(str2, z2);
        }
        int size2 = this.fCommonComponents.size();
        for (int i2 = 0; i2 < size2; i2++) {
            ((XMLComponent) this.fCommonComponents.get(i2)).setFeature(str2, z2);
        }
        int size3 = this.fXML11Components.size();
        for (int i3 = 0; i3 < size3; i3++) {
            try {
                ((XMLComponent) this.fXML11Components.get(i3)).setFeature(str2, z2);
            } catch (Exception e) {
                Exception exc = e;
            }
        }
        super.setFeature(str2, z2);
    }

    public void setInputSource(XMLInputSource xMLInputSource) throws XMLConfigurationException, IOException {
        XMLInputSource xMLInputSource2 = xMLInputSource;
        this.fInputSource = xMLInputSource2;
    }

    public void setLocale(Locale locale) throws XNIException {
        Locale locale2 = locale;
        this.fLocale = locale2;
        this.fErrorReporter.setLocale(locale2);
    }

    public void setProperty(String str, Object obj) throws XMLConfigurationException {
        String str2 = str;
        Object obj2 = obj;
        this.fConfigUpdated = true;
        int size = this.fComponents.size();
        for (int i = 0; i < size; i++) {
            ((XMLComponent) this.fComponents.get(i)).setProperty(str2, obj2);
        }
        int size2 = this.fCommonComponents.size();
        for (int i2 = 0; i2 < size2; i2++) {
            ((XMLComponent) this.fCommonComponents.get(i2)).setProperty(str2, obj2);
        }
        int size3 = this.fXML11Components.size();
        for (int i3 = 0; i3 < size3; i3++) {
            try {
                ((XMLComponent) this.fXML11Components.get(i3)).setProperty(str2, obj2);
            } catch (Exception e) {
                Exception exc = e;
            }
        }
        super.setProperty(str2, obj2);
    }
}
