package org.apache.xerces.parsers;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;
import org.apache.xerces.impl.XMLEntityManager;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.Grammar;
import org.apache.xerces.xni.grammars.XMLGrammarDescription;
import org.apache.xerces.xni.grammars.XMLGrammarLoader;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.apache.xerces.xni.parser.XMLInputSource;

public class XMLGrammarPreparser {
    private static final String CONTINUE_AFTER_FATAL_ERROR = "http://apache.org/xml/features/continue-after-fatal-error";
    protected static final String ENTITY_RESOLVER = "http://apache.org/xml/properties/internal/entity-resolver";
    protected static final String ERROR_HANDLER = "http://apache.org/xml/properties/internal/error-handler";
    protected static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
    protected static final String GRAMMAR_POOL = "http://apache.org/xml/properties/internal/grammar-pool";
    private static final Hashtable KNOWN_LOADERS;
    private static final String[] RECOGNIZED_PROPERTIES;
    protected static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    protected XMLEntityResolver fEntityResolver;
    protected final XMLErrorReporter fErrorReporter;
    protected XMLGrammarPool fGrammarPool;
    private final Hashtable fLoaders;
    protected Locale fLocale;
    private int fModCount;
    protected final SymbolTable fSymbolTable;

    static class XMLGrammarLoaderContainer {
        public final XMLGrammarLoader loader;
        public int modCount = 0;

        public XMLGrammarLoaderContainer(XMLGrammarLoader xMLGrammarLoader) {
            this.loader = xMLGrammarLoader;
        }
    }

    static {
        Hashtable hashtable;
        new Hashtable();
        KNOWN_LOADERS = hashtable;
        Object put = KNOWN_LOADERS.put("http://www.w3.org/2001/XMLSchema", "org.apache.xerces.impl.xs.XMLSchemaLoader");
        Object put2 = KNOWN_LOADERS.put(XMLGrammarDescription.XML_DTD, "org.apache.xerces.impl.dtd.XMLDTDLoader");
        String[] strArr = new String[5];
        strArr[0] = SYMBOL_TABLE;
        String[] strArr2 = strArr;
        strArr2[1] = ERROR_REPORTER;
        String[] strArr3 = strArr2;
        strArr3[2] = ERROR_HANDLER;
        String[] strArr4 = strArr3;
        strArr4[3] = ENTITY_RESOLVER;
        String[] strArr5 = strArr4;
        strArr5[4] = GRAMMAR_POOL;
        RECOGNIZED_PROPERTIES = strArr5;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XMLGrammarPreparser() {
        /*
            r5 = this;
            r0 = r5
            r1 = r0
            org.apache.xerces.util.SymbolTable r2 = new org.apache.xerces.util.SymbolTable
            r4 = r2
            r2 = r4
            r3 = r4
            r3.<init>()
            r1.<init>(r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.XMLGrammarPreparser.<init>():void");
    }

    public XMLGrammarPreparser(SymbolTable symbolTable) {
        Hashtable hashtable;
        XMLErrorReporter xMLErrorReporter;
        XMLEntityResolver xMLEntityResolver;
        this.fModCount = 1;
        this.fSymbolTable = symbolTable;
        new Hashtable();
        this.fLoaders = hashtable;
        new XMLErrorReporter();
        this.fErrorReporter = xMLErrorReporter;
        setLocale(Locale.getDefault());
        new XMLEntityManager();
        this.fEntityResolver = xMLEntityResolver;
    }

    private void clearModCounts() {
        Enumeration elements = this.fLoaders.elements();
        while (elements.hasMoreElements()) {
            ((XMLGrammarLoaderContainer) elements.nextElement()).modCount = 0;
        }
        this.fModCount = 1;
    }

    public XMLEntityResolver getEntityResolver() {
        return this.fEntityResolver;
    }

    public XMLErrorHandler getErrorHandler() {
        return this.fErrorReporter.getErrorHandler();
    }

    public boolean getFeature(String str, String str2) {
        return ((XMLGrammarLoaderContainer) this.fLoaders.get(str)).loader.getFeature(str2);
    }

    public XMLGrammarPool getGrammarPool() {
        return this.fGrammarPool;
    }

    public XMLGrammarLoader getLoader(String str) {
        XMLGrammarLoaderContainer xMLGrammarLoaderContainer = (XMLGrammarLoaderContainer) this.fLoaders.get(str);
        return xMLGrammarLoaderContainer != null ? xMLGrammarLoaderContainer.loader : null;
    }

    public Locale getLocale() {
        return this.fLocale;
    }

    public Object getProperty(String str, String str2) {
        return ((XMLGrammarLoaderContainer) this.fLoaders.get(str)).loader.getProperty(str2);
    }

    public Grammar preparseGrammar(String str, XMLInputSource xMLInputSource) throws XNIException, IOException {
        String str2 = str;
        XMLInputSource xMLInputSource2 = xMLInputSource;
        if (!this.fLoaders.containsKey(str2)) {
            return null;
        }
        XMLGrammarLoaderContainer xMLGrammarLoaderContainer = (XMLGrammarLoaderContainer) this.fLoaders.get(str2);
        XMLGrammarLoader xMLGrammarLoader = xMLGrammarLoaderContainer.loader;
        if (xMLGrammarLoaderContainer.modCount != this.fModCount) {
            xMLGrammarLoader.setProperty(SYMBOL_TABLE, this.fSymbolTable);
            xMLGrammarLoader.setProperty(ENTITY_RESOLVER, this.fEntityResolver);
            xMLGrammarLoader.setProperty(ERROR_REPORTER, this.fErrorReporter);
            if (this.fGrammarPool != null) {
                try {
                    xMLGrammarLoader.setProperty(GRAMMAR_POOL, this.fGrammarPool);
                } catch (Exception e) {
                    Exception exc = e;
                }
            }
            xMLGrammarLoaderContainer.modCount = this.fModCount;
        }
        return xMLGrammarLoader.loadGrammar(xMLInputSource2);
    }

    public boolean registerPreparser(String str, XMLGrammarLoader xMLGrammarLoader) {
        Object obj;
        Object obj2;
        String str2 = str;
        XMLGrammarLoader xMLGrammarLoader2 = xMLGrammarLoader;
        if (xMLGrammarLoader2 != null) {
            new XMLGrammarLoaderContainer(xMLGrammarLoader2);
            Object put = this.fLoaders.put(str2, obj);
            return true;
        } else if (!KNOWN_LOADERS.containsKey(str2)) {
            return false;
        } else {
            String str3 = (String) KNOWN_LOADERS.get(str2);
            try {
                new XMLGrammarLoaderContainer((XMLGrammarLoader) ObjectFactory.newInstance(str3, ObjectFactory.findClassLoader(), true));
                Object put2 = this.fLoaders.put(str2, obj2);
                return true;
            } catch (Exception e) {
                Exception exc = e;
                return false;
            }
        }
    }

    public void setEntityResolver(XMLEntityResolver xMLEntityResolver) {
        XMLEntityResolver xMLEntityResolver2 = xMLEntityResolver;
        if (this.fEntityResolver != xMLEntityResolver2) {
            int i = this.fModCount + 1;
            int i2 = i;
            this.fModCount = i;
            if (i2 < 0) {
                clearModCounts();
            }
            this.fEntityResolver = xMLEntityResolver2;
        }
    }

    public void setErrorHandler(XMLErrorHandler xMLErrorHandler) {
        this.fErrorReporter.setProperty(ERROR_HANDLER, xMLErrorHandler);
    }

    public void setFeature(String str, boolean z) {
        String str2 = str;
        boolean z2 = z;
        Enumeration elements = this.fLoaders.elements();
        while (elements.hasMoreElements()) {
            try {
                ((XMLGrammarLoaderContainer) elements.nextElement()).loader.setFeature(str2, z2);
            } catch (Exception e) {
                Exception exc = e;
            }
        }
        if (str2.equals(CONTINUE_AFTER_FATAL_ERROR)) {
            this.fErrorReporter.setFeature(CONTINUE_AFTER_FATAL_ERROR, z2);
        }
    }

    public void setGrammarPool(XMLGrammarPool xMLGrammarPool) {
        XMLGrammarPool xMLGrammarPool2 = xMLGrammarPool;
        if (this.fGrammarPool != xMLGrammarPool2) {
            int i = this.fModCount + 1;
            int i2 = i;
            this.fModCount = i;
            if (i2 < 0) {
                clearModCounts();
            }
            this.fGrammarPool = xMLGrammarPool2;
        }
    }

    public void setLocale(Locale locale) {
        Locale locale2 = locale;
        this.fLocale = locale2;
        this.fErrorReporter.setLocale(locale2);
    }

    public void setProperty(String str, Object obj) {
        String str2 = str;
        Object obj2 = obj;
        Enumeration elements = this.fLoaders.elements();
        while (elements.hasMoreElements()) {
            try {
                ((XMLGrammarLoaderContainer) elements.nextElement()).loader.setProperty(str2, obj2);
            } catch (Exception e) {
                Exception exc = e;
            }
        }
    }
}
