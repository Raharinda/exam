package org.apache.xerces.parsers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import org.apache.xerces.util.ParserConfigurationSettings;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.XMLDTDContentModelHandler;
import org.apache.xerces.xni.XMLDTDHandler;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLComponent;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLDocumentSource;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLParserConfiguration;

public abstract class BasicParserConfiguration extends ParserConfigurationSettings implements XMLParserConfiguration {
    protected static final String ENTITY_RESOLVER = "http://apache.org/xml/properties/internal/entity-resolver";
    protected static final String ERROR_HANDLER = "http://apache.org/xml/properties/internal/error-handler";
    protected static final String EXTERNAL_GENERAL_ENTITIES = "http://xml.org/sax/features/external-general-entities";
    protected static final String EXTERNAL_PARAMETER_ENTITIES = "http://xml.org/sax/features/external-parameter-entities";
    protected static final String NAMESPACES = "http://xml.org/sax/features/namespaces";
    protected static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    protected static final String VALIDATION = "http://xml.org/sax/features/validation";
    protected static final String XML_STRING = "http://xml.org/sax/properties/xml-string";
    protected ArrayList fComponents;
    protected XMLDTDContentModelHandler fDTDContentModelHandler;
    protected XMLDTDHandler fDTDHandler;
    protected XMLDocumentHandler fDocumentHandler;
    protected XMLDocumentSource fLastComponent;
    protected Locale fLocale;
    protected SymbolTable fSymbolTable;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    protected BasicParserConfiguration() {
        this((SymbolTable) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    protected BasicParserConfiguration(SymbolTable symbolTable) {
        this(symbolTable, (XMLComponentManager) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected BasicParserConfiguration(SymbolTable symbolTable, XMLComponentManager xMLComponentManager) {
        super(xMLComponentManager);
        ArrayList arrayList;
        ArrayList arrayList2;
        ArrayList arrayList3;
        HashMap hashMap;
        HashMap hashMap2;
        SymbolTable symbolTable2;
        SymbolTable symbolTable3 = symbolTable;
        new ArrayList();
        this.fComponents = arrayList;
        new ArrayList();
        this.fRecognizedFeatures = arrayList2;
        new ArrayList();
        this.fRecognizedProperties = arrayList3;
        new HashMap();
        this.fFeatures = hashMap;
        new HashMap();
        this.fProperties = hashMap2;
        String[] strArr = new String[5];
        strArr[0] = "http://apache.org/xml/features/internal/parser-settings";
        String[] strArr2 = strArr;
        strArr2[1] = VALIDATION;
        String[] strArr3 = strArr2;
        strArr3[2] = NAMESPACES;
        String[] strArr4 = strArr3;
        strArr4[3] = EXTERNAL_GENERAL_ENTITIES;
        String[] strArr5 = strArr4;
        strArr5[4] = EXTERNAL_PARAMETER_ENTITIES;
        addRecognizedFeatures(strArr5);
        Object put = this.fFeatures.put("http://apache.org/xml/features/internal/parser-settings", Boolean.TRUE);
        Object put2 = this.fFeatures.put(VALIDATION, Boolean.FALSE);
        Object put3 = this.fFeatures.put(NAMESPACES, Boolean.TRUE);
        Object put4 = this.fFeatures.put(EXTERNAL_GENERAL_ENTITIES, Boolean.TRUE);
        Object put5 = this.fFeatures.put(EXTERNAL_PARAMETER_ENTITIES, Boolean.TRUE);
        String[] strArr6 = new String[4];
        strArr6[0] = XML_STRING;
        String[] strArr7 = strArr6;
        strArr7[1] = SYMBOL_TABLE;
        String[] strArr8 = strArr7;
        strArr8[2] = ERROR_HANDLER;
        String[] strArr9 = strArr8;
        strArr9[3] = ENTITY_RESOLVER;
        addRecognizedProperties(strArr9);
        if (symbolTable3 == null) {
            new SymbolTable();
            symbolTable3 = symbolTable2;
        }
        this.fSymbolTable = symbolTable3;
        Object put6 = this.fProperties.put(SYMBOL_TABLE, this.fSymbolTable);
    }

    /* access modifiers changed from: protected */
    public void addComponent(XMLComponent xMLComponent) {
        XMLComponent xMLComponent2 = xMLComponent;
        if (!this.fComponents.contains(xMLComponent2)) {
            boolean add = this.fComponents.add(xMLComponent2);
            String[] recognizedFeatures = xMLComponent2.getRecognizedFeatures();
            addRecognizedFeatures(recognizedFeatures);
            String[] recognizedProperties = xMLComponent2.getRecognizedProperties();
            addRecognizedProperties(recognizedProperties);
            if (recognizedFeatures != null) {
                for (int i = 0; i < recognizedFeatures.length; i++) {
                    String str = recognizedFeatures[i];
                    Boolean featureDefault = xMLComponent2.getFeatureDefault(str);
                    if (featureDefault != null) {
                        super.setFeature(str, featureDefault.booleanValue());
                    }
                }
            }
            if (recognizedProperties != null) {
                for (int i2 = 0; i2 < recognizedProperties.length; i2++) {
                    String str2 = recognizedProperties[i2];
                    Object propertyDefault = xMLComponent2.getPropertyDefault(str2);
                    if (propertyDefault != null) {
                        super.setProperty(str2, propertyDefault);
                    }
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void checkFeature(String str) throws XMLConfigurationException {
        Throwable th;
        String str2 = str;
        if (!str2.startsWith("http://apache.org/xml/features/") || str2.length() - "http://apache.org/xml/features/".length() != "internal/parser-settings".length() || !str2.endsWith("internal/parser-settings")) {
            super.checkFeature(str2);
            return;
        }
        Throwable th2 = th;
        new XMLConfigurationException(1, str2);
        throw th2;
    }

    /* access modifiers changed from: protected */
    public void checkProperty(String str) throws XMLConfigurationException {
        Throwable th;
        String str2 = str;
        if (!str2.startsWith("http://xml.org/sax/properties/") || str2.length() - "http://xml.org/sax/properties/".length() != "xml-string".length() || !str2.endsWith("xml-string")) {
            super.checkProperty(str2);
            return;
        }
        Throwable th2 = th;
        new XMLConfigurationException(1, str2);
        throw th2;
    }

    public XMLDTDContentModelHandler getDTDContentModelHandler() {
        return this.fDTDContentModelHandler;
    }

    public XMLDTDHandler getDTDHandler() {
        return this.fDTDHandler;
    }

    public XMLDocumentHandler getDocumentHandler() {
        return this.fDocumentHandler;
    }

    public XMLEntityResolver getEntityResolver() {
        return (XMLEntityResolver) this.fProperties.get(ENTITY_RESOLVER);
    }

    public XMLErrorHandler getErrorHandler() {
        return (XMLErrorHandler) this.fProperties.get(ERROR_HANDLER);
    }

    public Locale getLocale() {
        return this.fLocale;
    }

    public abstract void parse(XMLInputSource xMLInputSource) throws XNIException, IOException;

    /* access modifiers changed from: protected */
    public void reset() throws XNIException {
        int size = this.fComponents.size();
        for (int i = 0; i < size; i++) {
            ((XMLComponent) this.fComponents.get(i)).reset(this);
        }
    }

    public void setDTDContentModelHandler(XMLDTDContentModelHandler xMLDTDContentModelHandler) {
        XMLDTDContentModelHandler xMLDTDContentModelHandler2 = xMLDTDContentModelHandler;
        this.fDTDContentModelHandler = xMLDTDContentModelHandler2;
    }

    public void setDTDHandler(XMLDTDHandler xMLDTDHandler) {
        XMLDTDHandler xMLDTDHandler2 = xMLDTDHandler;
        this.fDTDHandler = xMLDTDHandler2;
    }

    public void setDocumentHandler(XMLDocumentHandler xMLDocumentHandler) {
        this.fDocumentHandler = xMLDocumentHandler;
        if (this.fLastComponent != null) {
            this.fLastComponent.setDocumentHandler(this.fDocumentHandler);
            if (this.fDocumentHandler != null) {
                this.fDocumentHandler.setDocumentSource(this.fLastComponent);
            }
        }
    }

    public void setEntityResolver(XMLEntityResolver xMLEntityResolver) {
        Object put = this.fProperties.put(ENTITY_RESOLVER, xMLEntityResolver);
    }

    public void setErrorHandler(XMLErrorHandler xMLErrorHandler) {
        Object put = this.fProperties.put(ERROR_HANDLER, xMLErrorHandler);
    }

    public void setFeature(String str, boolean z) throws XMLConfigurationException {
        String str2 = str;
        boolean z2 = z;
        int size = this.fComponents.size();
        for (int i = 0; i < size; i++) {
            ((XMLComponent) this.fComponents.get(i)).setFeature(str2, z2);
        }
        super.setFeature(str2, z2);
    }

    public void setLocale(Locale locale) throws XNIException {
        Locale locale2 = locale;
        this.fLocale = locale2;
    }

    public void setProperty(String str, Object obj) throws XMLConfigurationException {
        String str2 = str;
        Object obj2 = obj;
        int size = this.fComponents.size();
        for (int i = 0; i < size; i++) {
            ((XMLComponent) this.fComponents.get(i)).setProperty(str2, obj2);
        }
        super.setProperty(str2, obj2);
    }
}
