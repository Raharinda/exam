package org.apache.xerces.parsers;

import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Stack;
import java.util.StringTokenizer;
import org.apache.xerces.dom.DOMErrorImpl;
import org.apache.xerces.dom.DOMMessageFormatter;
import org.apache.xerces.dom.DOMStringListImpl;
import org.apache.xerces.impl.Constants;
import org.apache.xerces.jaxp.JAXPConstants;
import org.apache.xerces.parsers.AbstractDOMParser;
import org.apache.xerces.util.DOMEntityResolverWrapper;
import org.apache.xerces.util.DOMErrorHandlerWrapper;
import org.apache.xerces.util.DOMUtil;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.util.XMLSymbols;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLDTDContentModelHandler;
import org.apache.xerces.xni.XMLDTDHandler;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLDTDContentModelSource;
import org.apache.xerces.xni.parser.XMLDTDSource;
import org.apache.xerces.xni.parser.XMLDocumentSource;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLParseException;
import org.apache.xerces.xni.parser.XMLParserConfiguration;
import org.w3c.dom.DOMConfiguration;
import org.w3c.dom.DOMErrorHandler;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMStringList;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.ls.LSException;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSParser;
import org.w3c.dom.ls.LSParserFilter;
import org.w3c.dom.ls.LSResourceResolver;

public class DOMParserImpl extends AbstractDOMParser implements LSParser, DOMConfiguration {
    protected static final boolean DEBUG = false;
    protected static final String DISALLOW_DOCTYPE_DECL_FEATURE = "http://apache.org/xml/features/disallow-doctype-decl";
    protected static final String DYNAMIC_VALIDATION = "http://apache.org/xml/features/validation/dynamic";
    protected static final String HONOUR_ALL_SCHEMALOCATIONS = "http://apache.org/xml/features/honour-all-schemaLocations";
    protected static final String NAMESPACES = "http://xml.org/sax/features/namespaces";
    protected static final String NAMESPACE_GROWTH = "http://apache.org/xml/features/namespace-growth";
    protected static final String NORMALIZE_DATA = "http://apache.org/xml/features/validation/schema/normalized-value";
    protected static final String PSVI_AUGMENT = "http://apache.org/xml/features/validation/schema/augment-psvi";
    protected static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    protected static final String TOLERATE_DUPLICATES = "http://apache.org/xml/features/internal/tolerate-duplicates";
    protected static final String VALIDATION_FEATURE = "http://xml.org/sax/features/validation";
    protected static final String XMLSCHEMA = "http://apache.org/xml/features/validation/schema";
    protected static final String XMLSCHEMA_FULL_CHECKING = "http://apache.org/xml/features/validation/schema-full-checking";
    private AbortHandler abortHandler;
    private boolean abortNow;
    private Thread currentThread;
    protected boolean fBusy;
    protected boolean fNamespaceDeclarations;
    private boolean fNullFilterInUse;
    private DOMStringList fRecognizedParameters;
    private String fSchemaLocation;
    protected String fSchemaType;

    /* renamed from: org.apache.xerces.parsers.DOMParserImpl$1  reason: invalid class name */
    class AnonymousClass1 {
    }

    private static final class AbortHandler implements XMLDocumentHandler, XMLDTDHandler, XMLDTDContentModelHandler {
        private XMLDocumentSource documentSource;
        private XMLDTDContentModelSource dtdContentSource;
        private XMLDTDSource dtdSource;

        private AbortHandler() {
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        AbortHandler(AnonymousClass1 r4) {
            this();
            AnonymousClass1 r1 = r4;
        }

        public void any(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void attributeDecl(String str, String str2, String str3, String[] strArr, String str4, XMLString xMLString, XMLString xMLString2, Augmentations augmentations) throws XNIException {
            String str5 = str;
            String str6 = str2;
            String str7 = str3;
            String[] strArr2 = strArr;
            String str8 = str4;
            XMLString xMLString3 = xMLString;
            XMLString xMLString4 = xMLString2;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void characters(XMLString xMLString, Augmentations augmentations) throws XNIException {
            XMLString xMLString2 = xMLString;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void comment(XMLString xMLString, Augmentations augmentations) throws XNIException {
            XMLString xMLString2 = xMLString;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void doctypeDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
            String str4 = str;
            String str5 = str2;
            String str6 = str3;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void element(String str, Augmentations augmentations) throws XNIException {
            String str2 = str;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void elementDecl(String str, String str2, Augmentations augmentations) throws XNIException {
            String str3 = str;
            String str4 = str2;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void empty(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void emptyElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
            QName qName2 = qName;
            XMLAttributes xMLAttributes2 = xMLAttributes;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void endAttlist(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void endCDATA(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void endConditional(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void endContentModel(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void endDTD(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void endDocument(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void endElement(QName qName, Augmentations augmentations) throws XNIException {
            QName qName2 = qName;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void endExternalSubset(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void endGeneralEntity(String str, Augmentations augmentations) throws XNIException {
            String str2 = str;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void endGroup(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void endParameterEntity(String str, Augmentations augmentations) throws XNIException {
            String str2 = str;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void externalEntityDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
            String str2 = str;
            XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public XMLDTDContentModelSource getDTDContentModelSource() {
            return this.dtdContentSource;
        }

        public XMLDTDSource getDTDSource() {
            return this.dtdSource;
        }

        public XMLDocumentSource getDocumentSource() {
            return this.documentSource;
        }

        public void ignorableWhitespace(XMLString xMLString, Augmentations augmentations) throws XNIException {
            XMLString xMLString2 = xMLString;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void ignoredCharacters(XMLString xMLString, Augmentations augmentations) throws XNIException {
            XMLString xMLString2 = xMLString;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void internalEntityDecl(String str, XMLString xMLString, XMLString xMLString2, Augmentations augmentations) throws XNIException {
            String str2 = str;
            XMLString xMLString3 = xMLString;
            XMLString xMLString4 = xMLString2;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void notationDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
            String str2 = str;
            XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void occurrence(short s, Augmentations augmentations) throws XNIException {
            short s2 = s;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void pcdata(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
            String str2 = str;
            XMLString xMLString2 = xMLString;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void separator(short s, Augmentations augmentations) throws XNIException {
            short s2 = s;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void setDTDContentModelSource(XMLDTDContentModelSource xMLDTDContentModelSource) {
            XMLDTDContentModelSource xMLDTDContentModelSource2 = xMLDTDContentModelSource;
            this.dtdContentSource = xMLDTDContentModelSource2;
        }

        public void setDTDSource(XMLDTDSource xMLDTDSource) {
            XMLDTDSource xMLDTDSource2 = xMLDTDSource;
            this.dtdSource = xMLDTDSource2;
        }

        public void setDocumentSource(XMLDocumentSource xMLDocumentSource) {
            XMLDocumentSource xMLDocumentSource2 = xMLDocumentSource;
            this.documentSource = xMLDocumentSource2;
        }

        public void startAttlist(String str, Augmentations augmentations) throws XNIException {
            String str2 = str;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void startCDATA(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void startConditional(short s, Augmentations augmentations) throws XNIException {
            short s2 = s;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void startContentModel(String str, Augmentations augmentations) throws XNIException {
            String str2 = str;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void startDTD(XMLLocator xMLLocator, Augmentations augmentations) throws XNIException {
            XMLLocator xMLLocator2 = xMLLocator;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void startDocument(XMLLocator xMLLocator, String str, NamespaceContext namespaceContext, Augmentations augmentations) throws XNIException {
            XMLLocator xMLLocator2 = xMLLocator;
            String str2 = str;
            NamespaceContext namespaceContext2 = namespaceContext;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void startElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
            QName qName2 = qName;
            XMLAttributes xMLAttributes2 = xMLAttributes;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void startExternalSubset(XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
            XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void startGeneralEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
            String str3 = str;
            XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
            String str4 = str2;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void startGroup(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void startParameterEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
            String str3 = str;
            XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
            String str4 = str2;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void textDecl(String str, String str2, Augmentations augmentations) throws XNIException {
            String str3 = str;
            String str4 = str2;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void unparsedEntityDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
            String str3 = str;
            XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
            String str4 = str2;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }

        public void xmlDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
            String str4 = str;
            String str5 = str2;
            String str6 = str3;
            Augmentations augmentations2 = augmentations;
            throw AbstractDOMParser.Abort.INSTANCE;
        }
    }

    static final class NullLSParserFilter implements LSParserFilter {
        static final NullLSParserFilter INSTANCE;

        static {
            NullLSParserFilter nullLSParserFilter;
            new NullLSParserFilter();
            INSTANCE = nullLSParserFilter;
        }

        private NullLSParserFilter() {
        }

        public short acceptNode(Node node) {
            Node node2 = node;
            return 1;
        }

        public int getWhatToShow() {
            return -1;
        }

        public short startElement(Element element) {
            Element element2 = element;
            return 1;
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DOMParserImpl(String str, String str2) {
        this((XMLParserConfiguration) ObjectFactory.createObject("org.apache.xerces.xni.parser.XMLParserConfiguration", str));
        String str3 = str2;
        if (str3 == null) {
            return;
        }
        if (str3.equals(Constants.NS_DTD)) {
            this.fConfiguration.setProperty(JAXPConstants.JAXP_SCHEMA_LANGUAGE, Constants.NS_DTD);
            this.fSchemaType = Constants.NS_DTD;
        } else if (str3.equals(Constants.NS_XMLSCHEMA)) {
            this.fConfiguration.setProperty(JAXPConstants.JAXP_SCHEMA_LANGUAGE, Constants.NS_XMLSCHEMA);
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DOMParserImpl(SymbolTable symbolTable) {
        this((XMLParserConfiguration) ObjectFactory.createObject("org.apache.xerces.xni.parser.XMLParserConfiguration", "org.apache.xerces.parsers.XIncludeAwareParserConfiguration"));
        this.fConfiguration.setProperty(SYMBOL_TABLE, symbolTable);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DOMParserImpl(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool) {
        this((XMLParserConfiguration) ObjectFactory.createObject("org.apache.xerces.xni.parser.XMLParserConfiguration", "org.apache.xerces.parsers.XIncludeAwareParserConfiguration"));
        this.fConfiguration.setProperty(SYMBOL_TABLE, symbolTable);
        this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/grammar-pool", xMLGrammarPool);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DOMParserImpl(XMLParserConfiguration xMLParserConfiguration) {
        super(xMLParserConfiguration);
        this.fNamespaceDeclarations = true;
        this.fSchemaType = null;
        this.fBusy = false;
        this.abortNow = false;
        this.fSchemaLocation = null;
        this.fNullFilterInUse = false;
        this.abortHandler = null;
        String[] strArr = new String[10];
        strArr[0] = "canonical-form";
        String[] strArr2 = strArr;
        strArr2[1] = "cdata-sections";
        String[] strArr3 = strArr2;
        strArr3[2] = "charset-overrides-xml-encoding";
        String[] strArr4 = strArr3;
        strArr4[3] = "infoset";
        String[] strArr5 = strArr4;
        strArr5[4] = "namespace-declarations";
        String[] strArr6 = strArr5;
        strArr6[5] = "split-cdata-sections";
        String[] strArr7 = strArr6;
        strArr7[6] = "supported-media-types-only";
        String[] strArr8 = strArr7;
        strArr8[7] = "certified";
        String[] strArr9 = strArr8;
        strArr9[8] = "well-formed";
        String[] strArr10 = strArr9;
        strArr10[9] = "ignore-unknown-character-denormalizations";
        this.fConfiguration.addRecognizedFeatures(strArr10);
        this.fConfiguration.setFeature("http://apache.org/xml/features/dom/defer-node-expansion", false);
        this.fConfiguration.setFeature("namespace-declarations", true);
        this.fConfiguration.setFeature("well-formed", true);
        this.fConfiguration.setFeature("http://apache.org/xml/features/include-comments", true);
        this.fConfiguration.setFeature("http://apache.org/xml/features/dom/include-ignorable-whitespace", true);
        this.fConfiguration.setFeature(NAMESPACES, true);
        this.fConfiguration.setFeature(DYNAMIC_VALIDATION, false);
        this.fConfiguration.setFeature("http://apache.org/xml/features/dom/create-entity-ref-nodes", false);
        this.fConfiguration.setFeature("http://apache.org/xml/features/create-cdata-nodes", false);
        this.fConfiguration.setFeature("canonical-form", false);
        this.fConfiguration.setFeature("charset-overrides-xml-encoding", true);
        this.fConfiguration.setFeature("split-cdata-sections", true);
        this.fConfiguration.setFeature("supported-media-types-only", false);
        this.fConfiguration.setFeature("ignore-unknown-character-denormalizations", true);
        this.fConfiguration.setFeature("certified", true);
        try {
            this.fConfiguration.setFeature(NORMALIZE_DATA, false);
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
        }
    }

    private static DOMException newFeatureNotFoundError(String str) {
        DOMException dOMException;
        new DOMException(8, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "FEATURE_NOT_FOUND", new Object[]{str}));
        return dOMException;
    }

    private static DOMException newFeatureNotSupportedError(String str) {
        DOMException dOMException;
        new DOMException(9, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "FEATURE_NOT_SUPPORTED", new Object[]{str}));
        return dOMException;
    }

    private static DOMException newInvalidStateError() {
        Throwable th;
        Throwable th2 = th;
        new DOMException(11, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "INVALID_STATE_ERR", (Object[]) null));
        throw th2;
    }

    private static DOMException newTypeMismatchError(String str) {
        DOMException dOMException;
        new DOMException(17, DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "TYPE_MISMATCH_ERR", new Object[]{str}));
        return dOMException;
    }

    private void restoreHandlers() {
        this.fConfiguration.setDocumentHandler(this);
        this.fConfiguration.setDTDHandler(this);
        this.fConfiguration.setDTDContentModelHandler(this);
    }

    public void abort() {
        AbortHandler abortHandler2;
        if (this.fBusy) {
            this.fBusy = false;
            if (this.currentThread != null) {
                this.abortNow = true;
                if (this.abortHandler == null) {
                    new AbortHandler((AnonymousClass1) null);
                    this.abortHandler = abortHandler2;
                }
                this.fConfiguration.setDocumentHandler(this.abortHandler);
                this.fConfiguration.setDTDHandler(this.abortHandler);
                this.fConfiguration.setDTDContentModelHandler(this.abortHandler);
                if (this.currentThread == Thread.currentThread()) {
                    throw AbstractDOMParser.Abort.INSTANCE;
                }
                this.currentThread.interrupt();
            }
        }
    }

    public boolean canSetParameter(String str, Object obj) {
        String str2 = str;
        Object obj2 = obj;
        if (obj2 == null) {
            return true;
        }
        if (obj2 instanceof Boolean) {
            boolean booleanValue = ((Boolean) obj2).booleanValue();
            if (str2.equalsIgnoreCase("supported-media-types-only") || str2.equalsIgnoreCase("normalize-characters") || str2.equalsIgnoreCase("check-character-normalization") || str2.equalsIgnoreCase("canonical-form")) {
                return !booleanValue;
            } else if (str2.equalsIgnoreCase("well-formed") || str2.equalsIgnoreCase("ignore-unknown-character-denormalizations")) {
                return booleanValue;
            } else if (str2.equalsIgnoreCase("cdata-sections") || str2.equalsIgnoreCase("charset-overrides-xml-encoding") || str2.equalsIgnoreCase("comments") || str2.equalsIgnoreCase("datatype-normalization") || str2.equalsIgnoreCase("disallow-doctype") || str2.equalsIgnoreCase("entities") || str2.equalsIgnoreCase("infoset") || str2.equalsIgnoreCase("namespaces") || str2.equalsIgnoreCase("namespace-declarations") || str2.equalsIgnoreCase("validate") || str2.equalsIgnoreCase("validate-if-schema") || str2.equalsIgnoreCase("element-content-whitespace") || str2.equalsIgnoreCase("xml-declaration")) {
                return true;
            } else {
                try {
                    boolean feature = this.fConfiguration.getFeature(str2.equalsIgnoreCase(HONOUR_ALL_SCHEMALOCATIONS) ? HONOUR_ALL_SCHEMALOCATIONS : str2.equalsIgnoreCase(NAMESPACE_GROWTH) ? NAMESPACE_GROWTH : str2.equalsIgnoreCase(TOLERATE_DUPLICATES) ? TOLERATE_DUPLICATES : str2.toLowerCase(Locale.ENGLISH));
                    return true;
                } catch (XMLConfigurationException e) {
                    XMLConfigurationException xMLConfigurationException = e;
                    return false;
                }
            }
        } else if (str2.equalsIgnoreCase("error-handler")) {
            return (obj2 instanceof DOMErrorHandler) || obj2 == null;
        } else {
            if (str2.equalsIgnoreCase("resource-resolver")) {
                return (obj2 instanceof LSResourceResolver) || obj2 == null;
            }
            if (str2.equalsIgnoreCase("schema-type")) {
                return ((obj2 instanceof String) && (obj2.equals(Constants.NS_XMLSCHEMA) || obj2.equals(Constants.NS_DTD))) || obj2 == null;
            }
            if (str2.equalsIgnoreCase("schema-location")) {
                return (obj2 instanceof String) || obj2 == null;
            }
            if (str2.equalsIgnoreCase("http://apache.org/xml/properties/dom/document-class-name")) {
                return true;
            }
            try {
                Object property = this.fConfiguration.getProperty(str2.toLowerCase(Locale.ENGLISH));
                return true;
            } catch (XMLConfigurationException e2) {
                XMLConfigurationException xMLConfigurationException2 = e2;
                return false;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public XMLInputSource dom2xmlInputSource(LSInput lSInput) {
        XMLInputSource xMLInputSource;
        XMLInputSource xMLInputSource2;
        Throwable th;
        DOMErrorImpl dOMErrorImpl;
        XMLInputSource xMLInputSource3;
        Reader reader;
        XMLInputSource xMLInputSource4;
        XMLInputSource xMLInputSource5;
        LSInput lSInput2 = lSInput;
        if (lSInput2.getCharacterStream() != null) {
            new XMLInputSource(lSInput2.getPublicId(), lSInput2.getSystemId(), lSInput2.getBaseURI(), lSInput2.getCharacterStream(), "UTF-16");
            xMLInputSource2 = xMLInputSource5;
        } else if (lSInput2.getByteStream() != null) {
            new XMLInputSource(lSInput2.getPublicId(), lSInput2.getSystemId(), lSInput2.getBaseURI(), lSInput2.getByteStream(), lSInput2.getEncoding());
            xMLInputSource2 = xMLInputSource4;
        } else if (lSInput2.getStringData() != null && lSInput2.getStringData().length() > 0) {
            new StringReader(lSInput2.getStringData());
            new XMLInputSource(lSInput2.getPublicId(), lSInput2.getSystemId(), lSInput2.getBaseURI(), reader, "UTF-16");
            xMLInputSource2 = xMLInputSource3;
        } else if ((lSInput2.getSystemId() == null || lSInput2.getSystemId().length() <= 0) && (lSInput2.getPublicId() == null || lSInput2.getPublicId().length() <= 0)) {
            if (this.fErrorHandler != null) {
                new DOMErrorImpl();
                DOMErrorImpl dOMErrorImpl2 = dOMErrorImpl;
                dOMErrorImpl2.fType = "no-input-specified";
                dOMErrorImpl2.fMessage = "no-input-specified";
                dOMErrorImpl2.fSeverity = 3;
                boolean handleError = this.fErrorHandler.getErrorHandler().handleError(dOMErrorImpl2);
            }
            Throwable th2 = th;
            new LSException(81, "no-input-specified");
            throw th2;
        } else {
            new XMLInputSource(lSInput2.getPublicId(), lSInput2.getSystemId(), lSInput2.getBaseURI());
            xMLInputSource2 = xMLInputSource;
        }
        return xMLInputSource2;
    }

    public boolean getAsync() {
        return false;
    }

    public boolean getBusy() {
        return this.fBusy;
    }

    public DOMConfiguration getDomConfig() {
        return this;
    }

    public LSParserFilter getFilter() {
        return !this.fNullFilterInUse ? this.fDOMFilter : null;
    }

    public Object getParameter(String str) throws DOMException {
        String str2 = str;
        if (str2.equalsIgnoreCase("comments")) {
            return this.fConfiguration.getFeature("http://apache.org/xml/features/include-comments") ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("datatype-normalization")) {
            return this.fConfiguration.getFeature(NORMALIZE_DATA) ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("entities")) {
            return this.fConfiguration.getFeature("http://apache.org/xml/features/dom/create-entity-ref-nodes") ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("namespaces")) {
            return this.fConfiguration.getFeature(NAMESPACES) ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("validate")) {
            return this.fConfiguration.getFeature(VALIDATION_FEATURE) ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("validate-if-schema")) {
            return this.fConfiguration.getFeature(DYNAMIC_VALIDATION) ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("element-content-whitespace")) {
            return this.fConfiguration.getFeature("http://apache.org/xml/features/dom/include-ignorable-whitespace") ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("disallow-doctype")) {
            return this.fConfiguration.getFeature(DISALLOW_DOCTYPE_DECL_FEATURE) ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("infoset")) {
            return this.fConfiguration.getFeature(NAMESPACES) && this.fConfiguration.getFeature("namespace-declarations") && this.fConfiguration.getFeature("http://apache.org/xml/features/include-comments") && this.fConfiguration.getFeature("http://apache.org/xml/features/dom/include-ignorable-whitespace") && !this.fConfiguration.getFeature(DYNAMIC_VALIDATION) && !this.fConfiguration.getFeature("http://apache.org/xml/features/dom/create-entity-ref-nodes") && !this.fConfiguration.getFeature(NORMALIZE_DATA) && !this.fConfiguration.getFeature("http://apache.org/xml/features/create-cdata-nodes") ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("cdata-sections")) {
            return this.fConfiguration.getFeature("http://apache.org/xml/features/create-cdata-nodes") ? Boolean.TRUE : Boolean.FALSE;
        } else if (str2.equalsIgnoreCase("check-character-normalization") || str2.equalsIgnoreCase("normalize-characters")) {
            return Boolean.FALSE;
        } else {
            if (str2.equalsIgnoreCase("namespace-declarations") || str2.equalsIgnoreCase("well-formed") || str2.equalsIgnoreCase("ignore-unknown-character-denormalizations") || str2.equalsIgnoreCase("canonical-form") || str2.equalsIgnoreCase("supported-media-types-only") || str2.equalsIgnoreCase("split-cdata-sections") || str2.equalsIgnoreCase("charset-overrides-xml-encoding")) {
                return this.fConfiguration.getFeature(str2.toLowerCase(Locale.ENGLISH)) ? Boolean.TRUE : Boolean.FALSE;
            } else if (str2.equalsIgnoreCase("error-handler")) {
                if (this.fErrorHandler != null) {
                    return this.fErrorHandler.getErrorHandler();
                }
                return null;
            } else if (str2.equalsIgnoreCase("resource-resolver")) {
                try {
                    XMLEntityResolver xMLEntityResolver = (XMLEntityResolver) this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/entity-resolver");
                    if (xMLEntityResolver != null && (xMLEntityResolver instanceof DOMEntityResolverWrapper)) {
                        return ((DOMEntityResolverWrapper) xMLEntityResolver).getEntityResolver();
                    }
                } catch (XMLConfigurationException e) {
                    XMLConfigurationException xMLConfigurationException = e;
                }
                return null;
            } else if (str2.equalsIgnoreCase("schema-type")) {
                return this.fConfiguration.getProperty(JAXPConstants.JAXP_SCHEMA_LANGUAGE);
            } else {
                if (str2.equalsIgnoreCase("schema-location")) {
                    return this.fSchemaLocation;
                }
                if (str2.equalsIgnoreCase(SYMBOL_TABLE)) {
                    return this.fConfiguration.getProperty(SYMBOL_TABLE);
                }
                if (str2.equalsIgnoreCase("http://apache.org/xml/properties/dom/document-class-name")) {
                    return this.fConfiguration.getProperty("http://apache.org/xml/properties/dom/document-class-name");
                }
                String lowerCase = str2.equalsIgnoreCase(HONOUR_ALL_SCHEMALOCATIONS) ? HONOUR_ALL_SCHEMALOCATIONS : str2.equals(NAMESPACE_GROWTH) ? NAMESPACE_GROWTH : str2.equals(TOLERATE_DUPLICATES) ? TOLERATE_DUPLICATES : str2.toLowerCase(Locale.ENGLISH);
                try {
                    return this.fConfiguration.getFeature(lowerCase) ? Boolean.TRUE : Boolean.FALSE;
                } catch (XMLConfigurationException e2) {
                    XMLConfigurationException xMLConfigurationException2 = e2;
                    try {
                        return this.fConfiguration.getProperty(lowerCase);
                    } catch (XMLConfigurationException e3) {
                        XMLConfigurationException xMLConfigurationException3 = e3;
                        throw newFeatureNotFoundError(str2);
                    }
                }
            }
        }
    }

    public DOMStringList getParameterNames() {
        ArrayList arrayList;
        DOMStringList dOMStringList;
        if (this.fRecognizedParameters == null) {
            new ArrayList();
            ArrayList arrayList2 = arrayList;
            boolean add = arrayList2.add("namespaces");
            boolean add2 = arrayList2.add("cdata-sections");
            boolean add3 = arrayList2.add("canonical-form");
            boolean add4 = arrayList2.add("namespace-declarations");
            boolean add5 = arrayList2.add("split-cdata-sections");
            boolean add6 = arrayList2.add("entities");
            boolean add7 = arrayList2.add("validate-if-schema");
            boolean add8 = arrayList2.add("validate");
            boolean add9 = arrayList2.add("datatype-normalization");
            boolean add10 = arrayList2.add("charset-overrides-xml-encoding");
            boolean add11 = arrayList2.add("check-character-normalization");
            boolean add12 = arrayList2.add("supported-media-types-only");
            boolean add13 = arrayList2.add("ignore-unknown-character-denormalizations");
            boolean add14 = arrayList2.add("normalize-characters");
            boolean add15 = arrayList2.add("well-formed");
            boolean add16 = arrayList2.add("infoset");
            boolean add17 = arrayList2.add("disallow-doctype");
            boolean add18 = arrayList2.add("element-content-whitespace");
            boolean add19 = arrayList2.add("comments");
            boolean add20 = arrayList2.add("error-handler");
            boolean add21 = arrayList2.add("resource-resolver");
            boolean add22 = arrayList2.add("schema-location");
            boolean add23 = arrayList2.add("schema-type");
            new DOMStringListImpl(arrayList2);
            this.fRecognizedParameters = dOMStringList;
        }
        return this.fRecognizedParameters;
    }

    public Document parse(LSInput lSInput) throws LSException {
        DOMErrorImpl dOMErrorImpl;
        XMLInputSource dom2xmlInputSource = dom2xmlInputSource(lSInput);
        if (this.fBusy) {
            throw newInvalidStateError();
        }
        try {
            this.currentThread = Thread.currentThread();
            this.fBusy = true;
            parse(dom2xmlInputSource);
            this.fBusy = false;
            if (this.abortNow && this.currentThread.isInterrupted()) {
                this.abortNow = false;
                boolean interrupted = Thread.interrupted();
            }
        } catch (Exception e) {
            Exception exc = e;
            this.fBusy = false;
            if (this.abortNow && this.currentThread.isInterrupted()) {
                boolean interrupted2 = Thread.interrupted();
            }
            if (this.abortNow) {
                this.abortNow = false;
                restoreHandlers();
                return null;
            } else if (exc != AbstractDOMParser.Abort.INSTANCE) {
                if (!(exc instanceof XMLParseException) && this.fErrorHandler != null) {
                    new DOMErrorImpl();
                    DOMErrorImpl dOMErrorImpl2 = dOMErrorImpl;
                    dOMErrorImpl2.fException = exc;
                    dOMErrorImpl2.fMessage = exc.getMessage();
                    dOMErrorImpl2.fSeverity = 3;
                    boolean handleError = this.fErrorHandler.getErrorHandler().handleError(dOMErrorImpl2);
                }
                throw ((LSException) DOMUtil.createLSException(81, exc).fillInStackTrace());
            }
        }
        Document document = getDocument();
        dropDocumentReferences();
        return document;
    }

    public Document parseURI(String str) throws LSException {
        XMLInputSource xMLInputSource;
        DOMErrorImpl dOMErrorImpl;
        String str2 = str;
        if (this.fBusy) {
            throw newInvalidStateError();
        }
        new XMLInputSource((String) null, str2, (String) null);
        XMLInputSource xMLInputSource2 = xMLInputSource;
        try {
            this.currentThread = Thread.currentThread();
            this.fBusy = true;
            parse(xMLInputSource2);
            this.fBusy = false;
            if (this.abortNow && this.currentThread.isInterrupted()) {
                this.abortNow = false;
                boolean interrupted = Thread.interrupted();
            }
        } catch (Exception e) {
            Exception exc = e;
            this.fBusy = false;
            if (this.abortNow && this.currentThread.isInterrupted()) {
                boolean interrupted2 = Thread.interrupted();
            }
            if (this.abortNow) {
                this.abortNow = false;
                restoreHandlers();
                return null;
            } else if (exc != AbstractDOMParser.Abort.INSTANCE) {
                if (!(exc instanceof XMLParseException) && this.fErrorHandler != null) {
                    new DOMErrorImpl();
                    DOMErrorImpl dOMErrorImpl2 = dOMErrorImpl;
                    dOMErrorImpl2.fException = exc;
                    dOMErrorImpl2.fMessage = exc.getMessage();
                    dOMErrorImpl2.fSeverity = 3;
                    boolean handleError = this.fErrorHandler.getErrorHandler().handleError(dOMErrorImpl2);
                }
                throw ((LSException) DOMUtil.createLSException(81, exc).fillInStackTrace());
            }
        }
        Document document = getDocument();
        dropDocumentReferences();
        return document;
    }

    public Node parseWithContext(LSInput lSInput, Node node, short s) throws DOMException, LSException {
        Throwable th;
        LSInput lSInput2 = lSInput;
        Node node2 = node;
        short s2 = s;
        Throwable th2 = th;
        new DOMException(9, "Not supported");
        throw th2;
    }

    public void reset() {
        super.reset();
        this.fNamespaceDeclarations = this.fConfiguration.getFeature("namespace-declarations");
        if (this.fNullFilterInUse) {
            this.fDOMFilter = null;
            this.fNullFilterInUse = false;
        }
        if (this.fSkippedElemStack != null) {
            this.fSkippedElemStack.removeAllElements();
        }
        this.fRejectedElementDepth = 0;
        this.fFilterReject = false;
        this.fSchemaType = null;
    }

    public void setFilter(LSParserFilter lSParserFilter) {
        Stack stack;
        LSParserFilter lSParserFilter2 = lSParserFilter;
        if (!this.fBusy || lSParserFilter2 != null || this.fDOMFilter == null) {
            this.fDOMFilter = lSParserFilter2;
        } else {
            this.fNullFilterInUse = true;
            this.fDOMFilter = NullLSParserFilter.INSTANCE;
        }
        if (this.fSkippedElemStack == null) {
            new Stack();
            this.fSkippedElemStack = stack;
        }
    }

    public void setParameter(String str, Object obj) throws DOMException {
        StringTokenizer stringTokenizer;
        ArrayList arrayList;
        Object obj2;
        DOMErrorHandlerWrapper dOMErrorHandlerWrapper;
        String str2 = str;
        Object obj3 = obj;
        if (obj3 instanceof Boolean) {
            boolean booleanValue = ((Boolean) obj3).booleanValue();
            try {
                if (str2.equalsIgnoreCase("comments")) {
                    this.fConfiguration.setFeature("http://apache.org/xml/features/include-comments", booleanValue);
                } else if (str2.equalsIgnoreCase("datatype-normalization")) {
                    this.fConfiguration.setFeature(NORMALIZE_DATA, booleanValue);
                } else if (str2.equalsIgnoreCase("entities")) {
                    this.fConfiguration.setFeature("http://apache.org/xml/features/dom/create-entity-ref-nodes", booleanValue);
                } else if (str2.equalsIgnoreCase("disallow-doctype")) {
                    this.fConfiguration.setFeature(DISALLOW_DOCTYPE_DECL_FEATURE, booleanValue);
                } else if (str2.equalsIgnoreCase("supported-media-types-only") || str2.equalsIgnoreCase("normalize-characters") || str2.equalsIgnoreCase("check-character-normalization") || str2.equalsIgnoreCase("canonical-form")) {
                    if (booleanValue) {
                        throw newFeatureNotSupportedError(str2);
                    }
                } else if (str2.equalsIgnoreCase("namespaces")) {
                    this.fConfiguration.setFeature(NAMESPACES, booleanValue);
                } else if (str2.equalsIgnoreCase("infoset")) {
                    if (booleanValue) {
                        this.fConfiguration.setFeature(NAMESPACES, true);
                        this.fConfiguration.setFeature("namespace-declarations", true);
                        this.fConfiguration.setFeature("http://apache.org/xml/features/include-comments", true);
                        this.fConfiguration.setFeature("http://apache.org/xml/features/dom/include-ignorable-whitespace", true);
                        this.fConfiguration.setFeature(DYNAMIC_VALIDATION, false);
                        this.fConfiguration.setFeature("http://apache.org/xml/features/dom/create-entity-ref-nodes", false);
                        this.fConfiguration.setFeature(NORMALIZE_DATA, false);
                        this.fConfiguration.setFeature("http://apache.org/xml/features/create-cdata-nodes", false);
                    }
                } else if (str2.equalsIgnoreCase("cdata-sections")) {
                    this.fConfiguration.setFeature("http://apache.org/xml/features/create-cdata-nodes", booleanValue);
                } else if (str2.equalsIgnoreCase("namespace-declarations")) {
                    this.fConfiguration.setFeature("namespace-declarations", booleanValue);
                } else if (str2.equalsIgnoreCase("well-formed") || str2.equalsIgnoreCase("ignore-unknown-character-denormalizations")) {
                    if (!booleanValue) {
                        throw newFeatureNotSupportedError(str2);
                    }
                } else if (str2.equalsIgnoreCase("validate")) {
                    this.fConfiguration.setFeature(VALIDATION_FEATURE, booleanValue);
                    if (this.fSchemaType != Constants.NS_DTD) {
                        this.fConfiguration.setFeature(XMLSCHEMA, booleanValue);
                        this.fConfiguration.setFeature(XMLSCHEMA_FULL_CHECKING, booleanValue);
                    }
                    if (booleanValue) {
                        this.fConfiguration.setFeature(DYNAMIC_VALIDATION, false);
                    }
                } else if (str2.equalsIgnoreCase("validate-if-schema")) {
                    this.fConfiguration.setFeature(DYNAMIC_VALIDATION, booleanValue);
                    if (booleanValue) {
                        this.fConfiguration.setFeature(VALIDATION_FEATURE, false);
                    }
                } else if (str2.equalsIgnoreCase("element-content-whitespace")) {
                    this.fConfiguration.setFeature("http://apache.org/xml/features/dom/include-ignorable-whitespace", booleanValue);
                } else if (str2.equalsIgnoreCase("psvi")) {
                    this.fConfiguration.setFeature(PSVI_AUGMENT, true);
                    this.fConfiguration.setProperty("http://apache.org/xml/properties/dom/document-class-name", "org.apache.xerces.dom.PSVIDocumentImpl");
                } else {
                    this.fConfiguration.setFeature(str2.equalsIgnoreCase(HONOUR_ALL_SCHEMALOCATIONS) ? HONOUR_ALL_SCHEMALOCATIONS : str2.equals(NAMESPACE_GROWTH) ? NAMESPACE_GROWTH : str2.equals(TOLERATE_DUPLICATES) ? TOLERATE_DUPLICATES : str2.toLowerCase(Locale.ENGLISH), booleanValue);
                }
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
                throw newFeatureNotFoundError(str2);
            }
        } else if (str2.equalsIgnoreCase("error-handler")) {
            if ((obj3 instanceof DOMErrorHandler) || obj3 == null) {
                try {
                    new DOMErrorHandlerWrapper((DOMErrorHandler) obj3);
                    this.fErrorHandler = dOMErrorHandlerWrapper;
                    this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/error-handler", this.fErrorHandler);
                } catch (XMLConfigurationException e2) {
                    XMLConfigurationException xMLConfigurationException2 = e2;
                }
            } else {
                throw newTypeMismatchError(str2);
            }
        } else if (str2.equalsIgnoreCase("resource-resolver")) {
            if ((obj3 instanceof LSResourceResolver) || obj3 == null) {
                try {
                    new DOMEntityResolverWrapper((LSResourceResolver) obj3);
                    this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/entity-resolver", obj2);
                } catch (XMLConfigurationException e3) {
                    XMLConfigurationException xMLConfigurationException3 = e3;
                }
            } else {
                throw newTypeMismatchError(str2);
            }
        } else if (str2.equalsIgnoreCase("schema-location")) {
            if ((obj3 instanceof String) || obj3 == null) {
                if (obj3 == null) {
                    try {
                        this.fSchemaLocation = null;
                        this.fConfiguration.setProperty(JAXPConstants.JAXP_SCHEMA_SOURCE, (Object) null);
                    } catch (XMLConfigurationException e4) {
                        XMLConfigurationException xMLConfigurationException4 = e4;
                        return;
                    }
                } else {
                    this.fSchemaLocation = (String) obj3;
                    new StringTokenizer(this.fSchemaLocation, " \n\t\r");
                    StringTokenizer stringTokenizer2 = stringTokenizer;
                    if (stringTokenizer2.hasMoreTokens()) {
                        new ArrayList();
                        ArrayList arrayList2 = arrayList;
                        boolean add = arrayList2.add(stringTokenizer2.nextToken());
                        while (stringTokenizer2.hasMoreTokens()) {
                            boolean add2 = arrayList2.add(stringTokenizer2.nextToken());
                        }
                        this.fConfiguration.setProperty(JAXPConstants.JAXP_SCHEMA_SOURCE, arrayList2.toArray());
                    } else {
                        this.fConfiguration.setProperty(JAXPConstants.JAXP_SCHEMA_SOURCE, obj3);
                    }
                }
                return;
            }
            throw newTypeMismatchError(str2);
        } else if (str2.equalsIgnoreCase("schema-type")) {
            if ((obj3 instanceof String) || obj3 == null) {
                if (obj3 == null) {
                    try {
                        this.fConfiguration.setFeature(XMLSCHEMA, false);
                        this.fConfiguration.setFeature(XMLSCHEMA_FULL_CHECKING, false);
                        this.fConfiguration.setProperty(JAXPConstants.JAXP_SCHEMA_LANGUAGE, (Object) null);
                        this.fSchemaType = null;
                    } catch (XMLConfigurationException e5) {
                        XMLConfigurationException xMLConfigurationException5 = e5;
                        return;
                    }
                } else if (obj3.equals(Constants.NS_XMLSCHEMA)) {
                    this.fConfiguration.setFeature(XMLSCHEMA, true);
                    this.fConfiguration.setFeature(XMLSCHEMA_FULL_CHECKING, true);
                    this.fConfiguration.setProperty(JAXPConstants.JAXP_SCHEMA_LANGUAGE, Constants.NS_XMLSCHEMA);
                    this.fSchemaType = Constants.NS_XMLSCHEMA;
                } else if (obj3.equals(Constants.NS_DTD)) {
                    this.fConfiguration.setFeature(XMLSCHEMA, false);
                    this.fConfiguration.setFeature(XMLSCHEMA_FULL_CHECKING, false);
                    this.fConfiguration.setProperty(JAXPConstants.JAXP_SCHEMA_LANGUAGE, Constants.NS_DTD);
                    this.fSchemaType = Constants.NS_DTD;
                }
                return;
            }
            throw newTypeMismatchError(str2);
        } else if (str2.equalsIgnoreCase("http://apache.org/xml/properties/dom/document-class-name")) {
            this.fConfiguration.setProperty("http://apache.org/xml/properties/dom/document-class-name", obj3);
        } else {
            String lowerCase = str2.toLowerCase(Locale.ENGLISH);
            try {
                this.fConfiguration.setProperty(lowerCase, obj3);
            } catch (XMLConfigurationException e6) {
                XMLConfigurationException xMLConfigurationException6 = e6;
                if (str2.equalsIgnoreCase(HONOUR_ALL_SCHEMALOCATIONS)) {
                    lowerCase = HONOUR_ALL_SCHEMALOCATIONS;
                } else if (str2.equals(NAMESPACE_GROWTH)) {
                    lowerCase = NAMESPACE_GROWTH;
                } else if (str2.equals(TOLERATE_DUPLICATES)) {
                    lowerCase = TOLERATE_DUPLICATES;
                }
                boolean feature = this.fConfiguration.getFeature(lowerCase);
                throw newTypeMismatchError(str2);
            } catch (XMLConfigurationException e7) {
                XMLConfigurationException xMLConfigurationException7 = e7;
                throw newFeatureNotFoundError(str2);
            }
        }
    }

    public void startElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) {
        QName qName2 = qName;
        XMLAttributes xMLAttributes2 = xMLAttributes;
        Augmentations augmentations2 = augmentations;
        if (!this.fNamespaceDeclarations && this.fNamespaceAware) {
            for (int length = xMLAttributes2.getLength() - 1; length >= 0; length--) {
                if (XMLSymbols.PREFIX_XMLNS == xMLAttributes2.getPrefix(length) || XMLSymbols.PREFIX_XMLNS == xMLAttributes2.getQName(length)) {
                    xMLAttributes2.removeAttributeAt(length);
                }
            }
        }
        super.startElement(qName2, xMLAttributes2, augmentations2);
    }
}
