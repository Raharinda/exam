package org.apache.xerces.parsers;

import java.io.CharConversionException;
import java.io.IOException;
import org.apache.xerces.dom.DOMMessageFormatter;
import org.apache.xerces.util.EntityResolver2Wrapper;
import org.apache.xerces.util.EntityResolverWrapper;
import org.apache.xerces.util.ErrorHandlerWrapper;
import org.apache.xerces.util.SAXMessageFormatter;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLParseException;
import org.apache.xerces.xni.parser.XMLParserConfiguration;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.SAXParseException;
import org.xml.sax.ext.EntityResolver2;
import org.xml.sax.helpers.LocatorImpl;

public class DOMParser extends AbstractDOMParser {
    private static final String[] RECOGNIZED_PROPERTIES;
    protected static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    protected static final String USE_ENTITY_RESOLVER2 = "http://xml.org/sax/features/use-entity-resolver2";
    protected static final String XMLGRAMMAR_POOL = "http://apache.org/xml/properties/internal/grammar-pool";
    protected boolean fUseEntityResolver2;

    static {
        String[] strArr = new String[2];
        strArr[0] = SYMBOL_TABLE;
        String[] strArr2 = strArr;
        strArr2[1] = XMLGRAMMAR_POOL;
        RECOGNIZED_PROPERTIES = strArr2;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DOMParser() {
        this((SymbolTable) null, (XMLGrammarPool) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DOMParser(SymbolTable symbolTable) {
        this(symbolTable, (XMLGrammarPool) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DOMParser(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool) {
        super((XMLParserConfiguration) ObjectFactory.createObject("org.apache.xerces.xni.parser.XMLParserConfiguration", "org.apache.xerces.parsers.XIncludeAwareParserConfiguration"));
        SymbolTable symbolTable2 = symbolTable;
        XMLGrammarPool xMLGrammarPool2 = xMLGrammarPool;
        this.fUseEntityResolver2 = true;
        this.fConfiguration.addRecognizedProperties(RECOGNIZED_PROPERTIES);
        if (symbolTable2 != null) {
            this.fConfiguration.setProperty(SYMBOL_TABLE, symbolTable2);
        }
        if (xMLGrammarPool2 != null) {
            this.fConfiguration.setProperty(XMLGRAMMAR_POOL, xMLGrammarPool2);
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DOMParser(XMLParserConfiguration xMLParserConfiguration) {
        super(xMLParserConfiguration);
        this.fUseEntityResolver2 = true;
    }

    public EntityResolver getEntityResolver() {
        EntityResolver2 entityResolver2 = null;
        try {
            XMLEntityResolver xMLEntityResolver = (XMLEntityResolver) this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/entity-resolver");
            if (xMLEntityResolver != null) {
                if (xMLEntityResolver instanceof EntityResolverWrapper) {
                    entityResolver2 = ((EntityResolverWrapper) xMLEntityResolver).getEntityResolver();
                } else if (xMLEntityResolver instanceof EntityResolver2Wrapper) {
                    entityResolver2 = ((EntityResolver2Wrapper) xMLEntityResolver).getEntityResolver();
                }
            }
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
        }
        return entityResolver2;
    }

    public ErrorHandler getErrorHandler() {
        ErrorHandler errorHandler = null;
        try {
            XMLErrorHandler xMLErrorHandler = (XMLErrorHandler) this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/error-handler");
            if (xMLErrorHandler != null && (xMLErrorHandler instanceof ErrorHandlerWrapper)) {
                errorHandler = ((ErrorHandlerWrapper) xMLErrorHandler).getErrorHandler();
            }
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
        }
        return errorHandler;
    }

    public boolean getFeature(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        String str2 = str;
        try {
            return str2.equals(USE_ENTITY_RESOLVER2) ? this.fUseEntityResolver2 : this.fConfiguration.getFeature(str2);
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
            String identifier = xMLConfigurationException.getIdentifier();
            if (xMLConfigurationException.getType() == 0) {
                Throwable th3 = th2;
                new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-not-recognized", new Object[]{identifier}));
                throw th3;
            }
            Throwable th4 = th;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-not-supported", new Object[]{identifier}));
            throw th4;
        }
    }

    public Object getProperty(String str) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        if (str2.equals("http://apache.org/xml/properties/dom/current-element-node")) {
            boolean z = false;
            try {
                z = getFeature("http://apache.org/xml/features/dom/defer-node-expansion");
            } catch (XMLConfigurationException e) {
                XMLConfigurationException xMLConfigurationException = e;
            }
            if (z) {
                Throwable th4 = th3;
                new SAXNotSupportedException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "CannotQueryDeferredNode", (Object[]) null));
                throw th4;
            }
            return (this.fCurrentNode == null || this.fCurrentNode.getNodeType() != 1) ? null : this.fCurrentNode;
        }
        try {
            return this.fConfiguration.getProperty(str2);
        } catch (XMLConfigurationException e2) {
            XMLConfigurationException xMLConfigurationException2 = e2;
            String identifier = xMLConfigurationException2.getIdentifier();
            if (xMLConfigurationException2.getType() == 0) {
                Throwable th5 = th2;
                new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-recognized", new Object[]{identifier}));
                throw th5;
            }
            Throwable th6 = th;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-supported", new Object[]{identifier}));
            throw th6;
        }
    }

    public XMLParserConfiguration getXMLParserConfiguration() {
        return this.fConfiguration;
    }

    public void parse(String str) throws SAXException, IOException {
        XMLInputSource xMLInputSource;
        Throwable th;
        Throwable th2;
        LocatorImpl locatorImpl;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        Throwable th6;
        new XMLInputSource((String) null, str, (String) null);
        try {
            parse(xMLInputSource);
        } catch (XMLParseException e) {
            XMLParseException xMLParseException = e;
            Exception exception = xMLParseException.getException();
            if (exception == null || (exception instanceof CharConversionException)) {
                new LocatorImpl();
                LocatorImpl locatorImpl2 = locatorImpl;
                locatorImpl2.setPublicId(xMLParseException.getPublicId());
                locatorImpl2.setSystemId(xMLParseException.getExpandedSystemId());
                locatorImpl2.setLineNumber(xMLParseException.getLineNumber());
                locatorImpl2.setColumnNumber(xMLParseException.getColumnNumber());
                if (exception == null) {
                    th4 = th5;
                    new SAXParseException(xMLParseException.getMessage(), locatorImpl2);
                } else {
                    th4 = th3;
                    new SAXParseException(xMLParseException.getMessage(), locatorImpl2, exception);
                }
                throw th4;
            } else if (exception instanceof SAXException) {
                throw ((SAXException) exception);
            } else if (exception instanceof IOException) {
                throw ((IOException) exception);
            } else {
                Throwable th7 = th6;
                new SAXException(exception);
                throw th7;
            }
        } catch (XNIException e2) {
            XNIException xNIException = e2;
            xNIException.printStackTrace();
            Exception exception2 = xNIException.getException();
            if (exception2 == null) {
                Throwable th8 = th2;
                new SAXException(xNIException.getMessage());
                throw th8;
            } else if (exception2 instanceof SAXException) {
                throw ((SAXException) exception2);
            } else if (exception2 instanceof IOException) {
                throw ((IOException) exception2);
            } else {
                Throwable th9 = th;
                new SAXException(exception2);
                throw th9;
            }
        }
    }

    public void parse(InputSource inputSource) throws SAXException, IOException {
        Throwable th;
        Throwable th2;
        LocatorImpl locatorImpl;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        Throwable th6;
        XMLInputSource xMLInputSource;
        InputSource inputSource2 = inputSource;
        try {
            new XMLInputSource(inputSource2.getPublicId(), inputSource2.getSystemId(), (String) null);
            XMLInputSource xMLInputSource2 = xMLInputSource;
            xMLInputSource2.setByteStream(inputSource2.getByteStream());
            xMLInputSource2.setCharacterStream(inputSource2.getCharacterStream());
            xMLInputSource2.setEncoding(inputSource2.getEncoding());
            parse(xMLInputSource2);
        } catch (XMLParseException e) {
            XMLParseException xMLParseException = e;
            Exception exception = xMLParseException.getException();
            if (exception == null || (exception instanceof CharConversionException)) {
                new LocatorImpl();
                LocatorImpl locatorImpl2 = locatorImpl;
                locatorImpl2.setPublicId(xMLParseException.getPublicId());
                locatorImpl2.setSystemId(xMLParseException.getExpandedSystemId());
                locatorImpl2.setLineNumber(xMLParseException.getLineNumber());
                locatorImpl2.setColumnNumber(xMLParseException.getColumnNumber());
                if (exception == null) {
                    th4 = th5;
                    new SAXParseException(xMLParseException.getMessage(), locatorImpl2);
                } else {
                    th4 = th3;
                    new SAXParseException(xMLParseException.getMessage(), locatorImpl2, exception);
                }
                throw th4;
            } else if (exception instanceof SAXException) {
                throw ((SAXException) exception);
            } else if (exception instanceof IOException) {
                throw ((IOException) exception);
            } else {
                Throwable th7 = th6;
                new SAXException(exception);
                throw th7;
            }
        } catch (XNIException e2) {
            XNIException xNIException = e2;
            Exception exception2 = xNIException.getException();
            if (exception2 == null) {
                Throwable th8 = th2;
                new SAXException(xNIException.getMessage());
                throw th8;
            } else if (exception2 instanceof SAXException) {
                throw ((SAXException) exception2);
            } else if (exception2 instanceof IOException) {
                throw ((IOException) exception2);
            } else {
                Throwable th9 = th;
                new SAXException(exception2);
                throw th9;
            }
        }
    }

    public void setEntityResolver(EntityResolver entityResolver) {
        Object obj;
        Object obj2;
        EntityResolver entityResolver2 = entityResolver;
        try {
            XMLEntityResolver xMLEntityResolver = (XMLEntityResolver) this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/entity-resolver");
            if (!this.fUseEntityResolver2 || !(entityResolver2 instanceof EntityResolver2)) {
                if (xMLEntityResolver instanceof EntityResolverWrapper) {
                    ((EntityResolverWrapper) xMLEntityResolver).setEntityResolver(entityResolver2);
                    return;
                }
                new EntityResolverWrapper(entityResolver2);
                this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/entity-resolver", obj);
            } else if (xMLEntityResolver instanceof EntityResolver2Wrapper) {
                ((EntityResolver2Wrapper) xMLEntityResolver).setEntityResolver((EntityResolver2) entityResolver2);
            } else {
                new EntityResolver2Wrapper((EntityResolver2) entityResolver2);
                this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/entity-resolver", obj2);
            }
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
        }
    }

    public void setErrorHandler(ErrorHandler errorHandler) {
        Object obj;
        ErrorHandler errorHandler2 = errorHandler;
        try {
            XMLErrorHandler xMLErrorHandler = (XMLErrorHandler) this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/error-handler");
            if (xMLErrorHandler instanceof ErrorHandlerWrapper) {
                ((ErrorHandlerWrapper) xMLErrorHandler).setErrorHandler(errorHandler2);
                return;
            }
            new ErrorHandlerWrapper(errorHandler2);
            this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/error-handler", obj);
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
        }
    }

    public void setFeature(String str, boolean z) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        String str2 = str;
        boolean z2 = z;
        try {
            if (!str2.equals(USE_ENTITY_RESOLVER2)) {
                this.fConfiguration.setFeature(str2, z2);
            } else if (z2 != this.fUseEntityResolver2) {
                this.fUseEntityResolver2 = z2;
                setEntityResolver(getEntityResolver());
            }
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
            String identifier = xMLConfigurationException.getIdentifier();
            if (xMLConfigurationException.getType() == 0) {
                Throwable th3 = th2;
                new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-not-recognized", new Object[]{identifier}));
                throw th3;
            }
            Throwable th4 = th;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "feature-not-supported", new Object[]{identifier}));
            throw th4;
        }
    }

    public void setProperty(String str, Object obj) throws SAXNotRecognizedException, SAXNotSupportedException {
        Throwable th;
        Throwable th2;
        try {
            this.fConfiguration.setProperty(str, obj);
        } catch (XMLConfigurationException e) {
            XMLConfigurationException xMLConfigurationException = e;
            String identifier = xMLConfigurationException.getIdentifier();
            if (xMLConfigurationException.getType() == 0) {
                Throwable th3 = th2;
                new SAXNotRecognizedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-recognized", new Object[]{identifier}));
                throw th3;
            }
            Throwable th4 = th;
            new SAXNotSupportedException(SAXMessageFormatter.formatMessage(this.fConfiguration.getLocale(), "property-not-supported", new Object[]{identifier}));
            throw th4;
        }
    }
}
