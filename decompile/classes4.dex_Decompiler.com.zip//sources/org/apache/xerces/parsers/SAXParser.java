package org.apache.xerces.parsers;

import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLParserConfiguration;

public class SAXParser extends AbstractSAXParser {
    protected static final String NOTIFY_BUILTIN_REFS = "http://apache.org/xml/features/scanner/notify-builtin-refs";
    private static final String[] RECOGNIZED_FEATURES = {NOTIFY_BUILTIN_REFS};
    private static final String[] RECOGNIZED_PROPERTIES;
    protected static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    protected static final String XMLGRAMMAR_POOL = "http://apache.org/xml/properties/internal/grammar-pool";

    static {
        String[] strArr = new String[2];
        strArr[0] = SYMBOL_TABLE;
        String[] strArr2 = strArr;
        strArr2[1] = XMLGRAMMAR_POOL;
        RECOGNIZED_PROPERTIES = strArr2;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SAXParser() {
        this((SymbolTable) null, (XMLGrammarPool) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SAXParser(SymbolTable symbolTable) {
        this(symbolTable, (XMLGrammarPool) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public SAXParser(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool) {
        super((XMLParserConfiguration) ObjectFactory.createObject("org.apache.xerces.xni.parser.XMLParserConfiguration", "org.apache.xerces.parsers.XIncludeAwareParserConfiguration"));
        SymbolTable symbolTable2 = symbolTable;
        XMLGrammarPool xMLGrammarPool2 = xMLGrammarPool;
        this.fConfiguration.addRecognizedFeatures(RECOGNIZED_FEATURES);
        this.fConfiguration.setFeature(NOTIFY_BUILTIN_REFS, true);
        this.fConfiguration.addRecognizedProperties(RECOGNIZED_PROPERTIES);
        if (symbolTable2 != null) {
            this.fConfiguration.setProperty(SYMBOL_TABLE, symbolTable2);
        }
        if (xMLGrammarPool2 != null) {
            this.fConfiguration.setProperty(XMLGRAMMAR_POOL, xMLGrammarPool2);
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public SAXParser(XMLParserConfiguration xMLParserConfiguration) {
        super(xMLParserConfiguration);
    }
}
