package org.apache.xerces.parsers;

import java.io.IOException;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLParserConfiguration;

public abstract class XMLParser {
    protected static final String ENTITY_RESOLVER = "http://apache.org/xml/properties/internal/entity-resolver";
    protected static final String ERROR_HANDLER = "http://apache.org/xml/properties/internal/error-handler";
    private static final String[] RECOGNIZED_PROPERTIES;
    protected final XMLParserConfiguration fConfiguration;

    static {
        String[] strArr = new String[2];
        strArr[0] = ENTITY_RESOLVER;
        String[] strArr2 = strArr;
        strArr2[1] = ERROR_HANDLER;
        RECOGNIZED_PROPERTIES = strArr2;
    }

    protected XMLParser(XMLParserConfiguration xMLParserConfiguration) {
        this.fConfiguration = xMLParserConfiguration;
        this.fConfiguration.addRecognizedProperties(RECOGNIZED_PROPERTIES);
    }

    public void parse(XMLInputSource xMLInputSource) throws XNIException, IOException {
        reset();
        this.fConfiguration.parse(xMLInputSource);
    }

    /* access modifiers changed from: protected */
    public void reset() throws XNIException {
    }
}
