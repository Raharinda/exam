package org.apache.xerces.parsers;

import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLComponentManager;

public class SoftReferenceSymbolTableConfiguration extends XIncludeAwareParserConfiguration {
    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public SoftReferenceSymbolTableConfiguration() {
        /*
            r6 = this;
            r0 = r6
            r1 = r0
            org.apache.xerces.util.SoftReferenceSymbolTable r2 = new org.apache.xerces.util.SoftReferenceSymbolTable
            r5 = r2
            r2 = r5
            r3 = r5
            r3.<init>()
            r3 = 0
            r4 = 0
            r1.<init>(r2, r3, r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.SoftReferenceSymbolTableConfiguration.<init>():void");
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SoftReferenceSymbolTableConfiguration(SymbolTable symbolTable) {
        this(symbolTable, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SoftReferenceSymbolTableConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool) {
        this(symbolTable, xMLGrammarPool, (XMLComponentManager) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public SoftReferenceSymbolTableConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool, XMLComponentManager xMLComponentManager) {
        super(symbolTable, xMLGrammarPool, xMLComponentManager);
    }
}
