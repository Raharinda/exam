package org.apache.xerces.parsers;

public interface XML11Configurable {
}
