package org.apache.xerces.parsers;

import org.apache.xerces.util.NamespaceSupport;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xinclude.XIncludeHandler;
import org.apache.xerces.xinclude.XIncludeNamespaceSupport;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLDocumentSource;

public class XIncludeAwareParserConfiguration extends XML11Configuration {
    protected static final String ALLOW_UE_AND_NOTATION_EVENTS = "http://xml.org/sax/features/allow-dtd-events-after-endDTD";
    protected static final String NAMESPACE_CONTEXT = "http://apache.org/xml/properties/internal/namespace-context";
    protected static final String XINCLUDE_FEATURE = "http://apache.org/xml/features/xinclude";
    protected static final String XINCLUDE_FIXUP_BASE_URIS = "http://apache.org/xml/features/xinclude/fixup-base-uris";
    protected static final String XINCLUDE_FIXUP_LANGUAGE = "http://apache.org/xml/features/xinclude/fixup-language";
    protected static final String XINCLUDE_HANDLER = "http://apache.org/xml/properties/internal/xinclude-handler";
    protected NamespaceContext fCurrentNSContext;
    protected NamespaceSupport fNonXIncludeNSContext;
    protected boolean fXIncludeEnabled;
    protected XIncludeHandler fXIncludeHandler;
    protected XIncludeNamespaceSupport fXIncludeNSContext;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XIncludeAwareParserConfiguration() {
        this((SymbolTable) null, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XIncludeAwareParserConfiguration(SymbolTable symbolTable) {
        this(symbolTable, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XIncludeAwareParserConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool) {
        this(symbolTable, xMLGrammarPool, (XMLComponentManager) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public XIncludeAwareParserConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool, XMLComponentManager xMLComponentManager) {
        super(symbolTable, xMLGrammarPool, xMLComponentManager);
        NamespaceSupport namespaceSupport;
        this.fXIncludeEnabled = false;
        String[] strArr = new String[3];
        strArr[0] = ALLOW_UE_AND_NOTATION_EVENTS;
        String[] strArr2 = strArr;
        strArr2[1] = XINCLUDE_FIXUP_BASE_URIS;
        String[] strArr3 = strArr2;
        strArr3[2] = XINCLUDE_FIXUP_LANGUAGE;
        addRecognizedFeatures(strArr3);
        String[] strArr4 = new String[2];
        strArr4[0] = XINCLUDE_HANDLER;
        String[] strArr5 = strArr4;
        strArr5[1] = NAMESPACE_CONTEXT;
        addRecognizedProperties(strArr5);
        setFeature(ALLOW_UE_AND_NOTATION_EVENTS, true);
        setFeature(XINCLUDE_FIXUP_BASE_URIS, true);
        setFeature(XINCLUDE_FIXUP_LANGUAGE, true);
        new NamespaceSupport();
        this.fNonXIncludeNSContext = namespaceSupport;
        this.fCurrentNSContext = this.fNonXIncludeNSContext;
        setProperty(NAMESPACE_CONTEXT, this.fNonXIncludeNSContext);
    }

    /* access modifiers changed from: protected */
    public void configurePipeline() {
        XMLDocumentSource xMLDocumentSource;
        XIncludeNamespaceSupport xIncludeNamespaceSupport;
        XIncludeHandler xIncludeHandler;
        super.configurePipeline();
        if (this.fXIncludeEnabled) {
            if (this.fXIncludeHandler == null) {
                new XIncludeHandler();
                this.fXIncludeHandler = xIncludeHandler;
                setProperty(XINCLUDE_HANDLER, this.fXIncludeHandler);
                addCommonComponent(this.fXIncludeHandler);
                this.fXIncludeHandler.reset(this);
            }
            if (this.fCurrentNSContext != this.fXIncludeNSContext) {
                if (this.fXIncludeNSContext == null) {
                    new XIncludeNamespaceSupport();
                    this.fXIncludeNSContext = xIncludeNamespaceSupport;
                }
                this.fCurrentNSContext = this.fXIncludeNSContext;
                setProperty(NAMESPACE_CONTEXT, this.fXIncludeNSContext);
            }
            this.fDTDScanner.setDTDHandler(this.fDTDProcessor);
            this.fDTDProcessor.setDTDSource(this.fDTDScanner);
            this.fDTDProcessor.setDTDHandler(this.fXIncludeHandler);
            this.fXIncludeHandler.setDTDSource(this.fDTDProcessor);
            this.fXIncludeHandler.setDTDHandler(this.fDTDHandler);
            if (this.fDTDHandler != null) {
                this.fDTDHandler.setDTDSource(this.fXIncludeHandler);
            }
            if (this.fFeatures.get("http://apache.org/xml/features/validation/schema") == Boolean.TRUE) {
                xMLDocumentSource = this.fSchemaValidator.getDocumentSource();
            } else {
                xMLDocumentSource = this.fLastComponent;
                this.fLastComponent = this.fXIncludeHandler;
            }
            XMLDocumentHandler documentHandler = xMLDocumentSource.getDocumentHandler();
            xMLDocumentSource.setDocumentHandler(this.fXIncludeHandler);
            this.fXIncludeHandler.setDocumentSource(xMLDocumentSource);
            if (documentHandler != null) {
                this.fXIncludeHandler.setDocumentHandler(documentHandler);
                documentHandler.setDocumentSource(this.fXIncludeHandler);
            }
        } else if (this.fCurrentNSContext != this.fNonXIncludeNSContext) {
            this.fCurrentNSContext = this.fNonXIncludeNSContext;
            setProperty(NAMESPACE_CONTEXT, this.fNonXIncludeNSContext);
        }
    }

    /* access modifiers changed from: protected */
    public void configureXML11Pipeline() {
        XMLDocumentSource xMLDocumentSource;
        XIncludeNamespaceSupport xIncludeNamespaceSupport;
        XIncludeHandler xIncludeHandler;
        super.configureXML11Pipeline();
        if (this.fXIncludeEnabled) {
            if (this.fXIncludeHandler == null) {
                new XIncludeHandler();
                this.fXIncludeHandler = xIncludeHandler;
                setProperty(XINCLUDE_HANDLER, this.fXIncludeHandler);
                addCommonComponent(this.fXIncludeHandler);
                this.fXIncludeHandler.reset(this);
            }
            if (this.fCurrentNSContext != this.fXIncludeNSContext) {
                if (this.fXIncludeNSContext == null) {
                    new XIncludeNamespaceSupport();
                    this.fXIncludeNSContext = xIncludeNamespaceSupport;
                }
                this.fCurrentNSContext = this.fXIncludeNSContext;
                setProperty(NAMESPACE_CONTEXT, this.fXIncludeNSContext);
            }
            this.fXML11DTDScanner.setDTDHandler(this.fXML11DTDProcessor);
            this.fXML11DTDProcessor.setDTDSource(this.fXML11DTDScanner);
            this.fXML11DTDProcessor.setDTDHandler(this.fXIncludeHandler);
            this.fXIncludeHandler.setDTDSource(this.fXML11DTDProcessor);
            this.fXIncludeHandler.setDTDHandler(this.fDTDHandler);
            if (this.fDTDHandler != null) {
                this.fDTDHandler.setDTDSource(this.fXIncludeHandler);
            }
            if (this.fFeatures.get("http://apache.org/xml/features/validation/schema") == Boolean.TRUE) {
                xMLDocumentSource = this.fSchemaValidator.getDocumentSource();
            } else {
                xMLDocumentSource = this.fLastComponent;
                this.fLastComponent = this.fXIncludeHandler;
            }
            XMLDocumentHandler documentHandler = xMLDocumentSource.getDocumentHandler();
            xMLDocumentSource.setDocumentHandler(this.fXIncludeHandler);
            this.fXIncludeHandler.setDocumentSource(xMLDocumentSource);
            if (documentHandler != null) {
                this.fXIncludeHandler.setDocumentHandler(documentHandler);
                documentHandler.setDocumentSource(this.fXIncludeHandler);
            }
        } else if (this.fCurrentNSContext != this.fNonXIncludeNSContext) {
            this.fCurrentNSContext = this.fNonXIncludeNSContext;
            setProperty(NAMESPACE_CONTEXT, this.fNonXIncludeNSContext);
        }
    }

    public boolean getFeature(String str) throws XMLConfigurationException {
        String str2 = str;
        return str2.equals("http://apache.org/xml/features/internal/parser-settings") ? this.fConfigUpdated : str2.equals(XINCLUDE_FEATURE) ? this.fXIncludeEnabled : super.getFeature0(str2);
    }

    public void setFeature(String str, boolean z) throws XMLConfigurationException {
        String str2 = str;
        boolean z2 = z;
        if (str2.equals(XINCLUDE_FEATURE)) {
            this.fXIncludeEnabled = z2;
            this.fConfigUpdated = true;
            return;
        }
        super.setFeature(str2, z2);
    }
}
