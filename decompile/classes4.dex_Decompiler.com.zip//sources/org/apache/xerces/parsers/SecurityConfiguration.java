package org.apache.xerces.parsers;

import org.apache.xerces.util.SecurityManager;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLComponentManager;

public class SecurityConfiguration extends XIncludeAwareParserConfiguration {
    protected static final String SECURITY_MANAGER_PROPERTY = "http://apache.org/xml/properties/security-manager";

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SecurityConfiguration() {
        this((SymbolTable) null, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SecurityConfiguration(SymbolTable symbolTable) {
        this(symbolTable, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SecurityConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool) {
        this(symbolTable, xMLGrammarPool, (XMLComponentManager) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public SecurityConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool, XMLComponentManager xMLComponentManager) {
        super(symbolTable, xMLGrammarPool, xMLComponentManager);
        Object obj;
        new SecurityManager();
        setProperty(SECURITY_MANAGER_PROPERTY, obj);
    }
}
