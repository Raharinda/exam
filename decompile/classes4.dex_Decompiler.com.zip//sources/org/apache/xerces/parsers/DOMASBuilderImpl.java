package org.apache.xerces.parsers;

import java.util.Vector;
import org.apache.xerces.dom.ASModelImpl;
import org.apache.xerces.dom3.as.ASModel;
import org.apache.xerces.dom3.as.DOMASBuilder;
import org.apache.xerces.dom3.as.DOMASException;
import org.apache.xerces.impl.xs.SchemaGrammar;
import org.apache.xerces.impl.xs.XSGrammarBucket;
import org.apache.xerces.util.XMLGrammarPoolImpl;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.Grammar;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLParserConfiguration;
import org.w3c.dom.ls.LSInput;

public class DOMASBuilderImpl extends DOMParserImpl implements DOMASBuilder {
    protected static final String ENTITY_MANAGER = "http://apache.org/xml/properties/internal/entity-manager";
    protected static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
    protected static final String SCHEMA_FULL_CHECKING = "http://apache.org/xml/features/validation/schema-full-checking";
    protected static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    protected ASModelImpl fAbstractSchema;
    protected XSGrammarBucket fGrammarBucket;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public DOMASBuilderImpl() {
        /*
            r5 = this;
            r0 = r5
            r1 = r0
            org.apache.xerces.parsers.XMLGrammarCachingConfiguration r2 = new org.apache.xerces.parsers.XMLGrammarCachingConfiguration
            r4 = r2
            r2 = r4
            r3 = r4
            r3.<init>()
            r1.<init>((org.apache.xerces.xni.parser.XMLParserConfiguration) r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.DOMASBuilderImpl.<init>():void");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DOMASBuilderImpl(XMLGrammarCachingConfiguration xMLGrammarCachingConfiguration) {
        super((XMLParserConfiguration) xMLGrammarCachingConfiguration);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public DOMASBuilderImpl(org.apache.xerces.util.SymbolTable r8) {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r2 = r0
            org.apache.xerces.parsers.XMLGrammarCachingConfiguration r3 = new org.apache.xerces.parsers.XMLGrammarCachingConfiguration
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r1
            r4.<init>(r5)
            r2.<init>((org.apache.xerces.xni.parser.XMLParserConfiguration) r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.DOMASBuilderImpl.<init>(org.apache.xerces.util.SymbolTable):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public DOMASBuilderImpl(org.apache.xerces.util.SymbolTable r10, org.apache.xerces.xni.grammars.XMLGrammarPool r11) {
        /*
            r9 = this;
            r0 = r9
            r1 = r10
            r2 = r11
            r3 = r0
            org.apache.xerces.parsers.XMLGrammarCachingConfiguration r4 = new org.apache.xerces.parsers.XMLGrammarCachingConfiguration
            r8 = r4
            r4 = r8
            r5 = r8
            r6 = r1
            r7 = r2
            r5.<init>(r6, r7)
            r3.<init>((org.apache.xerces.xni.parser.XMLParserConfiguration) r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.DOMASBuilderImpl.<init>(org.apache.xerces.util.SymbolTable, org.apache.xerces.xni.grammars.XMLGrammarPool):void");
    }

    private void addGrammars(ASModelImpl aSModelImpl, XSGrammarBucket xSGrammarBucket) {
        ASModelImpl aSModelImpl2;
        ASModelImpl aSModelImpl3 = aSModelImpl;
        SchemaGrammar[] grammars = xSGrammarBucket.getGrammars();
        for (int i = 0; i < grammars.length; i++) {
            new ASModelImpl();
            ASModelImpl aSModelImpl4 = aSModelImpl2;
            aSModelImpl4.setGrammar(grammars[i]);
            aSModelImpl3.addASModel(aSModelImpl4);
        }
    }

    private void initGrammarBucket() {
        this.fGrammarBucket.reset();
        if (this.fAbstractSchema != null) {
            initGrammarBucketRecurse(this.fAbstractSchema);
        }
    }

    private void initGrammarBucketRecurse(ASModelImpl aSModelImpl) {
        ASModelImpl aSModelImpl2 = aSModelImpl;
        if (aSModelImpl2.getGrammar() != null) {
            this.fGrammarBucket.putGrammar(aSModelImpl2.getGrammar());
        }
        for (int i = 0; i < aSModelImpl2.getInternalASModels().size(); i++) {
            initGrammarBucketRecurse((ASModelImpl) aSModelImpl2.getInternalASModels().elementAt(i));
        }
    }

    private void initGrammarPool(ASModelImpl aSModelImpl, XMLGrammarPool xMLGrammarPool) {
        ASModelImpl aSModelImpl2 = aSModelImpl;
        XMLGrammarPool xMLGrammarPool2 = xMLGrammarPool;
        Grammar[] grammarArr = new Grammar[1];
        Grammar grammar = aSModelImpl2.getGrammar();
        Grammar grammar2 = grammar;
        grammarArr[0] = grammar;
        if (grammar2 != null) {
            xMLGrammarPool2.cacheGrammars(grammarArr[0].getGrammarDescription().getGrammarType(), grammarArr);
        }
        Vector internalASModels = aSModelImpl2.getInternalASModels();
        for (int i = 0; i < internalASModels.size(); i++) {
            initGrammarPool((ASModelImpl) internalASModels.elementAt(i), xMLGrammarPool2);
        }
    }

    public ASModel getAbstractSchema() {
        return this.fAbstractSchema;
    }

    /* access modifiers changed from: package-private */
    public ASModel parseASInputSource(XMLInputSource xMLInputSource) throws Exception {
        ASModelImpl aSModelImpl;
        XSGrammarBucket xSGrammarBucket;
        XMLInputSource xMLInputSource2 = xMLInputSource;
        if (this.fGrammarBucket == null) {
            new XSGrammarBucket();
            this.fGrammarBucket = xSGrammarBucket;
        }
        initGrammarBucket();
        XMLGrammarCachingConfiguration xMLGrammarCachingConfiguration = (XMLGrammarCachingConfiguration) this.fConfiguration;
        xMLGrammarCachingConfiguration.lockGrammarPool();
        SchemaGrammar parseXMLSchema = xMLGrammarCachingConfiguration.parseXMLSchema(xMLInputSource2);
        xMLGrammarCachingConfiguration.unlockGrammarPool();
        ASModelImpl aSModelImpl2 = null;
        if (parseXMLSchema != null) {
            new ASModelImpl();
            aSModelImpl2 = aSModelImpl;
            boolean putGrammar = this.fGrammarBucket.putGrammar(parseXMLSchema, true);
            addGrammars(aSModelImpl2, this.fGrammarBucket);
        }
        return aSModelImpl2;
    }

    public ASModel parseASInputSource(LSInput lSInput) throws DOMASException, Exception {
        try {
            return parseASInputSource(dom2xmlInputSource(lSInput));
        } catch (XNIException e) {
            throw e.getException();
        }
    }

    public ASModel parseASURI(String str) throws DOMASException, Exception {
        XMLInputSource xMLInputSource;
        new XMLInputSource((String) null, str, (String) null);
        return parseASInputSource(xMLInputSource);
    }

    public void setAbstractSchema(ASModel aSModel) {
        XMLGrammarPool xMLGrammarPool;
        this.fAbstractSchema = (ASModelImpl) aSModel;
        XMLGrammarPool xMLGrammarPool2 = (XMLGrammarPool) this.fConfiguration.getProperty("http://apache.org/xml/properties/internal/grammar-pool");
        if (xMLGrammarPool2 == null) {
            new XMLGrammarPoolImpl();
            xMLGrammarPool2 = xMLGrammarPool;
            this.fConfiguration.setProperty("http://apache.org/xml/properties/internal/grammar-pool", xMLGrammarPool2);
        }
        if (this.fAbstractSchema != null) {
            initGrammarPool(this.fAbstractSchema, xMLGrammarPool2);
        }
    }
}
