package org.apache.xerces.parsers;

import java.io.IOException;
import org.apache.xerces.impl.dtd.DTDGrammar;
import org.apache.xerces.impl.dtd.XMLDTDLoader;
import org.apache.xerces.impl.xs.SchemaGrammar;
import org.apache.xerces.impl.xs.XMLSchemaLoader;
import org.apache.xerces.impl.xs.XSMessageFormatter;
import org.apache.xerces.jaxp.JAXPConstants;
import org.apache.xerces.util.MessageFormatter;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.util.SynchronizedSymbolTable;
import org.apache.xerces.util.XMLGrammarPoolImpl;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.Grammar;
import org.apache.xerces.xni.grammars.XMLGrammarDescription;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLInputSource;

public class XMLGrammarCachingConfiguration extends XIncludeAwareParserConfiguration {
    public static final int BIG_PRIME = 2039;
    protected static final String SCHEMA_FULL_CHECKING = "http://apache.org/xml/features/validation/schema-full-checking";
    protected static final XMLGrammarPoolImpl fStaticGrammarPool;
    protected static final SynchronizedSymbolTable fStaticSymbolTable;
    protected XMLDTDLoader fDTDLoader;
    protected XMLSchemaLoader fSchemaLoader;

    static {
        SynchronizedSymbolTable synchronizedSymbolTable;
        XMLGrammarPoolImpl xMLGrammarPoolImpl;
        new SynchronizedSymbolTable((int) BIG_PRIME);
        fStaticSymbolTable = synchronizedSymbolTable;
        new XMLGrammarPoolImpl();
        fStaticGrammarPool = xMLGrammarPoolImpl;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XMLGrammarCachingConfiguration() {
        this(fStaticSymbolTable, fStaticGrammarPool, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XMLGrammarCachingConfiguration(SymbolTable symbolTable) {
        this(symbolTable, fStaticGrammarPool, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XMLGrammarCachingConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool) {
        this(symbolTable, xMLGrammarPool, (XMLComponentManager) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public XMLGrammarCachingConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool, XMLComponentManager xMLComponentManager) {
        super(symbolTable, xMLGrammarPool, xMLComponentManager);
        XMLSchemaLoader xMLSchemaLoader;
        XMLDTDLoader xMLDTDLoader;
        new XMLSchemaLoader(this.fSymbolTable);
        this.fSchemaLoader = xMLSchemaLoader;
        this.fSchemaLoader.setProperty("http://apache.org/xml/properties/internal/grammar-pool", this.fGrammarPool);
        new XMLDTDLoader(this.fSymbolTable, this.fGrammarPool);
        this.fDTDLoader = xMLDTDLoader;
    }

    /* access modifiers changed from: protected */
    public void checkFeature(String str) throws XMLConfigurationException {
        super.checkFeature(str);
    }

    /* access modifiers changed from: protected */
    public void checkProperty(String str) throws XMLConfigurationException {
        super.checkProperty(str);
    }

    public void clearGrammarPool() {
        this.fGrammarPool.clear();
    }

    public void lockGrammarPool() {
        this.fGrammarPool.lockPool();
    }

    /* access modifiers changed from: package-private */
    public DTDGrammar parseDTD(XMLInputSource xMLInputSource) throws IOException {
        XMLInputSource xMLInputSource2 = xMLInputSource;
        XMLEntityResolver entityResolver = getEntityResolver();
        if (entityResolver != null) {
            this.fDTDLoader.setEntityResolver(entityResolver);
        }
        this.fDTDLoader.setProperty("http://apache.org/xml/properties/internal/error-reporter", this.fErrorReporter);
        DTDGrammar dTDGrammar = (DTDGrammar) this.fDTDLoader.loadGrammar(xMLInputSource2);
        if (dTDGrammar != null) {
            this.fGrammarPool.cacheGrammars(XMLGrammarDescription.XML_DTD, new Grammar[]{dTDGrammar});
        }
        return dTDGrammar;
    }

    public Grammar parseGrammar(String str, String str2) throws XNIException, IOException {
        XMLInputSource xMLInputSource;
        new XMLInputSource((String) null, str2, (String) null);
        return parseGrammar(str, xMLInputSource);
    }

    public Grammar parseGrammar(String str, XMLInputSource xMLInputSource) throws XNIException, IOException {
        String str2 = str;
        XMLInputSource xMLInputSource2 = xMLInputSource;
        if (str2.equals("http://www.w3.org/2001/XMLSchema")) {
            return parseXMLSchema(xMLInputSource2);
        }
        if (str2.equals(XMLGrammarDescription.XML_DTD)) {
            return parseDTD(xMLInputSource2);
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public SchemaGrammar parseXMLSchema(XMLInputSource xMLInputSource) throws IOException {
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        MessageFormatter messageFormatter;
        XMLInputSource xMLInputSource2 = xMLInputSource;
        XMLEntityResolver entityResolver = getEntityResolver();
        if (entityResolver != null) {
            this.fSchemaLoader.setEntityResolver(entityResolver);
        }
        if (this.fErrorReporter.getMessageFormatter("http://www.w3.org/TR/xml-schema-1") == null) {
            new XSMessageFormatter();
            this.fErrorReporter.putMessageFormatter("http://www.w3.org/TR/xml-schema-1", messageFormatter);
        }
        this.fSchemaLoader.setProperty("http://apache.org/xml/properties/internal/error-reporter", this.fErrorReporter);
        String str = "http://apache.org/xml/properties/";
        new StringBuffer();
        String stringBuffer3 = stringBuffer.append(str).append("schema/external-schemaLocation").toString();
        this.fSchemaLoader.setProperty(stringBuffer3, getProperty(stringBuffer3));
        new StringBuffer();
        String stringBuffer4 = stringBuffer2.append(str).append("schema/external-noNamespaceSchemaLocation").toString();
        this.fSchemaLoader.setProperty(stringBuffer4, getProperty(stringBuffer4));
        String str2 = JAXPConstants.JAXP_SCHEMA_SOURCE;
        this.fSchemaLoader.setProperty(str2, getProperty(str2));
        this.fSchemaLoader.setFeature(SCHEMA_FULL_CHECKING, getFeature(SCHEMA_FULL_CHECKING));
        SchemaGrammar schemaGrammar = (SchemaGrammar) this.fSchemaLoader.loadGrammar(xMLInputSource2);
        if (schemaGrammar != null) {
            this.fGrammarPool.cacheGrammars("http://www.w3.org/2001/XMLSchema", new Grammar[]{schemaGrammar});
        }
        return schemaGrammar;
    }

    public void unlockGrammarPool() {
        this.fGrammarPool.unlockPool();
    }
}
