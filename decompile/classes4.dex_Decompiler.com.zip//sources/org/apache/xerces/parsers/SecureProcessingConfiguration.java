package org.apache.xerces.parsers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.FilterReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.Reader;
import java.net.URL;
import java.util.Properties;
import org.apache.xerces.dom.DOMMessageFormatter;
import org.apache.xerces.dom3.as.ASContentModel;
import org.apache.xerces.impl.XML11DTDScannerImpl;
import org.apache.xerces.impl.XMLEntityDescription;
import org.apache.xerces.impl.dtd.XML11DTDProcessor;
import org.apache.xerces.util.SecurityManager;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.XMLDTDHandler;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLDTDFilter;
import org.apache.xerces.xni.parser.XMLDTDSource;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLInputSource;

public final class SecureProcessingConfiguration extends XIncludeAwareParserConfiguration {
    private static final boolean DEBUG = isDebugEnabled();
    private static final int ENTITY_EXPANSION_LIMIT_DEFAULT_VALUE = 64000;
    private static final String ENTITY_EXPANSION_LIMIT_PROPERTY_NAME = "jdk.xml.entityExpansionLimit";
    private static final String ENTITY_RESOLVER_PROPERTY = "http://apache.org/xml/properties/internal/entity-resolver";
    private static final String EXTERNAL_GENERAL_ENTITIES = "http://xml.org/sax/features/external-general-entities";
    private static final String EXTERNAL_PARAMETER_ENTITIES = "http://xml.org/sax/features/external-parameter-entities";
    private static final String LOAD_EXTERNAL_DTD = "http://apache.org/xml/features/nonvalidating/load-external-dtd";
    private static final int MAX_GENERAL_ENTITY_SIZE_LIMIT_DEFAULT_VALUE = Integer.MAX_VALUE;
    private static final String MAX_GENERAL_ENTITY_SIZE_LIMIT_PROPERTY_NAME = "jdk.xml.maxGeneralEntitySizeLimit";
    private static final int MAX_OCCUR_LIMIT_DEFAULT_VALUE = 5000;
    private static final String MAX_OCCUR_LIMIT_PROPERTY_NAME = "jdk.xml.maxOccur";
    private static final int MAX_PARAMETER_ENTITY_SIZE_LIMIT_DEFAULT_VALUE = Integer.MAX_VALUE;
    private static final String MAX_PARAMETER_ENTITY_SIZE_LIMIT_PROPERTY_NAME = "jdk.xml.maxParameterEntitySizeLimit";
    private static final boolean RESOLVE_EXTERNAL_ENTITIES_DEFAULT_VALUE = true;
    private static final String RESOLVE_EXTERNAL_ENTITIES_PROPERTY_NAME = "jdk.xml.resolveExternalEntities";
    private static final int SECURITY_MANAGER_DEFAULT_ENTITY_EXPANSION_LIMIT = 100000;
    private static final int SECURITY_MANAGER_DEFAULT_MAX_OCCUR_NODE_LIMIT = 3000;
    private static final String SECURITY_MANAGER_PROPERTY = "http://apache.org/xml/properties/security-manager";
    private static final int TOTAL_ENTITY_SIZE_LIMIT_DEFAULT_VALUE = 50000000;
    private static final String TOTAL_ENTITY_SIZE_LIMIT_PROPERTY_NAME = "jdk.xml.totalEntitySizeLimit";
    static Class class$org$apache$xerces$parsers$SecureProcessingConfiguration;
    private static Properties jaxpProperties = null;
    private static long lastModified = -1;
    protected final int ENTITY_EXPANSION_LIMIT_SYSTEM_VALUE;
    protected final int MAX_GENERAL_ENTITY_SIZE_LIMIT_SYSTEM_VALUE;
    protected final int MAX_OCCUR_LIMIT_SYSTEM_VALUE;
    protected final int MAX_PARAMETER_ENTITY_SIZE_LIMIT_SYSTEM_VALUE;
    protected final boolean RESOLVE_EXTERNAL_ENTITIES_SYSTEM_VALUE;
    protected final int TOTAL_ENTITY_SIZE_LIMIT_SYSTEM_VALUE;
    private final ExternalEntityMonitor fExternalEntityMonitor;
    private InternalEntityMonitor fInternalEntityMonitor;
    private final boolean fJavaSecurityManagerEnabled;
    private boolean fLimitSpecified;
    private SecurityManager fSecurityManager;
    private int fTotalEntitySize;

    final class ExternalEntityMonitor implements XMLEntityResolver {
        private XMLEntityResolver fEntityResolver;
        private final SecureProcessingConfiguration this$0;

        final class InputStreamMonitor extends FilterInputStream {
            private final boolean isPE;
            private int size = 0;
            private final ExternalEntityMonitor this$1;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            protected InputStreamMonitor(ExternalEntityMonitor externalEntityMonitor, InputStream inputStream, boolean z) {
                super(inputStream);
                this.this$1 = externalEntityMonitor;
                this.isPE = z;
            }

            public int read() throws IOException {
                int read = super.read();
                if (read != -1) {
                    this.size++;
                    ExternalEntityMonitor.access$000(this.this$1).checkEntitySizeLimits(this.size, 1, this.isPE);
                }
                return read;
            }

            public int read(byte[] bArr, int i, int i2) throws IOException {
                int read = super.read(bArr, i, i2);
                if (read > 0) {
                    this.size += read;
                    ExternalEntityMonitor.access$000(this.this$1).checkEntitySizeLimits(this.size, read, this.isPE);
                }
                return read;
            }
        }

        final class ReaderMonitor extends FilterReader {
            private final boolean isPE;
            private int size = 0;
            private final ExternalEntityMonitor this$1;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            protected ReaderMonitor(ExternalEntityMonitor externalEntityMonitor, Reader reader, boolean z) {
                super(reader);
                this.this$1 = externalEntityMonitor;
                this.isPE = z;
            }

            public int read() throws IOException {
                int read = super.read();
                if (read != -1) {
                    this.size++;
                    ExternalEntityMonitor.access$000(this.this$1).checkEntitySizeLimits(this.size, 1, this.isPE);
                }
                return read;
            }

            public int read(char[] cArr, int i, int i2) throws IOException {
                int read = super.read(cArr, i, i2);
                if (read > 0) {
                    this.size += read;
                    ExternalEntityMonitor.access$000(this.this$1).checkEntitySizeLimits(this.size, read, this.isPE);
                }
                return read;
            }
        }

        ExternalEntityMonitor(SecureProcessingConfiguration secureProcessingConfiguration) {
            this.this$0 = secureProcessingConfiguration;
        }

        static SecureProcessingConfiguration access$000(ExternalEntityMonitor externalEntityMonitor) {
            return externalEntityMonitor.this$0;
        }

        public XMLEntityResolver getEntityResolver() {
            return this.fEntityResolver;
        }

        public XMLInputSource resolveEntity(XMLResourceIdentifier xMLResourceIdentifier) throws XNIException, IOException {
            URL url;
            InputStream inputStream;
            InputStream inputStream2;
            Reader reader;
            XMLInputSource xMLInputSource;
            XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
            XMLInputSource xMLInputSource2 = null;
            if (this.fEntityResolver != null) {
                xMLInputSource2 = this.fEntityResolver.resolveEntity(xMLResourceIdentifier2);
            }
            if (SecureProcessingConfiguration.access$100(this.this$0) != null && (xMLResourceIdentifier2 instanceof XMLEntityDescription)) {
                String entityName = ((XMLEntityDescription) xMLResourceIdentifier2).getEntityName();
                boolean z = (entityName == null || !entityName.startsWith("%")) ? false : SecureProcessingConfiguration.RESOLVE_EXTERNAL_ENTITIES_DEFAULT_VALUE;
                if (xMLInputSource2 == null) {
                    new XMLInputSource(xMLResourceIdentifier2.getPublicId(), xMLResourceIdentifier2.getExpandedSystemId(), xMLResourceIdentifier2.getBaseSystemId());
                    xMLInputSource2 = xMLInputSource;
                }
                Reader characterStream = xMLInputSource2.getCharacterStream();
                if (characterStream != null) {
                    new ReaderMonitor(this, characterStream, z);
                    xMLInputSource2.setCharacterStream(reader);
                } else {
                    InputStream byteStream = xMLInputSource2.getByteStream();
                    if (byteStream != null) {
                        new InputStreamMonitor(this, byteStream, z);
                        xMLInputSource2.setByteStream(inputStream2);
                    } else {
                        new URL(xMLResourceIdentifier2.getExpandedSystemId());
                        new InputStreamMonitor(this, url.openStream(), z);
                        xMLInputSource2.setByteStream(inputStream);
                    }
                }
            }
            return xMLInputSource2;
        }

        public void setEntityResolver(XMLEntityResolver xMLEntityResolver) {
            XMLEntityResolver xMLEntityResolver2 = xMLEntityResolver;
            this.fEntityResolver = xMLEntityResolver2;
        }
    }

    final class InternalEntityMonitor implements XMLDTDFilter {
        private XMLDTDHandler fDTDHandler;
        private XMLDTDSource fDTDSource;
        private final SecureProcessingConfiguration this$0;

        public InternalEntityMonitor(SecureProcessingConfiguration secureProcessingConfiguration) {
            this.this$0 = secureProcessingConfiguration;
        }

        public void attributeDecl(String str, String str2, String str3, String[] strArr, String str4, XMLString xMLString, XMLString xMLString2, Augmentations augmentations) throws XNIException {
            String str5 = str;
            String str6 = str2;
            String str7 = str3;
            String[] strArr2 = strArr;
            String str8 = str4;
            XMLString xMLString3 = xMLString;
            XMLString xMLString4 = xMLString2;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.attributeDecl(str5, str6, str7, strArr2, str8, xMLString3, xMLString4, augmentations2);
            }
        }

        public void comment(XMLString xMLString, Augmentations augmentations) throws XNIException {
            XMLString xMLString2 = xMLString;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.comment(xMLString2, augmentations2);
            }
        }

        public void elementDecl(String str, String str2, Augmentations augmentations) throws XNIException {
            String str3 = str;
            String str4 = str2;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.elementDecl(str3, str4, augmentations2);
            }
        }

        public void endAttlist(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.endAttlist(augmentations2);
            }
        }

        public void endConditional(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.endConditional(augmentations2);
            }
        }

        public void endDTD(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.endDTD(augmentations2);
            }
        }

        public void endExternalSubset(Augmentations augmentations) throws XNIException {
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.endExternalSubset(augmentations2);
            }
        }

        public void endParameterEntity(String str, Augmentations augmentations) throws XNIException {
            String str2 = str;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.endParameterEntity(str2, augmentations2);
            }
        }

        public void externalEntityDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
            String str2 = str;
            XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.externalEntityDecl(str2, xMLResourceIdentifier2, augmentations2);
            }
        }

        public XMLDTDHandler getDTDHandler() {
            return this.fDTDHandler;
        }

        public XMLDTDSource getDTDSource() {
            return this.fDTDSource;
        }

        public void ignoredCharacters(XMLString xMLString, Augmentations augmentations) throws XNIException {
            XMLString xMLString2 = xMLString;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.ignoredCharacters(xMLString2, augmentations2);
            }
        }

        public void internalEntityDecl(String str, XMLString xMLString, XMLString xMLString2, Augmentations augmentations) throws XNIException {
            String str2 = str;
            XMLString xMLString3 = xMLString;
            XMLString xMLString4 = xMLString2;
            Augmentations augmentations2 = augmentations;
            this.this$0.checkEntitySizeLimits(xMLString3.length, xMLString3.length, (str2 == null || !str2.startsWith("%")) ? false : SecureProcessingConfiguration.RESOLVE_EXTERNAL_ENTITIES_DEFAULT_VALUE);
            if (this.fDTDHandler != null) {
                this.fDTDHandler.internalEntityDecl(str2, xMLString3, xMLString4, augmentations2);
            }
        }

        public void notationDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
            String str2 = str;
            XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.notationDecl(str2, xMLResourceIdentifier2, augmentations2);
            }
        }

        public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
            String str2 = str;
            XMLString xMLString2 = xMLString;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.processingInstruction(str2, xMLString2, augmentations2);
            }
        }

        public void setDTDHandler(XMLDTDHandler xMLDTDHandler) {
            XMLDTDHandler xMLDTDHandler2 = xMLDTDHandler;
            this.fDTDHandler = xMLDTDHandler2;
        }

        public void setDTDSource(XMLDTDSource xMLDTDSource) {
            XMLDTDSource xMLDTDSource2 = xMLDTDSource;
            this.fDTDSource = xMLDTDSource2;
        }

        public void startAttlist(String str, Augmentations augmentations) throws XNIException {
            String str2 = str;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.startAttlist(str2, augmentations2);
            }
        }

        public void startConditional(short s, Augmentations augmentations) throws XNIException {
            short s2 = s;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.startConditional(s2, augmentations2);
            }
        }

        public void startDTD(XMLLocator xMLLocator, Augmentations augmentations) throws XNIException {
            XMLLocator xMLLocator2 = xMLLocator;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.startDTD(xMLLocator2, augmentations2);
            }
        }

        public void startExternalSubset(XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
            XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.startExternalSubset(xMLResourceIdentifier2, augmentations2);
            }
        }

        public void startParameterEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
            String str3 = str;
            XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
            String str4 = str2;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.startParameterEntity(str3, xMLResourceIdentifier2, str4, augmentations2);
            }
        }

        public void textDecl(String str, String str2, Augmentations augmentations) throws XNIException {
            String str3 = str;
            String str4 = str2;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.textDecl(str3, str4, augmentations2);
            }
        }

        public void unparsedEntityDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
            String str3 = str;
            XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
            String str4 = str2;
            Augmentations augmentations2 = augmentations;
            if (this.fDTDHandler != null) {
                this.fDTDHandler.unparsedEntityDecl(str3, xMLResourceIdentifier2, str4, augmentations2);
            }
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SecureProcessingConfiguration() {
        this((SymbolTable) null, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SecureProcessingConfiguration(SymbolTable symbolTable) {
        this(symbolTable, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SecureProcessingConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool) {
        this(symbolTable, xMLGrammarPool, (XMLComponentManager) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public SecureProcessingConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool, XMLComponentManager xMLComponentManager) {
        super(symbolTable, xMLGrammarPool, xMLComponentManager);
        ExternalEntityMonitor externalEntityMonitor;
        SecurityManager securityManager;
        this.fTotalEntitySize = 0;
        this.fJavaSecurityManagerEnabled = System.getSecurityManager() != null ? RESOLVE_EXTERNAL_ENTITIES_DEFAULT_VALUE : false;
        this.ENTITY_EXPANSION_LIMIT_SYSTEM_VALUE = getPropertyValue(ENTITY_EXPANSION_LIMIT_PROPERTY_NAME, (int) ENTITY_EXPANSION_LIMIT_DEFAULT_VALUE);
        this.MAX_OCCUR_LIMIT_SYSTEM_VALUE = getPropertyValue(MAX_OCCUR_LIMIT_PROPERTY_NAME, (int) MAX_OCCUR_LIMIT_DEFAULT_VALUE);
        this.TOTAL_ENTITY_SIZE_LIMIT_SYSTEM_VALUE = getPropertyValue(TOTAL_ENTITY_SIZE_LIMIT_PROPERTY_NAME, (int) TOTAL_ENTITY_SIZE_LIMIT_DEFAULT_VALUE);
        this.MAX_GENERAL_ENTITY_SIZE_LIMIT_SYSTEM_VALUE = getPropertyValue(MAX_GENERAL_ENTITY_SIZE_LIMIT_PROPERTY_NAME, (int) ASContentModel.AS_UNBOUNDED);
        this.MAX_PARAMETER_ENTITY_SIZE_LIMIT_SYSTEM_VALUE = getPropertyValue(MAX_PARAMETER_ENTITY_SIZE_LIMIT_PROPERTY_NAME, (int) ASContentModel.AS_UNBOUNDED);
        this.RESOLVE_EXTERNAL_ENTITIES_SYSTEM_VALUE = getPropertyValue(RESOLVE_EXTERNAL_ENTITIES_PROPERTY_NAME, (boolean) RESOLVE_EXTERNAL_ENTITIES_DEFAULT_VALUE);
        if (this.fJavaSecurityManagerEnabled || this.fLimitSpecified) {
            if (!this.RESOLVE_EXTERNAL_ENTITIES_SYSTEM_VALUE) {
                super.setFeature(EXTERNAL_GENERAL_ENTITIES, false);
                super.setFeature(EXTERNAL_PARAMETER_ENTITIES, false);
                super.setFeature(LOAD_EXTERNAL_DTD, false);
            }
            new SecurityManager();
            this.fSecurityManager = securityManager;
            this.fSecurityManager.setEntityExpansionLimit(this.ENTITY_EXPANSION_LIMIT_SYSTEM_VALUE);
            this.fSecurityManager.setMaxOccurNodeLimit(this.MAX_OCCUR_LIMIT_SYSTEM_VALUE);
            super.setProperty(SECURITY_MANAGER_PROPERTY, this.fSecurityManager);
        }
        new ExternalEntityMonitor(this);
        this.fExternalEntityMonitor = externalEntityMonitor;
        super.setProperty(ENTITY_RESOLVER_PROPERTY, this.fExternalEntityMonitor);
    }

    static SecurityManager access$100(SecureProcessingConfiguration secureProcessingConfiguration) {
        return secureProcessingConfiguration.fSecurityManager;
    }

    static Class class$(String str) {
        Throwable th;
        try {
            return Class.forName(str);
        } catch (ClassNotFoundException e) {
            ClassNotFoundException classNotFoundException = e;
            Throwable th2 = th;
            new NoClassDefFoundError(classNotFoundException.getMessage());
            throw th2;
        }
    }

    private void configurePipelineCommon(boolean z) {
        XML11DTDScannerImpl xML11DTDScannerImpl;
        XML11DTDProcessor xML11DTDProcessor;
        InternalEntityMonitor internalEntityMonitor;
        boolean z2 = z;
        if (this.fSecurityManager != null) {
            this.fTotalEntitySize = 0;
            if (this.fInternalEntityMonitor == null) {
                new InternalEntityMonitor(this);
                this.fInternalEntityMonitor = internalEntityMonitor;
            }
            if (z2) {
                xML11DTDScannerImpl = this.fDTDScanner;
                xML11DTDProcessor = this.fDTDProcessor;
            } else {
                xML11DTDScannerImpl = this.fXML11DTDScanner;
                xML11DTDProcessor = this.fXML11DTDProcessor;
            }
            xML11DTDScannerImpl.setDTDHandler(this.fInternalEntityMonitor);
            this.fInternalEntityMonitor.setDTDSource(xML11DTDScannerImpl);
            this.fInternalEntityMonitor.setDTDHandler(xML11DTDProcessor);
            xML11DTDProcessor.setDTDSource(this.fInternalEntityMonitor);
        }
    }

    private static void debugPrintln(String str) {
        StringBuffer stringBuffer;
        String str2 = str;
        if (DEBUG) {
            PrintStream printStream = System.err;
            new StringBuffer();
            printStream.println(stringBuffer.append("XERCES: ").append(str2).toString());
        }
    }

    /* JADX INFO: finally extract failed */
    private int getPropertyValue(String str, int i) {
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        Class cls;
        String property;
        StringBuffer stringBuffer3;
        Properties properties;
        StringBuffer stringBuffer4;
        File file;
        StringBuffer stringBuffer5;
        String str2 = str;
        int i2 = i;
        try {
            String systemProperty = SecuritySupport.getSystemProperty(str2);
            if (systemProperty != null && systemProperty.length() > 0) {
                if (DEBUG) {
                    new StringBuffer();
                    debugPrintln(stringBuffer5.append("found system property \"").append(str2).append("\", value=").append(systemProperty).toString());
                }
                int parseInt = Integer.parseInt(systemProperty);
                this.fLimitSpecified = RESOLVE_EXTERNAL_ENTITIES_DEFAULT_VALUE;
                return parseInt > 0 ? parseInt : ASContentModel.AS_UNBOUNDED;
            }
        } catch (VirtualMachineError e) {
            throw e;
        } catch (ThreadDeath e2) {
            throw e2;
        } catch (Throwable th) {
            Throwable th2 = th;
            if (DEBUG) {
                new StringBuffer();
                debugPrintln(stringBuffer.append(th2.getClass().getName()).append(": ").append(th2.getMessage()).toString());
                th2.printStackTrace();
            }
        }
        boolean z = false;
        File file2 = null;
        try {
            String systemProperty2 = SecuritySupport.getSystemProperty("java.home");
            new StringBuffer();
            new File(stringBuffer4.append(systemProperty2).append(File.separator).append("lib").append(File.separator).append("jaxp.properties").toString());
            file2 = file;
            z = SecuritySupport.getFileExists(file2);
        } catch (SecurityException e3) {
            SecurityException securityException = e3;
            lastModified = -1;
            jaxpProperties = null;
        }
        try {
            if (class$org$apache$xerces$parsers$SecureProcessingConfiguration == null) {
                Class class$ = class$("org.apache.xerces.parsers.SecureProcessingConfiguration");
                cls = class$;
                class$org$apache$xerces$parsers$SecureProcessingConfiguration = class$;
            } else {
                cls = class$org$apache$xerces$parsers$SecureProcessingConfiguration;
            }
            Class cls2 = cls;
            synchronized (cls2) {
                boolean z2 = false;
                FileInputStream fileInputStream = null;
                try {
                    if (lastModified >= 0) {
                        if (z) {
                            long j = lastModified;
                            long lastModified2 = SecuritySupport.getLastModified(file2);
                            lastModified = lastModified2;
                            if (j < lastModified2) {
                                z2 = true;
                            }
                        }
                        if (!z) {
                            lastModified = -1;
                            jaxpProperties = null;
                        }
                    } else if (z) {
                        z2 = true;
                        lastModified = SecuritySupport.getLastModified(file2);
                    }
                    if (z2) {
                        new Properties();
                        jaxpProperties = properties;
                        fileInputStream = SecuritySupport.getFileInputStream(file2);
                        jaxpProperties.load(fileInputStream);
                    }
                    if (fileInputStream != null) {
                        try {
                            fileInputStream.close();
                        } catch (IOException e4) {
                            IOException iOException = e4;
                        }
                    }
                } catch (Exception e5) {
                    Exception exc = e5;
                    lastModified = -1;
                    jaxpProperties = null;
                    if (0 != 0) {
                        FileInputStream fileInputStream2 = null;
                        try {
                            fileInputStream2.close();
                        } catch (IOException e6) {
                            IOException iOException2 = e6;
                        }
                    }
                } catch (Throwable th3) {
                    Throwable th4 = th3;
                    if (0 != 0) {
                        FileInputStream fileInputStream3 = null;
                        try {
                            fileInputStream3.close();
                        } catch (IOException e7) {
                            IOException iOException3 = e7;
                        }
                    }
                    throw th4;
                }
                try {
                } catch (Throwable th5) {
                    Throwable th6 = th5;
                    Class cls3 = cls2;
                    throw th6;
                }
            }
            if (!(jaxpProperties == null || (property = jaxpProperties.getProperty(str2)) == null || property.length() <= 0)) {
                if (DEBUG) {
                    new StringBuffer();
                    debugPrintln(stringBuffer3.append("found \"").append(str2).append("\" in jaxp.properties, value=").append(property).toString());
                }
                int parseInt2 = Integer.parseInt(property);
                this.fLimitSpecified = RESOLVE_EXTERNAL_ENTITIES_DEFAULT_VALUE;
                return parseInt2 > 0 ? parseInt2 : ASContentModel.AS_UNBOUNDED;
            }
        } catch (VirtualMachineError e8) {
            throw e8;
        } catch (ThreadDeath e9) {
            throw e9;
        } catch (Throwable th7) {
            Throwable th8 = th7;
            if (DEBUG) {
                new StringBuffer();
                debugPrintln(stringBuffer2.append(th8.getClass().getName()).append(": ").append(th8.getMessage()).toString());
                th8.printStackTrace();
            }
        }
        return i2;
    }

    /* JADX INFO: finally extract failed */
    private boolean getPropertyValue(String str, boolean z) {
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        Class cls;
        String property;
        StringBuffer stringBuffer3;
        Properties properties;
        StringBuffer stringBuffer4;
        File file;
        StringBuffer stringBuffer5;
        String str2 = str;
        boolean z2 = z;
        try {
            String systemProperty = SecuritySupport.getSystemProperty(str2);
            if (systemProperty != null && systemProperty.length() > 0) {
                if (DEBUG) {
                    new StringBuffer();
                    debugPrintln(stringBuffer5.append("found system property \"").append(str2).append("\", value=").append(systemProperty).toString());
                }
                boolean booleanValue = Boolean.valueOf(systemProperty).booleanValue();
                this.fLimitSpecified = RESOLVE_EXTERNAL_ENTITIES_DEFAULT_VALUE;
                return booleanValue;
            }
        } catch (VirtualMachineError e) {
            throw e;
        } catch (ThreadDeath e2) {
            throw e2;
        } catch (Throwable th) {
            Throwable th2 = th;
            if (DEBUG) {
                new StringBuffer();
                debugPrintln(stringBuffer.append(th2.getClass().getName()).append(": ").append(th2.getMessage()).toString());
                th2.printStackTrace();
            }
        }
        boolean z3 = false;
        File file2 = null;
        try {
            String systemProperty2 = SecuritySupport.getSystemProperty("java.home");
            new StringBuffer();
            new File(stringBuffer4.append(systemProperty2).append(File.separator).append("lib").append(File.separator).append("jaxp.properties").toString());
            file2 = file;
            z3 = SecuritySupport.getFileExists(file2);
            try {
                if (class$org$apache$xerces$parsers$SecureProcessingConfiguration == null) {
                    Class class$ = class$("org.apache.xerces.parsers.SecureProcessingConfiguration");
                    cls = class$;
                    class$org$apache$xerces$parsers$SecureProcessingConfiguration = class$;
                } else {
                    cls = class$org$apache$xerces$parsers$SecureProcessingConfiguration;
                }
                Class cls2 = cls;
                synchronized (cls2) {
                    boolean z4 = false;
                    FileInputStream fileInputStream = null;
                    try {
                        if (lastModified >= 0) {
                            if (z3) {
                                long j = lastModified;
                                long lastModified2 = SecuritySupport.getLastModified(file2);
                                lastModified = lastModified2;
                                if (j < lastModified2) {
                                    z4 = true;
                                }
                            }
                            if (!z3) {
                                lastModified = -1;
                                jaxpProperties = null;
                            }
                        } else if (z3) {
                            z4 = true;
                            lastModified = SecuritySupport.getLastModified(file2);
                        }
                        if (z4) {
                            new Properties();
                            jaxpProperties = properties;
                            fileInputStream = SecuritySupport.getFileInputStream(file2);
                            jaxpProperties.load(fileInputStream);
                        }
                        if (fileInputStream != null) {
                            try {
                                fileInputStream.close();
                            } catch (IOException e3) {
                                IOException iOException = e3;
                            }
                        }
                    } catch (Exception e4) {
                        Exception exc = e4;
                        lastModified = -1;
                        jaxpProperties = null;
                        if (0 != 0) {
                            FileInputStream fileInputStream2 = null;
                            try {
                                fileInputStream2.close();
                            } catch (IOException e5) {
                                IOException iOException2 = e5;
                            }
                        }
                    } catch (Throwable th3) {
                        Throwable th4 = th3;
                        if (0 != 0) {
                            FileInputStream fileInputStream3 = null;
                            try {
                                fileInputStream3.close();
                            } catch (IOException e6) {
                                IOException iOException3 = e6;
                            }
                        }
                        throw th4;
                    }
                    try {
                    } catch (Throwable th5) {
                        Throwable th6 = th5;
                        Class cls3 = cls2;
                        throw th6;
                    }
                }
                if (!(jaxpProperties == null || (property = jaxpProperties.getProperty(str2)) == null || property.length() <= 0)) {
                    if (DEBUG) {
                        new StringBuffer();
                        debugPrintln(stringBuffer3.append("found \"").append(str2).append("\" in jaxp.properties, value=").append(property).toString());
                    }
                    boolean booleanValue2 = Boolean.valueOf(property).booleanValue();
                    this.fLimitSpecified = RESOLVE_EXTERNAL_ENTITIES_DEFAULT_VALUE;
                    return booleanValue2;
                }
            } catch (VirtualMachineError e7) {
                throw e7;
            } catch (ThreadDeath e8) {
                throw e8;
            } catch (Throwable th7) {
                Throwable th8 = th7;
                if (DEBUG) {
                    new StringBuffer();
                    debugPrintln(stringBuffer2.append(th8.getClass().getName()).append(": ").append(th8.getMessage()).toString());
                    th8.printStackTrace();
                }
            }
        } catch (SecurityException e9) {
            SecurityException securityException = e9;
            lastModified = -1;
            jaxpProperties = null;
        }
        return z2;
    }

    private static boolean isDebugEnabled() {
        try {
            String systemProperty = SecuritySupport.getSystemProperty("xerces.debug");
            return (systemProperty == null || "false".equals(systemProperty)) ? false : RESOLVE_EXTERNAL_ENTITIES_DEFAULT_VALUE;
        } catch (SecurityException e) {
            SecurityException securityException = e;
            return false;
        }
    }

    /* access modifiers changed from: protected */
    public void checkEntitySizeLimits(int i, int i2, boolean z) {
        Object obj;
        Object obj2;
        Object obj3;
        int i3 = i;
        boolean z2 = z;
        this.fTotalEntitySize += i2;
        if (this.fTotalEntitySize > this.TOTAL_ENTITY_SIZE_LIMIT_SYSTEM_VALUE) {
            new Integer(this.TOTAL_ENTITY_SIZE_LIMIT_SYSTEM_VALUE);
            String reportError = this.fErrorReporter.reportError(DOMMessageFormatter.XML_DOMAIN, "TotalEntitySizeLimitExceeded", new Object[]{obj3}, 2);
        }
        if (z2) {
            if (i3 > this.MAX_PARAMETER_ENTITY_SIZE_LIMIT_SYSTEM_VALUE) {
                new Integer(this.MAX_PARAMETER_ENTITY_SIZE_LIMIT_SYSTEM_VALUE);
                String reportError2 = this.fErrorReporter.reportError(DOMMessageFormatter.XML_DOMAIN, "MaxParameterEntitySizeLimitExceeded", new Object[]{obj2}, 2);
            }
        } else if (i3 > this.MAX_GENERAL_ENTITY_SIZE_LIMIT_SYSTEM_VALUE) {
            new Integer(this.MAX_GENERAL_ENTITY_SIZE_LIMIT_SYSTEM_VALUE);
            String reportError3 = this.fErrorReporter.reportError(DOMMessageFormatter.XML_DOMAIN, "MaxGeneralEntitySizeLimitExceeded", new Object[]{obj}, 2);
        }
    }

    /* access modifiers changed from: protected */
    public void configurePipeline() {
        super.configurePipeline();
        configurePipelineCommon(RESOLVE_EXTERNAL_ENTITIES_DEFAULT_VALUE);
    }

    /* access modifiers changed from: protected */
    public void configureXML11Pipeline() {
        super.configureXML11Pipeline();
        configurePipelineCommon(false);
    }

    public Object getProperty(String str) throws XMLConfigurationException {
        String str2 = str;
        return SECURITY_MANAGER_PROPERTY.equals(str2) ? this.fSecurityManager : ENTITY_RESOLVER_PROPERTY.equals(str2) ? this.fExternalEntityMonitor : super.getProperty(str2);
    }

    public void setProperty(String str, Object obj) throws XMLConfigurationException {
        String str2 = str;
        Object obj2 = obj;
        if (SECURITY_MANAGER_PROPERTY.equals(str2)) {
            if (obj2 != null || !this.fJavaSecurityManagerEnabled) {
                this.fSecurityManager = (SecurityManager) obj2;
                if (this.fSecurityManager != null) {
                    if (this.fSecurityManager.getEntityExpansionLimit() == SECURITY_MANAGER_DEFAULT_ENTITY_EXPANSION_LIMIT) {
                        this.fSecurityManager.setEntityExpansionLimit(this.ENTITY_EXPANSION_LIMIT_SYSTEM_VALUE);
                    }
                    if (this.fSecurityManager.getMaxOccurNodeLimit() == 3000) {
                        this.fSecurityManager.setMaxOccurNodeLimit(this.MAX_OCCUR_LIMIT_SYSTEM_VALUE);
                    }
                }
            } else {
                return;
            }
        } else if (ENTITY_RESOLVER_PROPERTY.equals(str2)) {
            this.fExternalEntityMonitor.setEntityResolver((XMLEntityResolver) obj2);
            return;
        }
        super.setProperty(str2, obj2);
    }
}
