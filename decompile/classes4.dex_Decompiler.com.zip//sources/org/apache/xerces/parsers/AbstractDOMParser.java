package org.apache.xerces.parsers;

import java.util.Locale;
import java.util.Stack;
import org.apache.xerces.dom.AttrImpl;
import org.apache.xerces.dom.CoreDocumentImpl;
import org.apache.xerces.dom.DOMErrorImpl;
import org.apache.xerces.dom.DOMMessageFormatter;
import org.apache.xerces.dom.DeferredDocumentImpl;
import org.apache.xerces.dom.DocumentImpl;
import org.apache.xerces.dom.DocumentTypeImpl;
import org.apache.xerces.dom.ElementDefinitionImpl;
import org.apache.xerces.dom.ElementNSImpl;
import org.apache.xerces.dom.EntityImpl;
import org.apache.xerces.dom.EntityReferenceImpl;
import org.apache.xerces.dom.NodeImpl;
import org.apache.xerces.dom.NotationImpl;
import org.apache.xerces.dom.PSVIDocumentImpl;
import org.apache.xerces.dom.PSVIElementNSImpl;
import org.apache.xerces.dom.TextImpl;
import org.apache.xerces.util.DOMErrorHandlerWrapper;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.NamespaceContext;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XMLResourceIdentifier;
import org.apache.xerces.xni.XMLString;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLParserConfiguration;
import org.apache.xerces.xs.ElementPSVI;
import org.apache.xerces.xs.XSTypeDefinition;
import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.EntityReference;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;
import org.w3c.dom.ls.LSParserFilter;

public class AbstractDOMParser extends AbstractXMLDocumentParser {
    protected static final String CORE_DOCUMENT_CLASS_NAME = "org.apache.xerces.dom.CoreDocumentImpl";
    protected static final String CREATE_CDATA_NODES_FEATURE = "http://apache.org/xml/features/create-cdata-nodes";
    protected static final String CREATE_ENTITY_REF_NODES = "http://apache.org/xml/features/dom/create-entity-ref-nodes";
    protected static final String CURRENT_ELEMENT_NODE = "http://apache.org/xml/properties/dom/current-element-node";
    private static final boolean DEBUG_BASEURI = false;
    private static final boolean DEBUG_EVENTS = false;
    protected static final String DEFAULT_DOCUMENT_CLASS_NAME = "org.apache.xerces.dom.DocumentImpl";
    protected static final String DEFER_NODE_EXPANSION = "http://apache.org/xml/features/dom/defer-node-expansion";
    protected static final String DOCUMENT_CLASS_NAME = "http://apache.org/xml/properties/dom/document-class-name";
    protected static final String INCLUDE_COMMENTS_FEATURE = "http://apache.org/xml/features/include-comments";
    protected static final String INCLUDE_IGNORABLE_WHITESPACE = "http://apache.org/xml/features/dom/include-ignorable-whitespace";
    protected static final String NAMESPACES = "http://xml.org/sax/features/namespaces";
    protected static final String PSVI_DOCUMENT_CLASS_NAME = "org.apache.xerces.dom.PSVIDocumentImpl";
    private static final String[] RECOGNIZED_FEATURES;
    private static final String[] RECOGNIZED_PROPERTIES;
    static Class class$org$w3c$dom$Document;
    private final QName fAttrQName;
    protected final Stack fBaseURIStack;
    protected boolean fCreateCDATANodes;
    protected boolean fCreateEntityRefNodes;
    protected CDATASection fCurrentCDATASection;
    protected int fCurrentCDATASectionIndex;
    protected EntityImpl fCurrentEntityDecl;
    protected Node fCurrentNode;
    protected int fCurrentNodeIndex;
    protected LSParserFilter fDOMFilter;
    protected boolean fDeferNodeExpansion;
    protected DeferredDocumentImpl fDeferredDocumentImpl;
    protected int fDeferredEntityDecl;
    protected Document fDocument;
    protected String fDocumentClassName;
    protected CoreDocumentImpl fDocumentImpl;
    protected int fDocumentIndex;
    protected DocumentType fDocumentType;
    protected int fDocumentTypeIndex;
    protected DOMErrorHandlerWrapper fErrorHandler = null;
    protected boolean fFilterReject;
    protected boolean fFirstChunk;
    protected boolean fInCDATASection;
    protected boolean fInDTD;
    protected boolean fInDTDExternalSubset;
    protected boolean fInEntityRef;
    protected boolean fIncludeComments;
    protected boolean fIncludeIgnorableWhitespace;
    protected StringBuffer fInternalSubset;
    private XMLLocator fLocator;
    protected boolean fNamespaceAware;
    protected int fRejectedElementDepth;
    protected Node fRoot;
    protected Stack fSkippedElemStack;
    protected boolean fStorePSVI;
    protected final StringBuffer fStringBuffer;

    static final class Abort extends RuntimeException {
        static final Abort INSTANCE;
        private static final long serialVersionUID = 1687848994976808490L;

        static {
            Abort abort;
            new Abort();
            INSTANCE = abort;
        }

        private Abort() {
        }

        public Throwable fillInStackTrace() {
            return this;
        }
    }

    static {
        String[] strArr = new String[6];
        strArr[0] = NAMESPACES;
        String[] strArr2 = strArr;
        strArr2[1] = CREATE_ENTITY_REF_NODES;
        String[] strArr3 = strArr2;
        strArr3[2] = INCLUDE_COMMENTS_FEATURE;
        String[] strArr4 = strArr3;
        strArr4[3] = CREATE_CDATA_NODES_FEATURE;
        String[] strArr5 = strArr4;
        strArr5[4] = INCLUDE_IGNORABLE_WHITESPACE;
        String[] strArr6 = strArr5;
        strArr6[5] = DEFER_NODE_EXPANSION;
        RECOGNIZED_FEATURES = strArr6;
        String[] strArr7 = new String[2];
        strArr7[0] = DOCUMENT_CLASS_NAME;
        String[] strArr8 = strArr7;
        strArr8[1] = CURRENT_ELEMENT_NODE;
        RECOGNIZED_PROPERTIES = strArr8;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected AbstractDOMParser(XMLParserConfiguration xMLParserConfiguration) {
        super(xMLParserConfiguration);
        StringBuffer stringBuffer;
        Stack stack;
        QName qName;
        new StringBuffer(50);
        this.fStringBuffer = stringBuffer;
        this.fFirstChunk = false;
        this.fFilterReject = false;
        new Stack();
        this.fBaseURIStack = stack;
        this.fRejectedElementDepth = 0;
        this.fSkippedElemStack = null;
        this.fInEntityRef = false;
        new QName();
        this.fAttrQName = qName;
        this.fDOMFilter = null;
        this.fConfiguration.addRecognizedFeatures(RECOGNIZED_FEATURES);
        this.fConfiguration.setFeature(CREATE_ENTITY_REF_NODES, true);
        this.fConfiguration.setFeature(INCLUDE_IGNORABLE_WHITESPACE, true);
        this.fConfiguration.setFeature(DEFER_NODE_EXPANSION, true);
        this.fConfiguration.setFeature(INCLUDE_COMMENTS_FEATURE, true);
        this.fConfiguration.setFeature(CREATE_CDATA_NODES_FEATURE, true);
        this.fConfiguration.addRecognizedProperties(RECOGNIZED_PROPERTIES);
        this.fConfiguration.setProperty(DOCUMENT_CLASS_NAME, DEFAULT_DOCUMENT_CLASS_NAME);
    }

    static Class class$(String str) {
        Throwable th;
        try {
            return Class.forName(str);
        } catch (ClassNotFoundException e) {
            ClassNotFoundException classNotFoundException = e;
            Throwable th2 = th;
            new NoClassDefFoundError(classNotFoundException.getMessage());
            throw th2;
        }
    }

    public void abort() {
        throw Abort.INSTANCE;
    }

    public void attributeDecl(String str, String str2, String str3, String[] strArr, String str4, XMLString xMLString, XMLString xMLString2, Augmentations augmentations) throws XNIException {
        AttrImpl attrImpl;
        String str5 = str;
        String str6 = str2;
        String str7 = str3;
        String[] strArr2 = strArr;
        String str8 = str4;
        XMLString xMLString3 = xMLString;
        XMLString xMLString4 = xMLString2;
        Augmentations augmentations2 = augmentations;
        if (this.fInternalSubset != null && !this.fInDTDExternalSubset) {
            StringBuffer append = this.fInternalSubset.append("<!ATTLIST ");
            StringBuffer append2 = this.fInternalSubset.append(str5);
            StringBuffer append3 = this.fInternalSubset.append(' ');
            StringBuffer append4 = this.fInternalSubset.append(str6);
            StringBuffer append5 = this.fInternalSubset.append(' ');
            if (str7.equals("ENUMERATION")) {
                StringBuffer append6 = this.fInternalSubset.append('(');
                for (int i = 0; i < strArr2.length; i++) {
                    if (i > 0) {
                        StringBuffer append7 = this.fInternalSubset.append('|');
                    }
                    StringBuffer append8 = this.fInternalSubset.append(strArr2[i]);
                }
                StringBuffer append9 = this.fInternalSubset.append(')');
            } else {
                StringBuffer append10 = this.fInternalSubset.append(str7);
            }
            if (str8 != null) {
                StringBuffer append11 = this.fInternalSubset.append(' ');
                StringBuffer append12 = this.fInternalSubset.append(str8);
            }
            if (xMLString3 != null) {
                StringBuffer append13 = this.fInternalSubset.append(" '");
                for (int i2 = 0; i2 < xMLString3.length; i2++) {
                    char c = xMLString3.ch[xMLString3.offset + i2];
                    if (c == '\'') {
                        StringBuffer append14 = this.fInternalSubset.append("&apos;");
                    } else {
                        StringBuffer append15 = this.fInternalSubset.append(c);
                    }
                }
                StringBuffer append16 = this.fInternalSubset.append('\'');
            }
            StringBuffer append17 = this.fInternalSubset.append(">\n");
        }
        if (this.fDeferredDocumentImpl != null) {
            if (xMLString3 != null) {
                int lookupElementDefinition = this.fDeferredDocumentImpl.lookupElementDefinition(str5);
                if (lookupElementDefinition == -1) {
                    lookupElementDefinition = this.fDeferredDocumentImpl.createDeferredElementDefinition(str5);
                    this.fDeferredDocumentImpl.appendChild(this.fDocumentTypeIndex, lookupElementDefinition);
                }
                String str9 = null;
                if (this.fNamespaceAware) {
                    if (str6.startsWith("xmlns:") || str6.equals("xmlns")) {
                        str9 = NamespaceContext.XMLNS_URI;
                    } else if (str6.startsWith("xml:")) {
                        str9 = NamespaceContext.XML_URI;
                    }
                }
                int createDeferredAttribute = this.fDeferredDocumentImpl.createDeferredAttribute(str6, str9, xMLString3.toString(), false);
                if ("ID".equals(str7)) {
                    this.fDeferredDocumentImpl.setIdAttribute(createDeferredAttribute);
                }
                this.fDeferredDocumentImpl.appendChild(lookupElementDefinition, createDeferredAttribute);
            }
        } else if (this.fDocumentImpl != null && xMLString3 != null) {
            ElementDefinitionImpl elementDefinitionImpl = (ElementDefinitionImpl) ((DocumentTypeImpl) this.fDocumentType).getElements().getNamedItem(str5);
            if (elementDefinitionImpl == null) {
                elementDefinitionImpl = this.fDocumentImpl.createElementDefinition(str5);
                Node namedItem = ((DocumentTypeImpl) this.fDocumentType).getElements().setNamedItem(elementDefinitionImpl);
            }
            boolean z = this.fNamespaceAware;
            if (z) {
                String str10 = null;
                if (str6.startsWith("xmlns:") || str6.equals("xmlns")) {
                    str10 = NamespaceContext.XMLNS_URI;
                } else if (str6.startsWith("xml:")) {
                    str10 = NamespaceContext.XML_URI;
                }
                attrImpl = (AttrImpl) this.fDocumentImpl.createAttributeNS(str10, str6);
            } else {
                attrImpl = (AttrImpl) this.fDocumentImpl.createAttribute(str6);
            }
            attrImpl.setValue(xMLString3.toString());
            attrImpl.setSpecified(false);
            attrImpl.setIdAttribute("ID".equals(str7));
            if (z) {
                Node namedItemNS = elementDefinitionImpl.getAttributes().setNamedItemNS(attrImpl);
            } else {
                Node namedItem2 = elementDefinitionImpl.getAttributes().setNamedItem(attrImpl);
            }
        }
    }

    public void characters(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (!this.fDeferNodeExpansion) {
            if (!this.fFilterReject) {
                if (!this.fInCDATASection || !this.fCreateCDATANodes) {
                    if (!this.fInDTD && xMLString2.length != 0) {
                        Node lastChild = this.fCurrentNode.getLastChild();
                        if (lastChild == null || lastChild.getNodeType() != 3) {
                            this.fFirstChunk = true;
                            Node appendChild = this.fCurrentNode.appendChild(this.fDocument.createTextNode(xMLString2.toString()));
                            return;
                        }
                        if (this.fFirstChunk) {
                            if (this.fDocumentImpl != null) {
                                StringBuffer append = this.fStringBuffer.append(((TextImpl) lastChild).removeData());
                            } else {
                                StringBuffer append2 = this.fStringBuffer.append(((Text) lastChild).getData());
                                ((Text) lastChild).setNodeValue((String) null);
                            }
                            this.fFirstChunk = false;
                        }
                        if (xMLString2.length > 0) {
                            StringBuffer append3 = this.fStringBuffer.append(xMLString2.ch, xMLString2.offset, xMLString2.length);
                        }
                    }
                } else if (this.fCurrentCDATASection == null) {
                    this.fCurrentCDATASection = this.fDocument.createCDATASection(xMLString2.toString());
                    Node appendChild2 = this.fCurrentNode.appendChild(this.fCurrentCDATASection);
                    this.fCurrentNode = this.fCurrentCDATASection;
                } else {
                    this.fCurrentCDATASection.appendData(xMLString2.toString());
                }
            }
        } else if (!this.fInCDATASection || !this.fCreateCDATANodes) {
            if (!this.fInDTD && xMLString2.length != 0) {
                this.fDeferredDocumentImpl.appendChild(this.fCurrentNodeIndex, this.fDeferredDocumentImpl.createDeferredTextNode(xMLString2.toString(), false));
            }
        } else if (this.fCurrentCDATASectionIndex == -1) {
            int createDeferredCDATASection = this.fDeferredDocumentImpl.createDeferredCDATASection(xMLString2.toString());
            this.fDeferredDocumentImpl.appendChild(this.fCurrentNodeIndex, createDeferredCDATASection);
            this.fCurrentCDATASectionIndex = createDeferredCDATASection;
            this.fCurrentNodeIndex = createDeferredCDATASection;
        } else {
            this.fDeferredDocumentImpl.appendChild(this.fCurrentNodeIndex, this.fDeferredDocumentImpl.createDeferredTextNode(xMLString2.toString(), false));
        }
    }

    public void comment(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (this.fInDTD) {
            if (this.fInternalSubset != null && !this.fInDTDExternalSubset) {
                StringBuffer append = this.fInternalSubset.append("<!--");
                if (xMLString2.length > 0) {
                    StringBuffer append2 = this.fInternalSubset.append(xMLString2.ch, xMLString2.offset, xMLString2.length);
                }
                StringBuffer append3 = this.fInternalSubset.append("-->");
            }
        } else if (this.fIncludeComments && !this.fFilterReject) {
            if (!this.fDeferNodeExpansion) {
                Comment createComment = this.fDocument.createComment(xMLString2.toString());
                setCharacterData(false);
                Node appendChild = this.fCurrentNode.appendChild(createComment);
                if (this.fDOMFilter != null && !this.fInEntityRef && (this.fDOMFilter.getWhatToShow() & 128) != 0) {
                    switch (this.fDOMFilter.acceptNode(createComment)) {
                        case 2:
                        case 3:
                            Node removeChild = this.fCurrentNode.removeChild(createComment);
                            this.fFirstChunk = true;
                            return;
                        case 4:
                            throw Abort.INSTANCE;
                        default:
                            return;
                    }
                }
            } else {
                this.fDeferredDocumentImpl.appendChild(this.fCurrentNodeIndex, this.fDeferredDocumentImpl.createDeferredComment(xMLString2.toString()));
            }
        }
    }

    /* access modifiers changed from: protected */
    public Attr createAttrNode(QName qName) {
        QName qName2 = qName;
        return this.fNamespaceAware ? this.fDocumentImpl != null ? this.fDocumentImpl.createAttributeNS(qName2.uri, qName2.rawname, qName2.localpart) : this.fDocument.createAttributeNS(qName2.uri, qName2.rawname) : this.fDocument.createAttribute(qName2.rawname);
    }

    /* access modifiers changed from: protected */
    public Element createElementNode(QName qName) {
        QName qName2 = qName;
        return this.fNamespaceAware ? this.fDocumentImpl != null ? this.fDocumentImpl.createElementNS(qName2.uri, qName2.rawname, qName2.localpart) : this.fDocument.createElementNS(qName2.uri, qName2.rawname) : this.fDocument.createElement(qName2.rawname);
    }

    public void doctypeDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        Augmentations augmentations2 = augmentations;
        if (this.fDeferNodeExpansion) {
            this.fDocumentTypeIndex = this.fDeferredDocumentImpl.createDeferredDocumentType(str4, str5, str6);
            this.fDeferredDocumentImpl.appendChild(this.fCurrentNodeIndex, this.fDocumentTypeIndex);
        } else if (this.fDocumentImpl != null) {
            this.fDocumentType = this.fDocumentImpl.createDocumentType(str4, str5, str6);
            Node appendChild = this.fCurrentNode.appendChild(this.fDocumentType);
        }
    }

    public final void dropDocumentReferences() {
        this.fDocument = null;
        this.fDocumentImpl = null;
        this.fDeferredDocumentImpl = null;
        this.fDocumentType = null;
        this.fCurrentNode = null;
        this.fCurrentCDATASection = null;
        this.fCurrentEntityDecl = null;
        this.fRoot = null;
    }

    public void elementDecl(String str, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        if (this.fInternalSubset != null && !this.fInDTDExternalSubset) {
            StringBuffer append = this.fInternalSubset.append("<!ELEMENT ");
            StringBuffer append2 = this.fInternalSubset.append(str3);
            StringBuffer append3 = this.fInternalSubset.append(' ');
            StringBuffer append4 = this.fInternalSubset.append(str4);
            StringBuffer append5 = this.fInternalSubset.append(">\n");
        }
    }

    public void emptyElement(QName qName, XMLAttributes xMLAttributes, Augmentations augmentations) throws XNIException {
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        startElement(qName2, xMLAttributes, augmentations2);
        endElement(qName2, augmentations2);
    }

    public void endAttlist(Augmentations augmentations) throws XNIException {
    }

    public void endCDATA(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        this.fInCDATASection = false;
        if (!this.fDeferNodeExpansion) {
            if (!this.fFilterReject && this.fCurrentCDATASection != null) {
                if (!(this.fDOMFilter == null || this.fInEntityRef || (this.fDOMFilter.getWhatToShow() & 8) == 0)) {
                    switch (this.fDOMFilter.acceptNode(this.fCurrentCDATASection)) {
                        case 2:
                        case 3:
                            Node parentNode = this.fCurrentNode.getParentNode();
                            Node removeChild = parentNode.removeChild(this.fCurrentCDATASection);
                            this.fCurrentNode = parentNode;
                            return;
                        case 4:
                            throw Abort.INSTANCE;
                    }
                }
                this.fCurrentNode = this.fCurrentNode.getParentNode();
                this.fCurrentCDATASection = null;
            }
        } else if (this.fCurrentCDATASectionIndex != -1) {
            this.fCurrentNodeIndex = this.fDeferredDocumentImpl.getParentNode(this.fCurrentNodeIndex, false);
            this.fCurrentCDATASectionIndex = -1;
        }
    }

    public void endConditional(Augmentations augmentations) throws XNIException {
    }

    public void endDTD(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        this.fInDTD = false;
        if (!this.fBaseURIStack.isEmpty()) {
            Object pop = this.fBaseURIStack.pop();
        }
        String stringBuffer = (this.fInternalSubset == null || this.fInternalSubset.length() <= 0) ? null : this.fInternalSubset.toString();
        if (this.fDeferNodeExpansion) {
            if (stringBuffer != null) {
                this.fDeferredDocumentImpl.setInternalSubset(this.fDocumentTypeIndex, stringBuffer);
            }
        } else if (this.fDocumentImpl != null && stringBuffer != null) {
            ((DocumentTypeImpl) this.fDocumentType).setInternalSubset(stringBuffer);
        }
    }

    public void endDocument(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        if (!this.fDeferNodeExpansion) {
            if (this.fDocumentImpl != null) {
                if (this.fLocator != null) {
                    this.fDocumentImpl.setInputEncoding(this.fLocator.getEncoding());
                }
                this.fDocumentImpl.setStrictErrorChecking(true);
            }
            this.fCurrentNode = null;
            return;
        }
        if (this.fLocator != null) {
            this.fDeferredDocumentImpl.setInputEncoding(this.fLocator.getEncoding());
        }
        this.fCurrentNodeIndex = -1;
    }

    public void endElement(QName qName, Augmentations augmentations) throws XNIException {
        ElementPSVI elementPSVI;
        ElementPSVI elementPSVI2;
        QName qName2 = qName;
        Augmentations augmentations2 = augmentations;
        if (!this.fDeferNodeExpansion) {
            if (!(augmentations2 == null || this.fDocumentImpl == null || ((!this.fNamespaceAware && !this.fStorePSVI) || (elementPSVI2 = (ElementPSVI) augmentations2.getItem("ELEMENT_PSVI")) == null))) {
                if (this.fNamespaceAware) {
                    XSTypeDefinition memberTypeDefinition = elementPSVI2.getMemberTypeDefinition();
                    if (memberTypeDefinition == null) {
                        memberTypeDefinition = elementPSVI2.getTypeDefinition();
                    }
                    ((ElementNSImpl) this.fCurrentNode).setType(memberTypeDefinition);
                }
                if (this.fStorePSVI) {
                    ((PSVIElementNSImpl) this.fCurrentNode).setPSVI(elementPSVI2);
                }
            }
            if (this.fDOMFilter == null) {
                setCharacterData(false);
                this.fCurrentNode = this.fCurrentNode.getParentNode();
            } else if (this.fFilterReject) {
                int i = this.fRejectedElementDepth;
                int i2 = i;
                this.fRejectedElementDepth = i - 1;
                if (i2 == 0) {
                    this.fFilterReject = false;
                }
            } else if (this.fSkippedElemStack.isEmpty() || this.fSkippedElemStack.pop() != Boolean.TRUE) {
                setCharacterData(false);
                if (!(this.fCurrentNode == this.fRoot || this.fInEntityRef || (this.fDOMFilter.getWhatToShow() & 1) == 0)) {
                    switch (this.fDOMFilter.acceptNode(this.fCurrentNode)) {
                        case 2:
                            Node parentNode = this.fCurrentNode.getParentNode();
                            Node removeChild = parentNode.removeChild(this.fCurrentNode);
                            this.fCurrentNode = parentNode;
                            return;
                        case 3:
                            this.fFirstChunk = true;
                            Node parentNode2 = this.fCurrentNode.getParentNode();
                            NodeList childNodes = this.fCurrentNode.getChildNodes();
                            int length = childNodes.getLength();
                            for (int i3 = 0; i3 < length; i3++) {
                                Node appendChild = parentNode2.appendChild(childNodes.item(0));
                            }
                            Node removeChild2 = parentNode2.removeChild(this.fCurrentNode);
                            this.fCurrentNode = parentNode2;
                            return;
                        case 4:
                            throw Abort.INSTANCE;
                    }
                }
                this.fCurrentNode = this.fCurrentNode.getParentNode();
            }
        } else {
            if (!(augmentations2 == null || (elementPSVI = (ElementPSVI) augmentations2.getItem("ELEMENT_PSVI")) == null)) {
                XSTypeDefinition memberTypeDefinition2 = elementPSVI.getMemberTypeDefinition();
                if (memberTypeDefinition2 == null) {
                    memberTypeDefinition2 = elementPSVI.getTypeDefinition();
                }
                this.fDeferredDocumentImpl.setTypeInfo(this.fCurrentNodeIndex, memberTypeDefinition2);
            }
            this.fCurrentNodeIndex = this.fDeferredDocumentImpl.getParentNode(this.fCurrentNodeIndex, false);
        }
    }

    public void endExternalSubset(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        this.fInDTDExternalSubset = false;
        Object pop = this.fBaseURIStack.pop();
    }

    public void endGeneralEntity(String str, Augmentations augmentations) throws XNIException {
        String str2 = str;
        Augmentations augmentations2 = augmentations;
        if (this.fDeferNodeExpansion) {
            if (this.fDocumentTypeIndex != -1) {
                int lastChild = this.fDeferredDocumentImpl.getLastChild(this.fDocumentTypeIndex, false);
                while (true) {
                    int i = lastChild;
                    if (i != -1) {
                        if (this.fDeferredDocumentImpl.getNodeType(i, false) == 6 && this.fDeferredDocumentImpl.getNodeName(i, false).equals(str2)) {
                            this.fDeferredEntityDecl = i;
                            break;
                        }
                        lastChild = this.fDeferredDocumentImpl.getRealPrevSibling(i, false);
                    } else {
                        break;
                    }
                }
            }
            if (this.fDeferredEntityDecl != -1 && this.fDeferredDocumentImpl.getLastChild(this.fDeferredEntityDecl, false) == -1) {
                int i2 = -1;
                int lastChild2 = this.fDeferredDocumentImpl.getLastChild(this.fCurrentNodeIndex, false);
                while (true) {
                    int i3 = lastChild2;
                    if (i3 == -1) {
                        break;
                    }
                    int cloneNode = this.fDeferredDocumentImpl.cloneNode(i3, true);
                    int insertBefore = this.fDeferredDocumentImpl.insertBefore(this.fDeferredEntityDecl, cloneNode, i2);
                    i2 = cloneNode;
                    lastChild2 = this.fDeferredDocumentImpl.getRealPrevSibling(i3, false);
                }
            }
            if (this.fCreateEntityRefNodes) {
                this.fCurrentNodeIndex = this.fDeferredDocumentImpl.getParentNode(this.fCurrentNodeIndex, false);
            } else {
                int lastChild3 = this.fDeferredDocumentImpl.getLastChild(this.fCurrentNodeIndex, false);
                int parentNode = this.fDeferredDocumentImpl.getParentNode(this.fCurrentNodeIndex, false);
                int i4 = this.fCurrentNodeIndex;
                int i5 = lastChild3;
                while (lastChild3 != -1) {
                    handleBaseURI(lastChild3);
                    int realPrevSibling = this.fDeferredDocumentImpl.getRealPrevSibling(lastChild3, false);
                    int insertBefore2 = this.fDeferredDocumentImpl.insertBefore(parentNode, lastChild3, i4);
                    i4 = lastChild3;
                    lastChild3 = realPrevSibling;
                }
                if (i5 != -1) {
                    this.fDeferredDocumentImpl.setAsLastChild(parentNode, i5);
                } else {
                    this.fDeferredDocumentImpl.setAsLastChild(parentNode, this.fDeferredDocumentImpl.getRealPrevSibling(i4, false));
                }
                this.fCurrentNodeIndex = parentNode;
            }
            this.fDeferredEntityDecl = -1;
        } else if (!this.fFilterReject) {
            setCharacterData(true);
            if (this.fDocumentType != null) {
                this.fCurrentEntityDecl = (EntityImpl) this.fDocumentType.getEntities().getNamedItem(str2);
                if (this.fCurrentEntityDecl != null) {
                    if (this.fCurrentEntityDecl != null && this.fCurrentEntityDecl.getFirstChild() == null) {
                        this.fCurrentEntityDecl.setReadOnly(false, true);
                        Node firstChild = this.fCurrentNode.getFirstChild();
                        while (true) {
                            Node node = firstChild;
                            if (node == null) {
                                break;
                            }
                            Node appendChild = this.fCurrentEntityDecl.appendChild(node.cloneNode(true));
                            firstChild = node.getNextSibling();
                        }
                        this.fCurrentEntityDecl.setReadOnly(true, true);
                    }
                    this.fCurrentEntityDecl = null;
                }
            }
            this.fInEntityRef = false;
            boolean z = false;
            if (this.fCreateEntityRefNodes) {
                if (this.fDocumentImpl != null) {
                    ((NodeImpl) this.fCurrentNode).setReadOnly(true, true);
                }
                if (this.fDOMFilter != null && (this.fDOMFilter.getWhatToShow() & 16) != 0) {
                    switch (this.fDOMFilter.acceptNode(this.fCurrentNode)) {
                        case 2:
                            Node parentNode2 = this.fCurrentNode.getParentNode();
                            Node removeChild = parentNode2.removeChild(this.fCurrentNode);
                            this.fCurrentNode = parentNode2;
                            return;
                        case 3:
                            this.fFirstChunk = true;
                            z = true;
                            break;
                        case 4:
                            throw Abort.INSTANCE;
                        default:
                            this.fCurrentNode = this.fCurrentNode.getParentNode();
                            break;
                    }
                } else {
                    this.fCurrentNode = this.fCurrentNode.getParentNode();
                }
            }
            if (!this.fCreateEntityRefNodes || z) {
                NodeList childNodes = this.fCurrentNode.getChildNodes();
                Node parentNode3 = this.fCurrentNode.getParentNode();
                int length = childNodes.getLength();
                if (length > 0) {
                    Node previousSibling = this.fCurrentNode.getPreviousSibling();
                    Node item = childNodes.item(0);
                    if (previousSibling != null && previousSibling.getNodeType() == 3 && item.getNodeType() == 3) {
                        ((Text) previousSibling).appendData(item.getNodeValue());
                        Node removeChild2 = this.fCurrentNode.removeChild(item);
                    } else {
                        handleBaseURI(parentNode3.insertBefore(item, this.fCurrentNode));
                    }
                    for (int i6 = 1; i6 < length; i6++) {
                        handleBaseURI(parentNode3.insertBefore(childNodes.item(0), this.fCurrentNode));
                    }
                }
                Node removeChild3 = parentNode3.removeChild(this.fCurrentNode);
                this.fCurrentNode = parentNode3;
            }
        }
    }

    public void endParameterEntity(String str, Augmentations augmentations) throws XNIException {
        String str2 = str;
        Augmentations augmentations2 = augmentations;
        Object pop = this.fBaseURIStack.pop();
    }

    public void externalEntityDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
        String str2 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        Augmentations augmentations2 = augmentations;
        String publicId = xMLResourceIdentifier2.getPublicId();
        String literalSystemId = xMLResourceIdentifier2.getLiteralSystemId();
        if (this.fInternalSubset != null && !this.fInDTDExternalSubset) {
            StringBuffer append = this.fInternalSubset.append("<!ENTITY ");
            if (str2.startsWith("%")) {
                StringBuffer append2 = this.fInternalSubset.append("% ");
                StringBuffer append3 = this.fInternalSubset.append(str2.substring(1));
            } else {
                StringBuffer append4 = this.fInternalSubset.append(str2);
            }
            StringBuffer append5 = this.fInternalSubset.append(' ');
            if (publicId != null) {
                StringBuffer append6 = this.fInternalSubset.append("PUBLIC '");
                StringBuffer append7 = this.fInternalSubset.append(publicId);
                StringBuffer append8 = this.fInternalSubset.append("' '");
            } else {
                StringBuffer append9 = this.fInternalSubset.append("SYSTEM '");
            }
            StringBuffer append10 = this.fInternalSubset.append(literalSystemId);
            StringBuffer append11 = this.fInternalSubset.append("'>\n");
        }
        if (!str2.startsWith("%")) {
            if (this.fDocumentType != null) {
                NamedNodeMap entities = this.fDocumentType.getEntities();
                if (((EntityImpl) entities.getNamedItem(str2)) == null) {
                    EntityImpl entityImpl = (EntityImpl) this.fDocumentImpl.createEntity(str2);
                    entityImpl.setPublicId(publicId);
                    entityImpl.setSystemId(literalSystemId);
                    entityImpl.setBaseURI(xMLResourceIdentifier2.getBaseSystemId());
                    Node namedItem = entities.setNamedItem(entityImpl);
                }
            }
            if (this.fDocumentTypeIndex != -1) {
                boolean z = false;
                int lastChild = this.fDeferredDocumentImpl.getLastChild(this.fDocumentTypeIndex, false);
                while (true) {
                    int i = lastChild;
                    if (i != -1) {
                        if (this.fDeferredDocumentImpl.getNodeType(i, false) == 6 && this.fDeferredDocumentImpl.getNodeName(i, false).equals(str2)) {
                            z = true;
                            break;
                        }
                        lastChild = this.fDeferredDocumentImpl.getRealPrevSibling(i, false);
                    } else {
                        break;
                    }
                }
                if (!z) {
                    this.fDeferredDocumentImpl.appendChild(this.fDocumentTypeIndex, this.fDeferredDocumentImpl.createDeferredEntity(str2, publicId, literalSystemId, (String) null, xMLResourceIdentifier2.getBaseSystemId()));
                }
            }
        }
    }

    public Document getDocument() {
        return this.fDocument;
    }

    /* access modifiers changed from: protected */
    public String getDocumentClassName() {
        return this.fDocumentClassName;
    }

    /* access modifiers changed from: protected */
    public final void handleBaseURI(int i) {
        DOMErrorImpl dOMErrorImpl;
        int i2 = i;
        short nodeType = this.fDeferredDocumentImpl.getNodeType(i2, false);
        if (nodeType == 1) {
            String nodeValueString = this.fDeferredDocumentImpl.getNodeValueString(this.fCurrentNodeIndex, false);
            if (nodeValueString == null) {
                nodeValueString = this.fDeferredDocumentImpl.getDeferredEntityBaseURI(this.fDeferredEntityDecl);
            }
            if (nodeValueString != null && !nodeValueString.equals(this.fDeferredDocumentImpl.getDocumentURI())) {
                int deferredAttribute = this.fDeferredDocumentImpl.setDeferredAttribute(i2, "xml:base", "http://www.w3.org/XML/1998/namespace", nodeValueString, true);
            }
        } else if (nodeType == 7) {
            String nodeValueString2 = this.fDeferredDocumentImpl.getNodeValueString(this.fCurrentNodeIndex, false);
            if (nodeValueString2 == null) {
                nodeValueString2 = this.fDeferredDocumentImpl.getDeferredEntityBaseURI(this.fDeferredEntityDecl);
            }
            if (nodeValueString2 != null && this.fErrorHandler != null) {
                new DOMErrorImpl();
                DOMErrorImpl dOMErrorImpl2 = dOMErrorImpl;
                dOMErrorImpl2.fType = "pi-base-uri-not-preserved";
                dOMErrorImpl2.fRelatedData = nodeValueString2;
                dOMErrorImpl2.fSeverity = 1;
                boolean handleError = this.fErrorHandler.getErrorHandler().handleError(dOMErrorImpl2);
            }
        }
    }

    /* access modifiers changed from: protected */
    public final void handleBaseURI(Node node) {
        DOMErrorImpl dOMErrorImpl;
        Node node2 = node;
        if (this.fDocumentImpl != null) {
            short nodeType = node2.getNodeType();
            if (nodeType == 1) {
                if (this.fNamespaceAware) {
                    if (((Element) node2).getAttributeNodeNS("http://www.w3.org/XML/1998/namespace", "base") != null) {
                        return;
                    }
                } else if (((Element) node2).getAttributeNode("xml:base") != null) {
                    return;
                }
                String baseURI = ((EntityReferenceImpl) this.fCurrentNode).getBaseURI();
                if (baseURI != null && !baseURI.equals(this.fDocumentImpl.getDocumentURI())) {
                    if (this.fNamespaceAware) {
                        ((Element) node2).setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:base", baseURI);
                    } else {
                        ((Element) node2).setAttribute("xml:base", baseURI);
                    }
                }
            } else if (nodeType == 7) {
                String baseURI2 = ((EntityReferenceImpl) this.fCurrentNode).getBaseURI();
                if (baseURI2 != null && this.fErrorHandler != null) {
                    new DOMErrorImpl();
                    DOMErrorImpl dOMErrorImpl2 = dOMErrorImpl;
                    dOMErrorImpl2.fType = "pi-base-uri-not-preserved";
                    dOMErrorImpl2.fRelatedData = baseURI2;
                    dOMErrorImpl2.fSeverity = 1;
                    boolean handleError = this.fErrorHandler.getErrorHandler().handleError(dOMErrorImpl2);
                }
            }
        }
    }

    public void ignorableWhitespace(XMLString xMLString, Augmentations augmentations) throws XNIException {
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (this.fIncludeIgnorableWhitespace && !this.fFilterReject) {
            if (!this.fDeferNodeExpansion) {
                Node lastChild = this.fCurrentNode.getLastChild();
                if (lastChild == null || lastChild.getNodeType() != 3) {
                    Text createTextNode = this.fDocument.createTextNode(xMLString2.toString());
                    if (this.fDocumentImpl != null) {
                        ((TextImpl) createTextNode).setIgnorableWhitespace(true);
                    }
                    Node appendChild = this.fCurrentNode.appendChild(createTextNode);
                    return;
                }
                ((Text) lastChild).appendData(xMLString2.toString());
                return;
            }
            this.fDeferredDocumentImpl.appendChild(this.fCurrentNodeIndex, this.fDeferredDocumentImpl.createDeferredTextNode(xMLString2.toString(), true));
        }
    }

    public void ignoredCharacters(XMLString xMLString, Augmentations augmentations) throws XNIException {
    }

    public void internalEntityDecl(String str, XMLString xMLString, XMLString xMLString2, Augmentations augmentations) throws XNIException {
        String str2 = str;
        XMLString xMLString3 = xMLString;
        XMLString xMLString4 = xMLString2;
        Augmentations augmentations2 = augmentations;
        if (this.fInternalSubset != null && !this.fInDTDExternalSubset) {
            StringBuffer append = this.fInternalSubset.append("<!ENTITY ");
            if (str2.startsWith("%")) {
                StringBuffer append2 = this.fInternalSubset.append("% ");
                StringBuffer append3 = this.fInternalSubset.append(str2.substring(1));
            } else {
                StringBuffer append4 = this.fInternalSubset.append(str2);
            }
            StringBuffer append5 = this.fInternalSubset.append(' ');
            String xMLString5 = xMLString4.toString();
            boolean z = xMLString5.indexOf(39) == -1;
            StringBuffer append6 = this.fInternalSubset.append(z ? '\'' : '\"');
            StringBuffer append7 = this.fInternalSubset.append(xMLString5);
            StringBuffer append8 = this.fInternalSubset.append(z ? '\'' : '\"');
            StringBuffer append9 = this.fInternalSubset.append(">\n");
        }
        if (!str2.startsWith("%")) {
            if (this.fDocumentType != null) {
                NamedNodeMap entities = this.fDocumentType.getEntities();
                if (((EntityImpl) entities.getNamedItem(str2)) == null) {
                    EntityImpl entityImpl = (EntityImpl) this.fDocumentImpl.createEntity(str2);
                    entityImpl.setBaseURI((String) this.fBaseURIStack.peek());
                    Node namedItem = entities.setNamedItem(entityImpl);
                }
            }
            if (this.fDocumentTypeIndex != -1) {
                boolean z2 = false;
                int lastChild = this.fDeferredDocumentImpl.getLastChild(this.fDocumentTypeIndex, false);
                while (true) {
                    int i = lastChild;
                    if (i != -1) {
                        if (this.fDeferredDocumentImpl.getNodeType(i, false) == 6 && this.fDeferredDocumentImpl.getNodeName(i, false).equals(str2)) {
                            z2 = true;
                            break;
                        }
                        lastChild = this.fDeferredDocumentImpl.getRealPrevSibling(i, false);
                    } else {
                        break;
                    }
                }
                if (!z2) {
                    this.fDeferredDocumentImpl.appendChild(this.fDocumentTypeIndex, this.fDeferredDocumentImpl.createDeferredEntity(str2, (String) null, (String) null, (String) null, (String) this.fBaseURIStack.peek()));
                }
            }
        }
    }

    public void notationDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
        String str2 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        Augmentations augmentations2 = augmentations;
        String publicId = xMLResourceIdentifier2.getPublicId();
        String literalSystemId = xMLResourceIdentifier2.getLiteralSystemId();
        if (this.fInternalSubset != null && !this.fInDTDExternalSubset) {
            StringBuffer append = this.fInternalSubset.append("<!NOTATION ");
            StringBuffer append2 = this.fInternalSubset.append(str2);
            if (publicId != null) {
                StringBuffer append3 = this.fInternalSubset.append(" PUBLIC '");
                StringBuffer append4 = this.fInternalSubset.append(publicId);
                if (literalSystemId != null) {
                    StringBuffer append5 = this.fInternalSubset.append("' '");
                    StringBuffer append6 = this.fInternalSubset.append(literalSystemId);
                }
            } else {
                StringBuffer append7 = this.fInternalSubset.append(" SYSTEM '");
                StringBuffer append8 = this.fInternalSubset.append(literalSystemId);
            }
            StringBuffer append9 = this.fInternalSubset.append("'>\n");
        }
        if (!(this.fDocumentImpl == null || this.fDocumentType == null)) {
            NamedNodeMap notations = this.fDocumentType.getNotations();
            if (notations.getNamedItem(str2) == null) {
                NotationImpl notationImpl = (NotationImpl) this.fDocumentImpl.createNotation(str2);
                notationImpl.setPublicId(publicId);
                notationImpl.setSystemId(literalSystemId);
                notationImpl.setBaseURI(xMLResourceIdentifier2.getBaseSystemId());
                Node namedItem = notations.setNamedItem(notationImpl);
            }
        }
        if (this.fDocumentTypeIndex != -1) {
            boolean z = false;
            int lastChild = this.fDeferredDocumentImpl.getLastChild(this.fDocumentTypeIndex, false);
            while (true) {
                int i = lastChild;
                if (i != -1) {
                    if (this.fDeferredDocumentImpl.getNodeType(i, false) == 12 && this.fDeferredDocumentImpl.getNodeName(i, false).equals(str2)) {
                        z = true;
                        break;
                    }
                    lastChild = this.fDeferredDocumentImpl.getPrevSibling(i, false);
                } else {
                    break;
                }
            }
            if (!z) {
                this.fDeferredDocumentImpl.appendChild(this.fDocumentTypeIndex, this.fDeferredDocumentImpl.createDeferredNotation(str2, publicId, literalSystemId, xMLResourceIdentifier2.getBaseSystemId()));
            }
        }
    }

    public void processingInstruction(String str, XMLString xMLString, Augmentations augmentations) throws XNIException {
        String str2 = str;
        XMLString xMLString2 = xMLString;
        Augmentations augmentations2 = augmentations;
        if (this.fInDTD) {
            if (this.fInternalSubset != null && !this.fInDTDExternalSubset) {
                StringBuffer append = this.fInternalSubset.append("<?");
                StringBuffer append2 = this.fInternalSubset.append(str2);
                if (xMLString2.length > 0) {
                    StringBuffer append3 = this.fInternalSubset.append(' ').append(xMLString2.ch, xMLString2.offset, xMLString2.length);
                }
                StringBuffer append4 = this.fInternalSubset.append("?>");
            }
        } else if (this.fDeferNodeExpansion) {
            this.fDeferredDocumentImpl.appendChild(this.fCurrentNodeIndex, this.fDeferredDocumentImpl.createDeferredProcessingInstruction(str2, xMLString2.toString()));
        } else if (!this.fFilterReject) {
            ProcessingInstruction createProcessingInstruction = this.fDocument.createProcessingInstruction(str2, xMLString2.toString());
            setCharacterData(false);
            Node appendChild = this.fCurrentNode.appendChild(createProcessingInstruction);
            if (this.fDOMFilter != null && !this.fInEntityRef && (this.fDOMFilter.getWhatToShow() & 64) != 0) {
                switch (this.fDOMFilter.acceptNode(createProcessingInstruction)) {
                    case 2:
                    case 3:
                        Node removeChild = this.fCurrentNode.removeChild(createProcessingInstruction);
                        this.fFirstChunk = true;
                        return;
                    case 4:
                        throw Abort.INSTANCE;
                    default:
                        return;
                }
            }
        }
    }

    public void reset() throws XNIException {
        super.reset();
        this.fCreateEntityRefNodes = this.fConfiguration.getFeature(CREATE_ENTITY_REF_NODES);
        this.fIncludeIgnorableWhitespace = this.fConfiguration.getFeature(INCLUDE_IGNORABLE_WHITESPACE);
        this.fDeferNodeExpansion = this.fConfiguration.getFeature(DEFER_NODE_EXPANSION);
        this.fNamespaceAware = this.fConfiguration.getFeature(NAMESPACES);
        this.fIncludeComments = this.fConfiguration.getFeature(INCLUDE_COMMENTS_FEATURE);
        this.fCreateCDATANodes = this.fConfiguration.getFeature(CREATE_CDATA_NODES_FEATURE);
        setDocumentClassName((String) this.fConfiguration.getProperty(DOCUMENT_CLASS_NAME));
        this.fDocument = null;
        this.fDocumentImpl = null;
        this.fStorePSVI = false;
        this.fDocumentType = null;
        this.fDocumentTypeIndex = -1;
        this.fDeferredDocumentImpl = null;
        this.fCurrentNode = null;
        this.fStringBuffer.setLength(0);
        this.fRoot = null;
        this.fInDTD = false;
        this.fInDTDExternalSubset = false;
        this.fInCDATASection = false;
        this.fFirstChunk = false;
        this.fCurrentCDATASection = null;
        this.fCurrentCDATASectionIndex = -1;
        this.fBaseURIStack.removeAllElements();
    }

    /* access modifiers changed from: protected */
    public void setCharacterData(boolean z) {
        this.fFirstChunk = z;
        Node lastChild = this.fCurrentNode.getLastChild();
        if (lastChild != null) {
            if (this.fStringBuffer.length() > 0) {
                if (lastChild.getNodeType() == 3) {
                    if (this.fDocumentImpl != null) {
                        ((TextImpl) lastChild).replaceData(this.fStringBuffer.toString());
                    } else {
                        ((Text) lastChild).setData(this.fStringBuffer.toString());
                    }
                }
                this.fStringBuffer.setLength(0);
            }
            if (this.fDOMFilter != null && !this.fInEntityRef && lastChild.getNodeType() == 3 && (this.fDOMFilter.getWhatToShow() & 4) != 0) {
                switch (this.fDOMFilter.acceptNode(lastChild)) {
                    case 2:
                    case 3:
                        Node removeChild = this.fCurrentNode.removeChild(lastChild);
                        return;
                    case 4:
                        throw Abort.INSTANCE;
                    default:
                        return;
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void setDocumentClassName(String str) {
        Throwable th;
        Class cls;
        Throwable th2;
        String str2 = str;
        if (str2 == null) {
            str2 = DEFAULT_DOCUMENT_CLASS_NAME;
        }
        if (!str2.equals(DEFAULT_DOCUMENT_CLASS_NAME) && !str2.equals(PSVI_DOCUMENT_CLASS_NAME)) {
            try {
                Class findProviderClass = ObjectFactory.findProviderClass(str2, ObjectFactory.findClassLoader(), true);
                if (class$org$w3c$dom$Document == null) {
                    Class class$ = class$("org.w3c.dom.Document");
                    cls = class$;
                    class$org$w3c$dom$Document = class$;
                } else {
                    cls = class$org$w3c$dom$Document;
                }
                if (!cls.isAssignableFrom(findProviderClass)) {
                    Throwable th3 = th2;
                    new IllegalArgumentException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "InvalidDocumentClassName", new Object[]{str2}));
                    throw th3;
                }
            } catch (ClassNotFoundException e) {
                ClassNotFoundException classNotFoundException = e;
                Throwable th4 = th;
                new IllegalArgumentException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "MissingDocumentClassName", new Object[]{str2}));
                throw th4;
            }
        }
        this.fDocumentClassName = str2;
        if (!str2.equals(DEFAULT_DOCUMENT_CLASS_NAME)) {
            this.fDeferNodeExpansion = false;
        }
    }

    public void setLocale(Locale locale) {
        this.fConfiguration.setLocale(locale);
    }

    public void startAttlist(String str, Augmentations augmentations) throws XNIException {
    }

    public void startCDATA(Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        this.fInCDATASection = true;
        if (!this.fDeferNodeExpansion && !this.fFilterReject && this.fCreateCDATANodes) {
            setCharacterData(false);
        }
    }

    public void startConditional(short s, Augmentations augmentations) throws XNIException {
    }

    public void startDTD(XMLLocator xMLLocator, Augmentations augmentations) throws XNIException {
        StringBuffer stringBuffer;
        XMLLocator xMLLocator2 = xMLLocator;
        Augmentations augmentations2 = augmentations;
        this.fInDTD = true;
        if (xMLLocator2 != null) {
            Object push = this.fBaseURIStack.push(xMLLocator2.getBaseSystemId());
        }
        if (this.fDeferNodeExpansion || this.fDocumentImpl != null) {
            new StringBuffer(1024);
            this.fInternalSubset = stringBuffer;
        }
    }

    public void startDocument(XMLLocator xMLLocator, String str, NamespaceContext namespaceContext, Augmentations augmentations) throws XNIException {
        DeferredDocumentImpl deferredDocumentImpl;
        Throwable th;
        Document document;
        Document document2;
        XMLLocator xMLLocator2 = xMLLocator;
        String str2 = str;
        NamespaceContext namespaceContext2 = namespaceContext;
        Augmentations augmentations2 = augmentations;
        this.fLocator = xMLLocator2;
        if (!this.fDeferNodeExpansion) {
            if (this.fDocumentClassName.equals(DEFAULT_DOCUMENT_CLASS_NAME)) {
                new DocumentImpl();
                this.fDocument = document2;
                this.fDocumentImpl = (CoreDocumentImpl) this.fDocument;
                this.fDocumentImpl.setStrictErrorChecking(false);
                this.fDocumentImpl.setInputEncoding(str2);
                this.fDocumentImpl.setDocumentURI(xMLLocator2.getExpandedSystemId());
            } else if (this.fDocumentClassName.equals(PSVI_DOCUMENT_CLASS_NAME)) {
                new PSVIDocumentImpl();
                this.fDocument = document;
                this.fDocumentImpl = (CoreDocumentImpl) this.fDocument;
                this.fStorePSVI = true;
                this.fDocumentImpl.setStrictErrorChecking(false);
                this.fDocumentImpl.setInputEncoding(str2);
                this.fDocumentImpl.setDocumentURI(xMLLocator2.getExpandedSystemId());
            } else {
                try {
                    ClassLoader findClassLoader = ObjectFactory.findClassLoader();
                    Class findProviderClass = ObjectFactory.findProviderClass(this.fDocumentClassName, findClassLoader, true);
                    this.fDocument = (Document) findProviderClass.newInstance();
                    if (ObjectFactory.findProviderClass(CORE_DOCUMENT_CLASS_NAME, findClassLoader, true).isAssignableFrom(findProviderClass)) {
                        this.fDocumentImpl = (CoreDocumentImpl) this.fDocument;
                        if (ObjectFactory.findProviderClass(PSVI_DOCUMENT_CLASS_NAME, findClassLoader, true).isAssignableFrom(findProviderClass)) {
                            this.fStorePSVI = true;
                        }
                        this.fDocumentImpl.setStrictErrorChecking(false);
                        this.fDocumentImpl.setInputEncoding(str2);
                        if (xMLLocator2 != null) {
                            this.fDocumentImpl.setDocumentURI(xMLLocator2.getExpandedSystemId());
                        }
                    }
                } catch (ClassNotFoundException e) {
                    ClassNotFoundException classNotFoundException = e;
                } catch (Exception e2) {
                    Exception exc = e2;
                    Throwable th2 = th;
                    new RuntimeException(DOMMessageFormatter.formatMessage(DOMMessageFormatter.DOM_DOMAIN, "CannotCreateDocumentClass", new Object[]{this.fDocumentClassName}));
                    throw th2;
                }
            }
            this.fCurrentNode = this.fDocument;
            return;
        }
        new DeferredDocumentImpl(this.fNamespaceAware);
        this.fDeferredDocumentImpl = deferredDocumentImpl;
        this.fDocument = this.fDeferredDocumentImpl;
        this.fDocumentIndex = this.fDeferredDocumentImpl.createDeferredDocument();
        this.fDeferredDocumentImpl.setInputEncoding(str2);
        this.fDeferredDocumentImpl.setDocumentURI(xMLLocator2.getExpandedSystemId());
        this.fCurrentNodeIndex = this.fDocumentIndex;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:40:0x017e, code lost:
        if (r2.fAttrQName.prefix == null) goto L_0x0180;
     */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0196  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x01df  */
    /* JADX WARNING: Removed duplicated region for block: B:97:0x01f1 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void startElement(org.apache.xerces.xni.QName r28, org.apache.xerces.xni.XMLAttributes r29, org.apache.xerces.xni.Augmentations r30) throws org.apache.xerces.xni.XNIException {
        /*
            r27 = this;
            r2 = r27
            r3 = r28
            r4 = r29
            r5 = r30
            r18 = r2
            r0 = r18
            boolean r0 = r0.fDeferNodeExpansion
            r18 = r0
            if (r18 != 0) goto L_0x02ae
            r18 = r2
            r0 = r18
            boolean r0 = r0.fFilterReject
            r18 = r0
            if (r18 == 0) goto L_0x0035
            r18 = r2
            r26 = r18
            r18 = r26
            r19 = r26
            r0 = r19
            int r0 = r0.fRejectedElementDepth
            r19 = r0
            r20 = 1
            int r19 = r19 + 1
            r0 = r19
            r1 = r18
            r1.fRejectedElementDepth = r0
        L_0x0034:
            return
        L_0x0035:
            r18 = r2
            r19 = r3
            org.w3c.dom.Element r18 = r18.createElementNode(r19)
            r6 = r18
            r18 = r4
            int r18 = r18.getLength()
            r7 = r18
            r18 = 0
            r8 = r18
            r18 = 0
            r9 = r18
        L_0x004f:
            r18 = r9
            r19 = r7
            r0 = r18
            r1 = r19
            if (r0 < r1) goto L_0x00de
            r18 = r2
            r19 = 0
            r18.setCharacterData(r19)
            r18 = r5
            if (r18 == 0) goto L_0x009c
            r18 = r5
            java.lang.String r19 = "ELEMENT_PSVI"
            java.lang.Object r18 = r18.getItem(r19)
            org.apache.xerces.xs.ElementPSVI r18 = (org.apache.xerces.xs.ElementPSVI) r18
            r10 = r18
            r18 = r10
            if (r18 == 0) goto L_0x009c
            r18 = r2
            r0 = r18
            boolean r0 = r0.fNamespaceAware
            r18 = r0
            if (r18 == 0) goto L_0x009c
            r18 = r10
            org.apache.xerces.xs.XSSimpleTypeDefinition r18 = r18.getMemberTypeDefinition()
            r11 = r18
            r18 = r11
            if (r18 != 0) goto L_0x0093
            r18 = r10
            org.apache.xerces.xs.XSTypeDefinition r18 = r18.getTypeDefinition()
            r11 = r18
        L_0x0093:
            r18 = r6
            org.apache.xerces.dom.ElementNSImpl r18 = (org.apache.xerces.dom.ElementNSImpl) r18
            r19 = r11
            r18.setType(r19)
        L_0x009c:
            r18 = r2
            r0 = r18
            org.w3c.dom.ls.LSParserFilter r0 = r0.fDOMFilter
            r18 = r0
            if (r18 == 0) goto L_0x00c4
            r18 = r2
            r0 = r18
            boolean r0 = r0.fInEntityRef
            r18 = r0
            if (r18 != 0) goto L_0x00c4
            r18 = r2
            r0 = r18
            org.w3c.dom.Node r0 = r0.fRoot
            r18 = r0
            if (r18 != 0) goto L_0x0248
            r18 = r2
            r19 = r6
            r0 = r19
            r1 = r18
            r1.fRoot = r0
        L_0x00c4:
            r18 = r2
            r0 = r18
            org.w3c.dom.Node r0 = r0.fCurrentNode
            r18 = r0
            r19 = r6
            org.w3c.dom.Node r18 = r18.appendChild(r19)
            r18 = r2
            r19 = r6
            r0 = r19
            r1 = r18
            r1.fCurrentNode = r0
        L_0x00dc:
            goto L_0x0034
        L_0x00de:
            r18 = r4
            r19 = r9
            r20 = r2
            r0 = r20
            org.apache.xerces.xni.QName r0 = r0.fAttrQName
            r20 = r0
            r18.getName(r19, r20)
            r18 = r2
            r19 = r2
            r0 = r19
            org.apache.xerces.xni.QName r0 = r0.fAttrQName
            r19 = r0
            org.w3c.dom.Attr r18 = r18.createAttrNode(r19)
            r10 = r18
            r18 = r4
            r19 = r9
            java.lang.String r18 = r18.getValue((int) r19)
            r11 = r18
            r18 = r4
            r19 = r9
            org.apache.xerces.xni.Augmentations r18 = r18.getAugmentations((int) r19)
            java.lang.String r19 = "ATTRIBUTE_PSVI"
            java.lang.Object r18 = r18.getItem(r19)
            org.apache.xerces.xs.AttributePSVI r18 = (org.apache.xerces.xs.AttributePSVI) r18
            r12 = r18
            r18 = r2
            r0 = r18
            boolean r0 = r0.fStorePSVI
            r18 = r0
            if (r18 == 0) goto L_0x0131
            r18 = r12
            if (r18 == 0) goto L_0x0131
            r18 = r10
            org.apache.xerces.dom.PSVIAttrNSImpl r18 = (org.apache.xerces.dom.PSVIAttrNSImpl) r18
            r19 = r12
            r18.setPSVI(r19)
        L_0x0131:
            r18 = r10
            r19 = r11
            r18.setValue(r19)
            r18 = r4
            r19 = r9
            boolean r18 = r18.isSpecified(r19)
            r13 = r18
            r18 = r13
            if (r18 != 0) goto L_0x01f5
            r18 = r8
            if (r18 != 0) goto L_0x0180
            r18 = r2
            r0 = r18
            org.apache.xerces.xni.QName r0 = r0.fAttrQName
            r18 = r0
            r0 = r18
            java.lang.String r0 = r0.uri
            r18 = r0
            if (r18 == 0) goto L_0x01f5
            r18 = r2
            r0 = r18
            org.apache.xerces.xni.QName r0 = r0.fAttrQName
            r18 = r0
            r0 = r18
            java.lang.String r0 = r0.uri
            r18 = r0
            java.lang.String r19 = org.apache.xerces.xni.NamespaceContext.XMLNS_URI
            r0 = r18
            r1 = r19
            if (r0 == r1) goto L_0x01f5
            r18 = r2
            r0 = r18
            org.apache.xerces.xni.QName r0 = r0.fAttrQName
            r18 = r0
            r0 = r18
            java.lang.String r0 = r0.prefix
            r18 = r0
            if (r18 != 0) goto L_0x01f5
        L_0x0180:
            r18 = r6
            r19 = r10
            org.w3c.dom.Attr r18 = r18.setAttributeNodeNS(r19)
            r18 = 1
            r8 = r18
        L_0x018c:
            r18 = r2
            r0 = r18
            org.apache.xerces.dom.CoreDocumentImpl r0 = r0.fDocumentImpl
            r18 = r0
            if (r18 == 0) goto L_0x01f1
            r18 = r10
            org.apache.xerces.dom.AttrImpl r18 = (org.apache.xerces.dom.AttrImpl) r18
            r14 = r18
            r18 = 0
            r15 = r18
            r18 = 0
            r16 = r18
            r18 = r12
            if (r18 == 0) goto L_0x0210
            r18 = r2
            r0 = r18
            boolean r0 = r0.fNamespaceAware
            r18 = r0
            if (r18 == 0) goto L_0x0210
            r18 = r12
            org.apache.xerces.xs.XSSimpleTypeDefinition r18 = r18.getMemberTypeDefinition()
            r15 = r18
            r18 = r15
            if (r18 != 0) goto L_0x01fe
            r18 = r12
            org.apache.xerces.xs.XSTypeDefinition r18 = r18.getTypeDefinition()
            r15 = r18
            r18 = r15
            if (r18 == 0) goto L_0x01db
            r18 = r15
            org.apache.xerces.impl.dv.XSSimpleType r18 = (org.apache.xerces.impl.dv.XSSimpleType) r18
            boolean r18 = r18.isIDType()
            r16 = r18
            r18 = r14
            r19 = r15
            r18.setType(r19)
        L_0x01db:
            r18 = r16
            if (r18 == 0) goto L_0x01ea
            r18 = r6
            org.apache.xerces.dom.ElementImpl r18 = (org.apache.xerces.dom.ElementImpl) r18
            r19 = r10
            r20 = 1
            r18.setIdAttributeNode(r19, r20)
        L_0x01ea:
            r18 = r14
            r19 = r13
            r18.setSpecified(r19)
        L_0x01f1:
            int r9 = r9 + 1
            goto L_0x004f
        L_0x01f5:
            r18 = r6
            r19 = r10
            org.w3c.dom.Attr r18 = r18.setAttributeNode(r19)
            goto L_0x018c
        L_0x01fe:
            r18 = r15
            org.apache.xerces.impl.dv.XSSimpleType r18 = (org.apache.xerces.impl.dv.XSSimpleType) r18
            boolean r18 = r18.isIDType()
            r16 = r18
            r18 = r14
            r19 = r15
            r18.setType(r19)
            goto L_0x01db
        L_0x0210:
            java.lang.Boolean r18 = java.lang.Boolean.TRUE
            r19 = r4
            r20 = r9
            org.apache.xerces.xni.Augmentations r19 = r19.getAugmentations((int) r20)
            java.lang.String r20 = "ATTRIBUTE_DECLARED"
            java.lang.Object r19 = r19.getItem(r20)
            boolean r18 = r18.equals(r19)
            r17 = r18
            r18 = r17
            if (r18 == 0) goto L_0x0240
            r18 = r4
            r19 = r9
            java.lang.String r18 = r18.getType((int) r19)
            r15 = r18
            java.lang.String r18 = "ID"
            r19 = r15
            boolean r18 = r18.equals(r19)
            r16 = r18
        L_0x0240:
            r18 = r14
            r19 = r15
            r18.setType(r19)
            goto L_0x01db
        L_0x0248:
            r18 = r2
            r0 = r18
            org.w3c.dom.ls.LSParserFilter r0 = r0.fDOMFilter
            r18 = r0
            r19 = r6
            short r18 = r18.startElement(r19)
            r10 = r18
            r18 = r10
            switch(r18) {
                case 2: goto L_0x027e;
                case 3: goto L_0x0294;
                case 4: goto L_0x027b;
                default: goto L_0x025d;
            }
        L_0x025d:
            r18 = r2
            r0 = r18
            java.util.Stack r0 = r0.fSkippedElemStack
            r18 = r0
            boolean r18 = r18.isEmpty()
            if (r18 != 0) goto L_0x00c4
            r18 = r2
            r0 = r18
            java.util.Stack r0 = r0.fSkippedElemStack
            r18 = r0
            java.lang.Boolean r19 = java.lang.Boolean.FALSE
            java.lang.Object r18 = r18.push(r19)
            goto L_0x00c4
        L_0x027b:
            org.apache.xerces.parsers.AbstractDOMParser$Abort r18 = org.apache.xerces.parsers.AbstractDOMParser.Abort.INSTANCE
            throw r18
        L_0x027e:
            r18 = r2
            r19 = 1
            r0 = r19
            r1 = r18
            r1.fFilterReject = r0
            r18 = r2
            r19 = 0
            r0 = r19
            r1 = r18
            r1.fRejectedElementDepth = r0
            goto L_0x0034
        L_0x0294:
            r18 = r2
            r19 = 1
            r0 = r19
            r1 = r18
            r1.fFirstChunk = r0
            r18 = r2
            r0 = r18
            java.util.Stack r0 = r0.fSkippedElemStack
            r18 = r0
            java.lang.Boolean r19 = java.lang.Boolean.TRUE
            java.lang.Object r18 = r18.push(r19)
            goto L_0x0034
        L_0x02ae:
            r18 = r2
            r0 = r18
            org.apache.xerces.dom.DeferredDocumentImpl r0 = r0.fDeferredDocumentImpl
            r18 = r0
            r19 = r2
            r0 = r19
            boolean r0 = r0.fNamespaceAware
            r19 = r0
            if (r19 == 0) goto L_0x030f
            r19 = r3
            r0 = r19
            java.lang.String r0 = r0.uri
            r19 = r0
        L_0x02c8:
            r20 = r3
            r0 = r20
            java.lang.String r0 = r0.rawname
            r20 = r0
            int r18 = r18.createDeferredElement(r19, r20)
            r6 = r18
            r18 = 0
            r7 = r18
            r18 = r4
            int r18 = r18.getLength()
            r8 = r18
            r18 = r8
            r19 = 1
            int r18 = r18 + -1
            r9 = r18
        L_0x02ea:
            r18 = r9
            if (r18 >= 0) goto L_0x0312
            r18 = r2
            r0 = r18
            org.apache.xerces.dom.DeferredDocumentImpl r0 = r0.fDeferredDocumentImpl
            r18 = r0
            r19 = r2
            r0 = r19
            int r0 = r0.fCurrentNodeIndex
            r19 = r0
            r20 = r6
            r18.appendChild(r19, r20)
            r18 = r2
            r19 = r6
            r0 = r19
            r1 = r18
            r1.fCurrentNodeIndex = r0
            goto L_0x00dc
        L_0x030f:
            r19 = 0
            goto L_0x02c8
        L_0x0312:
            r18 = r4
            r19 = r9
            org.apache.xerces.xni.Augmentations r18 = r18.getAugmentations((int) r19)
            java.lang.String r19 = "ATTRIBUTE_PSVI"
            java.lang.Object r18 = r18.getItem(r19)
            org.apache.xerces.xs.AttributePSVI r18 = (org.apache.xerces.xs.AttributePSVI) r18
            r10 = r18
            r18 = 0
            r11 = r18
            r18 = r10
            if (r18 == 0) goto L_0x039a
            r18 = r2
            r0 = r18
            boolean r0 = r0.fNamespaceAware
            r18 = r0
            if (r18 == 0) goto L_0x039a
            r18 = r10
            org.apache.xerces.xs.XSSimpleTypeDefinition r18 = r18.getMemberTypeDefinition()
            r7 = r18
            r18 = r7
            if (r18 != 0) goto L_0x038f
            r18 = r10
            org.apache.xerces.xs.XSTypeDefinition r18 = r18.getTypeDefinition()
            r7 = r18
            r18 = r7
            if (r18 == 0) goto L_0x0359
            r18 = r7
            org.apache.xerces.impl.dv.XSSimpleType r18 = (org.apache.xerces.impl.dv.XSSimpleType) r18
            boolean r18 = r18.isIDType()
            r11 = r18
        L_0x0359:
            r18 = r2
            r0 = r18
            org.apache.xerces.dom.DeferredDocumentImpl r0 = r0.fDeferredDocumentImpl
            r18 = r0
            r19 = r6
            r20 = r4
            r21 = r9
            java.lang.String r20 = r20.getQName(r21)
            r21 = r4
            r22 = r9
            java.lang.String r21 = r21.getURI(r22)
            r22 = r4
            r23 = r9
            java.lang.String r22 = r22.getValue((int) r23)
            r23 = r4
            r24 = r9
            boolean r23 = r23.isSpecified(r24)
            r24 = r11
            r25 = r7
            int r18 = r18.setDeferredAttribute(r19, r20, r21, r22, r23, r24, r25)
            int r9 = r9 + -1
            goto L_0x02ea
        L_0x038f:
            r18 = r7
            org.apache.xerces.impl.dv.XSSimpleType r18 = (org.apache.xerces.impl.dv.XSSimpleType) r18
            boolean r18 = r18.isIDType()
            r11 = r18
            goto L_0x0359
        L_0x039a:
            java.lang.Boolean r18 = java.lang.Boolean.TRUE
            r19 = r4
            r20 = r9
            org.apache.xerces.xni.Augmentations r19 = r19.getAugmentations((int) r20)
            java.lang.String r20 = "ATTRIBUTE_DECLARED"
            java.lang.Object r19 = r19.getItem(r20)
            boolean r18 = r18.equals(r19)
            r12 = r18
            r18 = r12
            if (r18 == 0) goto L_0x0359
            r18 = r4
            r19 = r9
            java.lang.String r18 = r18.getType((int) r19)
            r7 = r18
            java.lang.String r18 = "ID"
            r19 = r7
            boolean r18 = r18.equals(r19)
            r11 = r18
            goto L_0x0359
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.AbstractDOMParser.startElement(org.apache.xerces.xni.QName, org.apache.xerces.xni.XMLAttributes, org.apache.xerces.xni.Augmentations):void");
    }

    public void startExternalSubset(XMLResourceIdentifier xMLResourceIdentifier, Augmentations augmentations) throws XNIException {
        Augmentations augmentations2 = augmentations;
        Object push = this.fBaseURIStack.push(xMLResourceIdentifier.getBaseSystemId());
        this.fInDTDExternalSubset = true;
    }

    public void startGeneralEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        if (this.fDeferNodeExpansion) {
            int createDeferredEntityReference = this.fDeferredDocumentImpl.createDeferredEntityReference(str3, xMLResourceIdentifier2.getExpandedSystemId());
            if (this.fDocumentTypeIndex != -1) {
                int lastChild = this.fDeferredDocumentImpl.getLastChild(this.fDocumentTypeIndex, false);
                while (true) {
                    int i = lastChild;
                    if (i != -1) {
                        if (this.fDeferredDocumentImpl.getNodeType(i, false) == 6 && this.fDeferredDocumentImpl.getNodeName(i, false).equals(str3)) {
                            this.fDeferredEntityDecl = i;
                            this.fDeferredDocumentImpl.setInputEncoding(i, str4);
                            break;
                        }
                        lastChild = this.fDeferredDocumentImpl.getRealPrevSibling(i, false);
                    } else {
                        break;
                    }
                }
            }
            this.fDeferredDocumentImpl.appendChild(this.fCurrentNodeIndex, createDeferredEntityReference);
            this.fCurrentNodeIndex = createDeferredEntityReference;
        } else if (!this.fFilterReject) {
            setCharacterData(true);
            EntityReference createEntityReference = this.fDocument.createEntityReference(str3);
            if (this.fDocumentImpl != null) {
                EntityReferenceImpl entityReferenceImpl = (EntityReferenceImpl) createEntityReference;
                entityReferenceImpl.setBaseURI(xMLResourceIdentifier2.getExpandedSystemId());
                if (this.fDocumentType != null) {
                    this.fCurrentEntityDecl = (EntityImpl) this.fDocumentType.getEntities().getNamedItem(str3);
                    if (this.fCurrentEntityDecl != null) {
                        this.fCurrentEntityDecl.setInputEncoding(str4);
                    }
                }
                entityReferenceImpl.needsSyncChildren(false);
            }
            this.fInEntityRef = true;
            Node appendChild = this.fCurrentNode.appendChild(createEntityReference);
            this.fCurrentNode = createEntityReference;
        }
    }

    public void startParameterEntity(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        if (augmentations2 != null && this.fInternalSubset != null && !this.fInDTDExternalSubset && Boolean.TRUE.equals(augmentations2.getItem("ENTITY_SKIPPED"))) {
            StringBuffer append = this.fInternalSubset.append(str3).append(";\n");
        }
        Object push = this.fBaseURIStack.push(xMLResourceIdentifier2.getExpandedSystemId());
    }

    public void textDecl(String str, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        if (!this.fInDTD) {
            if (!this.fDeferNodeExpansion) {
                if (this.fCurrentEntityDecl != null && !this.fFilterReject) {
                    this.fCurrentEntityDecl.setXmlEncoding(str4);
                    if (str3 != null) {
                        this.fCurrentEntityDecl.setXmlVersion(str3);
                    }
                }
            } else if (this.fDeferredEntityDecl != -1) {
                this.fDeferredDocumentImpl.setEntityInfo(this.fDeferredEntityDecl, str3, str4);
            }
        }
    }

    public void unparsedEntityDecl(String str, XMLResourceIdentifier xMLResourceIdentifier, String str2, Augmentations augmentations) throws XNIException {
        String str3 = str;
        XMLResourceIdentifier xMLResourceIdentifier2 = xMLResourceIdentifier;
        String str4 = str2;
        Augmentations augmentations2 = augmentations;
        String publicId = xMLResourceIdentifier2.getPublicId();
        String literalSystemId = xMLResourceIdentifier2.getLiteralSystemId();
        if (this.fInternalSubset != null && !this.fInDTDExternalSubset) {
            StringBuffer append = this.fInternalSubset.append("<!ENTITY ");
            StringBuffer append2 = this.fInternalSubset.append(str3);
            StringBuffer append3 = this.fInternalSubset.append(' ');
            if (publicId != null) {
                StringBuffer append4 = this.fInternalSubset.append("PUBLIC '");
                StringBuffer append5 = this.fInternalSubset.append(publicId);
                if (literalSystemId != null) {
                    StringBuffer append6 = this.fInternalSubset.append("' '");
                    StringBuffer append7 = this.fInternalSubset.append(literalSystemId);
                }
            } else {
                StringBuffer append8 = this.fInternalSubset.append("SYSTEM '");
                StringBuffer append9 = this.fInternalSubset.append(literalSystemId);
            }
            StringBuffer append10 = this.fInternalSubset.append("' NDATA ");
            StringBuffer append11 = this.fInternalSubset.append(str4);
            StringBuffer append12 = this.fInternalSubset.append(">\n");
        }
        if (this.fDocumentType != null) {
            NamedNodeMap entities = this.fDocumentType.getEntities();
            if (((EntityImpl) entities.getNamedItem(str3)) == null) {
                EntityImpl entityImpl = (EntityImpl) this.fDocumentImpl.createEntity(str3);
                entityImpl.setPublicId(publicId);
                entityImpl.setSystemId(literalSystemId);
                entityImpl.setNotationName(str4);
                entityImpl.setBaseURI(xMLResourceIdentifier2.getBaseSystemId());
                Node namedItem = entities.setNamedItem(entityImpl);
            }
        }
        if (this.fDocumentTypeIndex != -1) {
            boolean z = false;
            int lastChild = this.fDeferredDocumentImpl.getLastChild(this.fDocumentTypeIndex, false);
            while (true) {
                int i = lastChild;
                if (i != -1) {
                    if (this.fDeferredDocumentImpl.getNodeType(i, false) == 6 && this.fDeferredDocumentImpl.getNodeName(i, false).equals(str3)) {
                        z = true;
                        break;
                    }
                    lastChild = this.fDeferredDocumentImpl.getRealPrevSibling(i, false);
                } else {
                    break;
                }
            }
            if (!z) {
                this.fDeferredDocumentImpl.appendChild(this.fDocumentTypeIndex, this.fDeferredDocumentImpl.createDeferredEntity(str3, publicId, literalSystemId, str4, xMLResourceIdentifier2.getBaseSystemId()));
            }
        }
    }

    public void xmlDecl(String str, String str2, String str3, Augmentations augmentations) throws XNIException {
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        Augmentations augmentations2 = augmentations;
        if (this.fDeferNodeExpansion) {
            if (str4 != null) {
                this.fDeferredDocumentImpl.setXmlVersion(str4);
            }
            this.fDeferredDocumentImpl.setXmlEncoding(str5);
            this.fDeferredDocumentImpl.setXmlStandalone("yes".equals(str6));
        } else if (this.fDocumentImpl != null) {
            if (str4 != null) {
                this.fDocumentImpl.setXmlVersion(str4);
            }
            this.fDocumentImpl.setXmlEncoding(str5);
            this.fDocumentImpl.setXmlStandalone("yes".equals(str6));
        }
    }
}
