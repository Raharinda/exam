package org.apache.xerces.parsers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import org.apache.xerces.impl.XML11DTDScannerImpl;
import org.apache.xerces.impl.XML11DocumentScannerImpl;
import org.apache.xerces.impl.XML11NSDocumentScannerImpl;
import org.apache.xerces.impl.XMLDocumentScannerImpl;
import org.apache.xerces.impl.XMLEntityManager;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.impl.XMLNSDocumentScannerImpl;
import org.apache.xerces.impl.XMLVersionDetector;
import org.apache.xerces.impl.dtd.XML11DTDProcessor;
import org.apache.xerces.impl.dtd.XML11DTDValidator;
import org.apache.xerces.impl.dtd.XML11NSDTDValidator;
import org.apache.xerces.impl.dtd.XMLDTDProcessor;
import org.apache.xerces.impl.dtd.XMLDTDValidator;
import org.apache.xerces.impl.dv.DTDDVFactory;
import org.apache.xerces.impl.validation.ValidationManager;
import org.apache.xerces.impl.xs.XMLSchemaValidator;
import org.apache.xerces.util.ParserConfigurationSettings;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.XMLDTDContentModelHandler;
import org.apache.xerces.xni.XMLDTDHandler;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLComponent;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLDTDScanner;
import org.apache.xerces.xni.parser.XMLDocumentScanner;
import org.apache.xerces.xni.parser.XMLDocumentSource;
import org.apache.xerces.xni.parser.XMLEntityResolver;
import org.apache.xerces.xni.parser.XMLErrorHandler;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLPullParserConfiguration;

public class XML11Configuration extends ParserConfigurationSettings implements XMLPullParserConfiguration, XML11Configurable {
    protected static final String ALLOW_JAVA_ENCODINGS = "http://apache.org/xml/features/allow-java-encodings";
    protected static final String CONTINUE_AFTER_FATAL_ERROR = "http://apache.org/xml/features/continue-after-fatal-error";
    protected static final String DATATYPE_VALIDATOR_FACTORY = "http://apache.org/xml/properties/internal/datatype-validator-factory";
    protected static final String DOCUMENT_SCANNER = "http://apache.org/xml/properties/internal/document-scanner";
    protected static final String DTD_PROCESSOR = "http://apache.org/xml/properties/internal/dtd-processor";
    protected static final String DTD_SCANNER = "http://apache.org/xml/properties/internal/dtd-scanner";
    protected static final String DTD_VALIDATOR = "http://apache.org/xml/properties/internal/validator/dtd";
    protected static final String ENTITY_MANAGER = "http://apache.org/xml/properties/internal/entity-manager";
    protected static final String ENTITY_RESOLVER = "http://apache.org/xml/properties/internal/entity-resolver";
    protected static final String ERROR_HANDLER = "http://apache.org/xml/properties/internal/error-handler";
    protected static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
    protected static final String EXTERNAL_GENERAL_ENTITIES = "http://xml.org/sax/features/external-general-entities";
    protected static final String EXTERNAL_PARAMETER_ENTITIES = "http://xml.org/sax/features/external-parameter-entities";
    protected static final String GENERATE_SYNTHETIC_ANNOTATIONS = "http://apache.org/xml/features/generate-synthetic-annotations";
    protected static final String HONOUR_ALL_SCHEMALOCATIONS = "http://apache.org/xml/features/honour-all-schemaLocations";
    protected static final String IDENTITY_CONSTRAINT_CHECKING = "http://apache.org/xml/features/validation/identity-constraint-checking";
    protected static final String ID_IDREF_CHECKING = "http://apache.org/xml/features/validation/id-idref-checking";
    protected static final String IGNORE_XSI_TYPE = "http://apache.org/xml/features/validation/schema/ignore-xsi-type-until-elemdecl";
    protected static final String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
    protected static final String JAXP_SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";
    protected static final String LOAD_EXTERNAL_DTD = "http://apache.org/xml/features/nonvalidating/load-external-dtd";
    protected static final String LOCALE = "http://apache.org/xml/properties/locale";
    protected static final String NAMESPACES = "http://xml.org/sax/features/namespaces";
    protected static final String NAMESPACE_BINDER = "http://apache.org/xml/properties/internal/namespace-binder";
    protected static final String NAMESPACE_GROWTH = "http://apache.org/xml/features/namespace-growth";
    protected static final String NORMALIZE_DATA = "http://apache.org/xml/features/validation/schema/normalized-value";
    protected static final String NOTIFY_BUILTIN_REFS = "http://apache.org/xml/features/scanner/notify-builtin-refs";
    protected static final String NOTIFY_CHAR_REFS = "http://apache.org/xml/features/scanner/notify-char-refs";
    protected static final boolean PRINT_EXCEPTION_STACK_TRACE = false;
    protected static final String ROOT_ELEMENT_DECL = "http://apache.org/xml/properties/validation/schema/root-element-declaration";
    protected static final String ROOT_TYPE_DEF = "http://apache.org/xml/properties/validation/schema/root-type-definition";
    protected static final String SCHEMA_AUGMENT_PSVI = "http://apache.org/xml/features/validation/schema/augment-psvi";
    protected static final String SCHEMA_DV_FACTORY = "http://apache.org/xml/properties/internal/validation/schema/dv-factory";
    protected static final String SCHEMA_ELEMENT_DEFAULT = "http://apache.org/xml/features/validation/schema/element-default";
    protected static final String SCHEMA_LOCATION = "http://apache.org/xml/properties/schema/external-schemaLocation";
    protected static final String SCHEMA_NONS_LOCATION = "http://apache.org/xml/properties/schema/external-noNamespaceSchemaLocation";
    protected static final String SCHEMA_VALIDATOR = "http://apache.org/xml/properties/internal/validator/schema";
    protected static final String SYMBOL_TABLE = "http://apache.org/xml/properties/internal/symbol-table";
    protected static final String TOLERATE_DUPLICATES = "http://apache.org/xml/features/internal/tolerate-duplicates";
    protected static final String UNPARSED_ENTITY_CHECKING = "http://apache.org/xml/features/validation/unparsed-entity-checking";
    protected static final String USE_GRAMMAR_POOL_ONLY = "http://apache.org/xml/features/internal/validation/schema/use-grammar-pool-only";
    protected static final String VALIDATE_ANNOTATIONS = "http://apache.org/xml/features/validate-annotations";
    protected static final String VALIDATION = "http://xml.org/sax/features/validation";
    protected static final String VALIDATION_MANAGER = "http://apache.org/xml/properties/internal/validation-manager";
    protected static final String WARN_ON_DUPLICATE_ATTDEF = "http://apache.org/xml/features/validation/warn-on-duplicate-attdef";
    protected static final String WARN_ON_DUPLICATE_ENTITYDEF = "http://apache.org/xml/features/warn-on-duplicate-entitydef";
    protected static final String WARN_ON_UNDECLARED_ELEMDEF = "http://apache.org/xml/features/validation/warn-on-undeclared-elemdef";
    protected static final String XML11_DATATYPE_VALIDATOR_FACTORY = "org.apache.xerces.impl.dv.dtd.XML11DTDDVFactoryImpl";
    protected static final String XMLGRAMMAR_POOL = "http://apache.org/xml/properties/internal/grammar-pool";
    protected static final String XMLSCHEMA_FULL_CHECKING = "http://apache.org/xml/features/validation/schema-full-checking";
    protected static final String XMLSCHEMA_VALIDATION = "http://apache.org/xml/features/validation/schema";
    protected static final String XML_STRING = "http://xml.org/sax/properties/xml-string";
    private boolean f11Initialized;
    protected final ArrayList fCommonComponents;
    protected final ArrayList fComponents;
    protected boolean fConfigUpdated;
    protected XMLDTDScanner fCurrentDTDScanner;
    protected DTDDVFactory fCurrentDVFactory;
    protected XMLDocumentScanner fCurrentScanner;
    protected XMLDTDContentModelHandler fDTDContentModelHandler;
    protected XMLDTDHandler fDTDHandler;
    protected final XMLDTDProcessor fDTDProcessor;
    protected final XMLDTDScanner fDTDScanner;
    protected final XMLDTDValidator fDTDValidator;
    protected final DTDDVFactory fDatatypeValidatorFactory;
    protected XMLDocumentHandler fDocumentHandler;
    protected XMLEntityManager fEntityManager;
    protected XMLErrorReporter fErrorReporter;
    protected XMLGrammarPool fGrammarPool;
    protected XMLInputSource fInputSource;
    protected XMLDocumentSource fLastComponent;
    protected Locale fLocale;
    protected final XMLNSDocumentScannerImpl fNamespaceScanner;
    protected XMLDTDValidator fNonNSDTDValidator;
    protected XMLDocumentScannerImpl fNonNSScanner;
    protected boolean fParseInProgress;
    protected XMLSchemaValidator fSchemaValidator;
    protected SymbolTable fSymbolTable;
    protected final ValidationManager fValidationManager;
    protected final XMLVersionDetector fVersionDetector;
    protected final ArrayList fXML11Components;
    protected XML11DTDProcessor fXML11DTDProcessor;
    protected XML11DTDScannerImpl fXML11DTDScanner;
    protected XML11DTDValidator fXML11DTDValidator;
    protected DTDDVFactory fXML11DatatypeFactory;
    protected XML11DocumentScannerImpl fXML11DocScanner;
    protected XML11NSDTDValidator fXML11NSDTDValidator;
    protected XML11NSDocumentScannerImpl fXML11NSDocScanner;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XML11Configuration() {
        this((SymbolTable) null, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XML11Configuration(SymbolTable symbolTable) {
        this(symbolTable, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public XML11Configuration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool) {
        this(symbolTable, xMLGrammarPool, (XMLComponentManager) null);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v54, resolved type: org.apache.xerces.xni.parser.XMLDTDScanner} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v56, resolved type: org.apache.xerces.impl.dtd.XMLDTDValidator} */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public XML11Configuration(org.apache.xerces.util.SymbolTable r13, org.apache.xerces.xni.grammars.XMLGrammarPool r14, org.apache.xerces.xni.parser.XMLComponentManager r15) {
        /*
            r12 = this;
            r0 = r12
            r1 = r13
            r2 = r14
            r3 = r15
            r7 = r0
            r8 = r3
            r7.<init>(r8)
            r7 = r0
            r8 = 0
            r7.fParseInProgress = r8
            r7 = r0
            r8 = 0
            r7.fConfigUpdated = r8
            r7 = r0
            r8 = 0
            r7.fXML11DatatypeFactory = r8
            r7 = r0
            r8 = 0
            r7.fXML11NSDocScanner = r8
            r7 = r0
            r8 = 0
            r7.fXML11DocScanner = r8
            r7 = r0
            r8 = 0
            r7.fXML11NSDTDValidator = r8
            r7 = r0
            r8 = 0
            r7.fXML11DTDValidator = r8
            r7 = r0
            r8 = 0
            r7.fXML11DTDScanner = r8
            r7 = r0
            r8 = 0
            r7.fXML11DTDProcessor = r8
            r7 = r0
            r8 = 0
            r7.f11Initialized = r8
            r7 = r0
            java.util.ArrayList r8 = new java.util.ArrayList
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fComponents = r8
            r7 = r0
            java.util.ArrayList r8 = new java.util.ArrayList
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fXML11Components = r8
            r7 = r0
            java.util.ArrayList r8 = new java.util.ArrayList
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fCommonComponents = r8
            r7 = r0
            java.util.ArrayList r8 = new java.util.ArrayList
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fRecognizedFeatures = r8
            r7 = r0
            java.util.ArrayList r8 = new java.util.ArrayList
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fRecognizedProperties = r8
            r7 = r0
            java.util.HashMap r8 = new java.util.HashMap
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fFeatures = r8
            r7 = r0
            java.util.HashMap r8 = new java.util.HashMap
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fProperties = r8
            r7 = 22
            java.lang.String[] r7 = new java.lang.String[r7]
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 0
            java.lang.String r10 = "http://apache.org/xml/features/continue-after-fatal-error"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 1
            java.lang.String r10 = "http://apache.org/xml/features/nonvalidating/load-external-dtd"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 2
            java.lang.String r10 = "http://xml.org/sax/features/validation"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 3
            java.lang.String r10 = "http://xml.org/sax/features/namespaces"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 4
            java.lang.String r10 = "http://apache.org/xml/features/validation/schema/normalized-value"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 5
            java.lang.String r10 = "http://apache.org/xml/features/validation/schema/element-default"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 6
            java.lang.String r10 = "http://apache.org/xml/features/validation/schema/augment-psvi"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 7
            java.lang.String r10 = "http://apache.org/xml/features/generate-synthetic-annotations"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 8
            java.lang.String r10 = "http://apache.org/xml/features/validate-annotations"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 9
            java.lang.String r10 = "http://apache.org/xml/features/honour-all-schemaLocations"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 10
            java.lang.String r10 = "http://apache.org/xml/features/namespace-growth"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 11
            java.lang.String r10 = "http://apache.org/xml/features/internal/tolerate-duplicates"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 12
            java.lang.String r10 = "http://apache.org/xml/features/validation/schema/ignore-xsi-type-until-elemdecl"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 13
            java.lang.String r10 = "http://apache.org/xml/features/validation/id-idref-checking"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 14
            java.lang.String r10 = "http://apache.org/xml/features/validation/identity-constraint-checking"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 15
            java.lang.String r10 = "http://apache.org/xml/features/validation/unparsed-entity-checking"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 16
            java.lang.String r10 = "http://apache.org/xml/features/internal/validation/schema/use-grammar-pool-only"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 17
            java.lang.String r10 = "http://apache.org/xml/features/validation/schema"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 18
            java.lang.String r10 = "http://apache.org/xml/features/validation/schema-full-checking"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 19
            java.lang.String r10 = "http://xml.org/sax/features/external-general-entities"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 20
            java.lang.String r10 = "http://xml.org/sax/features/external-parameter-entities"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 21
            java.lang.String r10 = "http://apache.org/xml/features/internal/parser-settings"
            r8[r9] = r10
            r4 = r7
            r7 = r0
            r8 = r4
            r7.addRecognizedFeatures(r8)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://xml.org/sax/features/validation"
            java.lang.Boolean r9 = java.lang.Boolean.FALSE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://xml.org/sax/features/namespaces"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://xml.org/sax/features/external-general-entities"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://xml.org/sax/features/external-parameter-entities"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/continue-after-fatal-error"
            java.lang.Boolean r9 = java.lang.Boolean.FALSE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/nonvalidating/load-external-dtd"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/validation/schema/element-default"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/validation/schema/normalized-value"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/validation/schema/augment-psvi"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/generate-synthetic-annotations"
            java.lang.Boolean r9 = java.lang.Boolean.FALSE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/validate-annotations"
            java.lang.Boolean r9 = java.lang.Boolean.FALSE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/honour-all-schemaLocations"
            java.lang.Boolean r9 = java.lang.Boolean.FALSE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/namespace-growth"
            java.lang.Boolean r9 = java.lang.Boolean.FALSE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/internal/tolerate-duplicates"
            java.lang.Boolean r9 = java.lang.Boolean.FALSE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/validation/schema/ignore-xsi-type-until-elemdecl"
            java.lang.Boolean r9 = java.lang.Boolean.FALSE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/validation/id-idref-checking"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/validation/identity-constraint-checking"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/validation/unparsed-entity-checking"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/internal/validation/schema/use-grammar-pool-only"
            java.lang.Boolean r9 = java.lang.Boolean.FALSE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            java.util.HashMap r7 = r7.fFeatures
            java.lang.String r8 = "http://apache.org/xml/features/internal/parser-settings"
            java.lang.Boolean r9 = java.lang.Boolean.TRUE
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = 22
            java.lang.String[] r7 = new java.lang.String[r7]
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 0
            java.lang.String r10 = "http://apache.org/xml/properties/internal/symbol-table"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 1
            java.lang.String r10 = "http://apache.org/xml/properties/internal/error-handler"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 2
            java.lang.String r10 = "http://apache.org/xml/properties/internal/entity-resolver"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 3
            java.lang.String r10 = "http://apache.org/xml/properties/internal/error-reporter"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 4
            java.lang.String r10 = "http://apache.org/xml/properties/internal/entity-manager"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 5
            java.lang.String r10 = "http://apache.org/xml/properties/internal/document-scanner"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 6
            java.lang.String r10 = "http://apache.org/xml/properties/internal/dtd-scanner"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 7
            java.lang.String r10 = "http://apache.org/xml/properties/internal/dtd-processor"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 8
            java.lang.String r10 = "http://apache.org/xml/properties/internal/validator/dtd"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 9
            java.lang.String r10 = "http://apache.org/xml/properties/internal/datatype-validator-factory"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 10
            java.lang.String r10 = "http://apache.org/xml/properties/internal/validation-manager"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 11
            java.lang.String r10 = "http://apache.org/xml/properties/internal/validator/schema"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 12
            java.lang.String r10 = "http://xml.org/sax/properties/xml-string"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 13
            java.lang.String r10 = "http://apache.org/xml/properties/internal/grammar-pool"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 14
            java.lang.String r10 = "http://java.sun.com/xml/jaxp/properties/schemaSource"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 15
            java.lang.String r10 = "http://java.sun.com/xml/jaxp/properties/schemaLanguage"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 16
            java.lang.String r10 = "http://apache.org/xml/properties/schema/external-schemaLocation"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 17
            java.lang.String r10 = "http://apache.org/xml/properties/schema/external-noNamespaceSchemaLocation"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 18
            java.lang.String r10 = "http://apache.org/xml/properties/locale"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 19
            java.lang.String r10 = "http://apache.org/xml/properties/validation/schema/root-type-definition"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 20
            java.lang.String r10 = "http://apache.org/xml/properties/validation/schema/root-element-declaration"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 21
            java.lang.String r10 = "http://apache.org/xml/properties/internal/validation/schema/dv-factory"
            r8[r9] = r10
            r5 = r7
            r7 = r0
            r8 = r5
            r7.addRecognizedProperties(r8)
            r7 = r1
            if (r7 != 0) goto L_0x0336
            org.apache.xerces.util.SymbolTable r7 = new org.apache.xerces.util.SymbolTable
            r11 = r7
            r7 = r11
            r8 = r11
            r8.<init>()
            r1 = r7
        L_0x0336:
            r7 = r0
            r8 = r1
            r7.fSymbolTable = r8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/symbol-table"
            r9 = r0
            org.apache.xerces.util.SymbolTable r9 = r9.fSymbolTable
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            r8 = r2
            r7.fGrammarPool = r8
            r7 = r0
            org.apache.xerces.xni.grammars.XMLGrammarPool r7 = r7.fGrammarPool
            if (r7 == 0) goto L_0x035d
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/grammar-pool"
            r9 = r0
            org.apache.xerces.xni.grammars.XMLGrammarPool r9 = r9.fGrammarPool
            java.lang.Object r7 = r7.put(r8, r9)
        L_0x035d:
            r7 = r0
            org.apache.xerces.impl.XMLEntityManager r8 = new org.apache.xerces.impl.XMLEntityManager
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fEntityManager = r8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/entity-manager"
            r9 = r0
            org.apache.xerces.impl.XMLEntityManager r9 = r9.fEntityManager
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.XMLEntityManager r8 = r8.fEntityManager
            r7.addCommonComponent(r8)
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r8 = new org.apache.xerces.impl.XMLErrorReporter
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fErrorReporter = r8
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r7 = r7.fErrorReporter
            r8 = r0
            org.apache.xerces.impl.XMLEntityManager r8 = r8.fEntityManager
            org.apache.xerces.impl.XMLEntityScanner r8 = r8.getEntityScanner()
            r7.setDocumentLocator(r8)
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/error-reporter"
            r9 = r0
            org.apache.xerces.impl.XMLErrorReporter r9 = r9.fErrorReporter
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.XMLErrorReporter r8 = r8.fErrorReporter
            r7.addCommonComponent(r8)
            r7 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r8 = new org.apache.xerces.impl.XMLNSDocumentScannerImpl
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fNamespaceScanner = r8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/document-scanner"
            r9 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r9 = r9.fNamespaceScanner
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r8 = r8.fNamespaceScanner
            r7.addComponent(r8)
            r7 = r0
            org.apache.xerces.impl.XMLDTDScannerImpl r8 = new org.apache.xerces.impl.XMLDTDScannerImpl
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fDTDScanner = r8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/dtd-scanner"
            r9 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r9 = r9.fDTDScanner
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r8 = r8.fDTDScanner
            org.apache.xerces.xni.parser.XMLComponent r8 = (org.apache.xerces.xni.parser.XMLComponent) r8
            r7.addComponent(r8)
            r7 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r8 = new org.apache.xerces.impl.dtd.XMLDTDProcessor
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fDTDProcessor = r8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/dtd-processor"
            r9 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r9 = r9.fDTDProcessor
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r8 = r8.fDTDProcessor
            r7.addComponent(r8)
            r7 = r0
            org.apache.xerces.impl.dtd.XMLNSDTDValidator r8 = new org.apache.xerces.impl.dtd.XMLNSDTDValidator
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fDTDValidator = r8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/validator/dtd"
            r9 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r9 = r9.fDTDValidator
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r8 = r8.fDTDValidator
            r7.addComponent(r8)
            r7 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r8 = org.apache.xerces.impl.dv.DTDDVFactory.getInstance()
            r7.fDatatypeValidatorFactory = r8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/datatype-validator-factory"
            r9 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r9 = r9.fDatatypeValidatorFactory
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            org.apache.xerces.impl.validation.ValidationManager r8 = new org.apache.xerces.impl.validation.ValidationManager
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fValidationManager = r8
            r7 = r0
            java.util.HashMap r7 = r7.fProperties
            java.lang.String r8 = "http://apache.org/xml/properties/internal/validation-manager"
            r9 = r0
            org.apache.xerces.impl.validation.ValidationManager r9 = r9.fValidationManager
            java.lang.Object r7 = r7.put(r8, r9)
            r7 = r0
            org.apache.xerces.impl.XMLVersionDetector r8 = new org.apache.xerces.impl.XMLVersionDetector
            r11 = r8
            r8 = r11
            r9 = r11
            r9.<init>()
            r7.fVersionDetector = r8
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r7 = r7.fErrorReporter
            java.lang.String r8 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            org.apache.xerces.util.MessageFormatter r7 = r7.getMessageFormatter(r8)
            if (r7 != 0) goto L_0x0486
            org.apache.xerces.impl.msg.XMLMessageFormatter r7 = new org.apache.xerces.impl.msg.XMLMessageFormatter
            r11 = r7
            r7 = r11
            r8 = r11
            r8.<init>()
            r6 = r7
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r7 = r7.fErrorReporter
            java.lang.String r8 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            r9 = r6
            r7.putMessageFormatter(r8, r9)
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r7 = r7.fErrorReporter
            java.lang.String r8 = "http://www.w3.org/TR/1999/REC-xml-names-19990114"
            r9 = r6
            r7.putMessageFormatter(r8, r9)
        L_0x0486:
            r7 = r0
            java.util.Locale r8 = java.util.Locale.getDefault()     // Catch:{ XNIException -> 0x0493 }
            r7.setLocale(r8)     // Catch:{ XNIException -> 0x0493 }
        L_0x048e:
            r7 = r0
            r8 = 0
            r7.fConfigUpdated = r8
            return
        L_0x0493:
            r7 = move-exception
            r6 = r7
            goto L_0x048e
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.XML11Configuration.<init>(org.apache.xerces.util.SymbolTable, org.apache.xerces.xni.grammars.XMLGrammarPool, org.apache.xerces.xni.parser.XMLComponentManager):void");
    }

    private void initXML11Components() {
        XML11DTDScannerImpl xML11DTDScannerImpl;
        XML11DTDProcessor xML11DTDProcessor;
        XML11NSDocumentScannerImpl xML11NSDocumentScannerImpl;
        XML11NSDTDValidator xML11NSDTDValidator;
        if (!this.f11Initialized) {
            this.fXML11DatatypeFactory = DTDDVFactory.getInstance(XML11_DATATYPE_VALIDATOR_FACTORY);
            new XML11DTDScannerImpl();
            this.fXML11DTDScanner = xML11DTDScannerImpl;
            addXML11Component(this.fXML11DTDScanner);
            new XML11DTDProcessor();
            this.fXML11DTDProcessor = xML11DTDProcessor;
            addXML11Component(this.fXML11DTDProcessor);
            new XML11NSDocumentScannerImpl();
            this.fXML11NSDocScanner = xML11NSDocumentScannerImpl;
            addXML11Component(this.fXML11NSDocScanner);
            new XML11NSDTDValidator();
            this.fXML11NSDTDValidator = xML11NSDTDValidator;
            addXML11Component(this.fXML11NSDTDValidator);
            this.f11Initialized = true;
        }
    }

    /* access modifiers changed from: protected */
    public void addCommonComponent(XMLComponent xMLComponent) {
        XMLComponent xMLComponent2 = xMLComponent;
        if (!this.fCommonComponents.contains(xMLComponent2)) {
            boolean add = this.fCommonComponents.add(xMLComponent2);
            addRecognizedParamsAndSetDefaults(xMLComponent2);
        }
    }

    /* access modifiers changed from: protected */
    public void addComponent(XMLComponent xMLComponent) {
        XMLComponent xMLComponent2 = xMLComponent;
        if (!this.fComponents.contains(xMLComponent2)) {
            boolean add = this.fComponents.add(xMLComponent2);
            addRecognizedParamsAndSetDefaults(xMLComponent2);
        }
    }

    /* access modifiers changed from: protected */
    public void addRecognizedParamsAndSetDefaults(XMLComponent xMLComponent) {
        XMLComponent xMLComponent2 = xMLComponent;
        String[] recognizedFeatures = xMLComponent2.getRecognizedFeatures();
        addRecognizedFeatures(recognizedFeatures);
        String[] recognizedProperties = xMLComponent2.getRecognizedProperties();
        addRecognizedProperties(recognizedProperties);
        if (recognizedFeatures != null) {
            for (int i = 0; i < recognizedFeatures.length; i++) {
                String str = recognizedFeatures[i];
                Boolean featureDefault = xMLComponent2.getFeatureDefault(str);
                if (featureDefault != null && !this.fFeatures.containsKey(str)) {
                    Object put = this.fFeatures.put(str, featureDefault);
                    this.fConfigUpdated = true;
                }
            }
        }
        if (recognizedProperties != null) {
            for (int i2 = 0; i2 < recognizedProperties.length; i2++) {
                String str2 = recognizedProperties[i2];
                Object propertyDefault = xMLComponent2.getPropertyDefault(str2);
                if (propertyDefault != null && !this.fProperties.containsKey(str2)) {
                    Object put2 = this.fProperties.put(str2, propertyDefault);
                    this.fConfigUpdated = true;
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void addXML11Component(XMLComponent xMLComponent) {
        XMLComponent xMLComponent2 = xMLComponent;
        if (!this.fXML11Components.contains(xMLComponent2)) {
            boolean add = this.fXML11Components.add(xMLComponent2);
            addRecognizedParamsAndSetDefaults(xMLComponent2);
        }
    }

    /* access modifiers changed from: protected */
    public void checkFeature(String str) throws XMLConfigurationException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        String str2 = str;
        if (str2.startsWith("http://apache.org/xml/features/")) {
            int length = str2.length() - "http://apache.org/xml/features/".length();
            if (length == "validation/dynamic".length() && str2.endsWith("validation/dynamic")) {
                return;
            }
            if (length == "validation/default-attribute-values".length() && str2.endsWith("validation/default-attribute-values")) {
                Throwable th5 = th4;
                new XMLConfigurationException(1, str2);
                throw th5;
            } else if (length == "validation/validate-content-models".length() && str2.endsWith("validation/validate-content-models")) {
                Throwable th6 = th3;
                new XMLConfigurationException(1, str2);
                throw th6;
            } else if (length == "nonvalidating/load-dtd-grammar".length() && str2.endsWith("nonvalidating/load-dtd-grammar")) {
                return;
            } else {
                if (length == "nonvalidating/load-external-dtd".length() && str2.endsWith("nonvalidating/load-external-dtd")) {
                    return;
                }
                if (length == "validation/validate-datatypes".length() && str2.endsWith("validation/validate-datatypes")) {
                    Throwable th7 = th2;
                    new XMLConfigurationException(1, str2);
                    throw th7;
                } else if (length == "validation/schema".length() && str2.endsWith("validation/schema")) {
                    return;
                } else {
                    if (length == "validation/schema-full-checking".length() && str2.endsWith("validation/schema-full-checking")) {
                        return;
                    }
                    if (length == "validation/schema/normalized-value".length() && str2.endsWith("validation/schema/normalized-value")) {
                        return;
                    }
                    if (length == "validation/schema/element-default".length() && str2.endsWith("validation/schema/element-default")) {
                        return;
                    }
                    if (length == "internal/parser-settings".length() && str2.endsWith("internal/parser-settings")) {
                        Throwable th8 = th;
                        new XMLConfigurationException(1, str2);
                        throw th8;
                    }
                }
            }
        }
        super.checkFeature(str2);
    }

    /* access modifiers changed from: protected */
    public void checkProperty(String str) throws XMLConfigurationException {
        Throwable th;
        String str2 = str;
        if (str2.startsWith("http://apache.org/xml/properties/")) {
            int length = str2.length() - "http://apache.org/xml/properties/".length();
            if (length == "internal/dtd-scanner".length() && str2.endsWith("internal/dtd-scanner")) {
                return;
            }
            if (length == "schema/external-schemaLocation".length() && str2.endsWith("schema/external-schemaLocation")) {
                return;
            }
            if (length == "schema/external-noNamespaceSchemaLocation".length() && str2.endsWith("schema/external-noNamespaceSchemaLocation")) {
                return;
            }
        }
        if (str2.startsWith("http://java.sun.com/xml/jaxp/properties/") && str2.length() - "http://java.sun.com/xml/jaxp/properties/".length() == "schemaSource".length() && str2.endsWith("schemaSource")) {
            return;
        }
        if (!str2.startsWith("http://xml.org/sax/properties/") || str2.length() - "http://xml.org/sax/properties/".length() != "xml-string".length() || !str2.endsWith("xml-string")) {
            super.checkProperty(str2);
            return;
        }
        Throwable th2 = th;
        new XMLConfigurationException(1, str2);
        throw th2;
    }

    public void cleanup() {
        this.fEntityManager.closeReaders();
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void configurePipeline() {
        /*
            r6 = this;
            r0 = r6
            r2 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r2 = r2.fCurrentDVFactory
            r3 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r3 = r3.fDatatypeValidatorFactory
            if (r2 == r3) goto L_0x0019
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r3 = r3.fDatatypeValidatorFactory
            r2.fCurrentDVFactory = r3
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/datatype-validator-factory"
            r4 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r4 = r4.fCurrentDVFactory
            r2.setProperty(r3, r4)
        L_0x0019:
            r2 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r2 = r2.fCurrentDTDScanner
            r3 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r3 = r3.fDTDScanner
            if (r2 == r3) goto L_0x003b
            r2 = r0
            r3 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r3 = r3.fDTDScanner
            r2.fCurrentDTDScanner = r3
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/dtd-scanner"
            r4 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r4 = r4.fCurrentDTDScanner
            r2.setProperty(r3, r4)
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/dtd-processor"
            r4 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r4 = r4.fDTDProcessor
            r2.setProperty(r3, r4)
        L_0x003b:
            r2 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r2 = r2.fDTDScanner
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r3 = r3.fDTDProcessor
            r2.setDTDHandler(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r2 = r2.fDTDProcessor
            r3 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r3 = r3.fDTDScanner
            r2.setDTDSource(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r2 = r2.fDTDProcessor
            r3 = r0
            org.apache.xerces.xni.XMLDTDHandler r3 = r3.fDTDHandler
            r2.setDTDHandler(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDTDHandler r2 = r2.fDTDHandler
            if (r2 == 0) goto L_0x0064
            r2 = r0
            org.apache.xerces.xni.XMLDTDHandler r2 = r2.fDTDHandler
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r3 = r3.fDTDProcessor
            r2.setDTDSource(r3)
        L_0x0064:
            r2 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r2 = r2.fDTDScanner
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r3 = r3.fDTDProcessor
            r2.setDTDContentModelHandler(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r2 = r2.fDTDProcessor
            r3 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r3 = r3.fDTDScanner
            r2.setDTDContentModelSource(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r2 = r2.fDTDProcessor
            r3 = r0
            org.apache.xerces.xni.XMLDTDContentModelHandler r3 = r3.fDTDContentModelHandler
            r2.setDTDContentModelHandler(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDTDContentModelHandler r2 = r2.fDTDContentModelHandler
            if (r2 == 0) goto L_0x008d
            r2 = r0
            org.apache.xerces.xni.XMLDTDContentModelHandler r2 = r2.fDTDContentModelHandler
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r3 = r3.fDTDProcessor
            r2.setDTDContentModelSource(r3)
        L_0x008d:
            r2 = r0
            java.util.HashMap r2 = r2.fFeatures
            java.lang.String r3 = "http://xml.org/sax/features/namespaces"
            java.lang.Object r2 = r2.get(r3)
            java.lang.Boolean r3 = java.lang.Boolean.TRUE
            if (r2 != r3) goto L_0x017a
            r2 = r0
            org.apache.xerces.xni.parser.XMLDocumentScanner r2 = r2.fCurrentScanner
            r3 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r3 = r3.fNamespaceScanner
            if (r2 == r3) goto L_0x00bd
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r3 = r3.fNamespaceScanner
            r2.fCurrentScanner = r3
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/document-scanner"
            r4 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r4 = r4.fNamespaceScanner
            r2.setProperty(r3, r4)
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/validator/dtd"
            r4 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r4 = r4.fDTDValidator
            r2.setProperty(r3, r4)
        L_0x00bd:
            r2 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r2 = r2.fNamespaceScanner
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fDTDValidator
            r2.setDTDValidator(r3)
            r2 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r2 = r2.fNamespaceScanner
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fDTDValidator
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r2 = r2.fDTDValidator
            r3 = r0
            org.apache.xerces.impl.XMLNSDocumentScannerImpl r3 = r3.fNamespaceScanner
            r2.setDocumentSource(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r2 = r2.fDTDValidator
            r3 = r0
            org.apache.xerces.xni.XMLDocumentHandler r3 = r3.fDocumentHandler
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            if (r2 == 0) goto L_0x00ef
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fDTDValidator
            r2.setDocumentSource(r3)
        L_0x00ef:
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fDTDValidator
            r2.fLastComponent = r3
        L_0x00f5:
            r2 = r0
            java.util.HashMap r2 = r2.fFeatures
            java.lang.String r3 = "http://apache.org/xml/features/validation/schema"
            java.lang.Object r2 = r2.get(r3)
            java.lang.Boolean r3 = java.lang.Boolean.TRUE
            if (r2 != r3) goto L_0x0179
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r2 = r2.fSchemaValidator
            if (r2 != 0) goto L_0x014a
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = new org.apache.xerces.impl.xs.XMLSchemaValidator
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r2.fSchemaValidator = r3
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/validator/schema"
            r4 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r4 = r4.fSchemaValidator
            r2.setProperty(r3, r4)
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.addCommonComponent(r3)
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r2 = r2.fSchemaValidator
            r3 = r0
            r2.reset(r3)
            r2 = r0
            org.apache.xerces.impl.XMLErrorReporter r2 = r2.fErrorReporter
            java.lang.String r3 = "http://www.w3.org/TR/xml-schema-1"
            org.apache.xerces.util.MessageFormatter r2 = r2.getMessageFormatter(r3)
            if (r2 != 0) goto L_0x014a
            org.apache.xerces.impl.xs.XSMessageFormatter r2 = new org.apache.xerces.impl.xs.XSMessageFormatter
            r5 = r2
            r2 = r5
            r3 = r5
            r3.<init>()
            r1 = r2
            r2 = r0
            org.apache.xerces.impl.XMLErrorReporter r2 = r2.fErrorReporter
            java.lang.String r3 = "http://www.w3.org/TR/xml-schema-1"
            r4 = r1
            r2.putMessageFormatter(r3, r4)
        L_0x014a:
            r2 = r0
            org.apache.xerces.xni.parser.XMLDocumentSource r2 = r2.fLastComponent
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r2 = r2.fSchemaValidator
            r3 = r0
            org.apache.xerces.xni.parser.XMLDocumentSource r3 = r3.fLastComponent
            r2.setDocumentSource(r3)
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r2 = r2.fSchemaValidator
            r3 = r0
            org.apache.xerces.xni.XMLDocumentHandler r3 = r3.fDocumentHandler
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            if (r2 == 0) goto L_0x0173
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.setDocumentSource(r3)
        L_0x0173:
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.fLastComponent = r3
        L_0x0179:
            return
        L_0x017a:
            r2 = r0
            org.apache.xerces.impl.XMLDocumentScannerImpl r2 = r2.fNonNSScanner
            if (r2 != 0) goto L_0x01a3
            r2 = r0
            org.apache.xerces.impl.XMLDocumentScannerImpl r3 = new org.apache.xerces.impl.XMLDocumentScannerImpl
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r2.fNonNSScanner = r3
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = new org.apache.xerces.impl.dtd.XMLDTDValidator
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r2.fNonNSDTDValidator = r3
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.XMLDocumentScannerImpl r3 = r3.fNonNSScanner
            r2.addComponent(r3)
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fNonNSDTDValidator
            r2.addComponent(r3)
        L_0x01a3:
            r2 = r0
            org.apache.xerces.xni.parser.XMLDocumentScanner r2 = r2.fCurrentScanner
            r3 = r0
            org.apache.xerces.impl.XMLDocumentScannerImpl r3 = r3.fNonNSScanner
            if (r2 == r3) goto L_0x01c5
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.XMLDocumentScannerImpl r3 = r3.fNonNSScanner
            r2.fCurrentScanner = r3
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/document-scanner"
            r4 = r0
            org.apache.xerces.impl.XMLDocumentScannerImpl r4 = r4.fNonNSScanner
            r2.setProperty(r3, r4)
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/validator/dtd"
            r4 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r4 = r4.fNonNSDTDValidator
            r2.setProperty(r3, r4)
        L_0x01c5:
            r2 = r0
            org.apache.xerces.impl.XMLDocumentScannerImpl r2 = r2.fNonNSScanner
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fNonNSDTDValidator
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r2 = r2.fNonNSDTDValidator
            r3 = r0
            org.apache.xerces.impl.XMLDocumentScannerImpl r3 = r3.fNonNSScanner
            r2.setDocumentSource(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r2 = r2.fNonNSDTDValidator
            r3 = r0
            org.apache.xerces.xni.XMLDocumentHandler r3 = r3.fDocumentHandler
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            if (r2 == 0) goto L_0x01ee
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fNonNSDTDValidator
            r2.setDocumentSource(r3)
        L_0x01ee:
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r3 = r3.fNonNSDTDValidator
            r2.fLastComponent = r3
            goto L_0x00f5
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.XML11Configuration.configurePipeline():void");
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void configureXML11Pipeline() {
        /*
            r6 = this;
            r0 = r6
            r2 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r2 = r2.fCurrentDVFactory
            r3 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r3 = r3.fXML11DatatypeFactory
            if (r2 == r3) goto L_0x0019
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r3 = r3.fXML11DatatypeFactory
            r2.fCurrentDVFactory = r3
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/datatype-validator-factory"
            r4 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r4 = r4.fCurrentDVFactory
            r2.setProperty(r3, r4)
        L_0x0019:
            r2 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r2 = r2.fCurrentDTDScanner
            r3 = r0
            org.apache.xerces.impl.XML11DTDScannerImpl r3 = r3.fXML11DTDScanner
            if (r2 == r3) goto L_0x003b
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.XML11DTDScannerImpl r3 = r3.fXML11DTDScanner
            r2.fCurrentDTDScanner = r3
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/dtd-scanner"
            r4 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r4 = r4.fCurrentDTDScanner
            r2.setProperty(r3, r4)
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/dtd-processor"
            r4 = r0
            org.apache.xerces.impl.dtd.XML11DTDProcessor r4 = r4.fXML11DTDProcessor
            r2.setProperty(r3, r4)
        L_0x003b:
            r2 = r0
            org.apache.xerces.impl.XML11DTDScannerImpl r2 = r2.fXML11DTDScanner
            r3 = r0
            org.apache.xerces.impl.dtd.XML11DTDProcessor r3 = r3.fXML11DTDProcessor
            r2.setDTDHandler(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XML11DTDProcessor r2 = r2.fXML11DTDProcessor
            r3 = r0
            org.apache.xerces.impl.XML11DTDScannerImpl r3 = r3.fXML11DTDScanner
            r2.setDTDSource(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XML11DTDProcessor r2 = r2.fXML11DTDProcessor
            r3 = r0
            org.apache.xerces.xni.XMLDTDHandler r3 = r3.fDTDHandler
            r2.setDTDHandler(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDTDHandler r2 = r2.fDTDHandler
            if (r2 == 0) goto L_0x0064
            r2 = r0
            org.apache.xerces.xni.XMLDTDHandler r2 = r2.fDTDHandler
            r3 = r0
            org.apache.xerces.impl.dtd.XML11DTDProcessor r3 = r3.fXML11DTDProcessor
            r2.setDTDSource(r3)
        L_0x0064:
            r2 = r0
            org.apache.xerces.impl.XML11DTDScannerImpl r2 = r2.fXML11DTDScanner
            r3 = r0
            org.apache.xerces.impl.dtd.XML11DTDProcessor r3 = r3.fXML11DTDProcessor
            r2.setDTDContentModelHandler(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XML11DTDProcessor r2 = r2.fXML11DTDProcessor
            r3 = r0
            org.apache.xerces.impl.XML11DTDScannerImpl r3 = r3.fXML11DTDScanner
            r2.setDTDContentModelSource(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XML11DTDProcessor r2 = r2.fXML11DTDProcessor
            r3 = r0
            org.apache.xerces.xni.XMLDTDContentModelHandler r3 = r3.fDTDContentModelHandler
            r2.setDTDContentModelHandler(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDTDContentModelHandler r2 = r2.fDTDContentModelHandler
            if (r2 == 0) goto L_0x008d
            r2 = r0
            org.apache.xerces.xni.XMLDTDContentModelHandler r2 = r2.fDTDContentModelHandler
            r3 = r0
            org.apache.xerces.impl.dtd.XML11DTDProcessor r3 = r3.fXML11DTDProcessor
            r2.setDTDContentModelSource(r3)
        L_0x008d:
            r2 = r0
            java.util.HashMap r2 = r2.fFeatures
            java.lang.String r3 = "http://xml.org/sax/features/namespaces"
            java.lang.Object r2 = r2.get(r3)
            java.lang.Boolean r3 = java.lang.Boolean.TRUE
            if (r2 != r3) goto L_0x017a
            r2 = r0
            org.apache.xerces.xni.parser.XMLDocumentScanner r2 = r2.fCurrentScanner
            r3 = r0
            org.apache.xerces.impl.XML11NSDocumentScannerImpl r3 = r3.fXML11NSDocScanner
            if (r2 == r3) goto L_0x00bd
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.XML11NSDocumentScannerImpl r3 = r3.fXML11NSDocScanner
            r2.fCurrentScanner = r3
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/document-scanner"
            r4 = r0
            org.apache.xerces.impl.XML11NSDocumentScannerImpl r4 = r4.fXML11NSDocScanner
            r2.setProperty(r3, r4)
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/validator/dtd"
            r4 = r0
            org.apache.xerces.impl.dtd.XML11NSDTDValidator r4 = r4.fXML11NSDTDValidator
            r2.setProperty(r3, r4)
        L_0x00bd:
            r2 = r0
            org.apache.xerces.impl.XML11NSDocumentScannerImpl r2 = r2.fXML11NSDocScanner
            r3 = r0
            org.apache.xerces.impl.dtd.XML11NSDTDValidator r3 = r3.fXML11NSDTDValidator
            r2.setDTDValidator(r3)
            r2 = r0
            org.apache.xerces.impl.XML11NSDocumentScannerImpl r2 = r2.fXML11NSDocScanner
            r3 = r0
            org.apache.xerces.impl.dtd.XML11NSDTDValidator r3 = r3.fXML11NSDTDValidator
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XML11NSDTDValidator r2 = r2.fXML11NSDTDValidator
            r3 = r0
            org.apache.xerces.impl.XML11NSDocumentScannerImpl r3 = r3.fXML11NSDocScanner
            r2.setDocumentSource(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XML11NSDTDValidator r2 = r2.fXML11NSDTDValidator
            r3 = r0
            org.apache.xerces.xni.XMLDocumentHandler r3 = r3.fDocumentHandler
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            if (r2 == 0) goto L_0x00ef
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            r3 = r0
            org.apache.xerces.impl.dtd.XML11NSDTDValidator r3 = r3.fXML11NSDTDValidator
            r2.setDocumentSource(r3)
        L_0x00ef:
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.dtd.XML11NSDTDValidator r3 = r3.fXML11NSDTDValidator
            r2.fLastComponent = r3
        L_0x00f5:
            r2 = r0
            java.util.HashMap r2 = r2.fFeatures
            java.lang.String r3 = "http://apache.org/xml/features/validation/schema"
            java.lang.Object r2 = r2.get(r3)
            java.lang.Boolean r3 = java.lang.Boolean.TRUE
            if (r2 != r3) goto L_0x0179
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r2 = r2.fSchemaValidator
            if (r2 != 0) goto L_0x014a
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = new org.apache.xerces.impl.xs.XMLSchemaValidator
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r2.fSchemaValidator = r3
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/validator/schema"
            r4 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r4 = r4.fSchemaValidator
            r2.setProperty(r3, r4)
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.addCommonComponent(r3)
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r2 = r2.fSchemaValidator
            r3 = r0
            r2.reset(r3)
            r2 = r0
            org.apache.xerces.impl.XMLErrorReporter r2 = r2.fErrorReporter
            java.lang.String r3 = "http://www.w3.org/TR/xml-schema-1"
            org.apache.xerces.util.MessageFormatter r2 = r2.getMessageFormatter(r3)
            if (r2 != 0) goto L_0x014a
            org.apache.xerces.impl.xs.XSMessageFormatter r2 = new org.apache.xerces.impl.xs.XSMessageFormatter
            r5 = r2
            r2 = r5
            r3 = r5
            r3.<init>()
            r1 = r2
            r2 = r0
            org.apache.xerces.impl.XMLErrorReporter r2 = r2.fErrorReporter
            java.lang.String r3 = "http://www.w3.org/TR/xml-schema-1"
            r4 = r1
            r2.putMessageFormatter(r3, r4)
        L_0x014a:
            r2 = r0
            org.apache.xerces.xni.parser.XMLDocumentSource r2 = r2.fLastComponent
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r2 = r2.fSchemaValidator
            r3 = r0
            org.apache.xerces.xni.parser.XMLDocumentSource r3 = r3.fLastComponent
            r2.setDocumentSource(r3)
            r2 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r2 = r2.fSchemaValidator
            r3 = r0
            org.apache.xerces.xni.XMLDocumentHandler r3 = r3.fDocumentHandler
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            if (r2 == 0) goto L_0x0173
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.setDocumentSource(r3)
        L_0x0173:
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.xs.XMLSchemaValidator r3 = r3.fSchemaValidator
            r2.fLastComponent = r3
        L_0x0179:
            return
        L_0x017a:
            r2 = r0
            org.apache.xerces.impl.XML11DocumentScannerImpl r2 = r2.fXML11DocScanner
            if (r2 != 0) goto L_0x01a3
            r2 = r0
            org.apache.xerces.impl.XML11DocumentScannerImpl r3 = new org.apache.xerces.impl.XML11DocumentScannerImpl
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r2.fXML11DocScanner = r3
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.XML11DocumentScannerImpl r3 = r3.fXML11DocScanner
            r2.addXML11Component(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XML11DTDValidator r3 = new org.apache.xerces.impl.dtd.XML11DTDValidator
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r2.fXML11DTDValidator = r3
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.dtd.XML11DTDValidator r3 = r3.fXML11DTDValidator
            r2.addXML11Component(r3)
        L_0x01a3:
            r2 = r0
            org.apache.xerces.xni.parser.XMLDocumentScanner r2 = r2.fCurrentScanner
            r3 = r0
            org.apache.xerces.impl.XML11DocumentScannerImpl r3 = r3.fXML11DocScanner
            if (r2 == r3) goto L_0x01c5
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.XML11DocumentScannerImpl r3 = r3.fXML11DocScanner
            r2.fCurrentScanner = r3
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/document-scanner"
            r4 = r0
            org.apache.xerces.impl.XML11DocumentScannerImpl r4 = r4.fXML11DocScanner
            r2.setProperty(r3, r4)
            r2 = r0
            java.lang.String r3 = "http://apache.org/xml/properties/internal/validator/dtd"
            r4 = r0
            org.apache.xerces.impl.dtd.XML11DTDValidator r4 = r4.fXML11DTDValidator
            r2.setProperty(r3, r4)
        L_0x01c5:
            r2 = r0
            org.apache.xerces.impl.XML11DocumentScannerImpl r2 = r2.fXML11DocScanner
            r3 = r0
            org.apache.xerces.impl.dtd.XML11DTDValidator r3 = r3.fXML11DTDValidator
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XML11DTDValidator r2 = r2.fXML11DTDValidator
            r3 = r0
            org.apache.xerces.impl.XML11DocumentScannerImpl r3 = r3.fXML11DocScanner
            r2.setDocumentSource(r3)
            r2 = r0
            org.apache.xerces.impl.dtd.XML11DTDValidator r2 = r2.fXML11DTDValidator
            r3 = r0
            org.apache.xerces.xni.XMLDocumentHandler r3 = r3.fDocumentHandler
            r2.setDocumentHandler(r3)
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            if (r2 == 0) goto L_0x01ee
            r2 = r0
            org.apache.xerces.xni.XMLDocumentHandler r2 = r2.fDocumentHandler
            r3 = r0
            org.apache.xerces.impl.dtd.XML11DTDValidator r3 = r3.fXML11DTDValidator
            r2.setDocumentSource(r3)
        L_0x01ee:
            r2 = r0
            r3 = r0
            org.apache.xerces.impl.dtd.XML11DTDValidator r3 = r3.fXML11DTDValidator
            r2.fLastComponent = r3
            goto L_0x00f5
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.XML11Configuration.configureXML11Pipeline():void");
    }

    public XMLDTDContentModelHandler getDTDContentModelHandler() {
        return this.fDTDContentModelHandler;
    }

    public XMLDTDHandler getDTDHandler() {
        return this.fDTDHandler;
    }

    public XMLDocumentHandler getDocumentHandler() {
        return this.fDocumentHandler;
    }

    public XMLEntityResolver getEntityResolver() {
        return (XMLEntityResolver) this.fProperties.get(ENTITY_RESOLVER);
    }

    public XMLErrorHandler getErrorHandler() {
        return (XMLErrorHandler) this.fProperties.get(ERROR_HANDLER);
    }

    public boolean getFeature(String str) throws XMLConfigurationException {
        String str2 = str;
        return str2.equals("http://apache.org/xml/features/internal/parser-settings") ? this.fConfigUpdated : super.getFeature(str2);
    }

    /* access modifiers changed from: package-private */
    public boolean getFeature0(String str) throws XMLConfigurationException {
        return super.getFeature(str);
    }

    public Locale getLocale() {
        return this.fLocale;
    }

    public Object getProperty(String str) throws XMLConfigurationException {
        String str2 = str;
        return LOCALE.equals(str2) ? getLocale() : super.getProperty(str2);
    }

    public void parse(XMLInputSource xMLInputSource) throws XNIException, IOException {
        Throwable th;
        Throwable th2;
        XMLInputSource xMLInputSource2 = xMLInputSource;
        if (this.fParseInProgress) {
            Throwable th3 = th2;
            new XNIException("FWK005 parse may not be called while parsing.");
            throw th3;
        }
        this.fParseInProgress = true;
        try {
            setInputSource(xMLInputSource2);
            boolean parse = parse(true);
            this.fParseInProgress = false;
            cleanup();
        } catch (XNIException e) {
            throw e;
        } catch (IOException e2) {
            throw e2;
        } catch (RuntimeException e3) {
            throw e3;
        } catch (Exception e4) {
            Exception exc = e4;
            Throwable th4 = th;
            new XNIException(exc);
            throw th4;
        } catch (Throwable th5) {
            Throwable th6 = th5;
            this.fParseInProgress = false;
            cleanup();
            throw th6;
        }
    }

    public boolean parse(boolean z) throws XNIException, IOException {
        Throwable th;
        Throwable th2;
        boolean z2 = z;
        if (this.fInputSource != null) {
            try {
                this.fValidationManager.reset();
                this.fVersionDetector.reset(this);
                resetCommon();
                short determineDocVersion = this.fVersionDetector.determineDocVersion(this.fInputSource);
                if (determineDocVersion == 1) {
                    configurePipeline();
                    reset();
                } else if (determineDocVersion != 2) {
                    return false;
                } else {
                    initXML11Components();
                    configureXML11Pipeline();
                    resetXML11();
                }
                this.fConfigUpdated = false;
                this.fVersionDetector.startDocumentParsing(this.fCurrentScanner, determineDocVersion);
                this.fInputSource = null;
            } catch (XNIException e) {
                throw e;
            } catch (IOException e2) {
                throw e2;
            } catch (RuntimeException e3) {
                throw e3;
            } catch (Exception e4) {
                Exception exc = e4;
                Throwable th3 = th2;
                new XNIException(exc);
                throw th3;
            }
        }
        try {
            return this.fCurrentScanner.scanDocument(z2);
        } catch (XNIException e5) {
            throw e5;
        } catch (IOException e6) {
            throw e6;
        } catch (RuntimeException e7) {
            throw e7;
        } catch (Exception e8) {
            Exception exc2 = e8;
            Throwable th4 = th;
            new XNIException(exc2);
            throw th4;
        }
    }

    /* access modifiers changed from: protected */
    public void reset() throws XNIException {
        int size = this.fComponents.size();
        for (int i = 0; i < size; i++) {
            ((XMLComponent) this.fComponents.get(i)).reset(this);
        }
    }

    /* access modifiers changed from: protected */
    public void resetCommon() throws XNIException {
        int size = this.fCommonComponents.size();
        for (int i = 0; i < size; i++) {
            ((XMLComponent) this.fCommonComponents.get(i)).reset(this);
        }
    }

    /* access modifiers changed from: protected */
    public void resetXML11() throws XNIException {
        int size = this.fXML11Components.size();
        for (int i = 0; i < size; i++) {
            ((XMLComponent) this.fXML11Components.get(i)).reset(this);
        }
    }

    public void setDTDContentModelHandler(XMLDTDContentModelHandler xMLDTDContentModelHandler) {
        XMLDTDContentModelHandler xMLDTDContentModelHandler2 = xMLDTDContentModelHandler;
        this.fDTDContentModelHandler = xMLDTDContentModelHandler2;
    }

    public void setDTDHandler(XMLDTDHandler xMLDTDHandler) {
        XMLDTDHandler xMLDTDHandler2 = xMLDTDHandler;
        this.fDTDHandler = xMLDTDHandler2;
    }

    public void setDocumentHandler(XMLDocumentHandler xMLDocumentHandler) {
        this.fDocumentHandler = xMLDocumentHandler;
        if (this.fLastComponent != null) {
            this.fLastComponent.setDocumentHandler(this.fDocumentHandler);
            if (this.fDocumentHandler != null) {
                this.fDocumentHandler.setDocumentSource(this.fLastComponent);
            }
        }
    }

    public void setEntityResolver(XMLEntityResolver xMLEntityResolver) {
        Object put = this.fProperties.put(ENTITY_RESOLVER, xMLEntityResolver);
    }

    public void setErrorHandler(XMLErrorHandler xMLErrorHandler) {
        Object put = this.fProperties.put(ERROR_HANDLER, xMLErrorHandler);
    }

    public void setFeature(String str, boolean z) throws XMLConfigurationException {
        String str2 = str;
        boolean z2 = z;
        this.fConfigUpdated = true;
        int size = this.fComponents.size();
        for (int i = 0; i < size; i++) {
            ((XMLComponent) this.fComponents.get(i)).setFeature(str2, z2);
        }
        int size2 = this.fCommonComponents.size();
        for (int i2 = 0; i2 < size2; i2++) {
            ((XMLComponent) this.fCommonComponents.get(i2)).setFeature(str2, z2);
        }
        int size3 = this.fXML11Components.size();
        for (int i3 = 0; i3 < size3; i3++) {
            try {
                ((XMLComponent) this.fXML11Components.get(i3)).setFeature(str2, z2);
            } catch (Exception e) {
                Exception exc = e;
            }
        }
        super.setFeature(str2, z2);
    }

    public void setInputSource(XMLInputSource xMLInputSource) throws XMLConfigurationException, IOException {
        XMLInputSource xMLInputSource2 = xMLInputSource;
        this.fInputSource = xMLInputSource2;
    }

    public void setLocale(Locale locale) throws XNIException {
        Locale locale2 = locale;
        this.fLocale = locale2;
        this.fErrorReporter.setLocale(locale2);
    }

    public void setProperty(String str, Object obj) throws XMLConfigurationException {
        String str2 = str;
        Object obj2 = obj;
        this.fConfigUpdated = true;
        if (LOCALE.equals(str2)) {
            setLocale((Locale) obj2);
        }
        int size = this.fComponents.size();
        for (int i = 0; i < size; i++) {
            ((XMLComponent) this.fComponents.get(i)).setProperty(str2, obj2);
        }
        int size2 = this.fCommonComponents.size();
        for (int i2 = 0; i2 < size2; i2++) {
            ((XMLComponent) this.fCommonComponents.get(i2)).setProperty(str2, obj2);
        }
        int size3 = this.fXML11Components.size();
        for (int i3 = 0; i3 < size3; i3++) {
            try {
                ((XMLComponent) this.fXML11Components.get(i3)).setProperty(str2, obj2);
            } catch (Exception e) {
                Exception exc = e;
            }
        }
        super.setProperty(str2, obj2);
    }
}
