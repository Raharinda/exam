package org.apache.xerces.parsers;

import java.io.IOException;
import java.util.Locale;
import org.apache.xerces.impl.XMLEntityManager;
import org.apache.xerces.impl.XMLErrorReporter;
import org.apache.xerces.impl.XMLNamespaceBinder;
import org.apache.xerces.impl.dtd.XMLDTDProcessor;
import org.apache.xerces.impl.dtd.XMLDTDValidator;
import org.apache.xerces.impl.dv.DTDDVFactory;
import org.apache.xerces.impl.validation.ValidationManager;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.xni.XMLLocator;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.grammars.XMLGrammarPool;
import org.apache.xerces.xni.parser.XMLComponentManager;
import org.apache.xerces.xni.parser.XMLConfigurationException;
import org.apache.xerces.xni.parser.XMLDTDScanner;
import org.apache.xerces.xni.parser.XMLDocumentScanner;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLPullParserConfiguration;

public class DTDConfiguration extends BasicParserConfiguration implements XMLPullParserConfiguration {
    protected static final String ALLOW_JAVA_ENCODINGS = "http://apache.org/xml/features/allow-java-encodings";
    protected static final String CONTINUE_AFTER_FATAL_ERROR = "http://apache.org/xml/features/continue-after-fatal-error";
    protected static final String DATATYPE_VALIDATOR_FACTORY = "http://apache.org/xml/properties/internal/datatype-validator-factory";
    protected static final String DOCUMENT_SCANNER = "http://apache.org/xml/properties/internal/document-scanner";
    protected static final String DTD_PROCESSOR = "http://apache.org/xml/properties/internal/dtd-processor";
    protected static final String DTD_SCANNER = "http://apache.org/xml/properties/internal/dtd-scanner";
    protected static final String DTD_VALIDATOR = "http://apache.org/xml/properties/internal/validator/dtd";
    protected static final String ENTITY_MANAGER = "http://apache.org/xml/properties/internal/entity-manager";
    protected static final String ERROR_REPORTER = "http://apache.org/xml/properties/internal/error-reporter";
    protected static final String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
    protected static final String JAXP_SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";
    protected static final String LOAD_EXTERNAL_DTD = "http://apache.org/xml/features/nonvalidating/load-external-dtd";
    protected static final String LOCALE = "http://apache.org/xml/properties/locale";
    protected static final String NAMESPACE_BINDER = "http://apache.org/xml/properties/internal/namespace-binder";
    protected static final String NOTIFY_BUILTIN_REFS = "http://apache.org/xml/features/scanner/notify-builtin-refs";
    protected static final String NOTIFY_CHAR_REFS = "http://apache.org/xml/features/scanner/notify-char-refs";
    protected static final boolean PRINT_EXCEPTION_STACK_TRACE = false;
    protected static final String VALIDATION_MANAGER = "http://apache.org/xml/properties/internal/validation-manager";
    protected static final String WARN_ON_DUPLICATE_ATTDEF = "http://apache.org/xml/features/validation/warn-on-duplicate-attdef";
    protected static final String WARN_ON_DUPLICATE_ENTITYDEF = "http://apache.org/xml/features/warn-on-duplicate-entitydef";
    protected static final String WARN_ON_UNDECLARED_ELEMDEF = "http://apache.org/xml/features/validation/warn-on-undeclared-elemdef";
    protected static final String XMLGRAMMAR_POOL = "http://apache.org/xml/properties/internal/grammar-pool";
    protected XMLDTDProcessor fDTDProcessor;
    protected XMLDTDScanner fDTDScanner;
    protected XMLDTDValidator fDTDValidator;
    protected DTDDVFactory fDatatypeValidatorFactory;
    protected XMLEntityManager fEntityManager;
    protected XMLErrorReporter fErrorReporter;
    protected XMLGrammarPool fGrammarPool;
    protected XMLInputSource fInputSource;
    protected XMLLocator fLocator;
    protected XMLNamespaceBinder fNamespaceBinder;
    protected boolean fParseInProgress;
    protected XMLDocumentScanner fScanner;
    protected ValidationManager fValidationManager;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DTDConfiguration() {
        this((SymbolTable) null, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DTDConfiguration(SymbolTable symbolTable) {
        this(symbolTable, (XMLGrammarPool) null, (XMLComponentManager) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DTDConfiguration(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool) {
        this(symbolTable, xMLGrammarPool, (XMLComponentManager) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public DTDConfiguration(org.apache.xerces.util.SymbolTable r13, org.apache.xerces.xni.grammars.XMLGrammarPool r14, org.apache.xerces.xni.parser.XMLComponentManager r15) {
        /*
            r12 = this;
            r0 = r12
            r1 = r13
            r2 = r14
            r3 = r15
            r7 = r0
            r8 = r1
            r9 = r3
            r7.<init>(r8, r9)
            r7 = r0
            r8 = 0
            r7.fParseInProgress = r8
            r7 = 2
            java.lang.String[] r7 = new java.lang.String[r7]
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 0
            java.lang.String r10 = "http://apache.org/xml/features/continue-after-fatal-error"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 1
            java.lang.String r10 = "http://apache.org/xml/features/nonvalidating/load-external-dtd"
            r8[r9] = r10
            r4 = r7
            r7 = r0
            r8 = r4
            r7.addRecognizedFeatures(r8)
            r7 = r0
            java.lang.String r8 = "http://apache.org/xml/features/continue-after-fatal-error"
            r9 = 0
            r7.setFeature(r8, r9)
            r7 = r0
            java.lang.String r8 = "http://apache.org/xml/features/nonvalidating/load-external-dtd"
            r9 = 1
            r7.setFeature(r8, r9)
            r7 = 13
            java.lang.String[] r7 = new java.lang.String[r7]
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 0
            java.lang.String r10 = "http://apache.org/xml/properties/internal/error-reporter"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 1
            java.lang.String r10 = "http://apache.org/xml/properties/internal/entity-manager"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 2
            java.lang.String r10 = "http://apache.org/xml/properties/internal/document-scanner"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 3
            java.lang.String r10 = "http://apache.org/xml/properties/internal/dtd-scanner"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 4
            java.lang.String r10 = "http://apache.org/xml/properties/internal/dtd-processor"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 5
            java.lang.String r10 = "http://apache.org/xml/properties/internal/validator/dtd"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 6
            java.lang.String r10 = "http://apache.org/xml/properties/internal/namespace-binder"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 7
            java.lang.String r10 = "http://apache.org/xml/properties/internal/grammar-pool"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 8
            java.lang.String r10 = "http://apache.org/xml/properties/internal/datatype-validator-factory"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 9
            java.lang.String r10 = "http://apache.org/xml/properties/internal/validation-manager"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 10
            java.lang.String r10 = "http://java.sun.com/xml/jaxp/properties/schemaSource"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 11
            java.lang.String r10 = "http://java.sun.com/xml/jaxp/properties/schemaLanguage"
            r8[r9] = r10
            r11 = r7
            r7 = r11
            r8 = r11
            r9 = 12
            java.lang.String r10 = "http://apache.org/xml/properties/locale"
            r8[r9] = r10
            r5 = r7
            r7 = r0
            r8 = r5
            r7.addRecognizedProperties(r8)
            r7 = r0
            r8 = r2
            r7.fGrammarPool = r8
            r7 = r0
            org.apache.xerces.xni.grammars.XMLGrammarPool r7 = r7.fGrammarPool
            if (r7 == 0) goto L_0x00d0
            r7 = r0
            java.lang.String r8 = "http://apache.org/xml/properties/internal/grammar-pool"
            r9 = r0
            org.apache.xerces.xni.grammars.XMLGrammarPool r9 = r9.fGrammarPool
            r7.setProperty(r8, r9)
        L_0x00d0:
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.XMLEntityManager r8 = r8.createEntityManager()
            r7.fEntityManager = r8
            r7 = r0
            java.lang.String r8 = "http://apache.org/xml/properties/internal/entity-manager"
            r9 = r0
            org.apache.xerces.impl.XMLEntityManager r9 = r9.fEntityManager
            r7.setProperty(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.XMLEntityManager r8 = r8.fEntityManager
            r7.addComponent(r8)
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.XMLErrorReporter r8 = r8.createErrorReporter()
            r7.fErrorReporter = r8
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r7 = r7.fErrorReporter
            r8 = r0
            org.apache.xerces.impl.XMLEntityManager r8 = r8.fEntityManager
            org.apache.xerces.impl.XMLEntityScanner r8 = r8.getEntityScanner()
            r7.setDocumentLocator(r8)
            r7 = r0
            java.lang.String r8 = "http://apache.org/xml/properties/internal/error-reporter"
            r9 = r0
            org.apache.xerces.impl.XMLErrorReporter r9 = r9.fErrorReporter
            r7.setProperty(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.XMLErrorReporter r8 = r8.fErrorReporter
            r7.addComponent(r8)
            r7 = r0
            r8 = r0
            org.apache.xerces.xni.parser.XMLDocumentScanner r8 = r8.createDocumentScanner()
            r7.fScanner = r8
            r7 = r0
            java.lang.String r8 = "http://apache.org/xml/properties/internal/document-scanner"
            r9 = r0
            org.apache.xerces.xni.parser.XMLDocumentScanner r9 = r9.fScanner
            r7.setProperty(r8, r9)
            r7 = r0
            org.apache.xerces.xni.parser.XMLDocumentScanner r7 = r7.fScanner
            boolean r7 = r7 instanceof org.apache.xerces.xni.parser.XMLComponent
            if (r7 == 0) goto L_0x0131
            r7 = r0
            r8 = r0
            org.apache.xerces.xni.parser.XMLDocumentScanner r8 = r8.fScanner
            org.apache.xerces.xni.parser.XMLComponent r8 = (org.apache.xerces.xni.parser.XMLComponent) r8
            r7.addComponent(r8)
        L_0x0131:
            r7 = r0
            r8 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r8 = r8.createDTDScanner()
            r7.fDTDScanner = r8
            r7 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r7 = r7.fDTDScanner
            if (r7 == 0) goto L_0x0158
            r7 = r0
            java.lang.String r8 = "http://apache.org/xml/properties/internal/dtd-scanner"
            r9 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r9 = r9.fDTDScanner
            r7.setProperty(r8, r9)
            r7 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r7 = r7.fDTDScanner
            boolean r7 = r7 instanceof org.apache.xerces.xni.parser.XMLComponent
            if (r7 == 0) goto L_0x0158
            r7 = r0
            r8 = r0
            org.apache.xerces.xni.parser.XMLDTDScanner r8 = r8.fDTDScanner
            org.apache.xerces.xni.parser.XMLComponent r8 = (org.apache.xerces.xni.parser.XMLComponent) r8
            r7.addComponent(r8)
        L_0x0158:
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r8 = r8.createDTDProcessor()
            r7.fDTDProcessor = r8
            r7 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r7 = r7.fDTDProcessor
            if (r7 == 0) goto L_0x0176
            r7 = r0
            java.lang.String r8 = "http://apache.org/xml/properties/internal/dtd-processor"
            r9 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r9 = r9.fDTDProcessor
            r7.setProperty(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.dtd.XMLDTDProcessor r8 = r8.fDTDProcessor
            r7.addComponent(r8)
        L_0x0176:
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r8 = r8.createDTDValidator()
            r7.fDTDValidator = r8
            r7 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r7 = r7.fDTDValidator
            if (r7 == 0) goto L_0x0194
            r7 = r0
            java.lang.String r8 = "http://apache.org/xml/properties/internal/validator/dtd"
            r9 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r9 = r9.fDTDValidator
            r7.setProperty(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.dtd.XMLDTDValidator r8 = r8.fDTDValidator
            r7.addComponent(r8)
        L_0x0194:
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.XMLNamespaceBinder r8 = r8.createNamespaceBinder()
            r7.fNamespaceBinder = r8
            r7 = r0
            org.apache.xerces.impl.XMLNamespaceBinder r7 = r7.fNamespaceBinder
            if (r7 == 0) goto L_0x01b2
            r7 = r0
            java.lang.String r8 = "http://apache.org/xml/properties/internal/namespace-binder"
            r9 = r0
            org.apache.xerces.impl.XMLNamespaceBinder r9 = r9.fNamespaceBinder
            r7.setProperty(r8, r9)
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.XMLNamespaceBinder r8 = r8.fNamespaceBinder
            r7.addComponent(r8)
        L_0x01b2:
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r8 = r8.createDatatypeValidatorFactory()
            r7.fDatatypeValidatorFactory = r8
            r7 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r7 = r7.fDatatypeValidatorFactory
            if (r7 == 0) goto L_0x01c9
            r7 = r0
            java.lang.String r8 = "http://apache.org/xml/properties/internal/datatype-validator-factory"
            r9 = r0
            org.apache.xerces.impl.dv.DTDDVFactory r9 = r9.fDatatypeValidatorFactory
            r7.setProperty(r8, r9)
        L_0x01c9:
            r7 = r0
            r8 = r0
            org.apache.xerces.impl.validation.ValidationManager r8 = r8.createValidationManager()
            r7.fValidationManager = r8
            r7 = r0
            org.apache.xerces.impl.validation.ValidationManager r7 = r7.fValidationManager
            if (r7 == 0) goto L_0x01e0
            r7 = r0
            java.lang.String r8 = "http://apache.org/xml/properties/internal/validation-manager"
            r9 = r0
            org.apache.xerces.impl.validation.ValidationManager r9 = r9.fValidationManager
            r7.setProperty(r8, r9)
        L_0x01e0:
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r7 = r7.fErrorReporter
            java.lang.String r8 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            org.apache.xerces.util.MessageFormatter r7 = r7.getMessageFormatter(r8)
            if (r7 != 0) goto L_0x0209
            org.apache.xerces.impl.msg.XMLMessageFormatter r7 = new org.apache.xerces.impl.msg.XMLMessageFormatter
            r11 = r7
            r7 = r11
            r8 = r11
            r8.<init>()
            r6 = r7
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r7 = r7.fErrorReporter
            java.lang.String r8 = "http://www.w3.org/TR/1998/REC-xml-19980210"
            r9 = r6
            r7.putMessageFormatter(r8, r9)
            r7 = r0
            org.apache.xerces.impl.XMLErrorReporter r7 = r7.fErrorReporter
            java.lang.String r8 = "http://www.w3.org/TR/1999/REC-xml-names-19990114"
            r9 = r6
            r7.putMessageFormatter(r8, r9)
        L_0x0209:
            r7 = r0
            java.util.Locale r8 = java.util.Locale.getDefault()     // Catch:{ XNIException -> 0x0212 }
            r7.setLocale(r8)     // Catch:{ XNIException -> 0x0212 }
        L_0x0211:
            return
        L_0x0212:
            r7 = move-exception
            r6 = r7
            goto L_0x0211
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.DTDConfiguration.<init>(org.apache.xerces.util.SymbolTable, org.apache.xerces.xni.grammars.XMLGrammarPool, org.apache.xerces.xni.parser.XMLComponentManager):void");
    }

    /* access modifiers changed from: protected */
    public void checkFeature(String str) throws XMLConfigurationException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        String str2 = str;
        if (str2.startsWith("http://apache.org/xml/features/")) {
            int length = str2.length() - "http://apache.org/xml/features/".length();
            if (length == "validation/dynamic".length() && str2.endsWith("validation/dynamic")) {
                return;
            }
            if (length == "validation/default-attribute-values".length() && str2.endsWith("validation/default-attribute-values")) {
                Throwable th4 = th3;
                new XMLConfigurationException(1, str2);
                throw th4;
            } else if (length == "validation/validate-content-models".length() && str2.endsWith("validation/validate-content-models")) {
                Throwable th5 = th2;
                new XMLConfigurationException(1, str2);
                throw th5;
            } else if (length == "nonvalidating/load-dtd-grammar".length() && str2.endsWith("nonvalidating/load-dtd-grammar")) {
                return;
            } else {
                if (length == "nonvalidating/load-external-dtd".length() && str2.endsWith("nonvalidating/load-external-dtd")) {
                    return;
                }
                if (length == "validation/validate-datatypes".length() && str2.endsWith("validation/validate-datatypes")) {
                    Throwable th6 = th;
                    new XMLConfigurationException(1, str2);
                    throw th6;
                }
            }
        }
        super.checkFeature(str2);
    }

    /* access modifiers changed from: protected */
    public void checkProperty(String str) throws XMLConfigurationException {
        String str2 = str;
        if (!str2.startsWith("http://apache.org/xml/properties/") || str2.length() - "http://apache.org/xml/properties/".length() != "internal/dtd-scanner".length() || !str2.endsWith("internal/dtd-scanner")) {
            super.checkProperty(str2);
        }
    }

    public void cleanup() {
        this.fEntityManager.closeReaders();
    }

    /* access modifiers changed from: protected */
    public void configureDTDPipeline() {
        if (this.fDTDScanner != null) {
            Object put = this.fProperties.put(DTD_SCANNER, this.fDTDScanner);
            if (this.fDTDProcessor != null) {
                Object put2 = this.fProperties.put(DTD_PROCESSOR, this.fDTDProcessor);
                this.fDTDScanner.setDTDHandler(this.fDTDProcessor);
                this.fDTDProcessor.setDTDSource(this.fDTDScanner);
                this.fDTDProcessor.setDTDHandler(this.fDTDHandler);
                if (this.fDTDHandler != null) {
                    this.fDTDHandler.setDTDSource(this.fDTDProcessor);
                }
                this.fDTDScanner.setDTDContentModelHandler(this.fDTDProcessor);
                this.fDTDProcessor.setDTDContentModelSource(this.fDTDScanner);
                this.fDTDProcessor.setDTDContentModelHandler(this.fDTDContentModelHandler);
                if (this.fDTDContentModelHandler != null) {
                    this.fDTDContentModelHandler.setDTDContentModelSource(this.fDTDProcessor);
                    return;
                }
                return;
            }
            this.fDTDScanner.setDTDHandler(this.fDTDHandler);
            if (this.fDTDHandler != null) {
                this.fDTDHandler.setDTDSource(this.fDTDScanner);
            }
            this.fDTDScanner.setDTDContentModelHandler(this.fDTDContentModelHandler);
            if (this.fDTDContentModelHandler != null) {
                this.fDTDContentModelHandler.setDTDContentModelSource(this.fDTDScanner);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void configurePipeline() {
        if (this.fDTDValidator != null) {
            this.fScanner.setDocumentHandler(this.fDTDValidator);
            if (this.fFeatures.get("http://xml.org/sax/features/namespaces") == Boolean.TRUE) {
                this.fDTDValidator.setDocumentHandler(this.fNamespaceBinder);
                this.fDTDValidator.setDocumentSource(this.fScanner);
                this.fNamespaceBinder.setDocumentHandler(this.fDocumentHandler);
                this.fNamespaceBinder.setDocumentSource(this.fDTDValidator);
                this.fLastComponent = this.fNamespaceBinder;
            } else {
                this.fDTDValidator.setDocumentHandler(this.fDocumentHandler);
                this.fDTDValidator.setDocumentSource(this.fScanner);
                this.fLastComponent = this.fDTDValidator;
            }
        } else if (this.fFeatures.get("http://xml.org/sax/features/namespaces") == Boolean.TRUE) {
            this.fScanner.setDocumentHandler(this.fNamespaceBinder);
            this.fNamespaceBinder.setDocumentHandler(this.fDocumentHandler);
            this.fNamespaceBinder.setDocumentSource(this.fScanner);
            this.fLastComponent = this.fNamespaceBinder;
        } else {
            this.fScanner.setDocumentHandler(this.fDocumentHandler);
            this.fLastComponent = this.fScanner;
        }
        configureDTDPipeline();
    }

    /* access modifiers changed from: protected */
    public XMLDTDProcessor createDTDProcessor() {
        XMLDTDProcessor xMLDTDProcessor;
        new XMLDTDProcessor();
        return xMLDTDProcessor;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public org.apache.xerces.xni.parser.XMLDTDScanner createDTDScanner() {
        /*
            r4 = this;
            r0 = r4
            org.apache.xerces.impl.XMLDTDScannerImpl r1 = new org.apache.xerces.impl.XMLDTDScannerImpl
            r3 = r1
            r1 = r3
            r2 = r3
            r2.<init>()
            r0 = r1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.DTDConfiguration.createDTDScanner():org.apache.xerces.xni.parser.XMLDTDScanner");
    }

    /* access modifiers changed from: protected */
    public XMLDTDValidator createDTDValidator() {
        XMLDTDValidator xMLDTDValidator;
        new XMLDTDValidator();
        return xMLDTDValidator;
    }

    /* access modifiers changed from: protected */
    public DTDDVFactory createDatatypeValidatorFactory() {
        return DTDDVFactory.getInstance();
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public org.apache.xerces.xni.parser.XMLDocumentScanner createDocumentScanner() {
        /*
            r4 = this;
            r0 = r4
            org.apache.xerces.impl.XMLDocumentScannerImpl r1 = new org.apache.xerces.impl.XMLDocumentScannerImpl
            r3 = r1
            r1 = r3
            r2 = r3
            r2.<init>()
            r0 = r1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.DTDConfiguration.createDocumentScanner():org.apache.xerces.xni.parser.XMLDocumentScanner");
    }

    /* access modifiers changed from: protected */
    public XMLEntityManager createEntityManager() {
        XMLEntityManager xMLEntityManager;
        new XMLEntityManager();
        return xMLEntityManager;
    }

    /* access modifiers changed from: protected */
    public XMLErrorReporter createErrorReporter() {
        XMLErrorReporter xMLErrorReporter;
        new XMLErrorReporter();
        return xMLErrorReporter;
    }

    /* access modifiers changed from: protected */
    public XMLNamespaceBinder createNamespaceBinder() {
        XMLNamespaceBinder xMLNamespaceBinder;
        new XMLNamespaceBinder();
        return xMLNamespaceBinder;
    }

    /* access modifiers changed from: protected */
    public ValidationManager createValidationManager() {
        ValidationManager validationManager;
        new ValidationManager();
        return validationManager;
    }

    public Object getProperty(String str) throws XMLConfigurationException {
        String str2 = str;
        return LOCALE.equals(str2) ? getLocale() : super.getProperty(str2);
    }

    public void parse(XMLInputSource xMLInputSource) throws XNIException, IOException {
        Throwable th;
        Throwable th2;
        XMLInputSource xMLInputSource2 = xMLInputSource;
        if (this.fParseInProgress) {
            Throwable th3 = th2;
            new XNIException("FWK005 parse may not be called while parsing.");
            throw th3;
        }
        this.fParseInProgress = true;
        try {
            setInputSource(xMLInputSource2);
            boolean parse = parse(true);
            this.fParseInProgress = false;
            cleanup();
        } catch (XNIException e) {
            throw e;
        } catch (IOException e2) {
            throw e2;
        } catch (RuntimeException e3) {
            throw e3;
        } catch (Exception e4) {
            Exception exc = e4;
            Throwable th4 = th;
            new XNIException(exc);
            throw th4;
        } catch (Throwable th5) {
            Throwable th6 = th5;
            this.fParseInProgress = false;
            cleanup();
            throw th6;
        }
    }

    public boolean parse(boolean z) throws XNIException, IOException {
        Throwable th;
        Throwable th2;
        boolean z2 = z;
        if (this.fInputSource != null) {
            try {
                reset();
                this.fScanner.setInputSource(this.fInputSource);
                this.fInputSource = null;
            } catch (XNIException e) {
                throw e;
            } catch (IOException e2) {
                throw e2;
            } catch (RuntimeException e3) {
                throw e3;
            } catch (Exception e4) {
                Exception exc = e4;
                Throwable th3 = th2;
                new XNIException(exc);
                throw th3;
            }
        }
        try {
            return this.fScanner.scanDocument(z2);
        } catch (XNIException e5) {
            throw e5;
        } catch (IOException e6) {
            throw e6;
        } catch (RuntimeException e7) {
            throw e7;
        } catch (Exception e8) {
            Exception exc2 = e8;
            Throwable th4 = th;
            new XNIException(exc2);
            throw th4;
        }
    }

    /* access modifiers changed from: protected */
    public void reset() throws XNIException {
        if (this.fValidationManager != null) {
            this.fValidationManager.reset();
        }
        configurePipeline();
        super.reset();
    }

    public void setInputSource(XMLInputSource xMLInputSource) throws XMLConfigurationException, IOException {
        XMLInputSource xMLInputSource2 = xMLInputSource;
        this.fInputSource = xMLInputSource2;
    }

    public void setLocale(Locale locale) throws XNIException {
        Locale locale2 = locale;
        super.setLocale(locale2);
        this.fErrorReporter.setLocale(locale2);
    }

    public void setProperty(String str, Object obj) throws XMLConfigurationException {
        String str2 = str;
        Object obj2 = obj;
        if (LOCALE.equals(str2)) {
            setLocale((Locale) obj2);
        }
        super.setProperty(str2, obj2);
    }
}
