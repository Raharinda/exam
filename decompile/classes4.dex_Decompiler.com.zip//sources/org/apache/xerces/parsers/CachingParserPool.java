package org.apache.xerces.parsers;

import org.apache.xerces.util.ShadowedSymbolTable;
import org.apache.xerces.util.SymbolTable;
import org.apache.xerces.util.SynchronizedSymbolTable;
import org.apache.xerces.util.XMLGrammarPoolImpl;
import org.apache.xerces.xni.grammars.Grammar;
import org.apache.xerces.xni.grammars.XMLGrammarDescription;
import org.apache.xerces.xni.grammars.XMLGrammarPool;

public class CachingParserPool {
    public static final boolean DEFAULT_SHADOW_GRAMMAR_POOL = false;
    public static final boolean DEFAULT_SHADOW_SYMBOL_TABLE = false;
    protected boolean fShadowGrammarPool;
    protected boolean fShadowSymbolTable;
    protected XMLGrammarPool fSynchronizedGrammarPool;
    protected SymbolTable fSynchronizedSymbolTable;

    public static final class ShadowedGrammarPool extends XMLGrammarPoolImpl {
        private XMLGrammarPool fGrammarPool;

        public ShadowedGrammarPool(XMLGrammarPool xMLGrammarPool) {
            this.fGrammarPool = xMLGrammarPool;
        }

        public void cacheGrammars(String str, Grammar[] grammarArr) {
            String str2 = str;
            Grammar[] grammarArr2 = grammarArr;
            super.cacheGrammars(str2, grammarArr2);
            this.fGrammarPool.cacheGrammars(str2, grammarArr2);
        }

        public boolean containsGrammar(XMLGrammarDescription xMLGrammarDescription) {
            return super.containsGrammar(xMLGrammarDescription);
        }

        public Grammar getGrammar(XMLGrammarDescription xMLGrammarDescription) {
            XMLGrammarDescription xMLGrammarDescription2 = xMLGrammarDescription;
            if (super.containsGrammar(xMLGrammarDescription2)) {
                return super.getGrammar(xMLGrammarDescription2);
            }
            return null;
        }

        public Grammar retrieveGrammar(XMLGrammarDescription xMLGrammarDescription) {
            XMLGrammarDescription xMLGrammarDescription2 = xMLGrammarDescription;
            Grammar retrieveGrammar = super.retrieveGrammar(xMLGrammarDescription2);
            return retrieveGrammar != null ? retrieveGrammar : this.fGrammarPool.retrieveGrammar(xMLGrammarDescription2);
        }

        public Grammar[] retrieveInitialGrammarSet(String str) {
            String str2 = str;
            Grammar[] retrieveInitialGrammarSet = super.retrieveInitialGrammarSet(str2);
            return retrieveInitialGrammarSet != null ? retrieveInitialGrammarSet : this.fGrammarPool.retrieveInitialGrammarSet(str2);
        }
    }

    public static final class SynchronizedGrammarPool implements XMLGrammarPool {
        private XMLGrammarPool fGrammarPool;

        public SynchronizedGrammarPool(XMLGrammarPool xMLGrammarPool) {
            this.fGrammarPool = xMLGrammarPool;
        }

        /* JADX INFO: finally extract failed */
        public void cacheGrammars(String str, Grammar[] grammarArr) {
            String str2 = str;
            Grammar[] grammarArr2 = grammarArr;
            XMLGrammarPool xMLGrammarPool = this.fGrammarPool;
            synchronized (xMLGrammarPool) {
                try {
                    this.fGrammarPool.cacheGrammars(str2, grammarArr2);
                } catch (Throwable th) {
                    Throwable th2 = th;
                    XMLGrammarPool xMLGrammarPool2 = xMLGrammarPool;
                    throw th2;
                }
            }
        }

        public void clear() {
            XMLGrammarPool xMLGrammarPool = this.fGrammarPool;
            synchronized (xMLGrammarPool) {
                try {
                    this.fGrammarPool.clear();
                } catch (Throwable th) {
                    Throwable th2 = th;
                    XMLGrammarPool xMLGrammarPool2 = xMLGrammarPool;
                    throw th2;
                }
            }
        }

        public void lockPool() {
            XMLGrammarPool xMLGrammarPool = this.fGrammarPool;
            synchronized (xMLGrammarPool) {
                try {
                    this.fGrammarPool.lockPool();
                } catch (Throwable th) {
                    Throwable th2 = th;
                    XMLGrammarPool xMLGrammarPool2 = xMLGrammarPool;
                    throw th2;
                }
            }
        }

        public Grammar retrieveGrammar(XMLGrammarDescription xMLGrammarDescription) {
            Grammar retrieveGrammar;
            XMLGrammarDescription xMLGrammarDescription2 = xMLGrammarDescription;
            XMLGrammarPool xMLGrammarPool = this.fGrammarPool;
            synchronized (xMLGrammarPool) {
                try {
                    retrieveGrammar = this.fGrammarPool.retrieveGrammar(xMLGrammarDescription2);
                } catch (Throwable th) {
                    Throwable th2 = th;
                    XMLGrammarPool xMLGrammarPool2 = xMLGrammarPool;
                    throw th2;
                }
            }
            return retrieveGrammar;
        }

        public Grammar[] retrieveInitialGrammarSet(String str) {
            Grammar[] retrieveInitialGrammarSet;
            String str2 = str;
            XMLGrammarPool xMLGrammarPool = this.fGrammarPool;
            synchronized (xMLGrammarPool) {
                try {
                    retrieveInitialGrammarSet = this.fGrammarPool.retrieveInitialGrammarSet(str2);
                } catch (Throwable th) {
                    Throwable th2 = th;
                    XMLGrammarPool xMLGrammarPool2 = xMLGrammarPool;
                    throw th2;
                }
            }
            return retrieveInitialGrammarSet;
        }

        public void unlockPool() {
            XMLGrammarPool xMLGrammarPool = this.fGrammarPool;
            synchronized (xMLGrammarPool) {
                try {
                    this.fGrammarPool.unlockPool();
                } catch (Throwable th) {
                    Throwable th2 = th;
                    XMLGrammarPool xMLGrammarPool2 = xMLGrammarPool;
                    throw th2;
                }
            }
        }
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public CachingParserPool() {
        /*
            r6 = this;
            r0 = r6
            r1 = r0
            org.apache.xerces.util.SymbolTable r2 = new org.apache.xerces.util.SymbolTable
            r5 = r2
            r2 = r5
            r3 = r5
            r3.<init>()
            org.apache.xerces.util.XMLGrammarPoolImpl r3 = new org.apache.xerces.util.XMLGrammarPoolImpl
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r1.<init>(r2, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.xerces.parsers.CachingParserPool.<init>():void");
    }

    public CachingParserPool(SymbolTable symbolTable, XMLGrammarPool xMLGrammarPool) {
        SymbolTable symbolTable2;
        XMLGrammarPool xMLGrammarPool2;
        this.fShadowSymbolTable = false;
        this.fShadowGrammarPool = false;
        new SynchronizedSymbolTable(symbolTable);
        this.fSynchronizedSymbolTable = symbolTable2;
        new SynchronizedGrammarPool(xMLGrammarPool);
        this.fSynchronizedGrammarPool = xMLGrammarPool2;
    }

    public DOMParser createDOMParser() {
        SymbolTable symbolTable;
        XMLGrammarPool xMLGrammarPool;
        DOMParser dOMParser;
        XMLGrammarPool xMLGrammarPool2;
        SymbolTable symbolTable2;
        if (this.fShadowSymbolTable) {
            symbolTable = symbolTable2;
            new ShadowedSymbolTable(this.fSynchronizedSymbolTable);
        } else {
            symbolTable = this.fSynchronizedSymbolTable;
        }
        SymbolTable symbolTable3 = symbolTable;
        if (this.fShadowGrammarPool) {
            xMLGrammarPool = xMLGrammarPool2;
            new ShadowedGrammarPool(this.fSynchronizedGrammarPool);
        } else {
            xMLGrammarPool = this.fSynchronizedGrammarPool;
        }
        new DOMParser(symbolTable3, xMLGrammarPool);
        return dOMParser;
    }

    public SAXParser createSAXParser() {
        SymbolTable symbolTable;
        XMLGrammarPool xMLGrammarPool;
        SAXParser sAXParser;
        XMLGrammarPool xMLGrammarPool2;
        SymbolTable symbolTable2;
        if (this.fShadowSymbolTable) {
            symbolTable = symbolTable2;
            new ShadowedSymbolTable(this.fSynchronizedSymbolTable);
        } else {
            symbolTable = this.fSynchronizedSymbolTable;
        }
        SymbolTable symbolTable3 = symbolTable;
        if (this.fShadowGrammarPool) {
            xMLGrammarPool = xMLGrammarPool2;
            new ShadowedGrammarPool(this.fSynchronizedGrammarPool);
        } else {
            xMLGrammarPool = this.fSynchronizedGrammarPool;
        }
        new SAXParser(symbolTable3, xMLGrammarPool);
        return sAXParser;
    }

    public SymbolTable getSymbolTable() {
        return this.fSynchronizedSymbolTable;
    }

    public XMLGrammarPool getXMLGrammarPool() {
        return this.fSynchronizedGrammarPool;
    }

    public void setShadowSymbolTable(boolean z) {
        boolean z2 = z;
        this.fShadowSymbolTable = z2;
    }
}
