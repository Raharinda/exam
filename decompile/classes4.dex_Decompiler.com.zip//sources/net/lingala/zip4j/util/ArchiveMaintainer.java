package net.lingala.zip4j.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import net.lingala.zip4j.core.HeaderReader;
import net.lingala.zip4j.core.HeaderWriter;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.io.SplitOutputStream;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.progress.ProgressMonitor;

public class ArchiveMaintainer {
    public ArchiveMaintainer() {
    }

    public HashMap removeZipFile(ZipModel zipModel, FileHeader fileHeader, ProgressMonitor progressMonitor, boolean runInThread) throws ZipException {
        Thread thread;
        ZipModel zipModel2 = zipModel;
        FileHeader fileHeader2 = fileHeader;
        ProgressMonitor progressMonitor2 = progressMonitor;
        if (runInThread) {
            new Thread(this, InternalZipConstants.THREAD_NAME, zipModel2, fileHeader2, progressMonitor2) {
                final ArchiveMaintainer this$0;
                private final FileHeader val$fileHeader;
                private final ProgressMonitor val$progressMonitor;
                private final ZipModel val$zipModel;

                {
                    this.this$0 = r9;
                    this.val$zipModel = r11;
                    this.val$fileHeader = r12;
                    this.val$progressMonitor = r13;
                }

                public void run() {
                    try {
                        HashMap initRemoveZipFile = this.this$0.initRemoveZipFile(this.val$zipModel, this.val$fileHeader, this.val$progressMonitor);
                        this.val$progressMonitor.endProgressMonitorSuccess();
                    } catch (ZipException e) {
                        ZipException zipException = e;
                    }
                }
            };
            thread.start();
            return null;
        }
        HashMap retMap = initRemoveZipFile(zipModel2, fileHeader2, progressMonitor2);
        progressMonitor2.endProgressMonitorSuccess();
        return retMap;
    }

    public HashMap initRemoveZipFile(ZipModel zipModel, FileHeader fileHeader, ProgressMonitor progressMonitor) throws ZipException {
        Throwable th;
        HashMap hashMap;
        Throwable th2;
        File newZipFile;
        Throwable th3;
        StringBuffer stringBuffer;
        File file;
        StringBuffer stringBuffer2;
        File file2;
        Throwable th4;
        OutputStream outputStream;
        File file3;
        File file4;
        HeaderReader headerReader;
        Throwable th5;
        HeaderWriter headerWriter;
        File newZipFile2;
        Throwable th6;
        File newZipFile3;
        Throwable th7;
        Throwable th8;
        Throwable th9;
        Throwable th10;
        ZipModel zipModel2 = zipModel;
        FileHeader fileHeader2 = fileHeader;
        ProgressMonitor progressMonitor2 = progressMonitor;
        if (fileHeader2 == null || zipModel2 == null) {
            Throwable th11 = th;
            new ZipException("input parameters is null in maintain zip file, cannot remove file from archive");
            throw th11;
        }
        OutputStream outputStream2 = null;
        File zipFile = null;
        RandomAccessFile inputStream = null;
        String tmpZipFileName = null;
        new HashMap();
        HashMap retMap = hashMap;
        try {
            int indexOfFileHeader = Zip4jUtil.getIndexOfFileHeader(zipModel2, fileHeader2);
            if (indexOfFileHeader < 0) {
                Throwable th12 = th10;
                new ZipException("file header not found in zip model, cannot remove file");
                throw th12;
            } else if (zipModel2.isSplitArchive()) {
                Throwable th13 = th9;
                new ZipException("This is a split archive. Zip file format does not allow updating split/spanned files");
                throw th13;
            } else {
                long currTime = System.currentTimeMillis();
                new StringBuffer(String.valueOf(zipModel2.getZipFile()));
                tmpZipFileName = stringBuffer.append(currTime % 1000).toString();
                new File(tmpZipFileName);
                for (File tmpFile = file; tmpFile.exists(); tmpFile = file2) {
                    long currTime2 = System.currentTimeMillis();
                    new StringBuffer(String.valueOf(zipModel2.getZipFile()));
                    tmpZipFileName = stringBuffer2.append(currTime2 % 1000).toString();
                    new File(tmpZipFileName);
                }
                OutputStream outputStream3 = outputStream;
                new File(tmpZipFileName);
                new SplitOutputStream(file3);
                outputStream2 = outputStream3;
                new File(zipModel2.getZipFile());
                zipFile = file4;
                inputStream = createFileHandler(zipModel2, InternalZipConstants.READ_MODE);
                new HeaderReader(inputStream);
                if (headerReader.readLocalFileHeader(fileHeader2) == null) {
                    Throwable th14 = th8;
                    new ZipException("invalid local file header, cannot remove file from archive");
                    throw th14;
                }
                long offsetLocalFileHeader = fileHeader2.getOffsetLocalHeader();
                if (!(fileHeader2.getZip64ExtendedInfo() == null || fileHeader2.getZip64ExtendedInfo().getOffsetLocalHeader() == -1)) {
                    offsetLocalFileHeader = fileHeader2.getZip64ExtendedInfo().getOffsetLocalHeader();
                }
                long offsetEndOfCompressedFile = -1;
                long offsetStartCentralDir = zipModel2.getEndCentralDirRecord().getOffsetOfStartOfCentralDir();
                if (zipModel2.isZip64Format() && zipModel2.getZip64EndCentralDirRecord() != null) {
                    offsetStartCentralDir = zipModel2.getZip64EndCentralDirRecord().getOffsetStartCenDirWRTStartDiskNo();
                }
                ArrayList fileHeaderList = zipModel2.getCentralDirectory().getFileHeaders();
                if (indexOfFileHeader == fileHeaderList.size() - 1) {
                    offsetEndOfCompressedFile = offsetStartCentralDir - 1;
                } else {
                    FileHeader nextFileHeader = (FileHeader) fileHeaderList.get(indexOfFileHeader + 1);
                    if (nextFileHeader != null) {
                        offsetEndOfCompressedFile = nextFileHeader.getOffsetLocalHeader() - 1;
                        if (!(nextFileHeader.getZip64ExtendedInfo() == null || nextFileHeader.getZip64ExtendedInfo().getOffsetLocalHeader() == -1)) {
                            offsetEndOfCompressedFile = nextFileHeader.getZip64ExtendedInfo().getOffsetLocalHeader() - 1;
                        }
                    }
                }
                if (offsetLocalFileHeader < 0 || offsetEndOfCompressedFile < 0) {
                    Throwable th15 = th5;
                    new ZipException("invalid offset for start and end of local file, cannot remove file");
                    throw th15;
                }
                if (indexOfFileHeader != 0) {
                    if (indexOfFileHeader == fileHeaderList.size() - 1) {
                        copyFile(inputStream, outputStream2, 0, offsetLocalFileHeader, progressMonitor2);
                    } else {
                        copyFile(inputStream, outputStream2, 0, offsetLocalFileHeader, progressMonitor2);
                        copyFile(inputStream, outputStream2, offsetEndOfCompressedFile + 1, offsetStartCentralDir, progressMonitor2);
                    }
                } else if (zipModel2.getCentralDirectory().getFileHeaders().size() > 1) {
                    copyFile(inputStream, outputStream2, offsetEndOfCompressedFile + 1, offsetStartCentralDir, progressMonitor2);
                }
                if (progressMonitor2.isCancelAllTasks()) {
                    progressMonitor2.setResult(3);
                    progressMonitor2.setState(0);
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e) {
                            IOException iOException = e;
                            Throwable th16 = th7;
                            new ZipException("cannot close input stream or output stream when trying to delete a file from zip file");
                            throw th16;
                        }
                    }
                    if (outputStream2 != null) {
                        outputStream2.close();
                    }
                    if (0 != 0) {
                        restoreFileName(zipFile, tmpZipFileName);
                    } else {
                        new File(tmpZipFileName);
                        boolean delete = newZipFile3.delete();
                    }
                    return null;
                }
                zipModel2.getEndCentralDirRecord().setOffsetOfStartOfCentralDir(((SplitOutputStream) outputStream2).getFilePointer());
                zipModel2.getEndCentralDirRecord().setTotNoOfEntriesInCentralDir(zipModel2.getEndCentralDirRecord().getTotNoOfEntriesInCentralDir() - 1);
                zipModel2.getEndCentralDirRecord().setTotNoOfEntriesInCentralDirOnThisDisk(zipModel2.getEndCentralDirRecord().getTotNoOfEntriesInCentralDirOnThisDisk() - 1);
                Object remove = zipModel2.getCentralDirectory().getFileHeaders().remove(indexOfFileHeader);
                for (int i = indexOfFileHeader; i < zipModel2.getCentralDirectory().getFileHeaders().size(); i++) {
                    long offsetLocalHdr = ((FileHeader) zipModel2.getCentralDirectory().getFileHeaders().get(i)).getOffsetLocalHeader();
                    if (!(((FileHeader) zipModel2.getCentralDirectory().getFileHeaders().get(i)).getZip64ExtendedInfo() == null || ((FileHeader) zipModel2.getCentralDirectory().getFileHeaders().get(i)).getZip64ExtendedInfo().getOffsetLocalHeader() == -1)) {
                        offsetLocalHdr = ((FileHeader) zipModel2.getCentralDirectory().getFileHeaders().get(i)).getZip64ExtendedInfo().getOffsetLocalHeader();
                    }
                    ((FileHeader) zipModel2.getCentralDirectory().getFileHeaders().get(i)).setOffsetLocalHeader((offsetLocalHdr - (offsetEndOfCompressedFile - offsetLocalFileHeader)) - 1);
                }
                new HeaderWriter();
                headerWriter.finalizeZipFile(zipModel2, outputStream2);
                Object put = retMap.put(InternalZipConstants.OFFSET_CENTRAL_DIR, Long.toString(zipModel2.getEndCentralDirRecord().getOffsetOfStartOfCentralDir()));
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e2) {
                        IOException iOException2 = e2;
                        Throwable th17 = th6;
                        new ZipException("cannot close input stream or output stream when trying to delete a file from zip file");
                        throw th17;
                    }
                }
                if (outputStream2 != null) {
                    outputStream2.close();
                }
                if (1 != 0) {
                    restoreFileName(zipFile, tmpZipFileName);
                } else {
                    new File(tmpZipFileName);
                    boolean delete2 = newZipFile2.delete();
                }
                return retMap;
            }
        } catch (FileNotFoundException e3) {
            FileNotFoundException e1 = e3;
            Throwable th18 = th4;
            new ZipException((Throwable) e1);
            throw th18;
        } catch (ZipException e4) {
            ZipException e5 = e4;
            progressMonitor2.endProgressMonitorError(e5);
            throw e5;
        } catch (Exception e6) {
            Exception e7 = e6;
            progressMonitor2.endProgressMonitorError(e7);
            Throwable th19 = th2;
            new ZipException((Throwable) e7);
            throw th19;
        } catch (Throwable th20) {
            Throwable th21 = th20;
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e8) {
                    IOException iOException3 = e8;
                    Throwable th22 = th3;
                    new ZipException("cannot close input stream or output stream when trying to delete a file from zip file");
                    throw th22;
                }
            }
            if (outputStream2 != null) {
                outputStream2.close();
            }
            if (0 != 0) {
                restoreFileName(zipFile, tmpZipFileName);
            } else {
                new File(tmpZipFileName);
                boolean delete3 = newZipFile.delete();
            }
            throw th21;
        }
    }

    private void restoreFileName(File file, String str) throws ZipException {
        Throwable th;
        File newZipFile;
        Throwable th2;
        File zipFile = file;
        String tmpZipFileName = str;
        if (zipFile.delete()) {
            new File(tmpZipFileName);
            if (!newZipFile.renameTo(zipFile)) {
                Throwable th3 = th2;
                new ZipException("cannot rename modified zip file");
                throw th3;
            }
            return;
        }
        Throwable th4 = th;
        new ZipException("cannot delete old zip file");
        throw th4;
    }

    private void copyFile(RandomAccessFile randomAccessFile, OutputStream outputStream, long j, long j2, ProgressMonitor progressMonitor) throws ZipException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        byte[] buff;
        Throwable th4;
        Throwable th5;
        Throwable th6;
        RandomAccessFile inputStream = randomAccessFile;
        OutputStream outputStream2 = outputStream;
        long start = j;
        long end = j2;
        ProgressMonitor progressMonitor2 = progressMonitor;
        if (inputStream == null || outputStream2 == null) {
            Throwable th7 = th;
            new ZipException("input or output stream is null, cannot copy file");
            throw th7;
        } else if (start < 0) {
            Throwable th8 = th6;
            new ZipException("starting offset is negative, cannot copy file");
            throw th8;
        } else if (end < 0) {
            Throwable th9 = th5;
            new ZipException("end offset is negative, cannot copy file");
            throw th9;
        } else if (start > end) {
            Throwable th10 = th4;
            new ZipException("start offset is greater than end offset, cannot copy file");
            throw th10;
        } else if (start != end) {
            if (progressMonitor2.isCancelAllTasks()) {
                progressMonitor2.setResult(3);
                progressMonitor2.setState(0);
                return;
            }
            try {
                inputStream.seek(start);
                long bytesRead = 0;
                long bytesToRead = end - start;
                if (end - start < 4096) {
                    buff = new byte[((int) (end - start))];
                } else {
                    buff = new byte[InternalZipConstants.BUFF_SIZE];
                }
                while (true) {
                    int read = inputStream.read(buff);
                    int readLen = read;
                    if (read == -1) {
                        break;
                    }
                    outputStream2.write(buff, 0, readLen);
                    progressMonitor2.updateWorkCompleted((long) readLen);
                    if (progressMonitor2.isCancelAllTasks()) {
                        progressMonitor2.setResult(3);
                        return;
                    }
                    bytesRead += (long) readLen;
                    if (bytesRead == bytesToRead) {
                        break;
                    } else if (bytesRead + ((long) buff.length) > bytesToRead) {
                        buff = new byte[((int) (bytesToRead - bytesRead))];
                    }
                }
            } catch (IOException e) {
                IOException e2 = e;
                Throwable th11 = th3;
                new ZipException((Throwable) e2);
                throw th11;
            } catch (Exception e3) {
                Exception e4 = e3;
                Throwable th12 = th2;
                new ZipException((Throwable) e4);
                throw th12;
            }
        }
    }

    private RandomAccessFile createFileHandler(ZipModel zipModel, String str) throws ZipException {
        Throwable th;
        Throwable th2;
        RandomAccessFile randomAccessFile;
        File file;
        ZipModel zipModel2 = zipModel;
        String mode = str;
        if (zipModel2 == null || !Zip4jUtil.isStringNotNullAndNotEmpty(zipModel2.getZipFile())) {
            Throwable th3 = th;
            new ZipException("input parameter is null in getFilePointer, cannot create file handler to remove file");
            throw th3;
        }
        try {
            RandomAccessFile randomAccessFile2 = randomAccessFile;
            new File(zipModel2.getZipFile());
            new RandomAccessFile(file, mode);
            return randomAccessFile2;
        } catch (FileNotFoundException e) {
            FileNotFoundException e2 = e;
            Throwable th4 = th2;
            new ZipException((Throwable) e2);
            throw th4;
        }
    }

    public void mergeSplitZipFiles(ZipModel zipModel, File file, ProgressMonitor progressMonitor, boolean runInThread) throws ZipException {
        Thread thread;
        ZipModel zipModel2 = zipModel;
        File outputZipFile = file;
        ProgressMonitor progressMonitor2 = progressMonitor;
        if (runInThread) {
            new Thread(this, InternalZipConstants.THREAD_NAME, zipModel2, outputZipFile, progressMonitor2) {
                final ArchiveMaintainer this$0;
                private final File val$outputZipFile;
                private final ProgressMonitor val$progressMonitor;
                private final ZipModel val$zipModel;

                {
                    this.this$0 = r9;
                    this.val$zipModel = r11;
                    this.val$outputZipFile = r12;
                    this.val$progressMonitor = r13;
                }

                public void run() {
                    try {
                        ArchiveMaintainer.access$0(this.this$0, this.val$zipModel, this.val$outputZipFile, this.val$progressMonitor);
                    } catch (ZipException e) {
                        ZipException zipException = e;
                    }
                }
            };
            thread.start();
            return;
        }
        initMergeSplitZipFile(zipModel2, outputZipFile, progressMonitor2);
    }

    static void access$0(ArchiveMaintainer archiveMaintainer, ZipModel zipModel, File file, ProgressMonitor progressMonitor) throws ZipException {
        archiveMaintainer.initMergeSplitZipFile(zipModel, file, progressMonitor);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:90:0x022f, code lost:
        r20 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:91:0x0230, code lost:
        r13 = r20;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:93:?, code lost:
        r6.endProgressMonitorError(r13);
        r20 = r28;
        new net.lingala.zip4j.exception.ZipException((java.lang.Throwable) r13);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:94:0x0246, code lost:
        throw r20;
     */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x022f A[ExcHandler: Exception (r20v10 'e' java.lang.Exception A[CUSTOM_DECLARE]), PHI: r7 r8 
      PHI: (r7v1 'outputStream' java.io.OutputStream) = (r7v0 'outputStream' java.io.OutputStream), (r7v0 'outputStream' java.io.OutputStream), (r7v4 'outputStream' java.io.OutputStream), (r7v4 'outputStream' java.io.OutputStream), (r7v4 'outputStream' java.io.OutputStream), (r7v4 'outputStream' java.io.OutputStream), (r7v4 'outputStream' java.io.OutputStream) binds: [B:9:0x0067, B:33:0x00b8, B:49:0x0120, B:82:0x021e, B:83:?, B:85:0x0224, B:86:?] A[DONT_GENERATE, DONT_INLINE]
      PHI: (r8v1 'inputStream' java.io.RandomAccessFile) = (r8v0 'inputStream' java.io.RandomAccessFile), (r8v0 'inputStream' java.io.RandomAccessFile), (r8v4 'inputStream' java.io.RandomAccessFile), (r8v5 'inputStream' java.io.RandomAccessFile), (r8v5 'inputStream' java.io.RandomAccessFile), (r8v5 'inputStream' java.io.RandomAccessFile), (r8v5 'inputStream' java.io.RandomAccessFile) binds: [B:9:0x0067, B:33:0x00b8, B:49:0x0120, B:82:0x021e, B:83:?, B:85:0x0224, B:86:?] A[DONT_GENERATE, DONT_INLINE], Splitter:B:9:0x0067] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void initMergeSplitZipFile(net.lingala.zip4j.model.ZipModel r30, java.io.File r31, net.lingala.zip4j.progress.ProgressMonitor r32) throws net.lingala.zip4j.exception.ZipException {
        /*
            r29 = this;
            r3 = r29
            r4 = r30
            r5 = r31
            r6 = r32
            r20 = r4
            if (r20 != 0) goto L_0x0026
            net.lingala.zip4j.exception.ZipException r20 = new net.lingala.zip4j.exception.ZipException
            r28 = r20
            r20 = r28
            r21 = r28
            java.lang.String r22 = "one of the input parameters is null, cannot merge split zip file"
            r21.<init>((java.lang.String) r22)
            r7 = r20
            r20 = r6
            r21 = r7
            r20.endProgressMonitorError(r21)
            r20 = r7
            throw r20
        L_0x0026:
            r20 = r4
            boolean r20 = r20.isSplitArchive()
            if (r20 != 0) goto L_0x0048
            net.lingala.zip4j.exception.ZipException r20 = new net.lingala.zip4j.exception.ZipException
            r28 = r20
            r20 = r28
            r21 = r28
            java.lang.String r22 = "archive not a split zip file"
            r21.<init>((java.lang.String) r22)
            r7 = r20
            r20 = r6
            r21 = r7
            r20.endProgressMonitorError(r21)
            r20 = r7
            throw r20
        L_0x0048:
            r20 = 0
            r7 = r20
            r20 = 0
            r8 = r20
            java.util.ArrayList r20 = new java.util.ArrayList
            r28 = r20
            r20 = r28
            r21 = r28
            r21.<init>()
            r9 = r20
            r20 = 0
            r10 = r20
            r20 = 0
            r12 = r20
            r20 = r4
            net.lingala.zip4j.model.EndCentralDirRecord r20 = r20.getEndCentralDirRecord()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            int r20 = r20.getNoOfThisDisk()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r13 = r20
            r20 = r13
            if (r20 > 0) goto L_0x00b4
            net.lingala.zip4j.exception.ZipException r20 = new net.lingala.zip4j.exception.ZipException     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r28 = r20
            r20 = r28
            r21 = r28
            java.lang.String r22 = "corrupt zip model, archive not a split zip file"
            r21.<init>((java.lang.String) r22)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            throw r20     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
        L_0x0084:
            r20 = move-exception
            r13 = r20
            r20 = r6
            r21 = r13
            r20.endProgressMonitorError(r21)     // Catch:{ all -> 0x009c }
            net.lingala.zip4j.exception.ZipException r20 = new net.lingala.zip4j.exception.ZipException     // Catch:{ all -> 0x009c }
            r28 = r20
            r20 = r28
            r21 = r28
            r22 = r13
            r21.<init>((java.lang.Throwable) r22)     // Catch:{ all -> 0x009c }
            throw r20     // Catch:{ all -> 0x009c }
        L_0x009c:
            r20 = move-exception
            r18 = r20
            r20 = r7
            if (r20 == 0) goto L_0x00a8
            r20 = r7
            r20.close()     // Catch:{ IOException -> 0x0247 }
        L_0x00a8:
            r20 = r8
            if (r20 == 0) goto L_0x00b1
            r20 = r8
            r20.close()     // Catch:{ IOException -> 0x024c }
        L_0x00b1:
            r20 = r18
            throw r20
        L_0x00b4:
            r20 = r3
            r21 = r5
            java.io.OutputStream r20 = r20.prepareOutputStreamForMerge(r21)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r7 = r20
            r20 = 0
            r14 = r20
        L_0x00c2:
            r20 = r14
            r21 = r13
            r0 = r20
            r1 = r21
            if (r0 <= r1) goto L_0x011a
            r20 = r4
            java.lang.Object r20 = r20.clone()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            net.lingala.zip4j.model.ZipModel r20 = (net.lingala.zip4j.model.ZipModel) r20     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r14 = r20
            r20 = r14
            net.lingala.zip4j.model.EndCentralDirRecord r20 = r20.getEndCentralDirRecord()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r21 = r10
            r20.setOffsetOfStartOfCentralDir(r21)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r20 = r3
            r21 = r14
            r22 = r9
            r23 = r12
            r20.updateSplitZipModel(r21, r22, r23)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            net.lingala.zip4j.core.HeaderWriter r20 = new net.lingala.zip4j.core.HeaderWriter     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r28 = r20
            r20 = r28
            r21 = r28
            r21.<init>()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r15 = r20
            r20 = r15
            r21 = r14
            r22 = r7
            r20.finalizeZipFileWithoutValidations(r21, r22)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r20 = r6
            r20.endProgressMonitorSuccess()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r20 = r7
            if (r20 == 0) goto L_0x0110
            r20 = r7
            r20.close()     // Catch:{ IOException -> 0x0251 }
        L_0x0110:
            r20 = r8
            if (r20 == 0) goto L_0x0119
            r20 = r8
            r20.close()     // Catch:{ IOException -> 0x0256 }
        L_0x0119:
            return
        L_0x011a:
            r20 = r3
            r21 = r4
            r22 = r14
            java.io.RandomAccessFile r20 = r20.createSplitZipFileHandler(r21, r22)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r8 = r20
            r20 = 0
            r15 = r20
            java.lang.Long r20 = new java.lang.Long     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r28 = r20
            r20 = r28
            r21 = r28
            r22 = r8
            long r22 = r22.length()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r21.<init>(r22)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r16 = r20
            r20 = r14
            if (r20 != 0) goto L_0x019a
            r20 = r4
            net.lingala.zip4j.model.CentralDirectory r20 = r20.getCentralDirectory()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            if (r20 == 0) goto L_0x019a
            r20 = r4
            net.lingala.zip4j.model.CentralDirectory r20 = r20.getCentralDirectory()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            java.util.ArrayList r20 = r20.getFileHeaders()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            if (r20 == 0) goto L_0x019a
            r20 = r4
            net.lingala.zip4j.model.CentralDirectory r20 = r20.getCentralDirectory()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            java.util.ArrayList r20 = r20.getFileHeaders()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            int r20 = r20.size()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            if (r20 <= 0) goto L_0x019a
            r20 = 4
            r0 = r20
            byte[] r0 = new byte[r0]     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r20 = r0
            r17 = r20
            r20 = r8
            r21 = 0
            r20.seek(r21)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r20 = r8
            r21 = r17
            int r20 = r20.read(r21)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r20 = r17
            r21 = 0
            int r20 = net.lingala.zip4j.util.Raw.readIntLittleEndian(r20, r21)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r0 = r20
            long r0 = (long) r0     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r20 = r0
            r22 = 134695760(0x8074b50, double:6.65485477E-316)
            int r20 = (r20 > r22 ? 1 : (r20 == r22 ? 0 : -1))
            if (r20 != 0) goto L_0x019a
            r20 = 4
            r15 = r20
            r20 = 1
            r12 = r20
        L_0x019a:
            r20 = r14
            r21 = r13
            r0 = r20
            r1 = r21
            if (r0 != r1) goto L_0x01bb
            java.lang.Long r20 = new java.lang.Long     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r28 = r20
            r20 = r28
            r21 = r28
            r22 = r4
            net.lingala.zip4j.model.EndCentralDirRecord r22 = r22.getEndCentralDirRecord()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            long r22 = r22.getOffsetOfStartOfCentralDir()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r21.<init>(r22)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r16 = r20
        L_0x01bb:
            r20 = r3
            r21 = r8
            r22 = r7
            r23 = r15
            r0 = r23
            long r0 = (long) r0     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r23 = r0
            r25 = r16
            long r25 = r25.longValue()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r27 = r6
            r20.copyFile(r21, r22, r23, r25, r27)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r20 = r10
            r22 = r16
            long r22 = r22.longValue()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r24 = r15
            r0 = r24
            long r0 = (long) r0     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r24 = r0
            long r22 = r22 - r24
            long r20 = r20 + r22
            r10 = r20
            r20 = r6
            boolean r20 = r20.isCancelAllTasks()     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            if (r20 == 0) goto L_0x021a
            r20 = r6
            r21 = 3
            r20.setResult(r21)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r20 = r6
            r21 = 0
            r20.setState(r21)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r20 = r7
            if (r20 == 0) goto L_0x0207
            r20 = r7
            r20.close()     // Catch:{ IOException -> 0x0212 }
        L_0x0207:
            r20 = r8
            if (r20 == 0) goto L_0x0210
            r20 = r8
            r20.close()     // Catch:{ IOException -> 0x0216 }
        L_0x0210:
            goto L_0x0119
        L_0x0212:
            r20 = move-exception
            r19 = r20
            goto L_0x0207
        L_0x0216:
            r20 = move-exception
            r19 = r20
            goto L_0x0210
        L_0x021a:
            r20 = r9
            r21 = r16
            boolean r20 = r20.add(r21)     // Catch:{ IOException -> 0x0084, Exception -> 0x022f }
            r20 = r8
            r20.close()     // Catch:{ IOException -> 0x022b, Exception -> 0x022f }
        L_0x0227:
            int r14 = r14 + 1
            goto L_0x00c2
        L_0x022b:
            r20 = move-exception
            r17 = r20
            goto L_0x0227
        L_0x022f:
            r20 = move-exception
            r13 = r20
            r20 = r6
            r21 = r13
            r20.endProgressMonitorError(r21)     // Catch:{ all -> 0x009c }
            net.lingala.zip4j.exception.ZipException r20 = new net.lingala.zip4j.exception.ZipException     // Catch:{ all -> 0x009c }
            r28 = r20
            r20 = r28
            r21 = r28
            r22 = r13
            r21.<init>((java.lang.Throwable) r22)     // Catch:{ all -> 0x009c }
            throw r20     // Catch:{ all -> 0x009c }
        L_0x0247:
            r20 = move-exception
            r19 = r20
            goto L_0x00a8
        L_0x024c:
            r20 = move-exception
            r19 = r20
            goto L_0x00b1
        L_0x0251:
            r20 = move-exception
            r19 = r20
            goto L_0x0110
        L_0x0256:
            r20 = move-exception
            r19 = r20
            goto L_0x0119
        */
        throw new UnsupportedOperationException("Method not decompiled: net.lingala.zip4j.util.ArchiveMaintainer.initMergeSplitZipFile(net.lingala.zip4j.model.ZipModel, java.io.File, net.lingala.zip4j.progress.ProgressMonitor):void");
    }

    private RandomAccessFile createSplitZipFileHandler(ZipModel zipModel, int i) throws ZipException {
        Throwable th;
        Throwable th2;
        StringBuffer stringBuffer;
        String partFile;
        StringBuffer stringBuffer2;
        File file;
        RandomAccessFile randomAccessFile;
        Throwable th3;
        StringBuffer stringBuffer3;
        Throwable th4;
        Throwable th5;
        ZipModel zipModel2 = zipModel;
        int partNumber = i;
        if (zipModel2 == null) {
            Throwable th6 = th5;
            new ZipException("zip model is null, cannot create split file handler");
            throw th6;
        } else if (partNumber < 0) {
            Throwable th7 = th4;
            new ZipException("invlaid part number, cannot create split file handler");
            throw th7;
        } else {
            try {
                String curZipFile = zipModel2.getZipFile();
                if (partNumber == zipModel2.getEndCentralDirRecord().getNoOfThisDisk()) {
                    partFile = zipModel2.getZipFile();
                } else if (partNumber >= 9) {
                    new StringBuffer(String.valueOf(curZipFile.substring(0, curZipFile.lastIndexOf("."))));
                    partFile = stringBuffer2.append(".z").append(partNumber + 1).toString();
                } else {
                    new StringBuffer(String.valueOf(curZipFile.substring(0, curZipFile.lastIndexOf("."))));
                    partFile = stringBuffer.append(".z0").append(partNumber + 1).toString();
                }
                new File(partFile);
                File tmpFile = file;
                if (!Zip4jUtil.checkFileExists(tmpFile)) {
                    Throwable th8 = th3;
                    new StringBuffer("split file does not exist: ");
                    new ZipException(stringBuffer3.append(partFile).toString());
                    throw th8;
                }
                RandomAccessFile randomAccessFile2 = randomAccessFile;
                new RandomAccessFile(tmpFile, InternalZipConstants.READ_MODE);
                return randomAccessFile2;
            } catch (FileNotFoundException e) {
                FileNotFoundException e2 = e;
                Throwable th9 = th2;
                new ZipException((Throwable) e2);
                throw th9;
            } catch (Exception e3) {
                Exception e4 = e3;
                Throwable th10 = th;
                new ZipException((Throwable) e4);
                throw th10;
            }
        }
    }

    private OutputStream prepareOutputStreamForMerge(File file) throws ZipException {
        Throwable th;
        Throwable th2;
        OutputStream outputStream;
        Throwable th3;
        File outFile = file;
        if (outFile == null) {
            Throwable th4 = th3;
            new ZipException("outFile is null, cannot create outputstream");
            throw th4;
        }
        try {
            OutputStream outputStream2 = outputStream;
            new FileOutputStream(outFile);
            return outputStream2;
        } catch (FileNotFoundException e) {
            FileNotFoundException e2 = e;
            Throwable th5 = th2;
            new ZipException((Throwable) e2);
            throw th5;
        } catch (Exception e3) {
            Exception e4 = e3;
            Throwable th6 = th;
            new ZipException((Throwable) e4);
            throw th6;
        }
    }

    private void updateSplitZipModel(ZipModel zipModel, ArrayList arrayList, boolean z) throws ZipException {
        Throwable th;
        ZipModel zipModel2 = zipModel;
        ArrayList fileSizeList = arrayList;
        boolean splitSigRemoved = z;
        if (zipModel2 == null) {
            Throwable th2 = th;
            new ZipException("zip model is null, cannot update split zip model");
            throw th2;
        }
        zipModel2.setSplitArchive(false);
        updateSplitFileHeader(zipModel2, fileSizeList, splitSigRemoved);
        updateSplitEndCentralDirectory(zipModel2);
        if (zipModel2.isZip64Format()) {
            updateSplitZip64EndCentralDirLocator(zipModel2, fileSizeList);
            updateSplitZip64EndCentralDirRec(zipModel2, fileSizeList);
        }
    }

    private void updateSplitFileHeader(ZipModel zipModel, ArrayList arrayList, boolean z) throws ZipException {
        Throwable th;
        Throwable th2;
        ZipModel zipModel2 = zipModel;
        ArrayList fileSizeList = arrayList;
        boolean splitSigRemoved = z;
        try {
            if (zipModel2.getCentralDirectory() == null) {
                Throwable th3 = th2;
                new ZipException("corrupt zip model - getCentralDirectory, cannot update split zip model");
                throw th3;
            }
            int fileHeaderCount = zipModel2.getCentralDirectory().getFileHeaders().size();
            int splitSigOverhead = 0;
            if (splitSigRemoved) {
                splitSigOverhead = 4;
            }
            for (int i = 0; i < fileHeaderCount; i++) {
                long offsetLHToAdd = 0;
                for (int j = 0; j < ((FileHeader) zipModel2.getCentralDirectory().getFileHeaders().get(i)).getDiskNumberStart(); j++) {
                    offsetLHToAdd += ((Long) fileSizeList.get(j)).longValue();
                }
                ((FileHeader) zipModel2.getCentralDirectory().getFileHeaders().get(i)).setOffsetLocalHeader((((FileHeader) zipModel2.getCentralDirectory().getFileHeaders().get(i)).getOffsetLocalHeader() + offsetLHToAdd) - ((long) splitSigOverhead));
                ((FileHeader) zipModel2.getCentralDirectory().getFileHeaders().get(i)).setDiskNumberStart(0);
            }
        } catch (ZipException e) {
            throw e;
        } catch (Exception e2) {
            Exception e3 = e2;
            Throwable th4 = th;
            new ZipException((Throwable) e3);
            throw th4;
        }
    }

    private void updateSplitEndCentralDirectory(ZipModel zipModel) throws ZipException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        ZipModel zipModel2 = zipModel;
        if (zipModel2 == null) {
            try {
                Throwable th4 = th3;
                new ZipException("zip model is null - cannot update end of central directory for split zip model");
                throw th4;
            } catch (ZipException e) {
                throw e;
            } catch (Exception e2) {
                Exception e3 = e2;
                Throwable th5 = th;
                new ZipException((Throwable) e3);
                throw th5;
            }
        } else if (zipModel2.getCentralDirectory() == null) {
            Throwable th6 = th2;
            new ZipException("corrupt zip model - getCentralDirectory, cannot update split zip model");
            throw th6;
        } else {
            zipModel2.getEndCentralDirRecord().setNoOfThisDisk(0);
            zipModel2.getEndCentralDirRecord().setNoOfThisDiskStartOfCentralDir(0);
            zipModel2.getEndCentralDirRecord().setTotNoOfEntriesInCentralDir(zipModel2.getCentralDirectory().getFileHeaders().size());
            zipModel2.getEndCentralDirRecord().setTotNoOfEntriesInCentralDirOnThisDisk(zipModel2.getCentralDirectory().getFileHeaders().size());
        }
    }

    private void updateSplitZip64EndCentralDirLocator(ZipModel zipModel, ArrayList arrayList) throws ZipException {
        Throwable th;
        ZipModel zipModel2 = zipModel;
        ArrayList fileSizeList = arrayList;
        if (zipModel2 == null) {
            Throwable th2 = th;
            new ZipException("zip model is null, cannot update split Zip64 end of central directory locator");
            throw th2;
        } else if (zipModel2.getZip64EndCentralDirLocator() != null) {
            zipModel2.getZip64EndCentralDirLocator().setNoOfDiskStartOfZip64EndOfCentralDirRec(0);
            long offsetZip64EndCentralDirRec = 0;
            for (int i = 0; i < fileSizeList.size(); i++) {
                offsetZip64EndCentralDirRec += ((Long) fileSizeList.get(i)).longValue();
            }
            zipModel2.getZip64EndCentralDirLocator().setOffsetZip64EndOfCentralDirRec(zipModel2.getZip64EndCentralDirLocator().getOffsetZip64EndOfCentralDirRec() + offsetZip64EndCentralDirRec);
            zipModel2.getZip64EndCentralDirLocator().setTotNumberOfDiscs(1);
        }
    }

    private void updateSplitZip64EndCentralDirRec(ZipModel zipModel, ArrayList arrayList) throws ZipException {
        Throwable th;
        ZipModel zipModel2 = zipModel;
        ArrayList fileSizeList = arrayList;
        if (zipModel2 == null) {
            Throwable th2 = th;
            new ZipException("zip model is null, cannot update split Zip64 end of central directory record");
            throw th2;
        } else if (zipModel2.getZip64EndCentralDirRecord() != null) {
            zipModel2.getZip64EndCentralDirRecord().setNoOfThisDisk(0);
            zipModel2.getZip64EndCentralDirRecord().setNoOfThisDiskStartOfCentralDir(0);
            zipModel2.getZip64EndCentralDirRecord().setTotNoOfEntriesInCentralDirOnThisDisk((long) zipModel2.getEndCentralDirRecord().getTotNoOfEntriesInCentralDir());
            long offsetStartCenDirWRTStartDiskNo = 0;
            for (int i = 0; i < fileSizeList.size(); i++) {
                offsetStartCenDirWRTStartDiskNo += ((Long) fileSizeList.get(i)).longValue();
            }
            zipModel2.getZip64EndCentralDirRecord().setOffsetStartCenDirWRTStartDiskNo(zipModel2.getZip64EndCentralDirRecord().getOffsetStartCenDirWRTStartDiskNo() + offsetStartCenDirWRTStartDiskNo);
        }
    }

    public void setComment(ZipModel zipModel, String str) throws ZipException {
        Throwable th;
        Throwable th2;
        HeaderWriter headerWriter;
        SplitOutputStream splitOutputStream;
        Throwable th3;
        String str2;
        Throwable th4;
        Throwable th5;
        ZipModel zipModel2 = zipModel;
        String comment = str;
        if (comment == null) {
            Throwable th6 = th5;
            new ZipException("comment is null, cannot update Zip file with comment");
            throw th6;
        } else if (zipModel2 == null) {
            Throwable th7 = th4;
            new ZipException("zipModel is null, cannot update Zip file with comment");
            throw th7;
        } else {
            String encodedComment = comment;
            byte[] commentBytes = comment.getBytes();
            int commentLength = comment.length();
            if (Zip4jUtil.isSupportedCharset(InternalZipConstants.CHARSET_COMMENTS_DEFAULT)) {
                try {
                    new String(comment.getBytes(InternalZipConstants.CHARSET_COMMENTS_DEFAULT), InternalZipConstants.CHARSET_COMMENTS_DEFAULT);
                    encodedComment = str2;
                    commentBytes = encodedComment.getBytes(InternalZipConstants.CHARSET_COMMENTS_DEFAULT);
                    commentLength = encodedComment.length();
                } catch (UnsupportedEncodingException e) {
                    UnsupportedEncodingException unsupportedEncodingException = e;
                    encodedComment = comment;
                    commentBytes = comment.getBytes();
                    commentLength = comment.length();
                }
            }
            if (commentLength > 65535) {
                Throwable th8 = th3;
                new ZipException("comment length exceeds maximum length");
                throw th8;
            }
            zipModel2.getEndCentralDirRecord().setComment(encodedComment);
            zipModel2.getEndCentralDirRecord().setCommentBytes(commentBytes);
            zipModel2.getEndCentralDirRecord().setCommentLength(commentLength);
            SplitOutputStream outputStream = null;
            try {
                new HeaderWriter();
                HeaderWriter headerWriter2 = headerWriter;
                new SplitOutputStream(zipModel2.getZipFile());
                outputStream = splitOutputStream;
                if (zipModel2.isZip64Format()) {
                    outputStream.seek(zipModel2.getZip64EndCentralDirRecord().getOffsetStartCenDirWRTStartDiskNo());
                } else {
                    outputStream.seek(zipModel2.getEndCentralDirRecord().getOffsetOfStartOfCentralDir());
                }
                headerWriter2.finalizeZipFileWithoutValidations(zipModel2, outputStream);
                if (outputStream != null) {
                    try {
                        outputStream.close();
                    } catch (IOException e2) {
                        IOException iOException = e2;
                    }
                }
            } catch (FileNotFoundException e3) {
                FileNotFoundException e4 = e3;
                Throwable th9 = th2;
                new ZipException((Throwable) e4);
                throw th9;
            } catch (IOException e5) {
                IOException e6 = e5;
                Throwable th10 = th;
                new ZipException((Throwable) e6);
                throw th10;
            } catch (Throwable th11) {
                Throwable th12 = th11;
                if (outputStream != null) {
                    try {
                        outputStream.close();
                    } catch (IOException e7) {
                        IOException iOException2 = e7;
                    }
                }
                throw th12;
            }
        }
    }

    public void initProgressMonitorForRemoveOp(ZipModel zipModel, FileHeader fileHeader, ProgressMonitor progressMonitor) throws ZipException {
        Throwable th;
        ZipModel zipModel2 = zipModel;
        FileHeader fileHeader2 = fileHeader;
        ProgressMonitor progressMonitor2 = progressMonitor;
        if (zipModel2 == null || fileHeader2 == null || progressMonitor2 == null) {
            Throwable th2 = th;
            new ZipException("one of the input parameters is null, cannot calculate total work");
            throw th2;
        }
        progressMonitor2.setCurrentOperation(2);
        progressMonitor2.setFileName(fileHeader2.getFileName());
        progressMonitor2.setTotalWork(calculateTotalWorkForRemoveOp(zipModel2, fileHeader2));
        progressMonitor2.setState(1);
    }

    private long calculateTotalWorkForRemoveOp(ZipModel zipModel, FileHeader fileHeader) throws ZipException {
        File file;
        new File(zipModel.getZipFile());
        return Zip4jUtil.getFileLengh(file) - fileHeader.getCompressedSize();
    }

    public void initProgressMonitorForMergeOp(ZipModel zipModel, ProgressMonitor progressMonitor) throws ZipException {
        Throwable th;
        ZipModel zipModel2 = zipModel;
        ProgressMonitor progressMonitor2 = progressMonitor;
        if (zipModel2 == null) {
            Throwable th2 = th;
            new ZipException("zip model is null, cannot calculate total work for merge op");
            throw th2;
        }
        progressMonitor2.setCurrentOperation(4);
        progressMonitor2.setFileName(zipModel2.getZipFile());
        progressMonitor2.setTotalWork(calculateTotalWorkForMergeOp(zipModel2));
        progressMonitor2.setState(1);
    }

    private long calculateTotalWorkForMergeOp(ZipModel zipModel) throws ZipException {
        StringBuffer stringBuffer;
        String partFile;
        StringBuffer stringBuffer2;
        File file;
        ZipModel zipModel2 = zipModel;
        long totSize = 0;
        if (zipModel2.isSplitArchive()) {
            int totNoOfSplitFiles = zipModel2.getEndCentralDirRecord().getNoOfThisDisk();
            String curZipFile = zipModel2.getZipFile();
            for (int i = 0; i <= totNoOfSplitFiles; i++) {
                if (0 == zipModel2.getEndCentralDirRecord().getNoOfThisDisk()) {
                    partFile = zipModel2.getZipFile();
                } else if (0 >= 9) {
                    new StringBuffer(String.valueOf(curZipFile.substring(0, curZipFile.lastIndexOf("."))));
                    partFile = stringBuffer2.append(".z").append(0 + 1).toString();
                } else {
                    new StringBuffer(String.valueOf(curZipFile.substring(0, curZipFile.lastIndexOf("."))));
                    partFile = stringBuffer.append(".z0").append(0 + 1).toString();
                }
                new File(partFile);
                totSize += Zip4jUtil.getFileLengh(file);
            }
        }
        return totSize;
    }
}
