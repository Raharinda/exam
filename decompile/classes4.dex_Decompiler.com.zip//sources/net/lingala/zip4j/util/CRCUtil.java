package net.lingala.zip4j.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.CRC32;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.progress.ProgressMonitor;

public class CRCUtil {
    private static final int BUF_SIZE = 16384;

    public CRCUtil() {
    }

    public static long computeFileCRC(String inputFile) throws ZipException {
        return computeFileCRC(inputFile, (ProgressMonitor) null);
    }

    public static long computeFileCRC(String str, ProgressMonitor progressMonitor) throws ZipException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        InputStream inputStream;
        File file;
        CRC32 crc32;
        Throwable th4;
        Throwable th5;
        Throwable th6;
        String inputFile = str;
        ProgressMonitor progressMonitor2 = progressMonitor;
        if (!Zip4jUtil.isStringNotNullAndNotEmpty(inputFile)) {
            Throwable th7 = th6;
            new ZipException("input file is null or empty, cannot calculate CRC for the file");
            throw th7;
        }
        InputStream inputStream2 = null;
        try {
            boolean checkFileReadAccess = Zip4jUtil.checkFileReadAccess(inputFile);
            new File(inputFile);
            new FileInputStream(file);
            inputStream2 = inputStream;
            byte[] buff = new byte[BUF_SIZE];
            new CRC32();
            CRC32 crc322 = crc32;
            while (true) {
                int read = inputStream2.read(buff);
                int readLen = read;
                if (read == -1) {
                    long value = crc322.getValue();
                    if (inputStream2 != null) {
                        try {
                            inputStream2.close();
                        } catch (IOException e) {
                            IOException iOException = e;
                            Throwable th8 = th4;
                            new ZipException("error while closing the file after calculating crc");
                            throw th8;
                        }
                    }
                    return value;
                }
                crc322.update(buff, 0, readLen);
                if (progressMonitor2 != null) {
                    progressMonitor2.updateWorkCompleted((long) readLen);
                    if (progressMonitor2.isCancelAllTasks()) {
                        progressMonitor2.setResult(3);
                        progressMonitor2.setState(0);
                        if (inputStream2 != null) {
                            try {
                                inputStream2.close();
                            } catch (IOException e2) {
                                IOException iOException2 = e2;
                                Throwable th9 = th5;
                                new ZipException("error while closing the file after calculating crc");
                                throw th9;
                            }
                        }
                        return 0;
                    }
                }
            }
        } catch (IOException e3) {
            IOException e4 = e3;
            Throwable th10 = th3;
            new ZipException((Throwable) e4);
            throw th10;
        } catch (Exception e5) {
            Exception e6 = e5;
            Throwable th11 = th;
            new ZipException((Throwable) e6);
            throw th11;
        } catch (Throwable th12) {
            Throwable th13 = th12;
            if (inputStream2 != null) {
                try {
                    inputStream2.close();
                } catch (IOException e7) {
                    IOException iOException3 = e7;
                    Throwable th14 = th2;
                    new ZipException("error while closing the file after calculating crc");
                    throw th14;
                }
            }
            throw th13;
        }
    }
}
