package net.lingala.zip4j.util;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.ZipModel;

public class Zip4jUtil {
    public Zip4jUtil() {
    }

    public static boolean isStringNotNullAndNotEmpty(String str) {
        String str2 = str;
        if (str2 == null || str2.trim().length() <= 0) {
            return false;
        }
        return true;
    }

    public static boolean checkOutputFolder(String str) throws ZipException {
        File file;
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        Throwable th6;
        Throwable th7;
        String path = str;
        if (!isStringNotNullAndNotEmpty(path)) {
            Throwable th8 = th6;
            new NullPointerException("output path is null");
            new ZipException(th7);
            throw th8;
        }
        new File(path);
        File file2 = file;
        if (!file2.exists()) {
            try {
                boolean mkdirs = file2.mkdirs();
                if (!file2.isDirectory()) {
                    Throwable th9 = th3;
                    new ZipException("output folder is not valid");
                    throw th9;
                } else if (!file2.canWrite()) {
                    Throwable th10 = th2;
                    new ZipException("no write access to destination folder");
                    throw th10;
                }
            } catch (Exception e) {
                Exception exc = e;
                Throwable th11 = th;
                new ZipException("Cannot create destination folder");
                throw th11;
            }
        } else if (!file2.isDirectory()) {
            Throwable th12 = th5;
            new ZipException("output folder is not valid");
            throw th12;
        } else if (!file2.canWrite()) {
            Throwable th13 = th4;
            new ZipException("no write access to output folder");
            throw th13;
        }
        return true;
    }

    public static boolean checkFileReadAccess(String str) throws ZipException {
        Throwable th;
        File file;
        Throwable th2;
        StringBuffer stringBuffer;
        Throwable th3;
        String path = str;
        if (!isStringNotNullAndNotEmpty(path)) {
            Throwable th4 = th3;
            new ZipException("path is null");
            throw th4;
        } else if (!checkFileExists(path)) {
            Throwable th5 = th2;
            new StringBuffer("file does not exist: ");
            new ZipException(stringBuffer.append(path).toString());
            throw th5;
        } else {
            try {
                new File(path);
                return file.canRead();
            } catch (Exception e) {
                Exception exc = e;
                Throwable th6 = th;
                new ZipException("cannot read zip file");
                throw th6;
            }
        }
    }

    public static boolean checkFileWriteAccess(String str) throws ZipException {
        Throwable th;
        File file;
        Throwable th2;
        StringBuffer stringBuffer;
        Throwable th3;
        String path = str;
        if (!isStringNotNullAndNotEmpty(path)) {
            Throwable th4 = th3;
            new ZipException("path is null");
            throw th4;
        } else if (!checkFileExists(path)) {
            Throwable th5 = th2;
            new StringBuffer("file does not exist: ");
            new ZipException(stringBuffer.append(path).toString());
            throw th5;
        } else {
            try {
                new File(path);
                return file.canWrite();
            } catch (Exception e) {
                Exception exc = e;
                Throwable th6 = th;
                new ZipException("cannot read zip file");
                throw th6;
            }
        }
    }

    public static boolean checkFileExists(String str) throws ZipException {
        File file;
        Throwable th;
        String path = str;
        if (!isStringNotNullAndNotEmpty(path)) {
            Throwable th2 = th;
            new ZipException("path is null");
            throw th2;
        }
        new File(path);
        return checkFileExists(file);
    }

    public static boolean checkFileExists(File file) throws ZipException {
        Throwable th;
        File file2 = file;
        if (file2 != null) {
            return file2.exists();
        }
        Throwable th2 = th;
        new ZipException("cannot check if file exists: input file is null");
        throw th2;
    }

    public static boolean isWindows() {
        return System.getProperty("os.name").toLowerCase().indexOf("win") >= 0;
    }

    public static void setFileReadOnly(File file) throws ZipException {
        Throwable th;
        File file2 = file;
        if (file2 == null) {
            Throwable th2 = th;
            new ZipException("input file is null. cannot set read only file attribute");
            throw th2;
        } else if (file2.exists()) {
            boolean readOnly = file2.setReadOnly();
        }
    }

    public static void setFileHidden(File file) throws ZipException {
    }

    public static void setFileArchive(File file) throws ZipException {
    }

    public static void setFileSystemMode(File file) throws ZipException {
    }

    public static long getLastModifiedFileTime(File file, TimeZone timeZone) throws ZipException {
        Throwable th;
        Throwable th2;
        File file2 = file;
        TimeZone timeZone2 = timeZone;
        if (file2 == null) {
            Throwable th3 = th2;
            new ZipException("input file is null, cannot read last modified file time");
            throw th3;
        } else if (file2.exists()) {
            return file2.lastModified();
        } else {
            Throwable th4 = th;
            new ZipException("input file does not exist, cannot read last modified file time");
            throw th4;
        }
    }

    public static String getFileNameFromFilePath(File file) throws ZipException {
        Throwable th;
        File file2 = file;
        if (file2 == null) {
            Throwable th2 = th;
            new ZipException("input file is null, cannot get file name");
            throw th2;
        } else if (file2.isDirectory()) {
            return null;
        } else {
            return file2.getName();
        }
    }

    public static long getFileLengh(String str) throws ZipException {
        File file;
        Throwable th;
        String file2 = str;
        if (!isStringNotNullAndNotEmpty(file2)) {
            Throwable th2 = th;
            new ZipException("invalid file name");
            throw th2;
        }
        new File(file2);
        return getFileLengh(file);
    }

    public static long getFileLengh(File file) throws ZipException {
        Throwable th;
        File file2 = file;
        if (file2 == null) {
            Throwable th2 = th;
            new ZipException("input file is null, cannot calculate file length");
            throw th2;
        } else if (file2.isDirectory()) {
            return -1;
        } else {
            return file2.length();
        }
    }

    public static long javaToDosTime(long time) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(time);
        int year = cal.get(1);
        if (year < 1980) {
            return 2162688;
        }
        return (long) (((year - 1980) << 25) | ((cal.get(2) + 1) << 21) | (cal.get(5) << 16) | (cal.get(11) << 11) | (cal.get(12) << 5) | (cal.get(13) >> 1));
    }

    public static long dosToJavaTme(int i) {
        int dosTime = i;
        int hrs = (dosTime >> 11) & 31;
        int day = (dosTime >> 16) & 31;
        int mon = ((dosTime >> 21) & 15) - 1;
        int year = ((dosTime >> 25) & 127) + 1980;
        Calendar cal = Calendar.getInstance();
        cal.set(year, mon, day, hrs, (dosTime >> 5) & 63, 2 * (dosTime & 31));
        cal.set(14, 0);
        return cal.getTime().getTime();
    }

    public static FileHeader getFileHeader(ZipModel zipModel, String str) throws ZipException {
        Throwable th;
        StringBuffer stringBuffer;
        Throwable th2;
        StringBuffer stringBuffer2;
        ZipModel zipModel2 = zipModel;
        String fileName = str;
        if (zipModel2 == null) {
            Throwable th3 = th2;
            new StringBuffer("zip model is null, cannot determine file header for fileName: ");
            new ZipException(stringBuffer2.append(fileName).toString());
            throw th3;
        } else if (!isStringNotNullAndNotEmpty(fileName)) {
            Throwable th4 = th;
            new StringBuffer("file name is null, cannot determine file header for fileName: ");
            new ZipException(stringBuffer.append(fileName).toString());
            throw th4;
        } else {
            FileHeader fileHeader = getFileHeaderWithExactMatch(zipModel2, fileName);
            if (fileHeader == null) {
                String fileName2 = fileName.replaceAll("\\\\", InternalZipConstants.ZIP_FILE_SEPARATOR);
                fileHeader = getFileHeaderWithExactMatch(zipModel2, fileName2);
                if (fileHeader == null) {
                    fileHeader = getFileHeaderWithExactMatch(zipModel2, fileName2.replaceAll(InternalZipConstants.ZIP_FILE_SEPARATOR, "\\\\"));
                }
            }
            return fileHeader;
        }
    }

    public static FileHeader getFileHeaderWithExactMatch(ZipModel zipModel, String str) throws ZipException {
        Throwable th;
        StringBuffer stringBuffer;
        Throwable th2;
        StringBuffer stringBuffer2;
        Throwable th3;
        StringBuffer stringBuffer3;
        Throwable th4;
        StringBuffer stringBuffer4;
        ZipModel zipModel2 = zipModel;
        String fileName = str;
        if (zipModel2 == null) {
            Throwable th5 = th4;
            new StringBuffer("zip model is null, cannot determine file header with exact match for fileName: ");
            new ZipException(stringBuffer4.append(fileName).toString());
            throw th5;
        } else if (!isStringNotNullAndNotEmpty(fileName)) {
            Throwable th6 = th3;
            new StringBuffer("file name is null, cannot determine file header with exact match for fileName: ");
            new ZipException(stringBuffer3.append(fileName).toString());
            throw th6;
        } else if (zipModel2.getCentralDirectory() == null) {
            Throwable th7 = th2;
            new StringBuffer("central directory is null, cannot determine file header with exact match for fileName: ");
            new ZipException(stringBuffer2.append(fileName).toString());
            throw th7;
        } else if (zipModel2.getCentralDirectory().getFileHeaders() == null) {
            Throwable th8 = th;
            new StringBuffer("file Headers are null, cannot determine file header with exact match for fileName: ");
            new ZipException(stringBuffer.append(fileName).toString());
            throw th8;
        } else if (zipModel2.getCentralDirectory().getFileHeaders().size() <= 0) {
            return null;
        } else {
            ArrayList fileHeaders = zipModel2.getCentralDirectory().getFileHeaders();
            for (int i = 0; i < fileHeaders.size(); i++) {
                FileHeader fileHeader = (FileHeader) fileHeaders.get(i);
                String fileNameForHdr = fileHeader.getFileName();
                if (isStringNotNullAndNotEmpty(fileNameForHdr) && fileName.equalsIgnoreCase(fileNameForHdr)) {
                    return fileHeader;
                }
            }
            return null;
        }
    }

    public static int getIndexOfFileHeader(ZipModel zipModel, FileHeader fileHeader) throws ZipException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        ZipModel zipModel2 = zipModel;
        FileHeader fileHeader2 = fileHeader;
        if (zipModel2 == null || fileHeader2 == null) {
            Throwable th5 = th;
            new ZipException("input parameters is null, cannot determine index of file header");
            throw th5;
        } else if (zipModel2.getCentralDirectory() == null) {
            Throwable th6 = th4;
            new ZipException("central directory is null, ccannot determine index of file header");
            throw th6;
        } else if (zipModel2.getCentralDirectory().getFileHeaders() == null) {
            Throwable th7 = th3;
            new ZipException("file Headers are null, cannot determine index of file header");
            throw th7;
        } else if (zipModel2.getCentralDirectory().getFileHeaders().size() <= 0) {
            return -1;
        } else {
            String fileName = fileHeader2.getFileName();
            if (!isStringNotNullAndNotEmpty(fileName)) {
                Throwable th8 = th2;
                new ZipException("file name in file header is empty or null, cannot determine index of file header");
                throw th8;
            }
            ArrayList fileHeaders = zipModel2.getCentralDirectory().getFileHeaders();
            for (int i = 0; i < fileHeaders.size(); i++) {
                String fileNameForHdr = ((FileHeader) fileHeaders.get(i)).getFileName();
                if (isStringNotNullAndNotEmpty(fileNameForHdr) && fileName.equalsIgnoreCase(fileNameForHdr)) {
                    return i;
                }
            }
            return -1;
        }
    }

    public static ArrayList getFilesInDirectoryRec(File file, boolean z) throws ZipException {
        ArrayList arrayList;
        Throwable th;
        File path = file;
        boolean readHiddenFiles = z;
        if (path == null) {
            Throwable th2 = th;
            new ZipException("input path is null, cannot read files in the directory");
            throw th2;
        }
        new ArrayList();
        ArrayList result = arrayList;
        List filesDirs = Arrays.asList(path.listFiles());
        if (!path.canRead()) {
            return result;
        }
        for (int i = 0; i < filesDirs.size(); i++) {
            File file2 = (File) filesDirs.get(i);
            if (file2.isHidden() && !readHiddenFiles) {
                return result;
            }
            boolean add = result.add(file2);
            if (file2.isDirectory()) {
                boolean addAll = result.addAll(getFilesInDirectoryRec(file2, readHiddenFiles));
            }
        }
        return result;
    }

    public static String getZipFileNameWithoutExt(String str) throws ZipException {
        Throwable th;
        String zipFile = str;
        if (!isStringNotNullAndNotEmpty(zipFile)) {
            Throwable th2 = th;
            new ZipException("zip file name is empty or null, cannot determine zip file name");
            throw th2;
        }
        String tmpFileName = zipFile;
        if (zipFile.indexOf(System.getProperty("file.separator")) >= 0) {
            tmpFileName = zipFile.substring(zipFile.lastIndexOf(System.getProperty("file.separator")));
        }
        if (tmpFileName.indexOf(".") > 0) {
            tmpFileName = tmpFileName.substring(0, tmpFileName.lastIndexOf("."));
        }
        return tmpFileName;
    }

    public static byte[] convertCharset(String str) throws ZipException {
        Throwable th;
        byte[] converted;
        String str2 = str;
        try {
            byte[] bArr = null;
            String charSet = detectCharSet(str2);
            if (charSet.equals(InternalZipConstants.CHARSET_CP850)) {
                converted = str2.getBytes(InternalZipConstants.CHARSET_CP850);
            } else if (charSet.equals(InternalZipConstants.CHARSET_UTF8)) {
                converted = str2.getBytes(InternalZipConstants.CHARSET_UTF8);
            } else {
                converted = str2.getBytes();
            }
            return converted;
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException unsupportedEncodingException = e;
            return str2.getBytes();
        } catch (Exception e2) {
            Exception e3 = e2;
            Throwable th2 = th;
            new ZipException((Throwable) e3);
            throw th2;
        }
    }

    public static String decodeFileName(byte[] bArr, boolean isUTF8) {
        String str;
        String str2;
        byte[] data = bArr;
        if (!isUTF8) {
            return getCp850EncodedString(data);
        }
        try {
            String str3 = str2;
            new String(data, InternalZipConstants.CHARSET_UTF8);
            return str3;
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException unsupportedEncodingException = e;
            new String(data);
            return str;
        }
    }

    public static String getCp850EncodedString(byte[] bArr) {
        String str;
        String str2;
        byte[] data = bArr;
        try {
            String retString = str2;
            new String(data, InternalZipConstants.CHARSET_CP850);
            return retString;
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException unsupportedEncodingException = e;
            new String(data);
            return str;
        }
    }

    public static String getAbsoluteFilePath(String str) throws ZipException {
        File file;
        Throwable th;
        String filePath = str;
        if (!isStringNotNullAndNotEmpty(filePath)) {
            Throwable th2 = th;
            new ZipException("filePath is null or empty, cannot get absolute file path");
            throw th2;
        }
        new File(filePath);
        return file.getAbsolutePath();
    }

    public static boolean checkArrayListTypes(ArrayList arrayList, int i) throws ZipException {
        boolean z;
        Throwable th;
        ArrayList sourceList = arrayList;
        int type = i;
        if (sourceList == null) {
            Throwable th2 = th;
            new ZipException("input arraylist is null, cannot check types");
            throw th2;
        } else if (sourceList.size() <= 0) {
            return true;
        } else {
            boolean invalidFound = false;
            switch (type) {
                case 1:
                    int i2 = 0;
                    while (true) {
                        if (i2 >= sourceList.size()) {
                            break;
                        } else if (!(sourceList.get(i2) instanceof File)) {
                            invalidFound = true;
                            break;
                        } else {
                            i2++;
                        }
                    }
                case 2:
                    int i3 = 0;
                    while (true) {
                        if (i3 >= sourceList.size()) {
                            break;
                        } else if (!(sourceList.get(i3) instanceof String)) {
                            invalidFound = true;
                            break;
                        } else {
                            i3++;
                        }
                    }
            }
            if (invalidFound) {
                z = false;
            } else {
                z = true;
            }
            return z;
        }
    }

    public static String detectCharSet(String str) throws ZipException {
        Object obj;
        Object obj2;
        Throwable th;
        String str2 = str;
        if (str2 == null) {
            Throwable th2 = th;
            new ZipException("input string is null, cannot detect charset");
            throw th2;
        }
        try {
            new String(str2.getBytes(InternalZipConstants.CHARSET_CP850), InternalZipConstants.CHARSET_CP850);
            if (str2.equals(obj)) {
                return InternalZipConstants.CHARSET_CP850;
            }
            new String(str2.getBytes(InternalZipConstants.CHARSET_UTF8), InternalZipConstants.CHARSET_UTF8);
            return str2.equals(obj2) ? InternalZipConstants.CHARSET_UTF8 : InternalZipConstants.CHARSET_DEFAULT;
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException unsupportedEncodingException = e;
            return InternalZipConstants.CHARSET_DEFAULT;
        } catch (Exception e2) {
            Exception exc = e2;
            return InternalZipConstants.CHARSET_DEFAULT;
        }
    }

    public static int getEncodedStringLength(String str) throws ZipException {
        Throwable th;
        String str2 = str;
        if (!isStringNotNullAndNotEmpty(str2)) {
            Throwable th2 = th;
            new ZipException("input string is null, cannot calculate encoded String length");
            throw th2;
        }
        return getEncodedStringLength(str2, detectCharSet(str2));
    }

    public static int getEncodedStringLength(String str, String str2) throws ZipException {
        Throwable th;
        ByteBuffer byteBuffer;
        Throwable th2;
        Throwable th3;
        String str3 = str;
        String charset = str2;
        if (!isStringNotNullAndNotEmpty(str3)) {
            Throwable th4 = th3;
            new ZipException("input string is null, cannot calculate encoded String length");
            throw th4;
        } else if (!isStringNotNullAndNotEmpty(charset)) {
            Throwable th5 = th2;
            new ZipException("encoding is not defined, cannot calculate string length");
            throw th5;
        } else {
            try {
                if (charset.equals(InternalZipConstants.CHARSET_CP850)) {
                    byteBuffer = ByteBuffer.wrap(str3.getBytes(InternalZipConstants.CHARSET_CP850));
                } else if (charset.equals(InternalZipConstants.CHARSET_UTF8)) {
                    byteBuffer = ByteBuffer.wrap(str3.getBytes(InternalZipConstants.CHARSET_UTF8));
                } else {
                    byteBuffer = ByteBuffer.wrap(str3.getBytes(charset));
                }
            } catch (UnsupportedEncodingException e) {
                UnsupportedEncodingException unsupportedEncodingException = e;
                byteBuffer = ByteBuffer.wrap(str3.getBytes());
            } catch (Exception e2) {
                Exception e3 = e2;
                Throwable th6 = th;
                new ZipException((Throwable) e3);
                throw th6;
            }
            return byteBuffer.limit();
        }
    }

    public static boolean isSupportedCharset(String str) throws ZipException {
        Throwable th;
        Throwable th2;
        String charset = str;
        if (!isStringNotNullAndNotEmpty(charset)) {
            Throwable th3 = th2;
            new ZipException("charset is null or empty, cannot check if it is supported");
            throw th3;
        }
        try {
            new String("a".getBytes(), charset);
            return true;
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException unsupportedEncodingException = e;
            return false;
        } catch (Exception e2) {
            Exception e3 = e2;
            Throwable th4 = th;
            new ZipException((Throwable) e3);
            throw th4;
        }
    }

    public static ArrayList getSplitZipFiles(ZipModel zipModel) throws ZipException {
        ArrayList arrayList;
        File file;
        StringBuffer stringBuffer;
        Throwable th;
        Throwable th2;
        ZipModel zipModel2 = zipModel;
        if (zipModel2 == null) {
            Throwable th3 = th2;
            new ZipException("cannot get split zip files: zipmodel is null");
            throw th3;
        } else if (zipModel2.getEndCentralDirRecord() == null) {
            return null;
        } else {
            new ArrayList();
            ArrayList retList = arrayList;
            String currZipFile = zipModel2.getZipFile();
            new File(currZipFile);
            String zipFileName = file.getName();
            if (!isStringNotNullAndNotEmpty(currZipFile)) {
                Throwable th4 = th;
                new ZipException("cannot get split zip files: zipfile is null");
                throw th4;
            } else if (!zipModel2.isSplitArchive()) {
                boolean add = retList.add(currZipFile);
                return retList;
            } else {
                int numberOfThisDisk = zipModel2.getEndCentralDirRecord().getNoOfThisDisk();
                if (numberOfThisDisk == 0) {
                    boolean add2 = retList.add(currZipFile);
                    return retList;
                }
                for (int i = 0; i <= numberOfThisDisk; i++) {
                    if (i == numberOfThisDisk) {
                        boolean add3 = retList.add(zipModel2.getZipFile());
                    } else {
                        String fileExt = ".z0";
                        if (i > 9) {
                            fileExt = ".z";
                        }
                        new StringBuffer(String.valueOf(zipFileName.indexOf(".") >= 0 ? currZipFile.substring(0, currZipFile.lastIndexOf(".")) : currZipFile));
                        boolean add4 = retList.add(stringBuffer.append(fileExt).append(i + 1).toString());
                    }
                }
                return retList;
            }
        }
    }

    public static String getRelativeFileName(String str, String str2, String str3) throws ZipException {
        File file;
        File file2;
        String fileName;
        StringBuffer stringBuffer;
        Throwable th;
        StringBuffer stringBuffer2;
        File rootFolderFile;
        File file3;
        StringBuffer stringBuffer3;
        String tmpFileName;
        StringBuffer stringBuffer4;
        StringBuffer stringBuffer5;
        Throwable th2;
        String file4 = str;
        String rootFolderInZip = str2;
        String rootFolderPath = str3;
        if (!isStringNotNullAndNotEmpty(file4)) {
            Throwable th3 = th2;
            new ZipException("input file path/name is empty, cannot calculate relative file name");
            throw th3;
        }
        if (isStringNotNullAndNotEmpty(rootFolderPath)) {
            new File(rootFolderPath);
            String rootFolderFileRef = rootFolderFile.getPath();
            if (!rootFolderFileRef.endsWith(InternalZipConstants.FILE_SEPARATOR)) {
                new StringBuffer(String.valueOf(rootFolderFileRef));
                rootFolderFileRef = stringBuffer5.append(InternalZipConstants.FILE_SEPARATOR).toString();
            }
            String tmpFileName2 = file4.substring(rootFolderFileRef.length());
            if (tmpFileName2.startsWith(System.getProperty("file.separator"))) {
                tmpFileName2 = tmpFileName2.substring(1);
            }
            new File(file4);
            File tmpFile = file3;
            if (tmpFile.isDirectory()) {
                new StringBuffer(String.valueOf(tmpFileName2.replaceAll("\\\\", InternalZipConstants.ZIP_FILE_SEPARATOR)));
                tmpFileName = stringBuffer4.append(InternalZipConstants.ZIP_FILE_SEPARATOR).toString();
            } else {
                new StringBuffer(String.valueOf(tmpFileName2.substring(0, tmpFileName2.lastIndexOf(tmpFile.getName())).replaceAll("\\\\", InternalZipConstants.ZIP_FILE_SEPARATOR)));
                tmpFileName = stringBuffer3.append(tmpFile.getName()).toString();
            }
            fileName = tmpFileName;
        } else {
            new File(file4);
            File relFile = file;
            if (relFile.isDirectory()) {
                new StringBuffer(String.valueOf(relFile.getName()));
                fileName = stringBuffer.append(InternalZipConstants.ZIP_FILE_SEPARATOR).toString();
            } else {
                new File(file4);
                fileName = getFileNameFromFilePath(file2);
            }
        }
        if (isStringNotNullAndNotEmpty(rootFolderInZip)) {
            new StringBuffer(String.valueOf(rootFolderInZip));
            fileName = stringBuffer2.append(fileName).toString();
        }
        if (isStringNotNullAndNotEmpty(fileName)) {
            return fileName;
        }
        Throwable th4 = th;
        new ZipException("Error determining file name");
        throw th4;
    }

    public static long[] getAllHeaderSignatures() {
        return new long[]{67324752, 134695760, 33639248, 101010256, 84233040, 134630224, 134695760, 117853008, 101075792, 1, 39169};
    }
}
