package net.lingala.zip4j.util;

import java.io.DataInput;
import java.io.IOException;
import net.lingala.zip4j.exception.ZipException;

public class Raw {
    public Raw() {
    }

    public static long readLongLittleEndian(byte[] bArr, int i) {
        byte[] array = bArr;
        int pos = i;
        return ((((((((((((((0 | ((long) (array[pos + 7] & 255))) << 8) | ((long) (array[pos + 6] & 255))) << 8) | ((long) (array[pos + 5] & 255))) << 8) | ((long) (array[pos + 4] & 255))) << 8) | ((long) (array[pos + 3] & 255))) << 8) | ((long) (array[pos + 2] & 255))) << 8) | ((long) (array[pos + 1] & 255))) << 8) | ((long) (array[pos] & 255));
    }

    public static int readLeInt(DataInput di, byte[] bArr) throws ZipException {
        Throwable th;
        byte[] b = bArr;
        try {
            di.readFully(b, 0, 4);
            return (b[0] & 255) | ((b[1] & 255) << 8) | (((b[2] & 255) | ((b[3] & 255) << 8)) << 16);
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th2 = th;
            new ZipException((Throwable) e2);
            throw th2;
        }
    }

    public static int readShortLittleEndian(byte[] bArr, int i) {
        byte[] b = bArr;
        int off = i;
        return (b[off] & 255) | ((b[off + 1] & 255) << 8);
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final short readShortBigEndian(byte[] r7, int r8) {
        /*
            r0 = r7
            r1 = r8
            r3 = 0
            r2 = r3
            r3 = r2
            r4 = r0
            r5 = r1
            byte r4 = r4[r5]
            r5 = 255(0xff, float:3.57E-43)
            r4 = r4 & 255(0xff, float:3.57E-43)
            r3 = r3 | r4
            short r3 = (short) r3
            r2 = r3
            r3 = r2
            r4 = 8
            int r3 = r3 << 8
            short r3 = (short) r3
            r2 = r3
            r3 = r2
            r4 = r0
            r5 = r1
            r6 = 1
            int r5 = r5 + 1
            byte r4 = r4[r5]
            r5 = 255(0xff, float:3.57E-43)
            r4 = r4 & 255(0xff, float:3.57E-43)
            r3 = r3 | r4
            short r3 = (short) r3
            r2 = r3
            r3 = r2
            r0 = r3
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: net.lingala.zip4j.util.Raw.readShortBigEndian(byte[], int):short");
    }

    public static int readIntLittleEndian(byte[] bArr, int i) {
        byte[] b = bArr;
        int off = i;
        return (b[off] & 255) | ((b[off + 1] & 255) << 8) | (((b[off + 2] & 255) | ((b[off + 3] & 255) << 8)) << 16);
    }

    public static byte[] toByteArray(int in, int i) {
        int outSize = i;
        byte[] out = new byte[outSize];
        byte[] intArray = toByteArray(in);
        int i2 = 0;
        while (i2 < intArray.length && i2 < outSize) {
            out[i2] = intArray[i2];
            i2++;
        }
        return out;
    }

    public static byte[] toByteArray(int i) {
        int in = i;
        return new byte[]{(byte) in, (byte) (in >> 8), (byte) (in >> 16), (byte) (in >> 24)};
    }

    public static final void writeShortLittleEndian(byte[] bArr, int i, short s) {
        byte[] array = bArr;
        int pos = i;
        short value = s;
        array[pos + 1] = (byte) (value >>> 8);
        array[pos] = (byte) (value & 255);
    }

    public static final void writeIntLittleEndian(byte[] bArr, int i, int i2) {
        byte[] array = bArr;
        int pos = i;
        int value = i2;
        array[pos + 3] = (byte) (value >>> 24);
        array[pos + 2] = (byte) (value >>> 16);
        array[pos + 1] = (byte) (value >>> 8);
        array[pos] = (byte) (value & 255);
    }

    public static void writeLongLittleEndian(byte[] bArr, int i, long j) {
        byte[] array = bArr;
        int pos = i;
        long value = j;
        array[pos + 7] = (byte) ((int) (value >>> 56));
        array[pos + 6] = (byte) ((int) (value >>> 48));
        array[pos + 5] = (byte) ((int) (value >>> 40));
        array[pos + 4] = (byte) ((int) (value >>> 32));
        array[pos + 3] = (byte) ((int) (value >>> 24));
        array[pos + 2] = (byte) ((int) (value >>> 16));
        array[pos + 1] = (byte) ((int) (value >>> 8));
        array[pos] = (byte) ((int) (value & 255));
    }

    public static byte bitArrayToByte(int[] iArr) throws ZipException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        int[] bitArray = iArr;
        if (bitArray == null) {
            Throwable th4 = th3;
            new ZipException("bit array is null, cannot calculate byte from bits");
            throw th4;
        } else if (bitArray.length != 8) {
            Throwable th5 = th2;
            new ZipException("invalid bit array length, cannot calculate byte");
            throw th5;
        } else if (!checkBits(bitArray)) {
            Throwable th6 = th;
            new ZipException("invalid bits provided, bits contain other values than 0 or 1");
            throw th6;
        } else {
            int retNum = 0;
            for (int i = 0; i < bitArray.length; i++) {
                retNum = (int) (((double) retNum) + (Math.pow(2.0d, (double) i) * ((double) bitArray[i])));
            }
            return (byte) retNum;
        }
    }

    private static boolean checkBits(int[] iArr) {
        int[] bitArray = iArr;
        for (int i = 0; i < bitArray.length; i++) {
            if (bitArray[i] != 0 && bitArray[i] != 1) {
                return false;
            }
        }
        return true;
    }

    public static void prepareBuffAESIVBytes(byte[] bArr, int i, int i2) {
        byte[] buff = bArr;
        int nonce = i;
        int i3 = i2;
        buff[0] = (byte) nonce;
        buff[1] = (byte) (nonce >> 8);
        buff[2] = (byte) (nonce >> 16);
        buff[3] = (byte) (nonce >> 24);
        buff[4] = 0;
        buff[5] = 0;
        buff[6] = 0;
        buff[7] = 0;
        buff[8] = 0;
        buff[9] = 0;
        buff[10] = 0;
        buff[11] = 0;
        buff[12] = 0;
        buff[13] = 0;
        buff[14] = 0;
        buff[15] = 0;
    }

    public static byte[] convertCharArrayToByteArray(char[] cArr) {
        Throwable th;
        char[] charArray = cArr;
        if (charArray == null) {
            Throwable th2 = th;
            new NullPointerException();
            throw th2;
        }
        byte[] bytes = new byte[charArray.length];
        for (int i = 0; i < charArray.length; i++) {
            bytes[i] = (byte) charArray[i];
        }
        return bytes;
    }
}
