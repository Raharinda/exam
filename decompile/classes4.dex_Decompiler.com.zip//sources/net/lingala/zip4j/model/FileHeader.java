package net.lingala.zip4j.model;

import java.util.ArrayList;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.unzip.Unzip;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.Zip4jUtil;

public class FileHeader {
    private AESExtraDataRecord aesExtraDataRecord;
    private long compressedSize;
    private int compressionMethod;
    private long crc32 = 0;
    private byte[] crcBuff;
    private boolean dataDescriptorExists;
    private int diskNumberStart;
    private int encryptionMethod = -1;
    private byte[] externalFileAttr;
    private ArrayList extraDataRecords;
    private int extraFieldLength;
    private String fileComment;
    private int fileCommentLength;
    private String fileName;
    private int fileNameLength;
    private boolean fileNameUTF8Encoded;
    private byte[] generalPurposeFlag;
    private byte[] internalFileAttr;
    private boolean isDirectory;
    private boolean isEncrypted;
    private int lastModFileTime;
    private long offsetLocalHeader;
    private char[] password;
    private int signature;
    private long uncompressedSize = 0;
    private int versionMadeBy;
    private int versionNeededToExtract;
    private Zip64ExtendedInfo zip64ExtendedInfo;

    public FileHeader() {
    }

    public int getSignature() {
        return this.signature;
    }

    public void setSignature(int signature2) {
        int i = signature2;
        this.signature = i;
    }

    public int getVersionMadeBy() {
        return this.versionMadeBy;
    }

    public void setVersionMadeBy(int versionMadeBy2) {
        int i = versionMadeBy2;
        this.versionMadeBy = i;
    }

    public int getVersionNeededToExtract() {
        return this.versionNeededToExtract;
    }

    public void setVersionNeededToExtract(int versionNeededToExtract2) {
        int i = versionNeededToExtract2;
        this.versionNeededToExtract = i;
    }

    public byte[] getGeneralPurposeFlag() {
        return this.generalPurposeFlag;
    }

    public void setGeneralPurposeFlag(byte[] generalPurposeFlag2) {
        byte[] bArr = generalPurposeFlag2;
        this.generalPurposeFlag = bArr;
    }

    public int getCompressionMethod() {
        return this.compressionMethod;
    }

    public void setCompressionMethod(int compressionMethod2) {
        int i = compressionMethod2;
        this.compressionMethod = i;
    }

    public int getLastModFileTime() {
        return this.lastModFileTime;
    }

    public void setLastModFileTime(int lastModFileTime2) {
        int i = lastModFileTime2;
        this.lastModFileTime = i;
    }

    public long getCrc32() {
        return this.crc32 & InternalZipConstants.ZIP_64_LIMIT;
    }

    public void setCrc32(long crc322) {
        long j = crc322;
        this.crc32 = j;
    }

    public long getCompressedSize() {
        return this.compressedSize;
    }

    public void setCompressedSize(long compressedSize2) {
        long j = compressedSize2;
        this.compressedSize = j;
    }

    public long getUncompressedSize() {
        return this.uncompressedSize;
    }

    public void setUncompressedSize(long uncompressedSize2) {
        long j = uncompressedSize2;
        this.uncompressedSize = j;
    }

    public int getFileNameLength() {
        return this.fileNameLength;
    }

    public void setFileNameLength(int fileNameLength2) {
        int i = fileNameLength2;
        this.fileNameLength = i;
    }

    public int getExtraFieldLength() {
        return this.extraFieldLength;
    }

    public void setExtraFieldLength(int extraFieldLength2) {
        int i = extraFieldLength2;
        this.extraFieldLength = i;
    }

    public int getFileCommentLength() {
        return this.fileCommentLength;
    }

    public void setFileCommentLength(int fileCommentLength2) {
        int i = fileCommentLength2;
        this.fileCommentLength = i;
    }

    public int getDiskNumberStart() {
        return this.diskNumberStart;
    }

    public void setDiskNumberStart(int diskNumberStart2) {
        int i = diskNumberStart2;
        this.diskNumberStart = i;
    }

    public byte[] getInternalFileAttr() {
        return this.internalFileAttr;
    }

    public void setInternalFileAttr(byte[] internalFileAttr2) {
        byte[] bArr = internalFileAttr2;
        this.internalFileAttr = bArr;
    }

    public byte[] getExternalFileAttr() {
        return this.externalFileAttr;
    }

    public void setExternalFileAttr(byte[] externalFileAttr2) {
        byte[] bArr = externalFileAttr2;
        this.externalFileAttr = bArr;
    }

    public long getOffsetLocalHeader() {
        return this.offsetLocalHeader;
    }

    public void setOffsetLocalHeader(long offsetLocalHeader2) {
        long j = offsetLocalHeader2;
        this.offsetLocalHeader = j;
    }

    public String getFileName() {
        return this.fileName;
    }

    public void setFileName(String fileName2) {
        String str = fileName2;
        this.fileName = str;
    }

    public String getFileComment() {
        return this.fileComment;
    }

    public void setFileComment(String fileComment2) {
        String str = fileComment2;
        this.fileComment = str;
    }

    public boolean isDirectory() {
        return this.isDirectory;
    }

    public void setDirectory(boolean isDirectory2) {
        boolean z = isDirectory2;
        this.isDirectory = z;
    }

    public void extractFile(ZipModel zipModel, String outPath, ProgressMonitor progressMonitor, boolean runInThread) throws ZipException {
        extractFile(zipModel, outPath, (UnzipParameters) null, progressMonitor, runInThread);
    }

    public void extractFile(ZipModel zipModel, String outPath, UnzipParameters unzipParameters, ProgressMonitor progressMonitor, boolean runInThread) throws ZipException {
        extractFile(zipModel, outPath, unzipParameters, (String) null, progressMonitor, runInThread);
    }

    public void extractFile(ZipModel zipModel, String str, UnzipParameters unzipParameters, String str2, ProgressMonitor progressMonitor, boolean z) throws ZipException {
        Unzip unzip;
        Throwable th;
        Throwable th2;
        Throwable th3;
        ZipModel zipModel2 = zipModel;
        String outPath = str;
        UnzipParameters unzipParameters2 = unzipParameters;
        String newFileName = str2;
        ProgressMonitor progressMonitor2 = progressMonitor;
        boolean runInThread = z;
        if (zipModel2 == null) {
            Throwable th4 = th3;
            new ZipException("input zipModel is null");
            throw th4;
        } else if (!Zip4jUtil.checkOutputFolder(outPath)) {
            Throwable th5 = th2;
            new ZipException("Invalid output path");
            throw th5;
        } else if (this == null) {
            Throwable th6 = th;
            new ZipException("invalid file header");
            throw th6;
        } else {
            new Unzip(zipModel2);
            unzip.extractFile(this, outPath, unzipParameters2, newFileName, progressMonitor2, runInThread);
        }
    }

    public boolean isEncrypted() {
        return this.isEncrypted;
    }

    public void setEncrypted(boolean isEncrypted2) {
        boolean z = isEncrypted2;
        this.isEncrypted = z;
    }

    public int getEncryptionMethod() {
        return this.encryptionMethod;
    }

    public void setEncryptionMethod(int encryptionMethod2) {
        int i = encryptionMethod2;
        this.encryptionMethod = i;
    }

    public char[] getPassword() {
        return this.password;
    }

    public void setPassword(char[] password2) {
        char[] cArr = password2;
        this.password = cArr;
    }

    public byte[] getCrcBuff() {
        return this.crcBuff;
    }

    public void setCrcBuff(byte[] crcBuff2) {
        byte[] bArr = crcBuff2;
        this.crcBuff = bArr;
    }

    public ArrayList getExtraDataRecords() {
        return this.extraDataRecords;
    }

    public void setExtraDataRecords(ArrayList extraDataRecords2) {
        ArrayList arrayList = extraDataRecords2;
        this.extraDataRecords = arrayList;
    }

    public boolean isDataDescriptorExists() {
        return this.dataDescriptorExists;
    }

    public void setDataDescriptorExists(boolean dataDescriptorExists2) {
        boolean z = dataDescriptorExists2;
        this.dataDescriptorExists = z;
    }

    public Zip64ExtendedInfo getZip64ExtendedInfo() {
        return this.zip64ExtendedInfo;
    }

    public void setZip64ExtendedInfo(Zip64ExtendedInfo zip64ExtendedInfo2) {
        Zip64ExtendedInfo zip64ExtendedInfo3 = zip64ExtendedInfo2;
        this.zip64ExtendedInfo = zip64ExtendedInfo3;
    }

    public AESExtraDataRecord getAesExtraDataRecord() {
        return this.aesExtraDataRecord;
    }

    public void setAesExtraDataRecord(AESExtraDataRecord aesExtraDataRecord2) {
        AESExtraDataRecord aESExtraDataRecord = aesExtraDataRecord2;
        this.aesExtraDataRecord = aESExtraDataRecord;
    }

    public boolean isFileNameUTF8Encoded() {
        return this.fileNameUTF8Encoded;
    }

    public void setFileNameUTF8Encoded(boolean fileNameUTF8Encoded2) {
        boolean z = fileNameUTF8Encoded2;
        this.fileNameUTF8Encoded = z;
    }
}
