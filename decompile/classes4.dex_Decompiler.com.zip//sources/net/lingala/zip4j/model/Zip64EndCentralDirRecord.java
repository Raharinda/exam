package net.lingala.zip4j.model;

public class Zip64EndCentralDirRecord {
    private byte[] extensibleDataSector;
    private int noOfThisDisk;
    private int noOfThisDiskStartOfCentralDir;
    private long offsetStartCenDirWRTStartDiskNo;
    private long signature;
    private long sizeOfCentralDir;
    private long sizeOfZip64EndCentralDirRec;
    private long totNoOfEntriesInCentralDir;
    private long totNoOfEntriesInCentralDirOnThisDisk;
    private int versionMadeBy;
    private int versionNeededToExtract;

    public Zip64EndCentralDirRecord() {
    }

    public long getSignature() {
        return this.signature;
    }

    public void setSignature(long signature2) {
        long j = signature2;
        this.signature = j;
    }

    public long getSizeOfZip64EndCentralDirRec() {
        return this.sizeOfZip64EndCentralDirRec;
    }

    public void setSizeOfZip64EndCentralDirRec(long sizeOfZip64EndCentralDirRec2) {
        long j = sizeOfZip64EndCentralDirRec2;
        this.sizeOfZip64EndCentralDirRec = j;
    }

    public int getVersionMadeBy() {
        return this.versionMadeBy;
    }

    public void setVersionMadeBy(int versionMadeBy2) {
        int i = versionMadeBy2;
        this.versionMadeBy = i;
    }

    public int getVersionNeededToExtract() {
        return this.versionNeededToExtract;
    }

    public void setVersionNeededToExtract(int versionNeededToExtract2) {
        int i = versionNeededToExtract2;
        this.versionNeededToExtract = i;
    }

    public int getNoOfThisDisk() {
        return this.noOfThisDisk;
    }

    public void setNoOfThisDisk(int noOfThisDisk2) {
        int i = noOfThisDisk2;
        this.noOfThisDisk = i;
    }

    public int getNoOfThisDiskStartOfCentralDir() {
        return this.noOfThisDiskStartOfCentralDir;
    }

    public void setNoOfThisDiskStartOfCentralDir(int noOfThisDiskStartOfCentralDir2) {
        int i = noOfThisDiskStartOfCentralDir2;
        this.noOfThisDiskStartOfCentralDir = i;
    }

    public long getTotNoOfEntriesInCentralDirOnThisDisk() {
        return this.totNoOfEntriesInCentralDirOnThisDisk;
    }

    public void setTotNoOfEntriesInCentralDirOnThisDisk(long totNoOfEntriesInCentralDirOnThisDisk2) {
        long j = totNoOfEntriesInCentralDirOnThisDisk2;
        this.totNoOfEntriesInCentralDirOnThisDisk = j;
    }

    public long getTotNoOfEntriesInCentralDir() {
        return this.totNoOfEntriesInCentralDir;
    }

    public void setTotNoOfEntriesInCentralDir(long totNoOfEntriesInCentralDir2) {
        long j = totNoOfEntriesInCentralDir2;
        this.totNoOfEntriesInCentralDir = j;
    }

    public long getSizeOfCentralDir() {
        return this.sizeOfCentralDir;
    }

    public void setSizeOfCentralDir(long sizeOfCentralDir2) {
        long j = sizeOfCentralDir2;
        this.sizeOfCentralDir = j;
    }

    public long getOffsetStartCenDirWRTStartDiskNo() {
        return this.offsetStartCenDirWRTStartDiskNo;
    }

    public void setOffsetStartCenDirWRTStartDiskNo(long offsetStartCenDirWRTStartDiskNo2) {
        long j = offsetStartCenDirWRTStartDiskNo2;
        this.offsetStartCenDirWRTStartDiskNo = j;
    }

    public byte[] getExtensibleDataSector() {
        return this.extensibleDataSector;
    }

    public void setExtensibleDataSector(byte[] extensibleDataSector2) {
        byte[] bArr = extensibleDataSector2;
        this.extensibleDataSector = bArr;
    }
}
