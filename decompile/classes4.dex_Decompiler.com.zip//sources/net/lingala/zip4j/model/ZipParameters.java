package net.lingala.zip4j.model;

import java.util.TimeZone;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.Zip4jUtil;

public class ZipParameters implements Cloneable {
    private int aesKeyStrength = -1;
    private int compressionLevel;
    private int compressionMethod = 8;
    private String defaultFolderPath;
    private boolean encryptFiles = false;
    private int encryptionMethod = -1;
    private String fileNameInZip;
    private boolean includeRootFolder = true;
    private boolean isSourceExternalStream;
    private char[] password;
    private boolean readHiddenFiles = true;
    private String rootFolderInZip;
    private int sourceFileCRC;
    private TimeZone timeZone = TimeZone.getDefault();

    public ZipParameters() {
    }

    public int getCompressionMethod() {
        return this.compressionMethod;
    }

    public void setCompressionMethod(int compressionMethod2) {
        int i = compressionMethod2;
        this.compressionMethod = i;
    }

    public boolean isEncryptFiles() {
        return this.encryptFiles;
    }

    public void setEncryptFiles(boolean encryptFiles2) {
        boolean z = encryptFiles2;
        this.encryptFiles = z;
    }

    public int getEncryptionMethod() {
        return this.encryptionMethod;
    }

    public void setEncryptionMethod(int encryptionMethod2) {
        int i = encryptionMethod2;
        this.encryptionMethod = i;
    }

    public int getCompressionLevel() {
        return this.compressionLevel;
    }

    public void setCompressionLevel(int compressionLevel2) {
        int i = compressionLevel2;
        this.compressionLevel = i;
    }

    public boolean isReadHiddenFiles() {
        return this.readHiddenFiles;
    }

    public void setReadHiddenFiles(boolean readHiddenFiles2) {
        boolean z = readHiddenFiles2;
        this.readHiddenFiles = z;
    }

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public char[] getPassword() {
        return this.password;
    }

    public void setPassword(String str) {
        String password2 = str;
        if (password2 != null) {
            setPassword(password2.toCharArray());
        }
    }

    public void setPassword(char[] password2) {
        char[] cArr = password2;
        this.password = cArr;
    }

    public int getAesKeyStrength() {
        return this.aesKeyStrength;
    }

    public void setAesKeyStrength(int aesKeyStrength2) {
        int i = aesKeyStrength2;
        this.aesKeyStrength = i;
    }

    public boolean isIncludeRootFolder() {
        return this.includeRootFolder;
    }

    public void setIncludeRootFolder(boolean includeRootFolder2) {
        boolean z = includeRootFolder2;
        this.includeRootFolder = z;
    }

    public String getRootFolderInZip() {
        return this.rootFolderInZip;
    }

    public void setRootFolderInZip(String str) {
        StringBuffer stringBuffer;
        String rootFolderInZip2 = str;
        if (Zip4jUtil.isStringNotNullAndNotEmpty(rootFolderInZip2)) {
            if (!rootFolderInZip2.endsWith("\\") && !rootFolderInZip2.endsWith(InternalZipConstants.ZIP_FILE_SEPARATOR)) {
                new StringBuffer(String.valueOf(rootFolderInZip2));
                rootFolderInZip2 = stringBuffer.append(InternalZipConstants.FILE_SEPARATOR).toString();
            }
            rootFolderInZip2 = rootFolderInZip2.replaceAll("\\\\", InternalZipConstants.ZIP_FILE_SEPARATOR);
        }
        this.rootFolderInZip = rootFolderInZip2;
    }

    public TimeZone getTimeZone() {
        return this.timeZone;
    }

    public void setTimeZone(TimeZone timeZone2) {
        TimeZone timeZone3 = timeZone2;
        this.timeZone = timeZone3;
    }

    public int getSourceFileCRC() {
        return this.sourceFileCRC;
    }

    public void setSourceFileCRC(int sourceFileCRC2) {
        int i = sourceFileCRC2;
        this.sourceFileCRC = i;
    }

    public String getDefaultFolderPath() {
        return this.defaultFolderPath;
    }

    public void setDefaultFolderPath(String defaultFolderPath2) {
        String str = defaultFolderPath2;
        this.defaultFolderPath = str;
    }

    public String getFileNameInZip() {
        return this.fileNameInZip;
    }

    public void setFileNameInZip(String fileNameInZip2) {
        String str = fileNameInZip2;
        this.fileNameInZip = str;
    }

    public boolean isSourceExternalStream() {
        return this.isSourceExternalStream;
    }

    public void setSourceExternalStream(boolean isSourceExternalStream2) {
        boolean z = isSourceExternalStream2;
        this.isSourceExternalStream = z;
    }
}
