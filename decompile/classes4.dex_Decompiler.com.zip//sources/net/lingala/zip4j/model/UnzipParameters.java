package net.lingala.zip4j.model;

public class UnzipParameters {
    private boolean ignoreAllFileAttributes;
    private boolean ignoreArchiveFileAttribute;
    private boolean ignoreDateTimeAttributes;
    private boolean ignoreHiddenFileAttribute;
    private boolean ignoreReadOnlyFileAttribute;
    private boolean ignoreSystemFileAttribute;

    public UnzipParameters() {
    }

    public boolean isIgnoreReadOnlyFileAttribute() {
        return this.ignoreReadOnlyFileAttribute;
    }

    public void setIgnoreReadOnlyFileAttribute(boolean ignoreReadOnlyFileAttribute2) {
        boolean z = ignoreReadOnlyFileAttribute2;
        this.ignoreReadOnlyFileAttribute = z;
    }

    public boolean isIgnoreHiddenFileAttribute() {
        return this.ignoreHiddenFileAttribute;
    }

    public void setIgnoreHiddenFileAttribute(boolean ignoreHiddenFileAttribute2) {
        boolean z = ignoreHiddenFileAttribute2;
        this.ignoreHiddenFileAttribute = z;
    }

    public boolean isIgnoreArchiveFileAttribute() {
        return this.ignoreArchiveFileAttribute;
    }

    public void setIgnoreArchiveFileAttribute(boolean ignoreArchiveFileAttribute2) {
        boolean z = ignoreArchiveFileAttribute2;
        this.ignoreArchiveFileAttribute = z;
    }

    public boolean isIgnoreSystemFileAttribute() {
        return this.ignoreSystemFileAttribute;
    }

    public void setIgnoreSystemFileAttribute(boolean ignoreSystemFileAttribute2) {
        boolean z = ignoreSystemFileAttribute2;
        this.ignoreSystemFileAttribute = z;
    }

    public boolean isIgnoreAllFileAttributes() {
        return this.ignoreAllFileAttributes;
    }

    public void setIgnoreAllFileAttributes(boolean ignoreAllFileAttributes2) {
        boolean z = ignoreAllFileAttributes2;
        this.ignoreAllFileAttributes = z;
    }

    public boolean isIgnoreDateTimeAttributes() {
        return this.ignoreDateTimeAttributes;
    }

    public void setIgnoreDateTimeAttributes(boolean ignoreDateTimeAttributes2) {
        boolean z = ignoreDateTimeAttributes2;
        this.ignoreDateTimeAttributes = z;
    }
}
