package net.lingala.zip4j.model;

public class AESExtraDataRecord {
    private int aesStrength = -1;
    private int compressionMethod = -1;
    private int dataSize = -1;
    private long signature = -1;
    private String vendorID = null;
    private int versionNumber = -1;

    public AESExtraDataRecord() {
    }

    public long getSignature() {
        return this.signature;
    }

    public void setSignature(long signature2) {
        long j = signature2;
        this.signature = j;
    }

    public int getDataSize() {
        return this.dataSize;
    }

    public void setDataSize(int dataSize2) {
        int i = dataSize2;
        this.dataSize = i;
    }

    public int getVersionNumber() {
        return this.versionNumber;
    }

    public void setVersionNumber(int versionNumber2) {
        int i = versionNumber2;
        this.versionNumber = i;
    }

    public String getVendorID() {
        return this.vendorID;
    }

    public void setVendorID(String vendorID2) {
        String str = vendorID2;
        this.vendorID = str;
    }

    public int getAesStrength() {
        return this.aesStrength;
    }

    public void setAesStrength(int aesStrength2) {
        int i = aesStrength2;
        this.aesStrength = i;
    }

    public int getCompressionMethod() {
        return this.compressionMethod;
    }

    public void setCompressionMethod(int compressionMethod2) {
        int i = compressionMethod2;
        this.compressionMethod = i;
    }
}
