package net.lingala.zip4j.model;

public class ExtraDataRecord {
    private byte[] data;
    private long header;
    private int sizeOfData;

    public ExtraDataRecord() {
    }

    public long getHeader() {
        return this.header;
    }

    public void setHeader(long header2) {
        long j = header2;
        this.header = j;
    }

    public int getSizeOfData() {
        return this.sizeOfData;
    }

    public void setSizeOfData(int sizeOfData2) {
        int i = sizeOfData2;
        this.sizeOfData = i;
    }

    public byte[] getData() {
        return this.data;
    }

    public void setData(byte[] data2) {
        byte[] bArr = data2;
        this.data = bArr;
    }
}
