package net.lingala.zip4j.model;

public class DigitalSignature {
    private int headerSignature;
    private String signatureData;
    private int sizeOfData;

    public DigitalSignature() {
    }

    public int getHeaderSignature() {
        return this.headerSignature;
    }

    public void setHeaderSignature(int headerSignature2) {
        int i = headerSignature2;
        this.headerSignature = i;
    }

    public int getSizeOfData() {
        return this.sizeOfData;
    }

    public void setSizeOfData(int sizeOfData2) {
        int i = sizeOfData2;
        this.sizeOfData = i;
    }

    public String getSignatureData() {
        return this.signatureData;
    }

    public void setSignatureData(String signatureData2) {
        String str = signatureData2;
        this.signatureData = str;
    }
}
