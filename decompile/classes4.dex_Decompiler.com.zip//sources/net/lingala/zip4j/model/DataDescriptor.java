package net.lingala.zip4j.model;

public class DataDescriptor {
    private int compressedSize;
    private String crc32;
    private int uncompressedSize;

    public DataDescriptor() {
    }

    public String getCrc32() {
        return this.crc32;
    }

    public void setCrc32(String crc322) {
        String str = crc322;
        this.crc32 = str;
    }

    public int getCompressedSize() {
        return this.compressedSize;
    }

    public void setCompressedSize(int compressedSize2) {
        int i = compressedSize2;
        this.compressedSize = i;
    }

    public int getUncompressedSize() {
        return this.uncompressedSize;
    }

    public void setUncompressedSize(int uncompressedSize2) {
        int i = uncompressedSize2;
        this.uncompressedSize = i;
    }
}
