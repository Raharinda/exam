package net.lingala.zip4j.model;

public class EndCentralDirRecord {
    private String comment;
    private byte[] commentBytes;
    private int commentLength;
    private int noOfThisDisk;
    private int noOfThisDiskStartOfCentralDir;
    private long offsetOfStartOfCentralDir;
    private long signature;
    private int sizeOfCentralDir;
    private int totNoOfEntriesInCentralDir;
    private int totNoOfEntriesInCentralDirOnThisDisk;

    public EndCentralDirRecord() {
    }

    public long getSignature() {
        return this.signature;
    }

    public void setSignature(long signature2) {
        long j = signature2;
        this.signature = j;
    }

    public int getNoOfThisDisk() {
        return this.noOfThisDisk;
    }

    public void setNoOfThisDisk(int noOfThisDisk2) {
        int i = noOfThisDisk2;
        this.noOfThisDisk = i;
    }

    public int getNoOfThisDiskStartOfCentralDir() {
        return this.noOfThisDiskStartOfCentralDir;
    }

    public void setNoOfThisDiskStartOfCentralDir(int noOfThisDiskStartOfCentralDir2) {
        int i = noOfThisDiskStartOfCentralDir2;
        this.noOfThisDiskStartOfCentralDir = i;
    }

    public int getTotNoOfEntriesInCentralDirOnThisDisk() {
        return this.totNoOfEntriesInCentralDirOnThisDisk;
    }

    public void setTotNoOfEntriesInCentralDirOnThisDisk(int totNoOfEntriesInCentralDirOnThisDisk2) {
        int i = totNoOfEntriesInCentralDirOnThisDisk2;
        this.totNoOfEntriesInCentralDirOnThisDisk = i;
    }

    public int getTotNoOfEntriesInCentralDir() {
        return this.totNoOfEntriesInCentralDir;
    }

    public void setTotNoOfEntriesInCentralDir(int totNoOfEntrisInCentralDir) {
        int i = totNoOfEntrisInCentralDir;
        this.totNoOfEntriesInCentralDir = i;
    }

    public int getSizeOfCentralDir() {
        return this.sizeOfCentralDir;
    }

    public void setSizeOfCentralDir(int sizeOfCentralDir2) {
        int i = sizeOfCentralDir2;
        this.sizeOfCentralDir = i;
    }

    public long getOffsetOfStartOfCentralDir() {
        return this.offsetOfStartOfCentralDir;
    }

    public void setOffsetOfStartOfCentralDir(long offSetOfStartOfCentralDir) {
        long j = offSetOfStartOfCentralDir;
        this.offsetOfStartOfCentralDir = j;
    }

    public int getCommentLength() {
        return this.commentLength;
    }

    public void setCommentLength(int commentLength2) {
        int i = commentLength2;
        this.commentLength = i;
    }

    public String getComment() {
        return this.comment;
    }

    public void setComment(String comment2) {
        String str = comment2;
        this.comment = str;
    }

    public byte[] getCommentBytes() {
        return this.commentBytes;
    }

    public void setCommentBytes(byte[] commentBytes2) {
        byte[] bArr = commentBytes2;
        this.commentBytes = bArr;
    }
}
