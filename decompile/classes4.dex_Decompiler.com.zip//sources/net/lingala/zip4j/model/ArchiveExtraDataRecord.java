package net.lingala.zip4j.model;

public class ArchiveExtraDataRecord {
    private String extraFieldData;
    private int extraFieldLength;
    private int signature;

    public ArchiveExtraDataRecord() {
    }

    public int getSignature() {
        return this.signature;
    }

    public void setSignature(int signature2) {
        int i = signature2;
        this.signature = i;
    }

    public int getExtraFieldLength() {
        return this.extraFieldLength;
    }

    public void setExtraFieldLength(int extraFieldLength2) {
        int i = extraFieldLength2;
        this.extraFieldLength = i;
    }

    public String getExtraFieldData() {
        return this.extraFieldData;
    }

    public void setExtraFieldData(String extraFieldData2) {
        String str = extraFieldData2;
        this.extraFieldData = str;
    }
}
