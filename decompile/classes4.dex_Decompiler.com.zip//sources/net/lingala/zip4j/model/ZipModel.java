package net.lingala.zip4j.model;

import java.util.List;

public class ZipModel implements Cloneable {
    private ArchiveExtraDataRecord archiveExtraDataRecord;
    private CentralDirectory centralDirectory;
    private List dataDescriptorList;
    private long end;
    private EndCentralDirRecord endCentralDirRecord;
    private String fileNameCharset;
    private boolean isNestedZipFile;
    private boolean isZip64Format;
    private List localFileHeaderList;
    private boolean splitArchive;
    private long splitLength = -1;
    private long start;
    private Zip64EndCentralDirLocator zip64EndCentralDirLocator;
    private Zip64EndCentralDirRecord zip64EndCentralDirRecord;
    private String zipFile;

    public ZipModel() {
    }

    public List getLocalFileHeaderList() {
        return this.localFileHeaderList;
    }

    public void setLocalFileHeaderList(List localFileHeaderList2) {
        List list = localFileHeaderList2;
        this.localFileHeaderList = list;
    }

    public List getDataDescriptorList() {
        return this.dataDescriptorList;
    }

    public void setDataDescriptorList(List dataDescriptorList2) {
        List list = dataDescriptorList2;
        this.dataDescriptorList = list;
    }

    public CentralDirectory getCentralDirectory() {
        return this.centralDirectory;
    }

    public void setCentralDirectory(CentralDirectory centralDirectory2) {
        CentralDirectory centralDirectory3 = centralDirectory2;
        this.centralDirectory = centralDirectory3;
    }

    public EndCentralDirRecord getEndCentralDirRecord() {
        return this.endCentralDirRecord;
    }

    public void setEndCentralDirRecord(EndCentralDirRecord endCentralDirRecord2) {
        EndCentralDirRecord endCentralDirRecord3 = endCentralDirRecord2;
        this.endCentralDirRecord = endCentralDirRecord3;
    }

    public ArchiveExtraDataRecord getArchiveExtraDataRecord() {
        return this.archiveExtraDataRecord;
    }

    public void setArchiveExtraDataRecord(ArchiveExtraDataRecord archiveExtraDataRecord2) {
        ArchiveExtraDataRecord archiveExtraDataRecord3 = archiveExtraDataRecord2;
        this.archiveExtraDataRecord = archiveExtraDataRecord3;
    }

    public boolean isSplitArchive() {
        return this.splitArchive;
    }

    public void setSplitArchive(boolean splitArchive2) {
        boolean z = splitArchive2;
        this.splitArchive = z;
    }

    public String getZipFile() {
        return this.zipFile;
    }

    public void setZipFile(String zipFile2) {
        String str = zipFile2;
        this.zipFile = str;
    }

    public Zip64EndCentralDirLocator getZip64EndCentralDirLocator() {
        return this.zip64EndCentralDirLocator;
    }

    public void setZip64EndCentralDirLocator(Zip64EndCentralDirLocator zip64EndCentralDirLocator2) {
        Zip64EndCentralDirLocator zip64EndCentralDirLocator3 = zip64EndCentralDirLocator2;
        this.zip64EndCentralDirLocator = zip64EndCentralDirLocator3;
    }

    public Zip64EndCentralDirRecord getZip64EndCentralDirRecord() {
        return this.zip64EndCentralDirRecord;
    }

    public void setZip64EndCentralDirRecord(Zip64EndCentralDirRecord zip64EndCentralDirRecord2) {
        Zip64EndCentralDirRecord zip64EndCentralDirRecord3 = zip64EndCentralDirRecord2;
        this.zip64EndCentralDirRecord = zip64EndCentralDirRecord3;
    }

    public boolean isZip64Format() {
        return this.isZip64Format;
    }

    public void setZip64Format(boolean isZip64Format2) {
        boolean z = isZip64Format2;
        this.isZip64Format = z;
    }

    public boolean isNestedZipFile() {
        return this.isNestedZipFile;
    }

    public void setNestedZipFile(boolean isNestedZipFile2) {
        boolean z = isNestedZipFile2;
        this.isNestedZipFile = z;
    }

    public long getStart() {
        return this.start;
    }

    public void setStart(long start2) {
        long j = start2;
        this.start = j;
    }

    public long getEnd() {
        return this.end;
    }

    public void setEnd(long end2) {
        long j = end2;
        this.end = j;
    }

    public long getSplitLength() {
        return this.splitLength;
    }

    public void setSplitLength(long splitLength2) {
        long j = splitLength2;
        this.splitLength = j;
    }

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public String getFileNameCharset() {
        return this.fileNameCharset;
    }

    public void setFileNameCharset(String fileNameCharset2) {
        String str = fileNameCharset2;
        this.fileNameCharset = str;
    }
}
