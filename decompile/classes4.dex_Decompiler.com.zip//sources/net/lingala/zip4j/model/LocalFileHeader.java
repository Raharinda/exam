package net.lingala.zip4j.model;

import java.util.ArrayList;

public class LocalFileHeader {
    private AESExtraDataRecord aesExtraDataRecord;
    private long compressedSize;
    private int compressionMethod;
    private long crc32 = 0;
    private byte[] crcBuff;
    private boolean dataDescriptorExists;
    private int encryptionMethod = -1;
    private ArrayList extraDataRecords;
    private byte[] extraField;
    private int extraFieldLength;
    private String fileName;
    private int fileNameLength;
    private boolean fileNameUTF8Encoded;
    private byte[] generalPurposeFlag;
    private boolean isEncrypted;
    private int lastModFileTime;
    private long offsetStartOfData;
    private char[] password;
    private int signature;
    private long uncompressedSize = 0;
    private int versionNeededToExtract;
    private boolean writeComprSizeInZip64ExtraRecord = false;
    private Zip64ExtendedInfo zip64ExtendedInfo;

    public LocalFileHeader() {
    }

    public int getSignature() {
        return this.signature;
    }

    public void setSignature(int signature2) {
        int i = signature2;
        this.signature = i;
    }

    public int getVersionNeededToExtract() {
        return this.versionNeededToExtract;
    }

    public void setVersionNeededToExtract(int versionNeededToExtract2) {
        int i = versionNeededToExtract2;
        this.versionNeededToExtract = i;
    }

    public byte[] getGeneralPurposeFlag() {
        return this.generalPurposeFlag;
    }

    public void setGeneralPurposeFlag(byte[] generalPurposeFlag2) {
        byte[] bArr = generalPurposeFlag2;
        this.generalPurposeFlag = bArr;
    }

    public int getCompressionMethod() {
        return this.compressionMethod;
    }

    public void setCompressionMethod(int compressionMethod2) {
        int i = compressionMethod2;
        this.compressionMethod = i;
    }

    public int getLastModFileTime() {
        return this.lastModFileTime;
    }

    public void setLastModFileTime(int lastModFileTime2) {
        int i = lastModFileTime2;
        this.lastModFileTime = i;
    }

    public long getCrc32() {
        return this.crc32;
    }

    public void setCrc32(long crc322) {
        long j = crc322;
        this.crc32 = j;
    }

    public long getCompressedSize() {
        return this.compressedSize;
    }

    public void setCompressedSize(long compressedSize2) {
        long j = compressedSize2;
        this.compressedSize = j;
    }

    public long getUncompressedSize() {
        return this.uncompressedSize;
    }

    public void setUncompressedSize(long uncompressedSize2) {
        long j = uncompressedSize2;
        this.uncompressedSize = j;
    }

    public int getFileNameLength() {
        return this.fileNameLength;
    }

    public void setFileNameLength(int fileNameLength2) {
        int i = fileNameLength2;
        this.fileNameLength = i;
    }

    public int getExtraFieldLength() {
        return this.extraFieldLength;
    }

    public void setExtraFieldLength(int extraFieldLength2) {
        int i = extraFieldLength2;
        this.extraFieldLength = i;
    }

    public String getFileName() {
        return this.fileName;
    }

    public void setFileName(String fileName2) {
        String str = fileName2;
        this.fileName = str;
    }

    public byte[] getExtraField() {
        return this.extraField;
    }

    public void setExtraField(byte[] extraField2) {
        byte[] bArr = extraField2;
        this.extraField = bArr;
    }

    public long getOffsetStartOfData() {
        return this.offsetStartOfData;
    }

    public void setOffsetStartOfData(long offsetStartOfData2) {
        long j = offsetStartOfData2;
        this.offsetStartOfData = j;
    }

    public boolean isEncrypted() {
        return this.isEncrypted;
    }

    public void setEncrypted(boolean isEncrypted2) {
        boolean z = isEncrypted2;
        this.isEncrypted = z;
    }

    public int getEncryptionMethod() {
        return this.encryptionMethod;
    }

    public void setEncryptionMethod(int encryptionMethod2) {
        int i = encryptionMethod2;
        this.encryptionMethod = i;
    }

    public byte[] getCrcBuff() {
        return this.crcBuff;
    }

    public void setCrcBuff(byte[] crcBuff2) {
        byte[] bArr = crcBuff2;
        this.crcBuff = bArr;
    }

    public char[] getPassword() {
        return this.password;
    }

    public void setPassword(char[] password2) {
        char[] cArr = password2;
        this.password = cArr;
    }

    public ArrayList getExtraDataRecords() {
        return this.extraDataRecords;
    }

    public void setExtraDataRecords(ArrayList extraDataRecords2) {
        ArrayList arrayList = extraDataRecords2;
        this.extraDataRecords = arrayList;
    }

    public boolean isDataDescriptorExists() {
        return this.dataDescriptorExists;
    }

    public void setDataDescriptorExists(boolean dataDescriptorExists2) {
        boolean z = dataDescriptorExists2;
        this.dataDescriptorExists = z;
    }

    public Zip64ExtendedInfo getZip64ExtendedInfo() {
        return this.zip64ExtendedInfo;
    }

    public void setZip64ExtendedInfo(Zip64ExtendedInfo zip64ExtendedInfo2) {
        Zip64ExtendedInfo zip64ExtendedInfo3 = zip64ExtendedInfo2;
        this.zip64ExtendedInfo = zip64ExtendedInfo3;
    }

    public AESExtraDataRecord getAesExtraDataRecord() {
        return this.aesExtraDataRecord;
    }

    public void setAesExtraDataRecord(AESExtraDataRecord aesExtraDataRecord2) {
        AESExtraDataRecord aESExtraDataRecord = aesExtraDataRecord2;
        this.aesExtraDataRecord = aESExtraDataRecord;
    }

    public boolean isWriteComprSizeInZip64ExtraRecord() {
        return this.writeComprSizeInZip64ExtraRecord;
    }

    public void setWriteComprSizeInZip64ExtraRecord(boolean writeComprSizeInZip64ExtraRecord2) {
        boolean z = writeComprSizeInZip64ExtraRecord2;
        this.writeComprSizeInZip64ExtraRecord = z;
    }

    public boolean isFileNameUTF8Encoded() {
        return this.fileNameUTF8Encoded;
    }

    public void setFileNameUTF8Encoded(boolean fileNameUTF8Encoded2) {
        boolean z = fileNameUTF8Encoded2;
        this.fileNameUTF8Encoded = z;
    }
}
