package net.lingala.zip4j.model;

public class Zip64ExtendedInfo {
    private long compressedSize = -1;
    private int diskNumberStart = -1;
    private int header;
    private long offsetLocalHeader = -1;
    private int size;
    private long unCompressedSize = -1;

    public Zip64ExtendedInfo() {
    }

    public int getHeader() {
        return this.header;
    }

    public void setHeader(int header2) {
        int i = header2;
        this.header = i;
    }

    public int getSize() {
        return this.size;
    }

    public void setSize(int size2) {
        int i = size2;
        this.size = i;
    }

    public long getCompressedSize() {
        return this.compressedSize;
    }

    public void setCompressedSize(long compressedSize2) {
        long j = compressedSize2;
        this.compressedSize = j;
    }

    public long getUnCompressedSize() {
        return this.unCompressedSize;
    }

    public void setUnCompressedSize(long unCompressedSize2) {
        long j = unCompressedSize2;
        this.unCompressedSize = j;
    }

    public long getOffsetLocalHeader() {
        return this.offsetLocalHeader;
    }

    public void setOffsetLocalHeader(long offsetLocalHeader2) {
        long j = offsetLocalHeader2;
        this.offsetLocalHeader = j;
    }

    public int getDiskNumberStart() {
        return this.diskNumberStart;
    }

    public void setDiskNumberStart(int diskNumberStart2) {
        int i = diskNumberStart2;
        this.diskNumberStart = i;
    }
}
