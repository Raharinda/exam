package net.lingala.zip4j.io;

import java.io.IOException;
import java.io.OutputStream;
import net.lingala.zip4j.model.ZipModel;

public class ZipOutputStream extends DeflaterOutputStream {
    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public ZipOutputStream(OutputStream outputStream) {
        this(outputStream, (ZipModel) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ZipOutputStream(OutputStream outputStream, ZipModel zipModel) {
        super(outputStream, zipModel);
    }

    public void write(int bval) throws IOException {
        write(new byte[]{(byte) bval}, 0, 1);
    }

    public void write(byte[] bArr) throws IOException {
        byte[] b = bArr;
        write(b, 0, b.length);
    }

    public void write(byte[] bArr, int i, int i2) throws IOException {
        byte[] b = bArr;
        int off = i;
        int len = i2;
        this.crc.update(b, off, len);
        updateTotalBytesRead(len);
        super.write(b, off, len);
    }
}
