package net.lingala.zip4j.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.Raw;
import net.lingala.zip4j.util.Zip4jUtil;

public class SplitOutputStream extends OutputStream {
    private long bytesWrittenForThisPart;
    private int currSplitFileCounter;
    private File outFile;
    private RandomAccessFile raf;
    private long splitLength;
    private File zipFile;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public SplitOutputStream(java.lang.String r8) throws java.io.FileNotFoundException, net.lingala.zip4j.exception.ZipException {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r2 = r0
            r3 = r1
            boolean r3 = net.lingala.zip4j.util.Zip4jUtil.isStringNotNullAndNotEmpty(r3)
            if (r3 == 0) goto L_0x0017
            java.io.File r3 = new java.io.File
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r1
            r4.<init>(r5)
        L_0x0013:
            r2.<init>((java.io.File) r3)
            return
        L_0x0017:
            r3 = 0
            goto L_0x0013
        */
        throw new UnsupportedOperationException("Method not decompiled: net.lingala.zip4j.io.SplitOutputStream.<init>(java.lang.String):void");
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SplitOutputStream(File file) throws FileNotFoundException, ZipException {
        this(file, -1);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public SplitOutputStream(java.lang.String r11, long r12) throws java.io.FileNotFoundException, net.lingala.zip4j.exception.ZipException {
        /*
            r10 = this;
            r0 = r10
            r1 = r11
            r2 = r12
            r4 = r0
            r5 = r1
            boolean r5 = net.lingala.zip4j.util.Zip4jUtil.isStringNotNullAndNotEmpty(r5)
            if (r5 != 0) goto L_0x0019
            java.io.File r5 = new java.io.File
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r1
            r6.<init>(r7)
        L_0x0014:
            r6 = r2
            r4.<init>((java.io.File) r5, (long) r6)
            return
        L_0x0019:
            r5 = 0
            goto L_0x0014
        */
        throw new UnsupportedOperationException("Method not decompiled: net.lingala.zip4j.io.SplitOutputStream.<init>(java.lang.String, long):void");
    }

    public SplitOutputStream(File file, long j) throws FileNotFoundException, ZipException {
        RandomAccessFile randomAccessFile;
        Throwable th;
        File file2 = file;
        long splitLength2 = j;
        if (splitLength2 < 0 || splitLength2 >= 65536) {
            new RandomAccessFile(file2, InternalZipConstants.WRITE_MODE);
            this.raf = randomAccessFile;
            this.splitLength = splitLength2;
            this.outFile = file2;
            this.zipFile = file2;
            this.currSplitFileCounter = 0;
            this.bytesWrittenForThisPart = 0;
            return;
        }
        Throwable th2 = th;
        new ZipException("split length less than minimum allowed split length of 65536 Bytes");
        throw th2;
    }

    public void write(int b) throws IOException {
        write(new byte[]{(byte) b}, 0, 1);
    }

    public void write(byte[] bArr) throws IOException {
        byte[] b = bArr;
        write(b, 0, b.length);
    }

    public void write(byte[] bArr, int i, int i2) throws IOException {
        Throwable th;
        byte[] b = bArr;
        int off = i;
        int len = i2;
        if (len > 0) {
            if (this.splitLength == -1) {
                this.raf.write(b, off, len);
                this.bytesWrittenForThisPart += (long) len;
            } else if (this.splitLength < 65536) {
                Throwable th2 = th;
                new IOException("split length less than minimum allowed split length of 65536 Bytes");
                throw th2;
            } else if (this.bytesWrittenForThisPart >= this.splitLength) {
                startNextSplitFile();
                this.raf.write(b, off, len);
                this.bytesWrittenForThisPart = (long) len;
            } else if (this.bytesWrittenForThisPart + ((long) len) <= this.splitLength) {
                this.raf.write(b, off, len);
                this.bytesWrittenForThisPart += (long) len;
            } else if (isHeaderData(b)) {
                startNextSplitFile();
                this.raf.write(b, off, len);
                this.bytesWrittenForThisPart = (long) len;
            } else {
                this.raf.write(b, off, (int) (this.splitLength - this.bytesWrittenForThisPart));
                startNextSplitFile();
                this.raf.write(b, off + ((int) (this.splitLength - this.bytesWrittenForThisPart)), (int) (((long) len) - (this.splitLength - this.bytesWrittenForThisPart)));
                this.bytesWrittenForThisPart = ((long) len) - (this.splitLength - this.bytesWrittenForThisPart);
            }
        }
    }

    private void startNextSplitFile() throws IOException {
        Throwable th;
        StringBuffer stringBuffer;
        String stringBuffer2;
        File file;
        StringBuffer stringBuffer3;
        File currSplitFile;
        File file2;
        RandomAccessFile randomAccessFile;
        Throwable th2;
        Throwable th3;
        StringBuffer stringBuffer4;
        File file3;
        StringBuffer stringBuffer5;
        try {
            String zipFileWithoutExt = Zip4jUtil.getZipFileNameWithoutExt(this.outFile.getName());
            String zipFileName = this.zipFile.getAbsolutePath();
            if (this.outFile.getParent() == null) {
                stringBuffer2 = "";
            } else {
                new StringBuffer(String.valueOf(this.outFile.getParent()));
                stringBuffer2 = stringBuffer.append(System.getProperty("file.separator")).toString();
            }
            String parentPath = stringBuffer2;
            if (this.currSplitFileCounter < 9) {
                new StringBuffer(String.valueOf(parentPath));
                new File(stringBuffer5.append(zipFileWithoutExt).append(".z0").append(this.currSplitFileCounter + 1).toString());
                currSplitFile = file3;
            } else {
                new StringBuffer(String.valueOf(parentPath));
                new File(stringBuffer3.append(zipFileWithoutExt).append(".z").append(this.currSplitFileCounter + 1).toString());
                currSplitFile = file;
            }
            this.raf.close();
            if (currSplitFile.exists()) {
                Throwable th4 = th3;
                new StringBuffer("split file: ");
                new IOException(stringBuffer4.append(currSplitFile.getName()).append(" already exists in the current directory, cannot rename this file").toString());
                throw th4;
            } else if (!this.zipFile.renameTo(currSplitFile)) {
                Throwable th5 = th2;
                new IOException("cannot rename newly created split file");
                throw th5;
            } else {
                new File(zipFileName);
                this.zipFile = file2;
                new RandomAccessFile(this.zipFile, InternalZipConstants.WRITE_MODE);
                this.raf = randomAccessFile;
                this.currSplitFileCounter++;
            }
        } catch (ZipException e) {
            ZipException e2 = e;
            Throwable th6 = th;
            new IOException(e2.getMessage());
            throw th6;
        }
    }

    private boolean isHeaderData(byte[] bArr) {
        byte[] buff = bArr;
        if (buff == null || buff.length < 4) {
            return false;
        }
        int signature = Raw.readIntLittleEndian(buff, 0);
        long[] allHeaderSignatures = Zip4jUtil.getAllHeaderSignatures();
        if (allHeaderSignatures != null && allHeaderSignatures.length > 0) {
            for (int i = 0; i < allHeaderSignatures.length; i++) {
                if (allHeaderSignatures[i] != 134695760 && allHeaderSignatures[i] == ((long) signature)) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean checkBuffSizeAndStartNextSplitFile(int i) throws ZipException {
        Throwable th;
        Throwable th2;
        int bufferSize = i;
        if (bufferSize < 0) {
            Throwable th3 = th2;
            new ZipException("negative buffersize for checkBuffSizeAndStartNextSplitFile");
            throw th3;
        } else if (isBuffSizeFitForCurrSplitFile(bufferSize)) {
            return false;
        } else {
            try {
                startNextSplitFile();
                this.bytesWrittenForThisPart = 0;
                return true;
            } catch (IOException e) {
                IOException e2 = e;
                Throwable th4 = th;
                new ZipException((Throwable) e2);
                throw th4;
            }
        }
    }

    public boolean isBuffSizeFitForCurrSplitFile(int i) throws ZipException {
        Throwable th;
        int bufferSize = i;
        if (bufferSize < 0) {
            Throwable th2 = th;
            new ZipException("negative buffersize for isBuffSizeFitForCurrSplitFile");
            throw th2;
        } else if (this.splitLength >= 65536) {
            return this.bytesWrittenForThisPart + ((long) bufferSize) <= this.splitLength;
        } else {
            return true;
        }
    }

    public void seek(long pos) throws IOException {
        this.raf.seek(pos);
    }

    public void close() throws IOException {
        if (this.raf != null) {
            this.raf.close();
        }
    }

    public void flush() throws IOException {
    }

    public long getFilePointer() throws IOException {
        return this.raf.getFilePointer();
    }

    public boolean isSplitZipFile() {
        return this.splitLength != -1;
    }

    public long getSplitLength() {
        return this.splitLength;
    }

    public int getCurrSplitFileCounter() {
        return this.currSplitFileCounter;
    }
}
