package net.lingala.zip4j.io;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.CRC32;
import net.lingala.zip4j.core.HeaderWriter;
import net.lingala.zip4j.crypto.AESEncrpyter;
import net.lingala.zip4j.crypto.IEncrypter;
import net.lingala.zip4j.crypto.StandardEncrypter;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.AESExtraDataRecord;
import net.lingala.zip4j.model.CentralDirectory;
import net.lingala.zip4j.model.EndCentralDirRecord;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.Raw;
import net.lingala.zip4j.util.Zip4jUtil;

public class CipherOutputStream extends BaseOutputStream {
    private long bytesWrittenForThisFile = 0;
    protected CRC32 crc;
    private IEncrypter encrypter;
    protected FileHeader fileHeader;
    protected LocalFileHeader localFileHeader;
    protected OutputStream outputStream;
    private byte[] pendingBuffer = new byte[16];
    private int pendingBufferLength = 0;
    private File sourceFile;
    private long totalBytesRead = 0;
    private long totalBytesWritten = 0;
    protected ZipModel zipModel;
    protected ZipParameters zipParameters;

    public CipherOutputStream(OutputStream outputStream2, ZipModel zipModel2) {
        CRC32 crc32;
        this.outputStream = outputStream2;
        initZipModel(zipModel2);
        new CRC32();
        this.crc = crc32;
    }

    public void putNextEntry(File file, ZipParameters zipParameters2) throws ZipException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        HeaderWriter headerWriter;
        Throwable th4;
        Throwable th5;
        File file2 = file;
        ZipParameters zipParameters3 = zipParameters2;
        if (!zipParameters3.isSourceExternalStream() && file2 == null) {
            Throwable th6 = th5;
            new ZipException("input file is null");
            throw th6;
        } else if (zipParameters3.isSourceExternalStream() || Zip4jUtil.checkFileExists(file2)) {
            try {
                this.sourceFile = file2;
                this.zipParameters = (ZipParameters) zipParameters3.clone();
                if (!zipParameters3.isSourceExternalStream()) {
                    if (this.sourceFile.isDirectory()) {
                        this.zipParameters.setEncryptFiles(false);
                        this.zipParameters.setEncryptionMethod(-1);
                        this.zipParameters.setCompressionMethod(0);
                    }
                } else if (!Zip4jUtil.isStringNotNullAndNotEmpty(this.zipParameters.getFileNameInZip())) {
                    Throwable th7 = th3;
                    new ZipException("file name is empty for external stream");
                    throw th7;
                } else if (this.zipParameters.getFileNameInZip().endsWith(InternalZipConstants.ZIP_FILE_SEPARATOR) || this.zipParameters.getFileNameInZip().endsWith("\\")) {
                    this.zipParameters.setEncryptFiles(false);
                    this.zipParameters.setEncryptionMethod(-1);
                    this.zipParameters.setCompressionMethod(0);
                }
                createFileHeader();
                createLocalFileHeader();
                if (this.zipModel.isSplitArchive() && (this.zipModel.getCentralDirectory() == null || this.zipModel.getCentralDirectory().getFileHeaders() == null || this.zipModel.getCentralDirectory().getFileHeaders().size() == 0)) {
                    byte[] intByte = new byte[4];
                    Raw.writeIntLittleEndian(intByte, 0, 134695760);
                    this.outputStream.write(intByte);
                    this.totalBytesWritten += 4;
                }
                if (this.outputStream instanceof SplitOutputStream) {
                    if (this.totalBytesWritten == 4) {
                        this.fileHeader.setOffsetLocalHeader(4);
                    } else {
                        this.fileHeader.setOffsetLocalHeader(((SplitOutputStream) this.outputStream).getFilePointer());
                    }
                } else if (this.totalBytesWritten == 4) {
                    this.fileHeader.setOffsetLocalHeader(4);
                } else {
                    this.fileHeader.setOffsetLocalHeader(this.totalBytesWritten);
                }
                new HeaderWriter();
                HeaderWriter headerWriter2 = headerWriter;
                this.totalBytesWritten += (long) headerWriter2.writeLocalFileHeader(this.zipModel, this.localFileHeader, this.outputStream);
                if (this.zipParameters.isEncryptFiles()) {
                    initEncrypter();
                    if (this.encrypter != null) {
                        if (zipParameters3.getEncryptionMethod() == 0) {
                            byte[] headerBytes = ((StandardEncrypter) this.encrypter).getHeaderBytes();
                            this.outputStream.write(headerBytes);
                            this.totalBytesWritten += (long) headerBytes.length;
                            this.bytesWrittenForThisFile += (long) headerBytes.length;
                        } else if (zipParameters3.getEncryptionMethod() == 99) {
                            byte[] saltBytes = ((AESEncrpyter) this.encrypter).getSaltBytes();
                            byte[] passwordVerifier = ((AESEncrpyter) this.encrypter).getDerivedPasswordVerifier();
                            this.outputStream.write(saltBytes);
                            this.outputStream.write(passwordVerifier);
                            this.totalBytesWritten += (long) (saltBytes.length + passwordVerifier.length);
                            this.bytesWrittenForThisFile += (long) (saltBytes.length + passwordVerifier.length);
                        }
                    }
                }
                this.crc.reset();
            } catch (CloneNotSupportedException e) {
                CloneNotSupportedException e2 = e;
                Throwable th8 = th2;
                new ZipException((Throwable) e2);
                throw th8;
            } catch (ZipException e3) {
                throw e3;
            } catch (Exception e4) {
                Exception e5 = e4;
                Throwable th9 = th;
                new ZipException((Throwable) e5);
                throw th9;
            }
        } else {
            Throwable th10 = th4;
            new ZipException("input file does not exist");
            throw th10;
        }
    }

    private void initEncrypter() throws ZipException {
        IEncrypter iEncrypter;
        IEncrypter iEncrypter2;
        Throwable th;
        if (!this.zipParameters.isEncryptFiles()) {
            this.encrypter = null;
            return;
        }
        switch (this.zipParameters.getEncryptionMethod()) {
            case 0:
                new StandardEncrypter(this.zipParameters.getPassword(), (this.localFileHeader.getLastModFileTime() & InternalZipConstants.MAX_ALLOWED_ZIP_COMMENT_LENGTH) << 16);
                this.encrypter = iEncrypter2;
                return;
            case 99:
                new AESEncrpyter(this.zipParameters.getPassword(), this.zipParameters.getAesKeyStrength());
                this.encrypter = iEncrypter;
                return;
            default:
                Throwable th2 = th;
                new ZipException("invalid encprytion method");
                throw th2;
        }
    }

    private void initZipModel(ZipModel zipModel2) {
        List list;
        ArrayList arrayList;
        CentralDirectory centralDirectory;
        EndCentralDirRecord endCentralDirRecord;
        ZipModel zipModel3;
        ZipModel zipModel4 = zipModel2;
        if (zipModel4 == null) {
            new ZipModel();
            this.zipModel = zipModel3;
        } else {
            this.zipModel = zipModel4;
        }
        if (this.zipModel.getEndCentralDirRecord() == null) {
            new EndCentralDirRecord();
            this.zipModel.setEndCentralDirRecord(endCentralDirRecord);
        }
        if (this.zipModel.getCentralDirectory() == null) {
            new CentralDirectory();
            this.zipModel.setCentralDirectory(centralDirectory);
        }
        if (this.zipModel.getCentralDirectory().getFileHeaders() == null) {
            new ArrayList();
            this.zipModel.getCentralDirectory().setFileHeaders(arrayList);
        }
        if (this.zipModel.getLocalFileHeaderList() == null) {
            new ArrayList();
            this.zipModel.setLocalFileHeaderList(list);
        }
        if ((this.outputStream instanceof SplitOutputStream) && ((SplitOutputStream) this.outputStream).isSplitZipFile()) {
            this.zipModel.setSplitArchive(true);
            this.zipModel.setSplitLength(((SplitOutputStream) this.outputStream).getSplitLength());
        }
        this.zipModel.getEndCentralDirRecord().setSignature(InternalZipConstants.ENDSIG);
    }

    public void write(int bval) throws IOException {
        write(new byte[]{(byte) bval}, 0, 1);
    }

    public void write(byte[] bArr) throws IOException {
        Throwable th;
        byte[] b = bArr;
        if (b == null) {
            Throwable th2 = th;
            new NullPointerException();
            throw th2;
        } else if (b.length != 0) {
            write(b, 0, b.length);
        }
    }

    public void write(byte[] bArr, int i, int i2) throws IOException {
        byte[] b = bArr;
        int off = i;
        int len = i2;
        if (len != 0) {
            if (this.zipParameters.isEncryptFiles() && this.zipParameters.getEncryptionMethod() == 99) {
                if (this.pendingBufferLength != 0) {
                    if (len >= 16 - this.pendingBufferLength) {
                        System.arraycopy(b, off, this.pendingBuffer, this.pendingBufferLength, 16 - this.pendingBufferLength);
                        encryptAndWrite(this.pendingBuffer, 0, this.pendingBuffer.length);
                        off = 16 - this.pendingBufferLength;
                        len -= off;
                        this.pendingBufferLength = 0;
                    } else {
                        System.arraycopy(b, off, this.pendingBuffer, this.pendingBufferLength, len);
                        this.pendingBufferLength += len;
                        return;
                    }
                }
                if (!(len == 0 || len % 16 == 0)) {
                    System.arraycopy(b, (len + off) - (len % 16), this.pendingBuffer, 0, len % 16);
                    this.pendingBufferLength = len % 16;
                    len -= this.pendingBufferLength;
                }
            }
            if (len != 0) {
                encryptAndWrite(b, off, len);
            }
        }
    }

    private void encryptAndWrite(byte[] bArr, int i, int i2) throws IOException {
        Throwable th;
        byte[] b = bArr;
        int off = i;
        int len = i2;
        if (this.encrypter != null) {
            try {
                int encryptData = this.encrypter.encryptData(b, off, len);
            } catch (ZipException e) {
                ZipException e2 = e;
                Throwable th2 = th;
                new IOException(e2.getMessage());
                throw th2;
            }
        }
        this.outputStream.write(b, off, len);
        this.totalBytesWritten += (long) len;
        this.bytesWrittenForThisFile += (long) len;
    }

    public void closeEntry() throws IOException, ZipException {
        HeaderWriter headerWriter;
        Throwable th;
        if (this.pendingBufferLength != 0) {
            encryptAndWrite(this.pendingBuffer, 0, this.pendingBufferLength);
            this.pendingBufferLength = 0;
        }
        if (this.zipParameters.isEncryptFiles() && this.zipParameters.getEncryptionMethod() == 99) {
            if (this.encrypter instanceof AESEncrpyter) {
                this.outputStream.write(((AESEncrpyter) this.encrypter).getFinalMac());
                this.bytesWrittenForThisFile += 10;
                this.totalBytesWritten += 10;
            } else {
                Throwable th2 = th;
                new ZipException("invalid encrypter for AES encrypted file");
                throw th2;
            }
        }
        this.fileHeader.setCompressedSize(this.bytesWrittenForThisFile);
        this.localFileHeader.setCompressedSize(this.bytesWrittenForThisFile);
        if (this.zipParameters.isSourceExternalStream()) {
            this.fileHeader.setUncompressedSize(this.totalBytesRead);
            if (this.localFileHeader.getUncompressedSize() != this.totalBytesRead) {
                this.localFileHeader.setUncompressedSize(this.totalBytesRead);
            }
        }
        long crc32 = this.crc.getValue();
        if (this.fileHeader.isEncrypted() && this.fileHeader.getEncryptionMethod() == 99) {
            crc32 = 0;
        }
        if (!this.zipParameters.isEncryptFiles() || this.zipParameters.getEncryptionMethod() != 99) {
            this.fileHeader.setCrc32(crc32);
            this.localFileHeader.setCrc32(crc32);
        } else {
            this.fileHeader.setCrc32(0);
            this.localFileHeader.setCrc32(0);
        }
        boolean add = this.zipModel.getLocalFileHeaderList().add(this.localFileHeader);
        boolean add2 = this.zipModel.getCentralDirectory().getFileHeaders().add(this.fileHeader);
        new HeaderWriter();
        HeaderWriter headerWriter2 = headerWriter;
        this.totalBytesWritten += (long) headerWriter2.writeExtendedLocalHeader(this.localFileHeader, this.outputStream);
        this.crc.reset();
        this.bytesWrittenForThisFile = 0;
        this.encrypter = null;
        this.totalBytesRead = 0;
    }

    public void finish() throws IOException, ZipException {
        HeaderWriter headerWriter;
        this.zipModel.getEndCentralDirRecord().setOffsetOfStartOfCentralDir(this.totalBytesWritten);
        new HeaderWriter();
        headerWriter.finalizeZipFile(this.zipModel, this.outputStream);
    }

    public void close() throws IOException {
        if (this.outputStream != null) {
            this.outputStream.close();
        }
    }

    private void createFileHeader() throws ZipException {
        FileHeader fileHeader2;
        String fileName;
        int saltLength;
        Throwable th;
        Throwable th2;
        Throwable th3;
        new FileHeader();
        this.fileHeader = fileHeader2;
        this.fileHeader.setSignature(33639248);
        this.fileHeader.setVersionMadeBy(20);
        this.fileHeader.setVersionNeededToExtract(20);
        if (!this.zipParameters.isEncryptFiles() || this.zipParameters.getEncryptionMethod() != 99) {
            this.fileHeader.setCompressionMethod(this.zipParameters.getCompressionMethod());
        } else {
            this.fileHeader.setCompressionMethod(99);
            this.fileHeader.setAesExtraDataRecord(generateAESExtraDataRecord(this.zipParameters));
        }
        if (this.zipParameters.isEncryptFiles()) {
            this.fileHeader.setEncrypted(true);
            this.fileHeader.setEncryptionMethod(this.zipParameters.getEncryptionMethod());
        }
        if (this.zipParameters.isSourceExternalStream()) {
            this.fileHeader.setLastModFileTime((int) Zip4jUtil.javaToDosTime(System.currentTimeMillis()));
            if (!Zip4jUtil.isStringNotNullAndNotEmpty(this.zipParameters.getFileNameInZip())) {
                Throwable th4 = th3;
                new ZipException("fileNameInZip is null or empty");
                throw th4;
            }
            fileName = this.zipParameters.getFileNameInZip();
        } else {
            this.fileHeader.setLastModFileTime((int) Zip4jUtil.javaToDosTime(Zip4jUtil.getLastModifiedFileTime(this.sourceFile, this.zipParameters.getTimeZone())));
            this.fileHeader.setUncompressedSize(this.sourceFile.length());
            fileName = Zip4jUtil.getRelativeFileName(this.sourceFile.getAbsolutePath(), this.zipParameters.getRootFolderInZip(), this.zipParameters.getDefaultFolderPath());
        }
        if (!Zip4jUtil.isStringNotNullAndNotEmpty(fileName)) {
            Throwable th5 = th2;
            new ZipException("fileName is null or empty. unable to create file header");
            throw th5;
        }
        this.fileHeader.setFileName(fileName);
        if (Zip4jUtil.isStringNotNullAndNotEmpty(this.zipModel.getFileNameCharset())) {
            this.fileHeader.setFileNameLength(Zip4jUtil.getEncodedStringLength(fileName, this.zipModel.getFileNameCharset()));
        } else {
            this.fileHeader.setFileNameLength(Zip4jUtil.getEncodedStringLength(fileName));
        }
        if (this.outputStream instanceof SplitOutputStream) {
            this.fileHeader.setDiskNumberStart(((SplitOutputStream) this.outputStream).getCurrSplitFileCounter());
        } else {
            this.fileHeader.setDiskNumberStart(0);
        }
        int fileAttrs = 0;
        if (!this.zipParameters.isSourceExternalStream()) {
            fileAttrs = getFileAttributes(this.sourceFile);
        }
        byte[] externalFileAttrs = new byte[4];
        externalFileAttrs[0] = (byte) fileAttrs;
        this.fileHeader.setExternalFileAttr(externalFileAttrs);
        if (this.zipParameters.isSourceExternalStream()) {
            this.fileHeader.setDirectory(fileName.endsWith(InternalZipConstants.ZIP_FILE_SEPARATOR) || fileName.endsWith("\\"));
        } else {
            this.fileHeader.setDirectory(this.sourceFile.isDirectory());
        }
        if (this.fileHeader.isDirectory()) {
            this.fileHeader.setCompressedSize(0);
            this.fileHeader.setUncompressedSize(0);
        } else if (!this.zipParameters.isSourceExternalStream()) {
            long fileSize = Zip4jUtil.getFileLengh(this.sourceFile);
            if (this.zipParameters.getCompressionMethod() != 0) {
                this.fileHeader.setCompressedSize(0);
            } else if (this.zipParameters.getEncryptionMethod() == 0) {
                this.fileHeader.setCompressedSize(fileSize + 12);
            } else if (this.zipParameters.getEncryptionMethod() == 99) {
                switch (this.zipParameters.getAesKeyStrength()) {
                    case 1:
                        saltLength = 8;
                        break;
                    case 3:
                        saltLength = 16;
                        break;
                    default:
                        Throwable th6 = th;
                        new ZipException("invalid aes key strength, cannot determine key sizes");
                        throw th6;
                }
                this.fileHeader.setCompressedSize(fileSize + ((long) saltLength) + 10 + 2);
            } else {
                this.fileHeader.setCompressedSize(0);
            }
            this.fileHeader.setUncompressedSize(fileSize);
        }
        if (this.zipParameters.isEncryptFiles() && this.zipParameters.getEncryptionMethod() == 0) {
            this.fileHeader.setCrc32((long) this.zipParameters.getSourceFileCRC());
        }
        byte[] shortByte = new byte[2];
        shortByte[0] = Raw.bitArrayToByte(generateGeneralPurposeBitArray(this.fileHeader.isEncrypted(), this.zipParameters.getCompressionMethod()));
        boolean isFileNameCharsetSet = Zip4jUtil.isStringNotNullAndNotEmpty(this.zipModel.getFileNameCharset());
        if ((!isFileNameCharsetSet || !this.zipModel.getFileNameCharset().equalsIgnoreCase(InternalZipConstants.CHARSET_UTF8)) && (isFileNameCharsetSet || !Zip4jUtil.detectCharSet(this.fileHeader.getFileName()).equals(InternalZipConstants.CHARSET_UTF8))) {
            shortByte[1] = 0;
        } else {
            shortByte[1] = 8;
        }
        this.fileHeader.setGeneralPurposeFlag(shortByte);
    }

    private void createLocalFileHeader() throws ZipException {
        LocalFileHeader localFileHeader2;
        Throwable th;
        if (this.fileHeader == null) {
            Throwable th2 = th;
            new ZipException("file header is null, cannot create local file header");
            throw th2;
        }
        new LocalFileHeader();
        this.localFileHeader = localFileHeader2;
        this.localFileHeader.setSignature(67324752);
        this.localFileHeader.setVersionNeededToExtract(this.fileHeader.getVersionNeededToExtract());
        this.localFileHeader.setCompressionMethod(this.fileHeader.getCompressionMethod());
        this.localFileHeader.setLastModFileTime(this.fileHeader.getLastModFileTime());
        this.localFileHeader.setUncompressedSize(this.fileHeader.getUncompressedSize());
        this.localFileHeader.setFileNameLength(this.fileHeader.getFileNameLength());
        this.localFileHeader.setFileName(this.fileHeader.getFileName());
        this.localFileHeader.setEncrypted(this.fileHeader.isEncrypted());
        this.localFileHeader.setEncryptionMethod(this.fileHeader.getEncryptionMethod());
        this.localFileHeader.setAesExtraDataRecord(this.fileHeader.getAesExtraDataRecord());
        this.localFileHeader.setCrc32(this.fileHeader.getCrc32());
        this.localFileHeader.setCompressedSize(this.fileHeader.getCompressedSize());
        this.localFileHeader.setGeneralPurposeFlag((byte[]) this.fileHeader.getGeneralPurposeFlag().clone());
    }

    private int getFileAttributes(File file) throws ZipException {
        Throwable th;
        File file2 = file;
        if (file2 == null) {
            Throwable th2 = th;
            new ZipException("input file is null, cannot get file attributes");
            throw th2;
        } else if (!file2.exists()) {
            return 0;
        } else {
            if (file2.isDirectory()) {
                if (file2.isHidden()) {
                    return 18;
                }
                return 16;
            } else if (!file2.canWrite() && file2.isHidden()) {
                return 3;
            } else {
                if (!file2.canWrite()) {
                    return 1;
                }
                if (file2.isHidden()) {
                    return 2;
                }
                return 0;
            }
        }
    }

    private int[] generateGeneralPurposeBitArray(boolean isEncrpyted, int i) {
        int compressionMethod = i;
        int[] generalPurposeBits = new int[8];
        if (isEncrpyted) {
            generalPurposeBits[0] = 1;
        } else {
            generalPurposeBits[0] = 0;
        }
        if (compressionMethod != 8) {
            generalPurposeBits[1] = 0;
            generalPurposeBits[2] = 0;
        }
        generalPurposeBits[3] = 1;
        return generalPurposeBits;
    }

    private AESExtraDataRecord generateAESExtraDataRecord(ZipParameters zipParameters2) throws ZipException {
        AESExtraDataRecord aESExtraDataRecord;
        Throwable th;
        Throwable th2;
        ZipParameters parameters = zipParameters2;
        if (parameters == null) {
            Throwable th3 = th2;
            new ZipException("zip parameters are null, cannot generate AES Extra Data record");
            throw th3;
        }
        new AESExtraDataRecord();
        AESExtraDataRecord aesDataRecord = aESExtraDataRecord;
        aesDataRecord.setSignature(39169);
        aesDataRecord.setDataSize(7);
        aesDataRecord.setVendorID("AE");
        aesDataRecord.setVersionNumber(2);
        if (parameters.getAesKeyStrength() == 1) {
            aesDataRecord.setAesStrength(1);
        } else if (parameters.getAesKeyStrength() == 3) {
            aesDataRecord.setAesStrength(3);
        } else {
            Throwable th4 = th;
            new ZipException("invalid AES key strength, cannot generate AES Extra data record");
            throw th4;
        }
        aesDataRecord.setCompressionMethod(parameters.getCompressionMethod());
        return aesDataRecord;
    }

    public void decrementCompressedFileSize(int i) {
        int value = i;
        if (value > 0 && ((long) value) <= this.bytesWrittenForThisFile) {
            this.bytesWrittenForThisFile -= (long) value;
        }
    }

    /* access modifiers changed from: protected */
    public void updateTotalBytesRead(int i) {
        int toUpdate = i;
        if (toUpdate > 0) {
            this.totalBytesRead += (long) toUpdate;
        }
    }

    public void setSourceFile(File sourceFile2) {
        File file = sourceFile2;
        this.sourceFile = file;
    }

    public File getSourceFile() {
        return this.sourceFile;
    }
}
