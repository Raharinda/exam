package net.lingala.zip4j.io;

import java.io.IOException;
import java.io.RandomAccessFile;
import net.lingala.zip4j.crypto.AESDecrypter;
import net.lingala.zip4j.crypto.IDecrypter;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.unzip.UnzipEngine;
import org.apache.xerces.dom3.as.ASContentModel;

public class PartInputStream extends BaseInputStream {
    private byte[] aesBlockByte = new byte[16];
    private int aesBytesReturned = 0;
    private long bytesRead;
    private int count = -1;
    private IDecrypter decrypter;
    private boolean isAESEncryptedFile = false;
    private long length;
    private byte[] oneByteBuff = new byte[1];
    private RandomAccessFile raf;
    private UnzipEngine unzipEngine;

    public PartInputStream(RandomAccessFile raf2, long j, long len, UnzipEngine unzipEngine2) {
        long j2 = j;
        UnzipEngine unzipEngine3 = unzipEngine2;
        this.raf = raf2;
        this.unzipEngine = unzipEngine3;
        this.decrypter = unzipEngine3.getDecrypter();
        this.bytesRead = 0;
        this.length = len;
        this.isAESEncryptedFile = unzipEngine3.getFileHeader().isEncrypted() && unzipEngine3.getFileHeader().getEncryptionMethod() == 99;
    }

    public int available() {
        long amount = this.length - this.bytesRead;
        if (amount > 2147483647L) {
            return ASContentModel.AS_UNBOUNDED;
        }
        return (int) amount;
    }

    public int read() throws IOException {
        if (this.bytesRead >= this.length) {
            return -1;
        }
        if (this.isAESEncryptedFile) {
            if (this.aesBytesReturned == 0 || this.aesBytesReturned == 16) {
                if (read(this.aesBlockByte) == -1) {
                    return -1;
                }
                this.aesBytesReturned = 0;
            }
            byte[] bArr = this.aesBlockByte;
            int i = this.aesBytesReturned;
            int i2 = i + 1;
            this.aesBytesReturned = i2;
            return bArr[i] & 255;
        }
        return read(this.oneByteBuff, 0, 1) == -1 ? -1 : this.oneByteBuff[0] & 255;
    }

    public int read(byte[] bArr) throws IOException {
        byte[] b = bArr;
        return read(b, 0, b.length);
    }

    /* JADX INFO: finally extract failed */
    public int read(byte[] bArr, int i, int i2) throws IOException {
        Throwable th;
        byte[] b = bArr;
        int off = i;
        int len = i2;
        if (((long) len) > this.length - this.bytesRead) {
            len = (int) (this.length - this.bytesRead);
            if (len == 0) {
                checkAndReadAESMacBytes();
                return -1;
            }
        }
        if ((this.unzipEngine.getDecrypter() instanceof AESDecrypter) && this.bytesRead + ((long) len) < this.length && len % 16 != 0) {
            len -= len % 16;
        }
        RandomAccessFile randomAccessFile = this.raf;
        RandomAccessFile randomAccessFile2 = randomAccessFile;
        synchronized (randomAccessFile) {
            try {
                this.count = this.raf.read(b, off, len);
                if (this.count < len && this.unzipEngine.getZipModel().isSplitArchive()) {
                    this.raf.close();
                    this.raf = this.unzipEngine.startNextSplitFile();
                    if (this.count < 0) {
                        this.count = 0;
                    }
                    int newlyRead = this.raf.read(b, this.count, len - this.count);
                    if (newlyRead > 0) {
                        this.count += newlyRead;
                    }
                }
                if (this.count > 0) {
                    if (this.decrypter != null) {
                        try {
                            int decryptData = this.decrypter.decryptData(b, off, this.count);
                        } catch (ZipException e) {
                            ZipException e2 = e;
                            Throwable th2 = th;
                            new IOException(e2.getMessage());
                            throw th2;
                        }
                    }
                    this.bytesRead += (long) this.count;
                }
                if (this.bytesRead >= this.length) {
                    checkAndReadAESMacBytes();
                }
                return this.count;
            } catch (Throwable th3) {
                while (true) {
                    RandomAccessFile randomAccessFile3 = randomAccessFile2;
                    throw th3;
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void checkAndReadAESMacBytes() throws IOException {
        Throwable th;
        if (this.isAESEncryptedFile && this.decrypter != null && (this.decrypter instanceof AESDecrypter) && ((AESDecrypter) this.decrypter).getStoredMac() == null) {
            byte[] macBytes = new byte[10];
            int readLen = this.raf.read(macBytes);
            if (readLen != 10) {
                if (this.unzipEngine.getZipModel().isSplitArchive()) {
                    this.raf.close();
                    this.raf = this.unzipEngine.startNextSplitFile();
                    int readLen2 = readLen + this.raf.read(macBytes, readLen, 10 - readLen);
                } else {
                    Throwable th2 = th;
                    new IOException("Error occured while reading stored AES authentication bytes");
                    throw th2;
                }
            }
            ((AESDecrypter) this.unzipEngine.getDecrypter()).setStoredMac(macBytes);
        }
    }

    public long skip(long j) throws IOException {
        Throwable th;
        long amount = j;
        if (amount < 0) {
            Throwable th2 = th;
            new IllegalArgumentException();
            throw th2;
        }
        if (amount > this.length - this.bytesRead) {
            amount = this.length - this.bytesRead;
        }
        this.bytesRead += amount;
        return amount;
    }

    public void close() throws IOException {
        this.raf.close();
    }

    public void seek(long pos) throws IOException {
        this.raf.seek(pos);
    }

    public UnzipEngine getUnzipEngine() {
        return this.unzipEngine;
    }
}
