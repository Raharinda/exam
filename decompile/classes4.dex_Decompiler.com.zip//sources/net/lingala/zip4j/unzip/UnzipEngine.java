package net.lingala.zip4j.unzip;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.zip.CRC32;
import net.lingala.zip4j.core.HeaderReader;
import net.lingala.zip4j.crypto.AESDecrypter;
import net.lingala.zip4j.crypto.IDecrypter;
import net.lingala.zip4j.crypto.StandardDecrypter;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.io.BaseInputStream;
import net.lingala.zip4j.io.InflaterInputStream;
import net.lingala.zip4j.io.PartInputStream;
import net.lingala.zip4j.io.ZipInputStream;
import net.lingala.zip4j.model.AESExtraDataRecord;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.model.UnzipParameters;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.Raw;
import net.lingala.zip4j.util.Zip4jUtil;

public class UnzipEngine {
    private CRC32 crc;
    private int currSplitFileCounter = 0;
    private IDecrypter decrypter;
    private FileHeader fileHeader;
    private LocalFileHeader localFileHeader;
    private ZipModel zipModel;

    public UnzipEngine(ZipModel zipModel2, FileHeader fileHeader2) throws ZipException {
        Throwable th;
        CRC32 crc32;
        ZipModel zipModel3 = zipModel2;
        FileHeader fileHeader3 = fileHeader2;
        if (zipModel3 == null || fileHeader3 == null) {
            Throwable th2 = th;
            new ZipException("Invalid parameters passed to StoreUnzip. One or more of the parameters were null");
            throw th2;
        }
        this.zipModel = zipModel3;
        this.fileHeader = fileHeader3;
        new CRC32();
        this.crc = crc32;
    }

    public void unzipFile(ProgressMonitor progressMonitor, String str, String str2, UnzipParameters unzipParameters) throws ZipException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        File file;
        ProgressMonitor progressMonitor2 = progressMonitor;
        String outPath = str;
        String newFileName = str2;
        UnzipParameters unzipParameters2 = unzipParameters;
        if (this.zipModel == null || this.fileHeader == null || !Zip4jUtil.isStringNotNullAndNotEmpty(outPath)) {
            Throwable th4 = th;
            new ZipException("Invalid parameters passed during unzipping file. One or more of the parameters were null");
            throw th4;
        }
        InputStream is = null;
        OutputStream os = null;
        try {
            byte[] buff = new byte[InternalZipConstants.BUFF_SIZE];
            is = getInputStream();
            os = getOutputStream(outPath, newFileName);
            do {
                int read = is.read(buff);
                int readLength = read;
                if (read == -1) {
                    closeStreams(is, os);
                    new File(getOutputFileNameWithPath(outPath, newFileName));
                    UnzipUtil.applyFileAttributes(this.fileHeader, file, unzipParameters2);
                    closeStreams(is, os);
                    return;
                }
                os.write(buff, 0, readLength);
                progressMonitor2.updateWorkCompleted((long) readLength);
            } while (!progressMonitor2.isCancelAllTasks());
            progressMonitor2.setResult(3);
            progressMonitor2.setState(0);
            closeStreams(is, os);
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th5 = th3;
            new ZipException((Throwable) e2);
            throw th5;
        } catch (Exception e3) {
            Exception e4 = e3;
            Throwable th6 = th2;
            new ZipException((Throwable) e4);
            throw th6;
        } catch (Throwable th7) {
            Throwable th8 = th7;
            closeStreams(is, os);
            throw th8;
        }
    }

    public ZipInputStream getInputStream() throws ZipException {
        Throwable th;
        ZipInputStream zipInputStream;
        BaseInputStream baseInputStream;
        ZipInputStream zipInputStream2;
        BaseInputStream baseInputStream2;
        Throwable th2;
        Throwable th3;
        StringBuffer stringBuffer;
        Throwable th4;
        StringBuffer stringBuffer2;
        Throwable th5;
        Throwable th6;
        if (this.fileHeader == null) {
            Throwable th7 = th6;
            new ZipException("file header is null, cannot get inputstream");
            throw th7;
        }
        RandomAccessFile raf = null;
        try {
            raf = createFileHandler(InternalZipConstants.READ_MODE);
            String errMsg = "local header and file header do not match";
            if (!checkLocalHeader()) {
                Throwable th8 = th5;
                new ZipException(errMsg);
                throw th8;
            }
            init(raf);
            long comprSize = this.localFileHeader.getCompressedSize();
            long offsetStartOfData = this.localFileHeader.getOffsetStartOfData();
            if (this.localFileHeader.isEncrypted()) {
                if (this.localFileHeader.getEncryptionMethod() == 99) {
                    if (this.decrypter instanceof AESDecrypter) {
                        comprSize -= (long) ((((AESDecrypter) this.decrypter).getSaltLength() + ((AESDecrypter) this.decrypter).getPasswordVerifierLength()) + 10);
                        offsetStartOfData += (long) (((AESDecrypter) this.decrypter).getSaltLength() + ((AESDecrypter) this.decrypter).getPasswordVerifierLength());
                    } else {
                        Throwable th9 = th4;
                        new StringBuffer("invalid decryptor when trying to calculate compressed size for AES encrypted file: ");
                        new ZipException(stringBuffer2.append(this.fileHeader.getFileName()).toString());
                        throw th9;
                    }
                } else if (this.localFileHeader.getEncryptionMethod() == 0) {
                    comprSize -= 12;
                    offsetStartOfData += 12;
                }
            }
            int compressionMethod = this.fileHeader.getCompressionMethod();
            if (this.fileHeader.getEncryptionMethod() == 99) {
                if (this.fileHeader.getAesExtraDataRecord() != null) {
                    compressionMethod = this.fileHeader.getAesExtraDataRecord().getCompressionMethod();
                } else {
                    Throwable th10 = th3;
                    new StringBuffer("AESExtraDataRecord does not exist for AES encrypted file: ");
                    new ZipException(stringBuffer.append(this.fileHeader.getFileName()).toString());
                    throw th10;
                }
            }
            raf.seek(offsetStartOfData);
            switch (compressionMethod) {
                case 0:
                    new PartInputStream(raf, offsetStartOfData, comprSize, this);
                    new ZipInputStream(baseInputStream2);
                    return zipInputStream2;
                case 8:
                    ZipInputStream zipInputStream3 = zipInputStream;
                    new InflaterInputStream(raf, offsetStartOfData, comprSize, this);
                    new ZipInputStream(baseInputStream);
                    return zipInputStream3;
                default:
                    Throwable th11 = th2;
                    new ZipException("compression type not supported");
                    throw th11;
            }
        } catch (ZipException e) {
            ZipException e2 = e;
            if (raf != null) {
                try {
                    raf.close();
                } catch (IOException e3) {
                    IOException iOException = e3;
                }
            }
            throw e2;
        } catch (Exception e4) {
            Exception e5 = e4;
            if (raf != null) {
                try {
                    raf.close();
                } catch (IOException e6) {
                    IOException iOException2 = e6;
                }
            }
            Throwable th12 = th;
            new ZipException((Throwable) e5);
            throw th12;
        }
    }

    private void init(RandomAccessFile randomAccessFile) throws ZipException {
        Throwable th;
        Throwable th2;
        RandomAccessFile raf = randomAccessFile;
        if (this.localFileHeader == null) {
            Throwable th3 = th2;
            new ZipException("local file header is null, cannot initialize input stream");
            throw th3;
        }
        try {
            initDecrypter(raf);
        } catch (ZipException e) {
            throw e;
        } catch (Exception e2) {
            Exception e3 = e2;
            Throwable th4 = th;
            new ZipException((Throwable) e3);
            throw th4;
        }
    }

    private void initDecrypter(RandomAccessFile randomAccessFile) throws ZipException {
        Throwable th;
        IDecrypter iDecrypter;
        IDecrypter iDecrypter2;
        Throwable th2;
        RandomAccessFile raf = randomAccessFile;
        if (this.localFileHeader == null) {
            Throwable th3 = th2;
            new ZipException("local file header is null, cannot init decrypter");
            throw th3;
        } else if (!this.localFileHeader.isEncrypted()) {
        } else {
            if (this.localFileHeader.getEncryptionMethod() == 0) {
                new StandardDecrypter(this.fileHeader, getStandardDecrypterHeaderBytes(raf));
                this.decrypter = iDecrypter2;
            } else if (this.localFileHeader.getEncryptionMethod() == 99) {
                new AESDecrypter(this.localFileHeader, getAESSalt(raf), getAESPasswordVerifier(raf));
                this.decrypter = iDecrypter;
            } else {
                Throwable th4 = th;
                new ZipException("unsupported encryption method");
                throw th4;
            }
        }
    }

    private byte[] getStandardDecrypterHeaderBytes(RandomAccessFile randomAccessFile) throws ZipException {
        Throwable th;
        Throwable th2;
        RandomAccessFile raf = randomAccessFile;
        try {
            byte[] headerBytes = new byte[12];
            raf.seek(this.localFileHeader.getOffsetStartOfData());
            int read = raf.read(headerBytes, 0, 12);
            return headerBytes;
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th3 = th2;
            new ZipException((Throwable) e2);
            throw th3;
        } catch (Exception e3) {
            Exception e4 = e3;
            Throwable th4 = th;
            new ZipException((Throwable) e4);
            throw th4;
        }
    }

    private byte[] getAESSalt(RandomAccessFile randomAccessFile) throws ZipException {
        Throwable th;
        RandomAccessFile raf = randomAccessFile;
        if (this.localFileHeader.getAesExtraDataRecord() == null) {
            return null;
        }
        try {
            byte[] saltBytes = new byte[calculateAESSaltLength(this.localFileHeader.getAesExtraDataRecord())];
            raf.seek(this.localFileHeader.getOffsetStartOfData());
            int read = raf.read(saltBytes);
            return saltBytes;
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th2 = th;
            new ZipException((Throwable) e2);
            throw th2;
        }
    }

    private byte[] getAESPasswordVerifier(RandomAccessFile raf) throws ZipException {
        Throwable th;
        try {
            byte[] pvBytes = new byte[2];
            int read = raf.read(pvBytes);
            return pvBytes;
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th2 = th;
            new ZipException((Throwable) e2);
            throw th2;
        }
    }

    private int calculateAESSaltLength(AESExtraDataRecord aESExtraDataRecord) throws ZipException {
        Throwable th;
        Throwable th2;
        AESExtraDataRecord aesExtraDataRecord = aESExtraDataRecord;
        if (aesExtraDataRecord == null) {
            Throwable th3 = th2;
            new ZipException("unable to determine salt length: AESExtraDataRecord is null");
            throw th3;
        }
        switch (aesExtraDataRecord.getAesStrength()) {
            case 1:
                return 8;
            case 2:
                return 12;
            case 3:
                return 16;
            default:
                Throwable th4 = th;
                new ZipException("unable to determine salt length: invalid aes key strength");
                throw th4;
        }
    }

    public void checkCRC() throws ZipException {
        StringBuffer stringBuffer;
        Throwable th;
        StringBuffer stringBuffer2;
        Throwable th2;
        StringBuffer stringBuffer3;
        Throwable th3;
        StringBuffer stringBuffer4;
        if (this.fileHeader == null) {
            return;
        }
        if (this.fileHeader.getEncryptionMethod() == 99) {
            if (this.decrypter != null && (this.decrypter instanceof AESDecrypter)) {
                byte[] tmpMacBytes = ((AESDecrypter) this.decrypter).getCalculatedAuthenticationBytes();
                byte[] storedMac = ((AESDecrypter) this.decrypter).getStoredMac();
                byte[] calculatedMac = new byte[10];
                if (calculatedMac == null || storedMac == null) {
                    Throwable th4 = th2;
                    new StringBuffer("CRC (MAC) check failed for ");
                    new ZipException(stringBuffer3.append(this.fileHeader.getFileName()).toString());
                    throw th4;
                }
                System.arraycopy(tmpMacBytes, 0, calculatedMac, 0, 10);
                if (!Arrays.equals(calculatedMac, storedMac)) {
                    Throwable th5 = th3;
                    new StringBuffer("invalid CRC (MAC) for file: ");
                    new ZipException(stringBuffer4.append(this.fileHeader.getFileName()).toString());
                    throw th5;
                }
            }
        } else if ((this.crc.getValue() & InternalZipConstants.ZIP_64_LIMIT) != this.fileHeader.getCrc32()) {
            new StringBuffer("invalid CRC for file: ");
            String errMsg = stringBuffer.append(this.fileHeader.getFileName()).toString();
            if (this.localFileHeader.isEncrypted() && this.localFileHeader.getEncryptionMethod() == 0) {
                new StringBuffer(String.valueOf(errMsg));
                errMsg = stringBuffer2.append(" - Wrong Password?").toString();
            }
            Throwable th6 = th;
            new ZipException(errMsg);
            throw th6;
        }
    }

    private boolean checkLocalHeader() throws ZipException {
        Throwable th;
        HeaderReader headerReader;
        Throwable th2;
        RandomAccessFile randomAccessFile;
        File file;
        RandomAccessFile rafForLH = null;
        try {
            rafForLH = checkSplitFile();
            if (rafForLH == null) {
                new File(this.zipModel.getZipFile());
                new RandomAccessFile(file, InternalZipConstants.READ_MODE);
                rafForLH = randomAccessFile;
            }
            new HeaderReader(rafForLH);
            this.localFileHeader = headerReader.readLocalFileHeader(this.fileHeader);
            if (this.localFileHeader == null) {
                Throwable th3 = th2;
                new ZipException("error reading local file header. Is this a valid zip file?");
                throw th3;
            } else if (this.localFileHeader.getCompressionMethod() != this.fileHeader.getCompressionMethod()) {
                if (rafForLH != null) {
                    try {
                        rafForLH.close();
                    } catch (IOException e) {
                        IOException iOException = e;
                    } catch (Exception e2) {
                        Exception exc = e2;
                    }
                }
                return false;
            } else {
                if (rafForLH != null) {
                    try {
                        rafForLH.close();
                    } catch (IOException e3) {
                        IOException iOException2 = e3;
                    } catch (Exception e4) {
                        Exception exc2 = e4;
                    }
                }
                return true;
            }
        } catch (FileNotFoundException e5) {
            FileNotFoundException e6 = e5;
            Throwable th4 = th;
            new ZipException((Throwable) e6);
            throw th4;
        } catch (Throwable th5) {
            Throwable th6 = th5;
            if (rafForLH != null) {
                try {
                    rafForLH.close();
                } catch (IOException e7) {
                    IOException iOException3 = e7;
                } catch (Exception e8) {
                    Exception exc3 = e8;
                }
            }
            throw th6;
        }
    }

    private RandomAccessFile checkSplitFile() throws ZipException {
        StringBuffer stringBuffer;
        String partFile;
        StringBuffer stringBuffer2;
        Throwable th;
        Throwable th2;
        RandomAccessFile randomAccessFile;
        Throwable th3;
        if (!this.zipModel.isSplitArchive()) {
            return null;
        }
        int diskNumberStartOfFile = this.fileHeader.getDiskNumberStart();
        this.currSplitFileCounter = diskNumberStartOfFile + 1;
        String curZipFile = this.zipModel.getZipFile();
        if (diskNumberStartOfFile == this.zipModel.getEndCentralDirRecord().getNoOfThisDisk()) {
            partFile = this.zipModel.getZipFile();
        } else if (diskNumberStartOfFile >= 9) {
            new StringBuffer(String.valueOf(curZipFile.substring(0, curZipFile.lastIndexOf("."))));
            partFile = stringBuffer2.append(".z").append(diskNumberStartOfFile + 1).toString();
        } else {
            new StringBuffer(String.valueOf(curZipFile.substring(0, curZipFile.lastIndexOf("."))));
            partFile = stringBuffer.append(".z0").append(diskNumberStartOfFile + 1).toString();
        }
        try {
            new RandomAccessFile(partFile, InternalZipConstants.READ_MODE);
            RandomAccessFile raf = randomAccessFile;
            if (this.currSplitFileCounter == 1) {
                byte[] splitSig = new byte[4];
                int read = raf.read(splitSig);
                if (((long) Raw.readIntLittleEndian(splitSig, 0)) != 134695760) {
                    Throwable th4 = th3;
                    new ZipException("invalid first part split file signature");
                    throw th4;
                }
            }
            return raf;
        } catch (FileNotFoundException e) {
            FileNotFoundException e2 = e;
            Throwable th5 = th2;
            new ZipException((Throwable) e2);
            throw th5;
        } catch (IOException e3) {
            IOException e4 = e3;
            Throwable th6 = th;
            new ZipException((Throwable) e4);
            throw th6;
        }
    }

    private RandomAccessFile createFileHandler(String str) throws ZipException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        RandomAccessFile randomAccessFile;
        File file;
        RandomAccessFile raf;
        String mode = str;
        if (this.zipModel == null || !Zip4jUtil.isStringNotNullAndNotEmpty(this.zipModel.getZipFile())) {
            Throwable th4 = th;
            new ZipException("input parameter is null in getFilePointer");
            throw th4;
        }
        try {
            if (this.zipModel.isSplitArchive()) {
                raf = checkSplitFile();
            } else {
                RandomAccessFile randomAccessFile2 = randomAccessFile;
                new File(this.zipModel.getZipFile());
                new RandomAccessFile(file, mode);
                raf = randomAccessFile2;
            }
            return raf;
        } catch (FileNotFoundException e) {
            FileNotFoundException e2 = e;
            Throwable th5 = th3;
            new ZipException((Throwable) e2);
            throw th5;
        } catch (Exception e3) {
            Exception e4 = e3;
            Throwable th6 = th2;
            new ZipException((Throwable) e4);
            throw th6;
        }
    }

    private FileOutputStream getOutputStream(String str, String str2) throws ZipException {
        Throwable th;
        File file;
        FileOutputStream fileOutputStream;
        Throwable th2;
        String outPath = str;
        String newFileName = str2;
        if (!Zip4jUtil.isStringNotNullAndNotEmpty(outPath)) {
            Throwable th3 = th2;
            new ZipException("invalid output path");
            throw th3;
        }
        try {
            new File(getOutputFileNameWithPath(outPath, newFileName));
            File file2 = file;
            if (!file2.getParentFile().exists()) {
                boolean mkdirs = file2.getParentFile().mkdirs();
            }
            if (file2.exists()) {
                boolean delete = file2.delete();
            }
            FileOutputStream fileOutputStream2 = fileOutputStream;
            new FileOutputStream(file2);
            return fileOutputStream2;
        } catch (FileNotFoundException e) {
            FileNotFoundException e2 = e;
            Throwable th4 = th;
            new ZipException((Throwable) e2);
            throw th4;
        }
    }

    private String getOutputFileNameWithPath(String str, String str2) throws ZipException {
        String fileName;
        StringBuffer stringBuffer;
        String outPath = str;
        String newFileName = str2;
        if (Zip4jUtil.isStringNotNullAndNotEmpty(newFileName)) {
            fileName = newFileName;
        } else {
            fileName = this.fileHeader.getFileName();
        }
        new StringBuffer(String.valueOf(outPath));
        return stringBuffer.append(System.getProperty("file.separator")).append(fileName).toString();
    }

    public RandomAccessFile startNextSplitFile() throws IOException, FileNotFoundException {
        StringBuffer stringBuffer;
        String partFile;
        StringBuffer stringBuffer2;
        Throwable th;
        RandomAccessFile randomAccessFile;
        Throwable th2;
        StringBuffer stringBuffer3;
        String currZipFile = this.zipModel.getZipFile();
        if (this.currSplitFileCounter == this.zipModel.getEndCentralDirRecord().getNoOfThisDisk()) {
            partFile = this.zipModel.getZipFile();
        } else if (this.currSplitFileCounter >= 9) {
            new StringBuffer(String.valueOf(currZipFile.substring(0, currZipFile.lastIndexOf("."))));
            partFile = stringBuffer2.append(".z").append(this.currSplitFileCounter + 1).toString();
        } else {
            new StringBuffer(String.valueOf(currZipFile.substring(0, currZipFile.lastIndexOf("."))));
            partFile = stringBuffer.append(".z0").append(this.currSplitFileCounter + 1).toString();
        }
        this.currSplitFileCounter++;
        try {
            if (!Zip4jUtil.checkFileExists(partFile)) {
                Throwable th3 = th2;
                new StringBuffer("zip split file does not exist: ");
                new IOException(stringBuffer3.append(partFile).toString());
                throw th3;
            }
            new RandomAccessFile(partFile, InternalZipConstants.READ_MODE);
            return randomAccessFile;
        } catch (ZipException e) {
            ZipException e2 = e;
            Throwable th4 = th;
            new IOException(e2.getMessage());
            throw th4;
        }
    }

    private void closeStreams(InputStream inputStream, OutputStream outputStream) throws ZipException {
        Throwable th;
        InputStream is = inputStream;
        OutputStream os = outputStream;
        if (is != null) {
            try {
                is.close();
            } catch (IOException e) {
                IOException e2 = e;
                if (e2 != null) {
                    if (Zip4jUtil.isStringNotNullAndNotEmpty(e2.getMessage()) && e2.getMessage().indexOf(" - Wrong Password?") >= 0) {
                        Throwable th2 = th;
                        new ZipException(e2.getMessage());
                        throw th2;
                    }
                }
                if (os != null) {
                    try {
                        os.close();
                        return;
                    } catch (IOException e3) {
                        IOException iOException = e3;
                        return;
                    }
                } else {
                    return;
                }
            } catch (Throwable th3) {
                Throwable th4 = th3;
                if (os != null) {
                    try {
                        os.close();
                    } catch (IOException e4) {
                        IOException iOException2 = e4;
                    }
                }
                throw th4;
            }
        }
        if (os != null) {
            try {
                os.close();
            } catch (IOException e5) {
                IOException iOException3 = e5;
            }
        }
    }

    public void updateCRC(int b) {
        this.crc.update(b);
    }

    public void updateCRC(byte[] bArr, int i, int i2) {
        byte[] buff = bArr;
        int offset = i;
        int len = i2;
        if (buff != null) {
            this.crc.update(buff, offset, len);
        }
    }

    public FileHeader getFileHeader() {
        return this.fileHeader;
    }

    public IDecrypter getDecrypter() {
        return this.decrypter;
    }

    public ZipModel getZipModel() {
        return this.zipModel;
    }

    public LocalFileHeader getLocalFileHeader() {
        return this.localFileHeader;
    }
}
