package net.lingala.zip4j.unzip;

import java.io.File;
import java.util.ArrayList;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.io.ZipInputStream;
import net.lingala.zip4j.model.CentralDirectory;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.UnzipParameters;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.Zip4jUtil;

public class Unzip {
    private ZipModel zipModel;

    public Unzip(ZipModel zipModel2) throws ZipException {
        Throwable th;
        ZipModel zipModel3 = zipModel2;
        if (zipModel3 == null) {
            Throwable th2 = th;
            new ZipException("ZipModel is null");
            throw th2;
        }
        this.zipModel = zipModel3;
    }

    public void extractAll(UnzipParameters unzipParameters, String str, ProgressMonitor progressMonitor, boolean z) throws ZipException {
        Throwable th;
        Thread thread;
        UnzipParameters unzipParameters2 = unzipParameters;
        String outPath = str;
        ProgressMonitor progressMonitor2 = progressMonitor;
        boolean runInThread = z;
        CentralDirectory centralDirectory = this.zipModel.getCentralDirectory();
        if (centralDirectory == null || centralDirectory.getFileHeaders() == null) {
            Throwable th2 = th;
            new ZipException("invalid central directory in zipModel");
            throw th2;
        }
        ArrayList fileHeaders = centralDirectory.getFileHeaders();
        progressMonitor2.setCurrentOperation(1);
        progressMonitor2.setTotalWork(calculateTotalWork(fileHeaders));
        progressMonitor2.setState(1);
        if (runInThread) {
            new Thread(this, InternalZipConstants.THREAD_NAME, fileHeaders, unzipParameters2, progressMonitor2, outPath) {
                final Unzip this$0;
                private final ArrayList val$fileHeaders;
                private final String val$outPath;
                private final ProgressMonitor val$progressMonitor;
                private final UnzipParameters val$unzipParameters;

                {
                    this.this$0 = r10;
                    this.val$fileHeaders = r12;
                    this.val$unzipParameters = r13;
                    this.val$progressMonitor = r14;
                    this.val$outPath = r15;
                }

                public void run() {
                    try {
                        Unzip.access$0(this.this$0, this.val$fileHeaders, this.val$unzipParameters, this.val$progressMonitor, this.val$outPath);
                        this.val$progressMonitor.endProgressMonitorSuccess();
                    } catch (ZipException e) {
                        ZipException zipException = e;
                    }
                }
            };
            thread.start();
            return;
        }
        initExtractAll(fileHeaders, unzipParameters2, progressMonitor2, outPath);
    }

    static void access$0(Unzip unzip, ArrayList arrayList, UnzipParameters unzipParameters, ProgressMonitor progressMonitor, String str) throws ZipException {
        unzip.initExtractAll(arrayList, unzipParameters, progressMonitor, str);
    }

    private void initExtractAll(ArrayList arrayList, UnzipParameters unzipParameters, ProgressMonitor progressMonitor, String str) throws ZipException {
        ArrayList fileHeaders = arrayList;
        UnzipParameters unzipParameters2 = unzipParameters;
        ProgressMonitor progressMonitor2 = progressMonitor;
        String outPath = str;
        for (int i = 0; i < fileHeaders.size(); i++) {
            initExtractFile((FileHeader) fileHeaders.get(i), outPath, unzipParameters2, (String) null, progressMonitor2);
            if (progressMonitor2.isCancelAllTasks()) {
                progressMonitor2.setResult(3);
                progressMonitor2.setState(0);
                return;
            }
        }
    }

    public void extractFile(FileHeader fileHeader, String str, UnzipParameters unzipParameters, String str2, ProgressMonitor progressMonitor, boolean z) throws ZipException {
        Thread thread;
        Throwable th;
        FileHeader fileHeader2 = fileHeader;
        String outPath = str;
        UnzipParameters unzipParameters2 = unzipParameters;
        String newFileName = str2;
        ProgressMonitor progressMonitor2 = progressMonitor;
        boolean runInThread = z;
        if (fileHeader2 == null) {
            Throwable th2 = th;
            new ZipException("fileHeader is null");
            throw th2;
        }
        progressMonitor2.setCurrentOperation(1);
        progressMonitor2.setTotalWork(fileHeader2.getCompressedSize());
        progressMonitor2.setState(1);
        progressMonitor2.setPercentDone(0);
        progressMonitor2.setFileName(fileHeader2.getFileName());
        if (runInThread) {
            new Thread(this, InternalZipConstants.THREAD_NAME, fileHeader2, outPath, unzipParameters2, newFileName, progressMonitor2) {
                final Unzip this$0;
                private final FileHeader val$fileHeader;
                private final String val$newFileName;
                private final String val$outPath;
                private final ProgressMonitor val$progressMonitor;
                private final UnzipParameters val$unzipParameters;

                {
                    this.this$0 = r11;
                    this.val$fileHeader = r13;
                    this.val$outPath = r14;
                    this.val$unzipParameters = r15;
                    this.val$newFileName = r16;
                    this.val$progressMonitor = r17;
                }

                public void run() {
                    try {
                        Unzip.access$1(this.this$0, this.val$fileHeader, this.val$outPath, this.val$unzipParameters, this.val$newFileName, this.val$progressMonitor);
                        this.val$progressMonitor.endProgressMonitorSuccess();
                    } catch (ZipException e) {
                        ZipException zipException = e;
                    }
                }
            };
            thread.start();
            return;
        }
        initExtractFile(fileHeader2, outPath, unzipParameters2, newFileName, progressMonitor2);
        progressMonitor2.endProgressMonitorSuccess();
    }

    static void access$1(Unzip unzip, FileHeader fileHeader, String str, UnzipParameters unzipParameters, String str2, ProgressMonitor progressMonitor) throws ZipException {
        unzip.initExtractFile(fileHeader, str, unzipParameters, str2, progressMonitor);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0098, code lost:
        r9 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0099, code lost:
        r6 = r9;
        r5.endProgressMonitorError(r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x00a0, code lost:
        throw r6;
     */
    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0098 A[ExcHandler: ZipException (r9v6 'e' net.lingala.zip4j.exception.ZipException A[CUSTOM_DECLARE]), Splitter:B:5:0x001c] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void initExtractFile(net.lingala.zip4j.model.FileHeader r16, java.lang.String r17, net.lingala.zip4j.model.UnzipParameters r18, java.lang.String r19, net.lingala.zip4j.progress.ProgressMonitor r20) throws net.lingala.zip4j.exception.ZipException {
        /*
            r15 = this;
            r0 = r15
            r1 = r16
            r2 = r17
            r3 = r18
            r4 = r19
            r5 = r20
            r9 = r1
            if (r9 != 0) goto L_0x001a
            net.lingala.zip4j.exception.ZipException r9 = new net.lingala.zip4j.exception.ZipException
            r14 = r9
            r9 = r14
            r10 = r14
            java.lang.String r11 = "fileHeader is null"
            r10.<init>((java.lang.String) r11)
            throw r9
        L_0x001a:
            r9 = r5
            r10 = r1
            java.lang.String r10 = r10.getFileName()     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            r9.setFileName(r10)     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            r9 = r2
            java.lang.String r10 = net.lingala.zip4j.util.InternalZipConstants.FILE_SEPARATOR     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            boolean r9 = r9.endsWith(r10)     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            if (r9 != 0) goto L_0x0044
            java.lang.StringBuffer r9 = new java.lang.StringBuffer     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r2
            java.lang.String r11 = java.lang.String.valueOf(r11)     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            r10.<init>(r11)     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            java.lang.String r10 = net.lingala.zip4j.util.InternalZipConstants.FILE_SEPARATOR     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            java.lang.StringBuffer r9 = r9.append(r10)     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            java.lang.String r9 = r9.toString()     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            r2 = r9
        L_0x0044:
            r9 = r1
            boolean r9 = r9.isDirectory()     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            if (r9 == 0) goto L_0x00a1
            r9 = r1
            java.lang.String r9 = r9.getFileName()     // Catch:{ Exception -> 0x0087, ZipException -> 0x0098 }
            r6 = r9
            r9 = r6
            boolean r9 = net.lingala.zip4j.util.Zip4jUtil.isStringNotNullAndNotEmpty(r9)     // Catch:{ Exception -> 0x0087, ZipException -> 0x0098 }
            if (r9 != 0) goto L_0x0059
        L_0x0058:
            return
        L_0x0059:
            java.lang.StringBuffer r9 = new java.lang.StringBuffer     // Catch:{ Exception -> 0x0087, ZipException -> 0x0098 }
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r2
            java.lang.String r11 = java.lang.String.valueOf(r11)     // Catch:{ Exception -> 0x0087, ZipException -> 0x0098 }
            r10.<init>(r11)     // Catch:{ Exception -> 0x0087, ZipException -> 0x0098 }
            r10 = r6
            java.lang.StringBuffer r9 = r9.append(r10)     // Catch:{ Exception -> 0x0087, ZipException -> 0x0098 }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x0087, ZipException -> 0x0098 }
            r7 = r9
            java.io.File r9 = new java.io.File     // Catch:{ Exception -> 0x0087, ZipException -> 0x0098 }
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r7
            r10.<init>(r11)     // Catch:{ Exception -> 0x0087, ZipException -> 0x0098 }
            r8 = r9
            r9 = r8
            boolean r9 = r9.exists()     // Catch:{ Exception -> 0x0087, ZipException -> 0x0098 }
            if (r9 != 0) goto L_0x0086
            r9 = r8
            boolean r9 = r9.mkdirs()     // Catch:{ Exception -> 0x0087, ZipException -> 0x0098 }
        L_0x0086:
            goto L_0x0058
        L_0x0087:
            r9 = move-exception
            r6 = r9
            r9 = r5
            r10 = r6
            r9.endProgressMonitorError(r10)     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            net.lingala.zip4j.exception.ZipException r9 = new net.lingala.zip4j.exception.ZipException     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r6
            r10.<init>((java.lang.Throwable) r11)     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            throw r9     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
        L_0x0098:
            r9 = move-exception
            r6 = r9
            r9 = r5
            r10 = r6
            r9.endProgressMonitorError(r10)
            r9 = r6
            throw r9
        L_0x00a1:
            r9 = r0
            r10 = r1
            r11 = r2
            r12 = r4
            r9.checkOutputDirectoryStructure(r10, r11, r12)     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            net.lingala.zip4j.unzip.UnzipEngine r9 = new net.lingala.zip4j.unzip.UnzipEngine     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r0
            net.lingala.zip4j.model.ZipModel r11 = r11.zipModel     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            r12 = r1
            r10.<init>(r11, r12)     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            r6 = r9
            r9 = r6
            r10 = r5
            r11 = r2
            r12 = r4
            r13 = r3
            r9.unzipFile(r10, r11, r12, r13)     // Catch:{ Exception -> 0x00be, ZipException -> 0x0098 }
            goto L_0x0086
        L_0x00be:
            r9 = move-exception
            r7 = r9
            r9 = r5
            r10 = r7
            r9.endProgressMonitorError(r10)     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            net.lingala.zip4j.exception.ZipException r9 = new net.lingala.zip4j.exception.ZipException     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r7
            r10.<init>((java.lang.Throwable) r11)     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
            throw r9     // Catch:{ ZipException -> 0x0098, Exception -> 0x00cf }
        L_0x00cf:
            r9 = move-exception
            r6 = r9
            r9 = r5
            r10 = r6
            r9.endProgressMonitorError(r10)
            net.lingala.zip4j.exception.ZipException r9 = new net.lingala.zip4j.exception.ZipException
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = r6
            r10.<init>((java.lang.Throwable) r11)
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: net.lingala.zip4j.unzip.Unzip.initExtractFile(net.lingala.zip4j.model.FileHeader, java.lang.String, net.lingala.zip4j.model.UnzipParameters, java.lang.String, net.lingala.zip4j.progress.ProgressMonitor):void");
    }

    public ZipInputStream getInputStream(FileHeader fileHeader) throws ZipException {
        UnzipEngine unzipEngine;
        new UnzipEngine(this.zipModel, fileHeader);
        return unzipEngine.getInputStream();
    }

    private void checkOutputDirectoryStructure(FileHeader fileHeader, String str, String str2) throws ZipException {
        Throwable th;
        StringBuffer stringBuffer;
        Throwable th2;
        File file;
        File file2;
        FileHeader fileHeader2 = fileHeader;
        String outPath = str;
        String newFileName = str2;
        if (fileHeader2 == null || !Zip4jUtil.isStringNotNullAndNotEmpty(outPath)) {
            Throwable th3 = th;
            new ZipException("Cannot check output directory structure...one of the parameters was null");
            throw th3;
        }
        String fileName = fileHeader2.getFileName();
        if (Zip4jUtil.isStringNotNullAndNotEmpty(newFileName)) {
            fileName = newFileName;
        }
        if (Zip4jUtil.isStringNotNullAndNotEmpty(fileName)) {
            new StringBuffer(String.valueOf(outPath));
            try {
                new File(stringBuffer.append(fileName).toString());
                new File(file.getParent());
                File parentDirFile = file2;
                if (!parentDirFile.exists()) {
                    boolean mkdirs = parentDirFile.mkdirs();
                }
            } catch (Exception e) {
                Exception e2 = e;
                Throwable th4 = th2;
                new ZipException((Throwable) e2);
                throw th4;
            }
        }
    }

    private long calculateTotalWork(ArrayList arrayList) throws ZipException {
        long j;
        long compressedSize;
        Throwable th;
        ArrayList fileHeaders = arrayList;
        if (fileHeaders == null) {
            Throwable th2 = th;
            new ZipException("fileHeaders is null, cannot calculate total work");
            throw th2;
        }
        long totalWork = 0;
        for (int i = 0; i < fileHeaders.size(); i++) {
            FileHeader fileHeader = (FileHeader) fileHeaders.get(i);
            if (fileHeader.getZip64ExtendedInfo() == null || fileHeader.getZip64ExtendedInfo().getUnCompressedSize() <= 0) {
                j = totalWork;
                compressedSize = fileHeader.getCompressedSize();
            } else {
                j = totalWork;
                compressedSize = fileHeader.getZip64ExtendedInfo().getCompressedSize();
            }
            totalWork = j + compressedSize;
        }
        return totalWork;
    }
}
