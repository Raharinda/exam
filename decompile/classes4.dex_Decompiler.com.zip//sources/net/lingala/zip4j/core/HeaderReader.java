package net.lingala.zip4j.core;

import com.microsoft.appcenter.Constants;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.AESExtraDataRecord;
import net.lingala.zip4j.model.CentralDirectory;
import net.lingala.zip4j.model.DigitalSignature;
import net.lingala.zip4j.model.EndCentralDirRecord;
import net.lingala.zip4j.model.ExtraDataRecord;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.model.Zip64EndCentralDirLocator;
import net.lingala.zip4j.model.Zip64EndCentralDirRecord;
import net.lingala.zip4j.model.Zip64ExtendedInfo;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.Raw;
import net.lingala.zip4j.util.Zip4jUtil;

public class HeaderReader {
    private RandomAccessFile zip4jRaf = null;
    private ZipModel zipModel;

    public HeaderReader(RandomAccessFile zip4jRaf2) {
        this.zip4jRaf = zip4jRaf2;
    }

    public ZipModel readAllHeaders() throws ZipException {
        return readAllHeaders((String) null);
    }

    public ZipModel readAllHeaders(String fileNameCharset) throws ZipException {
        ZipModel zipModel2;
        new ZipModel();
        this.zipModel = zipModel2;
        this.zipModel.setFileNameCharset(fileNameCharset);
        this.zipModel.setEndCentralDirRecord(readEndOfCentralDirectoryRecord());
        this.zipModel.setZip64EndCentralDirLocator(readZip64EndCentralDirLocator());
        if (this.zipModel.isZip64Format()) {
            this.zipModel.setZip64EndCentralDirRecord(readZip64EndCentralDirRec());
            if (this.zipModel.getZip64EndCentralDirRecord() == null || this.zipModel.getZip64EndCentralDirRecord().getNoOfThisDisk() <= 0) {
                this.zipModel.setSplitArchive(false);
            } else {
                this.zipModel.setSplitArchive(true);
            }
        }
        this.zipModel.setCentralDirectory(readCentralDirectory());
        return this.zipModel;
    }

    private EndCentralDirRecord readEndOfCentralDirectoryRecord() throws ZipException {
        Throwable th;
        EndCentralDirRecord endCentralDirRecord;
        String str;
        Throwable th2;
        Throwable th3;
        if (this.zip4jRaf == null) {
            Throwable th4 = th3;
            new ZipException("random access file was null", 3);
            throw th4;
        }
        try {
            byte[] ebs = new byte[4];
            long pos = this.zip4jRaf.length() - 22;
            new EndCentralDirRecord();
            EndCentralDirRecord endCentralDirRecord2 = endCentralDirRecord;
            int counter = 0;
            do {
                long j = pos;
                pos = j - 1;
                this.zip4jRaf.seek(j);
                counter++;
                if (((long) Raw.readLeInt(this.zip4jRaf, ebs)) == InternalZipConstants.ENDSIG || counter > 3000) {
                }
                long j2 = pos;
                pos = j2 - 1;
                this.zip4jRaf.seek(j2);
                counter++;
                break;
            } while (counter > 3000);
            if (((long) Raw.readIntLittleEndian(ebs, 0)) != InternalZipConstants.ENDSIG) {
                Throwable th5 = th2;
                new ZipException("zip headers not found. probably not a zip file");
                throw th5;
            }
            byte[] intBuff = new byte[4];
            byte[] shortBuff = new byte[2];
            endCentralDirRecord2.setSignature(InternalZipConstants.ENDSIG);
            byte[] readIntoBuff = readIntoBuff(this.zip4jRaf, shortBuff);
            endCentralDirRecord2.setNoOfThisDisk(Raw.readShortLittleEndian(shortBuff, 0));
            byte[] readIntoBuff2 = readIntoBuff(this.zip4jRaf, shortBuff);
            endCentralDirRecord2.setNoOfThisDiskStartOfCentralDir(Raw.readShortLittleEndian(shortBuff, 0));
            byte[] readIntoBuff3 = readIntoBuff(this.zip4jRaf, shortBuff);
            endCentralDirRecord2.setTotNoOfEntriesInCentralDirOnThisDisk(Raw.readShortLittleEndian(shortBuff, 0));
            byte[] readIntoBuff4 = readIntoBuff(this.zip4jRaf, shortBuff);
            endCentralDirRecord2.setTotNoOfEntriesInCentralDir(Raw.readShortLittleEndian(shortBuff, 0));
            byte[] readIntoBuff5 = readIntoBuff(this.zip4jRaf, intBuff);
            endCentralDirRecord2.setSizeOfCentralDir(Raw.readIntLittleEndian(intBuff, 0));
            byte[] readIntoBuff6 = readIntoBuff(this.zip4jRaf, intBuff);
            endCentralDirRecord2.setOffsetOfStartOfCentralDir(Raw.readLongLittleEndian(getLongByteFromIntByte(intBuff), 0));
            byte[] readIntoBuff7 = readIntoBuff(this.zip4jRaf, shortBuff);
            int commentLength = Raw.readShortLittleEndian(shortBuff, 0);
            endCentralDirRecord2.setCommentLength(commentLength);
            if (commentLength > 0) {
                byte[] commentBuf = new byte[commentLength];
                byte[] readIntoBuff8 = readIntoBuff(this.zip4jRaf, commentBuf);
                new String(commentBuf);
                endCentralDirRecord2.setComment(str);
                endCentralDirRecord2.setCommentBytes(commentBuf);
            } else {
                endCentralDirRecord2.setComment((String) null);
            }
            if (endCentralDirRecord2.getNoOfThisDisk() > 0) {
                this.zipModel.setSplitArchive(true);
            } else {
                this.zipModel.setSplitArchive(false);
            }
            return endCentralDirRecord2;
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th6 = th;
            new ZipException("Probably not a zip file or a corrupted zip file", e2, 4);
            throw th6;
        }
    }

    private CentralDirectory readCentralDirectory() throws ZipException {
        Throwable th;
        CentralDirectory centralDirectory;
        ArrayList arrayList;
        DigitalSignature digitalSignature;
        String str;
        FileHeader fileHeader;
        Throwable th2;
        StringBuffer stringBuffer;
        String str2;
        String str3;
        String fileName;
        Throwable th3;
        StringBuffer stringBuffer2;
        StringBuffer stringBuffer3;
        String str4;
        Throwable th4;
        Throwable th5;
        if (this.zip4jRaf == null) {
            Throwable th6 = th5;
            new ZipException("random access file was null", 3);
            throw th6;
        }
        if (this.zipModel.getEndCentralDirRecord() == null) {
            Throwable th7 = th4;
            new ZipException("EndCentralRecord was null, maybe a corrupt zip file");
            throw th7;
        }
        try {
            new CentralDirectory();
            CentralDirectory centralDirectory2 = centralDirectory;
            new ArrayList();
            ArrayList fileHeaderList = arrayList;
            EndCentralDirRecord endCentralDirRecord = this.zipModel.getEndCentralDirRecord();
            long offSetStartCentralDir = endCentralDirRecord.getOffsetOfStartOfCentralDir();
            int centralDirEntryCount = endCentralDirRecord.getTotNoOfEntriesInCentralDir();
            if (this.zipModel.isZip64Format()) {
                offSetStartCentralDir = this.zipModel.getZip64EndCentralDirRecord().getOffsetStartCenDirWRTStartDiskNo();
                centralDirEntryCount = (int) this.zipModel.getZip64EndCentralDirRecord().getTotNoOfEntriesInCentralDir();
            }
            this.zip4jRaf.seek(offSetStartCentralDir);
            byte[] intBuff = new byte[4];
            byte[] shortBuff = new byte[2];
            byte[] bArr = new byte[8];
            for (int i = 0; i < centralDirEntryCount; i++) {
                new FileHeader();
                FileHeader fileHeader2 = fileHeader;
                byte[] readIntoBuff = readIntoBuff(this.zip4jRaf, intBuff);
                int signature = Raw.readIntLittleEndian(intBuff, 0);
                if (((long) signature) != InternalZipConstants.CENSIG) {
                    Throwable th8 = th2;
                    new StringBuffer("Expected central directory entry not found (#");
                    new ZipException(stringBuffer.append(i + 1).append(")").toString());
                    throw th8;
                }
                fileHeader2.setSignature(signature);
                byte[] readIntoBuff2 = readIntoBuff(this.zip4jRaf, shortBuff);
                fileHeader2.setVersionMadeBy(Raw.readShortLittleEndian(shortBuff, 0));
                byte[] readIntoBuff3 = readIntoBuff(this.zip4jRaf, shortBuff);
                fileHeader2.setVersionNeededToExtract(Raw.readShortLittleEndian(shortBuff, 0));
                byte[] readIntoBuff4 = readIntoBuff(this.zip4jRaf, shortBuff);
                fileHeader2.setFileNameUTF8Encoded((Raw.readShortLittleEndian(shortBuff, 0) & InternalZipConstants.UFT8_NAMES_FLAG) != 0);
                int firstByte = shortBuff[0];
                if ((firstByte & 1) != 0) {
                    fileHeader2.setEncrypted(true);
                }
                fileHeader2.setGeneralPurposeFlag((byte[]) shortBuff.clone());
                fileHeader2.setDataDescriptorExists((firstByte >> 3) == 1);
                byte[] readIntoBuff5 = readIntoBuff(this.zip4jRaf, shortBuff);
                fileHeader2.setCompressionMethod(Raw.readShortLittleEndian(shortBuff, 0));
                byte[] readIntoBuff6 = readIntoBuff(this.zip4jRaf, intBuff);
                fileHeader2.setLastModFileTime(Raw.readIntLittleEndian(intBuff, 0));
                byte[] readIntoBuff7 = readIntoBuff(this.zip4jRaf, intBuff);
                fileHeader2.setCrc32((long) Raw.readIntLittleEndian(intBuff, 0));
                fileHeader2.setCrcBuff((byte[]) intBuff.clone());
                byte[] readIntoBuff8 = readIntoBuff(this.zip4jRaf, intBuff);
                fileHeader2.setCompressedSize(Raw.readLongLittleEndian(getLongByteFromIntByte(intBuff), 0));
                byte[] readIntoBuff9 = readIntoBuff(this.zip4jRaf, intBuff);
                fileHeader2.setUncompressedSize(Raw.readLongLittleEndian(getLongByteFromIntByte(intBuff), 0));
                byte[] readIntoBuff10 = readIntoBuff(this.zip4jRaf, shortBuff);
                int fileNameLength = Raw.readShortLittleEndian(shortBuff, 0);
                fileHeader2.setFileNameLength(fileNameLength);
                byte[] readIntoBuff11 = readIntoBuff(this.zip4jRaf, shortBuff);
                fileHeader2.setExtraFieldLength(Raw.readShortLittleEndian(shortBuff, 0));
                byte[] readIntoBuff12 = readIntoBuff(this.zip4jRaf, shortBuff);
                int fileCommentLength = Raw.readShortLittleEndian(shortBuff, 0);
                new String(shortBuff);
                fileHeader2.setFileComment(str2);
                byte[] readIntoBuff13 = readIntoBuff(this.zip4jRaf, shortBuff);
                fileHeader2.setDiskNumberStart(Raw.readShortLittleEndian(shortBuff, 0));
                byte[] readIntoBuff14 = readIntoBuff(this.zip4jRaf, shortBuff);
                fileHeader2.setInternalFileAttr((byte[]) shortBuff.clone());
                byte[] readIntoBuff15 = readIntoBuff(this.zip4jRaf, intBuff);
                fileHeader2.setExternalFileAttr((byte[]) intBuff.clone());
                byte[] readIntoBuff16 = readIntoBuff(this.zip4jRaf, intBuff);
                fileHeader2.setOffsetLocalHeader(Raw.readLongLittleEndian(getLongByteFromIntByte(intBuff), 0) & InternalZipConstants.ZIP_64_LIMIT);
                if (fileNameLength > 0) {
                    byte[] fileNameBuf = new byte[fileNameLength];
                    byte[] readIntoBuff17 = readIntoBuff(this.zip4jRaf, fileNameBuf);
                    if (Zip4jUtil.isStringNotNullAndNotEmpty(this.zipModel.getFileNameCharset())) {
                        new String(fileNameBuf, this.zipModel.getFileNameCharset());
                        fileName = str4;
                    } else {
                        fileName = Zip4jUtil.decodeFileName(fileNameBuf, fileHeader2.isFileNameUTF8Encoded());
                    }
                    if (fileName == null) {
                        Throwable th9 = th3;
                        new ZipException("fileName is null when reading central directory");
                        throw th9;
                    }
                    new StringBuffer(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR);
                    if (fileName.indexOf(stringBuffer2.append(System.getProperty("file.separator")).toString()) >= 0) {
                        new StringBuffer(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR);
                        fileName = fileName.substring(fileName.indexOf(stringBuffer3.append(System.getProperty("file.separator")).toString()) + 2);
                    }
                    fileHeader2.setFileName(fileName);
                    fileHeader2.setDirectory(fileName.endsWith(InternalZipConstants.ZIP_FILE_SEPARATOR) || fileName.endsWith("\\"));
                } else {
                    fileHeader2.setFileName((String) null);
                }
                readAndSaveExtraDataRecord(fileHeader2);
                readAndSaveZip64ExtendedInfo(fileHeader2);
                readAndSaveAESExtraDataRecord(fileHeader2);
                if (fileCommentLength > 0) {
                    byte[] fileCommentBuf = new byte[fileCommentLength];
                    byte[] readIntoBuff18 = readIntoBuff(this.zip4jRaf, fileCommentBuf);
                    new String(fileCommentBuf);
                    fileHeader2.setFileComment(str3);
                }
                boolean add = fileHeaderList.add(fileHeader2);
            }
            centralDirectory2.setFileHeaders(fileHeaderList);
            new DigitalSignature();
            DigitalSignature digitalSignature2 = digitalSignature;
            byte[] readIntoBuff19 = readIntoBuff(this.zip4jRaf, intBuff);
            int signature2 = Raw.readIntLittleEndian(intBuff, 0);
            if (((long) signature2) != InternalZipConstants.DIGSIG) {
                return centralDirectory2;
            }
            digitalSignature2.setHeaderSignature(signature2);
            byte[] readIntoBuff20 = readIntoBuff(this.zip4jRaf, shortBuff);
            int sizeOfData = Raw.readShortLittleEndian(shortBuff, 0);
            digitalSignature2.setSizeOfData(sizeOfData);
            if (sizeOfData > 0) {
                byte[] sigDataBuf = new byte[sizeOfData];
                byte[] readIntoBuff21 = readIntoBuff(this.zip4jRaf, sigDataBuf);
                new String(sigDataBuf);
                digitalSignature2.setSignatureData(str);
            }
            return centralDirectory2;
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th10 = th;
            new ZipException((Throwable) e2);
            throw th10;
        }
    }

    private void readAndSaveExtraDataRecord(FileHeader fileHeader) throws ZipException {
        Throwable th;
        Throwable th2;
        FileHeader fileHeader2 = fileHeader;
        if (this.zip4jRaf == null) {
            Throwable th3 = th2;
            new ZipException("invalid file handler when trying to read extra data record");
            throw th3;
        } else if (fileHeader2 == null) {
            Throwable th4 = th;
            new ZipException("file header is null");
            throw th4;
        } else {
            int extraFieldLength = fileHeader2.getExtraFieldLength();
            if (extraFieldLength > 0) {
                fileHeader2.setExtraDataRecords(readExtraDataRecords(extraFieldLength));
            }
        }
    }

    private void readAndSaveExtraDataRecord(LocalFileHeader localFileHeader) throws ZipException {
        Throwable th;
        Throwable th2;
        LocalFileHeader localFileHeader2 = localFileHeader;
        if (this.zip4jRaf == null) {
            Throwable th3 = th2;
            new ZipException("invalid file handler when trying to read extra data record");
            throw th3;
        } else if (localFileHeader2 == null) {
            Throwable th4 = th;
            new ZipException("file header is null");
            throw th4;
        } else {
            int extraFieldLength = localFileHeader2.getExtraFieldLength();
            if (extraFieldLength > 0) {
                localFileHeader2.setExtraDataRecords(readExtraDataRecords(extraFieldLength));
            }
        }
    }

    private ArrayList readExtraDataRecords(int i) throws ZipException {
        Throwable th;
        ArrayList arrayList;
        ExtraDataRecord extraDataRecord;
        int extraFieldLength = i;
        if (extraFieldLength <= 0) {
            return null;
        }
        try {
            byte[] extraFieldBuf = new byte[extraFieldLength];
            int read = this.zip4jRaf.read(extraFieldBuf);
            int counter = 0;
            new ArrayList();
            ArrayList extraDataList = arrayList;
            while (true) {
                if (counter >= extraFieldLength) {
                    break;
                }
                new ExtraDataRecord();
                ExtraDataRecord extraDataRecord2 = extraDataRecord;
                extraDataRecord2.setHeader((long) Raw.readShortLittleEndian(extraFieldBuf, counter));
                int counter2 = counter + 2;
                int sizeOfRec = Raw.readShortLittleEndian(extraFieldBuf, counter2);
                if (2 + sizeOfRec > extraFieldLength) {
                    sizeOfRec = Raw.readShortBigEndian(extraFieldBuf, counter2);
                    if (2 + sizeOfRec > extraFieldLength) {
                        break;
                    }
                }
                extraDataRecord2.setSizeOfData(sizeOfRec);
                int counter3 = counter2 + 2;
                if (sizeOfRec > 0) {
                    byte[] data = new byte[sizeOfRec];
                    System.arraycopy(extraFieldBuf, counter3, data, 0, sizeOfRec);
                    extraDataRecord2.setData(data);
                }
                counter = counter3 + sizeOfRec;
                boolean add = extraDataList.add(extraDataRecord2);
            }
            if (extraDataList.size() > 0) {
                return extraDataList;
            }
            return null;
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th2 = th;
            new ZipException((Throwable) e2);
            throw th2;
        }
    }

    private Zip64EndCentralDirLocator readZip64EndCentralDirLocator() throws ZipException {
        Throwable th;
        Zip64EndCentralDirLocator zip64EndCentralDirLocator;
        Throwable th2;
        if (this.zip4jRaf == null) {
            Throwable th3 = th2;
            new ZipException("invalid file handler when trying to read Zip64EndCentralDirLocator");
            throw th3;
        }
        try {
            new Zip64EndCentralDirLocator();
            Zip64EndCentralDirLocator zip64EndCentralDirLocator2 = zip64EndCentralDirLocator;
            setFilePointerToReadZip64EndCentralDirLoc();
            byte[] intBuff = new byte[4];
            byte[] longBuff = new byte[8];
            byte[] readIntoBuff = readIntoBuff(this.zip4jRaf, intBuff);
            int signature = Raw.readIntLittleEndian(intBuff, 0);
            if (((long) signature) == InternalZipConstants.ZIP64ENDCENDIRLOC) {
                this.zipModel.setZip64Format(true);
                zip64EndCentralDirLocator2.setSignature((long) signature);
                byte[] readIntoBuff2 = readIntoBuff(this.zip4jRaf, intBuff);
                zip64EndCentralDirLocator2.setNoOfDiskStartOfZip64EndOfCentralDirRec(Raw.readIntLittleEndian(intBuff, 0));
                byte[] readIntoBuff3 = readIntoBuff(this.zip4jRaf, longBuff);
                zip64EndCentralDirLocator2.setOffsetZip64EndOfCentralDirRec(Raw.readLongLittleEndian(longBuff, 0));
                byte[] readIntoBuff4 = readIntoBuff(this.zip4jRaf, intBuff);
                zip64EndCentralDirLocator2.setTotNumberOfDiscs(Raw.readIntLittleEndian(intBuff, 0));
                return zip64EndCentralDirLocator2;
            }
            this.zipModel.setZip64Format(false);
            return null;
        } catch (Exception e) {
            Exception e2 = e;
            Throwable th4 = th;
            new ZipException((Throwable) e2);
            throw th4;
        }
    }

    private Zip64EndCentralDirRecord readZip64EndCentralDirRec() throws ZipException {
        Throwable th;
        Zip64EndCentralDirRecord zip64EndCentralDirRecord;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        if (this.zipModel.getZip64EndCentralDirLocator() == null) {
            Throwable th5 = th4;
            new ZipException("invalid zip64 end of central directory locator");
            throw th5;
        }
        long offSetStartOfZip64CentralDir = this.zipModel.getZip64EndCentralDirLocator().getOffsetZip64EndOfCentralDirRec();
        if (offSetStartOfZip64CentralDir < 0) {
            Throwable th6 = th3;
            new ZipException("invalid offset for start of end of central directory record");
            throw th6;
        }
        try {
            this.zip4jRaf.seek(offSetStartOfZip64CentralDir);
            new Zip64EndCentralDirRecord();
            Zip64EndCentralDirRecord zip64EndCentralDirRecord2 = zip64EndCentralDirRecord;
            byte[] shortBuff = new byte[2];
            byte[] intBuff = new byte[4];
            byte[] longBuff = new byte[8];
            byte[] readIntoBuff = readIntoBuff(this.zip4jRaf, intBuff);
            int signature = Raw.readIntLittleEndian(intBuff, 0);
            if (((long) signature) != InternalZipConstants.ZIP64ENDCENDIRREC) {
                Throwable th7 = th2;
                new ZipException("invalid signature for zip64 end of central directory record");
                throw th7;
            }
            zip64EndCentralDirRecord2.setSignature((long) signature);
            byte[] readIntoBuff2 = readIntoBuff(this.zip4jRaf, longBuff);
            zip64EndCentralDirRecord2.setSizeOfZip64EndCentralDirRec(Raw.readLongLittleEndian(longBuff, 0));
            byte[] readIntoBuff3 = readIntoBuff(this.zip4jRaf, shortBuff);
            zip64EndCentralDirRecord2.setVersionMadeBy(Raw.readShortLittleEndian(shortBuff, 0));
            byte[] readIntoBuff4 = readIntoBuff(this.zip4jRaf, shortBuff);
            zip64EndCentralDirRecord2.setVersionNeededToExtract(Raw.readShortLittleEndian(shortBuff, 0));
            byte[] readIntoBuff5 = readIntoBuff(this.zip4jRaf, intBuff);
            zip64EndCentralDirRecord2.setNoOfThisDisk(Raw.readIntLittleEndian(intBuff, 0));
            byte[] readIntoBuff6 = readIntoBuff(this.zip4jRaf, intBuff);
            zip64EndCentralDirRecord2.setNoOfThisDiskStartOfCentralDir(Raw.readIntLittleEndian(intBuff, 0));
            byte[] readIntoBuff7 = readIntoBuff(this.zip4jRaf, longBuff);
            zip64EndCentralDirRecord2.setTotNoOfEntriesInCentralDirOnThisDisk(Raw.readLongLittleEndian(longBuff, 0));
            byte[] readIntoBuff8 = readIntoBuff(this.zip4jRaf, longBuff);
            zip64EndCentralDirRecord2.setTotNoOfEntriesInCentralDir(Raw.readLongLittleEndian(longBuff, 0));
            byte[] readIntoBuff9 = readIntoBuff(this.zip4jRaf, longBuff);
            zip64EndCentralDirRecord2.setSizeOfCentralDir(Raw.readLongLittleEndian(longBuff, 0));
            byte[] readIntoBuff10 = readIntoBuff(this.zip4jRaf, longBuff);
            zip64EndCentralDirRecord2.setOffsetStartCenDirWRTStartDiskNo(Raw.readLongLittleEndian(longBuff, 0));
            long extDataSecSize = zip64EndCentralDirRecord2.getSizeOfZip64EndCentralDirRec() - 44;
            if (extDataSecSize > 0) {
                byte[] extDataSecRecBuf = new byte[((int) extDataSecSize)];
                byte[] readIntoBuff11 = readIntoBuff(this.zip4jRaf, extDataSecRecBuf);
                zip64EndCentralDirRecord2.setExtensibleDataSector(extDataSecRecBuf);
            }
            return zip64EndCentralDirRecord2;
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th8 = th;
            new ZipException((Throwable) e2);
            throw th8;
        }
    }

    private void readAndSaveZip64ExtendedInfo(FileHeader fileHeader) throws ZipException {
        Zip64ExtendedInfo zip64ExtendedInfo;
        Throwable th;
        FileHeader fileHeader2 = fileHeader;
        if (fileHeader2 == null) {
            Throwable th2 = th;
            new ZipException("file header is null in reading Zip64 Extended Info");
            throw th2;
        } else if (fileHeader2.getExtraDataRecords() != null && fileHeader2.getExtraDataRecords().size() > 0 && (zip64ExtendedInfo = readZip64ExtendedInfo(fileHeader2.getExtraDataRecords(), fileHeader2.getUncompressedSize(), fileHeader2.getCompressedSize(), fileHeader2.getOffsetLocalHeader(), fileHeader2.getDiskNumberStart())) != null) {
            fileHeader2.setZip64ExtendedInfo(zip64ExtendedInfo);
            if (zip64ExtendedInfo.getUnCompressedSize() != -1) {
                fileHeader2.setUncompressedSize(zip64ExtendedInfo.getUnCompressedSize());
            }
            if (zip64ExtendedInfo.getCompressedSize() != -1) {
                fileHeader2.setCompressedSize(zip64ExtendedInfo.getCompressedSize());
            }
            if (zip64ExtendedInfo.getOffsetLocalHeader() != -1) {
                fileHeader2.setOffsetLocalHeader(zip64ExtendedInfo.getOffsetLocalHeader());
            }
            if (zip64ExtendedInfo.getDiskNumberStart() != -1) {
                fileHeader2.setDiskNumberStart(zip64ExtendedInfo.getDiskNumberStart());
            }
        }
    }

    private void readAndSaveZip64ExtendedInfo(LocalFileHeader localFileHeader) throws ZipException {
        Zip64ExtendedInfo zip64ExtendedInfo;
        Throwable th;
        LocalFileHeader localFileHeader2 = localFileHeader;
        if (localFileHeader2 == null) {
            Throwable th2 = th;
            new ZipException("file header is null in reading Zip64 Extended Info");
            throw th2;
        } else if (localFileHeader2.getExtraDataRecords() != null && localFileHeader2.getExtraDataRecords().size() > 0 && (zip64ExtendedInfo = readZip64ExtendedInfo(localFileHeader2.getExtraDataRecords(), localFileHeader2.getUncompressedSize(), localFileHeader2.getCompressedSize(), -1, -1)) != null) {
            localFileHeader2.setZip64ExtendedInfo(zip64ExtendedInfo);
            if (zip64ExtendedInfo.getUnCompressedSize() != -1) {
                localFileHeader2.setUncompressedSize(zip64ExtendedInfo.getUnCompressedSize());
            }
            if (zip64ExtendedInfo.getCompressedSize() != -1) {
                localFileHeader2.setCompressedSize(zip64ExtendedInfo.getCompressedSize());
            }
        }
    }

    private Zip64ExtendedInfo readZip64ExtendedInfo(ArrayList arrayList, long j, long j2, long j3, int i) throws ZipException {
        Zip64ExtendedInfo zip64ExtendedInfo;
        ArrayList extraDataRecords = arrayList;
        long unCompressedSize = j;
        long compressedSize = j2;
        long offsetLocalHeader = j3;
        int diskNumberStart = i;
        int i2 = 0;
        while (true) {
            if (i2 >= extraDataRecords.size()) {
                break;
            }
            ExtraDataRecord extraDataRecord = (ExtraDataRecord) extraDataRecords.get(i2);
            if (extraDataRecord != null && extraDataRecord.getHeader() == 1) {
                new Zip64ExtendedInfo();
                Zip64ExtendedInfo zip64ExtendedInfo2 = zip64ExtendedInfo;
                byte[] byteBuff = extraDataRecord.getData();
                if (extraDataRecord.getSizeOfData() > 0) {
                    byte[] longByteBuff = new byte[8];
                    byte[] intByteBuff = new byte[4];
                    int counter = 0;
                    boolean valueAdded = false;
                    if ((unCompressedSize & 65535) == 65535 && 0 < extraDataRecord.getSizeOfData()) {
                        System.arraycopy(byteBuff, 0, longByteBuff, 0, 8);
                        zip64ExtendedInfo2.setUnCompressedSize(Raw.readLongLittleEndian(longByteBuff, 0));
                        counter = 0 + 8;
                        valueAdded = true;
                    }
                    if ((compressedSize & 65535) == 65535 && counter < extraDataRecord.getSizeOfData()) {
                        System.arraycopy(byteBuff, counter, longByteBuff, 0, 8);
                        zip64ExtendedInfo2.setCompressedSize(Raw.readLongLittleEndian(longByteBuff, 0));
                        counter += 8;
                        valueAdded = true;
                    }
                    if ((offsetLocalHeader & 65535) == 65535 && counter < extraDataRecord.getSizeOfData()) {
                        System.arraycopy(byteBuff, counter, longByteBuff, 0, 8);
                        zip64ExtendedInfo2.setOffsetLocalHeader(Raw.readLongLittleEndian(longByteBuff, 0));
                        counter += 8;
                        valueAdded = true;
                    }
                    if ((diskNumberStart & InternalZipConstants.MAX_ALLOWED_ZIP_COMMENT_LENGTH) == 65535 && counter < extraDataRecord.getSizeOfData()) {
                        System.arraycopy(byteBuff, counter, intByteBuff, 0, 4);
                        zip64ExtendedInfo2.setDiskNumberStart(Raw.readIntLittleEndian(intByteBuff, 0));
                        int counter2 = counter + 8;
                        valueAdded = true;
                    }
                    if (valueAdded) {
                        return zip64ExtendedInfo2;
                    }
                }
            } else {
                i2++;
            }
        }
        return null;
    }

    private void setFilePointerToReadZip64EndCentralDirLoc() throws ZipException {
        Throwable th;
        try {
            byte[] ebs = new byte[4];
            long pos = this.zip4jRaf.length() - 22;
            do {
                long j = pos;
                pos = j - 1;
                this.zip4jRaf.seek(j);
            } while (((long) Raw.readLeInt(this.zip4jRaf, ebs)) != InternalZipConstants.ENDSIG);
            this.zip4jRaf.seek(((((this.zip4jRaf.getFilePointer() - 4) - 4) - 8) - 4) - 4);
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th2 = th;
            new ZipException((Throwable) e2);
            throw th2;
        }
    }

    public LocalFileHeader readLocalFileHeader(FileHeader fileHeader) throws ZipException {
        Throwable th;
        Throwable th2;
        LocalFileHeader localFileHeader;
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        Throwable th3;
        Throwable th4;
        StringBuffer stringBuffer3;
        Throwable th5;
        FileHeader fileHeader2 = fileHeader;
        if (fileHeader2 != null) {
            if (this.zip4jRaf != null) {
                long locHdrOffset = fileHeader2.getOffsetLocalHeader();
                if (fileHeader2.getZip64ExtendedInfo() != null && fileHeader2.getZip64ExtendedInfo().getOffsetLocalHeader() > 0) {
                    locHdrOffset = fileHeader2.getOffsetLocalHeader();
                }
                if (locHdrOffset < 0) {
                    Throwable th6 = th5;
                    new ZipException("invalid local header offset");
                    throw th6;
                }
                try {
                    this.zip4jRaf.seek(locHdrOffset);
                    new LocalFileHeader();
                    LocalFileHeader localFileHeader2 = localFileHeader;
                    byte[] shortBuff = new byte[2];
                    byte[] intBuff = new byte[4];
                    byte[] bArr = new byte[8];
                    byte[] readIntoBuff = readIntoBuff(this.zip4jRaf, intBuff);
                    int sig = Raw.readIntLittleEndian(intBuff, 0);
                    if (((long) sig) != InternalZipConstants.LOCSIG) {
                        Throwable th7 = th4;
                        new StringBuffer("invalid local header signature for file: ");
                        new ZipException(stringBuffer3.append(fileHeader2.getFileName()).toString());
                        throw th7;
                    }
                    localFileHeader2.setSignature(sig);
                    byte[] readIntoBuff2 = readIntoBuff(this.zip4jRaf, shortBuff);
                    localFileHeader2.setVersionNeededToExtract(Raw.readShortLittleEndian(shortBuff, 0));
                    int length = 0 + 4 + 2;
                    byte[] readIntoBuff3 = readIntoBuff(this.zip4jRaf, shortBuff);
                    localFileHeader2.setFileNameUTF8Encoded((Raw.readShortLittleEndian(shortBuff, 0) & InternalZipConstants.UFT8_NAMES_FLAG) != 0);
                    int firstByte = shortBuff[0];
                    if ((firstByte & 1) != 0) {
                        localFileHeader2.setEncrypted(true);
                    }
                    localFileHeader2.setGeneralPurposeFlag(shortBuff);
                    int length2 = length + 2;
                    String binary = Integer.toBinaryString(firstByte);
                    if (binary.length() >= 4) {
                        localFileHeader2.setDataDescriptorExists(binary.charAt(3) == '1');
                    }
                    byte[] readIntoBuff4 = readIntoBuff(this.zip4jRaf, shortBuff);
                    localFileHeader2.setCompressionMethod(Raw.readShortLittleEndian(shortBuff, 0));
                    byte[] readIntoBuff5 = readIntoBuff(this.zip4jRaf, intBuff);
                    localFileHeader2.setLastModFileTime(Raw.readIntLittleEndian(intBuff, 0));
                    byte[] readIntoBuff6 = readIntoBuff(this.zip4jRaf, intBuff);
                    localFileHeader2.setCrc32((long) Raw.readIntLittleEndian(intBuff, 0));
                    localFileHeader2.setCrcBuff((byte[]) intBuff.clone());
                    byte[] readIntoBuff7 = readIntoBuff(this.zip4jRaf, intBuff);
                    localFileHeader2.setCompressedSize(Raw.readLongLittleEndian(getLongByteFromIntByte(intBuff), 0));
                    byte[] readIntoBuff8 = readIntoBuff(this.zip4jRaf, intBuff);
                    localFileHeader2.setUncompressedSize(Raw.readLongLittleEndian(getLongByteFromIntByte(intBuff), 0));
                    byte[] readIntoBuff9 = readIntoBuff(this.zip4jRaf, shortBuff);
                    int fileNameLength = Raw.readShortLittleEndian(shortBuff, 0);
                    localFileHeader2.setFileNameLength(fileNameLength);
                    byte[] readIntoBuff10 = readIntoBuff(this.zip4jRaf, shortBuff);
                    int extraFieldLength = Raw.readShortLittleEndian(shortBuff, 0);
                    localFileHeader2.setExtraFieldLength(extraFieldLength);
                    int length3 = length2 + 2 + 4 + 4 + 4 + 4 + 2 + 2;
                    if (fileNameLength > 0) {
                        byte[] fileNameBuf = new byte[fileNameLength];
                        byte[] readIntoBuff11 = readIntoBuff(this.zip4jRaf, fileNameBuf);
                        String fileName = Zip4jUtil.decodeFileName(fileNameBuf, localFileHeader2.isFileNameUTF8Encoded());
                        if (fileName == null) {
                            Throwable th8 = th3;
                            new ZipException("file name is null, cannot assign file name to local file header");
                            throw th8;
                        }
                        new StringBuffer(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR);
                        if (fileName.indexOf(stringBuffer.append(System.getProperty("file.separator")).toString()) >= 0) {
                            new StringBuffer(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR);
                            fileName = fileName.substring(fileName.indexOf(stringBuffer2.append(System.getProperty("file.separator")).toString()) + 2);
                        }
                        localFileHeader2.setFileName(fileName);
                        length3 += fileNameLength;
                    } else {
                        localFileHeader2.setFileName((String) null);
                    }
                    readAndSaveExtraDataRecord(localFileHeader2);
                    localFileHeader2.setOffsetStartOfData(locHdrOffset + ((long) (length3 + extraFieldLength)));
                    localFileHeader2.setPassword(fileHeader2.getPassword());
                    readAndSaveZip64ExtendedInfo(localFileHeader2);
                    readAndSaveAESExtraDataRecord(localFileHeader2);
                    if (localFileHeader2.isEncrypted() && localFileHeader2.getEncryptionMethod() != 99) {
                        if ((firstByte & 64) == 64) {
                            localFileHeader2.setEncryptionMethod(1);
                        } else {
                            localFileHeader2.setEncryptionMethod(0);
                        }
                    }
                    if (localFileHeader2.getCrc32() <= 0) {
                        localFileHeader2.setCrc32(fileHeader2.getCrc32());
                        localFileHeader2.setCrcBuff(fileHeader2.getCrcBuff());
                    }
                    if (localFileHeader2.getCompressedSize() <= 0) {
                        localFileHeader2.setCompressedSize(fileHeader2.getCompressedSize());
                    }
                    if (localFileHeader2.getUncompressedSize() <= 0) {
                        localFileHeader2.setUncompressedSize(fileHeader2.getUncompressedSize());
                    }
                    return localFileHeader2;
                } catch (IOException e) {
                    IOException e2 = e;
                    Throwable th9 = th2;
                    new ZipException((Throwable) e2);
                    throw th9;
                }
            }
        }
        Throwable th10 = th;
        new ZipException("invalid read parameters for local header");
        throw th10;
    }

    private void readAndSaveAESExtraDataRecord(FileHeader fileHeader) throws ZipException {
        AESExtraDataRecord aesExtraDataRecord;
        Throwable th;
        FileHeader fileHeader2 = fileHeader;
        if (fileHeader2 == null) {
            Throwable th2 = th;
            new ZipException("file header is null in reading Zip64 Extended Info");
            throw th2;
        } else if (fileHeader2.getExtraDataRecords() != null && fileHeader2.getExtraDataRecords().size() > 0 && (aesExtraDataRecord = readAESExtraDataRecord(fileHeader2.getExtraDataRecords())) != null) {
            fileHeader2.setAesExtraDataRecord(aesExtraDataRecord);
            fileHeader2.setEncryptionMethod(99);
        }
    }

    private void readAndSaveAESExtraDataRecord(LocalFileHeader localFileHeader) throws ZipException {
        AESExtraDataRecord aesExtraDataRecord;
        Throwable th;
        LocalFileHeader localFileHeader2 = localFileHeader;
        if (localFileHeader2 == null) {
            Throwable th2 = th;
            new ZipException("file header is null in reading Zip64 Extended Info");
            throw th2;
        } else if (localFileHeader2.getExtraDataRecords() != null && localFileHeader2.getExtraDataRecords().size() > 0 && (aesExtraDataRecord = readAESExtraDataRecord(localFileHeader2.getExtraDataRecords())) != null) {
            localFileHeader2.setAesExtraDataRecord(aesExtraDataRecord);
            localFileHeader2.setEncryptionMethod(99);
        }
    }

    private AESExtraDataRecord readAESExtraDataRecord(ArrayList arrayList) throws ZipException {
        AESExtraDataRecord aESExtraDataRecord;
        String str;
        Throwable th;
        ArrayList extraDataRecords = arrayList;
        if (extraDataRecords == null) {
            return null;
        }
        int i = 0;
        while (i < extraDataRecords.size()) {
            ExtraDataRecord extraDataRecord = (ExtraDataRecord) extraDataRecords.get(i);
            if (extraDataRecord == null || extraDataRecord.getHeader() != 39169) {
                i++;
            } else if (extraDataRecord.getData() == null) {
                Throwable th2 = th;
                new ZipException("corrput AES extra data records");
                throw th2;
            } else {
                new AESExtraDataRecord();
                AESExtraDataRecord aesExtraDataRecord = aESExtraDataRecord;
                aesExtraDataRecord.setSignature(39169);
                aesExtraDataRecord.setDataSize(extraDataRecord.getSizeOfData());
                byte[] aesData = extraDataRecord.getData();
                aesExtraDataRecord.setVersionNumber(Raw.readShortLittleEndian(aesData, 0));
                byte[] vendorIDBytes = new byte[2];
                System.arraycopy(aesData, 2, vendorIDBytes, 0, 2);
                new String(vendorIDBytes);
                aesExtraDataRecord.setVendorID(str);
                aesExtraDataRecord.setAesStrength(aesData[4] & 255);
                aesExtraDataRecord.setCompressionMethod(Raw.readShortLittleEndian(aesData, 5));
                return aesExtraDataRecord;
            }
        }
        return null;
    }

    private byte[] readIntoBuff(RandomAccessFile zip4jRaf2, byte[] bArr) throws ZipException {
        Throwable th;
        Throwable th2;
        byte[] buf = bArr;
        try {
            if (zip4jRaf2.read(buf, 0, buf.length) != -1) {
                return buf;
            }
            Throwable th3 = th2;
            new ZipException("unexpected end of file when reading short buff");
            throw th3;
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th4 = th;
            new ZipException("IOException when reading short buff", (Throwable) e2);
            throw th4;
        }
    }

    private byte[] getLongByteFromIntByte(byte[] bArr) throws ZipException {
        Throwable th;
        Throwable th2;
        byte[] intByte = bArr;
        if (intByte == null) {
            Throwable th3 = th2;
            new ZipException("input parameter is null, cannot expand to 8 bytes");
            throw th3;
        } else if (intByte.length != 4) {
            Throwable th4 = th;
            new ZipException("invalid byte length, cannot expand to 8 bytes");
            throw th4;
        } else {
            byte[] bArr2 = new byte[8];
            bArr2[0] = intByte[0];
            byte[] bArr3 = bArr2;
            bArr3[1] = intByte[1];
            byte[] bArr4 = bArr3;
            bArr4[2] = intByte[2];
            byte[] longBuff = bArr4;
            longBuff[3] = intByte[3];
            return longBuff;
        }
    }
}
