package net.lingala.zip4j.core;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.io.SplitOutputStream;
import net.lingala.zip4j.model.AESExtraDataRecord;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.model.Zip64EndCentralDirLocator;
import net.lingala.zip4j.model.Zip64EndCentralDirRecord;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.Raw;
import net.lingala.zip4j.util.Zip4jUtil;

public class HeaderWriter {
    private final int ZIP64_EXTRA_BUF = 50;

    public HeaderWriter() {
    }

    public int writeLocalFileHeader(ZipModel zipModel, LocalFileHeader localFileHeader, OutputStream outputStream) throws ZipException {
        Throwable th;
        List list;
        Throwable th2;
        ZipModel zipModel2 = zipModel;
        LocalFileHeader localFileHeader2 = localFileHeader;
        OutputStream outputStream2 = outputStream;
        if (localFileHeader2 == null) {
            Throwable th3 = th2;
            new ZipException("input parameters are null, cannot write local file header");
            throw th3;
        }
        try {
            new ArrayList();
            List list2 = list;
            byte[] shortByte = new byte[2];
            byte[] intByte = new byte[4];
            byte[] longByte = new byte[8];
            byte[] emptyLongByte = new byte[8];
            Raw.writeIntLittleEndian(intByte, 0, localFileHeader2.getSignature());
            copyByteArrayToArrayList(intByte, list2);
            Raw.writeShortLittleEndian(shortByte, 0, (short) localFileHeader2.getVersionNeededToExtract());
            copyByteArrayToArrayList(shortByte, list2);
            copyByteArrayToArrayList(localFileHeader2.getGeneralPurposeFlag(), list2);
            Raw.writeShortLittleEndian(shortByte, 0, (short) localFileHeader2.getCompressionMethod());
            copyByteArrayToArrayList(shortByte, list2);
            Raw.writeIntLittleEndian(intByte, 0, localFileHeader2.getLastModFileTime());
            copyByteArrayToArrayList(intByte, list2);
            Raw.writeIntLittleEndian(intByte, 0, (int) localFileHeader2.getCrc32());
            copyByteArrayToArrayList(intByte, list2);
            boolean writingZip64Rec = false;
            if (localFileHeader2.getUncompressedSize() + 50 >= InternalZipConstants.ZIP_64_LIMIT) {
                Raw.writeLongLittleEndian(longByte, 0, InternalZipConstants.ZIP_64_LIMIT);
                System.arraycopy(longByte, 0, intByte, 0, 4);
                copyByteArrayToArrayList(intByte, list2);
                copyByteArrayToArrayList(intByte, list2);
                zipModel2.setZip64Format(true);
                writingZip64Rec = true;
                localFileHeader2.setWriteComprSizeInZip64ExtraRecord(true);
            } else {
                Raw.writeLongLittleEndian(longByte, 0, localFileHeader2.getCompressedSize());
                System.arraycopy(longByte, 0, intByte, 0, 4);
                copyByteArrayToArrayList(intByte, list2);
                Raw.writeLongLittleEndian(longByte, 0, localFileHeader2.getUncompressedSize());
                System.arraycopy(longByte, 0, intByte, 0, 4);
                copyByteArrayToArrayList(intByte, list2);
                localFileHeader2.setWriteComprSizeInZip64ExtraRecord(false);
            }
            Raw.writeShortLittleEndian(shortByte, 0, (short) localFileHeader2.getFileNameLength());
            copyByteArrayToArrayList(shortByte, list2);
            int extraFieldLength = 0;
            if (writingZip64Rec) {
                extraFieldLength = 0 + 20;
            }
            if (localFileHeader2.getAesExtraDataRecord() != null) {
                extraFieldLength += 11;
            }
            Raw.writeShortLittleEndian(shortByte, 0, (short) extraFieldLength);
            copyByteArrayToArrayList(shortByte, list2);
            if (Zip4jUtil.isStringNotNullAndNotEmpty(zipModel2.getFileNameCharset())) {
                copyByteArrayToArrayList(localFileHeader2.getFileName().getBytes(zipModel2.getFileNameCharset()), list2);
            } else {
                copyByteArrayToArrayList(Zip4jUtil.convertCharset(localFileHeader2.getFileName()), list2);
            }
            if (writingZip64Rec) {
                Raw.writeShortLittleEndian(shortByte, 0, 1);
                copyByteArrayToArrayList(shortByte, list2);
                Raw.writeShortLittleEndian(shortByte, 0, 16);
                copyByteArrayToArrayList(shortByte, list2);
                Raw.writeLongLittleEndian(longByte, 0, localFileHeader2.getUncompressedSize());
                copyByteArrayToArrayList(longByte, list2);
                copyByteArrayToArrayList(emptyLongByte, list2);
            }
            if (localFileHeader2.getAesExtraDataRecord() != null) {
                AESExtraDataRecord aesExtraDataRecord = localFileHeader2.getAesExtraDataRecord();
                Raw.writeShortLittleEndian(shortByte, 0, (short) ((int) aesExtraDataRecord.getSignature()));
                copyByteArrayToArrayList(shortByte, list2);
                Raw.writeShortLittleEndian(shortByte, 0, (short) aesExtraDataRecord.getDataSize());
                copyByteArrayToArrayList(shortByte, list2);
                Raw.writeShortLittleEndian(shortByte, 0, (short) aesExtraDataRecord.getVersionNumber());
                copyByteArrayToArrayList(shortByte, list2);
                copyByteArrayToArrayList(aesExtraDataRecord.getVendorID().getBytes(), list2);
                copyByteArrayToArrayList(new byte[]{(byte) aesExtraDataRecord.getAesStrength()}, list2);
                Raw.writeShortLittleEndian(shortByte, 0, (short) aesExtraDataRecord.getCompressionMethod());
                copyByteArrayToArrayList(shortByte, list2);
            }
            byte[] lhBytes = byteArrayListToByteArray(list2);
            outputStream2.write(lhBytes);
            return lhBytes.length;
        } catch (ZipException e) {
            throw e;
        } catch (Exception e2) {
            Exception e3 = e2;
            Throwable th4 = th;
            new ZipException((Throwable) e3);
            throw th4;
        }
    }

    public int writeExtendedLocalHeader(LocalFileHeader localFileHeader, OutputStream outputStream) throws ZipException, IOException {
        Throwable th;
        ArrayList arrayList;
        LocalFileHeader localFileHeader2 = localFileHeader;
        OutputStream outputStream2 = outputStream;
        if (localFileHeader2 == null || outputStream2 == null) {
            Throwable th2 = th;
            new ZipException("input parameters is null, cannot write extended local header");
            throw th2;
        }
        new ArrayList();
        ArrayList byteArrayList = arrayList;
        byte[] intByte = new byte[4];
        Raw.writeIntLittleEndian(intByte, 0, 134695760);
        copyByteArrayToArrayList(intByte, byteArrayList);
        Raw.writeIntLittleEndian(intByte, 0, (int) localFileHeader2.getCrc32());
        copyByteArrayToArrayList(intByte, byteArrayList);
        long compressedSize = localFileHeader2.getCompressedSize();
        if (compressedSize >= 2147483647L) {
            compressedSize = 2147483647L;
        }
        Raw.writeIntLittleEndian(intByte, 0, (int) compressedSize);
        copyByteArrayToArrayList(intByte, byteArrayList);
        long uncompressedSize = localFileHeader2.getUncompressedSize();
        if (uncompressedSize >= 2147483647L) {
            uncompressedSize = 2147483647L;
        }
        Raw.writeIntLittleEndian(intByte, 0, (int) uncompressedSize);
        copyByteArrayToArrayList(intByte, byteArrayList);
        byte[] extLocHdrBytes = byteArrayListToByteArray(byteArrayList);
        outputStream2.write(extLocHdrBytes);
        return extLocHdrBytes.length;
    }

    public void finalizeZipFile(ZipModel zipModel, OutputStream outputStream) throws ZipException {
        Throwable th;
        Throwable th2;
        List list;
        Zip64EndCentralDirLocator zip64EndCentralDirLocator;
        Zip64EndCentralDirRecord zip64EndCentralDirRecord;
        ZipModel zipModel2 = zipModel;
        OutputStream outputStream2 = outputStream;
        if (zipModel2 == null || outputStream2 == null) {
            Throwable th3 = th;
            new ZipException("input parameters is null, cannot finalize zip file");
            throw th3;
        }
        try {
            processHeaderData(zipModel2, outputStream2);
            long offsetCentralDir = zipModel2.getEndCentralDirRecord().getOffsetOfStartOfCentralDir();
            new ArrayList();
            List headerBytesList = list;
            int sizeOfCentralDir = writeCentralDirectory(zipModel2, outputStream2, headerBytesList);
            if (zipModel2.isZip64Format()) {
                if (zipModel2.getZip64EndCentralDirRecord() == null) {
                    new Zip64EndCentralDirRecord();
                    zipModel2.setZip64EndCentralDirRecord(zip64EndCentralDirRecord);
                }
                if (zipModel2.getZip64EndCentralDirLocator() == null) {
                    new Zip64EndCentralDirLocator();
                    zipModel2.setZip64EndCentralDirLocator(zip64EndCentralDirLocator);
                }
                zipModel2.getZip64EndCentralDirLocator().setOffsetZip64EndOfCentralDirRec(offsetCentralDir + ((long) sizeOfCentralDir));
                if (outputStream2 instanceof SplitOutputStream) {
                    zipModel2.getZip64EndCentralDirLocator().setNoOfDiskStartOfZip64EndOfCentralDirRec(((SplitOutputStream) outputStream2).getCurrSplitFileCounter());
                    zipModel2.getZip64EndCentralDirLocator().setTotNumberOfDiscs(((SplitOutputStream) outputStream2).getCurrSplitFileCounter() + 1);
                } else {
                    zipModel2.getZip64EndCentralDirLocator().setNoOfDiskStartOfZip64EndOfCentralDirRec(0);
                    zipModel2.getZip64EndCentralDirLocator().setTotNumberOfDiscs(1);
                }
                writeZip64EndOfCentralDirectoryRecord(zipModel2, outputStream2, sizeOfCentralDir, offsetCentralDir, headerBytesList);
                writeZip64EndOfCentralDirectoryLocator(zipModel2, outputStream2, headerBytesList);
            }
            writeEndOfCentralDirectoryRecord(zipModel2, outputStream2, sizeOfCentralDir, offsetCentralDir, headerBytesList);
            writeZipHeaderBytes(zipModel2, outputStream2, byteArrayListToByteArray(headerBytesList));
        } catch (ZipException e) {
            throw e;
        } catch (Exception e2) {
            Exception e3 = e2;
            Throwable th4 = th2;
            new ZipException((Throwable) e3);
            throw th4;
        }
    }

    public void finalizeZipFileWithoutValidations(ZipModel zipModel, OutputStream outputStream) throws ZipException {
        Throwable th;
        Throwable th2;
        List list;
        Zip64EndCentralDirLocator zip64EndCentralDirLocator;
        Zip64EndCentralDirRecord zip64EndCentralDirRecord;
        ZipModel zipModel2 = zipModel;
        OutputStream outputStream2 = outputStream;
        if (zipModel2 == null || outputStream2 == null) {
            Throwable th3 = th;
            new ZipException("input parameters is null, cannot finalize zip file without validations");
            throw th3;
        }
        try {
            new ArrayList();
            List headerBytesList = list;
            long offsetCentralDir = zipModel2.getEndCentralDirRecord().getOffsetOfStartOfCentralDir();
            int sizeOfCentralDir = writeCentralDirectory(zipModel2, outputStream2, headerBytesList);
            if (zipModel2.isZip64Format()) {
                if (zipModel2.getZip64EndCentralDirRecord() == null) {
                    new Zip64EndCentralDirRecord();
                    zipModel2.setZip64EndCentralDirRecord(zip64EndCentralDirRecord);
                }
                if (zipModel2.getZip64EndCentralDirLocator() == null) {
                    new Zip64EndCentralDirLocator();
                    zipModel2.setZip64EndCentralDirLocator(zip64EndCentralDirLocator);
                }
                zipModel2.getZip64EndCentralDirLocator().setOffsetZip64EndOfCentralDirRec(offsetCentralDir + ((long) sizeOfCentralDir));
                writeZip64EndOfCentralDirectoryRecord(zipModel2, outputStream2, sizeOfCentralDir, offsetCentralDir, headerBytesList);
                writeZip64EndOfCentralDirectoryLocator(zipModel2, outputStream2, headerBytesList);
            }
            writeEndOfCentralDirectoryRecord(zipModel2, outputStream2, sizeOfCentralDir, offsetCentralDir, headerBytesList);
            writeZipHeaderBytes(zipModel2, outputStream2, byteArrayListToByteArray(headerBytesList));
        } catch (ZipException e) {
            throw e;
        } catch (Exception e2) {
            Exception e3 = e2;
            Throwable th4 = th2;
            new ZipException((Throwable) e3);
            throw th4;
        }
    }

    private void writeZipHeaderBytes(ZipModel zipModel, OutputStream outputStream, byte[] bArr) throws ZipException {
        Throwable th;
        Throwable th2;
        ZipModel zipModel2 = zipModel;
        OutputStream outputStream2 = outputStream;
        byte[] buff = bArr;
        if (buff == null) {
            Throwable th3 = th2;
            new ZipException("invalid buff to write as zip headers");
            throw th3;
        }
        try {
            if (!(outputStream2 instanceof SplitOutputStream) || !((SplitOutputStream) outputStream2).checkBuffSizeAndStartNextSplitFile(buff.length)) {
                outputStream2.write(buff);
            } else {
                finalizeZipFile(zipModel2, outputStream2);
            }
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th4 = th;
            new ZipException((Throwable) e2);
            throw th4;
        }
    }

    private void processHeaderData(ZipModel zipModel, OutputStream outputStream) throws ZipException {
        Throwable th;
        Zip64EndCentralDirLocator zip64EndCentralDirLocator;
        Zip64EndCentralDirRecord zip64EndCentralDirRecord;
        ZipModel zipModel2 = zipModel;
        OutputStream outputStream2 = outputStream;
        int currSplitFileCounter = 0;
        try {
            if (outputStream2 instanceof SplitOutputStream) {
                zipModel2.getEndCentralDirRecord().setOffsetOfStartOfCentralDir(((SplitOutputStream) outputStream2).getFilePointer());
                currSplitFileCounter = ((SplitOutputStream) outputStream2).getCurrSplitFileCounter();
            }
            if (zipModel2.isZip64Format()) {
                if (zipModel2.getZip64EndCentralDirRecord() == null) {
                    new Zip64EndCentralDirRecord();
                    zipModel2.setZip64EndCentralDirRecord(zip64EndCentralDirRecord);
                }
                if (zipModel2.getZip64EndCentralDirLocator() == null) {
                    new Zip64EndCentralDirLocator();
                    zipModel2.setZip64EndCentralDirLocator(zip64EndCentralDirLocator);
                }
                zipModel2.getZip64EndCentralDirLocator().setNoOfDiskStartOfZip64EndOfCentralDirRec(currSplitFileCounter);
                zipModel2.getZip64EndCentralDirLocator().setTotNumberOfDiscs(currSplitFileCounter + 1);
            }
            zipModel2.getEndCentralDirRecord().setNoOfThisDisk(currSplitFileCounter);
            zipModel2.getEndCentralDirRecord().setNoOfThisDiskStartOfCentralDir(currSplitFileCounter);
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th2 = th;
            new ZipException((Throwable) e2);
            throw th2;
        }
    }

    private int writeCentralDirectory(ZipModel zipModel, OutputStream outputStream, List list) throws ZipException {
        Throwable th;
        ZipModel zipModel2 = zipModel;
        OutputStream outputStream2 = outputStream;
        List headerBytesList = list;
        if (zipModel2 == null || outputStream2 == null) {
            Throwable th2 = th;
            new ZipException("input parameters is null, cannot write central directory");
            throw th2;
        } else if (zipModel2.getCentralDirectory() == null || zipModel2.getCentralDirectory().getFileHeaders() == null || zipModel2.getCentralDirectory().getFileHeaders().size() <= 0) {
            return 0;
        } else {
            int sizeOfCentralDir = 0;
            for (int i = 0; i < zipModel2.getCentralDirectory().getFileHeaders().size(); i++) {
                sizeOfCentralDir += writeFileHeader(zipModel2, (FileHeader) zipModel2.getCentralDirectory().getFileHeaders().get(i), outputStream2, headerBytesList);
            }
            return sizeOfCentralDir;
        }
    }

    private int writeFileHeader(ZipModel zipModel, FileHeader fileHeader, OutputStream outputStream, List list) throws ZipException {
        Throwable th;
        Throwable th2;
        int sizeOfFileHeader;
        int sizeOfFileHeader2;
        int sizeOfFileHeader3;
        ZipModel zipModel2 = zipModel;
        FileHeader fileHeader2 = fileHeader;
        OutputStream outputStream2 = outputStream;
        List headerBytesList = list;
        if (fileHeader2 == null || outputStream2 == null) {
            Throwable th3 = th;
            new ZipException("input parameters is null, cannot write local file header");
            throw th3;
        }
        try {
            byte[] shortByte = new byte[2];
            byte[] intByte = new byte[4];
            byte[] longByte = new byte[8];
            byte[] emptyShortByte = new byte[2];
            byte[] emptyIntByte = new byte[4];
            boolean writeZip64FileSize = false;
            boolean writeZip64OffsetLocalHeader = false;
            Raw.writeIntLittleEndian(intByte, 0, fileHeader2.getSignature());
            copyByteArrayToArrayList(intByte, headerBytesList);
            Raw.writeShortLittleEndian(shortByte, 0, (short) fileHeader2.getVersionMadeBy());
            copyByteArrayToArrayList(shortByte, headerBytesList);
            Raw.writeShortLittleEndian(shortByte, 0, (short) fileHeader2.getVersionNeededToExtract());
            copyByteArrayToArrayList(shortByte, headerBytesList);
            copyByteArrayToArrayList(fileHeader2.getGeneralPurposeFlag(), headerBytesList);
            Raw.writeShortLittleEndian(shortByte, 0, (short) fileHeader2.getCompressionMethod());
            copyByteArrayToArrayList(shortByte, headerBytesList);
            Raw.writeIntLittleEndian(intByte, 0, fileHeader2.getLastModFileTime());
            copyByteArrayToArrayList(intByte, headerBytesList);
            Raw.writeIntLittleEndian(intByte, 0, (int) fileHeader2.getCrc32());
            copyByteArrayToArrayList(intByte, headerBytesList);
            int sizeOfFileHeader4 = 0 + 4 + 2 + 2 + 2 + 2 + 4 + 4;
            if (fileHeader2.getCompressedSize() >= InternalZipConstants.ZIP_64_LIMIT || fileHeader2.getUncompressedSize() + 50 >= InternalZipConstants.ZIP_64_LIMIT) {
                Raw.writeLongLittleEndian(longByte, 0, InternalZipConstants.ZIP_64_LIMIT);
                System.arraycopy(longByte, 0, intByte, 0, 4);
                copyByteArrayToArrayList(intByte, headerBytesList);
                copyByteArrayToArrayList(intByte, headerBytesList);
                sizeOfFileHeader = sizeOfFileHeader4 + 4 + 4;
                writeZip64FileSize = true;
            } else {
                Raw.writeLongLittleEndian(longByte, 0, fileHeader2.getCompressedSize());
                System.arraycopy(longByte, 0, intByte, 0, 4);
                copyByteArrayToArrayList(intByte, headerBytesList);
                Raw.writeLongLittleEndian(longByte, 0, fileHeader2.getUncompressedSize());
                System.arraycopy(longByte, 0, intByte, 0, 4);
                copyByteArrayToArrayList(intByte, headerBytesList);
                sizeOfFileHeader = sizeOfFileHeader4 + 4 + 4;
            }
            Raw.writeShortLittleEndian(shortByte, 0, (short) fileHeader2.getFileNameLength());
            copyByteArrayToArrayList(shortByte, headerBytesList);
            int sizeOfFileHeader5 = sizeOfFileHeader + 2;
            byte[] offsetLocalHeaderBytes = new byte[4];
            if (fileHeader2.getOffsetLocalHeader() > InternalZipConstants.ZIP_64_LIMIT) {
                Raw.writeLongLittleEndian(longByte, 0, InternalZipConstants.ZIP_64_LIMIT);
                System.arraycopy(longByte, 0, offsetLocalHeaderBytes, 0, 4);
                writeZip64OffsetLocalHeader = true;
            } else {
                Raw.writeLongLittleEndian(longByte, 0, fileHeader2.getOffsetLocalHeader());
                System.arraycopy(longByte, 0, offsetLocalHeaderBytes, 0, 4);
            }
            int extraFieldLength = 0;
            if (writeZip64FileSize || writeZip64OffsetLocalHeader) {
                extraFieldLength = 0 + 4;
                if (writeZip64FileSize) {
                    extraFieldLength += 16;
                }
                if (writeZip64OffsetLocalHeader) {
                    extraFieldLength += 8;
                }
            }
            if (fileHeader2.getAesExtraDataRecord() != null) {
                extraFieldLength += 11;
            }
            Raw.writeShortLittleEndian(shortByte, 0, (short) extraFieldLength);
            copyByteArrayToArrayList(shortByte, headerBytesList);
            copyByteArrayToArrayList(emptyShortByte, headerBytesList);
            Raw.writeShortLittleEndian(shortByte, 0, (short) fileHeader2.getDiskNumberStart());
            copyByteArrayToArrayList(shortByte, headerBytesList);
            copyByteArrayToArrayList(emptyShortByte, headerBytesList);
            int sizeOfFileHeader6 = sizeOfFileHeader5 + 2 + 2 + 2 + 2;
            if (fileHeader2.getExternalFileAttr() != null) {
                copyByteArrayToArrayList(fileHeader2.getExternalFileAttr(), headerBytesList);
            } else {
                copyByteArrayToArrayList(emptyIntByte, headerBytesList);
            }
            copyByteArrayToArrayList(offsetLocalHeaderBytes, headerBytesList);
            int sizeOfFileHeader7 = sizeOfFileHeader6 + 4 + 4;
            if (Zip4jUtil.isStringNotNullAndNotEmpty(zipModel2.getFileNameCharset())) {
                byte[] fileNameBytes = fileHeader2.getFileName().getBytes(zipModel2.getFileNameCharset());
                copyByteArrayToArrayList(fileNameBytes, headerBytesList);
                sizeOfFileHeader2 = sizeOfFileHeader7 + fileNameBytes.length;
            } else {
                copyByteArrayToArrayList(Zip4jUtil.convertCharset(fileHeader2.getFileName()), headerBytesList);
                sizeOfFileHeader2 = sizeOfFileHeader7 + Zip4jUtil.getEncodedStringLength(fileHeader2.getFileName());
            }
            if (writeZip64FileSize || writeZip64OffsetLocalHeader) {
                zipModel2.setZip64Format(true);
                Raw.writeShortLittleEndian(shortByte, 0, 1);
                copyByteArrayToArrayList(shortByte, headerBytesList);
                int sizeOfFileHeader8 = sizeOfFileHeader3 + 2;
                int dataSize = 0;
                if (writeZip64FileSize) {
                    dataSize = 0 + 16;
                }
                if (writeZip64OffsetLocalHeader) {
                    dataSize += 8;
                }
                Raw.writeShortLittleEndian(shortByte, 0, (short) dataSize);
                copyByteArrayToArrayList(shortByte, headerBytesList);
                sizeOfFileHeader3 = sizeOfFileHeader8 + 2;
                if (writeZip64FileSize) {
                    Raw.writeLongLittleEndian(longByte, 0, fileHeader2.getUncompressedSize());
                    copyByteArrayToArrayList(longByte, headerBytesList);
                    Raw.writeLongLittleEndian(longByte, 0, fileHeader2.getCompressedSize());
                    copyByteArrayToArrayList(longByte, headerBytesList);
                    sizeOfFileHeader3 = sizeOfFileHeader3 + 8 + 8;
                }
                if (writeZip64OffsetLocalHeader) {
                    Raw.writeLongLittleEndian(longByte, 0, fileHeader2.getOffsetLocalHeader());
                    copyByteArrayToArrayList(longByte, headerBytesList);
                    sizeOfFileHeader3 += 8;
                }
            }
            if (fileHeader2.getAesExtraDataRecord() != null) {
                AESExtraDataRecord aesExtraDataRecord = fileHeader2.getAesExtraDataRecord();
                Raw.writeShortLittleEndian(shortByte, 0, (short) ((int) aesExtraDataRecord.getSignature()));
                copyByteArrayToArrayList(shortByte, headerBytesList);
                Raw.writeShortLittleEndian(shortByte, 0, (short) aesExtraDataRecord.getDataSize());
                copyByteArrayToArrayList(shortByte, headerBytesList);
                Raw.writeShortLittleEndian(shortByte, 0, (short) aesExtraDataRecord.getVersionNumber());
                copyByteArrayToArrayList(shortByte, headerBytesList);
                copyByteArrayToArrayList(aesExtraDataRecord.getVendorID().getBytes(), headerBytesList);
                copyByteArrayToArrayList(new byte[]{(byte) aesExtraDataRecord.getAesStrength()}, headerBytesList);
                Raw.writeShortLittleEndian(shortByte, 0, (short) aesExtraDataRecord.getCompressionMethod());
                copyByteArrayToArrayList(shortByte, headerBytesList);
                sizeOfFileHeader3 += 11;
            }
            return sizeOfFileHeader3;
        } catch (Exception e) {
            Exception e2 = e;
            Throwable th4 = th2;
            new ZipException((Throwable) e2);
            throw th4;
        }
    }

    private void writeZip64EndOfCentralDirectoryRecord(ZipModel zipModel, OutputStream outputStream, int i, long j, List list) throws ZipException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        ZipModel zipModel2 = zipModel;
        OutputStream outputStream2 = outputStream;
        int sizeOfCentralDir = i;
        long offsetCentralDir = j;
        List headerBytesList = list;
        if (zipModel2 == null || outputStream2 == null) {
            Throwable th4 = th;
            new ZipException("zip model or output stream is null, cannot write zip64 end of central directory record");
            throw th4;
        }
        try {
            byte[] shortByte = new byte[2];
            byte[] emptyShortByte = new byte[2];
            byte[] intByte = new byte[4];
            byte[] longByte = new byte[8];
            Raw.writeIntLittleEndian(intByte, 0, 101075792);
            copyByteArrayToArrayList(intByte, headerBytesList);
            Raw.writeLongLittleEndian(longByte, 0, 44);
            copyByteArrayToArrayList(longByte, headerBytesList);
            if (zipModel2.getCentralDirectory() == null || zipModel2.getCentralDirectory().getFileHeaders() == null || zipModel2.getCentralDirectory().getFileHeaders().size() <= 0) {
                copyByteArrayToArrayList(emptyShortByte, headerBytesList);
                copyByteArrayToArrayList(emptyShortByte, headerBytesList);
            } else {
                Raw.writeShortLittleEndian(shortByte, 0, (short) ((FileHeader) zipModel2.getCentralDirectory().getFileHeaders().get(0)).getVersionMadeBy());
                copyByteArrayToArrayList(shortByte, headerBytesList);
                Raw.writeShortLittleEndian(shortByte, 0, (short) ((FileHeader) zipModel2.getCentralDirectory().getFileHeaders().get(0)).getVersionNeededToExtract());
                copyByteArrayToArrayList(shortByte, headerBytesList);
            }
            Raw.writeIntLittleEndian(intByte, 0, zipModel2.getEndCentralDirRecord().getNoOfThisDisk());
            copyByteArrayToArrayList(intByte, headerBytesList);
            Raw.writeIntLittleEndian(intByte, 0, zipModel2.getEndCentralDirRecord().getNoOfThisDiskStartOfCentralDir());
            copyByteArrayToArrayList(intByte, headerBytesList);
            int numEntriesOnThisDisk = 0;
            if (zipModel2.getCentralDirectory() == null || zipModel2.getCentralDirectory().getFileHeaders() == null) {
                Throwable th5 = th3;
                new ZipException("invalid central directory/file headers, cannot write end of central directory record");
                throw th5;
            }
            int numEntries = zipModel2.getCentralDirectory().getFileHeaders().size();
            if (zipModel2.isSplitArchive()) {
                int countNumberOfFileHeaderEntriesOnDisk = countNumberOfFileHeaderEntriesOnDisk(zipModel2.getCentralDirectory().getFileHeaders(), zipModel2.getEndCentralDirRecord().getNoOfThisDisk());
            } else {
                numEntriesOnThisDisk = numEntries;
            }
            Raw.writeLongLittleEndian(longByte, 0, (long) numEntriesOnThisDisk);
            copyByteArrayToArrayList(longByte, headerBytesList);
            Raw.writeLongLittleEndian(longByte, 0, (long) numEntries);
            copyByteArrayToArrayList(longByte, headerBytesList);
            Raw.writeLongLittleEndian(longByte, 0, (long) sizeOfCentralDir);
            copyByteArrayToArrayList(longByte, headerBytesList);
            Raw.writeLongLittleEndian(longByte, 0, offsetCentralDir);
            copyByteArrayToArrayList(longByte, headerBytesList);
        } catch (ZipException e) {
            throw e;
        } catch (Exception e2) {
            Exception e3 = e2;
            Throwable th6 = th2;
            new ZipException((Throwable) e3);
            throw th6;
        }
    }

    private void writeZip64EndOfCentralDirectoryLocator(ZipModel zipModel, OutputStream outputStream, List list) throws ZipException {
        Throwable th;
        Throwable th2;
        ZipModel zipModel2 = zipModel;
        OutputStream outputStream2 = outputStream;
        List headerBytesList = list;
        if (zipModel2 == null || outputStream2 == null) {
            Throwable th3 = th;
            new ZipException("zip model or output stream is null, cannot write zip64 end of central directory locator");
            throw th3;
        }
        try {
            byte[] intByte = new byte[4];
            byte[] longByte = new byte[8];
            Raw.writeIntLittleEndian(intByte, 0, 117853008);
            copyByteArrayToArrayList(intByte, headerBytesList);
            Raw.writeIntLittleEndian(intByte, 0, zipModel2.getZip64EndCentralDirLocator().getNoOfDiskStartOfZip64EndOfCentralDirRec());
            copyByteArrayToArrayList(intByte, headerBytesList);
            Raw.writeLongLittleEndian(longByte, 0, zipModel2.getZip64EndCentralDirLocator().getOffsetZip64EndOfCentralDirRec());
            copyByteArrayToArrayList(longByte, headerBytesList);
            Raw.writeIntLittleEndian(intByte, 0, zipModel2.getZip64EndCentralDirLocator().getTotNumberOfDiscs());
            copyByteArrayToArrayList(intByte, headerBytesList);
        } catch (ZipException e) {
            throw e;
        } catch (Exception e2) {
            Exception e3 = e2;
            Throwable th4 = th2;
            new ZipException((Throwable) e3);
            throw th4;
        }
    }

    private void writeEndOfCentralDirectoryRecord(ZipModel zipModel, OutputStream outputStream, int i, long j, List list) throws ZipException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        int numEntriesOnThisDisk;
        ZipModel zipModel2 = zipModel;
        OutputStream outputStream2 = outputStream;
        int sizeOfCentralDir = i;
        long offsetCentralDir = j;
        List headrBytesList = list;
        if (zipModel2 == null || outputStream2 == null) {
            Throwable th4 = th;
            new ZipException("zip model or output stream is null, cannot write end of central directory record");
            throw th4;
        }
        try {
            byte[] shortByte = new byte[2];
            byte[] intByte = new byte[4];
            byte[] longByte = new byte[8];
            Raw.writeIntLittleEndian(intByte, 0, (int) zipModel2.getEndCentralDirRecord().getSignature());
            copyByteArrayToArrayList(intByte, headrBytesList);
            Raw.writeShortLittleEndian(shortByte, 0, (short) zipModel2.getEndCentralDirRecord().getNoOfThisDisk());
            copyByteArrayToArrayList(shortByte, headrBytesList);
            Raw.writeShortLittleEndian(shortByte, 0, (short) zipModel2.getEndCentralDirRecord().getNoOfThisDiskStartOfCentralDir());
            copyByteArrayToArrayList(shortByte, headrBytesList);
            if (zipModel2.getCentralDirectory() == null || zipModel2.getCentralDirectory().getFileHeaders() == null) {
                Throwable th5 = th3;
                new ZipException("invalid central directory/file headers, cannot write end of central directory record");
                throw th5;
            }
            int numEntries = zipModel2.getCentralDirectory().getFileHeaders().size();
            if (zipModel2.isSplitArchive()) {
                numEntriesOnThisDisk = countNumberOfFileHeaderEntriesOnDisk(zipModel2.getCentralDirectory().getFileHeaders(), zipModel2.getEndCentralDirRecord().getNoOfThisDisk());
            } else {
                numEntriesOnThisDisk = numEntries;
            }
            Raw.writeShortLittleEndian(shortByte, 0, (short) numEntriesOnThisDisk);
            copyByteArrayToArrayList(shortByte, headrBytesList);
            Raw.writeShortLittleEndian(shortByte, 0, (short) numEntries);
            copyByteArrayToArrayList(shortByte, headrBytesList);
            Raw.writeIntLittleEndian(intByte, 0, sizeOfCentralDir);
            copyByteArrayToArrayList(intByte, headrBytesList);
            if (offsetCentralDir > InternalZipConstants.ZIP_64_LIMIT) {
                Raw.writeLongLittleEndian(longByte, 0, InternalZipConstants.ZIP_64_LIMIT);
                System.arraycopy(longByte, 0, intByte, 0, 4);
                copyByteArrayToArrayList(intByte, headrBytesList);
            } else {
                Raw.writeLongLittleEndian(longByte, 0, offsetCentralDir);
                System.arraycopy(longByte, 0, intByte, 0, 4);
                copyByteArrayToArrayList(intByte, headrBytesList);
            }
            int commentLength = 0;
            if (zipModel2.getEndCentralDirRecord().getComment() != null) {
                commentLength = zipModel2.getEndCentralDirRecord().getCommentLength();
            }
            Raw.writeShortLittleEndian(shortByte, 0, (short) commentLength);
            copyByteArrayToArrayList(shortByte, headrBytesList);
            if (commentLength > 0) {
                copyByteArrayToArrayList(zipModel2.getEndCentralDirRecord().getCommentBytes(), headrBytesList);
            }
        } catch (Exception e) {
            Exception e2 = e;
            Throwable th6 = th2;
            new ZipException((Throwable) e2);
            throw th6;
        }
    }

    public void updateLocalFileHeader(LocalFileHeader localFileHeader, long j, int i, ZipModel zipModel, byte[] bArr, int i2, SplitOutputStream splitOutputStream) throws ZipException {
        Throwable th;
        Throwable th2;
        SplitOutputStream currOutputStream;
        File file;
        StringBuffer stringBuffer;
        StringBuffer stringBuffer2;
        String fileName;
        SplitOutputStream splitOutputStream2;
        File file2;
        StringBuffer stringBuffer3;
        LocalFileHeader localFileHeader2 = localFileHeader;
        long offset = j;
        int toUpdate = i;
        ZipModel zipModel2 = zipModel;
        byte[] bytesToWrite = bArr;
        int noOfDisk = i2;
        SplitOutputStream outputStream = splitOutputStream;
        if (localFileHeader2 == null || offset < 0 || zipModel2 == null) {
            Throwable th3 = th;
            new ZipException("invalid input parameters, cannot update local file header");
            throw th3;
        }
        boolean closeFlag = false;
        try {
            if (noOfDisk != outputStream.getCurrSplitFileCounter()) {
                new File(zipModel2.getZipFile());
                File zipFile = file;
                String parentFile = zipFile.getParent();
                String fileNameWithoutExt = Zip4jUtil.getZipFileNameWithoutExt(zipFile.getName());
                new StringBuffer(String.valueOf(parentFile));
                String fileName2 = stringBuffer.append(System.getProperty("file.separator")).toString();
                if (noOfDisk < 9) {
                    new StringBuffer(String.valueOf(fileName2));
                    fileName = stringBuffer3.append(fileNameWithoutExt).append(".z0").append(noOfDisk + 1).toString();
                } else {
                    new StringBuffer(String.valueOf(fileName2));
                    fileName = stringBuffer2.append(fileNameWithoutExt).append(".z").append(noOfDisk + 1).toString();
                }
                new File(fileName);
                new SplitOutputStream(file2);
                currOutputStream = splitOutputStream2;
                closeFlag = true;
            } else {
                currOutputStream = outputStream;
            }
            long currOffset = currOutputStream.getFilePointer();
            switch (toUpdate) {
                case 14:
                    currOutputStream.seek(offset + ((long) toUpdate));
                    currOutputStream.write(bytesToWrite);
                    break;
                case 18:
                case 22:
                    updateCompressedSizeInLocalFileHeader(currOutputStream, localFileHeader2, offset, (long) toUpdate, bytesToWrite, zipModel2.isZip64Format());
                    break;
            }
            if (closeFlag) {
                currOutputStream.close();
            } else {
                outputStream.seek(currOffset);
            }
        } catch (Exception e) {
            Exception e2 = e;
            Throwable th4 = th2;
            new ZipException((Throwable) e2);
            throw th4;
        }
    }

    private void updateCompressedSizeInLocalFileHeader(SplitOutputStream splitOutputStream, LocalFileHeader localFileHeader, long j, long j2, byte[] bArr, boolean z) throws ZipException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        SplitOutputStream outputStream = splitOutputStream;
        LocalFileHeader localFileHeader2 = localFileHeader;
        long offset = j;
        long toUpdate = j2;
        byte[] bytesToWrite = bArr;
        boolean z2 = z;
        if (outputStream == null) {
            Throwable th4 = th3;
            new ZipException("invalid output stream, cannot update compressed size for local file header");
            throw th4;
        }
        try {
            if (!localFileHeader2.isWriteComprSizeInZip64ExtraRecord()) {
                outputStream.seek(offset + toUpdate);
                outputStream.write(bytesToWrite);
            } else if (bytesToWrite.length != 8) {
                Throwable th5 = th2;
                new ZipException("attempting to write a non 8-byte compressed size block for a zip64 file");
                throw th5;
            } else {
                long zip64CompressedSizeOffset = offset + toUpdate + 4 + 4 + 2 + 2 + ((long) localFileHeader2.getFileNameLength()) + 2 + 2 + 8;
                if (toUpdate == 22) {
                    zip64CompressedSizeOffset += 8;
                }
                outputStream.seek(zip64CompressedSizeOffset);
                outputStream.write(bytesToWrite);
            }
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th6 = th;
            new ZipException((Throwable) e2);
            throw th6;
        }
    }

    private void copyByteArrayToArrayList(byte[] bArr, List list) throws ZipException {
        Throwable th;
        byte[] byteArray = bArr;
        List arrayList = list;
        if (arrayList == null || byteArray == null) {
            Throwable th2 = th;
            new ZipException("one of the input parameters is null, cannot copy byte array to array list");
            throw th2;
        }
        for (int i = 0; i < byteArray.length; i++) {
            boolean add = arrayList.add(Byte.toString(byteArray[i]));
        }
    }

    private byte[] byteArrayListToByteArray(List list) throws ZipException {
        Throwable th;
        List arrayList = list;
        if (arrayList == null) {
            Throwable th2 = th;
            new ZipException("input byte array list is null, cannot conver to byte array");
            throw th2;
        } else if (arrayList.size() <= 0) {
            return null;
        } else {
            byte[] retBytes = new byte[arrayList.size()];
            for (int i = 0; i < arrayList.size(); i++) {
                retBytes[i] = Byte.parseByte((String) arrayList.get(i));
            }
            return retBytes;
        }
    }

    private int countNumberOfFileHeaderEntriesOnDisk(ArrayList arrayList, int i) throws ZipException {
        Throwable th;
        ArrayList fileHeaders = arrayList;
        int numOfDisk = i;
        if (fileHeaders == null) {
            Throwable th2 = th;
            new ZipException("file headers are null, cannot calculate number of entries on this disk");
            throw th2;
        }
        int noEntries = 0;
        for (int i2 = 0; i2 < fileHeaders.size(); i2++) {
            if (((FileHeader) fileHeaders.get(i2)).getDiskNumberStart() == numOfDisk) {
                noEntries++;
            }
        }
        return noEntries;
    }
}
