package net.lingala.zip4j.exception;

public class ZipException extends Exception {
    private static final long serialVersionUID = 1;
    private int code = -1;

    public ZipException() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ZipException(String msg) {
        super(msg);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ZipException(String message, Throwable cause) {
        super(message, cause);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ZipException(String msg, int code2) {
        super(msg);
        this.code = code2;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ZipException(String message, Throwable cause, int code2) {
        super(message, cause);
        this.code = code2;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ZipException(Throwable cause) {
        super(cause);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ZipException(Throwable cause, int code2) {
        super(cause);
        this.code = code2;
    }

    public int getCode() {
        return this.code;
    }
}
