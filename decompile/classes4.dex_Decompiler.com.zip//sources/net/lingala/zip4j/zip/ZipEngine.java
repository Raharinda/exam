package net.lingala.zip4j.zip;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.HashMap;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.EndCentralDirRecord;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.ZipModel;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.progress.ProgressMonitor;
import net.lingala.zip4j.util.ArchiveMaintainer;
import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.Zip4jUtil;

public class ZipEngine {
    private ZipModel zipModel;

    public ZipEngine(ZipModel zipModel2) throws ZipException {
        Throwable th;
        ZipModel zipModel3 = zipModel2;
        if (zipModel3 == null) {
            Throwable th2 = th;
            new ZipException("zip model is null in ZipEngine constructor");
            throw th2;
        }
        this.zipModel = zipModel3;
    }

    public void addFiles(ArrayList arrayList, ZipParameters zipParameters, ProgressMonitor progressMonitor, boolean z) throws ZipException {
        Throwable th;
        Thread thread;
        Throwable th2;
        ArrayList fileList = arrayList;
        ZipParameters parameters = zipParameters;
        ProgressMonitor progressMonitor2 = progressMonitor;
        boolean runInThread = z;
        if (fileList == null || parameters == null) {
            Throwable th3 = th;
            new ZipException("one of the input parameters is null when adding files");
            throw th3;
        } else if (fileList.size() <= 0) {
            Throwable th4 = th2;
            new ZipException("no files to add");
            throw th4;
        } else {
            progressMonitor2.setCurrentOperation(0);
            progressMonitor2.setState(1);
            progressMonitor2.setResult(1);
            if (runInThread) {
                progressMonitor2.setTotalWork(calculateTotalWork(fileList, parameters));
                progressMonitor2.setFileName(((File) fileList.get(0)).getAbsolutePath());
                new Thread(this, InternalZipConstants.THREAD_NAME, fileList, parameters, progressMonitor2) {
                    final ZipEngine this$0;
                    private final ArrayList val$fileList;
                    private final ZipParameters val$parameters;
                    private final ProgressMonitor val$progressMonitor;

                    {
                        this.this$0 = r9;
                        this.val$fileList = r11;
                        this.val$parameters = r12;
                        this.val$progressMonitor = r13;
                    }

                    public void run() {
                        try {
                            ZipEngine.access$0(this.this$0, this.val$fileList, this.val$parameters, this.val$progressMonitor);
                        } catch (ZipException e) {
                            ZipException zipException = e;
                        }
                    }
                };
                thread.start();
                return;
            }
            initAddFiles(fileList, parameters, progressMonitor2);
        }
    }

    static void access$0(ZipEngine zipEngine, ArrayList arrayList, ZipParameters zipParameters, ProgressMonitor progressMonitor) throws ZipException {
        zipEngine.initAddFiles(arrayList, zipParameters, progressMonitor);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v0, resolved type: java.io.OutputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r17v120, resolved type: net.lingala.zip4j.io.SplitOutputStream} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void initAddFiles(java.util.ArrayList r24, net.lingala.zip4j.model.ZipParameters r25, net.lingala.zip4j.progress.ProgressMonitor r26) throws net.lingala.zip4j.exception.ZipException {
        /*
            r23 = this;
            r3 = r23
            r4 = r24
            r5 = r25
            r6 = r26
            r17 = r4
            if (r17 == 0) goto L_0x0010
            r17 = r5
            if (r17 != 0) goto L_0x001f
        L_0x0010:
            net.lingala.zip4j.exception.ZipException r17 = new net.lingala.zip4j.exception.ZipException
            r22 = r17
            r17 = r22
            r18 = r22
            java.lang.String r19 = "one of the input parameters is null when adding files"
            r18.<init>((java.lang.String) r19)
            throw r17
        L_0x001f:
            r17 = r4
            int r17 = r17.size()
            if (r17 > 0) goto L_0x0036
            net.lingala.zip4j.exception.ZipException r17 = new net.lingala.zip4j.exception.ZipException
            r22 = r17
            r17 = r22
            r18 = r22
            java.lang.String r19 = "no files to add"
            r18.<init>((java.lang.String) r19)
            throw r17
        L_0x0036:
            r17 = r3
            r0 = r17
            net.lingala.zip4j.model.ZipModel r0 = r0.zipModel
            r17 = r0
            net.lingala.zip4j.model.EndCentralDirRecord r17 = r17.getEndCentralDirRecord()
            if (r17 != 0) goto L_0x0055
            r17 = r3
            r0 = r17
            net.lingala.zip4j.model.ZipModel r0 = r0.zipModel
            r17 = r0
            r18 = r3
            net.lingala.zip4j.model.EndCentralDirRecord r18 = r18.createEndOfCentralDirectoryRecord()
            r17.setEndCentralDirRecord(r18)
        L_0x0055:
            r17 = 0
            r7 = r17
            r17 = 0
            r8 = r17
            r17 = r3
            r18 = r5
            r17.checkParameters(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r3
            r18 = r4
            r19 = r5
            r20 = r6
            r17.removeFilesIfExists(r18, r19, r20)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r3
            r0 = r17
            net.lingala.zip4j.model.ZipModel r0 = r0.zipModel     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r0
            java.lang.String r17 = r17.getZipFile()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            boolean r17 = net.lingala.zip4j.util.Zip4jUtil.checkFileExists((java.lang.String) r17)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r9 = r17
            net.lingala.zip4j.io.SplitOutputStream r17 = new net.lingala.zip4j.io.SplitOutputStream     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r22 = r17
            r17 = r22
            r18 = r22
            java.io.File r19 = new java.io.File     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r22 = r19
            r19 = r22
            r20 = r22
            r21 = r3
            r0 = r21
            net.lingala.zip4j.model.ZipModel r0 = r0.zipModel     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r21 = r0
            java.lang.String r21 = r21.getZipFile()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r20.<init>(r21)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r20 = r3
            r0 = r20
            net.lingala.zip4j.model.ZipModel r0 = r0.zipModel     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r20 = r0
            long r20 = r20.getSplitLength()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r18.<init>((java.io.File) r19, (long) r20)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r10 = r17
            net.lingala.zip4j.io.ZipOutputStream r17 = new net.lingala.zip4j.io.ZipOutputStream     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r22 = r17
            r17 = r22
            r18 = r22
            r19 = r10
            r20 = r3
            r0 = r20
            net.lingala.zip4j.model.ZipModel r0 = r0.zipModel     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r20 = r0
            r18.<init>(r19, r20)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r7 = r17
            r17 = r9
            if (r17 == 0) goto L_0x0123
            r17 = r3
            r0 = r17
            net.lingala.zip4j.model.ZipModel r0 = r0.zipModel     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r0
            net.lingala.zip4j.model.EndCentralDirRecord r17 = r17.getEndCentralDirRecord()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            if (r17 != 0) goto L_0x010e
            net.lingala.zip4j.exception.ZipException r17 = new net.lingala.zip4j.exception.ZipException     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r22 = r17
            r17 = r22
            r18 = r22
            java.lang.String r19 = "invalid end of central directory record"
            r18.<init>((java.lang.String) r19)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            throw r17     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
        L_0x00e9:
            r17 = move-exception
            r9 = r17
            r17 = r6
            r18 = r9
            r17.endProgressMonitorError(r18)     // Catch:{ all -> 0x00f6 }
            r17 = r9
            throw r17     // Catch:{ all -> 0x00f6 }
        L_0x00f6:
            r17 = move-exception
            r15 = r17
            r17 = r8
            if (r17 == 0) goto L_0x0102
            r17 = r8
            r17.close()     // Catch:{ IOException -> 0x0312 }
        L_0x0102:
            r17 = r7
            if (r17 == 0) goto L_0x010b
            r17 = r7
            r17.close()     // Catch:{ IOException -> 0x0317 }
        L_0x010b:
            r17 = r15
            throw r17
        L_0x010e:
            r17 = r10
            r18 = r3
            r0 = r18
            net.lingala.zip4j.model.ZipModel r0 = r0.zipModel     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r18 = r0
            net.lingala.zip4j.model.EndCentralDirRecord r18 = r18.getEndCentralDirRecord()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            long r18 = r18.getOffsetOfStartOfCentralDir()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17.seek(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
        L_0x0123:
            r17 = 4096(0x1000, float:5.74E-42)
            r0 = r17
            byte[] r0 = new byte[r0]     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r0
            r11 = r17
            r17 = -1
            r12 = r17
            r17 = 0
            r13 = r17
        L_0x0135:
            r17 = r13
            r18 = r4
            int r18 = r18.size()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r0 = r17
            r1 = r18
            if (r0 < r1) goto L_0x0160
            r17 = r7
            r17.finish()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r6
            r17.endProgressMonitorSuccess()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r8
            if (r17 == 0) goto L_0x0156
            r17 = r8
            r17.close()     // Catch:{ IOException -> 0x031c }
        L_0x0156:
            r17 = r7
            if (r17 == 0) goto L_0x015f
            r17 = r7
            r17.close()     // Catch:{ IOException -> 0x0321 }
        L_0x015f:
            return
        L_0x0160:
            r17 = r6
            boolean r17 = r17.isCancelAllTasks()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            if (r17 == 0) goto L_0x0191
            r17 = r6
            r18 = 3
            r17.setResult(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r6
            r18 = 0
            r17.setState(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r8
            if (r17 == 0) goto L_0x017f
            r17 = r8
            r17.close()     // Catch:{ IOException -> 0x0189 }
        L_0x017f:
            r17 = r7
            if (r17 == 0) goto L_0x0188
            r17 = r7
            r17.close()     // Catch:{ IOException -> 0x018d }
        L_0x0188:
            goto L_0x015f
        L_0x0189:
            r17 = move-exception
            r16 = r17
            goto L_0x017f
        L_0x018d:
            r17 = move-exception
            r16 = r17
            goto L_0x0188
        L_0x0191:
            r17 = r5
            java.lang.Object r17 = r17.clone()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            net.lingala.zip4j.model.ZipParameters r17 = (net.lingala.zip4j.model.ZipParameters) r17     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r14 = r17
            r17 = r6
            r18 = r4
            r19 = r13
            java.lang.Object r18 = r18.get(r19)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            java.io.File r18 = (java.io.File) r18     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            java.lang.String r18 = r18.getAbsolutePath()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17.setFileName(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r4
            r18 = r13
            java.lang.Object r17 = r17.get(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            java.io.File r17 = (java.io.File) r17     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            boolean r17 = r17.isDirectory()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            if (r17 != 0) goto L_0x0247
            r17 = r14
            boolean r17 = r17.isEncryptFiles()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            if (r17 == 0) goto L_0x022c
            r17 = r14
            int r17 = r17.getEncryptionMethod()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            if (r17 != 0) goto L_0x022c
            r17 = r6
            r18 = 3
            r17.setCurrentOperation(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r14
            r18 = r4
            r19 = r13
            java.lang.Object r18 = r18.get(r19)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            java.io.File r18 = (java.io.File) r18     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            java.lang.String r18 = r18.getAbsolutePath()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r19 = r6
            long r18 = net.lingala.zip4j.util.CRCUtil.computeFileCRC(r18, r19)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r0 = r18
            int r0 = (int) r0     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r18 = r0
            r17.setSourceFileCRC(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r6
            r18 = 0
            r17.setCurrentOperation(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r6
            boolean r17 = r17.isCancelAllTasks()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            if (r17 == 0) goto L_0x022c
            r17 = r6
            r18 = 3
            r17.setResult(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r6
            r18 = 0
            r17.setState(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r8
            if (r17 == 0) goto L_0x0219
            r17 = r8
            r17.close()     // Catch:{ IOException -> 0x0224 }
        L_0x0219:
            r17 = r7
            if (r17 == 0) goto L_0x0222
            r17 = r7
            r17.close()     // Catch:{ IOException -> 0x0228 }
        L_0x0222:
            goto L_0x015f
        L_0x0224:
            r17 = move-exception
            r16 = r17
            goto L_0x0219
        L_0x0228:
            r17 = move-exception
            r16 = r17
            goto L_0x0222
        L_0x022c:
            r17 = r4
            r18 = r13
            java.lang.Object r17 = r17.get(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            java.io.File r17 = (java.io.File) r17     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            long r17 = net.lingala.zip4j.util.Zip4jUtil.getFileLengh((java.io.File) r17)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r19 = 0
            int r17 = (r17 > r19 ? 1 : (r17 == r19 ? 0 : -1))
            if (r17 != 0) goto L_0x0247
            r17 = r14
            r18 = 0
            r17.setCompressionMethod(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
        L_0x0247:
            r17 = r7
            r18 = r4
            r19 = r13
            java.lang.Object r18 = r18.get(r19)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            java.io.File r18 = (java.io.File) r18     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r19 = r14
            r17.putNextEntry(r18, r19)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r4
            r18 = r13
            java.lang.Object r17 = r17.get(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            java.io.File r17 = (java.io.File) r17     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            boolean r17 = r17.isDirectory()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            if (r17 == 0) goto L_0x0271
            r17 = r7
            r17.closeEntry()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
        L_0x026d:
            int r13 = r13 + 1
            goto L_0x0135
        L_0x0271:
            java.io.FileInputStream r17 = new java.io.FileInputStream     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r22 = r17
            r17 = r22
            r18 = r22
            r19 = r4
            r20 = r13
            java.lang.Object r19 = r19.get(r20)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            java.io.File r19 = (java.io.File) r19     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r18.<init>(r19)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r8 = r17
        L_0x0288:
            r17 = r8
            r18 = r11
            int r17 = r17.read(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r22 = r17
            r17 = r22
            r18 = r22
            r12 = r18
            r18 = -1
            r0 = r17
            r1 = r18
            if (r0 != r1) goto L_0x02c7
            r17 = r7
            r17.closeEntry()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r8
            if (r17 == 0) goto L_0x026d
            r17 = r8
            r17.close()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            goto L_0x026d
        L_0x02af:
            r17 = move-exception
            r9 = r17
            r17 = r6
            r18 = r9
            r17.endProgressMonitorError(r18)     // Catch:{ all -> 0x00f6 }
            net.lingala.zip4j.exception.ZipException r17 = new net.lingala.zip4j.exception.ZipException     // Catch:{ all -> 0x00f6 }
            r22 = r17
            r17 = r22
            r18 = r22
            r19 = r9
            r18.<init>((java.lang.Throwable) r19)     // Catch:{ all -> 0x00f6 }
            throw r17     // Catch:{ all -> 0x00f6 }
        L_0x02c7:
            r17 = r6
            boolean r17 = r17.isCancelAllTasks()     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            if (r17 == 0) goto L_0x02f9
            r17 = r6
            r18 = 3
            r17.setResult(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r6
            r18 = 0
            r17.setState(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r8
            if (r17 == 0) goto L_0x02e6
            r17 = r8
            r17.close()     // Catch:{ IOException -> 0x02f1 }
        L_0x02e6:
            r17 = r7
            if (r17 == 0) goto L_0x02ef
            r17 = r7
            r17.close()     // Catch:{ IOException -> 0x02f5 }
        L_0x02ef:
            goto L_0x015f
        L_0x02f1:
            r17 = move-exception
            r16 = r17
            goto L_0x02e6
        L_0x02f5:
            r17 = move-exception
            r16 = r17
            goto L_0x02ef
        L_0x02f9:
            r17 = r7
            r18 = r11
            r19 = 0
            r20 = r12
            r17.write(r18, r19, r20)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r17 = r6
            r18 = r12
            r0 = r18
            long r0 = (long) r0     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            r18 = r0
            r17.updateWorkCompleted(r18)     // Catch:{ ZipException -> 0x00e9, Exception -> 0x02af }
            goto L_0x0288
        L_0x0312:
            r17 = move-exception
            r16 = r17
            goto L_0x0102
        L_0x0317:
            r17 = move-exception
            r16 = r17
            goto L_0x010b
        L_0x031c:
            r17 = move-exception
            r16 = r17
            goto L_0x0156
        L_0x0321:
            r17 = move-exception
            r16 = r17
            goto L_0x015f
        */
        throw new UnsupportedOperationException("Method not decompiled: net.lingala.zip4j.zip.ZipEngine.initAddFiles(java.util.ArrayList, net.lingala.zip4j.model.ZipParameters, net.lingala.zip4j.progress.ProgressMonitor):void");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v0, resolved type: java.io.OutputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v47, resolved type: net.lingala.zip4j.io.SplitOutputStream} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void addStreamToZip(java.io.InputStream r18, net.lingala.zip4j.model.ZipParameters r19) throws net.lingala.zip4j.exception.ZipException {
        /*
            r17 = this;
            r1 = r17
            r2 = r18
            r3 = r19
            r11 = r2
            if (r11 == 0) goto L_0x000c
            r11 = r3
            if (r11 != 0) goto L_0x001b
        L_0x000c:
            net.lingala.zip4j.exception.ZipException r11 = new net.lingala.zip4j.exception.ZipException
            r16 = r11
            r11 = r16
            r12 = r16
            java.lang.String r13 = "one of the input parameters is null, cannot add stream to zip"
            r12.<init>((java.lang.String) r13)
            throw r11
        L_0x001b:
            r11 = 0
            r4 = r11
            r11 = r1
            r12 = r3
            r11.checkParameters(r12)     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r11 = r1
            net.lingala.zip4j.model.ZipModel r11 = r11.zipModel     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            java.lang.String r11 = r11.getZipFile()     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            boolean r11 = net.lingala.zip4j.util.Zip4jUtil.checkFileExists((java.lang.String) r11)     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r5 = r11
            net.lingala.zip4j.io.SplitOutputStream r11 = new net.lingala.zip4j.io.SplitOutputStream     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r16 = r11
            r11 = r16
            r12 = r16
            java.io.File r13 = new java.io.File     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r16 = r13
            r13 = r16
            r14 = r16
            r15 = r1
            net.lingala.zip4j.model.ZipModel r15 = r15.zipModel     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            java.lang.String r15 = r15.getZipFile()     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r14.<init>(r15)     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r14 = r1
            net.lingala.zip4j.model.ZipModel r14 = r14.zipModel     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            long r14 = r14.getSplitLength()     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r12.<init>((java.io.File) r13, (long) r14)     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r6 = r11
            net.lingala.zip4j.io.ZipOutputStream r11 = new net.lingala.zip4j.io.ZipOutputStream     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r16 = r11
            r11 = r16
            r12 = r16
            r13 = r6
            r14 = r1
            net.lingala.zip4j.model.ZipModel r14 = r14.zipModel     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r12.<init>(r13, r14)     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r4 = r11
            r11 = r5
            if (r11 == 0) goto L_0x009c
            r11 = r1
            net.lingala.zip4j.model.ZipModel r11 = r11.zipModel     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            net.lingala.zip4j.model.EndCentralDirRecord r11 = r11.getEndCentralDirRecord()     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            if (r11 != 0) goto L_0x008d
            net.lingala.zip4j.exception.ZipException r11 = new net.lingala.zip4j.exception.ZipException     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r16 = r11
            r11 = r16
            r12 = r16
            java.lang.String r13 = "invalid end of central directory record"
            r12.<init>((java.lang.String) r13)     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            throw r11     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
        L_0x007e:
            r11 = move-exception
            r5 = r11
            r11 = r5
            throw r11     // Catch:{ all -> 0x0082 }
        L_0x0082:
            r11 = move-exception
            r9 = r11
            r11 = r4
            if (r11 == 0) goto L_0x008b
            r11 = r4
            r11.close()     // Catch:{ IOException -> 0x00fc }
        L_0x008b:
            r11 = r9
            throw r11
        L_0x008d:
            r11 = r6
            r12 = r1
            net.lingala.zip4j.model.ZipModel r12 = r12.zipModel     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            net.lingala.zip4j.model.EndCentralDirRecord r12 = r12.getEndCentralDirRecord()     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            long r12 = r12.getOffsetOfStartOfCentralDir()     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r11.seek(r12)     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
        L_0x009c:
            r11 = 4096(0x1000, float:5.74E-42)
            byte[] r11 = new byte[r11]     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r7 = r11
            r11 = -1
            r8 = r11
            r11 = r4
            r12 = 0
            r13 = r3
            r11.putNextEntry(r12, r13)     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r11 = r3
            java.lang.String r11 = r11.getFileNameInZip()     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            java.lang.String r12 = "/"
            boolean r11 = r11.endsWith(r12)     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            if (r11 != 0) goto L_0x00d5
            r11 = r3
            java.lang.String r11 = r11.getFileNameInZip()     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            java.lang.String r12 = "\\"
            boolean r11 = r11.endsWith(r12)     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            if (r11 != 0) goto L_0x00d5
        L_0x00c5:
            r11 = r2
            r12 = r7
            int r11 = r11.read(r12)     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r16 = r11
            r11 = r16
            r12 = r16
            r8 = r12
            r12 = -1
            if (r11 != r12) goto L_0x00e5
        L_0x00d5:
            r11 = r4
            r11.closeEntry()     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r11 = r4
            r11.finish()     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            r11 = r4
            if (r11 == 0) goto L_0x00e4
            r11 = r4
            r11.close()     // Catch:{ IOException -> 0x00ff }
        L_0x00e4:
            return
        L_0x00e5:
            r11 = r4
            r12 = r7
            r13 = 0
            r14 = r8
            r11.write(r12, r13, r14)     // Catch:{ ZipException -> 0x007e, Exception -> 0x00ed }
            goto L_0x00c5
        L_0x00ed:
            r11 = move-exception
            r5 = r11
            net.lingala.zip4j.exception.ZipException r11 = new net.lingala.zip4j.exception.ZipException     // Catch:{ all -> 0x0082 }
            r16 = r11
            r11 = r16
            r12 = r16
            r13 = r5
            r12.<init>((java.lang.Throwable) r13)     // Catch:{ all -> 0x0082 }
            throw r11     // Catch:{ all -> 0x0082 }
        L_0x00fc:
            r11 = move-exception
            r10 = r11
            goto L_0x008b
        L_0x00ff:
            r11 = move-exception
            r10 = r11
            goto L_0x00e4
        */
        throw new UnsupportedOperationException("Method not decompiled: net.lingala.zip4j.zip.ZipEngine.addStreamToZip(java.io.InputStream, net.lingala.zip4j.model.ZipParameters):void");
    }

    public void addFolderToZip(File file, ZipParameters zipParameters, ProgressMonitor progressMonitor, boolean z) throws ZipException {
        Throwable th;
        String rootFolderPath;
        ArrayList arrayList;
        Throwable th2;
        StringBuffer stringBuffer;
        Throwable th3;
        Throwable th4;
        File file2 = file;
        ZipParameters parameters = zipParameters;
        ProgressMonitor progressMonitor2 = progressMonitor;
        boolean runInThread = z;
        if (file2 == null || parameters == null) {
            Throwable th5 = th;
            new ZipException("one of the input parameters is null, cannot add folder to zip");
            throw th5;
        } else if (!Zip4jUtil.checkFileExists(file2.getAbsolutePath())) {
            Throwable th6 = th4;
            new ZipException("input folder does not exist");
            throw th6;
        } else if (!file2.isDirectory()) {
            Throwable th7 = th3;
            new ZipException("input file is not a folder, user addFileToZip method to add files");
            throw th7;
        } else if (!Zip4jUtil.checkFileReadAccess(file2.getAbsolutePath())) {
            Throwable th8 = th2;
            new StringBuffer("cannot read folder: ");
            new ZipException(stringBuffer.append(file2.getAbsolutePath()).toString());
            throw th8;
        } else {
            if (!parameters.isIncludeRootFolder()) {
                rootFolderPath = file2.getAbsolutePath();
            } else if (file2.getAbsolutePath() != null) {
                rootFolderPath = file2.getAbsoluteFile().getParentFile() != null ? file2.getAbsoluteFile().getParentFile().getAbsolutePath() : "";
            } else {
                rootFolderPath = file2.getParentFile() != null ? file2.getParentFile().getAbsolutePath() : "";
            }
            parameters.setDefaultFolderPath(rootFolderPath);
            ArrayList fileList = Zip4jUtil.getFilesInDirectoryRec(file2, parameters.isReadHiddenFiles());
            if (parameters.isIncludeRootFolder()) {
                if (fileList == null) {
                    new ArrayList();
                    fileList = arrayList;
                }
                boolean add = fileList.add(file2);
            }
            addFiles(fileList, parameters, progressMonitor2, runInThread);
        }
    }

    private void checkParameters(ZipParameters zipParameters) throws ZipException {
        Throwable th;
        Throwable th2;
        Throwable th3;
        Throwable th4;
        Throwable th5;
        ZipParameters parameters = zipParameters;
        if (parameters == null) {
            Throwable th6 = th5;
            new ZipException("cannot validate zip parameters");
            throw th6;
        } else if (parameters.getCompressionMethod() != 0 && parameters.getCompressionMethod() != 8) {
            Throwable th7 = th4;
            new ZipException("unsupported compression type");
            throw th7;
        } else if (parameters.getCompressionMethod() == 8 && parameters.getCompressionLevel() < 0 && parameters.getCompressionLevel() > 9) {
            Throwable th8 = th3;
            new ZipException("invalid compression level. compression level dor deflate should be in the range of 0-9");
            throw th8;
        } else if (!parameters.isEncryptFiles()) {
            parameters.setAesKeyStrength(-1);
            parameters.setEncryptionMethod(-1);
        } else if (parameters.getEncryptionMethod() != 0 && parameters.getEncryptionMethod() != 99) {
            Throwable th9 = th2;
            new ZipException("unsupported encryption method");
            throw th9;
        } else if (parameters.getPassword() == null || parameters.getPassword().length <= 0) {
            Throwable th10 = th;
            new ZipException("input password is empty or null");
            throw th10;
        }
    }

    private void removeFilesIfExists(ArrayList arrayList, ZipParameters zipParameters, ProgressMonitor progressMonitor) throws ZipException {
        Throwable th;
        ArchiveMaintainer archiveMaintainer;
        Throwable th2;
        Throwable th3;
        ArrayList fileList = arrayList;
        ZipParameters parameters = zipParameters;
        ProgressMonitor progressMonitor2 = progressMonitor;
        if (this.zipModel != null) {
            if (this.zipModel.getCentralDirectory() != null) {
                if (this.zipModel.getCentralDirectory().getFileHeaders() != null) {
                    if (this.zipModel.getCentralDirectory().getFileHeaders().size() > 0) {
                        RandomAccessFile outputStream = null;
                        int i = 0;
                        while (true) {
                            try {
                                if (i < fileList.size()) {
                                    FileHeader fileHeader = Zip4jUtil.getFileHeader(this.zipModel, Zip4jUtil.getRelativeFileName(((File) fileList.get(i)).getAbsolutePath(), parameters.getRootFolderInZip(), parameters.getDefaultFolderPath()));
                                    if (fileHeader != null) {
                                        if (outputStream != null) {
                                            outputStream.close();
                                            outputStream = null;
                                        }
                                        new ArchiveMaintainer();
                                        progressMonitor2.setCurrentOperation(2);
                                        HashMap retMap = archiveMaintainer.initRemoveZipFile(this.zipModel, fileHeader, progressMonitor2);
                                        if (progressMonitor2.isCancelAllTasks()) {
                                            progressMonitor2.setResult(3);
                                            progressMonitor2.setState(0);
                                            if (outputStream != null) {
                                                try {
                                                    outputStream.close();
                                                    return;
                                                } catch (IOException e) {
                                                    IOException iOException = e;
                                                    return;
                                                }
                                            } else {
                                                return;
                                            }
                                        } else {
                                            progressMonitor2.setCurrentOperation(0);
                                            if (outputStream == null) {
                                                outputStream = prepareFileOutputStream();
                                                if (!(retMap == null || retMap.get(InternalZipConstants.OFFSET_CENTRAL_DIR) == null)) {
                                                    long offsetCentralDir = Long.parseLong((String) retMap.get(InternalZipConstants.OFFSET_CENTRAL_DIR));
                                                    if (offsetCentralDir >= 0) {
                                                        outputStream.seek(offsetCentralDir);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    i++;
                                } else if (outputStream != null) {
                                    try {
                                        outputStream.close();
                                        return;
                                    } catch (IOException e2) {
                                        IOException iOException2 = e2;
                                        return;
                                    }
                                } else {
                                    return;
                                }
                            } catch (NumberFormatException e3) {
                                NumberFormatException numberFormatException = e3;
                                Throwable th4 = th3;
                                new ZipException("NumberFormatException while parsing offset central directory. Cannot update already existing file header");
                                throw th4;
                            } catch (Exception e4) {
                                Exception exc = e4;
                                Throwable th5 = th2;
                                new ZipException("Error while parsing offset central directory. Cannot update already existing file header");
                                throw th5;
                            } catch (IOException e5) {
                                IOException e6 = e5;
                                try {
                                    Throwable th6 = th;
                                    new ZipException((Throwable) e6);
                                    throw th6;
                                } catch (Throwable th7) {
                                    Throwable th8 = th7;
                                    if (outputStream != null) {
                                        try {
                                            outputStream.close();
                                        } catch (IOException e7) {
                                            IOException iOException3 = e7;
                                        }
                                    }
                                    throw th8;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private RandomAccessFile prepareFileOutputStream() throws ZipException {
        Throwable th;
        File file;
        RandomAccessFile randomAccessFile;
        Throwable th2;
        String outPath = this.zipModel.getZipFile();
        if (!Zip4jUtil.isStringNotNullAndNotEmpty(outPath)) {
            Throwable th3 = th2;
            new ZipException("invalid output path");
            throw th3;
        }
        try {
            new File(outPath);
            File outFile = file;
            if (!outFile.getParentFile().exists()) {
                boolean mkdirs = outFile.getParentFile().mkdirs();
            }
            RandomAccessFile randomAccessFile2 = randomAccessFile;
            new RandomAccessFile(outFile, InternalZipConstants.WRITE_MODE);
            return randomAccessFile2;
        } catch (FileNotFoundException e) {
            FileNotFoundException e2 = e;
            Throwable th4 = th;
            new ZipException((Throwable) e2);
            throw th4;
        }
    }

    private EndCentralDirRecord createEndOfCentralDirectoryRecord() {
        EndCentralDirRecord endCentralDirRecord;
        new EndCentralDirRecord();
        EndCentralDirRecord endCentralDirRecord2 = endCentralDirRecord;
        endCentralDirRecord2.setSignature(InternalZipConstants.ENDSIG);
        endCentralDirRecord2.setNoOfThisDisk(0);
        endCentralDirRecord2.setTotNoOfEntriesInCentralDir(0);
        endCentralDirRecord2.setTotNoOfEntriesInCentralDirOnThisDisk(0);
        endCentralDirRecord2.setOffsetOfStartOfCentralDir(0);
        return endCentralDirRecord2;
    }

    private long calculateTotalWork(ArrayList arrayList, ZipParameters zipParameters) throws ZipException {
        FileHeader fileHeader;
        File file;
        Throwable th;
        ArrayList fileList = arrayList;
        ZipParameters parameters = zipParameters;
        if (fileList == null) {
            Throwable th2 = th;
            new ZipException("file list is null, cannot calculate total work");
            throw th2;
        }
        long totalWork = 0;
        for (int i = 0; i < fileList.size(); i++) {
            if ((fileList.get(i) instanceof File) && ((File) fileList.get(i)).exists()) {
                if (!parameters.isEncryptFiles() || parameters.getEncryptionMethod() != 0) {
                    totalWork += Zip4jUtil.getFileLengh((File) fileList.get(i));
                } else {
                    totalWork += Zip4jUtil.getFileLengh((File) fileList.get(i)) * 2;
                }
                if (!(this.zipModel.getCentralDirectory() == null || this.zipModel.getCentralDirectory().getFileHeaders() == null || this.zipModel.getCentralDirectory().getFileHeaders().size() <= 0 || (fileHeader = Zip4jUtil.getFileHeader(this.zipModel, Zip4jUtil.getRelativeFileName(((File) fileList.get(i)).getAbsolutePath(), parameters.getRootFolderInZip(), parameters.getDefaultFolderPath()))) == null)) {
                    new File(this.zipModel.getZipFile());
                    totalWork += Zip4jUtil.getFileLengh(file) - fileHeader.getCompressedSize();
                }
            }
        }
        return totalWork;
    }
}
