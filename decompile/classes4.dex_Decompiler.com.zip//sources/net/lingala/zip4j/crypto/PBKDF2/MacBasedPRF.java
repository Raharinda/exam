package net.lingala.zip4j.crypto.PBKDF2;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class MacBasedPRF implements PRF {
    protected int hLen;
    protected Mac mac;
    protected String macAlgorithm;

    public MacBasedPRF(String str) {
        Throwable th;
        String macAlgorithm2 = str;
        this.macAlgorithm = macAlgorithm2;
        try {
            this.mac = Mac.getInstance(macAlgorithm2);
            this.hLen = this.mac.getMacLength();
        } catch (NoSuchAlgorithmException e) {
            NoSuchAlgorithmException e2 = e;
            Throwable th2 = th;
            new RuntimeException(e2);
            throw th2;
        }
    }

    public MacBasedPRF(String str, String provider) {
        Throwable th;
        Throwable th2;
        String macAlgorithm2 = str;
        this.macAlgorithm = macAlgorithm2;
        try {
            this.mac = Mac.getInstance(macAlgorithm2, provider);
            this.hLen = this.mac.getMacLength();
        } catch (NoSuchAlgorithmException e) {
            NoSuchAlgorithmException e2 = e;
            Throwable th3 = th2;
            new RuntimeException(e2);
            throw th3;
        } catch (NoSuchProviderException e3) {
            NoSuchProviderException e4 = e3;
            Throwable th4 = th;
            new RuntimeException(e4);
            throw th4;
        }
    }

    public byte[] doFinal(byte[] M) {
        return this.mac.doFinal(M);
    }

    public byte[] doFinal() {
        return this.mac.doFinal();
    }

    public int getHLen() {
        return this.hLen;
    }

    public void init(byte[] P) {
        Throwable th;
        Key key;
        try {
            new SecretKeySpec(P, this.macAlgorithm);
            this.mac.init(key);
        } catch (InvalidKeyException e) {
            InvalidKeyException e2 = e;
            Throwable th2 = th;
            new RuntimeException(e2);
            throw th2;
        }
    }

    public void update(byte[] U) {
        Throwable th;
        try {
            this.mac.update(U);
        } catch (IllegalStateException e) {
            IllegalStateException e2 = e;
            Throwable th2 = th;
            new RuntimeException(e2);
            throw th2;
        }
    }

    public void update(byte[] U, int start, int len) {
        Throwable th;
        try {
            this.mac.update(U, start, len);
        } catch (IllegalStateException e) {
            IllegalStateException e2 = e;
            Throwable th2 = th;
            new RuntimeException(e2);
            throw th2;
        }
    }
}
