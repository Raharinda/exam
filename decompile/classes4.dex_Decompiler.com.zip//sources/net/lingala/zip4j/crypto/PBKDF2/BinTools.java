package net.lingala.zip4j.crypto.PBKDF2;

class BinTools {
    public static final String hex = "0123456789ABCDEF";

    BinTools() {
    }

    public static String bin2hex(byte[] bArr) {
        StringBuffer stringBuffer;
        byte[] b = bArr;
        if (b == null) {
            return "";
        }
        new StringBuffer(2 * b.length);
        StringBuffer sb = stringBuffer;
        for (int i = 0; i < b.length; i++) {
            int v = (256 + b[i]) % 256;
            StringBuffer append = sb.append(hex.charAt((v / 16) & 15));
            StringBuffer append2 = sb.append(hex.charAt((v % 16) & 15));
        }
        return sb.toString();
    }

    public static byte[] hex2bin(String str) {
        StringBuffer stringBuffer;
        String s = str;
        String m = s;
        if (s == null) {
            m = "";
        } else if (s.length() % 2 != 0) {
            new StringBuffer("0");
            m = stringBuffer.append(s).toString();
        }
        byte[] r = new byte[(m.length() / 2)];
        int i = 0;
        int n = 0;
        while (i < m.length()) {
            int i2 = i;
            int i3 = i + 1;
            char h = m.charAt(i2);
            int i4 = i3;
            i = i3 + 1;
            r[n] = (byte) ((hex2bin(h) * 16) + hex2bin(m.charAt(i4)));
            n++;
        }
        return r;
    }

    public static int hex2bin(char c) {
        Throwable th;
        StringBuffer stringBuffer;
        char c2 = c;
        if (c2 >= '0' && c2 <= '9') {
            return c2 - '0';
        }
        if (c2 >= 'A' && c2 <= 'F') {
            return (c2 - 'A') + 10;
        }
        if (c2 >= 'a' && c2 <= 'f') {
            return (c2 - 'a') + 10;
        }
        Throwable th2 = th;
        new StringBuffer("Input string may only contain hex digits, but found '");
        new IllegalArgumentException(stringBuffer.append(c2).append("'").toString());
        throw th2;
    }
}
