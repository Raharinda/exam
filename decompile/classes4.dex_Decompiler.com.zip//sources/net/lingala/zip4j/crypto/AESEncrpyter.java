package net.lingala.zip4j.crypto;

import java.util.Random;
import net.lingala.zip4j.crypto.PBKDF2.MacBasedPRF;
import net.lingala.zip4j.crypto.PBKDF2.PBKDF2Engine;
import net.lingala.zip4j.crypto.PBKDF2.PBKDF2Parameters;
import net.lingala.zip4j.crypto.engine.AESEngine;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.util.Raw;

public class AESEncrpyter implements IEncrypter {
    private int KEY_LENGTH;
    private int MAC_LENGTH;
    private final int PASSWORD_VERIFIER_LENGTH = 2;
    private int SALT_LENGTH;
    private AESEngine aesEngine;
    private byte[] aesKey;
    private byte[] counterBlock;
    private byte[] derivedPasswordVerifier;
    private boolean finished;
    private byte[] iv;
    private int keyStrength;
    private int loopCount = 0;
    private MacBasedPRF mac;
    private byte[] macKey;
    private int nonce = 1;
    private char[] password;
    private byte[] saltBytes;

    public AESEncrpyter(char[] cArr, int i) throws ZipException {
        Throwable th;
        Throwable th2;
        char[] password2 = cArr;
        int keyStrength2 = i;
        if (password2 == null || password2.length == 0) {
            Throwable th3 = th;
            new ZipException("input password is empty or null in AES encrypter constructor");
            throw th3;
        } else if (keyStrength2 == 1 || keyStrength2 == 3) {
            this.password = password2;
            this.keyStrength = keyStrength2;
            this.finished = false;
            this.counterBlock = new byte[16];
            this.iv = new byte[16];
            init();
        } else {
            Throwable th4 = th2;
            new ZipException("Invalid key strength in AES encrypter constructor");
            throw th4;
        }
    }

    private void init() throws ZipException {
        Throwable th;
        AESEngine aESEngine;
        MacBasedPRF macBasedPRF;
        Throwable th2;
        switch (this.keyStrength) {
            case 1:
                this.KEY_LENGTH = 16;
                this.MAC_LENGTH = 16;
                this.SALT_LENGTH = 8;
                break;
            case 3:
                this.KEY_LENGTH = 32;
                this.MAC_LENGTH = 32;
                this.SALT_LENGTH = 16;
                break;
            default:
                Throwable th3 = th2;
                new ZipException("invalid aes key strength, cannot determine key sizes");
                throw th3;
        }
        this.saltBytes = generateSalt(this.SALT_LENGTH);
        byte[] keyBytes = deriveKey(this.saltBytes, this.password);
        if (keyBytes == null || keyBytes.length != this.KEY_LENGTH + this.MAC_LENGTH + 2) {
            Throwable th4 = th;
            new ZipException("invalid key generated, cannot decrypt file");
            throw th4;
        }
        this.aesKey = new byte[this.KEY_LENGTH];
        this.macKey = new byte[this.MAC_LENGTH];
        this.derivedPasswordVerifier = new byte[2];
        System.arraycopy(keyBytes, 0, this.aesKey, 0, this.KEY_LENGTH);
        System.arraycopy(keyBytes, this.KEY_LENGTH, this.macKey, 0, this.MAC_LENGTH);
        System.arraycopy(keyBytes, this.KEY_LENGTH + this.MAC_LENGTH, this.derivedPasswordVerifier, 0, 2);
        new AESEngine(this.aesKey);
        this.aesEngine = aESEngine;
        new MacBasedPRF("HmacSHA1");
        this.mac = macBasedPRF;
        this.mac.init(this.macKey);
    }

    private byte[] deriveKey(byte[] salt, char[] cArr) throws ZipException {
        Throwable th;
        PBKDF2Parameters p;
        PBKDF2Engine e;
        char[] password2 = cArr;
        try {
            new PBKDF2Parameters("HmacSHA1", "ISO-8859-1", salt, 1000);
            new PBKDF2Engine(p);
            return e.deriveKey(password2, this.KEY_LENGTH + this.MAC_LENGTH + 2);
        } catch (Exception e2) {
            Exception e3 = e2;
            Throwable th2 = th;
            new ZipException((Throwable) e3);
            throw th2;
        }
    }

    public int encryptData(byte[] bArr) throws ZipException {
        Throwable th;
        byte[] buff = bArr;
        if (buff != null) {
            return encryptData(buff, 0, buff.length);
        }
        Throwable th2 = th;
        new ZipException("input bytes are null, cannot perform AES encrpytion");
        throw th2;
    }

    public int encryptData(byte[] bArr, int i, int i2) throws ZipException {
        Throwable th;
        byte[] buff = bArr;
        int start = i;
        int len = i2;
        if (this.finished) {
            Throwable th2 = th;
            new ZipException("AES Encrypter is in finished state (A non 16 byte block has already been passed to encrypter)");
            throw th2;
        }
        if (len % 16 != 0) {
            this.finished = true;
        }
        for (int j = start; j < start + len; j += 16) {
            this.loopCount = j + 16 <= start + len ? 16 : (start + len) - j;
            Raw.prepareBuffAESIVBytes(this.iv, this.nonce, 16);
            int processBlock = this.aesEngine.processBlock(this.iv, this.counterBlock);
            for (int k = 0; k < this.loopCount; k++) {
                buff[j + k] = (byte) (buff[j + k] ^ this.counterBlock[k]);
            }
            this.mac.update(buff, j, this.loopCount);
            this.nonce++;
        }
        return len;
    }

    private static byte[] generateSalt(int i) throws ZipException {
        Random rand;
        Throwable th;
        int size = i;
        if (size == 8 || size == 16) {
            int rounds = 0;
            if (size == 8) {
                rounds = 2;
            }
            if (size == 16) {
                rounds = 4;
            }
            byte[] salt = new byte[size];
            for (int j = 0; j < rounds; j++) {
                new Random();
                int i2 = rand.nextInt();
                salt[0 + (j * 4)] = (byte) (i2 >> 24);
                salt[1 + (j * 4)] = (byte) (i2 >> 16);
                salt[2 + (j * 4)] = (byte) (i2 >> 8);
                salt[3 + (j * 4)] = (byte) i2;
            }
            return salt;
        }
        Throwable th2 = th;
        new ZipException("invalid salt size, cannot generate salt");
        throw th2;
    }

    public byte[] getFinalMac() {
        byte[] macBytes = new byte[10];
        System.arraycopy(this.mac.doFinal(), 0, macBytes, 0, 10);
        return macBytes;
    }

    public byte[] getDerivedPasswordVerifier() {
        return this.derivedPasswordVerifier;
    }

    public void setDerivedPasswordVerifier(byte[] derivedPasswordVerifier2) {
        byte[] bArr = derivedPasswordVerifier2;
        this.derivedPasswordVerifier = bArr;
    }

    public byte[] getSaltBytes() {
        return this.saltBytes;
    }

    public void setSaltBytes(byte[] saltBytes2) {
        byte[] bArr = saltBytes2;
        this.saltBytes = bArr;
    }

    public int getSaltLength() {
        return this.SALT_LENGTH;
    }

    public int getPasswordVeriifierLength() {
        return 2;
    }
}
