package net.lingala.zip4j.crypto;

import java.util.Random;
import net.lingala.zip4j.crypto.engine.ZipCryptoEngine;
import net.lingala.zip4j.exception.ZipException;

public class StandardEncrypter implements IEncrypter {
    private byte[] headerBytes;
    private ZipCryptoEngine zipCryptoEngine;

    public StandardEncrypter(char[] cArr, int i) throws ZipException {
        Throwable th;
        ZipCryptoEngine zipCryptoEngine2;
        char[] password = cArr;
        int crc = i;
        if (password == null || password.length <= 0) {
            Throwable th2 = th;
            new ZipException("input password is null or empty in standard encrpyter constructor");
            throw th2;
        }
        new ZipCryptoEngine();
        this.zipCryptoEngine = zipCryptoEngine2;
        this.headerBytes = new byte[12];
        init(password, crc);
    }

    private void init(char[] cArr, int i) throws ZipException {
        Throwable th;
        Throwable th2;
        char[] password = cArr;
        int crc = i;
        if (password == null || password.length <= 0) {
            Throwable th3 = th;
            new ZipException("input password is null or empty, cannot initialize standard encrypter");
            throw th3;
        }
        this.zipCryptoEngine.initKeys(password);
        this.headerBytes = generateRandomBytes(12);
        this.zipCryptoEngine.initKeys(password);
        this.headerBytes[11] = (byte) (crc >>> 24);
        this.headerBytes[10] = (byte) (crc >>> 16);
        if (this.headerBytes.length < 12) {
            Throwable th4 = th2;
            new ZipException("invalid header bytes generated, cannot perform standard encryption");
            throw th4;
        }
        int encryptData = encryptData(this.headerBytes);
    }

    public int encryptData(byte[] bArr) throws ZipException {
        Throwable th;
        byte[] buff = bArr;
        if (buff != null) {
            return encryptData(buff, 0, buff.length);
        }
        Throwable th2 = th;
        new NullPointerException();
        throw th2;
    }

    public int encryptData(byte[] bArr, int i, int i2) throws ZipException {
        Throwable th;
        Throwable th2;
        byte[] buff = bArr;
        int start = i;
        int len = i2;
        if (len < 0) {
            Throwable th3 = th2;
            new ZipException("invalid length specified to decrpyt data");
            throw th3;
        }
        int i3 = start;
        while (i3 < start + len) {
            try {
                buff[i3] = encryptByte(buff[i3]);
                i3++;
            } catch (Exception e) {
                Exception e2 = e;
                Throwable th4 = th;
                new ZipException((Throwable) e2);
                throw th4;
            }
        }
        return len;
    }

    /* access modifiers changed from: protected */
    public byte encryptByte(byte b) {
        byte val = b;
        byte temp_val = (byte) (val ^ (this.zipCryptoEngine.decryptByte() & 255));
        this.zipCryptoEngine.updateKeys(val);
        return temp_val;
    }

    /* access modifiers changed from: protected */
    public byte[] generateRandomBytes(int i) throws ZipException {
        Random random;
        Throwable th;
        int size = i;
        if (size <= 0) {
            Throwable th2 = th;
            new ZipException("size is either 0 or less than 0, cannot generate header for standard encryptor");
            throw th2;
        }
        byte[] buff = new byte[size];
        new Random();
        Random rand = random;
        for (int i2 = 0; i2 < buff.length; i2++) {
            buff[i2] = encryptByte((byte) rand.nextInt(256));
        }
        return buff;
    }

    public byte[] getHeaderBytes() {
        return this.headerBytes;
    }
}
