package net.lingala.zip4j.crypto.engine;

public class ZipCryptoEngine {
    private static final int[] CRC_TABLE = new int[256];
    private final int[] keys = new int[3];

    static {
        int i;
        for (int i2 = 0; i2 < 256; i2++) {
            int r = i2;
            for (int j = 0; j < 8; j++) {
                if ((r & 1) == 1) {
                    i = (r >>> 1) ^ -306674912;
                } else {
                    i = r >>> 1;
                }
                r = i;
            }
            CRC_TABLE[i2] = r;
        }
    }

    public ZipCryptoEngine() {
    }

    public void initKeys(char[] cArr) {
        char[] password = cArr;
        this.keys[0] = 305419896;
        this.keys[1] = 591751049;
        this.keys[2] = 878082192;
        for (int i = 0; i < password.length; i++) {
            updateKeys((byte) (password[i] & 255));
        }
    }

    public void updateKeys(byte charAt) {
        this.keys[0] = crc32(this.keys[0], charAt);
        int[] iArr = this.keys;
        iArr[1] = iArr[1] + (this.keys[0] & 255);
        this.keys[1] = (this.keys[1] * 134775813) + 1;
        this.keys[2] = crc32(this.keys[2], (byte) (this.keys[1] >> 24));
    }

    private int crc32(int i, byte charAt) {
        int oldCrc = i;
        return (oldCrc >>> 8) ^ CRC_TABLE[(oldCrc ^ charAt) & 255];
    }

    public byte decryptByte() {
        int temp = this.keys[2] | 2;
        return (byte) ((temp * (temp ^ 1)) >>> 8);
    }
}
