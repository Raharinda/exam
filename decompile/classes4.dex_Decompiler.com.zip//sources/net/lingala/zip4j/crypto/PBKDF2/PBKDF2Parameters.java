package net.lingala.zip4j.crypto.PBKDF2;

public class PBKDF2Parameters {
    protected byte[] derivedKey;
    protected String hashAlgorithm;
    protected String hashCharset;
    protected int iterationCount;
    protected byte[] salt;

    public PBKDF2Parameters() {
        this.hashAlgorithm = null;
        this.hashCharset = "UTF-8";
        this.salt = null;
        this.iterationCount = 1000;
        this.derivedKey = null;
    }

    public PBKDF2Parameters(String hashAlgorithm2, String hashCharset2, byte[] salt2, int iterationCount2) {
        this.hashAlgorithm = hashAlgorithm2;
        this.hashCharset = hashCharset2;
        this.salt = salt2;
        this.iterationCount = iterationCount2;
        this.derivedKey = null;
    }

    public PBKDF2Parameters(String hashAlgorithm2, String hashCharset2, byte[] salt2, int iterationCount2, byte[] derivedKey2) {
        this.hashAlgorithm = hashAlgorithm2;
        this.hashCharset = hashCharset2;
        this.salt = salt2;
        this.iterationCount = iterationCount2;
        this.derivedKey = derivedKey2;
    }

    public int getIterationCount() {
        return this.iterationCount;
    }

    public void setIterationCount(int iterationCount2) {
        int i = iterationCount2;
        this.iterationCount = i;
    }

    public byte[] getSalt() {
        return this.salt;
    }

    public void setSalt(byte[] salt2) {
        byte[] bArr = salt2;
        this.salt = bArr;
    }

    public byte[] getDerivedKey() {
        return this.derivedKey;
    }

    public void setDerivedKey(byte[] derivedKey2) {
        byte[] bArr = derivedKey2;
        this.derivedKey = bArr;
    }

    public String getHashAlgorithm() {
        return this.hashAlgorithm;
    }

    public void setHashAlgorithm(String hashAlgorithm2) {
        String str = hashAlgorithm2;
        this.hashAlgorithm = str;
    }

    public String getHashCharset() {
        return this.hashCharset;
    }

    public void setHashCharset(String hashCharset2) {
        String str = hashCharset2;
        this.hashCharset = str;
    }
}
