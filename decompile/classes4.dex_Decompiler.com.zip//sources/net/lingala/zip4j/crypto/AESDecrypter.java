package net.lingala.zip4j.crypto;

import java.util.Arrays;
import net.lingala.zip4j.crypto.PBKDF2.MacBasedPRF;
import net.lingala.zip4j.crypto.PBKDF2.PBKDF2Engine;
import net.lingala.zip4j.crypto.PBKDF2.PBKDF2Parameters;
import net.lingala.zip4j.crypto.engine.AESEngine;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.AESExtraDataRecord;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.util.Raw;

public class AESDecrypter implements IDecrypter {
    private int KEY_LENGTH;
    private int MAC_LENGTH;
    private final int PASSWORD_VERIFIER_LENGTH = 2;
    private int SALT_LENGTH;
    private AESEngine aesEngine;
    private byte[] aesKey;
    private byte[] counterBlock;
    private byte[] derivedPasswordVerifier;
    private byte[] iv;
    private LocalFileHeader localFileHeader;
    private int loopCount = 0;
    private MacBasedPRF mac;
    private byte[] macKey;
    private int nonce = 1;
    private byte[] storedMac;

    public AESDecrypter(LocalFileHeader localFileHeader2, byte[] bArr, byte[] bArr2) throws ZipException {
        Throwable th;
        LocalFileHeader localFileHeader3 = localFileHeader2;
        byte[] salt = bArr;
        byte[] passwordVerifier = bArr2;
        if (localFileHeader3 == null) {
            Throwable th2 = th;
            new ZipException("one of the input parameters is null in AESDecryptor Constructor");
            throw th2;
        }
        this.localFileHeader = localFileHeader3;
        this.storedMac = null;
        this.iv = new byte[16];
        this.counterBlock = new byte[16];
        init(salt, passwordVerifier);
    }

    private void init(byte[] bArr, byte[] bArr2) throws ZipException {
        Throwable th;
        Throwable th2;
        AESEngine aESEngine;
        MacBasedPRF macBasedPRF;
        Throwable th3;
        StringBuffer stringBuffer;
        Throwable th4;
        Throwable th5;
        StringBuffer stringBuffer2;
        Throwable th6;
        Throwable th7;
        byte[] salt = bArr;
        byte[] passwordVerifier = bArr2;
        if (this.localFileHeader == null) {
            Throwable th8 = th7;
            new ZipException("invalid file header in init method of AESDecryptor");
            throw th8;
        }
        AESExtraDataRecord aesExtraDataRecord = this.localFileHeader.getAesExtraDataRecord();
        if (aesExtraDataRecord == null) {
            Throwable th9 = th6;
            new ZipException("invalid aes extra data record - in init method of AESDecryptor");
            throw th9;
        }
        switch (aesExtraDataRecord.getAesStrength()) {
            case 1:
                this.KEY_LENGTH = 16;
                this.MAC_LENGTH = 16;
                this.SALT_LENGTH = 8;
                break;
            case 2:
                this.KEY_LENGTH = 24;
                this.MAC_LENGTH = 24;
                this.SALT_LENGTH = 12;
                break;
            case 3:
                this.KEY_LENGTH = 32;
                this.MAC_LENGTH = 32;
                this.SALT_LENGTH = 16;
                break;
            default:
                Throwable th10 = th5;
                new StringBuffer("invalid aes key strength for file: ");
                new ZipException(stringBuffer2.append(this.localFileHeader.getFileName()).toString());
                throw th10;
        }
        if (this.localFileHeader.getPassword() == null || this.localFileHeader.getPassword().length <= 0) {
            Throwable th11 = th;
            new ZipException("empty or null password provided for AES Decryptor");
            throw th11;
        }
        byte[] derivedKey = deriveKey(salt, this.localFileHeader.getPassword());
        if (derivedKey == null || derivedKey.length != this.KEY_LENGTH + this.MAC_LENGTH + 2) {
            Throwable th12 = th2;
            new ZipException("invalid derived key");
            throw th12;
        }
        this.aesKey = new byte[this.KEY_LENGTH];
        this.macKey = new byte[this.MAC_LENGTH];
        this.derivedPasswordVerifier = new byte[2];
        System.arraycopy(derivedKey, 0, this.aesKey, 0, this.KEY_LENGTH);
        System.arraycopy(derivedKey, this.KEY_LENGTH, this.macKey, 0, this.MAC_LENGTH);
        System.arraycopy(derivedKey, this.KEY_LENGTH + this.MAC_LENGTH, this.derivedPasswordVerifier, 0, 2);
        if (this.derivedPasswordVerifier == null) {
            Throwable th13 = th4;
            new ZipException("invalid derived password verifier for AES");
            throw th13;
        } else if (!Arrays.equals(passwordVerifier, this.derivedPasswordVerifier)) {
            Throwable th14 = th3;
            new StringBuffer("Wrong Password for file: ");
            new ZipException(stringBuffer.append(this.localFileHeader.getFileName()).toString(), 5);
            throw th14;
        } else {
            new AESEngine(this.aesKey);
            this.aesEngine = aESEngine;
            new MacBasedPRF("HmacSHA1");
            this.mac = macBasedPRF;
            this.mac.init(this.macKey);
        }
    }

    public int decryptData(byte[] bArr, int i, int i2) throws ZipException {
        Throwable th;
        Throwable th2;
        byte[] buff = bArr;
        int start = i;
        int len = i2;
        if (this.aesEngine == null) {
            Throwable th3 = th2;
            new ZipException("AES not initialized properly");
            throw th3;
        }
        int j = start;
        while (j < start + len) {
            try {
                this.loopCount = j + 16 <= start + len ? 16 : (start + len) - j;
                this.mac.update(buff, j, this.loopCount);
                Raw.prepareBuffAESIVBytes(this.iv, this.nonce, 16);
                int processBlock = this.aesEngine.processBlock(this.iv, this.counterBlock);
                for (int k = 0; k < this.loopCount; k++) {
                    buff[j + k] = (byte) (buff[j + k] ^ this.counterBlock[k]);
                }
                this.nonce++;
                j += 16;
            } catch (ZipException e) {
                throw e;
            } catch (Exception e2) {
                Exception e3 = e2;
                Throwable th4 = th;
                new ZipException((Throwable) e3);
                throw th4;
            }
        }
        return len;
    }

    public int decryptData(byte[] bArr) throws ZipException {
        byte[] buff = bArr;
        return decryptData(buff, 0, buff.length);
    }

    private byte[] deriveKey(byte[] salt, char[] cArr) throws ZipException {
        Throwable th;
        PBKDF2Parameters p;
        PBKDF2Engine e;
        char[] password = cArr;
        try {
            new PBKDF2Parameters("HmacSHA1", "ISO-8859-1", salt, 1000);
            new PBKDF2Engine(p);
            return e.deriveKey(password, this.KEY_LENGTH + this.MAC_LENGTH + 2);
        } catch (Exception e2) {
            Exception e3 = e2;
            Throwable th2 = th;
            new ZipException((Throwable) e3);
            throw th2;
        }
    }

    public int getPasswordVerifierLength() {
        return 2;
    }

    public int getSaltLength() {
        return this.SALT_LENGTH;
    }

    public byte[] getCalculatedAuthenticationBytes() {
        return this.mac.doFinal();
    }

    public void setStoredMac(byte[] storedMac2) {
        byte[] bArr = storedMac2;
        this.storedMac = bArr;
    }

    public byte[] getStoredMac() {
        return this.storedMac;
    }
}
