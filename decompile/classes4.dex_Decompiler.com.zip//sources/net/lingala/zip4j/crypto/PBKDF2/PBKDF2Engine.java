package net.lingala.zip4j.crypto.PBKDF2;

import net.lingala.zip4j.util.InternalZipConstants;
import net.lingala.zip4j.util.Raw;

public class PBKDF2Engine {
    protected PBKDF2Parameters parameters;
    protected PRF prf;

    public PBKDF2Engine() {
        this.parameters = null;
        this.prf = null;
    }

    public PBKDF2Engine(PBKDF2Parameters parameters2) {
        this.parameters = parameters2;
        this.prf = null;
    }

    public PBKDF2Engine(PBKDF2Parameters parameters2, PRF prf2) {
        this.parameters = parameters2;
        this.prf = prf2;
    }

    public byte[] deriveKey(char[] inputPassword) {
        return deriveKey(inputPassword, 0);
    }

    public byte[] deriveKey(char[] cArr, int i) {
        Throwable th;
        char[] inputPassword = cArr;
        int dkLen = i;
        byte[] bArr = null;
        byte[] bArr2 = null;
        if (inputPassword == null) {
            Throwable th2 = th;
            new NullPointerException();
            throw th2;
        }
        assertPRF(Raw.convertCharArrayToByteArray(inputPassword));
        if (dkLen == 0) {
            dkLen = this.prf.getHLen();
        }
        return PBKDF2(this.prf, this.parameters.getSalt(), this.parameters.getIterationCount(), dkLen);
    }

    public boolean verifyKey(char[] cArr) {
        char[] inputPassword = cArr;
        byte[] referenceKey = getParameters().getDerivedKey();
        if (referenceKey == null || referenceKey.length == 0) {
            return false;
        }
        byte[] inputKey = deriveKey(inputPassword, referenceKey.length);
        if (inputKey == null || inputKey.length != referenceKey.length) {
            return false;
        }
        for (int i = 0; i < inputKey.length; i++) {
            if (inputKey[i] != referenceKey[i]) {
                return false;
            }
        }
        return true;
    }

    /* access modifiers changed from: protected */
    public void assertPRF(byte[] bArr) {
        PRF prf2;
        byte[] P = bArr;
        if (this.prf == null) {
            new MacBasedPRF(this.parameters.getHashAlgorithm());
            this.prf = prf2;
        }
        this.prf.init(P);
    }

    public PRF getPseudoRandomFunction() {
        return this.prf;
    }

    /* access modifiers changed from: protected */
    public byte[] PBKDF2(PRF prf2, byte[] bArr, int i, int i2) {
        PRF prf3 = prf2;
        byte[] S = bArr;
        int c = i;
        int dkLen = i2;
        if (S == null) {
            S = new byte[0];
        }
        int hLen = prf3.getHLen();
        int l = ceil(dkLen, hLen);
        int r = dkLen - ((l - 1) * hLen);
        byte[] T = new byte[(l * hLen)];
        int ti_offset = 0;
        for (int i3 = 1; i3 <= l; i3++) {
            _F(T, ti_offset, prf3, S, c, i3);
            ti_offset += hLen;
        }
        if (r >= hLen) {
            return T;
        }
        byte[] DK = new byte[dkLen];
        System.arraycopy(T, 0, DK, 0, dkLen);
        return DK;
    }

    /* access modifiers changed from: protected */
    public int ceil(int i, int i2) {
        int a = i;
        int b = i2;
        int m = 0;
        if (a % b > 0) {
            m = 1;
        }
        return (a / b) + m;
    }

    /* access modifiers changed from: protected */
    public void _F(byte[] bArr, int i, PRF prf2, byte[] bArr2, int i2, int blockIndex) {
        byte[] dest = bArr;
        int offset = i;
        PRF prf3 = prf2;
        byte[] S = bArr2;
        int c = i2;
        int hLen = prf3.getHLen();
        byte[] U_r = new byte[hLen];
        byte[] U_i = new byte[(S.length + 4)];
        System.arraycopy(S, 0, U_i, 0, S.length);
        INT(U_i, S.length, blockIndex);
        for (int i3 = 0; i3 < c; i3++) {
            U_i = prf3.doFinal(U_i);
            xor(U_r, U_i);
        }
        System.arraycopy(U_r, 0, dest, offset, hLen);
    }

    /* access modifiers changed from: protected */
    public void xor(byte[] bArr, byte[] bArr2) {
        byte[] dest = bArr;
        byte[] src = bArr2;
        for (int i = 0; i < dest.length; i++) {
            byte[] bArr3 = dest;
            int i2 = i;
            bArr3[i2] = (byte) (bArr3[i2] ^ src[i]);
        }
    }

    /* access modifiers changed from: protected */
    public void INT(byte[] bArr, int i, int i2) {
        byte[] dest = bArr;
        int offset = i;
        int i3 = i2;
        dest[offset + 0] = (byte) (i3 / 16777216);
        dest[offset + 1] = (byte) (i3 / InternalZipConstants.MIN_SPLIT_LENGTH);
        dest[offset + 2] = (byte) (i3 / 256);
        dest[offset + 3] = (byte) i3;
    }

    public PBKDF2Parameters getParameters() {
        return this.parameters;
    }

    public void setParameters(PBKDF2Parameters parameters2) {
        PBKDF2Parameters pBKDF2Parameters = parameters2;
        this.parameters = pBKDF2Parameters;
    }

    public void setPseudoRandomFunction(PRF prf2) {
        PRF prf3 = prf2;
        this.prf = prf3;
    }
}
