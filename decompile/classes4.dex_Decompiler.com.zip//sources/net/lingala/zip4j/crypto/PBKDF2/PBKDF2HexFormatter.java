package net.lingala.zip4j.crypto.PBKDF2;

import com.microsoft.appcenter.Constants;

class PBKDF2HexFormatter {
    PBKDF2HexFormatter() {
    }

    public boolean fromString(PBKDF2Parameters pBKDF2Parameters, String str) {
        PBKDF2Parameters p = pBKDF2Parameters;
        String s = str;
        if (p == null || s == null) {
            return true;
        }
        String[] p123 = s.split(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR);
        if (p123 == null || p123.length != 3) {
            return true;
        }
        byte[] salt = BinTools.hex2bin(p123[0]);
        int iterationCount = Integer.parseInt(p123[1]);
        byte[] bDK = BinTools.hex2bin(p123[2]);
        p.setSalt(salt);
        p.setIterationCount(iterationCount);
        p.setDerivedKey(bDK);
        return false;
    }

    public String toString(PBKDF2Parameters pBKDF2Parameters) {
        StringBuffer stringBuffer;
        PBKDF2Parameters p = pBKDF2Parameters;
        new StringBuffer(String.valueOf(BinTools.bin2hex(p.getSalt())));
        return stringBuffer.append(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR).append(String.valueOf(p.getIterationCount())).append(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR).append(BinTools.bin2hex(p.getDerivedKey())).toString();
    }
}
