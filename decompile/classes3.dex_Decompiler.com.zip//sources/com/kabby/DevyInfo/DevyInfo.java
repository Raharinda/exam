package com.kabby.DevyInfo;

import android.app.Activity;
import android.content.Context;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.util.YailList;
import com.oseamiya.deviceinformation.AppsInformation;
import com.oseamiya.deviceinformation.BatteryInformation;
import com.oseamiya.deviceinformation.CameraInformation;
import com.oseamiya.deviceinformation.CpuInformation;
import com.oseamiya.deviceinformation.DeviceInformation;
import com.oseamiya.deviceinformation.DisplayInformation;
import com.oseamiya.deviceinformation.LocationInformation;
import com.oseamiya.deviceinformation.MemoryInformation;
import com.oseamiya.deviceinformation.NetworkInformation;
import com.oseamiya.deviceinformation.SensorInformation;
import com.oseamiya.deviceinformation.SystemInformation;

@DesignerComponent(category = ComponentCategory.EXTENSION, description = "", iconName = "", nonVisible = true, version = 1)
@UsesLibraries(libraries = "devyinfo.jar")
@SimpleObject(external = true)
@UsesPermissions(permissionNames = "android.permission.INTERNET, android.permission.ACCESS_NETWORK_STATE, android.permission.ACCESS_NETWORK_STATE, android.permission.ACCESS_NETWORK_STATE, android.permission.ACCESS_FINE_LOCATION, android.permission.ACCESS_COARSE_LOCATION")
public class DevyInfo extends AndroidNonvisibleComponent {
    private Activity activity;
    private AppsInformation appsInformation;
    private BatteryInformation batteryInformation;
    private CameraInformation cameraInformation;
    private Context context;
    private CpuInformation cpuInformation;
    private DeviceInformation deviceInformation;
    private DisplayInformation displayInformation;
    private float kiddo;
    private LocationInformation locationInformation;
    private MemoryInformation memoryInformation;
    private NetworkInformation networkInformation;
    private SensorInformation sensorInformation;
    private SystemInformation systemInformation;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public DevyInfo(com.google.appinventor.components.runtime.ComponentContainer r8) {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.activity = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.context = r3
            r2 = r0
            com.oseamiya.deviceinformation.DeviceInformation r3 = new com.oseamiya.deviceinformation.DeviceInformation
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r0
            android.content.Context r5 = r5.context
            r4.<init>(r5)
            r2.deviceInformation = r3
            r2 = r0
            com.oseamiya.deviceinformation.DisplayInformation r3 = new com.oseamiya.deviceinformation.DisplayInformation
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r0
            android.content.Context r5 = r5.context
            r4.<init>(r5)
            r2.displayInformation = r3
            r2 = r0
            com.oseamiya.deviceinformation.AppsInformation r3 = new com.oseamiya.deviceinformation.AppsInformation
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r0
            android.content.Context r5 = r5.context
            r4.<init>(r5)
            r2.appsInformation = r3
            r2 = r0
            com.oseamiya.deviceinformation.BatteryInformation r3 = new com.oseamiya.deviceinformation.BatteryInformation
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r0
            android.content.Context r5 = r5.context
            r4.<init>(r5)
            r2.batteryInformation = r3
            r2 = r0
            com.oseamiya.deviceinformation.CameraInformation r3 = new com.oseamiya.deviceinformation.CameraInformation
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r0
            android.content.Context r5 = r5.context
            r4.<init>(r5)
            r2.cameraInformation = r3
            r2 = r0
            com.oseamiya.deviceinformation.CpuInformation r3 = new com.oseamiya.deviceinformation.CpuInformation
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r0
            android.content.Context r5 = r5.context
            r4.<init>(r5)
            r2.cpuInformation = r3
            r2 = r0
            com.oseamiya.deviceinformation.LocationInformation r3 = new com.oseamiya.deviceinformation.LocationInformation
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r0
            android.content.Context r5 = r5.context
            r4.<init>(r5)
            r2.locationInformation = r3
            r2 = r0
            com.oseamiya.deviceinformation.MemoryInformation r3 = new com.oseamiya.deviceinformation.MemoryInformation
            r6 = r3
            r3 = r6
            r4 = r6
            r4.<init>()
            r2.memoryInformation = r3
            r2 = r0
            com.oseamiya.deviceinformation.SensorInformation r3 = new com.oseamiya.deviceinformation.SensorInformation
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r0
            android.content.Context r5 = r5.context
            r4.<init>(r5)
            r2.sensorInformation = r3
            r2 = r0
            com.oseamiya.deviceinformation.SystemInformation r3 = new com.oseamiya.deviceinformation.SystemInformation
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r0
            android.content.Context r5 = r5.context
            r4.<init>(r5)
            r2.systemInformation = r3
            r2 = r0
            com.oseamiya.deviceinformation.NetworkInformation r3 = new com.oseamiya.deviceinformation.NetworkInformation
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r0
            android.content.Context r5 = r5.context
            r4.<init>(r5)
            r2.networkInformation = r3
            r2 = r0
            com.oseamiya.deviceinformation.MemoryInformation r2 = r2.memoryInformation
            r3 = r0
            android.content.Context r3 = r3.context
            r2.MemoryInformation(r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.kabby.DevyInfo.DevyInfo.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    @SimpleFunction
    public YailList GetAllAppsPackageName() {
        return YailList.makeList(this.appsInformation.getAllAppsPackageName());
    }

    @SimpleFunction
    public int GetApiLevel() {
        return this.systemInformation.getApiLevel();
    }

    @SimpleFunction
    public String GetApplicationName(String str) {
        return this.appsInformation.getApplicationName(str);
    }

    @SimpleFunction
    public long GetAvailableExternalStorageSize() {
        return this.memoryInformation.getAvailableExternalStorageSize();
    }

    @SimpleFunction
    public long GetAvailableInternalMemorySize() {
        return this.memoryInformation.getAvailableInternalMemorySize();
    }

    @SimpleFunction
    public long GetAvailableRam() {
        return this.memoryInformation.getAvailableRam();
    }

    @SimpleFunction
    public double GetBatteryCapacity() {
        return this.batteryInformation.getBatteryCapacity();
    }

    @SimpleFunction
    public int GetBatteryPercentage() {
        return this.batteryInformation.getPercentage();
    }

    @SimpleFunction
    public float GetBatteryTemperature() {
        return this.batteryInformation.getBatteryTemperature();
    }

    @SimpleFunction
    public int GetBatteryVoltage() {
        return this.batteryInformation.getBatteryVoltage();
    }

    @SimpleFunction
    public String GetBoardName() {
        return this.deviceInformation.getBoardName();
    }

    @SimpleFunction
    public float GetBogoMips() {
        try {
            CpuInformation cpuInformation2 = this.cpuInformation;
            this.kiddo = CpuInformation.getBogoMips();
        } catch (Exception e) {
            Exception exc = e;
        }
        return this.kiddo;
    }

    @SimpleFunction
    public String GetBootloader() {
        return this.systemInformation.getBootloader();
    }

    @SimpleFunction
    public String GetBrandName() {
        return this.deviceInformation.getBrandName();
    }

    @SimpleFunction
    public int GetBrightnessLevel() {
        return this.displayInformation.getBrightnessLevel();
    }

    @SimpleFunction
    public String GetBuildFingerPrint() {
        return this.deviceInformation.getBuildFingerPrint();
    }

    @SimpleFunction
    public long GetBuildTime() {
        return this.deviceInformation.getBuildTime();
    }

    @SimpleFunction
    public String GetBuildUser() {
        return this.deviceInformation.getBuildUser();
    }

    @SimpleFunction
    public YailList GetCameraIds() {
        return YailList.makeList(this.cameraInformation.getCameraIds());
    }

    @SimpleFunction
    public String GetChargingSource() {
        return this.batteryInformation.getChargingSource();
    }

    @SimpleFunction
    public String GetCity(double d, double d2) {
        return this.locationInformation.getCity(d, d2);
    }

    @SimpleFunction
    public int GetClockSpeed() {
        CpuInformation cpuInformation2 = this.cpuInformation;
        return CpuInformation.getClockSpeed();
    }

    @SimpleFunction
    public String GetCountry() {
        return this.systemInformation.getCountry();
    }

    @SimpleFunction
    public String GetCountryDisplayName() {
        return this.systemInformation.getDisplayName();
    }

    @SimpleFunction
    public String GetCountryName(double d, double d2) {
        return this.locationInformation.getCountryName(d, d2);
    }

    @SimpleFunction
    public double GetCurrentLatitude() {
        return this.locationInformation.getCurrentLatitude();
    }

    @SimpleFunction
    public double GetCurrentLongitude() {
        return this.locationInformation.getCurrentLongitude();
    }

    @SimpleFunction
    public String GetDeviceId() {
        return this.deviceInformation.getDeviceId();
    }

    @SimpleFunction
    public String GetDeviceName() {
        return this.deviceInformation.getDeviceName();
    }

    @SimpleFunction
    public String GetDeviceType() {
        return this.deviceInformation.getDeviceType();
    }

    @SimpleFunction
    public String GetDisplayCountry() {
        return this.systemInformation.getDisplayCountry();
    }

    @SimpleFunction
    public int GetDisplayHeight() {
        return this.displayInformation.getDisplayHeight();
    }

    @SimpleFunction
    public String GetDisplayLanguage() {
        return this.systemInformation.getDisplayLanguage();
    }

    @SimpleFunction
    public String GetDisplayVersion() {
        return this.deviceInformation.getDisplayVersion();
    }

    @SimpleFunction
    public int GetDisplayWidth() {
        return this.displayInformation.getDisplayWidth();
    }

    @SimpleFunction
    public float GetFontScale() {
        return this.displayInformation.getFontScale();
    }

    @SimpleFunction
    public String GetGPUExtension() {
        return this.cpuInformation.getGPUVersion();
    }

    @SimpleFunction
    public String GetGPURenderer() {
        return this.cpuInformation.getGPURenderer();
    }

    @SimpleFunction
    public String GetGPUVendor() {
        return this.cpuInformation.getGPUVendor();
    }

    @SimpleFunction
    public String GetGPUVersion() {
        return this.cpuInformation.getGPUVersion();
    }

    @SimpleFunction
    public String GetHardwareName() {
        return this.deviceInformation.getHardwareName();
    }

    @SimpleFunction
    public int GetHealth() {
        return this.batteryInformation.getHealth();
    }

    @SimpleFunction
    public String GetHost() {
        return this.deviceInformation.getHost();
    }

    @SimpleFunction
    public long GetInstalledTime(String str) {
        return this.appsInformation.getInstalledTime(str);
    }

    @SimpleFunction
    public String GetIpAddress(boolean z) {
        return this.networkInformation.getIpAddress(z);
    }

    @SimpleFunction
    public String GetIso3Country() {
        return this.systemInformation.getIso3Country();
    }

    @SimpleFunction
    public String GetIso3Language() {
        return this.systemInformation.getIso3Language();
    }

    @SimpleFunction
    public String GetKernalVersion() {
        return this.systemInformation.getKernalVersion();
    }

    @SimpleFunction
    public String GetLanguage() {
        return this.systemInformation.getLanguage();
    }

    @SimpleFunction
    public String GetLanguageTag() {
        return this.systemInformation.getLanguageTag();
    }

    @SimpleFunction
    public long GetLastUpdatedTime(String str) {
        return this.appsInformation.getLastUpdatedTime(str);
    }

    @SimpleFunction
    public String GetManafacturerName() {
        return this.deviceInformation.getManafacturerName();
    }

    @SimpleFunction
    public int GetMaxScalingFrequency() {
        CpuInformation cpuInformation2 = this.cpuInformation;
        return CpuInformation.getMaxScalingFrequency();
    }

    @SimpleFunction
    public int GetMaximumAutoExposureRegions(String str) {
        return this.cameraInformation.getMaximumAutoExposureRegions(str);
    }

    @SimpleFunction
    public int GetMaximumAutoFocusRegions(String str) {
        return this.cameraInformation.getMaximumAutoFocusRegions(str);
    }

    @SimpleFunction
    public int GetMaximumAutoWhiteBalancingRegions(String str) {
        return this.cameraInformation.getMaximumAutoWhiteBalanceRegions(str);
    }

    @SimpleFunction
    public int GetMaximumFrequency() {
        CpuInformation cpuInformation2 = this.cpuInformation;
        return CpuInformation.getMaximumFrequency();
    }

    @SimpleFunction
    public int GetMinScalingFrequency() {
        CpuInformation cpuInformation2 = this.cpuInformation;
        return CpuInformation.getMinScalingFrequency();
    }

    @SimpleFunction
    public int GetMinimumFrequency() {
        CpuInformation cpuInformation2 = this.cpuInformation;
        return CpuInformation.getMinimumFrequency();
    }

    @SimpleFunction
    public String GetModelName() {
        return this.deviceInformation.getModelName();
    }

    @SimpleFunction
    public int GetNavigationBarHeight() {
        return this.displayInformation.getNavigationBarHeight();
    }

    @SimpleFunction
    public int GetNumberOfCameras() {
        return this.cameraInformation.getNumberOfCameras();
    }

    @SimpleFunction
    public int GetNumberOfCores() {
        return this.cpuInformation.getNumberOfCores();
    }

    @SimpleFunction
    public int GetNumberOfSimSlot() {
        return this.deviceInformation.getNumberOfSimSlot();
    }

    @SimpleFunction
    public int GetOrientation() {
        return this.displayInformation.getOrientation();
    }

    @SimpleFunction
    public double GetPhysicalSize() {
        return this.displayInformation.getPhysicalSize();
    }

    @SimpleFunction
    public String GetPostalCode(double d, double d2) {
        return this.locationInformation.getPostalCode(d, d2);
    }

    @SimpleFunction
    public String GetProductName() {
        return this.deviceInformation.getProductName();
    }

    @SimpleFunction
    public String GetRadioVersion() {
        return this.deviceInformation.getRadioVersion();
    }

    @SimpleFunction
    public float GetRefreshRate() {
        return this.displayInformation.getRefreshRate();
    }

    @SimpleFunction
    public YailList GetRequestedPermissions(String str) {
        return YailList.makeList(this.appsInformation.getRequestedPermissions(str));
    }

    @SimpleFunction
    public int GetRotation() {
        return this.displayInformation.getRotation();
    }

    @SimpleFunction
    public int GetScreenTimeout() {
        return this.displayInformation.getScreenTimeout();
    }

    @SimpleFunction
    public String GetSecurityPatchDate() {
        return this.systemInformation.getSecurityPathDate();
    }

    @SimpleFunction
    public YailList GetSensorList() {
        return YailList.makeList(this.sensorInformation.getSensorList());
    }

    @SimpleFunction
    public String GetSerial() {
        return this.deviceInformation.getSerial();
    }

    @SimpleFunction
    public YailList GetServers() {
        return YailList.makeList(this.networkInformation.getServers());
    }

    @SimpleFunction
    public String GetStreetAddress(double d, double d2) {
        return this.locationInformation.getStreetAddress(d, d2);
    }

    @SimpleFunction
    public YailList GetSupportedABIs() {
        CpuInformation cpuInformation2 = this.cpuInformation;
        return YailList.makeList(CpuInformation.getSupportedABIs());
    }

    @SimpleFunction
    public String GetTechnology() {
        return this.batteryInformation.getTechnology();
    }

    @SimpleFunction
    public long GetTotalExternalStorageSize() {
        return this.memoryInformation.getTotalExternalStorageSize();
    }

    @SimpleFunction
    public long GetTotalInternalMemorySize() {
        return this.memoryInformation.getTotalInternalMemorySize();
    }

    @SimpleFunction
    public int GetTotalNumberOfSensors() {
        return this.sensorInformation.getTotalNumberOfSensors();
    }

    @SimpleFunction
    public long GetTotalRam() {
        return this.memoryInformation.getTotalRam();
    }

    @SimpleFunction
    public long GetUsedExternalStorageSize() {
        return this.memoryInformation.getUsedExternalStorageSize();
    }

    @SimpleFunction
    public long GetUsedInternalMemorySize() {
        return this.memoryInformation.getUsedInternalMemorySize();
    }

    @SimpleFunction
    public long GetUsedRam() {
        return this.memoryInformation.getUsedRam();
    }

    @SimpleFunction
    public int GetVersionCode(String str) {
        return this.appsInformation.getVersionCode(str);
    }

    @SimpleFunction
    public String GetVersionCode() {
        return this.deviceInformation.getCodeName();
    }

    @SimpleFunction
    public String GetVersionName() {
        return this.systemInformation.getVersionName();
    }

    @SimpleFunction
    public String GetVersionName(String str) {
        return this.appsInformation.getVersionName(str);
    }

    @SimpleFunction
    public boolean Is64Bit() {
        CpuInformation cpuInformation2 = this.cpuInformation;
        return CpuInformation.is64Bit();
    }

    @SimpleFunction
    public boolean IsBatteryAvailable() {
        return this.batteryInformation.isBatteryAvailable();
    }

    @SimpleFunction
    public boolean IsBrightnessAutoMode() {
        return this.displayInformation.isBrightnessAutoMode();
    }

    @SimpleFunction
    public boolean IsCameraAvailable() {
        return this.cameraInformation.isCameraAvailable();
    }

    @SimpleFunction
    public boolean IsCharging() {
        return this.batteryInformation.isCharging();
    }

    @SimpleFunction
    public boolean IsExternalMemoryAvailable() {
        return this.memoryInformation.isExternalMemoryAvailable();
    }

    @SimpleFunction
    public boolean IsFlashAvailable() {
        return this.cameraInformation.isFlashAvailable();
    }

    @SimpleFunction
    public boolean IsGPUSupported() {
        return this.cpuInformation.isGPUSupported();
    }

    @SimpleFunction
    public boolean IsHdrCapable() {
        return this.displayInformation.isHdrCapable();
    }

    @SimpleFunction
    public boolean IsInMultiWindowMode() {
        return this.activity.isInMultiWindowMode();
    }

    @SimpleFunction
    public boolean IsNightModeActive() {
        return this.displayInformation.isNightModeActive();
    }

    @SimpleFunction
    public boolean IsRooted() {
        return this.deviceInformation.isRooted();
    }

    @SimpleFunction
    public boolean IsScreenCurved() {
        return this.displayInformation.isScreenRound();
    }

    @SimpleFunction
    public boolean IsScreenWideColorGamut() {
        return this.displayInformation.isScreenWideColorGamut();
    }

    @SimpleFunction
    public boolean IsUsbHostSupported() {
        return this.deviceInformation.isUsbHostSupported();
    }

    @SimpleFunction
    public void TriggerBrightnessMode() {
        this.displayInformation.triggerBrightnessMode();
    }
}
