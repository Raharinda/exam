package com.sonu.AppSettings;

import android.content.Intent;
import android.net.Uri;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.ComponentContainer;

@SimpleObject(external = true)
@DesignerComponent(category = ComponentCategory.EXTENSION, description = "", iconName = "http://appyBuilder.com/extensions/icons/extension.png", nonVisible = true, version = 1)
public class AppSettings extends AndroidNonvisibleComponent {
    private ComponentContainer container;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public AppSettings(com.google.appinventor.components.runtime.ComponentContainer r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            r3 = r1
            r2.container = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sonu.AppSettings.AppSettings.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    @SimpleFunction(description = "")
    public void Open(String str) {
        Intent intent;
        StringBuilder sb;
        new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        Intent intent2 = intent;
        new StringBuilder();
        Intent data = intent2.setData(Uri.parse(sb.append("package:").append(str).toString()));
        this.container.$context().startActivity(intent2);
    }
}
