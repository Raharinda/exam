package com.dreamers.AlphaDialog;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Toast;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.EventDispatcher;

@SimpleObject(external = true)
@DesignerComponent(category = ComponentCategory.EXTENSION, iconName = "https://res.cloudinary.com/dzqb4drjv/image/upload/v1608883763/circular-speech-bubble_c0z91r.png", nonVisible = true, version = 1)
public class AlphaDialog extends AndroidNonvisibleComponent {
    private Context context;
    private Dialog dialog = null;
    private WindowManager.LayoutParams params;
    private Toast toast;
    private View toastView = null;
    private boolean wrap = true;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public AlphaDialog(com.google.appinventor.components.runtime.ComponentContainer r7) {
        /*
            r6 = this;
            r0 = r6
            r1 = r7
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            r3 = 0
            r2.dialog = r3
            r2 = r0
            r3 = 1
            r2.wrap = r3
            r2 = r0
            r3 = 0
            r2.toastView = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.context = r3
            r2 = r0
            android.view.WindowManager$LayoutParams r3 = new android.view.WindowManager$LayoutParams
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r2.params = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.dreamers.AlphaDialog.AlphaDialog.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    @SimpleFunction
    public void CreateDialog(AndroidViewComponent androidViewComponent, boolean z) {
        Dialog dialog2;
        DialogInterface.OnDismissListener onDismissListener;
        DialogInterface.OnShowListener onShowListener;
        boolean z2 = z;
        View view = androidViewComponent.getView();
        view.setVisibility(0);
        if (view.getParent() != null) {
            ((ViewGroup) view.getParent()).removeView(view);
        }
        new Dialog(this.context);
        this.dialog = dialog2;
        this.dialog.setCancelable(z2);
        boolean requestWindowFeature = this.dialog.requestWindowFeature(1);
        this.dialog.setContentView(view);
        new DialogInterface.OnDismissListener(this) {
            final /* synthetic */ AlphaDialog this$0;

            {
                this.this$0 = r5;
            }

            public void onDismiss(DialogInterface dialogInterface) {
                DialogInterface dialogInterface2 = dialogInterface;
                this.this$0.OnDismiss();
            }
        };
        this.dialog.setOnDismissListener(onDismissListener);
        new DialogInterface.OnShowListener(this) {
            final /* synthetic */ AlphaDialog this$0;

            {
                this.this$0 = r5;
            }

            public void onShow(DialogInterface dialogInterface) {
                DialogInterface dialogInterface2 = dialogInterface;
                this.this$0.OnShow();
            }
        };
        this.dialog.setOnShowListener(onShowListener);
    }

    @SimpleFunction
    public void Dismiss() {
        if (this.dialog != null) {
            this.dialog.dismiss();
        }
    }

    @SimpleProperty
    public int LongLength() {
        return 1;
    }

    @SimpleEvent
    public void OnDismiss() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnDismiss", new Object[0]);
    }

    @SimpleEvent
    public void OnShow() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnShow", new Object[0]);
    }

    @SimpleProperty
    public int ShortLength() {
        return 0;
    }

    @SimpleFunction
    public void Show() {
        if (this.dialog != null) {
            int copyFrom = this.params.copyFrom(this.dialog.getWindow().getAttributes());
            this.dialog.show();
            this.dialog.getWindow().setBackgroundDrawableResource(17170445);
            if (this.wrap) {
                this.params.width = -2;
                this.params.height = -2;
            } else {
                this.params.width = -1;
                this.params.height = -1;
            }
            this.dialog.getWindow().setAttributes(this.params);
        }
    }

    @SimpleFunction
    public void ShowToast(AndroidViewComponent androidViewComponent, int i) {
        StringBuilder sb;
        Toast toast2;
        AndroidViewComponent androidViewComponent2 = androidViewComponent;
        int i2 = i;
        try {
            if (this.toastView == null || this.toastView != androidViewComponent2.getView()) {
                this.toastView = androidViewComponent2.getView();
                if (this.toastView.getParent() != null) {
                    ((ViewGroup) this.toastView.getParent()).removeView(this.toastView);
                }
            }
            this.toastView.setVisibility(0);
            new Toast(this.context);
            this.toast = toast2;
            this.toast.setView(this.toastView);
            this.toast.setDuration(i2);
            this.toast.show();
        } catch (Exception e) {
            Exception exc = e;
            Context context2 = this.context;
            new StringBuilder();
            Toast.makeText(context2, sb.append("").append(exc).toString(), 1).show();
        }
    }

    @SimpleProperty
    public void WrapContent(boolean z) {
        boolean z2 = z;
        this.wrap = z2;
    }

    @SimpleProperty
    public boolean WrapContent() {
        return this.wrap;
    }
}
