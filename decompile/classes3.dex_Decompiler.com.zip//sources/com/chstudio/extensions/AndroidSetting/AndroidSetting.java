package com.chstudio.extensions.AndroidSetting;

import android.content.Context;
import android.content.Intent;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;

@SimpleObject(external = true)
@DesignerComponent(category = ComponentCategory.EXTENSION, description = "By Anas Chawdhary", iconName = "https://icons.iconarchive.com/icons/fasticon/hand-draw-iphone/128/Settings-icon.png", nonVisible = true, version = 1)
public class AndroidSetting extends AndroidNonvisibleComponent implements Component {
    private static final String LOG_TAG = "AndroidSetting";
    public static final int VERSION = 1;
    private ComponentContainer container;
    private Context context;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public AndroidSetting(com.google.appinventor.components.runtime.ComponentContainer r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            r3 = r1
            r2.container = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.context = r3
            java.lang.String r2 = "AndroidSetting"
            java.lang.String r3 = "AndroidSetting Created"
            int r2 = android.util.Log.d(r2, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.chstudio.extensions.AndroidSetting.AndroidSetting.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    @SimpleFunction(description = "Method to open Accessibility setting")
    public void Accessibility_setting() {
        Intent intent;
        new Intent("android.settings.ACCESSIBILITY_SETTINGS");
        Intent intent2 = intent;
        this.context.startActivity(intent2);
    }

    @SimpleFunction(description = "Method to open Airplane mode setting")
    public void Airplane_mode_setting() {
        Intent intent;
        new Intent("android.settings.AIRPLANE_MODE_SETTINGS");
        Intent intent2 = intent;
        this.context.startActivity(intent2);
    }

    @SimpleFunction(description = "Method to open Application Manager setting")
    public void Applications_manager_setting() {
        Intent intent;
        new Intent("android.settings.MANAGE_APPLICATIONS_SETTINGS");
        Intent intent2 = intent;
        this.context.startActivity(intent2);
    }

    @SimpleFunction(description = "Method to open ur cast screen setting(Wireless Setting)")
    public void Cast_setting() {
        Intent intent;
        new Intent("android.settings.CAST_SETTINGS");
        Intent intent2 = intent;
        this.context.startActivity(intent2);
    }

    @SimpleFunction(description = "Method to open Date setting setting")
    public void Date_setting() {
        Intent intent;
        new Intent("android.settings.DATE_SETTINGS");
        Intent intent2 = intent;
        this.context.startActivity(intent2);
    }

    @SimpleFunction(description = "Method to open Devive info setting")
    public void Device_info_setting() {
        Intent intent;
        new Intent("android.settings.DEVICE_INFO_SETTINGS");
        Intent intent2 = intent;
        this.context.startActivity(intent2);
    }

    @SimpleFunction(description = "Method to open Display setting")
    public void Display_setting() {
        Intent intent;
        new Intent("android.settings.DISPLAY_SETTINGS");
        Intent intent2 = intent;
        this.context.startActivity(intent2);
    }

    @SimpleFunction(description = "Method to Minimize ur app")
    public void Minimize_App() {
        Intent intent;
        new Intent("android.intent.action.MAIN");
        Intent intent2 = intent;
        Intent flags = intent2.setFlags(67108864);
        Intent addCategory = intent2.addCategory("android.intent.category.HOME");
        this.context.startActivity(intent2);
    }

    @SimpleFunction(description = "Method to open NFC setting")
    public void NFC_setting() {
        Intent intent;
        new Intent("android.settings.NFC_SETTINGS");
        Intent intent2 = intent;
        this.context.startActivity(intent2);
    }

    @SimpleFunction(description = "Method to open security setting")
    public void Security_setting() {
        Intent intent;
        new Intent("android.settings.SECURITY_SETTINGS");
        Intent intent2 = intent;
        this.context.startActivity(intent2);
    }

    @SimpleFunction(description = "Method to open Usage access setting")
    public void Usage_Access_setting() {
        Intent intent;
        new Intent("android.settings.USAGE_ACCESS_SETTINGS");
        Intent intent2 = intent;
        this.context.startActivity(intent2);
    }

    @SimpleFunction(description = "Method to open VPN setting")
    public void VPN_setting() {
        Intent intent;
        new Intent("android.settings.VPN_SETTINGS");
        Intent intent2 = intent;
        this.context.startActivity(intent2);
    }

    @SimpleFunction(description = "Method to open wifi setting")
    public void Wifi_setting() {
        Intent intent;
        new Intent("android.settings.WIFI_SETTINGS");
        Intent intent2 = intent;
        this.context.startActivity(intent2);
    }

    @SimpleFunction(description = "Method to open Sound setting")
    public void sound_setting() {
        Intent intent;
        new Intent("android.settings.SOUND_SETTINGS");
        Intent intent2 = intent;
        this.context.startActivity(intent2);
    }
}
