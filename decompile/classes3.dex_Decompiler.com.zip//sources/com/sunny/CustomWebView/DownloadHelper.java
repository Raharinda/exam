package com.sunny.CustomWebView;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.OnDestroyListener;
import java.util.Timer;
import java.util.TimerTask;

@SimpleObject(external = true)
@DesignerComponent(androidMinSdk = 21, category = ComponentCategory.EXTENSION, description = "Helper class of CustomWebView extension for downloading files <br> Developed by Sunny Gupta", helpUrl = "https://github.com/vknow360/CustomWebView", iconName = "https://res.cloudinary.com/andromedaviewflyvipul/image/upload/c_scale,h_20,w_20/v1571472765/ktvu4bapylsvnykoyhdm.png", nonVisible = true, version = 1, versionName = "1.1")
public class DownloadHelper extends AndroidNonvisibleComponent implements OnDestroyListener {
    public BroadcastReceiver completed;
    public Context context;
    public DownloadManager downloadManager = ((DownloadManager) this.context.getSystemService("download"));
    public long lastRequestId;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public DownloadHelper(com.google.appinventor.components.runtime.ComponentContainer r9) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            com.sunny.CustomWebView.DownloadHelper$1 r3 = new com.sunny.CustomWebView.DownloadHelper$1
            r7 = r3
            r3 = r7
            r4 = r7
            r5 = r0
            r4.<init>(r5)
            r2.completed = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.context = r3
            r2 = r0
            r3 = r0
            android.content.Context r3 = r3.context
            java.lang.String r4 = "download"
            java.lang.Object r3 = r3.getSystemService(r4)
            android.app.DownloadManager r3 = (android.app.DownloadManager) r3
            r2.downloadManager = r3
            r2 = r0
            android.content.Context r2 = r2.context
            r3 = r0
            android.content.BroadcastReceiver r3 = r3.completed
            android.content.IntentFilter r4 = new android.content.IntentFilter
            r7 = r4
            r4 = r7
            r5 = r7
            java.lang.String r6 = "android.intent.action.DOWNLOAD_COMPLETE"
            r5.<init>(r6)
            android.content.Intent r2 = r2.registerReceiver(r3, r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sunny.CustomWebView.DownloadHelper.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    @SimpleFunction(description = "Cancels the current download request")
    public void Cancel() {
        int remove = this.downloadManager.remove(new long[]{this.lastRequestId});
    }

    @SimpleFunction(description = "Downloads the given file")
    public void Download(String str, String str2, String str3, String str4, String str5) {
        DownloadManager.Request request;
        Timer timer;
        TimerTask timerTask;
        String str6 = str;
        String str7 = str2;
        String str8 = str3;
        String str9 = str4;
        String str10 = str5;
        String str11 = str9;
        String str12 = str10;
        new DownloadManager.Request(Uri.parse(str6));
        DownloadManager.Request request2 = request;
        DownloadManager.Request mimeType = request2.setMimeType(str7);
        DownloadManager.Request addRequestHeader = request2.addRequestHeader("cookie", CookieManager.getInstance().getCookie(str6));
        DownloadManager.Request description = request2.setDescription("Downloading file...");
        DownloadManager.Request title = request2.setTitle(str9);
        DownloadManager.Request notificationVisibility = request2.setNotificationVisibility(1);
        if (str10.isEmpty()) {
            str12 = Environment.DIRECTORY_DOWNLOADS;
        }
        if (str9.isEmpty()) {
            str11 = URLUtil.guessFileName(str6, str8, str7);
            DownloadManager.Request title2 = request2.setTitle(str11);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            DownloadManager.Request destinationInExternalFilesDir = request2.setDestinationInExternalFilesDir(this.context, str12, str11);
        } else {
            DownloadManager.Request destinationInExternalPublicDir = request2.setDestinationInExternalPublicDir(str12, str11);
        }
        this.lastRequestId = this.downloadManager.enqueue(request2);
        new Timer();
        Timer timer2 = timer;
        final Timer timer3 = timer2;
        new TimerTask(this) {
            final /* synthetic */ DownloadHelper this$0;

            {
                this.this$0 = r6;
            }

            public void run() {
                DownloadManager.Query query;
                Runnable runnable;
                new DownloadManager.Query();
                DownloadManager.Query query2 = query;
                DownloadManager.Query filterById = query2.setFilterById(new long[]{this.this$0.lastRequestId});
                Cursor query3 = this.this$0.downloadManager.query(query2);
                if (query3.moveToFirst()) {
                    int i = query3.getInt(query3.getColumnIndex("bytes_so_far"));
                    int i2 = query3.getInt(query3.getColumnIndex("total_size"));
                    query3.close();
                    final int i3 = (i * 100) / i2;
                    new Runnable(this) {
                        final /* synthetic */ AnonymousClass2 this$1;

                        {
                            this.this$1 = r6;
                        }

                        public void run() {
                            if (i3 >= 99) {
                                timer3.cancel();
                                int purge = timer3.purge();
                            }
                            this.this$1.this$0.DownloadProgressChanged(i3);
                        }
                    };
                    this.this$0.form.runOnUiThread(runnable);
                }
            }
        };
        timer2.schedule(timerTask, 0, 1000);
    }

    @SimpleEvent(description = "Event invoked when downloading gets completed")
    public void DownloadCompleted() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "DownloadCompleted", new Object[0]);
    }

    @SimpleEvent(description = "Event invoked when downloading progress changes")
    public void DownloadProgressChanged(int i) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "DownloadProgressChanged", new Object[]{Integer.valueOf(i)});
    }

    @SimpleFunction(description = "Tries to open the last downloaded file")
    public void OpenFile() {
        try {
            ParcelFileDescriptor openDownloadedFile = this.downloadManager.openDownloadedFile(this.lastRequestId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onDestroy() {
        this.context.unregisterReceiver(this.completed);
    }
}
