package com.sunny.CustomWebView;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.net.http.SslCertificate;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Message;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintJob;
import android.print.PrintManager;
import android.util.Base64;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.HttpAuthHandler;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebBackForwardList;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import com.chstudio.extensions.AndroidSetting.AndroidSetting;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.HVArrangement;
import com.google.appinventor.components.runtime.util.JsonUtil;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@DesignerComponent(androidMinSdk = 21, category = ComponentCategory.EXTENSION, description = "An extended form of Web Viewer <br> Developed by Sunny Gupta", helpUrl = "https://github.com/vknow360/CustomWebView", iconName = "https://res.cloudinary.com/andromedaviewflyvipul/image/upload/c_scale,h_20,w_20/v1571472765/ktvu4bapylsvnykoyhdm.png", nonVisible = true, version = 11, versionName = "11")
@SimpleObject(external = true)
@UsesPermissions(permissionNames = "android.permission.WRITE_EXTERNAL_STORAGE,android.permission.ACCESS_DOWNLOAD_MANAGER,android.permission.ACCESS_FINE_LOCATION,android.permission.RECORD_AUDIO, android.permission.MODIFY_AUDIO_SETTINGS, android.permission.CAMERA,android.permission.VIBRATE,android.webkit.resource.VIDEO_CAPTURE,android.webkit.resource.AUDIO_CAPTURE,android.launcher.permission.INSTALL_SHORTCUT")
public final class CustomWebView extends AndroidNonvisibleComponent {
    public static List<String> AD_HOSTS;
    private String MOBILE_USER_AGENT = "";
    public String UserAgent = "";
    public Activity activity;
    public boolean blockAds;
    public Context context;
    public CookieManager cookieManager;
    public boolean deepLinks = false;
    public boolean desktopMode;
    public float deviceDensity;
    public boolean displayZoom;
    public Message dontSend;
    public boolean followLinks = true;
    public HttpAuthHandler httpAuthHandler;
    public int iD;
    public boolean isLoading = false;
    public String jobName = "";
    public JsResult jsAlert;
    public JsPromptResult jsPromptResult;
    public JsResult jsResult;
    private ValueCallback<Uri[]> mFilePathCallback;
    public PermissionRequest permissionRequest;
    public PrintJob printJob;
    public boolean prompt = true;
    public Message reSend;
    public Message resultObj;
    public SslErrorHandler sslHandler;
    public GeolocationPermissions.Callback theCallback;
    public String theOrigin;
    public WebView webView;
    public HashMap<Integer, WebView> wv;
    public WebViewInterface wvInterface;
    public boolean zoomEnabled;
    public int zoomPercent;

    public static class AdBlocker {
        public AdBlocker() {
        }

        private boolean isAdHost(String str) {
            String str2 = str;
            if (str2.isEmpty()) {
                return false;
            }
            int indexOf = str2.indexOf(".");
            return indexOf >= 0 && (CustomWebView.AD_HOSTS.contains(str2) || (indexOf + 1 < str2.length() && isAdHost(str2.substring(indexOf + 1))));
        }

        public WebResourceResponse createEmptyResource() {
            WebResourceResponse webResourceResponse;
            new WebResourceResponse("text/plain", "utf-8", (InputStream) null);
            return webResourceResponse;
        }

        public boolean isAd(String str) {
            String str2;
            URL url;
            URL url2;
            String str3 = str;
            if (str3 != null) {
                try {
                    new URL(str3);
                    if (url.getHost() != null) {
                        new URL(str3);
                        str2 = url2.getHost();
                        return isAdHost(str2);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    return false;
                }
            }
            str2 = "";
            return isAdHost(str2);
        }
    }

    public class ChromeClient extends WebChromeClient {
        private final int FULL_SCREEN_SETTING = 3846;
        private View mCustomView;
        private WebChromeClient.CustomViewCallback mCustomViewCallback;
        private int mOriginalOrientation;
        private int mOriginalSystemUiVisibility;
        final /* synthetic */ CustomWebView this$0;

        public ChromeClient(CustomWebView customWebView) {
            this.this$0 = customWebView;
        }

        public void onCloseWindow(WebView webView) {
            this.this$0.OnCloseWindowRequest(this.this$0.getIndex(webView));
        }

        public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
            ConsoleMessage consoleMessage2 = consoleMessage;
            this.this$0.OnConsoleMessage(consoleMessage2.message(), consoleMessage2.lineNumber(), consoleMessage2.lineNumber(), consoleMessage2.messageLevel().toString());
            return true;
        }

        public boolean onCreateWindow(WebView webView, boolean z, boolean z2, Message message) {
            WebView webView2 = webView;
            boolean z3 = z;
            boolean z4 = z2;
            Message message2 = message;
            if (this.this$0.SupportMultipleWindows()) {
                this.this$0.resultObj = message2;
                this.this$0.OnNewWindowRequest(this.this$0.getIndex(webView2), z3, z4);
            }
            return this.this$0.SupportMultipleWindows();
        }

        public void onGeolocationPermissionsShowPrompt(String str, GeolocationPermissions.Callback callback) {
            String str2 = str;
            GeolocationPermissions.Callback callback2 = callback;
            if (!this.this$0.prompt) {
                callback2.invoke(str2, true, true);
                return;
            }
            this.this$0.theCallback = callback2;
            this.this$0.theOrigin = str2;
            this.this$0.OnGeolocationRequested(str2);
        }

        public void onHideCustomView() {
            this.this$0.OnHideCustomView();
            ((FrameLayout) this.this$0.activity.getWindow().getDecorView()).removeView(this.mCustomView);
            this.mCustomView = null;
            this.this$0.activity.getWindow().getDecorView().setSystemUiVisibility(this.mOriginalSystemUiVisibility);
            this.this$0.activity.setRequestedOrientation(this.mOriginalOrientation);
            this.mCustomViewCallback.onCustomViewHidden();
            this.mCustomViewCallback = null;
            this.this$0.activity.setRequestedOrientation(2);
        }

        public boolean onJsAlert(WebView webView, String str, String str2, JsResult jsResult) {
            this.this$0.OnJsAlert(this.this$0.getIndex(webView), str, str2);
            this.this$0.jsAlert = jsResult;
            return this.this$0.EnableJS();
        }

        public boolean onJsConfirm(WebView webView, String str, String str2, JsResult jsResult) {
            this.this$0.jsResult = jsResult;
            this.this$0.OnJsConfirm(this.this$0.getIndex(webView), str, str2);
            return this.this$0.EnableJS();
        }

        public boolean onJsPrompt(WebView webView, String str, String str2, String str3, JsPromptResult jsPromptResult) {
            this.this$0.jsPromptResult = jsPromptResult;
            this.this$0.OnJsPrompt(this.this$0.getIndex(webView), str, str2, str3);
            return this.this$0.EnableJS();
        }

        public void onPermissionRequest(PermissionRequest permissionRequest) {
            PermissionRequest permissionRequest2 = permissionRequest;
            if (!this.this$0.prompt) {
                permissionRequest2.grant(permissionRequest2.getResources());
                return;
            }
            this.this$0.permissionRequest = permissionRequest2;
            this.this$0.OnPermissionRequest(Arrays.asList(permissionRequest2.getResources()));
        }

        public void onProgressChanged(WebView webView, int i) {
            this.this$0.OnProgressChanged(this.this$0.getIndex(webView), i);
        }

        public void onShowCustomView(View view, WebChromeClient.CustomViewCallback customViewCallback) {
            ViewGroup.LayoutParams layoutParams;
            View.OnSystemUiVisibilityChangeListener onSystemUiVisibilityChangeListener;
            View view2 = view;
            WebChromeClient.CustomViewCallback customViewCallback2 = customViewCallback;
            this.this$0.OnShowCustomView();
            if (this.mCustomView != null) {
                onHideCustomView();
                return;
            }
            this.mCustomView = view2;
            this.mOriginalSystemUiVisibility = this.this$0.activity.getWindow().getDecorView().getSystemUiVisibility();
            this.mOriginalOrientation = this.this$0.activity.getRequestedOrientation();
            this.mCustomViewCallback = customViewCallback2;
            new FrameLayout.LayoutParams(-1, -1);
            ((FrameLayout) this.this$0.activity.getWindow().getDecorView()).addView(this.mCustomView, layoutParams);
            this.this$0.activity.getWindow().getDecorView().setSystemUiVisibility(3846);
            this.this$0.activity.setRequestedOrientation(2);
            new View.OnSystemUiVisibilityChangeListener(this) {
                final /* synthetic */ ChromeClient this$1;

                {
                    this.this$1 = r5;
                }

                public void onSystemUiVisibilityChange(int i) {
                    int i2 = i;
                    this.this$1.updateControls();
                }
            };
            this.mCustomView.setOnSystemUiVisibilityChangeListener(onSystemUiVisibilityChangeListener);
        }

        public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> valueCallback, WebChromeClient.FileChooserParams fileChooserParams) {
            WebChromeClient.FileChooserParams fileChooserParams2 = fileChooserParams;
            ValueCallback access$002 = CustomWebView.access$002(this.this$0, valueCallback);
            this.this$0.FileUploadNeeded(this.this$0.getIndex(webView), fileChooserParams2.getAcceptTypes()[0], fileChooserParams2.isCaptureEnabled());
            return this.this$0.FileAccess();
        }

        /* access modifiers changed from: package-private */
        public void updateControls() {
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.mCustomView.getLayoutParams();
            layoutParams.bottomMargin = 0;
            layoutParams.topMargin = 0;
            layoutParams.leftMargin = 0;
            layoutParams.rightMargin = 0;
            layoutParams.height = -1;
            layoutParams.width = -1;
            this.mCustomView.setLayoutParams(layoutParams);
            this.this$0.activity.getWindow().getDecorView().setSystemUiVisibility(3846);
        }
    }

    public class PrintDocumentAdapterWrapper extends PrintDocumentAdapter {
        private final PrintDocumentAdapter delegate;
        final /* synthetic */ CustomWebView this$0;

        public PrintDocumentAdapterWrapper(CustomWebView customWebView, PrintDocumentAdapter printDocumentAdapter) {
            this.this$0 = customWebView;
            this.delegate = printDocumentAdapter;
        }

        public void onFinish() {
            this.delegate.onFinish();
            this.this$0.GotPrintResult(this.this$0.jobName, this.this$0.printJob.isCompleted(), this.this$0.printJob.isFailed(), this.this$0.printJob.isBlocked());
        }

        public void onLayout(PrintAttributes printAttributes, PrintAttributes printAttributes2, CancellationSignal cancellationSignal, PrintDocumentAdapter.LayoutResultCallback layoutResultCallback, Bundle bundle) {
            this.delegate.onLayout(printAttributes, printAttributes2, cancellationSignal, layoutResultCallback, bundle);
        }

        public void onWrite(PageRange[] pageRangeArr, ParcelFileDescriptor parcelFileDescriptor, CancellationSignal cancellationSignal, PrintDocumentAdapter.WriteResultCallback writeResultCallback) {
            this.delegate.onWrite(pageRangeArr, parcelFileDescriptor, cancellationSignal, writeResultCallback);
        }
    }

    public class WebClient extends WebViewClient {
        public HashMap<String, Boolean> loadedUrls;
        final /* synthetic */ CustomWebView this$0;

        public WebClient(CustomWebView customWebView) {
            HashMap<String, Boolean> hashMap;
            this.this$0 = customWebView;
            new HashMap<>();
            this.loadedUrls = hashMap;
        }

        public void onFormResubmission(WebView webView, Message message, Message message2) {
            this.this$0.dontSend = message;
            this.this$0.reSend = message2;
            this.this$0.OnFormResubmission(this.this$0.getIndex(webView));
        }

        public void onPageFinished(WebView webView, String str) {
            WebView webView2 = webView;
            String str2 = str;
            if (this.this$0.wv.get(Integer.valueOf(this.this$0.CurrentId())) == webView2 && this.this$0.isLoading) {
                this.this$0.isLoading = false;
                this.this$0.PageLoaded(this.this$0.getIndex(webView2));
            }
        }

        public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
            WebView webView2 = webView;
            String str2 = str;
            Bitmap bitmap2 = bitmap;
            if (!this.this$0.isLoading) {
                this.this$0.PageStarted(this.this$0.getIndex(webView2), str2);
                this.this$0.isLoading = true;
            }
        }

        public void onReceivedError(WebView webView, int i, String str, String str2) {
            this.this$0.OnErrorReceived(this.this$0.getIndex(webView), str, i, str2);
        }

        public void onReceivedError(WebView webView, WebResourceRequest webResourceRequest, WebResourceError webResourceError) {
            WebResourceError webResourceError2 = webResourceError;
            this.this$0.OnErrorReceived(this.this$0.getIndex(webView), webResourceError2.getDescription().toString(), webResourceError2.getErrorCode(), webResourceRequest.getUrl().toString());
        }

        public void onReceivedHttpAuthRequest(WebView webView, HttpAuthHandler httpAuthHandler, String str, String str2) {
            this.this$0.httpAuthHandler = httpAuthHandler;
            this.this$0.OnReceivedHttpAuthRequest(this.this$0.getIndex(webView), str, str2);
        }

        public void onReceivedHttpError(WebView webView, WebResourceRequest webResourceRequest, WebResourceResponse webResourceResponse) {
            WebResourceResponse webResourceResponse2 = webResourceResponse;
            this.this$0.OnErrorReceived(this.this$0.getIndex(webView), webResourceResponse2.getReasonPhrase(), webResourceResponse2.getStatusCode(), webResourceRequest.getUrl().toString());
        }

        public void onReceivedSslError(WebView webView, SslErrorHandler sslErrorHandler, SslError sslError) {
            WebView webView2 = webView;
            this.this$0.sslHandler = sslErrorHandler;
            this.this$0.OnReceivedSslError(sslError.getPrimaryError());
        }

        public WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest webResourceRequest) {
            AdBlocker adBlocker;
            boolean booleanValue;
            WebView webView2 = webView;
            WebResourceRequest webResourceRequest2 = webResourceRequest;
            if (!this.this$0.blockAds) {
                return null;
            }
            new AdBlocker();
            AdBlocker adBlocker2 = adBlocker;
            String uri = webResourceRequest2.getUrl().toString();
            if (!this.loadedUrls.containsKey(uri)) {
                booleanValue = adBlocker2.isAd(uri);
                Boolean put = this.loadedUrls.put(uri, Boolean.valueOf(booleanValue));
            } else {
                booleanValue = this.loadedUrls.get(uri).booleanValue();
            }
            return booleanValue ? adBlocker2.createEmptyResource() : null;
        }

        public WebResourceResponse shouldInterceptRequest(WebView webView, String str) {
            AdBlocker adBlocker;
            boolean booleanValue;
            WebView webView2 = webView;
            String str2 = str;
            if (!this.this$0.blockAds) {
                return null;
            }
            new AdBlocker();
            AdBlocker adBlocker2 = adBlocker;
            if (!this.loadedUrls.containsKey(str2)) {
                booleanValue = adBlocker2.isAd(str2);
                Boolean put = this.loadedUrls.put(str2, Boolean.valueOf(booleanValue));
            } else {
                booleanValue = this.loadedUrls.get(str2).booleanValue();
            }
            return booleanValue ? adBlocker2.createEmptyResource() : null;
        }

        public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
            WebView webView2 = webView;
            String uri = webResourceRequest.getUrl().toString();
            if (uri.startsWith("http")) {
                return !this.this$0.followLinks;
            } else if (this.this$0.deepLinks) {
                return this.this$0.DeepLinkParser(uri);
            } else {
                return false;
            }
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            WebView webView2 = webView;
            String str2 = str;
            if (str2.startsWith("http")) {
                return !this.this$0.followLinks;
            } else if (this.this$0.deepLinks) {
                return this.this$0.DeepLinkParser(str2);
            } else {
                return false;
            }
        }
    }

    public class WebViewInterface {
        final /* synthetic */ CustomWebView this$0;
        String webViewString = "";

        WebViewInterface(CustomWebView customWebView) {
            this.this$0 = customWebView;
        }

        @JavascriptInterface
        public String getWebViewString() {
            return this.webViewString;
        }

        @JavascriptInterface
        public void setWebViewString(String str) {
            Runnable runnable;
            String str2 = str;
            this.webViewString = str2;
            final String str3 = str2;
            new Runnable(this) {
                final /* synthetic */ WebViewInterface this$1;

                {
                    this.this$1 = r6;
                }

                public void run() {
                    this.this$1.this$0.WebViewStringChanged(str3);
                }
            };
            this.this$0.activity.runOnUiThread(runnable);
        }

        public void setWebViewStringFromBlocks(String str) {
            String str2 = str;
            this.webViewString = str2;
        }
    }

    static {
        List<String> list;
        new ArrayList();
        AD_HOSTS = list;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public CustomWebView(com.google.appinventor.components.runtime.ComponentContainer r8) {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            r3 = 1
            r2.followLinks = r3
            r2 = r0
            r3 = 1
            r2.prompt = r3
            r2 = r0
            java.lang.String r3 = ""
            r2.UserAgent = r3
            r2 = r0
            java.lang.String r3 = ""
            r2.MOBILE_USER_AGENT = r3
            r2 = r0
            r3 = 0
            r2.deepLinks = r3
            r2 = r0
            java.lang.String r3 = ""
            r2.jobName = r3
            r2 = r0
            r3 = 0
            r2.isLoading = r3
            r2 = r0
            java.util.HashMap r3 = new java.util.HashMap
            r6 = r3
            r3 = r6
            r4 = r6
            r4.<init>()
            r2.wv = r3
            r2 = r0
            r3 = 0
            r2.blockAds = r3
            r2 = r0
            r3 = 0
            r2.iD = r3
            r2 = r0
            r3 = 0
            r2.desktopMode = r3
            r2 = r0
            r3 = 100
            r2.zoomPercent = r3
            r2 = r0
            r3 = 1
            r2.zoomEnabled = r3
            r2 = r0
            r3 = 1
            r2.displayZoom = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.activity = r3
            r2 = r0
            r3 = r0
            android.app.Activity r3 = r3.activity
            r2.context = r3
            r2 = r0
            com.sunny.CustomWebView.CustomWebView$WebViewInterface r3 = new com.sunny.CustomWebView.CustomWebView$WebViewInterface
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r0
            r4.<init>(r5)
            r2.wvInterface = r3
            r2 = r0
            android.webkit.CookieManager r3 = android.webkit.CookieManager.getInstance()
            r2.cookieManager = r3
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            float r3 = r3.deviceDensity()
            r2.deviceDensity = r3
            r2 = r0
            android.webkit.WebView r3 = new android.webkit.WebView
            r6 = r3
            r3 = r6
            r4 = r6
            r5 = r0
            android.content.Context r5 = r5.context
            r4.<init>(r5)
            r2.webView = r3
            r2 = r0
            r3 = r0
            android.webkit.WebView r3 = r3.webView
            r2.resetWebView(r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.sunny.CustomWebView.CustomWebView.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    static /* synthetic */ ValueCallback access$002(CustomWebView customWebView, ValueCallback valueCallback) {
        ValueCallback valueCallback2 = valueCallback;
        ValueCallback valueCallback3 = valueCallback2;
        customWebView.mFilePathCallback = valueCallback3;
        return valueCallback2;
    }

    @DesignerProperty(defaultValue = "", editorType = "string")
    @SimpleProperty(description = "Sets the ad hosts which will be blocked")
    public void AdHosts(String str) {
        boolean addAll = AD_HOSTS.addAll(Arrays.asList(str.split(",")));
    }

    @SimpleEvent(description = "Event raised after 'SaveArchive' method.If 'success' is true then returns file path else empty string.")
    public void AfterArchiveSaved(boolean z, String str) {
        Object[] objArr = new Object[2];
        objArr[0] = Boolean.valueOf(z);
        Object[] objArr2 = objArr;
        objArr2[1] = str;
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "AfterArchiveSaved", objArr2);
    }

    @SimpleEvent(description = "Event raised after evaluating Js and returns result.")
    public void AfterJavaScriptEvaluated(String str) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "AfterJavaScriptEvaluated", new Object[]{str});
    }

    @SimpleFunction
    public void AllowGeolocationAccess(boolean z, boolean z2) {
        boolean z3 = z;
        boolean z4 = z2;
        if (this.theCallback != null) {
            this.theCallback.invoke(this.theOrigin, z3, z4);
            this.theCallback = null;
            this.theOrigin = "";
        }
    }

    @SimpleProperty(description = "Sets whether the WebView should load image resources")
    public void AutoLoadImages(boolean z) {
        boolean z2 = z;
        this.webView.getSettings().setBlockNetworkImage(!z2);
        this.webView.getSettings().setLoadsImagesAutomatically(z2);
    }

    @SimpleProperty(description = "Returnss whether the WebView should load image resources")
    public boolean AutoLoadImages() {
        return this.webView.getSettings().getLoadsImagesAutomatically();
    }

    @SimpleProperty(description = "Sets whether the WebView requires a user gesture to play media")
    public void AutoplayMedia(boolean z) {
        this.webView.getSettings().setMediaPlaybackRequiresUserGesture(z);
    }

    @SimpleProperty(description = "Returns whether the WebView requires a user gesture to play media")
    public boolean AutoplayMedia() {
        return this.webView.getSettings().getMediaPlaybackRequiresUserGesture();
    }

    @SimpleProperty(description = "Sets background color of webview")
    public void BackgroundColor(int i) {
        this.webView.setBackgroundColor(i);
    }

    @DesignerProperty(defaultValue = "False", editorType = "boolean")
    @SimpleProperty(description = "Sets whether to block ads or not")
    public void BlockAds(boolean z) {
        boolean z2 = z;
        this.blockAds = z2;
    }

    @SimpleProperty(description = "Sets whether the WebView should not load resources from the network.Use this to save data.")
    public void BlockNetworkLoads(boolean z) {
        this.webView.getSettings().setBlockNetworkLoads(z);
    }

    @SimpleProperty(description = "Returns whether the WebView should not load resources from the network")
    public boolean BlockNetworkLoads() {
        return this.webView.getSettings().getBlockNetworkLoads();
    }

    @SimpleProperty(description = "Gets cache mode of active webview")
    public int CacheMode() {
        return this.webView.getSettings().getCacheMode();
    }

    @SimpleProperty(description = "Sets cache mode for active webview")
    public void CacheMode(int i) {
        this.webView.getSettings().setCacheMode(i);
    }

    @SimpleFunction(description = "Gets whether this WebView has a back history item")
    public boolean CanGoBack() {
        return this.webView.canGoBack();
    }

    @SimpleFunction(description = "Gets whether the page can go back or forward the given number of steps.")
    public boolean CanGoBackOrForward(int i) {
        return this.webView.canGoBackOrForward(i);
    }

    @SimpleFunction(description = "Gets whether this WebView has a forward history item.")
    public boolean CanGoForward() {
        return this.webView.canGoForward();
    }

    public void CancelJsRequests() {
        if (this.jsAlert != null) {
            this.jsAlert.cancel();
            this.jsAlert = null;
        } else if (this.jsResult != null) {
            this.jsResult.cancel();
            this.jsResult = null;
        } else if (this.jsPromptResult != null) {
            this.jsPromptResult.cancel();
            this.jsPromptResult = null;
        } else if (this.mFilePathCallback != null) {
            this.mFilePathCallback.onReceiveValue((Object) null);
            this.mFilePathCallback = null;
        }
    }

    @SimpleFunction(description = "Cancels current print job. You can request cancellation of a queued, started, blocked, or failed print job.")
    public void CancelPrinting() throws Exception {
        this.printJob.cancel();
    }

    @SimpleFunction(description = "Clears the resource cache.")
    public void ClearCache() {
        this.webView.clearCache(true);
    }

    @SimpleFunction(description = "Removes all cookies and raises 'CookiesRemoved' event")
    public void ClearCookies() {
        ValueCallback valueCallback;
        new ValueCallback<Boolean>(this) {
            final /* synthetic */ CustomWebView this$0;

            {
                this.this$0 = r5;
            }

            public void onReceiveValue(Boolean bool) {
                this.this$0.CookiesRemoved(bool.booleanValue());
            }
        };
        this.cookieManager.removeAllCookies(valueCallback);
        this.cookieManager.flush();
    }

    @SimpleFunction(description = "Tells this WebView to clear its internal back/forward list.")
    public void ClearInternalHistory() {
        this.webView.clearHistory();
    }

    @SimpleFunction(description = "Clear all location preferences.")
    public void ClearLocation() {
        GeolocationPermissions.getInstance().clearAll();
    }

    @SimpleFunction(description = "Clears the highlighting surrounding text matches.")
    public void ClearMatches() {
        this.webView.clearMatches();
    }

    @SimpleFunction(description = "Whether to proceed JavaScript originated request")
    public void ConfirmJs(boolean z) {
        boolean z2 = z;
        if (this.jsResult != null) {
            if (z2) {
                this.jsResult.confirm();
            } else {
                this.jsResult.cancel();
            }
            this.jsResult = null;
        }
    }

    @SimpleFunction(description = "Gets height of HTML content")
    public int ContentHeight() {
        return d2p(this.webView.getContentHeight());
    }

    @SimpleFunction(description = "Inputs a confirmation response to Js")
    public void ContinueJs(String str) {
        String str2 = str;
        if (this.jsPromptResult != null) {
            this.jsPromptResult.confirm(str2);
            this.jsPromptResult = null;
        }
    }

    @SimpleEvent(description = "Event raised after 'ClearCokies' method with result")
    public void CookiesRemoved(boolean z) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "CookiesRemoved", new Object[]{Boolean.valueOf(z)});
    }

    @SimpleFunction(description = "Creates a shortcut of given website on home screen")
    public void CreateShortcut(String str, String str2, String str3) {
        Intent intent;
        List list;
        ShortcutInfo.Builder builder;
        Intent intent2;
        String str4 = str;
        String str5 = str3;
        try {
            Bitmap decodeFile = BitmapFactory.decodeFile(str2);
            if (decodeFile != null) {
                String string = this.context.getSharedPreferences("TinyDB1", 0).getString("ssn", "");
                String packageName = this.context.getPackageName();
                new Intent();
                Intent intent3 = intent;
                Intent className = intent3.setClassName(this.context, ((ResolveInfo) Objects.requireNonNull(this.context.getPackageManager().resolveActivity(this.context.getPackageManager().getLaunchIntentForPackage(packageName), 0))).activityInfo.name.replaceAll("Screen1", string.length() == 0 ? "Screen1" : JsonUtil.getObjectFromJson(string, true).toString()));
                new ArrayList();
                List list2 = list;
                boolean add = list2.add(str4);
                boolean add2 = list2.add("2");
                Intent putExtra = intent3.putExtra("APP_INVENTOR_START", JsonUtil.getJsonRepresentation(list2));
                if (Build.VERSION.SDK_INT < 26) {
                    new Intent("com.android.launcher.action.INSTALL_SHORTCUT");
                    Intent intent4 = intent2;
                    Intent putExtra2 = intent4.putExtra("android.intent.extra.shortcut.INTENT", intent3);
                    Intent putExtra3 = intent4.putExtra("android.intent.extra.shortcut.NAME", str5);
                    Intent putExtra4 = intent4.putExtra("android.intent.extra.shortcut.ICON", decodeFile);
                    Intent putExtra5 = intent4.putExtra("duplicate", false);
                    this.context.sendBroadcast(intent4);
                    return;
                }
                ShortcutManager shortcutManager = (ShortcutManager) this.context.getSystemService("shortcut");
                if (shortcutManager.isRequestPinShortcutSupported()) {
                    new ShortcutInfo.Builder(this.context, str5);
                    ShortcutInfo build = builder.setShortLabel(str5).setIcon(Icon.createWithBitmap(decodeFile)).setIntent(intent3).build();
                    boolean requestPinShortcut = shortcutManager.requestPinShortcut(build, PendingIntent.getBroadcast(this.context, 0, shortcutManager.createShortcutResultIntent(build), 0).getIntentSender());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SimpleFunction(description = "Creates the webview in given arrangement with id")
    public void CreateWebView(HVArrangement hVArrangement, int i) {
        WebView webView2;
        ViewGroup.LayoutParams layoutParams;
        HVArrangement hVArrangement2 = hVArrangement;
        int i2 = i;
        if (!this.wv.containsKey(Integer.valueOf(i2)) || hVArrangement2 != null) {
            View view = hVArrangement2.getView();
            if (!this.wv.containsKey(Integer.valueOf(i2))) {
                new WebView(this.context);
                WebView webView3 = webView2;
                resetWebView(webView3);
                new FrameLayout.LayoutParams(-1, -1);
                ((FrameLayout) view).addView(webView3, layoutParams);
                WebView put = this.wv.put(Integer.valueOf(i2), webView3);
            }
        }
    }

    @SimpleFunction(description = "Returns current id")
    public int CurrentId() {
        return this.iD;
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "Title of the page currently viewed")
    public String CurrentPageTitle() {
        return this.webView.getTitle() == null ? "" : this.webView.getTitle();
    }

    @SimpleProperty(description = "URL of the page currently viewed")
    public String CurrentUrl() {
        return this.webView.getUrl() == null ? "" : this.webView.getUrl();
    }

    public boolean DeepLinkParser(String str) {
        Intent intent;
        Intent intent2;
        StringBuilder sb;
        Intent intent3;
        Intent intent4;
        Intent intent5;
        String str2 = str;
        PackageManager packageManager = this.context.getPackageManager();
        if (str2.startsWith("tel:")) {
            new Intent("android.intent.action.DIAL", Uri.parse(str2));
            this.activity.startActivity(intent5);
            return true;
        } else if (str2.startsWith("mailto:") || str2.startsWith("sms:")) {
            new Intent("android.intent.action.VIEW", Uri.parse(str2));
            this.activity.startActivity(intent);
            return true;
        } else if (str2.startsWith("whatsapp:")) {
            new Intent("android.intent.action.VIEW", Uri.parse(str2));
            Intent intent6 = intent4;
            Intent intent7 = intent6.setPackage("com.whatsapp");
            this.activity.startActivity(intent6);
            return true;
        } else if (str2.startsWith("geo:")) {
            new Intent("android.intent.action.VIEW", Uri.parse(str2));
            Intent intent8 = intent3;
            Intent intent9 = intent8.setPackage("com.google.android.apps.maps");
            if (intent8.resolveActivity(packageManager) == null) {
                return false;
            }
            this.activity.startActivity(intent8);
            return true;
        } else if (!str2.startsWith("intent:")) {
            return false;
        } else {
            try {
                Intent parseUri = Intent.parseUri(str2, 1);
                if (parseUri.resolveActivity(packageManager) != null) {
                    this.activity.startActivity(parseUri);
                    return true;
                }
                String stringExtra = parseUri.getStringExtra("browser_fallback_url");
                if (stringExtra != null) {
                    this.webView.loadUrl(stringExtra);
                }
                new Intent("android.intent.action.VIEW");
                new StringBuilder();
                Intent data = intent2.setData(Uri.parse(sb.append("market://details?id=").append(parseUri.getPackage()).toString()));
                if (data.resolveActivity(packageManager) == null) {
                    return false;
                }
                this.activity.startActivity(data);
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
    }

    @DesignerProperty(defaultValue = "False", editorType = "boolean")
    @SimpleProperty(description = "Sets whether to enable deep links or not i.e. tel: , whatsapp: , sms: , etc.")
    public void DeepLinks(boolean z) {
        boolean z2 = z;
        this.deepLinks = z2;
    }

    @SimpleProperty(description = "Returns whether deep links are enabled or not")
    public boolean DeepLinks() {
        return this.deepLinks;
    }

    @SimpleProperty(description = "Sets whether to load content in desktop mode")
    public void DesktopMode(boolean z) {
        boolean z2 = z;
        if (z2) {
            this.UserAgent = this.UserAgent.replace("Android", "diordnA").replace("Mobile", "eliboM");
        } else {
            this.UserAgent = this.UserAgent.replace("diordnA", "Android").replace("eliboM", "Mobile");
        }
        this.webView.getSettings().setUserAgentString(this.UserAgent);
        this.desktopMode = z2;
    }

    @SimpleProperty(description = "Returns whether to load content in desktop mode")
    public boolean DesktopMode() {
        return this.desktopMode;
    }

    @SimpleFunction(description = "Dismiss previously requested Js alert")
    public void DismissJsAlert() {
        if (this.jsAlert != null) {
            this.jsAlert.cancel();
            this.jsAlert = null;
        }
    }

    @DesignerProperty(defaultValue = "True", editorType = "boolean")
    @SimpleProperty(description = "Sets whether the WebView should display on-screen zoom controls")
    public void DisplayZoom(boolean z) {
        boolean z2 = z;
        this.displayZoom = z2;
    }

    @SimpleProperty(description = "Gets whether the WebView should display on-screen zoom controls")
    public boolean DisplayZoom() {
        return this.displayZoom;
    }

    @SimpleProperty(description = "Tells the WebView to enable JavaScript execution.")
    public void EnableJS(boolean z) {
        this.webView.getSettings().setJavaScriptEnabled(z);
    }

    @SimpleProperty(description = "Returns whether webview supports JavaScript execution")
    public boolean EnableJS() {
        return this.webView.getSettings().getJavaScriptEnabled();
    }

    @SimpleFunction(description = "Asynchronously evaluates JavaScript in the context of the currently displayed page.")
    public void EvaluateJavaScript(String str) {
        ValueCallback valueCallback;
        new ValueCallback<String>(this) {
            final /* synthetic */ CustomWebView this$0;

            {
                this.this$0 = r5;
            }

            public void onReceiveValue(String str) {
                this.this$0.AfterJavaScriptEvaluated(str);
            }
        };
        this.webView.evaluateJavascript(str, valueCallback);
    }

    @SimpleProperty(description = "Sets whether webview can access local files.Use this to enable file uploading and loading files using HTML")
    public void FileAccess(boolean z) {
        boolean z2 = z;
        this.webView.getSettings().setAllowFileAccess(z2);
        this.webView.getSettings().setAllowFileAccessFromFileURLs(z2);
        this.webView.getSettings().setAllowUniversalAccessFromFileURLs(z2);
        this.webView.getSettings().setAllowContentAccess(z2);
    }

    @SimpleProperty(description = "Returns whether webview can access local files")
    public boolean FileAccess() {
        return this.webView.getSettings().getAllowFileAccess();
    }

    @SimpleEvent(description = "Event raised when file uploading is needed")
    public void FileUploadNeeded(int i, String str, boolean z) {
        Object[] objArr = new Object[3];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = str;
        Object[] objArr3 = objArr2;
        objArr3[2] = Boolean.valueOf(z);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "FileUploadNeeded", objArr3);
    }

    @SimpleFunction(description = "Finds all instances of find on the page and highlights them, asynchronously. Successive calls to this will cancel any pending searches.")
    public void Find(String str) {
        this.webView.findAllAsync(str);
    }

    @SimpleFunction(description = "Highlights and scrolls to the next match if 'forward' is true else scrolls to previous match.")
    public void FindNext(boolean z) {
        this.webView.findNext(z);
    }

    @SimpleEvent(description = "Event raised after 'Find' method with int 'activeMatchOrdinal','numberOfMatches' and 'isDoneCounting'")
    public void FindResultReceived(int i, int i2, int i3, boolean z) {
        Object[] objArr = new Object[4];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = Integer.valueOf(i2);
        Object[] objArr3 = objArr2;
        objArr3[2] = Integer.valueOf(i3);
        Object[] objArr4 = objArr3;
        objArr4[3] = Boolean.valueOf(z);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "FindResultReceived", objArr4);
    }

    @DesignerProperty(defaultValue = "True", editorType = "boolean")
    @SimpleProperty(description = "Sets whether to follow links or not")
    public void FollowLinks(boolean z) {
        boolean z2 = z;
        this.followLinks = z2;
    }

    @SimpleProperty(description = "Determines whether to follow links when they are tapped in the WebViewer.If you follow links, you can use GoBack and GoForward to navigate the browser history")
    public boolean FollowLinks() {
        return this.followLinks;
    }

    @SimpleProperty(description = "Returns the font size of text")
    public int FontSize() {
        return this.webView.getSettings().getDefaultFontSize();
    }

    @SimpleProperty(description = "Sets the default font size of text. The default is 16.")
    public void FontSize(int i) {
        this.webView.getSettings().setDefaultFontSize(i);
    }

    @SimpleFunction(description = "Get cookies for specific url")
    public String GetCookies(String str) {
        String cookie = CookieManager.getInstance().getCookie(str);
        return cookie != null ? cookie : "";
    }

    @SimpleFunction(description = "Returns a list of used ids")
    public List<Integer> GetIds() {
        List<Integer> list;
        new ArrayList(this.wv.keySet());
        return list;
    }

    @SimpleFunction(description = "Get internal history of given webview.")
    public List<String> GetInternalHistory(int i) {
        List<String> list;
        int i2 = i;
        new ArrayList();
        List<String> list2 = list;
        if (this.wv.containsKey(Integer.valueOf(i2))) {
            WebBackForwardList copyBackForwardList = this.wv.get(Integer.valueOf(i2)).copyBackForwardList();
            for (int i3 = 0; i3 < copyBackForwardList.getSize(); i3++) {
                boolean add = list2.add(copyBackForwardList.getItemAtIndex(i3).getUrl());
            }
        }
        return list2;
    }

    @SimpleFunction(description = "Gets the progress for the given webview")
    public int GetProgress(int i) {
        return this.wv.get(Integer.valueOf(i)).getProgress();
    }

    @SimpleFunction(description = "Return the scrolled left position of the webview")
    public int GetScrollX() {
        return d2p(this.webView.getScrollX());
    }

    @SimpleFunction(description = "Return the scrolled top position of the webview")
    public int GetScrollY() {
        return d2p(this.webView.getScrollY());
    }

    @SimpleFunction(description = "Gets the SSL certificate for the main top-level page and raises 'GotCertificate' event")
    public void GetSslCertificate() {
        SslCertificate certificate = this.webView.getCertificate();
        if (certificate != null) {
            GotCertificate(true, certificate.getIssuedBy().getDName(), certificate.getIssuedTo().getDName(), certificate.getValidNotAfterDate().toString());
        } else {
            GotCertificate(false, "", "", "");
        }
    }

    @SimpleFunction(description = "Returns webview object from id")
    public Object GetWebView(int i) {
        int i2 = i;
        if (this.wv.containsKey(Integer.valueOf(i2))) {
            return this.wv.get(Integer.valueOf(i2));
        }
        return null;
    }

    @SimpleFunction(description = "Goes back in the history of this WebView.")
    public void GoBack() {
        if (CanGoBack()) {
            this.webView.goBack();
        }
    }

    @SimpleFunction(description = "Goes to the history item that is the number of steps away from the current item. Steps is negative if backward and positive if forward.")
    public void GoBackOrForward(int i) {
        int i2 = i;
        if (CanGoBackOrForward(i2)) {
            this.webView.goBackOrForward(i2);
        }
    }

    @SimpleFunction(description = "Goes forward in the history of this WebView.")
    public void GoForward() {
        if (CanGoForward()) {
            this.webView.goForward();
        }
    }

    @SimpleFunction(description = "Loads the given URL.")
    public void GoToUrl(String str) {
        CancelJsRequests();
        this.webView.loadUrl(str);
    }

    @SimpleEvent(description = "Event raised after getting SSL certificate of current displayed url/website with boolean 'isSecure' and Strings 'issuedBy','issuedTo' and 'validTill'.If 'isSecure' is false and other values are empty then assume that website is not secure")
    public void GotCertificate(boolean z, String str, String str2, String str3) {
        Object[] objArr = new Object[4];
        objArr[0] = Boolean.valueOf(z);
        Object[] objArr2 = objArr;
        objArr2[1] = str;
        Object[] objArr3 = objArr2;
        objArr3[2] = str2;
        Object[] objArr4 = objArr3;
        objArr4[3] = str3;
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "GotCertificate", objArr4);
    }

    @SimpleEvent(description = "Event raised after getting previus print's result.")
    public void GotPrintResult(String str, boolean z, boolean z2, boolean z3) {
        Object[] objArr = new Object[4];
        objArr[0] = str;
        Object[] objArr2 = objArr;
        objArr2[1] = Boolean.valueOf(z);
        Object[] objArr3 = objArr2;
        objArr3[2] = Boolean.valueOf(z2);
        Object[] objArr4 = objArr3;
        objArr4[3] = Boolean.valueOf(z3);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "GotPrintResult", objArr4);
    }

    @SimpleFunction(description = "Grants given permissions to webview.Use empty list to deny the request.")
    public void GrantPermission(String str) {
        String str2 = str;
        if (this.permissionRequest != null) {
            if (str2.isEmpty()) {
                this.permissionRequest.deny();
            } else {
                this.permissionRequest.grant(this.permissionRequest.getResources());
            }
            this.permissionRequest = null;
        }
    }

    @SimpleFunction(description = "Hides previously shown custom view")
    public void HideCustomView() {
        this.webView.getWebChromeClient().onHideCustomView();
    }

    @SimpleProperty(description = "Sets the initial scale for active WebView. 0 means default. If initial scale is greater than 0, WebView starts with this value as initial scale.")
    public void InitialScale(int i) {
        this.webView.setInitialScale(i);
    }

    @SimpleFunction(description = "Invokes the graphical zoom picker widget for this WebView. This will result in the zoom widget appearing on the screen to control the zoom level of this WebView.Note that it does not checks whether zoom is enabled or not.")
    public void InvokeZoomPicker() {
        this.webView.invokeZoomPicker();
    }

    @SimpleProperty(description = "")
    public int LayerType() {
        return this.webView.getLayerType();
    }

    @SimpleProperty(description = "")
    public void LayerType(int i) {
        this.webView.setLayerType(i, (Paint) null);
    }

    @SimpleFunction(description = "Loads the given data into this WebView using a 'data' scheme URL.")
    public void LoadHtml(String str) {
        CancelJsRequests();
        this.webView.loadData(Base64.encodeToString(str.getBytes(), 1), "text/html", "base64");
    }

    @SimpleFunction(description = "Loads requested url in given webview")
    public void LoadInNewWindow(int i) {
        int i2 = i;
        if (this.wv.containsKey(Integer.valueOf(i2)) && this.resultObj != null) {
            ((WebView.WebViewTransport) this.resultObj.obj).setWebView(this.wv.get(Integer.valueOf(i2)));
            this.resultObj.sendToTarget();
            this.resultObj = null;
        }
    }

    @SimpleFunction(description = "Loads the given URL with the specified additional HTTP headers defined is list of lists.")
    public void LoadWithHeaders(String str, List<List<String>> list) {
        Map map;
        String str2 = str;
        List<List<String>> list2 = list;
        if (list2.size() == 0 || list2.get(0).size() != 2) {
            GoToUrl(str2);
            return;
        }
        new HashMap();
        Map map2 = map;
        for (List next : list2) {
            Object put = map2.put(next.get(0), next.get(1));
        }
        this.webView.loadUrl(str2, map2);
    }

    @SimpleProperty(description = "Sets whether the WebView loads pages in overview mode, that is, zooms out the content to fit on screen by width. This setting is taken into account when the content width is greater than the width of the WebView control.")
    public void LoadWithOverviewMode(boolean z) {
        this.webView.getSettings().setLoadWithOverviewMode(z);
    }

    @SimpleProperty(description = "Returns whether the WebView loads pages in overview mode")
    public boolean LoadWithOverviewMode() {
        return this.webView.getSettings().getLoadWithOverviewMode();
    }

    @DesignerProperty(defaultValue = "True", editorType = "boolean")
    @SimpleProperty(description = "Sets whether to enable text selection and context menu")
    public void LongClickable(boolean z) {
        this.webView.setLongClickable(!z);
    }

    @SimpleProperty(description = "Returns whether text selection and context menu are enabled or not")
    public boolean LongClickable() {
        return !this.webView.isLongClickable();
    }

    @SimpleEvent(description = "Event raised when something is long clicked in webview with item(image,string,empty,etc) and type(item type like 0,1,8,etc)")
    public void LongClicked(int i, String str, String str2, int i2) {
        Object[] objArr = new Object[4];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = str;
        Object[] objArr3 = objArr2;
        objArr3[2] = str2;
        Object[] objArr4 = objArr3;
        objArr4[3] = Integer.valueOf(i2);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "LongClicked", objArr4);
    }

    @SimpleEvent(description = "Event triggered when a window needs to be closed")
    public void OnCloseWindowRequest(int i) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnCloseWindowRequest", new Object[]{Integer.valueOf(i)});
    }

    @SimpleEvent(description = "Event raised after getting console message.")
    public void OnConsoleMessage(String str, int i, int i2, String str2) {
        Object[] objArr = new Object[4];
        objArr[0] = str;
        Object[] objArr2 = objArr;
        objArr2[1] = Integer.valueOf(i);
        Object[] objArr3 = objArr2;
        objArr3[2] = Integer.valueOf(i2);
        Object[] objArr4 = objArr3;
        objArr4[3] = str2;
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnConsoleMessage", objArr4);
    }

    @SimpleEvent(description = "Event raised when downloading is needed.")
    public void OnDownloadNeeded(int i, String str, String str2, String str3, long j) {
        Object[] objArr = new Object[5];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = str;
        Object[] objArr3 = objArr2;
        objArr3[2] = str2;
        Object[] objArr4 = objArr3;
        objArr4[3] = str3;
        Object[] objArr5 = objArr4;
        objArr5[4] = Long.valueOf(j);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnDownloadNeeded", objArr5);
    }

    @SimpleEvent(description = "Event raised when any error is received during loading url and returns message,error code and failing url")
    public void OnErrorReceived(int i, String str, int i2, String str2) {
        Object[] objArr = new Object[4];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = str;
        Object[] objArr3 = objArr2;
        objArr3[2] = Integer.valueOf(i2);
        Object[] objArr4 = objArr3;
        objArr4[3] = str2;
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnErrorReceived", objArr4);
    }

    @SimpleEvent(description = "Event raised when resubmission of form is needed")
    public void OnFormResubmission(int i) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnFormResubmission", new Object[]{Integer.valueOf(i)});
    }

    @SimpleEvent
    public void OnGeolocationRequested(String str) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnGeolocationRequested", new Object[]{str});
    }

    @SimpleEvent(description = "Event raised when current page exits from full screen mode")
    public void OnHideCustomView() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnHideCustomView", new Object[0]);
    }

    @SimpleEvent(description = "Event raised when Js have to show an alert to user")
    public void OnJsAlert(int i, String str, String str2) {
        Object[] objArr = new Object[3];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = str;
        Object[] objArr3 = objArr2;
        objArr3[2] = str2;
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnJsAlert", objArr3);
    }

    @SimpleEvent(description = "Tells to display a confirm dialog to the user.")
    public void OnJsConfirm(int i, String str, String str2) {
        Object[] objArr = new Object[3];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = str;
        Object[] objArr3 = objArr2;
        objArr3[2] = str2;
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnJsConfirm", objArr3);
    }

    @SimpleEvent(description = "Event raised when JavaScript needs input from user")
    public void OnJsPrompt(int i, String str, String str2, String str3) {
        Object[] objArr = new Object[4];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = str;
        Object[] objArr3 = objArr2;
        objArr3[2] = str2;
        Object[] objArr4 = objArr3;
        objArr4[3] = str3;
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnJsPrompt", objArr4);
    }

    @SimpleEvent(description = "Event raised when new window is requested by webview with boolean 'isDialog' and 'isPopup'")
    public void OnNewWindowRequest(int i, boolean z, boolean z2) {
        Object[] objArr = new Object[3];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = Boolean.valueOf(z);
        Object[] objArr3 = objArr2;
        objArr3[2] = Boolean.valueOf(z2);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnNewWindowRequest", objArr3);
    }

    @SimpleEvent(description = "Event raised when a website asks for specific permission(s) in list format.")
    public void OnPermissionRequest(List<String> list) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnPermissionRequest", new Object[]{list});
    }

    @SimpleEvent(description = "Event raised when page loading progress has changed.")
    public void OnProgressChanged(int i, int i2) {
        Object[] objArr = new Object[2];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = Integer.valueOf(i2);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnProgressChanged", objArr2);
    }

    @SimpleEvent(description = "Notifies that the WebView received an HTTP authentication request.")
    public void OnReceivedHttpAuthRequest(int i, String str, String str2) {
        Object[] objArr = new Object[3];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = str;
        Object[] objArr3 = objArr2;
        objArr3[2] = str2;
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnReceivedHttpAuthRequest", objArr3);
    }

    @SimpleEvent
    public void OnReceivedSslError(int i) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnReceivedSslError", new Object[]{Integer.valueOf(i)});
    }

    @SimpleEvent(description = "Event raised when webview gets scrolled")
    public void OnScrollChanged(int i, int i2, int i3, int i4, int i5, boolean z, boolean z2) {
        Object[] objArr = new Object[7];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = Integer.valueOf(i2);
        Object[] objArr3 = objArr2;
        objArr3[2] = Integer.valueOf(i3);
        Object[] objArr4 = objArr3;
        objArr4[3] = Integer.valueOf(i4);
        Object[] objArr5 = objArr4;
        objArr5[4] = Integer.valueOf(i5);
        Object[] objArr6 = objArr5;
        objArr6[5] = Boolean.valueOf(z);
        Object[] objArr7 = objArr6;
        objArr7[6] = Boolean.valueOf(z2);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnScrollChanged", objArr7);
    }

    @SimpleEvent(description = "Event raised when current page enters in full screen mode")
    public void OnShowCustomView() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnShowCustomView", new Object[0]);
    }

    @SimpleProperty(description = "")
    public int OverScrollMode() {
        return this.webView.getOverScrollMode();
    }

    @SimpleProperty(description = "")
    public void OverScrollMode(int i) {
        this.webView.setOverScrollMode(i);
    }

    @SimpleFunction(description = "Scrolls the contents of the WebView down by half the page size")
    public void PageDown(boolean z) {
        boolean pageDown = this.webView.pageDown(z);
    }

    @SimpleEvent(description = "Event raised when page loading has finished.")
    public void PageLoaded(int i) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "PageLoaded", new Object[]{Integer.valueOf(i)});
    }

    @SimpleEvent(description = "Event indicating that page loading has started in web view.")
    public void PageStarted(int i, String str) {
        Object[] objArr = new Object[2];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = str;
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "PageStarted", objArr2);
    }

    @SimpleFunction(description = "Scrolls the contents of the WebView up by half the page size")
    public void PageUp(boolean z) {
        boolean pageUp = this.webView.pageUp(z);
    }

    @SimpleFunction(description = "Does a best-effort attempt to pause any processing that can be paused safely, such as animations and geolocation. Note that this call does not pause JavaScript.")
    public void PauseWebView(int i) {
        this.wv.get(Integer.valueOf(i)).onPause();
    }

    @SimpleFunction(description = "Loads the URL with postData using 'POST' method into active WebView.")
    public void PostData(String str, String str2) {
        this.webView.postUrl(str, str2.getBytes(StandardCharsets.UTF_8));
    }

    @SimpleFunction(description = "Prints the content of webview with given document name")
    public void PrintWebContent(String str) throws Exception {
        PrintDocumentAdapter printDocumentAdapter;
        PrintAttributes.Builder builder;
        StringBuilder sb;
        String str2 = str;
        PrintManager printManager = (PrintManager) this.context.getSystemService("print");
        if (str2.isEmpty()) {
            new StringBuilder();
            this.jobName = sb.append(this.webView.getTitle()).append("_Document").toString();
        } else {
            this.jobName = str2;
        }
        new PrintDocumentAdapterWrapper(this, this.webView.createPrintDocumentAdapter(this.jobName));
        PrintDocumentAdapter printDocumentAdapter2 = printDocumentAdapter;
        if (printManager != null) {
            new PrintAttributes.Builder();
            this.printJob = printManager.print(this.jobName, printDocumentAdapter2, builder.build());
        }
    }

    @SimpleFunction(description = "Instructs the WebView to proceed with the authentication with the given credentials.If both parameters are empty then it will cancel the request.")
    public void ProceedHttpAuthRequest(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        if (this.httpAuthHandler != null) {
            if (!str3.isEmpty() || !str4.isEmpty()) {
                this.httpAuthHandler.proceed(str3, str4);
            } else {
                this.httpAuthHandler.cancel();
            }
            this.httpAuthHandler = null;
        }
    }

    @SimpleFunction
    public void ProceedSslError(boolean z) {
        boolean z2 = z;
        if (this.sslHandler != null) {
            if (z2) {
                this.sslHandler.proceed();
            } else {
                this.sslHandler.cancel();
            }
            this.sslHandler = null;
        }
    }

    @DesignerProperty(defaultValue = "True", editorType = "boolean")
    @SimpleProperty(description = "Sets whether webview will prompt for permission and raise 'OnPermissionRequest' event or not else assume permission is granted.")
    public void PromptForPermission(boolean z) {
        boolean z2 = z;
        this.prompt = z2;
    }

    @SimpleProperty(description = "Returns whether webview will prompt for permission and raise 'OnPermissionRequest' event or not")
    public boolean PromptForPermission() {
        return this.prompt;
    }

    @SimpleFunction(description = "Reloads the current URL.")
    public void Reload() {
        CancelJsRequests();
        this.webView.reload();
    }

    @SimpleFunction(description = "Destroys the webview and removes it completely from view system")
    public void RemoveWebView(int i) {
        int i2 = i;
        if (this.wv.containsKey(Integer.valueOf(i2))) {
            WebView webView2 = this.wv.get(Integer.valueOf(i2));
            ((FrameLayout) webView2.getParent()).removeView(webView2);
            webView2.destroy();
            WebView remove = this.wv.remove(Integer.valueOf(i2));
            this.iD = 0;
        }
    }

    @SimpleFunction(description = "Restarts current/previous print job. You can request restart of a failed print job.")
    public void RestartPrinting() throws Exception {
        this.printJob.restart();
    }

    @SimpleFunction(description = "Whether to resubmit form or not.")
    public void ResubmitForm(boolean z) {
        boolean z2 = z;
        if (this.reSend != null && this.dontSend != null) {
            if (z2) {
                this.reSend.sendToTarget();
            } else {
                this.dontSend.sendToTarget();
            }
            this.reSend = null;
            this.dontSend = null;
        }
    }

    @SimpleFunction(description = "Resumes the previously paused WebView.")
    public void ResumeWebView(int i) {
        this.wv.get(Integer.valueOf(i)).onResume();
    }

    @SimpleProperty
    public float RotationAngle() {
        return this.webView.getRotation();
    }

    @SimpleProperty
    public void RotationAngle(float f) {
        this.webView.setRotation(f);
    }

    @SimpleFunction(description = "Saves the current site as a web archive")
    public void SaveArchive(String str) {
        ValueCallback valueCallback;
        new ValueCallback<String>(this) {
            final /* synthetic */ CustomWebView this$0;

            {
                this.this$0 = r5;
            }

            public void onReceiveValue(String str) {
                String str2 = str;
                if (str2 == null) {
                    this.this$0.AfterArchiveSaved(false, "");
                } else {
                    this.this$0.AfterArchiveSaved(true, str2);
                }
            }
        };
        this.webView.saveWebArchive(str, true, valueCallback);
    }

    @SimpleProperty(description = "Whether to display horizonatal and vertical scrollbars or not")
    public void ScrollBar(boolean z) {
        boolean z2 = z;
        this.webView.setVerticalScrollBarEnabled(z2);
        this.webView.setHorizontalScrollBarEnabled(z2);
    }

    @SimpleProperty(description = "")
    public int ScrollBarStyle() {
        return this.webView.getScrollBarStyle();
    }

    @SimpleProperty(description = "")
    public void ScrollBarStyle(int i) {
        this.webView.setScrollBarStyle(i);
    }

    @SimpleFunction(description = "Scrolls the webview to given position")
    public void ScrollTo(int i, int i2) {
        Runnable runnable;
        final int i3 = i;
        final int i4 = i2;
        new Runnable(this) {
            final /* synthetic */ CustomWebView this$0;

            {
                this.this$0 = r7;
            }

            public void run() {
                this.this$0.webView.scrollTo(this.this$0.p2d(i3), this.this$0.p2d(i4));
            }
        };
        boolean postDelayed = this.webView.postDelayed(runnable, 300);
    }

    @SimpleFunction(description = "Sets cookies for given url")
    public void SetCookies(String str, String str2) {
        try {
            CookieManager.getInstance().setCookie(str, str2);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SimpleFunction(description = "Sets the visibility of webview by id")
    public void SetVisibility(int i, boolean z) {
        int i2 = i;
        boolean z2 = z;
        if (!this.wv.containsKey(Integer.valueOf(i2))) {
            return;
        }
        if (z2) {
            this.wv.get(Integer.valueOf(i2)).setVisibility(0);
        } else {
            this.wv.get(Integer.valueOf(i2)).setVisibility(8);
        }
    }

    @SimpleFunction(description = "Set specific webview to current webview by id")
    public void SetWebView(int i) {
        int i2 = i;
        if (this.wv.containsKey(Integer.valueOf(i2))) {
            this.webView = this.wv.get(Integer.valueOf(i2));
            this.webView.setVisibility(0);
            this.iD = i2;
        }
    }

    @SimpleFunction(description = "Stops the current load.")
    public void StopLoading() {
        this.webView.stopLoading();
    }

    @SimpleProperty(description = "Sets whether the WebView supports multiple windows")
    public void SupportMultipleWindows(boolean z) {
        boolean z2 = z;
        this.webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(z2);
        this.webView.getSettings().setSupportMultipleWindows(z2);
    }

    @SimpleProperty(description = "Returns whether the WebView supports multiple windows")
    public boolean SupportMultipleWindows() {
        return this.webView.getSettings().getJavaScriptCanOpenWindowsAutomatically();
    }

    @SimpleFunction(description = "Uploads the given file from content uri.Use empty string to cancel the upload request.")
    public void UploadFile(String str) {
        String str2 = str;
        if (this.mFilePathCallback == null) {
            return;
        }
        if (str2.isEmpty()) {
            this.mFilePathCallback.onReceiveValue((Object) null);
            this.mFilePathCallback = null;
            return;
        }
        this.mFilePathCallback.onReceiveValue(new Uri[]{Uri.parse(str2)});
        this.mFilePathCallback = null;
    }

    @SimpleProperty(description = "Sets whether the WebView should enable support for the 'viewport' HTML meta tag or should use a wide viewport.")
    public void UseWideViewPort(boolean z) {
        this.webView.getSettings().setUseWideViewPort(z);
    }

    @SimpleProperty(description = "Returns whether the WebView should enable support for the 'viewport' HTML meta tag or should use a wide viewport.")
    public boolean UseWideViewPort() {
        return this.webView.getSettings().getUseWideViewPort();
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "Get webview user agent")
    public String UserAgent() {
        return this.UserAgent;
    }

    @SimpleProperty(description = "Sets the WebView's user-agent string. If the string is null or empty, the system default value will be used. ")
    public void UserAgent(String str) {
        String str2 = str;
        if (!str2.isEmpty()) {
            this.UserAgent = str2;
        } else {
            this.UserAgent = this.MOBILE_USER_AGENT;
        }
        this.webView.getSettings().setUserAgentString(this.UserAgent);
    }

    @SimpleProperty(description = "Whether or not to give the application permission to use the Javascript geolocation API")
    public void UsesLocation(boolean z) {
        this.webView.getSettings().setGeolocationEnabled(z);
    }

    @SimpleProperty(description = "Returns the visibility of current webview")
    public boolean Visible() {
        return this.webView.getVisibility() == 0;
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "Get webview string")
    public String WebViewString() {
        return this.wvInterface.webViewString;
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "Set webview string")
    public void WebViewString(String str) {
        this.wvInterface.setWebViewStringFromBlocks(str);
    }

    @SimpleEvent(description = "When the JavaScript calls AppInventor.setWebViewString this event is run.")
    public void WebViewStringChanged(String str) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "WebViewStringChanged", new Object[]{str});
    }

    @SimpleFunction(description = "Performs a zoom operation in the WebView by given zoom percent")
    public void ZoomBy(int i) {
        this.webView.zoomBy((float) i);
    }

    @DesignerProperty(defaultValue = "True", editorType = "boolean")
    @SimpleProperty(description = "Sets whether the WebView should support zooming using its on-screen zoom controls and gestures")
    public void ZoomEnabled(boolean z) {
        boolean z2 = z;
        this.zoomEnabled = z2;
    }

    @SimpleProperty(description = "Gets whether the WebView should support zooming using its on-screen zoom controls and gestures")
    public boolean ZoomEnabled() {
        return this.zoomEnabled;
    }

    @SimpleFunction(description = "Performs zoom in in the WebView")
    public void ZoomIn() {
        boolean zoomIn = this.webView.zoomIn();
    }

    @SimpleFunction(description = "Performs zoom out in the WebView")
    public void ZoomOut() {
        boolean zoomOut = this.webView.zoomOut();
    }

    @SimpleProperty(description = "Gets the zoom of the page in percent")
    public int ZoomPercent() {
        return this.zoomPercent;
    }

    @DesignerProperty(defaultValue = "100", editorType = "integer")
    @SimpleProperty(description = "Sets the zoom of the page in percent. The default is 100")
    public void ZoomPercent(int i) {
        int i2 = i;
        this.zoomPercent = i2;
    }

    public int d2p(int i) {
        return Math.round(((float) i) / this.deviceDensity);
    }

    public int getIndex(WebView webView2) {
        List list;
        ArrayList arrayList;
        new ArrayList(this.wv.values());
        List list2 = list;
        new ArrayList(this.wv.keySet());
        return ((Integer) arrayList.get(list2.indexOf(webView2))).intValue();
    }

    public int p2d(int i) {
        return Math.round(((float) i) * this.deviceDensity);
    }

    public void resetWebView(WebView webView2) {
        WebViewClient webViewClient;
        WebChromeClient webChromeClient;
        DownloadListener downloadListener;
        WebView.FindListener findListener;
        View.OnTouchListener onTouchListener;
        View.OnLongClickListener onLongClickListener;
        View.OnScrollChangeListener onScrollChangeListener;
        WebView webView3 = webView2;
        webView3.addJavascriptInterface(this.wvInterface, "AppInventor");
        this.MOBILE_USER_AGENT = webView3.getSettings().getUserAgentString();
        webView3.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.TEXT_AUTOSIZING);
        webView3.getSettings().setCacheMode(-1);
        webView3.setFocusable(true);
        new WebClient(this);
        webView3.setWebViewClient(webViewClient);
        new ChromeClient(this);
        webView3.setWebChromeClient(webChromeClient);
        webView3.getSettings().setJavaScriptEnabled(true);
        webView3.getSettings().setDisplayZoomControls(this.displayZoom);
        webView3.getSettings().setAllowFileAccess(false);
        webView3.getSettings().setAllowFileAccessFromFileURLs(false);
        webView3.getSettings().setAllowUniversalAccessFromFileURLs(false);
        webView3.getSettings().setAllowContentAccess(false);
        webView3.getSettings().setSupportZoom(this.zoomEnabled);
        webView3.getSettings().setBuiltInZoomControls(this.zoomEnabled);
        webView3.setLongClickable(false);
        webView3.getSettings().setTextZoom(this.zoomPercent);
        this.cookieManager.setAcceptThirdPartyCookies(webView3, true);
        webView3.getSettings().setDomStorageEnabled(true);
        webView3.setVerticalScrollBarEnabled(true);
        webView3.setHorizontalScrollBarEnabled(true);
        webView3.getSettings().setDefaultFontSize(16);
        webView3.getSettings().setBlockNetworkImage(false);
        webView3.getSettings().setLoadsImagesAutomatically(true);
        webView3.getSettings().setLoadWithOverviewMode(true);
        webView3.getSettings().setUseWideViewPort(true);
        webView3.getSettings().setBlockNetworkLoads(false);
        webView3.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView3.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webView3.getSettings().setSupportMultipleWindows(true);
        webView3.getSettings().setGeolocationDatabasePath((String) null);
        webView3.getSettings().setDatabaseEnabled(false);
        webView3.getSettings().setGeolocationEnabled(false);
        if (this.UserAgent.isEmpty()) {
            this.UserAgent = this.MOBILE_USER_AGENT;
        }
        webView3.getSettings().setUserAgentString(this.UserAgent);
        final WebView webView4 = webView3;
        new DownloadListener(this) {
            final /* synthetic */ CustomWebView this$0;

            {
                this.this$0 = r6;
            }

            public void onDownloadStart(String str, String str2, String str3, String str4, long j) {
                String str5 = str2;
                this.this$0.OnDownloadNeeded(this.this$0.getIndex(webView4), str, str3, str4, j);
            }
        };
        webView3.setDownloadListener(downloadListener);
        final WebView webView5 = webView3;
        new WebView.FindListener(this) {
            final /* synthetic */ CustomWebView this$0;

            {
                this.this$0 = r6;
            }

            public void onFindResultReceived(int i, int i2, boolean z) {
                this.this$0.FindResultReceived(this.this$0.getIndex(webView5), i, i2, z);
            }
        };
        webView3.setFindListener(findListener);
        new View.OnTouchListener(this) {
            final /* synthetic */ CustomWebView this$0;

            {
                this.this$0 = r5;
            }

            public boolean onTouch(View view, MotionEvent motionEvent) {
                View view2 = view;
                switch (motionEvent.getAction()) {
                    case 0:
                    case AndroidSetting.VERSION:
                        if (!view2.hasFocus()) {
                            boolean requestFocus = view2.requestFocus();
                            break;
                        }
                        break;
                }
                return false;
            }
        };
        webView3.setOnTouchListener(onTouchListener);
        final WebView webView6 = webView3;
        new View.OnLongClickListener(this) {
            final /* synthetic */ CustomWebView this$0;

            {
                this.this$0 = r6;
            }

            public boolean onLongClick(View view) {
                Handler handler;
                View view2 = view;
                WebView.HitTestResult hitTestResult = this.this$0.webView.getHitTestResult();
                String extra = hitTestResult.getExtra();
                int type = hitTestResult.getType();
                if (type == 0) {
                    return false;
                }
                if (extra == null) {
                    extra = "";
                }
                String str = "";
                if (type == 8) {
                    new Handler();
                    Message obtainMessage = handler.obtainMessage();
                    webView6.requestFocusNodeHref(obtainMessage);
                    str = (String) obtainMessage.getData().get("url");
                }
                this.this$0.LongClicked(this.this$0.getIndex(webView6), extra, str, type);
                return this.this$0.webView.isLongClickable();
            }
        };
        webView3.setOnLongClickListener(onLongClickListener);
        final WebView webView7 = webView3;
        new View.OnScrollChangeListener(this) {
            final /* synthetic */ CustomWebView this$0;

            {
                this.this$0 = r6;
            }

            public void onScrollChange(View view, int i, int i2, int i3, int i4) {
                View view2 = view;
                this.this$0.OnScrollChanged(this.this$0.getIndex(webView7), i, i2, i3, i4, webView7.canScrollHorizontally(-1), webView7.canScrollHorizontally(1));
            }
        };
        webView3.setOnScrollChangeListener(onScrollChangeListener);
    }
}
