package com.oseamiya.deviceinformation;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.RouteInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import androidx.annotation.RequiresApi;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.Reader;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class NetworkInformation {
    private static final String[] FACTORY_DNS_SERVERS;
    private static final String METHOD_EXEC_PROP_DELIM = "]: [";
    private static final String TAG = "NetworkInformation";
    private Context context;

    public NetworkInformation(Context context2) {
        this.context = context2;
    }

    @SuppressLint({"DefaultLocale"})
    public String getIpAddress(boolean z) {
        boolean useIPv4 = z;
        String finalAdress = "";
        try {
            for (NetworkInterface intf : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (InetAddress addr : Collections.list(intf.getInetAddresses())) {
                    if (!addr.isLoopbackAddress()) {
                        String sAddr = addr.getHostAddress();
                        boolean isIPv4 = sAddr.indexOf(58) < 0;
                        if (useIPv4) {
                            if (isIPv4) {
                                finalAdress = sAddr;
                            }
                        } else if (!isIPv4) {
                            int delim = sAddr.indexOf(37);
                            finalAdress = delim < 0 ? sAddr.toUpperCase() : sAddr.substring(0, delim);
                        }
                    }
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
            int ipAddress = ((WifiManager) this.context.getSystemService("wifi")).getConnectionInfo().getIpAddress();
            Object[] objArr = new Object[4];
            objArr[0] = Integer.valueOf(ipAddress & 255);
            Object[] objArr2 = objArr;
            objArr2[1] = Integer.valueOf((ipAddress >> 8) & 255);
            Object[] objArr3 = objArr2;
            objArr3[2] = Integer.valueOf((ipAddress >> 16) & 255);
            Object[] objArr4 = objArr3;
            objArr4[3] = Integer.valueOf((ipAddress >> 24) & 255);
            finalAdress = String.format("%d.%d.%d.%d", objArr4);
        }
        return finalAdress;
    }

    static {
        String[] strArr = new String[2];
        strArr[0] = "8.8.8.8";
        String[] strArr2 = strArr;
        strArr2[1] = "8.8.4.4";
        FACTORY_DNS_SERVERS = strArr2;
    }

    public String[] getServers() {
        String[] result = getServersMethodSystemProperties();
        if (result != null && result.length > 0) {
            return result;
        }
        String[] result2 = getServersMethodConnectivityManager();
        if (result2 != null && result2.length > 0) {
            return result2;
        }
        String[] result3 = getServersMethodExec();
        if (result3 == null || result3.length <= 0) {
            return FACTORY_DNS_SERVERS;
        }
        return result3;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v0, resolved type: java.util.Collection} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r14v50, resolved type: java.util.ArrayList} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.lang.String[] getServersMethodConnectivityManager() {
        /*
            r18 = this;
            r0 = r18
            int r14 = android.os.Build.VERSION.SDK_INT
            r15 = 21
            if (r14 < r15) goto L_0x00ce
            java.util.ArrayList r14 = new java.util.ArrayList     // Catch:{ Exception -> 0x00d1 }
            r17 = r14
            r14 = r17
            r15 = r17
            r15.<init>()     // Catch:{ Exception -> 0x00d1 }
            r1 = r14
            java.util.ArrayList r14 = new java.util.ArrayList     // Catch:{ Exception -> 0x00d1 }
            r17 = r14
            r14 = r17
            r15 = r17
            r15.<init>()     // Catch:{ Exception -> 0x00d1 }
            r2 = r14
            r14 = r0
            android.content.Context r14 = r14.context     // Catch:{ Exception -> 0x00d1 }
            java.lang.String r15 = "connectivity"
            java.lang.Object r14 = r14.getSystemService(r15)     // Catch:{ Exception -> 0x00d1 }
            android.net.ConnectivityManager r14 = (android.net.ConnectivityManager) r14     // Catch:{ Exception -> 0x00d1 }
            r3 = r14
            r14 = r3
            if (r14 == 0) goto L_0x00ae
            r14 = r3
            android.net.Network[] r14 = r14.getAllNetworks()     // Catch:{ Exception -> 0x00d1 }
            r4 = r14
            r14 = r4
            int r14 = r14.length     // Catch:{ Exception -> 0x00d1 }
            r5 = r14
            r14 = 0
            r6 = r14
        L_0x003b:
            r14 = r6
            r15 = r5
            if (r14 >= r15) goto L_0x00ae
            r14 = r4
            r15 = r6
            r14 = r14[r15]     // Catch:{ Exception -> 0x00d1 }
            r7 = r14
            r14 = r3
            r15 = r7
            android.net.NetworkInfo r14 = r14.getNetworkInfo(r15)     // Catch:{ Exception -> 0x00d1 }
            r8 = r14
            r14 = r8
            boolean r14 = r14.isConnected()     // Catch:{ Exception -> 0x00d1 }
            if (r14 == 0) goto L_0x0089
            r14 = r3
            r15 = r7
            android.net.LinkProperties r14 = r14.getLinkProperties(r15)     // Catch:{ Exception -> 0x00d1 }
            r9 = r14
            r14 = r9
            java.util.List r14 = r14.getDnsServers()     // Catch:{ Exception -> 0x00d1 }
            r10 = r14
            r14 = r0
            r15 = r9
            boolean r14 = r14.linkPropertiesHasDefaultRoute(r15)     // Catch:{ Exception -> 0x00d1 }
            if (r14 == 0) goto L_0x008c
            r14 = r10
            java.util.Iterator r14 = r14.iterator()     // Catch:{ Exception -> 0x00d1 }
            r11 = r14
        L_0x006d:
            r14 = r11
            boolean r14 = r14.hasNext()     // Catch:{ Exception -> 0x00d1 }
            if (r14 == 0) goto L_0x0089
            r14 = r11
            java.lang.Object r14 = r14.next()     // Catch:{ Exception -> 0x00d1 }
            java.net.InetAddress r14 = (java.net.InetAddress) r14     // Catch:{ Exception -> 0x00d1 }
            r12 = r14
            r14 = r12
            java.lang.String r14 = r14.getHostAddress()     // Catch:{ Exception -> 0x00d1 }
            r13 = r14
            r14 = r1
            r15 = r13
            boolean r14 = r14.add(r15)     // Catch:{ Exception -> 0x00d1 }
            goto L_0x006d
        L_0x0089:
            int r6 = r6 + 1
            goto L_0x003b
        L_0x008c:
            r14 = r10
            java.util.Iterator r14 = r14.iterator()     // Catch:{ Exception -> 0x00d1 }
            r11 = r14
        L_0x0092:
            r14 = r11
            boolean r14 = r14.hasNext()     // Catch:{ Exception -> 0x00d1 }
            if (r14 == 0) goto L_0x0089
            r14 = r11
            java.lang.Object r14 = r14.next()     // Catch:{ Exception -> 0x00d1 }
            java.net.InetAddress r14 = (java.net.InetAddress) r14     // Catch:{ Exception -> 0x00d1 }
            r12 = r14
            r14 = r12
            java.lang.String r14 = r14.getHostAddress()     // Catch:{ Exception -> 0x00d1 }
            r13 = r14
            r14 = r2
            r15 = r13
            boolean r14 = r14.add(r15)     // Catch:{ Exception -> 0x00d1 }
            goto L_0x0092
        L_0x00ae:
            r14 = r1
            boolean r14 = r14.isEmpty()     // Catch:{ Exception -> 0x00d1 }
            if (r14 == 0) goto L_0x00bb
            r14 = r1
            r15 = r2
            boolean r14 = r14.addAll(r15)     // Catch:{ Exception -> 0x00d1 }
        L_0x00bb:
            r14 = r1
            int r14 = r14.size()     // Catch:{ Exception -> 0x00d1 }
            if (r14 <= 0) goto L_0x00ce
            r14 = r1
            r15 = 0
            java.lang.String[] r15 = new java.lang.String[r15]     // Catch:{ Exception -> 0x00d1 }
            java.lang.Object[] r14 = r14.toArray(r15)     // Catch:{ Exception -> 0x00d1 }
            java.lang.String[] r14 = (java.lang.String[]) r14     // Catch:{ Exception -> 0x00d1 }
            r0 = r14
        L_0x00cd:
            return r0
        L_0x00ce:
            r14 = 0
            r0 = r14
            goto L_0x00cd
        L_0x00d1:
            r14 = move-exception
            r1 = r14
            java.lang.String r14 = "NetworkInformation"
            java.lang.String r15 = "Exception detecting DNS servers using ConnectivityManager method"
            r16 = r1
            int r14 = android.util.Log.d(r14, r15, r16)
            goto L_0x00ce
        */
        throw new UnsupportedOperationException("Method not decompiled: com.oseamiya.deviceinformation.NetworkInformation.getServersMethodConnectivityManager():java.lang.String[]");
    }

    private String[] getServersMethodSystemProperties() {
        ArrayList arrayList;
        if (Build.VERSION.SDK_INT < 26) {
            Object obj = "^\\d+(\\.\\d+){3}$";
            Object obj2 = "^[0-9a-f]+(:[0-9a-f]*)+:[0-9a-f]+$";
            new ArrayList();
            ArrayList arrayList2 = arrayList;
            try {
                Method method = Class.forName("android.os.SystemProperties").getMethod("get", new Class[]{String.class});
                String[] strArr = new String[4];
                strArr[0] = "net.dns1";
                String[] strArr2 = strArr;
                strArr2[1] = "net.dns2";
                String[] strArr3 = strArr2;
                strArr3[2] = "net.dns3";
                String[] strArr4 = strArr3;
                strArr4[3] = "net.dns4";
                String[] netdns = strArr4;
                for (int i = 0; i < netdns.length; i++) {
                    String v = (String) method.invoke((Object) null, new Object[]{netdns[i]});
                    if (v != null && ((v.matches("^\\d+(\\.\\d+){3}$") || v.matches("^[0-9a-f]+(:[0-9a-f]*)+:[0-9a-f]+$")) && !arrayList2.contains(v))) {
                        boolean add = arrayList2.add(v);
                    }
                }
                if (arrayList2.size() > 0) {
                    return (String[]) arrayList2.toArray(new String[0]);
                }
            } catch (Exception e) {
                int d = Log.d(TAG, "Exception detecting DNS servers using SystemProperties method", e);
            }
        }
        return null;
    }

    private String[] getServersMethodExec() {
        BufferedReader bufferedReader;
        Reader reader;
        if (Build.VERSION.SDK_INT >= 16) {
            try {
                new InputStreamReader(Runtime.getRuntime().exec("getprop").getInputStream());
                new LineNumberReader(reader);
                Set<String> serversSet = methodExecParseProps(bufferedReader);
                if (serversSet != null && serversSet.size() > 0) {
                    return (String[]) serversSet.toArray(new String[0]);
                }
            } catch (Exception e) {
                int d = Log.d(TAG, "Exception in getServersMethodExec", e);
            }
        }
        return null;
    }

    private Set<String> methodExecParseProps(BufferedReader bufferedReader) throws Exception {
        Set<String> set;
        InetAddress ip;
        String value;
        StringBuilder sb;
        BufferedReader lineNumberReader = bufferedReader;
        new HashSet(10);
        Set<String> serversSet = set;
        while (true) {
            String readLine = lineNumberReader.readLine();
            String line = readLine;
            if (readLine == null) {
                return serversSet;
            }
            int split = line.indexOf(METHOD_EXEC_PROP_DELIM);
            if (split != -1) {
                String property = line.substring(1, split);
                int valueStart = split + METHOD_EXEC_PROP_DELIM.length();
                int valueEnd = line.length() - 1;
                if (valueEnd < valueStart) {
                    new StringBuilder();
                    int d = Log.d(TAG, sb.append("Malformed property detected: \"").append(line).append('\"').toString());
                } else {
                    String value2 = line.substring(valueStart, valueEnd);
                    if (!value2.isEmpty() && !((!property.endsWith(".dns") && !property.endsWith(".dns1") && !property.endsWith(".dns2") && !property.endsWith(".dns3") && !property.endsWith(".dns4")) || (ip = InetAddress.getByName(value2)) == null || (value = ip.getHostAddress()) == null || value.length() == 0)) {
                        boolean add = serversSet.add(value);
                    }
                }
            }
        }
    }

    @TargetApi(21)
    private boolean linkPropertiesHasDefaultRoute(LinkProperties linkProperties) {
        for (RouteInfo route : linkProperties.getRoutes()) {
            if (route.isDefaultRoute()) {
                return true;
            }
        }
        return false;
    }

    public boolean isADBDebuggingEnabled() {
        return Settings.Secure.getInt(this.context.getContentResolver(), "adb_enabled", 0) > 0;
    }

    @RequiresApi(api = 23)
    public boolean isVpnConnection() {
        return Settings.Secure.getInt(this.context.getContentResolver(), "vpn_state", 0) == 1 || isvpn1() || isvpn2();
    }

    /* JADX WARNING: Removed duplicated region for block: B:5:0x0019 A[Catch:{ SocketException -> 0x0072 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean isvpn1() {
        /*
            r8 = this;
            r0 = r8
            java.lang.String r4 = ""
            r1 = r4
            java.util.Enumeration r4 = java.net.NetworkInterface.getNetworkInterfaces()     // Catch:{ SocketException -> 0x0072 }
            java.util.ArrayList r4 = java.util.Collections.list(r4)     // Catch:{ SocketException -> 0x0072 }
            java.util.Iterator r4 = r4.iterator()     // Catch:{ SocketException -> 0x0072 }
            r2 = r4
        L_0x0012:
            r4 = r2
            boolean r4 = r4.hasNext()     // Catch:{ SocketException -> 0x0072 }
            if (r4 == 0) goto L_0x006f
            r4 = r2
            java.lang.Object r4 = r4.next()     // Catch:{ SocketException -> 0x0072 }
            java.net.NetworkInterface r4 = (java.net.NetworkInterface) r4     // Catch:{ SocketException -> 0x0072 }
            r3 = r4
            r4 = r3
            boolean r4 = r4.isUp()     // Catch:{ SocketException -> 0x0072 }
            if (r4 == 0) goto L_0x002e
            r4 = r3
            java.lang.String r4 = r4.getName()     // Catch:{ SocketException -> 0x0072 }
            r1 = r4
        L_0x002e:
            java.lang.String r4 = "DEBUG"
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ SocketException -> 0x0072 }
            r7 = r5
            r5 = r7
            r6 = r7
            r6.<init>()     // Catch:{ SocketException -> 0x0072 }
            java.lang.String r6 = "IFACE NAME: "
            java.lang.StringBuilder r5 = r5.append(r6)     // Catch:{ SocketException -> 0x0072 }
            r6 = r1
            java.lang.StringBuilder r5 = r5.append(r6)     // Catch:{ SocketException -> 0x0072 }
            java.lang.String r5 = r5.toString()     // Catch:{ SocketException -> 0x0072 }
            int r4 = android.util.Log.d(r4, r5)     // Catch:{ SocketException -> 0x0072 }
            r4 = r1
            java.lang.String r5 = "tun"
            boolean r4 = r4.contains(r5)     // Catch:{ SocketException -> 0x0072 }
            if (r4 != 0) goto L_0x006b
            r4 = r1
            java.lang.String r5 = "ppp"
            boolean r4 = r4.contains(r5)     // Catch:{ SocketException -> 0x0072 }
            if (r4 != 0) goto L_0x006b
            r4 = r1
            java.lang.String r5 = "pptp"
            boolean r4 = r4.contains(r5)     // Catch:{ SocketException -> 0x0072 }
            if (r4 == 0) goto L_0x006e
        L_0x006b:
            r4 = 1
            r0 = r4
        L_0x006d:
            return r0
        L_0x006e:
            goto L_0x0012
        L_0x006f:
            r4 = 0
            r0 = r4
            goto L_0x006d
        L_0x0072:
            r4 = move-exception
            r2 = r4
            r4 = r2
            r4.printStackTrace()
            goto L_0x006f
        */
        throw new UnsupportedOperationException("Method not decompiled: com.oseamiya.deviceinformation.NetworkInformation.isvpn1():boolean");
    }

    @RequiresApi(api = 23)
    private boolean isvpn2() {
        ConnectivityManager cm = (ConnectivityManager) this.context.getSystemService("connectivity");
        return cm.getNetworkCapabilities(cm.getActiveNetwork()).hasTransport(4);
    }
}
