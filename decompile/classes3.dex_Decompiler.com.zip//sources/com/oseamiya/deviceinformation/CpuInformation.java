package com.oseamiya.deviceinformation;

import android.app.ActivityManager;
import android.content.Context;
import android.opengl.GLSurfaceView;
import android.os.Build;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.MatchResult;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class CpuInformation implements GLSurfaceView.Renderer {
    private final Context context;
    private final HashMap<String, String> hashMap;

    public CpuInformation(Context context2) {
        HashMap<String, String> hashMap2;
        new HashMap<>();
        this.hashMap = hashMap2;
        this.context = context2;
    }

    public int getNumberOfCores() {
        return Runtime.getRuntime().availableProcessors();
    }

    public static String[] getSupportedABIs() {
        return Build.SUPPORTED_ABIS;
    }

    public static int getMinimumFrequency() {
        return readSystemFileAsInt("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq");
    }

    public static int getMaximumFrequency() {
        return readSystemFileAsInt("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq");
    }

    public static float getBogoMips() throws Exception {
        Throwable th;
        Throwable th2;
        MatchResult matchResult = matchSystemFile("/proc/cpuinfo", "BogoMIPS[\\s]*:[\\s]*(\\d+\\.\\d+)[\\s]*\n", 1000);
        try {
            if (matchResult.groupCount() > 0) {
                return Float.parseFloat(matchResult.group(1));
            }
            Throwable th3 = th2;
            new Exception();
            throw th3;
        } catch (NumberFormatException e) {
            NumberFormatException e2 = e;
            Throwable th4 = th;
            new Exception(e2);
            throw th4;
        }
    }

    public static int getClockSpeed() {
        return readSystemFileAsInt("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq");
    }

    public static boolean is64Bit() {
        return Build.SUPPORTED_64_BIT_ABIS.length > 0;
    }

    public static int getMinScalingFrequency() {
        return readSystemFileAsInt("/sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq");
    }

    public static int getMaxScalingFrequency() {
        return readSystemFileAsInt("/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq");
    }

    public String getGPURenderer() {
        getGPUInformation();
        return this.hashMap.get("RENDERER");
    }

    public String getGPUVendor() {
        getGPUInformation();
        return this.hashMap.get("VENDOR");
    }

    public String getGPUExtensions() {
        getGPUInformation();
        return this.hashMap.get("EXTENSIONS");
    }

    public String getGPUVersion() {
        getGPUInformation();
        return this.hashMap.get("VERSION");
    }

    public boolean isGPUSupported() {
        return ((ActivityManager) this.context.getSystemService("activity")).getDeviceConfigurationInfo().reqGlEsVersion >= 131072;
    }

    public String getCpuInformation() {
        StringBuilder sb;
        ProcessBuilder processBuilder;
        String str;
        String[] strArr = new String[2];
        strArr[0] = "/system/bin/cat";
        String[] DATA = strArr;
        DATA[1] = "/proc/cpuinfo";
        new StringBuilder();
        StringBuilder Holder = sb;
        new ProcessBuilder(DATA);
        byte[] byteArray = new byte[1024];
        try {
            InputStream inputStream = processBuilder.start().getInputStream();
            while (inputStream.read(byteArray) != -1) {
                new String(byteArray);
                StringBuilder append = Holder.append(str);
            }
            inputStream.close();
            return Holder.toString();
        } catch (IOException e) {
            e.printStackTrace();
            return "Exception Occurred";
        }
    }

    private static int readSystemFileAsInt(String str) {
        ProcessBuilder processBuilder;
        String systemFile = str;
        try {
            ProcessBuilder processBuilder2 = processBuilder;
            String[] strArr = new String[2];
            strArr[0] = "/system/bin/cat";
            String[] strArr2 = strArr;
            strArr2[1] = systemFile;
            new ProcessBuilder(strArr2);
            return Integer.parseInt(readFully(processBuilder2.start().getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static final String readFully(InputStream pInputStream) throws IOException {
        StringBuilder sb;
        Scanner scanner;
        new StringBuilder();
        StringBuilder sb2 = sb;
        new Scanner(pInputStream);
        Scanner sc = scanner;
        while (sc.hasNextLine()) {
            StringBuilder append = sb2.append(sc.nextLine());
        }
        return sb2.toString();
    }

    private static MatchResult matchSystemFile(String str, String str2, int i) throws Exception {
        Throwable th;
        ProcessBuilder processBuilder;
        Scanner scanner;
        Throwable th2;
        String systemFile = str;
        String pattern = str2;
        int horizon = i;
        try {
            ProcessBuilder processBuilder2 = processBuilder;
            String[] strArr = new String[2];
            strArr[0] = "/system/bin/cat";
            String[] strArr2 = strArr;
            strArr2[1] = systemFile;
            new ProcessBuilder(strArr2);
            new Scanner(processBuilder2.start().getInputStream());
            Scanner scanner2 = scanner;
            if (scanner2.findWithinHorizon(pattern, horizon) != null) {
                return scanner2.match();
            }
            Throwable th3 = th2;
            new Exception();
            throw th3;
        } catch (IOException e) {
            IOException e2 = e;
            Throwable th4 = th;
            new Exception(e2);
            throw th4;
        }
    }

    public void onSurfaceCreated(GL10 gl10, EGLConfig eGLConfig) {
        GL10 gl = gl10;
        EGLConfig eGLConfig2 = eGLConfig;
        this.hashMap.clear();
        String put = this.hashMap.put("RENDERER", gl.glGetString(7937));
        String put2 = this.hashMap.put("VENDOR", gl.glGetString(7936));
        String put3 = this.hashMap.put("VERSION", gl.glGetString(7938));
        String put4 = this.hashMap.put("EXTENSIONS", gl.glGetString(7939));
    }

    public void onSurfaceChanged(GL10 gl, int width, int height) {
    }

    public void onDrawFrame(GL10 gl) {
    }

    private void getGPUInformation() {
        GLSurfaceView glSurfaceView;
        boolean z = ((ActivityManager) this.context.getSystemService("activity")).getDeviceConfigurationInfo().reqGlEsVersion >= 131072;
        new GLSurfaceView(this.context);
        glSurfaceView.setRenderer(this);
    }
}
