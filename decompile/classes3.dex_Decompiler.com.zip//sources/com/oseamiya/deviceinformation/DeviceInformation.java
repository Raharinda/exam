package com.oseamiya.deviceinformation;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import androidx.annotation.RequiresApi;
import androidx.annotation.RequiresPermission;
import java.io.File;

public class DeviceInformation {
    private final Context context;

    public DeviceInformation(Context context2) {
        this.context = context2;
    }

    public String getModelName() {
        return Build.MODEL;
    }

    public String getDeviceName() {
        String manafacture = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.startsWith(manafacture)) {
            return capitalize(model);
        }
        return capitalize(manafacture);
    }

    public String getManafacturerName() {
        return Build.MANUFACTURER;
    }

    public String getBoardName() {
        return Build.BOARD;
    }

    public String getHardwareName() {
        return Build.HARDWARE;
    }

    public String getBrandName() {
        return Build.BRAND;
    }

    @SuppressLint({"HardwareIds"})
    public String getDeviceId() {
        return Settings.Secure.getString(this.context.getContentResolver(), "android_id");
    }

    public String getBuildFingerPrint() {
        return Build.FINGERPRINT;
    }

    public String getDeviceType() {
        int phoneType = ((TelephonyManager) this.context.getSystemService("phone")).getPhoneType();
        if (phoneType == 2) {
            return "CDMA";
        }
        if (phoneType == 1) {
            return "GSM";
        }
        if (phoneType == 3) {
            return "SIP";
        }
        return "";
    }

    public boolean isUsbHostSupported() {
        return this.context.getPackageManager().hasSystemFeature("android.hardware.usb.host");
    }

    public int getNumberOfSimSlot() {
        if (Build.VERSION.SDK_INT >= 22) {
            return SubscriptionManager.from(this.context).getActiveSubscriptionInfoCountMax();
        }
        return 1;
    }

    @RequiresApi(api = 23)
    @SuppressLint({"MissingPermission", "HardwareIds"})
    @RequiresPermission("android.permission.READ_PHONE_STATE")
    @Deprecated
    public String getImei(int i) {
        int slotNumber = i;
        if (Build.VERSION.SDK_INT < 23) {
            return ((TelephonyManager) this.context.getSystemService("phone")).getDeviceId(slotNumber);
        }
        return getDeviceId();
    }

    public long getBuildTime() {
        return Build.TIME;
    }

    public String getProductName() {
        return Build.PRODUCT;
    }

    public String getCodeName() {
        return Build.VERSION.CODENAME;
    }

    public String getRadioVersion() {
        return Build.getRadioVersion();
    }

    public String getDisplayVersion() {
        return Build.DISPLAY;
    }

    public String getHost() {
        return Build.HOST;
    }

    public String getBuildUser() {
        return Build.USER;
    }

    public String getSerial() {
        return Build.SERIAL;
    }

    public boolean isRooted() {
        File file;
        StringBuilder sb;
        String[] strArr = new String[8];
        strArr[0] = "/sbin";
        String[] strArr2 = strArr;
        strArr2[1] = "/system/bin";
        String[] strArr3 = strArr2;
        strArr3[2] = "/system/xbin/";
        String[] strArr4 = strArr3;
        strArr4[3] = "/system/sd/xbin";
        String[] strArr5 = strArr4;
        strArr5[4] = "/system/bin/failsafe/";
        String[] strArr6 = strArr5;
        strArr6[5] = "/data/local/xbin/";
        String[] strArr7 = strArr6;
        strArr7[6] = "/data/local/bin/";
        String[] locations = strArr7;
        locations[7] = "/data/local/";
        String[] strArr8 = locations;
        int length = strArr8.length;
        for (int i = 0; i < length; i++) {
            String location = strArr8[i];
            new StringBuilder();
            new File(sb.append(location).append("su").toString());
            if (file.exists()) {
                return true;
            }
        }
        return false;
    }

    private String capitalize(String str) {
        StringBuilder sb;
        String s = str;
        if (TextUtils.isEmpty(s)) {
            return s;
        }
        boolean capitalizeNext = true;
        String phrase = "";
        char[] charArray = s.toCharArray();
        int length = charArray.length;
        for (int i = 0; i < length; i++) {
            char c = charArray[i];
            if (!capitalizeNext || !Character.isLetter(c)) {
                if (Character.isWhitespace(c)) {
                    capitalizeNext = true;
                }
                new StringBuilder();
                phrase = sb.append(phrase).append(c).toString();
            } else {
                capitalizeNext = false;
            }
        }
        return phrase;
    }
}
