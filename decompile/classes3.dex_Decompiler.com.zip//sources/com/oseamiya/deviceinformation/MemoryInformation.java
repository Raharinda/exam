package com.oseamiya.deviceinformation;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Environment;
import android.os.StatFs;

public class MemoryInformation {
    private Context context;

    public MemoryInformation() {
    }

    public void MemoryInformation(Context context2) {
        Context context3 = context2;
        this.context = context3;
    }

    public long getTotalRam() {
        return memoryInfo().totalMem;
    }

    public long getAvailableRam() {
        return memoryInfo().availMem;
    }

    public long getUsedRam() {
        return getTotalRam() - getAvailableRam();
    }

    public boolean isExternalMemoryAvailable() {
        return Environment.getExternalStorageState().equals("mounted");
    }

    public long getAvailableInternalMemorySize() {
        StatFs statFs;
        new StatFs(Environment.getDataDirectory().getPath());
        StatFs statFs2 = statFs;
        return statFs2.getAvailableBlocksLong() * statFs2.getBlockSizeLong();
    }

    public long getTotalInternalMemorySize() {
        StatFs statFs;
        new StatFs(Environment.getDataDirectory().getPath());
        StatFs statFs2 = statFs;
        return statFs2.getBlockSizeLong() * statFs2.getBlockCountLong();
    }

    public long getUsedInternalMemorySize() {
        if (getTotalInternalMemorySize() > getAvailableInternalMemorySize()) {
            return getTotalInternalMemorySize() - getAvailableInternalMemorySize();
        }
        return -11111111;
    }

    public long getTotalExternalStorageSize() {
        StatFs statFs;
        if (!isExternalMemoryAvailable()) {
            return -1111111111;
        }
        new StatFs(Environment.getExternalStorageDirectory().getPath());
        StatFs statFs2 = statFs;
        return statFs2.getBlockSizeLong() * statFs2.getBlockCountLong();
    }

    public long getAvailableExternalStorageSize() {
        StatFs statFs;
        if (!isExternalMemoryAvailable()) {
            return -1111111111;
        }
        new StatFs(Environment.getExternalStorageDirectory().getPath());
        StatFs statFs2 = statFs;
        return statFs2.getBlockSizeLong() * statFs2.getAvailableBlocksLong();
    }

    public long getUsedExternalStorageSize() {
        if (!isExternalMemoryAvailable()) {
            return -1111111111;
        }
        if (getTotalExternalStorageSize() > getAvailableExternalStorageSize()) {
            return getTotalExternalStorageSize() - getAvailableExternalStorageSize();
        }
        return -1111111111;
    }

    private ActivityManager.MemoryInfo memoryInfo() {
        ActivityManager.MemoryInfo memoryInfo;
        ActivityManager activityManager = (ActivityManager) this.context.getSystemService("activity");
        new ActivityManager.MemoryInfo();
        ActivityManager.MemoryInfo memoryInfo2 = memoryInfo;
        activityManager.getMemoryInfo(memoryInfo2);
        return memoryInfo2;
    }
}
