package com.oseamiya.deviceinformation;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import androidx.annotation.RequiresApi;
import com.chstudio.extensions.AndroidSetting.AndroidSetting;
import com.puravidaapps.TaifunPM;

public class DisplayInformation {
    private Context context;

    public DisplayInformation(Context context2) {
        this.context = context2;
    }

    public int getDisplayHeight() {
        return this.context.getResources().getDisplayMetrics().heightPixels + getNavigationBarHeight();
    }

    public int getDisplayWidth() {
        return this.context.getResources().getDisplayMetrics().widthPixels;
    }

    public int getNavigationBarHeight() {
        DisplayMetrics displayMetrics;
        if (Build.VERSION.SDK_INT < 17) {
            return 0;
        }
        new DisplayMetrics();
        DisplayMetrics metrics = displayMetrics;
        WindowManager windowManager = (WindowManager) this.context.getSystemService("window");
        windowManager.getDefaultDisplay().getMetrics(metrics);
        int usableHeight = metrics.heightPixels;
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        int realHeight = metrics.heightPixels;
        if (realHeight > usableHeight) {
            return realHeight - usableHeight;
        }
        return 0;
    }

    public double getPhysicalSize() {
        DisplayMetrics displayMetrics;
        new DisplayMetrics();
        DisplayMetrics dm = displayMetrics;
        ((WindowManager) this.context.getSystemService("window")).getDefaultDisplay().getMetrics(dm);
        return Math.sqrt(Math.pow((double) (((float) getDisplayWidth()) / dm.xdpi), 2.0d) + Math.pow((double) (((float) getDisplayHeight()) / dm.ydpi), 2.0d));
    }

    public float getFontScale() {
        return this.context.getResources().getConfiguration().fontScale;
    }

    public float getRefreshRate() {
        return ((WindowManager) this.context.getSystemService("window")).getDefaultDisplay().getRefreshRate();
    }

    public int getOrientation() {
        return this.context.getResources().getConfiguration().orientation;
    }

    public int getRotation() {
        int angle;
        switch (((WindowManager) this.context.getSystemService("window")).getDefaultDisplay().getRotation()) {
            case AndroidSetting.VERSION:
                angle = 90;
                break;
            case TaifunPM.VERSION /*2*/:
                angle = 180;
                break;
            case 3:
                angle = 270;
                break;
            default:
                angle = 0;
                break;
        }
        return angle;
    }

    @RequiresApi(api = 26)
    public boolean isHdrCapable() {
        Object obj;
        new Configuration();
        Object obj2 = obj;
        return this.context.getResources().getConfiguration().isScreenHdr();
    }

    @RequiresApi(api = 30)
    public boolean isNightModeActive() {
        Object obj;
        new Configuration();
        Object obj2 = obj;
        return this.context.getResources().getConfiguration().isNightModeActive();
    }

    @RequiresApi(api = 23)
    public boolean isScreenRound() {
        Object obj;
        new Configuration();
        Object obj2 = obj;
        return this.context.getResources().getConfiguration().isScreenRound();
    }

    @RequiresApi(api = 26)
    public boolean isScreenWideColorGamut() {
        Object obj;
        new Configuration();
        Object obj2 = obj;
        return this.context.getResources().getConfiguration().isScreenWideColorGamut();
    }

    public boolean isBrightnessAutoMode() {
        try {
            if (Settings.System.getInt(this.context.getContentResolver(), "screen_brightness_mode") == 1) {
                return true;
            }
            return false;
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getBrightnessLevel() {
        ContentResolver contentResolver = this.context.getContentResolver();
        int a = 0;
        int mode = 0;
        try {
            mode = Settings.System.getInt(contentResolver, "screen_brightness_mode");
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
        if (mode == 1) {
            a = 1;
            boolean putInt = Settings.System.putInt(contentResolver, "screen_brightness_mode", 0);
        }
        int brightnessLevel = Settings.System.getInt(contentResolver, "screen_brightness", 125);
        if (a == 1) {
            boolean putInt2 = Settings.System.putInt(contentResolver, "screen_brightness_mode", 1);
        }
        return brightnessLevel;
    }

    public void triggerBrightnessMode() {
        ContentResolver contentResolver = this.context.getContentResolver();
        try {
            if (Settings.System.getInt(contentResolver, "screen_brightness_mode") == 1) {
                boolean putInt = Settings.System.putInt(contentResolver, "screen_brightness_mode", 0);
            } else {
                boolean putInt2 = Settings.System.putInt(contentResolver, "screen_brightness_mode", 1);
            }
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
    }

    public int getScreenTimeout() {
        try {
            return Settings.System.getInt(this.context.getContentResolver(), "screen_off_timeout");
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
            return 0;
        }
    }
}
