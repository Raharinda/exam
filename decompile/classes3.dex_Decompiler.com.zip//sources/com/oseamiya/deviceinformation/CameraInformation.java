package com.oseamiya.deviceinformation;

import android.content.Context;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;

public class CameraInformation {
    static final /* synthetic */ boolean $assertionsDisabled = (!CameraInformation.class.desiredAssertionStatus());
    private final Context context;

    public CameraInformation(Context context2) {
        this.context = context2;
    }

    public boolean isCameraAvailable() {
        return this.context.getPackageManager().hasSystemFeature("android.hardware.camera.any");
    }

    public boolean isFlashAvailable() {
        return this.context.getPackageManager().hasSystemFeature("android.hardware.camera.flash");
    }

    public String[] getCameraIds() {
        try {
            return ((CameraManager) this.context.getSystemService("camera")).getCameraIdList();
        } catch (CameraAccessException e) {
            e.printStackTrace();
            return null;
        }
    }

    public int getNumberOfCameras() {
        return getCameraIds().length;
    }

    public int[] getAntibandingModes(String cameraId) {
        return getCharacteristics(cameraId, CameraCharacteristics.CONTROL_AE_AVAILABLE_ANTIBANDING_MODES);
    }

    public int[] getAberrationModes(String cameraId) {
        return getCharacteristics(cameraId, CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES);
    }

    public int[] getAutoExposureModes(String cameraId) {
        return getCharacteristics(cameraId, CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES);
    }

    public int[] getAutoFocusModes(String cameraId) {
        return getCharacteristics(cameraId, CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES);
    }

    public int[] getEffects(String cameraId) {
        return getCharacteristics(cameraId, CameraCharacteristics.CONTROL_AVAILABLE_EFFECTS);
    }

    public int[] getWhiteBalanceModes(String cameraId) {
        return getCharacteristics(cameraId, CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES);
    }

    public int[] getVideoStabilizationModes(String cameraId) {
        return getCharacteristics(cameraId, CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES);
    }

    public int getMaximumAutoFocusRegions(String cameraId) {
        return getMaximumRegions(cameraId, CameraCharacteristics.CONTROL_MAX_REGIONS_AF);
    }

    public int getMaximumAutoExposureRegions(String cameraId) {
        return getMaximumRegions(cameraId, CameraCharacteristics.CONTROL_MAX_REGIONS_AE);
    }

    public int getMaximumAutoWhiteBalanceRegions(String cameraId) {
        return getMaximumRegions(cameraId, CameraCharacteristics.CONTROL_MAX_REGIONS_AWB);
    }

    private int getMaximumRegions(String cameraId, CameraCharacteristics.Key<Integer> key) {
        Throwable th;
        CameraCharacteristics.Key<Integer> characterSpecific = key;
        CameraCharacteristics characteristics = null;
        try {
            characteristics = ((CameraManager) this.context.getSystemService("camera")).getCameraCharacteristics(cameraId);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
        if ($assertionsDisabled || characteristics != null) {
            return ((Integer) characteristics.get(characterSpecific)).intValue();
        }
        Throwable th2 = th;
        new AssertionError();
        throw th2;
    }

    private int[] getCharacteristics(String cameraId, CameraCharacteristics.Key<int[]> key) {
        CameraCharacteristics.Key<int[]> characterSpecificKey = key;
        CameraCharacteristics characteristics = null;
        try {
            characteristics = ((CameraManager) this.context.getSystemService("camera")).getCameraCharacteristics(cameraId);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
        return (int[]) characteristics.get(characterSpecificKey);
    }
}
