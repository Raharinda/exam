package com.oseamiya.deviceinformation;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import com.chstudio.extensions.AndroidSetting.AndroidSetting;
import com.puravidaapps.TaifunPM;

public class BatteryInformation {
    private final Context context;

    public BatteryInformation(Context context2) {
        this.context = context2;
    }

    private Intent getBatteryStatus() {
        IntentFilter filter;
        new IntentFilter("android.intent.action.BATTERY_CHANGED");
        return this.context.registerReceiver((BroadcastReceiver) null, filter);
    }

    public final int getPercentage() {
        Intent status = getBatteryStatus();
        int batteryPercentage = 0;
        if (status != null) {
            batteryPercentage = (int) ((((float) status.getIntExtra("level", -1)) / ((float) status.getIntExtra("scale", -1))) * 100.0f);
        }
        return batteryPercentage;
    }

    public boolean isCharging() {
        int plugged = getBatteryStatus().getIntExtra("plugged", -1);
        boolean isCharging = plugged == 1 || plugged == 2;
        if (Build.VERSION.SDK_INT > 16) {
            isCharging = isCharging || plugged == 4;
        }
        return isCharging;
    }

    public final int getHealth() {
        Intent intent = getBatteryStatus();
        int health = 0;
        if (intent != null) {
            health = intent.getIntExtra("health", 0);
        }
        return health;
    }

    public String getTechnology() {
        return getBatteryStatus().getStringExtra("technology");
    }

    public float getBatteryTemperature() {
        float temperature = 0.0f;
        Intent intent = getBatteryStatus();
        if (intent != null) {
            temperature = (float) (intent.getIntExtra("temperature", 0) / 10);
        }
        return temperature;
    }

    public int getBatteryVoltage() {
        int voltage = 0;
        Intent intent = getBatteryStatus();
        if (intent != null) {
            voltage = intent.getIntExtra("voltage", 0);
        }
        return voltage;
    }

    public boolean isBatteryAvailable() {
        return getBatteryStatus().getExtras() != null && getBatteryStatus().getExtras().getBoolean("present");
    }

    public String getChargingSource() {
        switch (getBatteryStatus().getIntExtra("plugged", 0)) {
            case AndroidSetting.VERSION:
                return "AC";
            case TaifunPM.VERSION /*2*/:
                return "USB";
            case 4:
                return "WIRELESS";
            default:
                return "UNKNOWN";
        }
    }

    @SuppressLint({"PrivateApi"})
    public double getBatteryCapacity() {
        double batteryCapacity = 0.0d;
        Object obj = "com.android.internal.os.PowerProfile";
        try {
            batteryCapacity = ((Double) Class.forName("com.android.internal.os.PowerProfile").getMethod("getBatteryCapacity", new Class[0]).invoke(Class.forName("com.android.internal.os.PowerProfile").getConstructor(new Class[]{Context.class}).newInstance(new Object[]{this.context}), new Object[0])).doubleValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return batteryCapacity;
    }
}
