package com.oseamiya.deviceinformation;

import android.app.Activity;
import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.provider.Settings;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import java.io.IOException;
import java.util.Locale;

@RequiresApi(api = 23)
public class LocationInformation {
    private final Context context;

    public LocationInformation(Context context2) {
        this.context = context2;
    }

    public Location getLocation() {
        LocationManager locationManager = (LocationManager) this.context.getSystemService("location");
        if (!(ActivityCompat.checkSelfPermission(this.context, "android.permission.ACCESS_FINE_LOCATION") == 0 || ActivityCompat.checkSelfPermission(this.context, "android.permission.ACCESS_COARSE_LOCATION") == 0)) {
            String[] strArr = new String[2];
            strArr[0] = "android.permission.ACCESS_FINE_LOCATION";
            String[] strArr2 = strArr;
            strArr2[1] = "android.permission.ACCESS_COARSE_LOCATION";
            ActivityCompat.requestPermissions((Activity) this.context, strArr2, 1);
        }
        Location location = locationManager.getLastKnownLocation("gps");
        if (location == null) {
            location = locationManager.getLastKnownLocation("network");
        } else if (location == null) {
            location = locationManager.getLastKnownLocation("passive");
        }
        return location;
    }

    public double getCurrentLatitude() {
        if (getLocation() == null) {
            return 0.0d;
        }
        return getLocation().getLatitude();
    }

    public double getCurrentLongitude() {
        if (getLocation() == null) {
            return 0.0d;
        }
        return getLocation().getLongitude();
    }

    public boolean IsLocationServicesEnabled() {
        if (Build.VERSION.SDK_INT >= 28) {
            return ((LocationManager) this.context.getSystemService("location")).isLocationEnabled();
        }
        return Settings.Secure.getInt(this.context.getContentResolver(), "location_mode", 0) != 0;
    }

    public String getStreetAddress(double latitude, double longitude) {
        return getStringAddress(latitude, longitude, 1);
    }

    public String getCity(double latitude, double longitude) {
        return getStringAddress(latitude, longitude, 2);
    }

    public String getCountryName(double latitude, double longitude) {
        return getStringAddress(latitude, longitude, 3);
    }

    public String getPostalCode(double latitude, double longitude) {
        return getStringAddress(latitude, longitude, 4);
    }

    private String getStringAddress(double latitude, double longitude, int i) {
        Geocoder geocoder;
        int val = i;
        String address = "";
        new Geocoder(this.context, Locale.getDefault());
        try {
            Address add = geocoder.getFromLocation(latitude, longitude, 1).get(0);
            if (val == 1) {
                address = add.getAddressLine(0);
            } else if (val == 2) {
                address = add.getLocality();
            } else if (val == 3) {
                address = add.getCountryName();
            } else if (val == 4) {
                address = add.getPostalCode();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return address;
    }
}
