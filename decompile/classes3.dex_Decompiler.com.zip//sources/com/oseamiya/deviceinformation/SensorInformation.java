package com.oseamiya.deviceinformation;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import com.chstudio.extensions.AndroidSetting.AndroidSetting;
import com.puravidaapps.TaifunPM;
import com.puravidaapps.TaifunTools;
import java.util.List;

public class SensorInformation {
    private final Context context;

    public SensorInformation(Context context2) {
        this.context = context2;
    }

    public List<Sensor> getSensorList() {
        return ((SensorManager) this.context.getSystemService("sensor")).getSensorList(-1);
    }

    public int getTotalNumberOfSensors() {
        return getSensorList().size();
    }

    public String getSensorVendor(Sensor sensor) {
        return sensor.getVendor();
    }

    public int getSensorVersion(Sensor sensor) {
        return sensor.getVersion();
    }

    public float getSensorResolution(Sensor sensor) {
        return sensor.getResolution();
    }

    public float getSensorPower(Sensor sensor) {
        return sensor.getPower();
    }

    public float getSensorMaximumRange(Sensor sensor) {
        return sensor.getMaximumRange();
    }

    public String getSensorName(Sensor sensor) {
        switch (sensor.getType()) {
            case AndroidSetting.VERSION:
                return "Accelerometer";
            case TaifunPM.VERSION /*2*/:
                return "Magnetic Field";
            case 4:
                return "Gyroscope";
            case 5:
                return "Light";
            case 6:
                return "Pressure";
            case 9:
                return "Gravity";
            case 10:
                return "Linear Acceleration";
            case 11:
                return "Rotation Vector";
            case 12:
                return "Humidity";
            case 13:
                return "Ambient Temperature";
            case 15:
                return "Game Rotation Vector";
            case 17:
                return "Significant Motion";
            case 18:
                return "Step Detector";
            case 19:
                return "Step Counter";
            case 20:
                return "Geomagnetic Rotation Vector";
            case TaifunTools.VERSION /*21*/:
                return "Heart Rate";
            case 31:
                return "Heart Beat";
            default:
                return "Unknown";
        }
    }
}
