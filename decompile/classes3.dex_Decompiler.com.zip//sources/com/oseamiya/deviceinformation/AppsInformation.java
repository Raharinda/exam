package com.oseamiya.deviceinformation;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import java.util.List;

public class AppsInformation {
    private final Context context;

    public AppsInformation(Context context2) {
        this.context = context2;
    }

    public List<ApplicationInfo> getListOfApplicationInfo() {
        return this.context.getPackageManager().getInstalledApplications(128);
    }

    public String[] getAllAppsPackageName() {
        List<ApplicationInfo> infoList = getListOfApplicationInfo();
        String[] packageNames = new String[infoList.size()];
        for (int i = 0; i < infoList.size(); i++) {
            packageNames[i] = infoList.get(i).packageName;
        }
        return packageNames;
    }

    public String getApplicationName(String packageName) {
        PackageManager packageManager = this.context.getPackageManager();
        try {
            return (String) packageManager.getApplicationLabel(packageManager.getApplicationInfo(packageName, 128));
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return "Unknown";
        }
    }

    public String getVersionName(String packageName) {
        return getApplicationInfo(packageName, 1);
    }

    public int getVersionCode(String packageName) {
        return Integer.parseInt(getApplicationInfo(packageName, 2));
    }

    public Drawable getApplicationIcon(String packageName) {
        try {
            return this.context.getPackageManager().getApplicationIcon(packageName);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    public long getInstalledTime(String packageName) {
        try {
            return this.context.getPackageManager().getPackageInfo(packageName, 128).firstInstallTime;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public long getLastUpdatedTime(String packageName) {
        try {
            return this.context.getPackageManager().getPackageInfo(packageName, 128).lastUpdateTime;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public String[] getRequestedPermissions(String packageName) {
        try {
            return this.context.getPackageManager().getPackageInfo(packageName, 128).requestedPermissions;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    private String getApplicationInfo(String packageName, int i) {
        int identity = i;
        try {
            PackageInfo packageInfo = this.context.getPackageManager().getPackageInfo(packageName, 128);
            if (identity == 1) {
                return packageInfo.versionName;
            }
            if (identity == 2) {
                return Integer.toString(packageInfo.versionCode);
            }
            return "0";
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return "0";
        }
    }
}
