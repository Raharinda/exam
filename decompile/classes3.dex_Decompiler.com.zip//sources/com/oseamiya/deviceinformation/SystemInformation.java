package com.oseamiya.deviceinformation;

import android.content.Context;
import android.os.Build;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class SystemInformation {
    private final Context context;

    public SystemInformation(Context context2) {
        this.context = context2;
    }

    public int getApiLevel() {
        return Build.VERSION.SDK_INT;
    }

    public String getVersionName() {
        String name = Build.VERSION_CODES.class.getFields()[Build.VERSION.SDK_INT + 1].getName();
        if (name.equals("O")) {
            name = "Oreo";
        }
        if (name.equals("N")) {
            name = "Nougat";
        }
        if (name.equals("M")) {
            name = "Marshmallow";
        }
        if (name.startsWith("O_")) {
            name = "Oreo++";
        }
        if (name.startsWith("N_")) {
            name = "Nougat++";
        }
        return name;
    }

    public String getSecurityPathDate() {
        ProcessBuilder processBuilder;
        BufferedReader bufferedReader;
        Reader reader;
        StringBuilder sb;
        if (Build.VERSION.SDK_INT >= 23) {
            return Build.VERSION.SECURITY_PATCH;
        }
        try {
            new ProcessBuilder(new String[0]);
            Process process = processBuilder.command(new String[]{"/system/bin/getprop"}).redirectErrorStream(true).start();
            new InputStreamReader(process.getInputStream());
            new BufferedReader(reader);
            BufferedReader br = bufferedReader;
            new StringBuilder();
            StringBuilder str = sb;
            while (true) {
                String readLine = br.readLine();
                String line = readLine;
                if (readLine == null) {
                    break;
                }
                StringBuilder append = str.append(line).append("\n");
                if (str.toString().contains("security_patch")) {
                    String[] split = line.split(":");
                    if (split.length == 2) {
                        return split[1];
                    }
                }
            }
            br.close();
            process.destroy();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    public Date getAndroidSdkReleaseDate() {
        int sdk = Build.VERSION.SDK_INT;
        Calendar calendar = Calendar.getInstance();
        if (sdk == 1) {
            calendar.set(2, 8);
            calendar.set(5, 23);
            calendar.set(1, 2008);
            return calendar.getTime();
        } else if (sdk == 2) {
            calendar.set(2, 1);
            calendar.set(5, 9);
            calendar.set(1, 2009);
            return calendar.getTime();
        } else if (sdk == 3) {
            calendar.set(2, 3);
            calendar.set(5, 27);
            calendar.set(1, 2009);
            return calendar.getTime();
        } else if (sdk == 4) {
            calendar.set(2, 8);
            calendar.set(5, 15);
            calendar.set(1, 2009);
            return calendar.getTime();
        } else if (sdk == 5) {
            calendar.set(2, 9);
            calendar.set(5, 27);
            calendar.set(1, 2009);
            return calendar.getTime();
        } else if (sdk == 6) {
            calendar.set(2, 11);
            calendar.set(5, 3);
            calendar.set(1, 2009);
            return calendar.getTime();
        } else if (sdk == 7) {
            calendar.set(2, 0);
            calendar.set(5, 11);
            calendar.set(1, 2010);
            return calendar.getTime();
        } else if (sdk == 8) {
            calendar.set(2, 4);
            calendar.set(5, 20);
            calendar.set(1, 2010);
            return calendar.getTime();
        } else if (sdk == 9) {
            calendar.set(2, 11);
            calendar.set(5, 6);
            calendar.set(1, 2010);
            return calendar.getTime();
        } else if (sdk == 10) {
            calendar.set(2, 1);
            calendar.set(5, 9);
            calendar.set(1, 2011);
            return calendar.getTime();
        } else if (sdk == 11) {
            calendar.set(2, 1);
            calendar.set(5, 22);
            calendar.set(1, 2011);
            return calendar.getTime();
        } else if (sdk == 12) {
            calendar.set(2, 4);
            calendar.set(5, 10);
            calendar.set(1, 2011);
            return calendar.getTime();
        } else if (sdk == 13) {
            calendar.set(2, 6);
            calendar.set(5, 15);
            calendar.set(1, 2011);
            return calendar.getTime();
        } else if (sdk == 14) {
            calendar.set(2, 9);
            calendar.set(5, 18);
            calendar.set(1, 2011);
            return calendar.getTime();
        } else if (sdk == 15) {
            calendar.set(2, 11);
            calendar.set(5, 16);
            calendar.set(1, 2011);
            return calendar.getTime();
        } else if (sdk == 16) {
            calendar.set(2, 6);
            calendar.set(5, 9);
            calendar.set(1, 2012);
            return calendar.getTime();
        } else if (sdk == 17) {
            calendar.set(2, 10);
            calendar.set(5, 13);
            calendar.set(1, 2012);
            return calendar.getTime();
        } else if (sdk == 18) {
            calendar.set(2, 6);
            calendar.set(5, 24);
            calendar.set(1, 2013);
            return calendar.getTime();
        } else if (sdk == 19) {
            calendar.set(2, 9);
            calendar.set(5, 31);
            calendar.set(1, 2013);
            return calendar.getTime();
        } else if (sdk == 20) {
            calendar.set(2, 5);
            calendar.set(5, 25);
            calendar.set(1, 2014);
            return calendar.getTime();
        } else if (sdk == 21) {
            calendar.set(2, 10);
            calendar.set(5, 4);
            calendar.set(1, 2014);
            return calendar.getTime();
        } else if (sdk == 22) {
            calendar.set(2, 2);
            calendar.set(5, 2);
            calendar.set(1, 2015);
            return calendar.getTime();
        } else if (sdk == 23) {
            calendar.set(2, 9);
            calendar.set(5, 2);
            calendar.set(1, 2015);
            return calendar.getTime();
        } else if (sdk == 24) {
            calendar.set(2, 7);
            calendar.set(5, 22);
            calendar.set(1, 2016);
            return calendar.getTime();
        } else if (sdk == 25) {
            calendar.set(2, 9);
            calendar.set(5, 4);
            calendar.set(1, 2016);
            return calendar.getTime();
        } else if (sdk == 26) {
            calendar.set(2, 6);
            calendar.set(5, 21);
            calendar.set(1, 2017);
            return calendar.getTime();
        } else if (sdk == 27) {
            calendar.set(2, 11);
            calendar.set(5, 5);
            calendar.set(1, 2017);
            return calendar.getTime();
        } else if (sdk == 28) {
            calendar.set(2, 6);
            calendar.set(5, 6);
            calendar.set(1, 2018);
            return calendar.getTime();
        } else if (sdk == 29) {
            calendar.set(2, 8);
            calendar.set(5, 7);
            calendar.set(1, 2019);
            return calendar.getTime();
        } else if (sdk != 30) {
            return null;
        } else {
            calendar.set(2, 8);
            calendar.set(5, 8);
            calendar.set(1, 2020);
            return calendar.getTime();
        }
    }

    public String getBootloader() {
        return Build.BOOTLOADER;
    }

    public String getKernalVersion() {
        InputStream is;
        BufferedReader bufferedReader;
        Reader reader;
        Process process = null;
        try {
            process = Runtime.getRuntime().exec("uname -a");
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            if (process.waitFor() == 0) {
                is = process.getInputStream();
            } else {
                is = process.getErrorStream();
            }
            new InputStreamReader(is);
            new BufferedReader(reader);
            BufferedReader br = bufferedReader;
            String line = br.readLine();
            br.close();
            return line;
        } catch (InterruptedException e2) {
            e2.printStackTrace();
            return "Error";
        } catch (IOException e3) {
            e3.printStackTrace();
            return "Error";
        }
    }

    public String getLanguage() {
        return Locale.getDefault().getLanguage();
    }

    public String getIso3Language() {
        return Locale.getDefault().getISO3Language();
    }

    public String getCountry() {
        return Locale.getDefault().getCountry();
    }

    public String getIso3Country() {
        return Locale.getDefault().getISO3Country();
    }

    public String getDisplayCountry() {
        return Locale.getDefault().getDisplayCountry();
    }

    public String getDisplayName() {
        return Locale.getDefault().getDisplayName();
    }

    public String getDisplayLanguage() {
        return Locale.getDefault().getDisplayLanguage();
    }

    public String getLanguageTag() {
        return Locale.getDefault().toLanguageTag();
    }
}
