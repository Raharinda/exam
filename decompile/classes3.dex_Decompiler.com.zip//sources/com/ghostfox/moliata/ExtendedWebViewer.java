package com.ghostfox.moliata;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.WebViewer;

@DesignerComponent(category = ComponentCategory.EXTENSION, description = "An extension that extends the features of the existing Web Viewer component <br>Created by Sivagiri Visakan & ILoveThunkable", iconName = "http://voltscdn.weebly.com/uploads/2/0/8/1/20817010/idea.png", nonVisible = true, version = 2)
@SimpleObject(external = true)
@UsesPermissions(permissionNames = "android.permission.INTERNET,android.permission.ACCESS_NETWORK_STATE,android.permission.WRITE_EXTERNAL_STORAGE")
public class ExtendedWebViewer extends AndroidNonvisibleComponent implements Component {
    public final String LOG_TAG = "ExtendedWebViewer";
    private final Activity activity;
    private ComponentContainer container;
    private Context context;
    private String desc = "Downloading file";
    private BroadcastReceiver downloadReceiver;
    private boolean showNotification = true;
    public boolean suppressToast;
    public String userAgentString = "";
    public WebView webView;
    public WebViewer webViewer;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ExtendedWebViewer(com.google.appinventor.components.runtime.ComponentContainer r9) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            r3 = r0
            r4 = r1
            com.google.appinventor.components.runtime.Form r4 = r4.$form()
            r3.<init>(r4)
            r3 = r0
            java.lang.String r4 = "ExtendedWebViewer"
            r3.LOG_TAG = r4
            r3 = r0
            java.lang.String r4 = ""
            r3.userAgentString = r4
            r3 = r0
            java.lang.String r4 = "Downloading file"
            r3.desc = r4
            r3 = r0
            r4 = 1
            r3.showNotification = r4
            r3 = r0
            com.ghostfox.moliata.ExtendedWebViewer$3 r4 = new com.ghostfox.moliata.ExtendedWebViewer$3
            r7 = r4
            r4 = r7
            r5 = r7
            r6 = r0
            r5.<init>(r6)
            r3.downloadReceiver = r4
            r3 = r0
            r4 = r1
            r3.container = r4
            r3 = r0
            r4 = r1
            android.app.Activity r4 = r4.$context()
            r3.context = r4
            r3 = r0
            r4 = r1
            android.app.Activity r4 = r4.$context()
            r3.activity = r4
            java.lang.String r3 = "ExtendedWebViewer"
            java.lang.String r4 = "ExtendedWebViewer Created"
            int r3 = android.util.Log.d(r3, r4)
            android.content.IntentFilter r3 = new android.content.IntentFilter
            r7 = r3
            r3 = r7
            r4 = r7
            java.lang.String r5 = "android.intent.action.DOWNLOAD_COMPLETE"
            r4.<init>(r5)
            r2 = r3
            r3 = r0
            com.google.appinventor.components.runtime.Form r3 = r3.form
            r4 = r0
            android.content.BroadcastReceiver r4 = r4.downloadReceiver
            r5 = r2
            android.content.Intent r3 = r3.registerReceiver(r4, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.ghostfox.moliata.ExtendedWebViewer.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    @SimpleFunction(description = "Enable the OAuth requests made from the WebViewer")
    public void EnableOAuth() {
        this.webView.getSettings().setUserAgentString(System.getProperty("http.agent"));
    }

    @SimpleFunction(description = "Set a custom User Agent for the WebViewer")
    public void SetUserAgent(String userAgent) {
        this.webView.getSettings().setUserAgentString(userAgent);
    }

    @SimpleFunction(description = "Show the zoom icons for the WebViewer")
    public void InvokeZoomPicker() {
        this.webView.invokeZoomPicker();
    }

    @SimpleFunction(description = "Reload the current page. AfterReload event is called after this block")
    public void Reload() {
        this.webView.reload();
        AfterReload(this.webView.getUrl());
    }

    @SimpleFunction(description = "A function to download files through android's default download manager.")
    public void DownloadFile(String str, String str2, String str3, String str4, String contentDisposition) {
        DownloadManager.Request request;
        String filename = str;
        String url = str2;
        String mimeType = str3;
        String userAgent = str4;
        String filename2 = (filename == null || filename.isEmpty()) ? URLUtil.guessFileName(url, contentDisposition, mimeType) : filename;
        new DownloadManager.Request(Uri.parse(url));
        DownloadManager.Request request2 = request;
        DownloadManager.Request mimeType2 = request2.setMimeType(mimeType);
        DownloadManager.Request addRequestHeader = request2.addRequestHeader("cookie", CookieManager.getInstance().getCookie(url));
        DownloadManager.Request addRequestHeader2 = request2.addRequestHeader("User-Agent", userAgent);
        DownloadManager.Request title = request2.setTitle(filename2);
        request2.allowScanningByMediaScanner();
        if (this.showNotification) {
            DownloadManager.Request notificationVisibility = request2.setNotificationVisibility(1);
        }
        DownloadManager.Request destinationInExternalPublicDir = request2.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename2);
        Context context2 = this.context;
        Context context3 = this.context;
        long enqueue = ((DownloadManager) context2.getSystemService("download")).enqueue(request2);
    }

    @SimpleFunction(description = "Returns the User Agent String of the WebViewer.")
    public String GetUserAgent() {
        return this.webView.getSettings().getUserAgentString();
    }

    @SimpleFunction(description = "Gets the height of the HTML content.")
    public int GetContentHeight() {
        return this.webView.getContentHeight();
    }

    @SimpleProperty(description = "Set the Web Viewer component in which all the functions will be executed .")
    public void WebViewer(WebViewer webViewerComponent) {
        WebChromeClient webChromeClient;
        WebViewClient webViewClient2;
        DownloadListener downloadListener;
        this.webViewer = webViewerComponent;
        this.webView = (WebView) this.webViewer.getView();
        new WebChromeClient(this) {
            final /* synthetic */ ExtendedWebViewer this$0;

            {
                this.this$0 = r5;
            }

            public void onProgressChanged(WebView webView, int progress) {
                WebView webView2 = webView;
                this.this$0.OnProgressChanged(progress);
            }
        };
        this.webView.setWebChromeClient(webChromeClient);
        new webViewClient(this);
        this.webView.setWebViewClient(webViewClient2);
        new DownloadListener(this) {
            final /* synthetic */ ExtendedWebViewer this$0;

            {
                this.this$0 = r5;
            }

            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {
                this.this$0.OnDownloadNeeded(url, mimeType, userAgent, contentDisposition, contentLength);
            }
        };
        this.webView.setDownloadListener(downloadListener);
    }

    @SimpleProperty(description = "Get the Web Viewer component in which all the functions will be executed .")
    public WebViewer WebViewer() {
        return this.webViewer;
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "Shows an notification about downloading of a file in the status bar if true ")
    public boolean ShowNotification() {
        return this.showNotification;
    }

    @DesignerProperty(defaultValue = "True", editorType = "boolean")
    @SimpleProperty
    public void ShowNotification(boolean show) {
        boolean z = show;
        this.showNotification = z;
    }

    @SimpleEvent(description = "This event fires after the Reload block")
    @Deprecated
    public void AfterReload(String url) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "AfterReload", new Object[]{url});
    }

    @SimpleEvent(description = "Indicates the progress of loading of a webpage.The value of \"progress\" lies between 1 and 100")
    public void OnProgressChanged(int progress) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnProgressChanged", new Object[]{Integer.valueOf(progress)});
    }

    @SimpleEvent(description = "Indicates that a webpage has started loading.")
    public void OnLoadingStarted(String url) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnLoadingStarted", new Object[]{url});
    }

    @SimpleEvent(description = "Indicates that a webpage has finished loading.")
    public void OnLoadingFinished(String url) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnLoadingFinished", new Object[]{url});
    }

    @SimpleEvent(description = "Indicates that a webviewer has encountered an error while loading a webpage.")
    public void OnErrorOccured(int code, String message, String failingUrl) {
        Object[] objArr = new Object[3];
        objArr[0] = Integer.valueOf(code);
        Object[] objArr2 = objArr;
        objArr2[1] = message;
        Object[] objArr3 = objArr2;
        objArr3[2] = failingUrl;
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnErrorOccured", objArr3);
    }

    @SimpleEvent(description = "Indicates that the content at the URL cannot be displayed in the Web Viewer \n and therefore needs to be downloaded to view the content. contentLength is the size in bytes")
    public void OnDownloadNeeded(String url, String mimeType, String userAgent, String contentDisposition, long contentLength) {
        Object[] objArr = new Object[5];
        objArr[0] = url;
        Object[] objArr2 = objArr;
        objArr2[1] = mimeType;
        Object[] objArr3 = objArr2;
        objArr3[2] = userAgent;
        Object[] objArr4 = objArr3;
        objArr4[3] = contentDisposition;
        Object[] objArr5 = objArr4;
        objArr5[4] = Long.valueOf(contentLength);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnDownloadNeeded", objArr5);
    }

    @SimpleEvent(description = "Indicates that a webpage has finished loading.")
    public void OnDownloadFinished() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnDownloadFinished", new Object[0]);
    }

    public class webViewClient extends WebViewClient {
        final /* synthetic */ ExtendedWebViewer this$0;

        public webViewClient(ExtendedWebViewer extendedWebViewer) {
            this.this$0 = extendedWebViewer;
        }

        public void onPageStarted(WebView webView, String url, Bitmap bitmap) {
            WebView webView2 = webView;
            Bitmap bitmap2 = bitmap;
            this.this$0.OnLoadingStarted(url);
        }

        public void onPageFinished(WebView webView, String url) {
            WebView webView2 = webView;
            this.this$0.OnLoadingFinished(url);
        }

        public void onReceivedError(WebView webView, int errorCode, String description, String failingUrl) {
            WebView webView2 = webView;
            this.this$0.OnErrorOccured(errorCode, description, failingUrl);
        }
    }
}
