package com.puravidaapps;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.util.Base64;
import android.util.Log;
import android.util.Patterns;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.OnDestroyListener;
import com.google.appinventor.components.runtime.OnPauseListener;
import com.google.appinventor.components.runtime.OnResumeListener;
import com.google.appinventor.components.runtime.OnStopListener;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.security.Key;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

@SimpleObject(external = true)
@DesignerComponent(category = ComponentCategory.EXTENSION, description = "A collection of several tools, which do not need additional permissions. Version 21a as of 2021-01-06.", helpUrl = "https://puravidaapps.com/tools.php", iconName = "https://puravidaapps.com/images/taifun16.png", nonVisible = true, version = 21)
public class TaifunTools extends AndroidNonvisibleComponent implements Component, OnPauseListener, OnResumeListener, OnStopListener, OnDestroyListener {
    private static final String LOG_TAG = "TaifunTools";
    public static final int VERSION = 21;
    private static Context context;
    private final Activity activity;
    private ComponentContainer container;
    private File file;
    private final InputMethodManager imm;
    private boolean isRepl = false;
    private MediaScannerConnection msc;
    private boolean suppressWarnings;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public TaifunTools(com.google.appinventor.components.runtime.ComponentContainer r6) {
        /*
            r5 = this;
            r0 = r5
            r1 = r6
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            r3 = 0
            r2.isRepl = r3
            r2 = r0
            com.google.appinventor.components.runtime.Form r2 = r2.form
            boolean r2 = r2 instanceof com.google.appinventor.components.runtime.ReplForm
            if (r2 == 0) goto L_0x001a
            r2 = r0
            r3 = 1
            r2.isRepl = r3
        L_0x001a:
            r2 = r0
            com.google.appinventor.components.runtime.Form r2 = r2.form
            r3 = r0
            r2.registerForOnPause(r3)
            r2 = r0
            com.google.appinventor.components.runtime.Form r2 = r2.form
            r3 = r0
            r2.registerForOnStop(r3)
            r2 = r0
            com.google.appinventor.components.runtime.Form r2 = r2.form
            r3 = r0
            r2.registerForOnResume(r3)
            r2 = r0
            com.google.appinventor.components.runtime.Form r2 = r2.form
            r3 = r0
            r2.registerForOnDestroy(r3)
            r2 = r0
            r3 = r1
            r2.container = r3
            r2 = r1
            android.app.Activity r2 = r2.$context()
            context = r2
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.activity = r3
            r2 = r0
            android.content.Context r3 = context
            java.lang.String r4 = "input_method"
            java.lang.Object r3 = r3.getSystemService(r4)
            android.view.inputmethod.InputMethodManager r3 = (android.view.inputmethod.InputMethodManager) r3
            r2.imm = r3
            java.lang.String r2 = "TaifunTools"
            java.lang.String r3 = "TaifunTools Created"
            int r2 = android.util.Log.d(r2, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.puravidaapps.TaifunTools.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    @SimpleFunction(description = "Gallery Refresh for a specific filename.")
    public String GalleryRefresh(String str) {
        StringBuilder sb;
        File file2;
        MediaScannerConnection.OnScanCompletedListener onScanCompletedListener;
        String fileName = str;
        new StringBuilder();
        int i = Log.i(LOG_TAG, sb.append("Refresh, filename: ").append(fileName).toString());
        new File(fileName);
        this.file = file2;
        String[] strArr = {this.file.getAbsolutePath()};
        new MediaScannerConnection.OnScanCompletedListener(this) {
            final /* synthetic */ TaifunTools this$0;

            {
                this.this$0 = this$0;
            }

            public void onScanCompleted(String path, Uri uri) {
                StringBuilder sb;
                new StringBuilder();
                int i = Log.i(TaifunTools.LOG_TAG, sb.append("onScanCompleted, path: ").append(path).append(", uri: ").append(uri).toString());
            }
        };
        MediaScannerConnection.scanFile(context, strArr, (String[]) null, onScanCompletedListener);
        return fileName;
    }

    @SimpleFunction(description = "Returns a base64 encoded HMAC SHA1 hash. Precondition to use this block: Min Android Version of the app must be 8!")
    public String HmacSha1(String message, String key) {
        int d = Log.d(LOG_TAG, "HmacSha1");
        return HmacDigest(message, key, "HmacSHA1");
    }

    @SimpleFunction(description = "Returns a base64 encoded HMAC SHA256 hash. Precondition to use this block: Min Android Version of the app must be 8!")
    public String HmacSha256(String message, String key) {
        int d = Log.d(LOG_TAG, "HmacSha256");
        return HmacDigest(message, key, "HmacSha256");
    }

    private static String HmacDigest(String str, String str2, String str3) {
        Key key;
        String msg = str;
        String keyString = str2;
        String algo = str3;
        if (Build.VERSION.SDK_INT < 8) {
            int w = Log.w(LOG_TAG, "Sorry, Base64 encode is not available for API < 8");
        } else {
            try {
                new SecretKeySpec(keyString.getBytes("UTF-8"), algo);
                Mac mac = Mac.getInstance(algo);
                mac.init(key);
                return Base64.encodeToString(mac.doFinal(msg.getBytes("UTF-8")), 0);
            } catch (Exception e) {
                Exception e2 = e;
                int e3 = Log.e(LOG_TAG, e2.getMessage());
                e2.printStackTrace();
            }
        }
        return null;
    }

    @SimpleFunction(description = "Returns a list of available sensors")
    public Object SensorList() {
        List<Map<String, String>> list;
        Map<String, String> map;
        List<Sensor> sensorList = ((SensorManager) this.activity.getSystemService("sensor")).getSensorList(-1);
        new ArrayList<>();
        List<Map<String, String>> sensorData = list;
        for (Sensor sensor : sensorList) {
            new HashMap<>();
            Map<String, String> data = map;
            String put = data.put("name", sensor.getName());
            String put2 = data.put("vendor", sensor.getVendor());
            boolean add = sensorData.add(data);
        }
        return sensorData;
    }

    @SimpleFunction(description = "Hide the system user interface")
    public void HideSystemUI() {
        this.activity.getWindow().getDecorView().setSystemUiVisibility(5894);
    }

    @SimpleFunction(description = "Show the system user interface")
    public void ShowSystemUI() {
        this.activity.getWindow().getDecorView().setSystemUiVisibility(1792);
    }

    @SimpleFunction(description = "Returns the version code of the app")
    public int VersionCode() {
        int d = Log.d(LOG_TAG, "VersionCode");
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            PackageManager.NameNotFoundException e2 = e;
            int e3 = Log.e(LOG_TAG, e2.getMessage());
            e2.printStackTrace();
            return 0;
        }
    }

    @SimpleEvent(description = "Event indicating that the state of the activity changed.Possible values are pause, stop, resume. See also the activity lifecycle here http://developer.android.com/reference/android/app/Activity.html#ActivityLifecycle")
    public void ActivityStateChanged(String str) {
        StringBuilder sb;
        String state = str;
        new StringBuilder();
        int i = Log.i(LOG_TAG, sb.append("ActivityStateChanged: ").append(state).toString());
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "ActivityStateChanged", new Object[]{state});
    }

    public void onResume() {
        ActivityStateChanged("resume");
    }

    public void onPause() {
        ActivityStateChanged("pause");
    }

    public void onStop() {
        ActivityStateChanged("stop");
    }

    public void onDestroy() {
        int i = Log.i(LOG_TAG, "onDestroy");
        ActivityStateChanged("destroy");
    }

    @SimpleFunction(description = "Show the keyboard")
    public void ShowKeyboard() {
        int d = Log.d(LOG_TAG, "ShowKeyboard");
        this.imm.toggleSoftInput(2, 1);
    }

    @SimpleFunction(description = "Clear the cache of the current app. Returns true if clearing was successful, else false.")
    public boolean ClearCache() {
        StringBuilder sb;
        int d = Log.d(LOG_TAG, "ClearCache");
        try {
            File dir = context.getCacheDir();
            new StringBuilder();
            int d2 = Log.d(LOG_TAG, sb.append("dir: ").append(dir).toString());
            return deleteDir(dir);
        } catch (Exception e) {
            Exception e2 = e;
            int e3 = Log.e(LOG_TAG, e2.getMessage());
            e2.printStackTrace();
            return false;
        }
    }

    private static boolean deleteDir(File file2) {
        StringBuilder sb;
        File file3;
        File dir = file2;
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                new StringBuilder();
                int d = Log.d(LOG_TAG, sb.append("i: ").append(i).append(", children: ").append(children[i]).toString());
                new File(dir, children[i]);
                if (!deleteDir(file3)) {
                    return false;
                }
            }
            return dir.delete();
        } else if (dir == null || !dir.isFile()) {
            return false;
        } else {
            return dir.delete();
        }
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "whether Warnings should be suppressed")
    public boolean SuppressWarnings() {
        return this.suppressWarnings;
    }

    @DesignerProperty(defaultValue = "false", editorType = "boolean")
    @SimpleProperty
    public void SuppressWarnings(boolean suppressWarnings2) {
        boolean z = suppressWarnings2;
        this.suppressWarnings = z;
    }

    @SimpleFunction(description = "Exclusive or for boolean: returns true only when inputs differ (one is true, the other is false).")
    public boolean Xor(boolean a, boolean b) {
        return a ^ b;
    }

    @SimpleFunction(description = "Exclusive or for hex strings, returns hex result. Strings must have the same length.")
    public String XorHex(String str, String str2) {
        String str3;
        String a = str;
        String b = str2;
        if (a.length() != b.length()) {
            if (!this.suppressWarnings) {
                Toast.makeText(context, "Strings must have the same length.", 0).show();
            }
            return "";
        } else if (!isHex(a) || !isHex(b)) {
            if (!this.suppressWarnings) {
                Toast.makeText(context, "Strings must be hex values.", 0).show();
            }
            return "";
        } else {
            char[] chars = new char[a.length()];
            for (int i = 0; i < chars.length; i++) {
                chars[i] = toHex(fromHex(a.charAt(i)) ^ fromHex(b.charAt(i)));
            }
            new String(chars);
            return str3;
        }
    }

    private static int fromHex(char c) {
        Throwable th;
        char c2 = c;
        if (c2 >= '0' && c2 <= '9') {
            return c2 - '0';
        }
        if (c2 >= 'A' && c2 <= 'F') {
            return (c2 - 'A') + 10;
        }
        if (c2 >= 'a' && c2 <= 'f') {
            return (c2 - 'a') + 10;
        }
        Throwable th2 = th;
        new IllegalArgumentException();
        throw th2;
    }

    private char toHex(int i) {
        Throwable th;
        int nybble = i;
        if (nybble >= 0 && nybble <= 15) {
            return "0123456789ABCDEF".charAt(nybble);
        }
        Throwable th2 = th;
        new IllegalArgumentException();
        throw th2;
    }

    private boolean isHex(String s) {
        return s.matches("-?[0-9a-fA-F]+");
    }

    @DesignerProperty(defaultValue = "&H00FFFFFF", editorType = "color")
    @SimpleProperty(description = "Set status bar color. This will work starting from API Level 21 (Android Lollipop")
    public void StatusBarColor(int i) {
        int argb = i;
        if (Build.VERSION.SDK_INT < 21) {
            int w = Log.w(LOG_TAG, "Sorry, setStatusBarColor is not available for API Level < 21");
            return;
        }
        Window window = this.activity.getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        window.setStatusBarColor(argb);
    }

    @DesignerProperty(defaultValue = "&H00FFFFFF", editorType = "color")
    @SimpleProperty(description = "Set navigation bar color. This will work starting from API Level 21 (Android Lollipop")
    public void NavigationBarColor(int i) {
        int argb = i;
        if (Build.VERSION.SDK_INT < 21) {
            int w = Log.w(LOG_TAG, "Sorry, NavigationBarColor is not available for API Level < 21");
            return;
        }
        Window window = this.activity.getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(134217728);
        window.setNavigationBarColor(argb);
    }

    @SimpleFunction(description = "Hide content, i.e. enable content to move behind status and navigation bar.")
    public void HideContent() {
        this.activity.getWindow().getDecorView().setSystemUiVisibility(1792);
    }

    @DesignerProperty(defaultValue = "&H00FFFFFF", editorType = "color")
    @SimpleProperty(description = "Set title color.")
    public void TitleColor(int argb) {
        this.activity.getWindow().setTitleColor(argb);
    }

    @SimpleProperty(description = "Returns the language code of the current Locale. A Locale object represents a specific geographical, political, or cultural region.")
    public String Language() {
        return context.getResources().getConfiguration().locale.getLanguage();
    }

    @SimpleProperty(description = "Returns the country/region code of the current Locale, which should either be the empty string, an uppercase ISO 3166 2-letter code, or a UN M.49 3-digit code. A Locale object represents a specific geographical, political, or cultural region.")
    public String Country() {
        return context.getResources().getConfiguration().locale.getCountry();
    }

    @SimpleFunction(description = "Base64 encode a string. Precondition to use this block: Min Android Version of the app must be 8!")
    public String Base64Encode(String string) {
        int d = Log.d(LOG_TAG, "Base64Encode");
        try {
            return Base64.encodeToString(string.getBytes("UTF-8"), 2);
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException e2 = e;
            int e3 = Log.e(LOG_TAG, e2.getMessage());
            e2.printStackTrace();
            return e2.getMessage();
        }
    }

    @SimpleFunction(description = "returns true, if string matches a regular expression, else false")
    public boolean Matches(String string, String regex) {
        int d = Log.d(LOG_TAG, "Matches");
        if (string.matches(regex)) {
            return true;
        }
        return false;
    }

    @SimpleFunction(description = "As long as this window is visible to the user, keep the device's screen turned on and bright.")
    public void KeepScreenOn() {
        int d = Log.d(LOG_TAG, "KeepScreenOn");
        this.activity.getWindow().addFlags(128);
    }

    @SimpleFunction(description = "Returns the version name of the app")
    public String VersionName() {
        int d = Log.d(LOG_TAG, "VersionName");
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            PackageManager.NameNotFoundException e2 = e;
            int e3 = Log.e(LOG_TAG, e2.getMessage());
            e2.printStackTrace();
            return "";
        }
    }

    @SimpleFunction(description = "Returns true, if it is a valid email address, else false.")
    public boolean EmailAddressIsValid(String emailAddress) {
        int d = Log.d(LOG_TAG, "EmailAddressIsValid");
        return Patterns.EMAIL_ADDRESS.matcher(emailAddress).matches();
    }

    @SimpleFunction(description = "Returns the path to the assets. This method is useful, if you want to access files from the webviewer component stored in the assets of the app. The method will return 'file:///android_asset/' in case the app is running after building the app as apk file. For the companion app there can be returned 3 different values: file:///storage/emulated/0/Android/data/<packageName>/files/assets/ for devices >= Android 10, file:///storage/emulated/0/AppInventor/assets/' for the App Inventor companion app and < Android 10, file:///storage/emulated/0/Makeroid/assets/' for the Kodular (formerly Makeroid) companion app and < Android 10.")
    public String PathToAssets() {
        StringBuilder sb;
        int d = Log.d(LOG_TAG, "PathToAssets");
        if (!this.isRepl) {
            return "file:///android_asset/";
        }
        if (Build.VERSION.SDK_INT >= 29) {
            new StringBuilder();
            return sb.append("file://").append(ApplicationSpecificDirectory()).append("/assets/").toString();
        } else if (context.getPackageName().contains("makeroid")) {
            return "file:///storage/emulated/0/Makeroid/assets/";
        } else {
            return "file:///storage/emulated/0/AppInventor/assets/";
        }
    }

    @SimpleFunction(description = "Returns the density of the device.")
    public double Density() {
        int d = Log.d(LOG_TAG, "Density");
        return (double) this.activity.getResources().getDisplayMetrics().density;
    }

    @SimpleFunction(description = "Returns the package name of the app.")
    public String PackageName() {
        StringBuilder sb;
        new StringBuilder();
        int d = Log.d(LOG_TAG, sb.append("PackageName: ").append(context.getPackageName()).toString());
        return context.getPackageName();
    }

    @SimpleFunction(description = "Returns true, if app is running in development mode (using the companion app), else returns false.")
    public boolean IsDevelopment() {
        StringBuilder sb;
        new StringBuilder();
        int d = Log.d(LOG_TAG, sb.append("IsDevelopment: ").append(this.isRepl).toString());
        return this.isRepl;
    }

    @SimpleFunction(description = "Returns a Sha256 hash of a given string.")
    public String Sha256(String str) {
        StringBuffer stringBuffer;
        String string = str;
        int d = Log.d(LOG_TAG, "Sha256");
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(string.getBytes("UTF-8"));
            new StringBuffer();
            StringBuffer hexString = stringBuffer;
            for (int i = 0; i < hash.length; i++) {
                String hex = Integer.toHexString(255 & hash[i]);
                if (hex.length() == 1) {
                    StringBuffer append = hexString.append('0');
                }
                StringBuffer append2 = hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            Exception e2 = e;
            int e3 = Log.e(LOG_TAG, e2.getMessage());
            e2.printStackTrace();
            return "";
        }
    }

    @SimpleFunction(description = "Remove the KeepScreenOn flag.")
    public void DontKeepScreenOn() {
        int d = Log.d(LOG_TAG, "KeepScreenOn");
        this.activity.getWindow().clearFlags(128);
    }

    @SimpleFunction(description = "API Level.")
    public int ApiLevel() {
        int d = Log.d(LOG_TAG, "ApiLEvel");
        return Build.VERSION.SDK_INT;
    }

    @SimpleFunction(description = "Returns the application specific directory you can use to write files without having WRITE_EXTERNAL_STORAGE permission.")
    public String ApplicationSpecificDirectory() {
        int d = Log.d(LOG_TAG, "ApplicationSpecificDirectory");
        return context.getExternalFilesDir((String) null).toString();
    }

    @SimpleFunction(description = "Clear the app data of the current app. Returns true if clearing was successful, else false.")
    public boolean ClearAppData() {
        StringBuilder sb;
        int d = Log.d(LOG_TAG, "ClearAppData");
        try {
            if (19 <= Build.VERSION.SDK_INT) {
                Context context2 = context;
                Context context3 = context;
                boolean clearApplicationUserData = ((ActivityManager) context2.getSystemService("activity")).clearApplicationUserData();
            } else {
                String packageName = PackageName();
                new StringBuilder();
                Process exec = Runtime.getRuntime().exec(sb.append("pm clear ").append(packageName).toString());
            }
            return true;
        } catch (Exception e) {
            Exception e2 = e;
            int e3 = Log.e(LOG_TAG, e2.getMessage());
            e2.printStackTrace();
            return false;
        }
    }
}
