package com.puravidaapps;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import java.io.File;

public class TaifunPM extends AndroidNonvisibleComponent implements Component {
    public static final int VERSION = 2;
    private final Activity a;

    /* renamed from: a  reason: collision with other field name */
    private Context f2a;

    /* renamed from: a  reason: collision with other field name */
    private PackageManager f3a;

    /* renamed from: a  reason: collision with other field name */
    private String f4a = "";

    /* renamed from: a  reason: collision with other field name */
    private boolean f5a = false;
    private boolean b;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public TaifunPM(com.google.appinventor.components.runtime.ComponentContainer r8) {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            r3 = 0
            r2.f5a = r3
            r2 = r0
            java.lang.String r3 = ""
            r2.f4a = r3
            r2 = r0
            com.google.appinventor.components.runtime.Form r2 = r2.form
            boolean r2 = r2 instanceof com.google.appinventor.components.runtime.ReplForm
            if (r2 == 0) goto L_0x0020
            r2 = r0
            r3 = 1
            r2.f5a = r3
        L_0x0020:
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.f2a = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.a = r3
            r2 = r0
            r6 = r2
            r2 = r6
            r3 = r6
            android.content.Context r3 = r3.f2a
            android.content.pm.PackageManager r3 = r3.getPackageManager()
            r2.f3a = r3
            r2 = r0
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r6 = r3
            r3 = r6
            r4 = r6
            r4.<init>()
            r4 = r0
            java.lang.String r4 = r4.a()
            java.lang.StringBuilder r3 = r3.append(r4)
            java.lang.String r4 = "/Packages"
            java.lang.StringBuilder r3 = r3.append(r4)
            java.lang.String r3 = r3.toString()
            r2.f4a = r3
            java.lang.String r2 = "TaifunPM"
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r6 = r3
            r3 = r6
            r4 = r6
            java.lang.String r5 = "TaifunPM Created, "
            r4.<init>(r5)
            r4 = r0
            java.lang.String r4 = r4.f4a
            java.lang.StringBuilder r3 = r3.append(r4)
            java.lang.String r3 = r3.toString()
            int r2 = android.util.Log.d(r2, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.puravidaapps.TaifunPM.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    private static Bitmap a(Drawable drawable) {
        Canvas canvas;
        Drawable drawable2 = drawable;
        if (drawable2 instanceof BitmapDrawable) {
            BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable2;
            BitmapDrawable bitmapDrawable2 = bitmapDrawable;
            if (bitmapDrawable.getBitmap() != null) {
                return bitmapDrawable2.getBitmap();
            }
        }
        Bitmap createBitmap = (drawable2.getIntrinsicWidth() <= 0 || drawable2.getIntrinsicHeight() <= 0) ? Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888) : Bitmap.createBitmap(drawable2.getIntrinsicWidth(), drawable2.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        new Canvas(createBitmap);
        Canvas canvas2 = canvas;
        drawable2.setBounds(0, 0, canvas2.getWidth(), canvas2.getHeight());
        drawable2.draw(canvas2);
        return createBitmap;
    }

    private String a() {
        int d = Log.d("TaifunPM", "ApplicationSpecificDirectory");
        return this.f2a.getExternalFilesDir((String) null).toString();
    }

    private String a(String str) {
        StringBuilder sb;
        StringBuilder sb2;
        StringBuilder sb3;
        StringBuilder sb4;
        StringBuilder sb5;
        String str2 = str;
        File externalStorageDirectory = Environment.getExternalStorageDirectory();
        String str3 = str2;
        if (str2.startsWith("file:///")) {
            str3 = str2.substring(7);
        } else if (str2.startsWith("//")) {
            String substring = str2.substring(2);
            if (!this.f5a) {
                str3 = substring;
            } else if (Build.VERSION.SDK_INT >= 29) {
                new StringBuilder();
                str3 = sb5.append(a()).append("/assets/").append(substring).toString();
            } else if (this.f2a.getPackageName().contains("makeroid")) {
                new StringBuilder();
                str3 = sb4.append(Environment.getExternalStorageDirectory().getPath()).append("/Makeroid/assets/").append(substring).toString();
            } else {
                new StringBuilder();
                str3 = sb3.append(Environment.getExternalStorageDirectory().getPath()).append("/AppInventor/assets/").append(substring).toString();
            }
        } else if (!str2.startsWith("/")) {
            new StringBuilder();
            str3 = sb.append(externalStorageDirectory).append(File.separator).append(str2).toString();
        } else if (!str2.startsWith(externalStorageDirectory.toString())) {
            new StringBuilder();
            str3 = sb2.append(externalStorageDirectory).append(str2).toString();
        }
        int d = Log.d("TaifunPM", "completeFileName= ".concat(String.valueOf(str3)));
        return str3;
    }

    /* JADX WARNING: type inference failed for: r10v86, types: [java.io.FileOutputStream] */
    /* JADX WARNING: type inference failed for: r10v87, types: [java.io.FileOutputStream] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static /* synthetic */ void a(com.puravidaapps.TaifunPM r17) {
        /*
            r0 = r17
            java.lang.String r10 = "TaifunPM"
            java.lang.String r11 = "AsyncGet"
            int r10 = android.util.Log.d(r10, r11)
            r10 = r0
            android.content.pm.PackageManager r10 = r10.f3a
            r11 = 128(0x80, float:1.794E-43)
            java.util.List r10 = r10.getInstalledPackages(r11)
            r1 = r10
            org.json.JSONArray r10 = new org.json.JSONArray
            r16 = r10
            r10 = r16
            r11 = r16
            r11.<init>()
            r2 = r10
            r10 = r0
            android.content.pm.PackageManager r10 = r10.f3a
            android.graphics.drawable.Drawable r10 = r10.getDefaultActivityIcon()
            r3 = r10
            r10 = r1
            int r10 = r10.size()
            r4 = r10
            java.io.File r10 = new java.io.File
            r16 = r10
            r10 = r16
            r11 = r16
            r12 = r0
            r16 = r12
            r12 = r16
            r13 = r16
            java.lang.String r13 = r13.f4a
            java.lang.String r12 = r12.a((java.lang.String) r13)
            r11.<init>(r12)
            r16 = r10
            r10 = r16
            r11 = r16
            r5 = r11
            boolean r10 = r10.exists()
            if (r10 != 0) goto L_0x007a
            java.lang.String r10 = "TaifunPM"
            java.lang.StringBuilder r11 = new java.lang.StringBuilder
            r16 = r11
            r11 = r16
            r12 = r16
            java.lang.String r13 = "create diretory: "
            r12.<init>(r13)
            r12 = r0
            java.lang.String r12 = r12.f4a
            java.lang.StringBuilder r11 = r11.append(r12)
            java.lang.String r11 = r11.toString()
            int r10 = android.util.Log.i(r10, r11)
            r10 = r5
            boolean r10 = r10.mkdirs()
        L_0x007a:
            r10 = r1
            java.util.Iterator r10 = r10.iterator()
            r5 = r10
        L_0x0080:
            r10 = r5
            boolean r10 = r10.hasNext()
            if (r10 == 0) goto L_0x025c
            r10 = r5
            java.lang.Object r10 = r10.next()
            android.content.pm.PackageInfo r10 = (android.content.pm.PackageInfo) r10
            r6 = r10
            r10 = r1
            r11 = r6
            int r10 = r10.indexOf(r11)
            r11 = 1
            int r10 = r10 + 1
            r7 = r10
            r10 = r0
            r11 = r7
            r8 = r11
            r16 = r10
            r10 = r16
            r11 = r16
            r7 = r11
            android.app.Activity r10 = r10.a
            c r11 = new c
            r16 = r11
            r11 = r16
            r12 = r16
            r13 = r7
            r14 = r8
            r15 = r4
            r12.<init>(r13, r14, r15)
            r10.runOnUiThread(r11)
            r10 = r6
            android.content.pm.ApplicationInfo r10 = r10.applicationInfo
            r11 = r0
            android.content.Context r11 = r11.f2a
            android.content.pm.PackageManager r11 = r11.getPackageManager()
            java.lang.CharSequence r10 = r10.loadLabel(r11)
            java.lang.String r10 = r10.toString()
            r7 = r10
            r10 = r0
            android.content.Context r10 = r10.f2a
            java.lang.String r10 = r10.getPackageName()
            r11 = r6
            java.lang.String r11 = r11.packageName
            boolean r10 = r10.equals(r11)
            if (r10 == 0) goto L_0x00ff
            java.lang.String r10 = "TaifunPM"
            java.lang.StringBuilder r11 = new java.lang.StringBuilder
            r16 = r11
            r11 = r16
            r12 = r16
            java.lang.String r13 = "appname: "
            r12.<init>(r13)
            r12 = r7
            java.lang.StringBuilder r11 = r11.append(r12)
            java.lang.String r12 = "skipped"
            java.lang.StringBuilder r11 = r11.append(r12)
            java.lang.String r11 = r11.toString()
            int r10 = android.util.Log.i(r10, r11)
            goto L_0x0080
        L_0x00ff:
            r10 = r0
            android.content.pm.PackageManager r10 = r10.f3a     // Catch:{ Exception -> 0x0227 }
            r11 = r6
            java.lang.String r11 = r11.packageName     // Catch:{ Exception -> 0x0227 }
            android.content.Intent r10 = r10.getLaunchIntentForPackage(r11)     // Catch:{ Exception -> 0x0227 }
            r16 = r10
            r10 = r16
            r11 = r16
            r8 = r11
            if (r10 != 0) goto L_0x0139
            java.lang.String r10 = "TaifunPM"
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0227 }
            r16 = r11
            r11 = r16
            r12 = r16
            java.lang.String r13 = "appname: "
            r12.<init>(r13)     // Catch:{ Exception -> 0x0227 }
            r12 = r7
            java.lang.StringBuilder r11 = r11.append(r12)     // Catch:{ Exception -> 0x0227 }
            java.lang.String r12 = "skipped"
            java.lang.StringBuilder r11 = r11.append(r12)     // Catch:{ Exception -> 0x0227 }
            java.lang.String r11 = r11.toString()     // Catch:{ Exception -> 0x0227 }
            int r10 = android.util.Log.i(r10, r11)     // Catch:{ Exception -> 0x0227 }
            goto L_0x0080
        L_0x0139:
            r10 = r0
            android.content.pm.PackageManager r10 = r10.f3a     // Catch:{ Exception -> 0x0227 }
            r11 = r8
            android.graphics.drawable.Drawable r10 = r10.getActivityIcon(r11)     // Catch:{ Exception -> 0x0227 }
            android.graphics.Bitmap r10 = a((android.graphics.drawable.Drawable) r10)     // Catch:{ Exception -> 0x0227 }
            r8 = r10
            r10 = r3
            android.graphics.Bitmap r10 = a((android.graphics.drawable.Drawable) r10)     // Catch:{ Exception -> 0x0227 }
            r9 = r10
            r10 = r8
            if (r10 == 0) goto L_0x0225
            r10 = r9
            r11 = r8
            boolean r10 = r10.equals(r11)     // Catch:{ Exception -> 0x0227 }
            if (r10 != 0) goto L_0x0225
            java.lang.String r10 = "TaifunPM"
            java.lang.String r11 = "appname: "
            r12 = r7
            java.lang.String r12 = java.lang.String.valueOf(r12)     // Catch:{ Exception -> 0x0227 }
            java.lang.String r11 = r11.concat(r12)     // Catch:{ Exception -> 0x0227 }
            int r10 = android.util.Log.i(r10, r11)     // Catch:{ Exception -> 0x0227 }
            org.json.JSONObject r10 = new org.json.JSONObject     // Catch:{ Exception -> 0x0227 }
            r16 = r10
            r10 = r16
            r11 = r16
            r11.<init>()     // Catch:{ Exception -> 0x0227 }
            r16 = r10
            r10 = r16
            r11 = r16
            r9 = r11
            java.lang.String r11 = "package name"
            r12 = r6
            java.lang.String r12 = r12.packageName     // Catch:{ Exception -> 0x0227 }
            org.json.JSONObject r10 = r10.put(r11, r12)     // Catch:{ Exception -> 0x0227 }
            r10 = r9
            java.lang.String r11 = "app name"
            r12 = r7
            org.json.JSONObject r10 = r10.put(r11, r12)     // Catch:{ Exception -> 0x0227 }
            r10 = r9
            java.lang.String r11 = "version name"
            r12 = r6
            java.lang.String r12 = r12.versionName     // Catch:{ Exception -> 0x0227 }
            org.json.JSONObject r10 = r10.put(r11, r12)     // Catch:{ Exception -> 0x0227 }
            r10 = r9
            java.lang.String r11 = "version code"
            r12 = r6
            int r12 = r12.versionCode     // Catch:{ Exception -> 0x0227 }
            org.json.JSONObject r10 = r10.put(r11, r12)     // Catch:{ Exception -> 0x0227 }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0227 }
            r16 = r10
            r10 = r16
            r11 = r16
            r11.<init>()     // Catch:{ Exception -> 0x0227 }
            r11 = r6
            java.lang.String r11 = r11.packageName     // Catch:{ Exception -> 0x0227 }
            java.lang.StringBuilder r10 = r10.append(r11)     // Catch:{ Exception -> 0x0227 }
            java.lang.String r11 = ".png"
            java.lang.StringBuilder r10 = r10.append(r11)     // Catch:{ Exception -> 0x0227 }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x0227 }
            r7 = r10
            r10 = r0
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0227 }
            r16 = r11
            r11 = r16
            r12 = r16
            r12.<init>()     // Catch:{ Exception -> 0x0227 }
            r12 = r0
            java.lang.String r12 = r12.f4a     // Catch:{ Exception -> 0x0227 }
            java.lang.StringBuilder r11 = r11.append(r12)     // Catch:{ Exception -> 0x0227 }
            java.lang.String r12 = java.io.File.separator     // Catch:{ Exception -> 0x0227 }
            java.lang.StringBuilder r11 = r11.append(r12)     // Catch:{ Exception -> 0x0227 }
            r12 = r7
            java.lang.StringBuilder r11 = r11.append(r12)     // Catch:{ Exception -> 0x0227 }
            java.lang.String r11 = r11.toString()     // Catch:{ Exception -> 0x0227 }
            java.lang.String r10 = r10.a((java.lang.String) r11)     // Catch:{ Exception -> 0x0227 }
            r7 = r10
            r10 = r9
            java.lang.String r11 = "icon"
            r12 = r7
            org.json.JSONObject r10 = r10.put(r11, r12)     // Catch:{ Exception -> 0x0227 }
            r10 = r2
            r11 = r9
            org.json.JSONArray r10 = r10.put(r11)     // Catch:{ Exception -> 0x0227 }
            java.io.File r10 = new java.io.File     // Catch:{ Exception -> 0x0227 }
            r16 = r10
            r10 = r16
            r11 = r16
            r12 = r7
            r11.<init>(r12)     // Catch:{ Exception -> 0x0227 }
            r7 = r10
            java.io.FileOutputStream r10 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x0227 }
            r16 = r10
            r10 = r16
            r11 = r16
            r12 = r7
            r11.<init>(r12)     // Catch:{ Exception -> 0x0227 }
            r7 = r10
            r10 = r8
            android.graphics.Bitmap$CompressFormat r11 = android.graphics.Bitmap.CompressFormat.PNG     // Catch:{ Exception -> 0x0227 }
            r12 = 100
            r13 = r7
            boolean r10 = r10.compress(r11, r12, r13)     // Catch:{ Exception -> 0x0227 }
            r10 = r7
            r10.flush()     // Catch:{ Exception -> 0x0227 }
            r10 = r7
            r10.close()     // Catch:{ Exception -> 0x0227 }
        L_0x0225:
            goto L_0x0080
        L_0x0227:
            r10 = move-exception
            r8 = r10
            java.lang.String r10 = "TaifunPM"
            java.lang.StringBuilder r11 = new java.lang.StringBuilder
            r16 = r11
            r11 = r16
            r12 = r16
            r12.<init>()
            r12 = r8
            java.lang.String r12 = r12.getMessage()
            java.lang.StringBuilder r11 = r11.append(r12)
            java.lang.String r12 = ", package name: "
            java.lang.StringBuilder r11 = r11.append(r12)
            r12 = r6
            java.lang.String r12 = r12.packageName
            java.lang.StringBuilder r11 = r11.append(r12)
            java.lang.String r11 = r11.toString()
            int r10 = android.util.Log.e(r10, r11)
            r10 = r8
            r10.printStackTrace()
            goto L_0x0080
        L_0x025c:
            r10 = r2
            r5 = r10
            r10 = r0
            android.app.Activity r10 = r10.a
            b r11 = new b
            r16 = r11
            r11 = r16
            r12 = r16
            r13 = r0
            r14 = r5
            r12.<init>(r13, r14)
            r10.runOnUiThread(r11)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.puravidaapps.TaifunPM.a(com.puravidaapps.TaifunPM):void");
    }

    public String DefaultDirectory() {
        return this.f4a;
    }

    public void GetPackages() {
        Runnable runnable;
        new a(this);
        AsynchUtil.runAsynchronously(runnable);
    }

    public void GotPackages(Object obj) {
        int d = Log.d("TaifunPM", "GotPackages");
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "GotPackages", new Object[]{obj});
    }

    public void LaunchApp(String str) {
        Intent launchIntentForPackage = this.f3a.getLaunchIntentForPackage(str);
        Intent intent = launchIntentForPackage;
        if (launchIntentForPackage != null) {
            try {
                this.a.startActivity(intent);
            } catch (ActivityNotFoundException e) {
                ActivityNotFoundException activityNotFoundException = e;
                if (!this.b) {
                    Toast.makeText(this.f2a, "app to launch not found", 0).show();
                }
                int e2 = Log.e("TaifunPM", activityNotFoundException.getMessage());
                activityNotFoundException.printStackTrace();
            }
        }
    }

    public void Progress(int i, int i2) {
        int d = Log.d("TaifunPM", "Progress");
        Object[] objArr = new Object[2];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = Integer.valueOf(i2);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "Progress", objArr2);
    }

    public void SuppressWarnings(boolean z) {
        boolean z2 = z;
        this.b = z2;
    }

    public boolean SuppressWarnings() {
        return this.b;
    }
}
