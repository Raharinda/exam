package com.puravidaapps;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import java.io.File;

@SimpleObject(external = true)
@DesignerComponent(category = ComponentCategory.EXTENSION, description = "Settings Extension. Version 7a (FREE VERSION) as of 2019-02-13 for App Inventor version nb175 and Companion version 2.51.", helpUrl = "https://puravidaapps.com/settings.php", iconName = "https://puravidaapps.com/images/taifun16.png", nonVisible = true, version = 7)
@UsesPermissions(permissionNames = "android.permission.READ_EXTERNAL_STORAGE, android.permission.WRITE_SETTINGS, android.permission.ACCESS_NOTIFICATION_POLICY")
public class TaifunSettings extends AndroidNonvisibleComponent implements Component {
    private static final String LOG_TAG = "TaifunSettings";
    public static final int VERSION = 7;
    private final Activity activity;
    private AudioManager audioManager;
    private ComponentContainer container;
    private ContentResolver contentResolver;
    private Context context;
    private boolean isAlarm = false;
    private boolean isNotification = false;
    private boolean isRepl = false;
    private boolean isRingtone = false;
    private Ringtone ringtone;
    private boolean showUI;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public TaifunSettings(com.google.appinventor.components.runtime.ComponentContainer r6) {
        /*
            r5 = this;
            r0 = r5
            r1 = r6
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            r3 = 0
            r2.isRepl = r3
            r2 = r0
            r3 = 0
            r2.isRingtone = r3
            r2 = r0
            r3 = 0
            r2.isNotification = r3
            r2 = r0
            r3 = 0
            r2.isAlarm = r3
            r2 = r0
            com.google.appinventor.components.runtime.Form r2 = r2.form
            boolean r2 = r2 instanceof com.google.appinventor.components.runtime.ReplForm
            if (r2 == 0) goto L_0x0026
            r2 = r0
            r3 = 1
            r2.isRepl = r3
        L_0x0026:
            r2 = r0
            r3 = r1
            r2.container = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.context = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.activity = r3
            r2 = r0
            r3 = r0
            android.content.Context r3 = r3.context
            android.content.ContentResolver r3 = r3.getContentResolver()
            r2.contentResolver = r3
            r2 = r0
            r3 = r0
            android.content.Context r3 = r3.context
            android.content.Context r3 = r3.getApplicationContext()
            java.lang.String r4 = "audio"
            java.lang.Object r3 = r3.getSystemService(r4)
            android.media.AudioManager r3 = (android.media.AudioManager) r3
            r2.audioManager = r3
            java.lang.String r2 = "TaifunSettings"
            java.lang.String r3 = "TaifunSettings Created"
            int r2 = android.util.Log.d(r2, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.puravidaapps.TaifunSettings.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "brightness (a value between 0 and 255)")
    public int Brightness() {
        StringBuilder sb;
        int brightness = Settings.System.getInt(this.contentResolver, "screen_brightness", 0);
        new StringBuilder();
        int d = Log.d(LOG_TAG, sb.append("Brightness (get): ").append(brightness).toString());
        return brightness;
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "whether User Interface shoud be showed while setting the volume.")
    public boolean ShowUI() {
        return this.showUI;
    }

    @DesignerProperty(defaultValue = "True", editorType = "boolean")
    @SimpleProperty
    public void ShowUI(boolean showUI2) {
        boolean z = showUI2;
        this.showUI = z;
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "media volume in percent.")
    public int VolumeMusic() {
        return getVolume(3);
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "ringtone volume in percent.")
    public int VolumeRing() {
        return getVolume(2);
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "notification volume in percent.")
    public int VolumeAlarm() {
        return getVolume(4);
    }

    private int getVolume(int i) {
        StringBuilder sb;
        int type = i;
        int maxVolume = this.audioManager.getStreamMaxVolume(type);
        int currentVolume = this.audioManager.getStreamVolume(type);
        int percent = (currentVolume * 100) / maxVolume;
        new StringBuilder();
        int d = Log.d(LOG_TAG, sb.append("getVolume,  percent= ").append(currentVolume).append(" * 100 / ").append(maxVolume).append(" = ").append(percent).toString());
        return percent;
    }

    @DesignerProperty(defaultValue = "82", editorType = "non_negative_integer")
    @SimpleProperty
    public void VolumeMusic(int percent) {
        setVolume(percent, 3);
    }

    @DesignerProperty(defaultValue = "82", editorType = "non_negative_integer")
    @SimpleProperty
    public void VolumeRing(int i) {
        int percent = i;
        if (Build.VERSION.SDK_INT < 28) {
            setVolume(percent, 2);
        }
    }

    @DesignerProperty(defaultValue = "82", editorType = "non_negative_integer")
    @SimpleProperty
    public void VolumeAlarm(int percent) {
        setVolume(percent, 4);
    }

    private void setVolume(int i, int i2) {
        StringBuilder sb;
        int percent = i;
        int type = i2;
        if (percent < 0) {
            percent = 0;
        } else if (percent > 255) {
            percent = 100;
        }
        int flagShowUi = this.showUI ? 1 : 0;
        int maxVolume = this.audioManager.getStreamMaxVolume(type);
        int newVolume = (maxVolume * percent) / 100;
        new StringBuilder();
        int d = Log.d(LOG_TAG, sb.append("setVolume, newVolume: ").append(maxVolume).append(" * ").append(percent).append(" / 100 = ").append(newVolume).toString());
        this.audioManager.setStreamVolume(type, newVolume, flagShowUi);
    }

    @SimpleFunction(description = "Get current ringtone. Type can be RINGTONE, NOTIFICATION or ALARM.")
    public String RingtoneGet(String str) {
        StringBuilder sb;
        String type = str;
        new StringBuilder();
        int d = Log.d(LOG_TAG, sb.append("RingtoneGet, type: ").append(type).toString());
        setRingtone(type);
        return this.ringtone.getTitle(this.context);
    }

    @SimpleFunction(description = "Play ringtone. Type can be RINGTONE, NOTIFICATION or ALARM.")
    public void RingtonePlay(String str) {
        StringBuilder sb;
        String type = str;
        new StringBuilder();
        int d = Log.d(LOG_TAG, sb.append("RingtonePlay, type: ").append(type).toString());
        if (this.ringtone != null) {
            this.ringtone.stop();
        }
        setRingtone(type);
        this.ringtone.play();
    }

    @SimpleFunction(description = "Stop currently playing ringtone.")
    public void RingtoneStop() {
        int d = Log.d(LOG_TAG, "RingtoneStop");
        if (this.ringtone != null) {
            this.ringtone.stop();
        }
    }

    private void setRingtone(String str) {
        Uri uri;
        String type = str;
        if (type.equals("NOTIFICATION")) {
            int d = Log.d(LOG_TAG, "setRingtone, NOTIFICATION");
            uri = RingtoneManager.getActualDefaultRingtoneUri(this.context, 2);
        } else if (type.equals("ALARM")) {
            int d2 = Log.d(LOG_TAG, "setRingtone, ALARM");
            uri = RingtoneManager.getActualDefaultRingtoneUri(this.context, 4);
        } else {
            int d3 = Log.d(LOG_TAG, "setRingtone, RINGTONE");
            uri = RingtoneManager.getActualDefaultRingtoneUri(this.context, 1);
        }
        this.ringtone = RingtoneManager.getRingtone(this.context, uri);
    }

    private String completeFileName(String str) {
        StringBuilder sb;
        StringBuilder sb2;
        StringBuilder sb3;
        StringBuilder sb4;
        String fileName = str;
        File sd = Environment.getExternalStorageDirectory();
        String completeFileName = fileName;
        if (fileName.startsWith("file:///")) {
            completeFileName = fileName.substring(7);
        } else if (fileName.startsWith("//")) {
            String fileName2 = fileName.substring(2);
            if (this.isRepl) {
                new StringBuilder();
                completeFileName = sb3.append(Environment.getExternalStorageDirectory().getPath()).append("/AppInventor/assets/").append(fileName2).toString();
            } else {
                completeFileName = fileName2;
            }
        } else if (!fileName.startsWith("/")) {
            new StringBuilder();
            completeFileName = sb.append(sd).append(File.separator).append(fileName).toString();
        } else if (!fileName.startsWith(sd.toString())) {
            new StringBuilder();
            completeFileName = sb2.append(sd).append(fileName).toString();
        }
        new StringBuilder();
        int d = Log.d(LOG_TAG, sb4.append("completeFileName= ").append(completeFileName).toString());
        return completeFileName;
    }

    private static String fileExtension(String str) {
        String name = str;
        int idx = name.lastIndexOf(46);
        if (idx == -1) {
            return "";
        }
        if (idx == name.length() - 1) {
            return "";
        }
        return name.substring(idx + 1, name.length());
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "brightness mode (MANUAL or AUTO)")
    public String BrightnessMode() {
        StringBuilder sb;
        int brightnessMode = Settings.System.getInt(this.contentResolver, "screen_brightness_mode", 0);
        new StringBuilder();
        int d = Log.d(LOG_TAG, sb.append("BrightnessMode (get): ").append(brightnessMode).toString());
        return brightnessMode == 1 ? "AUTO" : "MANUAL";
    }

    @SimpleProperty(category = PropertyCategory.BEHAVIOR, description = "font scale")
    public float FontScale() {
        int d = Log.d(LOG_TAG, "FontScale");
        return Settings.System.getFloat(this.activity.getContentResolver(), "font_scale", 1.0f);
    }
}
