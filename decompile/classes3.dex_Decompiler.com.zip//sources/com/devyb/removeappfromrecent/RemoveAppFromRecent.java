package com.devyb.removeappfromrecent;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.ComponentContainer;
import java.util.List;

@SimpleObject(external = true)
@DesignerComponent(category = ComponentCategory.EXTENSION, description = "This extension helps you to remove app from recent Apps.", iconName = "https://res.cloudinary.com/dujfnjfcz/image/upload/v1596225104/icon16.png", nonVisible = true, version = 2)
public class RemoveAppFromRecent extends AndroidNonvisibleComponent {
    private Activity activity;
    private ComponentContainer container;
    private Context context;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public RemoveAppFromRecent(com.google.appinventor.components.runtime.ComponentContainer r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            r3 = r1
            r2.container = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.activity = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.context = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.devyb.removeappfromrecent.RemoveAppFromRecent.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    @SimpleFunction
    public void Add() {
        List<ActivityManager.AppTask> appTasks;
        ActivityManager activityManager = (ActivityManager) this.context.getSystemService("activity");
        if (activityManager != null && (appTasks = activityManager.getAppTasks()) != null && appTasks.size() > 0) {
            appTasks.get(0).setExcludeFromRecents(false);
        }
    }

    @SimpleFunction
    public void Remove() {
        List<ActivityManager.AppTask> appTasks;
        ActivityManager activityManager = (ActivityManager) this.context.getSystemService("activity");
        if (activityManager != null && (appTasks = activityManager.getAppTasks()) != null && appTasks.size() > 0) {
            appTasks.get(0).setExcludeFromRecents(true);
        }
    }
}
