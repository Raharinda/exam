package com.jdl.FloatingView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import com.chstudio.extensions.AndroidSetting.AndroidSetting;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.ActivityResultListener;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.OnDestroyListener;
import com.google.appinventor.components.runtime.util.YailList;
import com.puravidaapps.TaifunPM;

@SimpleObject(external = true)
@DesignerComponent(category = ComponentCategory.EXTENSION, description = "Floating View <br> Developed by Jarlisson", helpUrl = "https://github.com/jarlisson2/FloatingViewAIX", iconName = "aiwebres/icon.png", nonVisible = true, version = 1)
@UsesPermissions(permissionNames = "android.permission.ACTION_MANAGE_OVERLAY_PERMISSION,android.permission.SYSTEM_ALERT_WINDOW")
public class FloatingView extends AndroidNonvisibleComponent implements ActivityResultListener, OnDestroyListener {
    private static final int REQUEST_CODE_DRAW_OVERLAY_PERMISSION = 5;
    /* access modifiers changed from: private */
    public static boolean mIsFloatViewShowing = false;
    public Activity activity;
    /* access modifiers changed from: private */
    public boolean clickable = false;
    public ComponentContainer container;
    public Context context;
    /* access modifiers changed from: private */
    public int indexChild;
    public boolean isRepl = false;
    /* access modifiers changed from: private */
    public int mFloatViewFirstX;
    /* access modifiers changed from: private */
    public int mFloatViewFirstY;
    /* access modifiers changed from: private */
    public int mFloatViewLastX;
    /* access modifiers changed from: private */
    public int mFloatViewLastY;
    /* access modifiers changed from: private */
    public boolean mFloatViewTouchConsumedByMove = false;
    /* access modifiers changed from: private */
    public WindowManager mWindowManager;
    /* access modifiers changed from: private */
    public WindowManager.LayoutParams params;
    private int requestCode = 0;
    /* access modifiers changed from: private */
    public RelativeLayout rl;
    /* access modifiers changed from: private */
    public View viewHV;
    /* access modifiers changed from: private */
    public ViewGroup viewParent;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public FloatingView(com.google.appinventor.components.runtime.ComponentContainer r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            r3 = 0
            r2.isRepl = r3
            r2 = r0
            r3 = 0
            r2.mFloatViewTouchConsumedByMove = r3
            r2 = r0
            r3 = 0
            r2.clickable = r3
            r2 = r0
            r3 = 0
            r2.requestCode = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.context = r3
            r2 = r0
            r3 = r1
            r2.container = r3
            r2 = r0
            r3 = r0
            android.content.Context r3 = r3.context
            android.app.Activity r3 = (android.app.Activity) r3
            r2.activity = r3
            r2 = r0
            com.google.appinventor.components.runtime.Form r2 = r2.form
            r3 = r0
            r2.registerForOnDestroy(r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.jdl.FloatingView.FloatingView.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    static /* synthetic */ RelativeLayout access$002(FloatingView floatingView, RelativeLayout relativeLayout) {
        RelativeLayout relativeLayout2 = relativeLayout;
        RelativeLayout relativeLayout3 = relativeLayout2;
        floatingView.rl = relativeLayout3;
        return relativeLayout2;
    }

    static /* synthetic */ int access$1002(FloatingView floatingView, int i) {
        int i2 = i;
        int i3 = i2;
        floatingView.mFloatViewFirstY = i3;
        return i2;
    }

    static /* synthetic */ boolean access$102(boolean z) {
        boolean z2 = z;
        mIsFloatViewShowing = z2;
        return z2;
    }

    static /* synthetic */ boolean access$1102(FloatingView floatingView, boolean z) {
        boolean z2 = z;
        boolean z3 = z2;
        floatingView.mFloatViewTouchConsumedByMove = z3;
        return z2;
    }

    static /* synthetic */ WindowManager access$202(FloatingView floatingView, WindowManager windowManager) {
        WindowManager windowManager2 = windowManager;
        WindowManager windowManager3 = windowManager2;
        floatingView.mWindowManager = windowManager3;
        return windowManager2;
    }

    static /* synthetic */ int access$702(FloatingView floatingView, int i) {
        int i2 = i;
        int i3 = i2;
        floatingView.mFloatViewLastX = i3;
        return i2;
    }

    static /* synthetic */ int access$802(FloatingView floatingView, int i) {
        int i2 = i;
        int i3 = i2;
        floatingView.mFloatViewFirstX = i3;
        return i2;
    }

    static /* synthetic */ int access$902(FloatingView floatingView, int i) {
        int i2 = i;
        int i3 = i2;
        floatingView.mFloatViewLastY = i3;
        return i2;
    }

    private boolean checkDrawOverlayPermission(boolean z) {
        Intent intent;
        StringBuilder sb;
        boolean z2 = z;
        if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this.context)) {
            return true;
        }
        if (z2) {
            new StringBuilder();
            new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse(sb.append("package:").append(this.context.getPackageName()).toString()));
            Intent intent2 = intent;
            if (this.requestCode == 0) {
                this.requestCode = this.form.registerForActivityResult(this);
            }
            this.container.$context().startActivityForResult(intent2, REQUEST_CODE_DRAW_OVERLAY_PERMISSION);
        }
        return false;
    }

    private void dismissFloatView() {
        Runnable runnable;
        if (mIsFloatViewShowing) {
            mIsFloatViewShowing = false;
            new Runnable(this) {
                final /* synthetic */ FloatingView this$0;

                {
                    this.this$0 = r5;
                }

                public void run() {
                    if (this.this$0.mWindowManager != null) {
                        this.this$0.mWindowManager.removeViewImmediate(this.this$0.rl);
                    }
                }
            };
            this.activity.runOnUiThread(runnable);
        }
    }

    private void floatViewHV(int i, int i2) {
        RelativeLayout relativeLayout;
        View.OnClickListener onClickListener;
        View.OnTouchListener onTouchListener;
        int i3 = i;
        int i4 = i2;
        dismissFloatView();
        new RelativeLayout(this.context);
        this.rl = relativeLayout;
        WindowManager.LayoutParams layoutParams = r12;
        WindowManager.LayoutParams layoutParams2 = new WindowManager.LayoutParams(-2, -2, Build.VERSION.SDK_INT >= 26 ? 2038 : 2002, 262152, -3);
        this.params = layoutParams;
        this.params.gravity = 51;
        this.params.x = i3;
        this.params.y = i4;
        View childAt = this.viewHV instanceof ViewGroup ? ((ViewGroup) this.viewHV).getChildAt(0) : this.viewHV;
        new View.OnClickListener(this) {
            final /* synthetic */ FloatingView this$0;

            {
                this.this$0 = r5;
            }

            public void onClick(View view) {
                View view2 = view;
                this.this$0.ClickView();
            }
        };
        childAt.setOnClickListener(onClickListener);
        new View.OnTouchListener(this) {
            final /* synthetic */ FloatingView this$0;

            {
                this.this$0 = r5;
            }

            public boolean onTouch(View view, MotionEvent motionEvent) {
                View view2 = view;
                MotionEvent motionEvent2 = motionEvent;
                int access$700 = this.this$0.mFloatViewLastX - this.this$0.mFloatViewFirstX;
                int access$900 = this.this$0.mFloatViewLastY - this.this$0.mFloatViewFirstY;
                switch (motionEvent2.getActionMasked()) {
                    case 0:
                        int access$702 = FloatingView.access$702(this.this$0, (int) motionEvent2.getRawX());
                        int access$902 = FloatingView.access$902(this.this$0, (int) motionEvent2.getRawY());
                        int access$802 = FloatingView.access$802(this.this$0, this.this$0.mFloatViewLastX);
                        int access$1002 = FloatingView.access$1002(this.this$0, this.this$0.mFloatViewLastY);
                        boolean access$1102 = FloatingView.access$1102(this.this$0, !this.this$0.clickable);
                        break;
                    case AndroidSetting.VERSION:
                        boolean access$11022 = FloatingView.access$1102(this.this$0, !this.this$0.clickable);
                        break;
                    case TaifunPM.VERSION /*2*/:
                        int rawX = ((int) motionEvent2.getRawX()) - this.this$0.mFloatViewLastX;
                        int rawY = ((int) motionEvent2.getRawY()) - this.this$0.mFloatViewLastY;
                        int access$7022 = FloatingView.access$702(this.this$0, (int) motionEvent2.getRawX());
                        int access$9022 = FloatingView.access$902(this.this$0, (int) motionEvent2.getRawY());
                        if (Math.abs(access$700) >= FloatingView.REQUEST_CODE_DRAW_OVERLAY_PERMISSION || Math.abs(access$900) >= FloatingView.REQUEST_CODE_DRAW_OVERLAY_PERMISSION) {
                            if (motionEvent2.getPointerCount() != 1) {
                                boolean access$11023 = FloatingView.access$1102(this.this$0, false);
                                break;
                            } else {
                                this.this$0.params.x += rawX;
                                this.this$0.params.y += rawY;
                                boolean access$11024 = FloatingView.access$1102(this.this$0, true);
                                if (this.this$0.mWindowManager != null) {
                                    this.this$0.PositionMoved(this.this$0.params.x, this.this$0.params.y);
                                    this.this$0.mWindowManager.updateViewLayout(this.this$0.rl, this.this$0.params);
                                    break;
                                }
                            }
                        } else {
                            boolean access$11025 = FloatingView.access$1102(this.this$0, false);
                            break;
                        }
                        break;
                }
                return this.this$0.mFloatViewTouchConsumedByMove;
            }
        };
        childAt.setOnTouchListener(onTouchListener);
        if (this.viewHV.getParent() != null) {
            this.viewParent = (ViewGroup) this.viewHV.getParent();
            this.indexChild = this.viewParent.indexOfChild(this.viewHV);
            ((ViewGroup) this.viewHV.getParent()).removeView(this.viewHV);
        }
        this.rl.addView(this.viewHV);
    }

    private void overlapView(AndroidViewComponent androidViewComponent, AndroidViewComponent androidViewComponent2, YailList yailList, int i) {
        FrameLayout frameLayout;
        FrameLayout.LayoutParams layoutParams;
        AndroidViewComponent androidViewComponent3 = androidViewComponent;
        AndroidViewComponent androidViewComponent4 = androidViewComponent2;
        YailList yailList2 = yailList;
        int i2 = i;
        if (i2 == 0) {
            i2 = 51;
        } else if (i2 == 1) {
            i2 = 49;
        } else if (i2 == 2) {
            i2 = 53;
        } else if (i2 == 3) {
            i2 = 19;
        } else if (i2 == 4) {
            i2 = 17;
        } else if (i2 == REQUEST_CODE_DRAW_OVERLAY_PERMISSION) {
            i2 = 21;
        } else if (i2 == 6) {
            i2 = 83;
        } else if (i2 == 7) {
            i2 = 81;
        } else if (i2 == 8) {
            i2 = 85;
        }
        View view = androidViewComponent4.getView();
        if (view.getParent() != null) {
            ((ViewGroup) view.getParent()).removeView(view);
        }
        new FrameLayout(this.context);
        FrameLayout frameLayout2 = frameLayout;
        frameLayout2.addView(view);
        new FrameLayout.LayoutParams(-2, -2);
        FrameLayout.LayoutParams layoutParams2 = layoutParams;
        layoutParams2.gravity = i2;
        String[] stringArray = yailList2.toStringArray();
        layoutParams2.setMargins(stringArray.length > 0 ? Integer.parseInt(stringArray[0]) : 0, stringArray.length > 1 ? Integer.parseInt(stringArray[1]) : 0, stringArray.length > 2 ? Integer.parseInt(stringArray[2]) : 0, stringArray.length > 3 ? Integer.parseInt(stringArray[3]) : 0);
        frameLayout2.setLayoutParams(layoutParams2);
        ((FrameLayout) androidViewComponent3.getView()).addView(frameLayout2);
    }

    private void showFloatView() {
        Runnable runnable;
        if (!mIsFloatViewShowing) {
            mIsFloatViewShowing = true;
            new Runnable(this) {
                final /* synthetic */ FloatingView this$0;

                {
                    this.this$0 = r5;
                }

                public void run() {
                    if (!this.this$0.activity.isFinishing()) {
                        WindowManager access$202 = FloatingView.access$202(this.this$0, (WindowManager) this.this$0.activity.getSystemService("window"));
                        if (this.this$0.mWindowManager != null) {
                            this.this$0.rl.clearFocus();
                            this.this$0.mWindowManager.addView(this.this$0.rl, this.this$0.params);
                        }
                    }
                }
            };
            this.activity.runOnUiThread(runnable);
        }
    }

    @SimpleFunction(description = "Checks whether the overlay permission is active.")
    public boolean CheckDrawOverlayPermission() {
        return checkDrawOverlayPermission(false);
    }

    @SimpleEvent(description = "Executes after clicking on the floating component.")
    public void ClickView() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "ClickView", new Object[0]);
    }

    @SimpleFunction(description = "Hides the floating component.")
    public void DismissViewFloating() {
        dismissFloatView();
    }

    @SimpleProperty(description = "Checks whether the floating view is clickable.")
    public boolean GetClickable() {
        return this.clickable;
    }

    @SimpleProperty(description = "Checks if the floating is present on the screen.")
    public boolean GetFloatingViewVisible() {
        return mIsFloatViewShowing;
    }

    @SimpleFunction(description = "Gets the X coordinate that the floating view is in.")
    public int GetPositionX() {
        return this.params.x;
    }

    @SimpleFunction(description = "Gets the Y coordinate that the floating view is in.")
    public int GetPositionY() {
        return this.params.y;
    }

    @SimpleFunction(description = "Loses focus on the floating window.")
    public void LoseFocusFloatingView() {
        Runnable runnable;
        if (mIsFloatViewShowing) {
            new Runnable(this) {
                final /* synthetic */ FloatingView this$0;

                {
                    this.this$0 = r5;
                }

                public void run() {
                    if (this.this$0.mWindowManager != null) {
                        this.this$0.rl.clearFocus();
                        this.this$0.params.flags = 262152;
                        this.this$0.mWindowManager.updateViewLayout(this.this$0.rl, this.this$0.params);
                    }
                }
            };
            this.activity.runOnUiThread(runnable);
        }
    }

    @SimpleFunction(description = "Through this block it is possible to overlap any visible component on another.\nmargins (list):\n\tindex 1 -> margin left (number)\n\tindex 2 -> margin top (number)\n\tindex 3 -> margin right(number)\n\tindex 4 -> margin bottom (number)\ngravity (number):\n\t0  -> TOP-LEFT\n\t1  -> TOP-CENTER\n\t2  -> TOP-RIGHT\n\t3  -> CENTER-LEFT\n\t4  -> CENTER\n\t5  -> CENTER-RIGHT\n\t6  -> BOTTOM-LEFT\n\t7  -> BOTTOM-CENTER\n\t8  -> BOTTOM-RIGHT\n")
    public void OverlapView(AndroidViewComponent androidViewComponent, AndroidViewComponent androidViewComponent2, YailList yailList, int i) {
        overlapView(androidViewComponent, androidViewComponent2, yailList, i);
    }

    @SimpleEvent(description = "View moved from position")
    public void PositionMoved(int i, int i2) {
        Object[] objArr = new Object[2];
        objArr[0] = Integer.valueOf(i);
        Object[] objArr2 = objArr;
        objArr2[1] = Integer.valueOf(i2);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "PositionMoved", objArr2);
    }

    @SimpleFunction(description = "Redirects to application settings to allow overlay permission.")
    public void RequestDrawOverlayPermission() {
        boolean checkDrawOverlayPermission = checkDrawOverlayPermission(true);
    }

    @SimpleFunction(description = "Prompts to focus on the floating window.")
    public void RequestFocusFloatingView() {
        Runnable runnable;
        if (mIsFloatViewShowing) {
            new Runnable(this) {
                final /* synthetic */ FloatingView this$0;

                {
                    this.this$0 = r5;
                }

                public void run() {
                    if (this.this$0.mWindowManager != null) {
                        this.this$0.params.flags = 262144;
                        this.this$0.mWindowManager.updateViewLayout(this.this$0.rl, this.this$0.params);
                    }
                }
            };
            this.activity.runOnUiThread(runnable);
        }
    }

    @SimpleFunction(description = "Returns the floating window to the screen.")
    public void RestoreFloatingView() {
        Runnable runnable;
        new Runnable(this) {
            final /* synthetic */ FloatingView this$0;

            {
                this.this$0 = r5;
            }

            public void run() {
                if (this.this$0.rl != null) {
                    if (FloatingView.mIsFloatViewShowing && this.this$0.mWindowManager != null) {
                        this.this$0.mWindowManager.removeView(this.this$0.rl);
                    }
                    boolean access$102 = FloatingView.access$102(false);
                    this.this$0.rl.removeView(this.this$0.viewHV);
                    View childAt = this.this$0.viewHV instanceof ViewGroup ? ((ViewGroup) this.this$0.viewHV).getChildAt(0) : this.this$0.viewHV;
                    childAt.setOnClickListener((View.OnClickListener) null);
                    childAt.setOnTouchListener((View.OnTouchListener) null);
                    this.this$0.viewParent.addView(this.this$0.viewHV, this.this$0.indexChild);
                    RelativeLayout access$002 = FloatingView.access$002(this.this$0, (RelativeLayout) null);
                }
            }
        };
        this.activity.runOnUiThread(runnable);
    }

    @SimpleProperty(description = "Adjusts whether the floating view is clickable")
    public void SetClickable(boolean z) {
        boolean z2 = z;
        this.clickable = z2;
    }

    @SimpleFunction(description = "Moves the floating view to the indicated coordinates.")
    public void SetPosition(int i, int i2) {
        this.params.x = i;
        this.params.y = i2;
        if (this.mWindowManager != null) {
            PositionMoved(this.params.x, this.params.y);
            this.mWindowManager.updateViewLayout(this.rl, this.params);
        }
    }

    @SimpleFunction(description = "Initializes the component you want to float.")
    public void SetupView(AndroidViewComponent androidViewComponent, boolean z, int i, int i2) {
        this.viewHV = androidViewComponent.getView();
        this.clickable = z;
        floatViewHV(i, i2);
    }

    @SimpleFunction(description = "Displays the floating component.")
    public void ShowFloatingView() {
        if (checkDrawOverlayPermission(true)) {
            showFloatView();
        }
    }

    public void onDestroy() {
        if (this.mWindowManager != null) {
            this.mWindowManager.removeViewImmediate(this.rl);
        }
    }

    public void resultReturned(int i, int i2, Intent intent) {
        int i3 = i2;
        Intent intent2 = intent;
        if (i == REQUEST_CODE_DRAW_OVERLAY_PERMISSION && Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this.context)) {
            showFloatView();
        }
    }
}
