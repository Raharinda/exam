package defpackage;

import com.puravidaapps.TaifunPM;

/* renamed from: b  reason: default package */
public final class b implements Runnable {
    private /* synthetic */ TaifunPM a;

    /* renamed from: a  reason: collision with other field name */
    private /* synthetic */ Object f0a;

    public b(TaifunPM taifunPM, Object obj) {
        this.a = taifunPM;
        this.f0a = obj;
    }

    public final void run() {
        this.a.GotPackages(this.f0a);
    }
}
