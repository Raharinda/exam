package defpackage;

import com.puravidaapps.TaifunPM;

/* renamed from: c  reason: default package */
public final class c implements Runnable {
    private /* synthetic */ int a;

    /* renamed from: a  reason: collision with other field name */
    private /* synthetic */ TaifunPM f1a;
    private /* synthetic */ int b;

    public c(TaifunPM taifunPM, int i, int i2) {
        this.f1a = taifunPM;
        this.a = i;
        this.b = i2;
    }

    public final void run() {
        this.f1a.Progress(this.a, this.b);
    }
}
