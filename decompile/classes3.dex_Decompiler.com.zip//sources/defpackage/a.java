package defpackage;

import com.puravidaapps.TaifunPM;

/* renamed from: a  reason: default package */
public final class a implements Runnable {
    private /* synthetic */ TaifunPM a;

    public a(TaifunPM taifunPM) {
        this.a = taifunPM;
    }

    public final void run() {
        TaifunPM.a(this.a);
    }
}
